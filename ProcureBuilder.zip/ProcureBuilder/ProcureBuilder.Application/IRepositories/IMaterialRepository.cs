﻿using ProcureBuilder.Materials.DTOs;
using ProcureBuilder.Materials.Entities;
using ProcureBuilder.Repositories;

namespace ProcureBuilder.IRepositories;

public interface IMaterialRepository<TEntity> :
    IBaseRepository<Material>,
    IDisposable where TEntity : class
{
    ValueTask<MaterialResponse> CreateMaterialAsync(CreateMaterialDTO request);
    ValueTask<MaterialResponse> UpdateMaterialAsync(UpdateMaterialDTO request);
    ValueTask<MaterialResponse> DeleteMaterialAsync(DeleteMaterialDTO request);
    ValueTask<MaterialResponse> GetMaterialsByIdAsync(Guid projectId);
    ValueTask<GetBidMaterialListResponse> GetBidMaterialListAsync(Guid projectId);
    ValueTask<BidMaterialReportResponse> GetBidMaterialReportAsync(BidMaterialFilters filters);
}