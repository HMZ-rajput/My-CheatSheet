﻿using ProcureBuilder.Repositories;
using ProcureBuilder.StorageTypes.DTOs;
using ProcureBuilder.StorageTypes.Entities;

namespace ProcureBuilder.IRepositories;

public interface IStorageTypeRepository<TEntity> :
    IBaseRepository<StorageType>,
    IDisposable where TEntity : class
{
    ValueTask<StorageTypeResponse> CreateStorageTypeAsync(CreateStorageTypeDTO request);
    ValueTask<StorageTypeResponse> UpdateStorageTypeAsync(Guid storageTypeId, UpdateStorageTypeDTO request);
    ValueTask<StorageTypeResponse> DeleteStorageTypeAsync(Guid storageTypeId, string? modifiedBy);
    ValueTask<GetAllStorageTypesResponse> GetAllStorageTypesAsync();
}