﻿using ProcureBuilder.PurchaseOrders.DTOs;
using ProcureBuilder.PurchaseOrders.Entities;
using ProcureBuilder.Repositories;

namespace ProcureBuilder.IRepositories;

public interface IPurchaseOrderApprovalRepository<TEntity> :
    IBaseRepository<PurchaseOrderApproval>,
    IDisposable where TEntity : class
{
    ValueTask<PurchaseOrderApprovalResponse> CreatePurchaseOrderApprovalAsync(CreatePurchaseOrderApprovalDTO request);
    ValueTask<AllPurchaseOrderApprovalResponse> GetPurchaseOrderApprovalAsync(Guid purchaseOrderId);
}

