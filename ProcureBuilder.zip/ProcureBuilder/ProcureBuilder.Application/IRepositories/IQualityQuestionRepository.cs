﻿using ProcureBuilder.QualityQuestions.DTOs;
using ProcureBuilder.QualityQuestions.Entities;
using ProcureBuilder.Repositories;

namespace ProcureBuilder.IRepositories;
public interface IQualityQuestionRepository<TEntity> :
IBaseRepository<QualityQuestion>,
IDisposable where TEntity : class
{
    ValueTask<QualityQuestionsResponse> CreateQualityQuestionsAsync(CreateQualityQuestion request);
    ValueTask<QualityQuestionsResponse> GetQualityQuestionsAsync(Guid projectId);
    ValueTask<QualityQuestionsResponse> DeleteAllQualityQuestionsAsync(Guid projectId, string? ModifiedBy);
    ValueTask<QualityQuestionsResponse> UpdateQualityQuestionsAsync(Guid projectId, UpdateQualityQuestionRequestDTO request);
}
