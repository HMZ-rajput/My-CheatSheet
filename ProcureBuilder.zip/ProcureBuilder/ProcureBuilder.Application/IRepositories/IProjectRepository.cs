﻿using ProcureBuilder.Projects.DTOs;
using ProcureBuilder.Projects.Entities;
using ProcureBuilder.Repositories;

namespace ProcureBuilder.IRepositories;

public interface IProjectRepository<TEntity> :
    IBaseRepository<Project>,
    IDisposable where TEntity : class
{
    ValueTask<ProjectResponse> CreateProjectAsync(CreateProjectDTO request);
    ValueTask<ProjectResponse> UpdateProjectAsync(Guid projectId, UpdateProjectDTO request);
    ValueTask<ProjectResponse> DeleteProjectAsync(Guid projectId, string? modifiedBy);
    ValueTask<GetAllProjectsResponse> GetAllProjectsAsync(ProjectFilters filters);
    ValueTask<ProjectResponse> GetProjectByIdAsync(Guid projectId);
    ValueTask<GetProjectTypeResponse> CreateProjectTypeAsync(CreateProjectTypeRequest request);
    ValueTask<GetProjectTypeResponse> UpdateProjectTypeAsync(UpdateProjectTypeRequest request);
    ValueTask<GetNewProjectCodeResponse> GetNewCodeAsync();
    ValueTask<AssignProjectResponse> AssignProjectAsync(string userId, AssignProjectRequest request);
    ValueTask<GetAllProjectTypesResponse> GetAllProjectTypesAsync();
    ValueTask<ProjectResponse> AddCustomerToProjectAsync(Guid projectId, Guid customerId, string? modifiedBy);
    ValueTask<GetProjectsListResponse> GetProjectsListResponseAsync(ProjectStatus? status);
    ValueTask<List<Guid>> GetAllowedProjectIdsAndValidateUserAsync();
}
