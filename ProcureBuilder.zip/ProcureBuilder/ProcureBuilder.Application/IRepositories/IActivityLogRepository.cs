﻿using ProcureBuilder.ActivityLogs.Entities;
using ProcureBuilder.Repositories;

namespace ProcureBuilder.IRepositories;

public interface IActivityLogRepository<TEntity> :
    IBaseRepository<ActivityLog>,
    IDisposable where TEntity : class
{
    ValueTask AddEntityLogAsync(string entityName, string entityTypeName,
        string logType, string? createdby, Guid entityId, bool saveLog = true);

    ActivityLog MapActivityLog(string entityName,
        string entityTypeName,
        string logType,
        string? createdby,
        Guid entityId);
}
