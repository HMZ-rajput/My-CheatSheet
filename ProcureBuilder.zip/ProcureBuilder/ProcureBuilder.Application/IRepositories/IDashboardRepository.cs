﻿using ProcureBuilder.Common.DTOs;
using ProcureBuilder.DashBoards.DTOs;
using ProcureBuilder.Materials.DTOs;
using ProcureBuilder.Projects.Entities;
using ProcureBuilder.Repositories;

namespace ProcureBuilder.IRepositories;

public interface IDashboardRepository<TEntity> :
    IBaseRepository<Project>,
    IDisposable where TEntity : class
{
    ValueTask<ProjectDashboardResponse> GetDashboardByProjectIdAsync(Guid projectId, string? userId, NotificationFilters filters);
    ValueTask<AllProjectDashboardResponse> GetDashboardAsync(string? userId, NotificationFilters filters);
    ValueTask<StatusUpdateResponse> UpdateStatus(Guid entityId, UpdateStatusDTO request);
    ValueTask<SideNotificationResponse> GetSideNotification(string? userId, SideNotificationFilters filters);
    ValueTask<CommonResponse> DeleteNotificationByIdAsync(string? userId, string? modifiedBy, Guid notificationId);
    GetMaterialCostAnalyticsResponse GetMaterialCostAnalysis(Guid projectId, MaterialCostAnalysisFilters filters);
}

