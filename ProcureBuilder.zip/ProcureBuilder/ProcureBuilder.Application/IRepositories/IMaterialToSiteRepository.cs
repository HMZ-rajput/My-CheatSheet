﻿using ProcureBuilder.MaterialToSites.DTOs;
using ProcureBuilder.MaterialToSites.Entities;
using ProcureBuilder.Repositories;

namespace ProcureBuilder.IRepositories;

public interface IMaterialToSiteRepository<TEntity> :
IBaseRepository<MaterialToSite>,
IDisposable where TEntity : class
{
    ValueTask<MaterialToSiteResponse> CreateMaterialToSiteAsync(CreateMaterialToSiteDTO request);
    ValueTask<AllMaterialToSiteResponse> GetAllMaterialToSiteAsync(MaterialToSiteFilters filters);
    ValueTask<MaterialToSiteResponse> DeleteMaterialToSiteAsync(Guid materialToSiteId, string? modifiedBy);
    ValueTask<MaterialToSiteResponse> UpdateMaterialToSiteAsync(Guid materialToSiteId, CreateMaterialToSiteDTO request);
    ValueTask<MaterialToSiteResponse> GetMaterialToSiteByIdAsync(Guid materialToSiteId);
}
