﻿using ProcureBuilder.Invoices.DTOs;
using ProcureBuilder.Invoices.Entities;
using ProcureBuilder.Repositories;

namespace ProcureBuilder.IRepositories;

public interface IInvoiceRepository<TEntity> :
    IBaseRepository<Invoice>,
    IDisposable where TEntity : class
{
    ValueTask<InvoiceResponse> CreateInvoiceAsync(CreateInvoiceDTO request);
    ValueTask<GetAllInvoiceResponse> GetAllInvoiceAsync(InvoiceFilters filters);
    ValueTask<InvoiceResponse> GetInvoiceByIdAsync(Guid invoiceId);
    ValueTask<InvoiceResponse> DeleteInvoiceAsync(Guid invoiceId, string? ModifiedBy);
    ValueTask<InvoiceResponse> UpdateInvoiceAsync(Guid invoiceId, CreateInvoiceDTO request);
    ValueTask<PurchaseOrderMaterialResponse> GetMaterialsFromPurchaseOrder(Guid purchaseOrderId);
    ValueTask<GetNewInvoiceNumberResponse> GetNewInvoiceNumberAsync();
    ValueTask<GetAllInvoiceNumberListResponse> GetInvoiceNumberListAsync();
    ValueTask<GetAllInvoiceProjectReportResponse> GetAllInvoiceProjectReportAsync(InvoiceReportFilters filters);
    ValueTask<GetAllInvoiceProjectCostCodeReportResponse> GetAllInvoiceProjectCostCodeReportAsync(InvoiceReportFilters filters);
    ValueTask<GetAllInvoicePurchaseOrderReportResponse> GetAllInvoicePurchaseOrderReportAsync(InvoiceReportFilters filters);
    ValueTask<GetAllPurchaseOrderInvoicesResponse> GetAllPurchaseOrderInvoicesReportAsync(Guid purchaseOrderId, PurchaseOrderInvoiceReportFilters filters);
}
