﻿using ProcureBuilder.Materials.Entities;
using ProcureBuilder.Products.DTOs;
using ProcureBuilder.Repositories;

namespace ProcureBuilder.IRepositories;

public interface IProductRepository<TEntity> :
IBaseRepository<Material>,
IDisposable where TEntity : class
{
    ValueTask<GetAllProductsResponse> GetAllProductsAsync(ProductsFilter filters);
    ValueTask<GetProductResponse> GetProductByNameAsync(string productName, GetProductFilter filters);
}
