﻿using ProcureBuilder.ChangeOrders.DTOs;
using ProcureBuilder.ChangeOrders.Entities;
using ProcureBuilder.Projects.DTOs;
using ProcureBuilder.Repositories;

namespace ProcureBuilder.IRepositories;

public interface IChangeOrderRepository<TEntity> :
    IBaseRepository<ChangeOrder>,
    IDisposable where TEntity : class
{
    ValueTask<ChangeOrderResponse> CreateChangeOrderAsync(Guid projectId, CreateChangeOrderDTO request);
    ValueTask<ChangeOrderResponse> UpdateChangeOrderAsync(Guid projectId, Guid changeOrderId, UpdateChangeOrderDTO request);
    ValueTask<ChangeOrderResponse> DeleteChangeOrderAsync(Guid projectId, Guid changeOrderId, string? modifiedBy);
    ValueTask<GetAllChangeOrdersResponse> GetAllChangeOrdersAsync(ChangeOrderFilters filters);
    ValueTask<GetAllChangeOrdersResponse> GetChangeOrdersByProjectIdAsync(Guid projectId, bool approvedOnly);
    ValueTask<ChangeOrderResponse> GetChangeOrderByIdAsync(Guid changeOrderId);
    ValueTask<ChangeOrderResponse> DeleteChangeOrderMaterialsByIdAsync(Guid projectId,Guid changeOrderId ,DeleteChangeOrderMaterialsRequest request);
    ValueTask<ChangeOrderResponse> DeleteChangeOrderAttachmentsByIdAsync(Guid projectId, Guid changeOrderId, DeleteChangeOrderAttachmentsRequest request);
    ValueTask<GetNewChangeOrderNumberResponse> GetNewChangeOrderNumberAsync();
}