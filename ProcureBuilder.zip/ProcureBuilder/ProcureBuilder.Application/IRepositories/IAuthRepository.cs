﻿using ProcureBuilder.Common.DTOs;
using ProcureBuilder.Identity.DTOs;

namespace ProcureBuilder.IRepositories;

public interface IAuthRepository
{
    ValueTask<AuthResponse> LoginAsync(LoginRequest request);

    ValueTask<AuthResponse> SignUpAsync(SignUpRequest request);

    ValueTask ConfirmEmailAsync(string userId);

    ValueTask<ChangePasswordResponse> ChangePasswordAsync(ChangePasswordRequest request);

    ValueTask<SendForgotPasswordEmailResponse> SendForgotPasswordEmailAsync(SendForgotPasswordEmailRequest request);

    ValueTask<ResetPasswordResponse> ResetPasswordAsync(ResetPasswordRequest request);

    ValueTask<GetAllManagersResponse> GetAllManagersAsync();

    ValueTask<VerifyPasswordOTPResponse> VerifyPasswordOTPAsync(VerifyPasswordOTPRequest request);

    ValueTask<AuthResponse> UpdatePersonalInfoAsync(string id, UpdatePersonalInfoRequest request);

    ValueTask<GetAllUsersResponse> GetAllUsersAsync(Userfilters filter);

    ValueTask<GetUserByIdResponse> GetUserByIdAsync(Guid userId);

    ValueTask<GetAllUsersWithRolesResponse> GetUsersWithRolesAsync(GetUsersWithRolesRequest request);

    ValueTask<AuthResponse> UpdateInternalUserAsync(UpdateInternalUserRequest request);

    ValueTask<GetUserByIdResponse> DeleteInternalUserAsync(string userId, string? modifiedBy);

    ValueTask<CommonResponse> ResendInviteAsync(string userId);
}