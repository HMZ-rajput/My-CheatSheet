﻿
using ProcureBuilder.Customers.Entities;
using ProcureBuilder.Projects.Entities;

namespace ProcureBuilder.IRepositories;
public interface IUnitOfWork : IDisposable
{
    IGenericRepository<Project> Project { get; }
    IGenericRepository<Customer> Customer { get; }
    ValueTask Save();
}
