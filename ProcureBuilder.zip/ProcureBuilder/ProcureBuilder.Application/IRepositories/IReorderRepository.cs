﻿using ProcureBuilder.Reorders.DTOs;
using ProcureBuilder.Reorders.Entities;
using ProcureBuilder.Repositories;

namespace ProcureBuilder.IRepositories;

public interface IReorderRepository<TEntity> :
    IBaseRepository<Reorder>,
    IDisposable where TEntity : class
{
    ValueTask<ReorderResponse> CreateReorderAsync(Guid projectId, CreateReorderRequest request);
    ValueTask<GetAllReorderResponse> GetAllReorderAsync(ReorderFilters filters);
    ValueTask<ReorderResponse> GetReorderByIdAsync(Guid reorderId);
    ValueTask<ReorderResponse> UpdateReorderRecipentAsync(Guid reorderId, UpdateReorderRecipientRequest request);
    ValueTask<ReorderResponse> DeleteReorderAsync(Guid reorderId, string? ModifiedBy);
    ValueTask<ReorderResponse> UpdateReorderAsync(Guid reorderId, Guid projectId, UpdateReorderRequest request);
    ValueTask<GetNewReorderNumberResponse> GetNewReorderNumberAsync();
}
