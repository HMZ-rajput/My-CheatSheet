﻿using ProcureBuilder.MaterialInventory.DTOs;
using ProcureBuilder.Materials.DTOs;
using ProcureBuilder.Materials.Entities;
using ProcureBuilder.Repositories;

namespace ProcureBuilder.IRepositories;
public interface IMaterialInventoryRepository<TEntity> :
IBaseRepository<Material>,
IDisposable where TEntity : class
{
    ValueTask<MaterialInventoryResponse> CreateMaterialInventoryAsync(Guid projectId, AddInventoryRequest request);
    ValueTask<GetMaterialInventoryResponse> GetMaterialInventoryAsync(Guid projectId, MaterialInventoryFilters filters);
    ValueTask<MaterialInventoryResponse> GetAllInventoryMaterialsAsync(Guid projectId, GetAllInventoryMaterialsFilter filters);
    ValueTask<MaterialInventoryResponse> UpdateMaterialInventoryAsync(Guid projectId, AddInventoryRequest request);
    ValueTask<MaterialInventoryResponse> DeleteMaterialInventoryAsync(Guid projectId, string? ModifiedBy);
}

