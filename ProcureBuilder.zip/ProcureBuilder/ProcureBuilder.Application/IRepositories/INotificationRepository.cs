﻿using Microsoft.AspNetCore.Identity;
using ProcureBuilder.DashBoards.Entities;
using ProcureBuilder.Materials.Entities;
using ProcureBuilder.Repositories;

namespace ProcureBuilder.IRepositories;

public interface INotificationRepository<TEntity> :
    IBaseRepository<Notification>,
    IDisposable where TEntity : class
{
    ValueTask AddEntityNotificationAsync(
        DashBoards.Entities.EntityType EntityType,
        Actions? Action,
        NotificationCategory Category,
        string Title, string Description,
        Guid ProjectId,
        Guid? EntityId,
        IList<Material> Materials);

    ValueTask AddEntityNotificationAsync(
        DashBoards.Entities.EntityType EntityType,
        Actions? Action,
        NotificationCategory Category,
        string Title, string Description,
        Guid ProjectId,
        Guid? EntityId,
        IList<Material> Materials,
        DateTimeOffset CreatedDate);

    string MapRoleIdToRoleName(IdentityUserRole<string>? role);

    ValueTask<bool> DeleteNotificationsForEntityAsync(DashBoards.Entities.EntityType entityType, Guid entityId);
}
