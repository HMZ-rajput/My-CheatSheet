﻿using Microsoft.EntityFrameworkCore.Query;
using System.Linq.Expressions;

namespace ProcureBuilder.IRepositories;
public interface IGenericRepository<T> where T : class
{
    ValueTask<IList<T>> GetAllAsync(
            Expression<Func<T, bool>>? expression = null,
            Func<IQueryable<T>, IOrderedQueryable<T>>? orderBy = null,
            Func<IQueryable<T>, IIncludableQueryable<T, object?>>? include = null
        );
    ValueTask<T?> GetAsync(Expression<Func<T, bool>> expression, Func<IQueryable<T>, IIncludableQueryable<T, object?>>? include = null);
    ValueTask AddAsync(T entity);
    ValueTask InsertRangeAsync(IEnumerable<T> entities);
    ValueTask Delete(int id);
    void DeleteRange(IEnumerable<T> entities);
    void Update(T entity);
}