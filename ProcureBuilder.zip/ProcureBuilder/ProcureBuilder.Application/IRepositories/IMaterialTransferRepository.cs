﻿using ProcureBuilder.MaterialTransfers.DTOs;
using ProcureBuilder.MaterialTransfers.Entities;
using ProcureBuilder.Repositories;

namespace ProcureBuilder.IRepositories;

public interface IMaterialTransferRepository<TEntity> :
IBaseRepository<MaterialTransfer>,
IDisposable where TEntity : class
{
    ValueTask<MaterialTransferResponse> CreateMaterialTransferAsync(CreateMaterialTransferDTO request);
    ValueTask<AllMaterialTransfersResponse> GetAllMaterialTransferAsync(MaterialTransferFilters filters);
    ValueTask<MaterialTransferResponse> DeleteMaterialTransferAsync(Guid materialTransferId, string? modifiedBy);
    ValueTask<MaterialTransferResponse> UpdateMaterialTransferAsync(Guid materialTransferId, CreateMaterialTransferDTO request);
    ValueTask<MaterialTransferResponse> GetMaterialTransferByIdAsync(Guid materialTransferId);
    ValueTask<GetMaterialInventoryListResponse> GetMaterialInventoryListAsync(Guid projectLocationId, GetMaterialInventoryListRequest request);
}
