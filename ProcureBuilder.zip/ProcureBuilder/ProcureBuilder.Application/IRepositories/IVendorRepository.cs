﻿using ProcureBuilder.Repositories;
using ProcureBuilder.Vendors.DTOs;
using ProcureBuilder.Vendors.Entities;

namespace ProcureBuilder.IRepositories;

public interface IVendorRepository<TEntity> :
IBaseRepository<Vendor>,
IDisposable where TEntity : class
{
    ValueTask<VendorResponse> CreateVendorAsync(CreateVendorDTO request);
    ValueTask<DivisionResponse> CreateDivisionAsync(CreateDivisionRequest request);
    ValueTask<DivisionResponse> UpdateDivisionAsync(UpdateDivisionRequest request);
    ValueTask<GetAllVendorsResponse> GetAllVendorsAsync(VendorFilters filters);
    ValueTask<VendorResponse> GetVendorByIdAsync(Guid id);
    ValueTask<GetAllDivisionResponse> GetAllDivisionAsync();
    ValueTask<VendorListResponse> GetVendorListAsync();
    ValueTask<VendorResponse> UpdateVendorAsync(Guid vendorId, UpdateVendorDTO request);
    ValueTask<VendorResponse> DeleteVendorAsync(Guid vendorId, string? modifiedBy);
}
