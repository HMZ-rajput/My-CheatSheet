﻿using ProcureBuilder.QualityQuestions.DTOs;
using ProcureBuilder.QualityQuestions.Entities;
using ProcureBuilder.Repositories;

namespace ProcureBuilder.IRepositories;
public interface IQualityAnswerRepository<TEntity> :
IBaseRepository<QualityAnswer>,
IDisposable where TEntity : class
{
    ValueTask<QualityAnswersResponse> CreateQualityAnswersAsync(CreateQualityAnswersDTO request);
    ValueTask<QualityAnswersResponse> GetQualityAnswersAsync(Guid materialReceiptInspectionId);
    ValueTask<DeleteQualityAnswersResponse> DeleteQualityAnswersAsync(Guid materialReceiptInspectionId, string? ModifiedBy);
    ValueTask<QualityAnswersResponse> UpdateQualityAnswersAsync(UpdateQualityAnswerRequestDTO request);
}
