﻿using ProcureBuilder.Locations.DTOs;
using ProcureBuilder.Locations.Entities;
using ProcureBuilder.Repositories;

namespace ProcureBuilder.IRepositories;

public interface IProjectLocationRepository<TEntity> :
    IBaseRepository<ProjectLocation>,
    IDisposable where TEntity : class
{
    ValueTask<ProjectLocationResponse> CreateLocationAsync(Guid projectId, CreateLocationRequest request);
    ValueTask<GetProjectLocationResponse> CreateSingleLocationAsync(Guid projectId, CreateProjectLocationDTO request);
    ValueTask<ProjectLocationResponse> UpdateLocationAsync(Guid projectId, UpdateProjectLocationRequest request);
    ValueTask<ProjectLocationResponse> DeleteLocationAsync(Guid projectId, IList<Guid> locationIds, string? modifiedBy);
    ValueTask<GetAllProjectLocationsResponse> GetAllLocationsAsync(ProjectLocationFilters filters);
    ValueTask<ProjectLocationResponse> GetLocationByIdAsync(Guid projectId);
    ValueTask<GetLocationsListResponse> GetLocationsListResponseAsync(Guid? projectId);
}