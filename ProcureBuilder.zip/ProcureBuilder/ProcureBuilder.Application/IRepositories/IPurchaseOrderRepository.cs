﻿using ProcureBuilder.Common.DTOs;
using ProcureBuilder.Documents.Entities;
using ProcureBuilder.MaterialReceiptInspections.Entities;
using ProcureBuilder.PurchaseOrders.DTOs;
using ProcureBuilder.PurchaseOrders.Entities;
using ProcureBuilder.Repositories;

namespace ProcureBuilder.IRepositories;

public interface IPurchaseOrderRepository<TEntity> :
IBaseRepository<PurchaseOrder>,
IDisposable where TEntity : class
{
    ValueTask<PurchaseOrderResponse> CreatePurchaseOrderAsync(CreatePurchaseOrderDTO request);
    ValueTask<GetAllPurchaseOrdersResponse> GetAllPurchaseOrdersAsync(PurchaseOrderFilters filters);
    ValueTask<PurchaseOrderResponse> GetPurchaseOrderByIdAsync(Guid purchaseOrderId);
    ValueTask<GetVendorDetailsResponse> GetVendorDetailsAsync(Guid purchaseOrderId);
    ValueTask<GetVendorPurchaseOrderResponse> GetPurchaseOrderVendorByIdAsync(Guid purchaseOrderId);
    ValueTask<PurchaseOrderResponse> UpdatePurchaseOrderAsync(Guid purchaseOrderId, UpdatePurchaseOrderDTO request);
    ValueTask<PurchaseOrderProcurmentResponse> UpdatePurchaseOrderProcurementAsync(Guid purchaseOrderId, PurchaseOrderProcurmentUpdateDTO request);
    ValueTask<PurchaseOrderVendorResponse> UpdatePurchaseOrderVendorAsync(Guid purchaseOrderId, PurchaseOrderVendorUpdateDTO request);
    ValueTask<PurchaseOrderResponse> DeletePurchaseOrderByIdAsync(Guid purchaseOrderId, string? modifiedBy);
    ValueTask<PurchaseOrderListResponse> GetPurchaseOrderListAsync(Guid? projectId, bool isForMRI, MaterialReceiptInspectionStatus mRIStatus);
    ValueTask<PurchaseOrderMaterialListResponse> GetPurchaseOrderMaterialListAsync(Guid purchaseOrderId);
    ValueTask<GetNewPurchaseNumberResponse> GetNewPurchaseOrderNumberAsync();
    ValueTask<GeneratePDFDocumentResponse> GeneratePOScanDocumentAsync(Guid purchaseOrderId);
    ValueTask<GeneratePDFDocumentResponse> GeneratePOMaterialScanDocumentAsync(Guid purchaseOrderId, Guid materialId);
    ValueTask<GeneratePDFDocumentResponse> GeneratePODocumentAsync(Guid purchaseOrderId, PDFType pdfType);
}
