﻿using ProcureBuilder.CompanySettings.DTOs;
using ProcureBuilder.CompanySettings.Entities;
using ProcureBuilder.Repositories;

namespace ProcureBuilder.IRepositories;

public interface ICompanyRepository<TEntity> :
    IBaseRepository<Company>,
    IDisposable where TEntity : class
{
    ValueTask<GetCompanyInfoResponse> GetCompanyInfoAsync();
    ValueTask<GetCompanyInfoResponse> UpdateCompanyInfoAsync(UpdateCompanyInfoRequest request);
    ValueTask<GetReorderSettingsResponse> UpdateReorderSettingsAsync(UpdateReorderSettings request);
    ValueTask<GetPurchaseOrderSettingsResponse> UpdatePurchaseOrderSettingsAsync(UpdatePurchaseOrderSettingsDTO request);
    ValueTask<GetPurchaseOrderSettingsResponse> GetPurchaseOrderSettingsAsync();
    ValueTask<GetReorderSettingsResponse> GetReorderSettingsAsync();
    ValueTask<GetCompanyLogoResponse> UpdateCompanyLogoAsync(UpdateCompanyLogoDTO request);
    ValueTask<GetCompanyLogoResponse> GetCompanyLogoAsync();
}
