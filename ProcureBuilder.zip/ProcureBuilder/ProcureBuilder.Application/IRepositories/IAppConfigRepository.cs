﻿using ProcureBuilder.AppConfigs.DTOs;
using ProcureBuilder.AppConfigs.Entities;
using ProcureBuilder.Repositories;

namespace ProcureBuilder.IRepositories;

public interface IAppConfigRepository<TEntity> :
    IBaseRepository<AppConfig>,
    IDisposable where TEntity : class
{
    ValueTask<GetAppVersionResponse> GetAppVersionAsync();
}
