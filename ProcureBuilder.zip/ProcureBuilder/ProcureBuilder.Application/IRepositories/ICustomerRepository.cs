﻿using ProcureBuilder.Customers.DTOs;
using ProcureBuilder.Customers.Entities;
using ProcureBuilder.Projects.DTOs;
using ProcureBuilder.Repositories;

namespace ProcureBuilder.IRepositories;

public interface ICustomerRepository<TEntity> :
    IBaseRepository<Customer>,
    IDisposable where TEntity : class
{
    ValueTask<CustomerResponse> CreateCustomerAsync(CreateCustomerDTO request);
    ValueTask<CustomerResponse> UpdateCustomerAsync(Guid customerId, UpdateCustomerDTO request);
    ValueTask<CustomerResponse> DeleteCustomerAsync(Guid customerId, string? modifiedBy);
    ValueTask<GetAllCustomersResponse> GetAllCustomersAsync(CustomerFilters filters);
    ValueTask<CustomerResponse> GetCustomerByIdAsync(Guid customerId);
    ValueTask<CustomerResponse> RemoveCustomerFromProjectAsync(Guid projectId, Guid customerId, string? modifiedBy);
}