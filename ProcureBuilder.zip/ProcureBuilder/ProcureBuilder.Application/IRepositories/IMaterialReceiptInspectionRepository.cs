﻿using ProcureBuilder.Common.DTOs;
using ProcureBuilder.MaterialReceiptInspections.DTOs;
using ProcureBuilder.MaterialReceiptInspections.Entities;
using ProcureBuilder.Repositories;

namespace ProcureBuilder.IRepositories;

public interface IMaterialReceiptInspectionRepository<TEntity> :
IBaseRepository<MaterialReceiptInspection>,
IDisposable where TEntity : class
{
    ValueTask<MaterialReceiptInspectionResponse> CreateMaterialReceiptInspectionAsync(CreateInspectionDTO request);
    ValueTask<MaterialReceiptInspectionResponse> GetMaterialReceiptInspectionByIdAsync(Guid materialReceiptInspectionId);
    ValueTask<AllMaterialReceiptInspectionResponse> GetAllMaterialReceiptInspectionAsync(MaterialReceiptInspectionFilters filters);
    ValueTask<MaterialReceiptInspectionResponse> UpdateMaterialReceiptInspectionAsync(Guid materialReceiptInspectionId, UpdateInspectionDTO request);
    ValueTask<MaterialImagesResponse> UpdateMaterialReceiptInspectionMaterialImagesAsync(Guid materialReceiptInspectionId, UpdateImagesDTO request);
    ValueTask<MaterialReceiptInspectionResponse> DeleteMaterialReceiptInspectionAsync(Guid materialReceiptInspectionId, string? modifiedBy);
    ValueTask<DeleteMaterialImageResponse> DeleteMaterialReceiptInspectionMaterialImagesAsync(Guid materialReceiptInspectionId, string? ModifiedBy);
    ValueTask<GetPurchaseOrderMaterialResponse> GetPurchaseOrderMaterialsAsync(Guid purchaseOrderId);
    ValueTask<GeneratePDFDocumentResponse> GenerateMaterialReceiptInspectionAsync(MaterialReceiptInspectionPDFFilters filters);
}
