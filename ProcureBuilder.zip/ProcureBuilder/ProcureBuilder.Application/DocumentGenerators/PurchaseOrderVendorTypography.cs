﻿using QuestPDF.Fluent;
using QuestPDF.Helpers;
using QuestPDF.Infrastructure;

namespace ProcureBuilder.DocumentGenerators;

public static class PurchaseOrderVendorTypography
{
    private const int _fontSize1 = 14;
    private const int _fontSize2 = 25;
    private const int _fontSize3 = 44;

    public static TextStyle Title => TextStyle
    .Default
    .FontColor(Colors.Black)
    .FontSize(_fontSize3)
    .ExtraBlack();

    public static TextStyle Heading => TextStyle
        .Default
        .FontColor(Colors.Black)
        .FontSize(_fontSize2)
        .ExtraBlack();

    public static TextStyle Label => TextStyle
    .Default
    .FontColor(Colors.Black)
    .FontSize(_fontSize1)
    .ExtraBlack();

    public static TextStyle LabelValue => TextStyle
    .Default
    .FontColor(Colors.Grey.Darken1)
    .FontSize(_fontSize1)
    .SemiBold();

    public static TextStyle TableHeaderStyle => TextStyle
    .Default
    .FontColor(Colors.Grey.Darken4)
    .FontSize(14)
    .ExtraBlack();

    public static TextStyle TableSubHeaderStyle => TextStyle
    .Default
    .FontColor(Colors.Grey.Darken4)
    .FontSize(12)
    .ExtraBlack();

    public static TextStyle TableDataStyle => TextStyle
    .Default
    .FontColor(Colors.Grey.Darken1)
    .FontSize(14)
    .SemiBold();
}
