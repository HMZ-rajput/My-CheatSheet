﻿using QuestPDF.Fluent;
using QuestPDF.Helpers;
using QuestPDF.Infrastructure;

namespace ProcureBuilder.DocumentGenerators;

public static class MRITypography
{
    private const int _fontSizeSmall = 8;
    private const int _fontSizeMedium = 12;
    private const int _fontSizeLarge = 30;
    private const int _fontSizeExtraLarge = 44;
    private const string _procureOrange = "#F56D36";

    public static TextStyle Title => TextStyle
    .Default
    .FontColor(_procureOrange)
    .FontSize(_fontSizeLarge)
    .ExtraBlack();

    public static TextStyle Heading => TextStyle
        .Default
        .FontColor(_procureOrange)
        .FontSize(_fontSizeMedium)
        .ExtraBlack();

    public static TextStyle HeadingLarge => TextStyle
        .Default
        .FontColor(Colors.Black)
        .FontSize(_fontSizeExtraLarge)
        .ExtraBlack();

    public static TextStyle Label => TextStyle
    .Default
    .FontColor(Colors.Black)
    .FontSize(_fontSizeSmall)
    .ExtraBlack();

    public static TextStyle LabelValue => TextStyle
    .Default
    .FontColor(Colors.Grey.Darken1)
    .FontSize(_fontSizeSmall)
    .SemiBold();

    public static TextStyle GeneralLabel => TextStyle
    .Default
    .FontColor(Colors.Black)
    .FontSize(_fontSizeMedium)
    .ExtraBlack();

    public static TextStyle GeneralLabelValue => TextStyle
    .Default
    .FontColor(Colors.Grey.Darken1)
    .FontSize(_fontSizeMedium)
    .SemiBold();

    public static TextStyle TableHeaderStyle => TextStyle
    .Default
    .FontColor(Colors.Grey.Darken4)
    .FontSize(_fontSizeSmall)
    .ExtraBlack();

    public static TextStyle TableDataStyle => TextStyle
    .Default
    .FontColor(Colors.Grey.Darken1)
    .FontSize(_fontSizeSmall)
    .SemiBold();
}
