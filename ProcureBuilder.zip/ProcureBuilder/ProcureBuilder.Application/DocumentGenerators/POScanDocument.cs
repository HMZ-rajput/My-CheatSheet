﻿using ProcureBuilder.PurchaseOrders.Entities;
using QuestPDF.Fluent;
using QuestPDF.Helpers;
using QuestPDF.Infrastructure;
using ZXing;
using ZXing.QrCode;
using ZXing.Rendering;

namespace ProcureBuilder.DocumentGenerators;

public class POScanDocument : IDocument
{
    private readonly PurchaseOrder _purchaseOrder;

    public POScanDocument(PurchaseOrder purchaseOrder)
    {
        _purchaseOrder = purchaseOrder ?? throw new ArgumentNullException(nameof(purchaseOrder));
    }

    void IDocument.Compose(IDocumentContainer container)
    {
        container
            .Page(page =>
            {
                page.Margin(20);
                page.Content().Element(ComposeContent);
            });
    }

    void ComposeContent(IContainer container)
    {
        var fontSizeSm = 14;
        var fontSizeLg = 36;
        var primaryColor = Colors.DeepOrange.Accent2;

        var materials = _purchaseOrder.Materials;
        var total = materials.Count;

        container.Column(column =>
        {
            for (int i = 0; i < total; i++)
            {
                var material = _purchaseOrder.Materials.ElementAt(i);

                // Header block
                column.Item().Inlined(inlined =>
                {
                    inlined.AlignJustify();
                    inlined.Item().Column(col =>
                    {
                        col.Item().Text(text =>
                        {
                            text.Span("PO Title: ").FontColor(primaryColor).FontSize(fontSizeSm).Black();
                            text.Span(_purchaseOrder.Title).FontSize(fontSizeSm);
                        });
                        col.Item().Text(text =>
                        {
                            text.Span("PO Number: ").FontColor(primaryColor).FontSize(fontSizeSm).Black();
                            text.Span(_purchaseOrder.PurchaseOrderNumber).FontSize(fontSizeSm);
                        });
                    });

                    inlined.Item().Column(col =>
                    {
                        col.Item().Inlined(right =>
                        {
                            right.AlignRight();
                            right.Item().Text(text =>
                            {
                                text.Span("Vendor: ").FontColor(primaryColor).FontSize(fontSizeSm).Black();
                                text.Span(_purchaseOrder.Vendor?.Name ?? "-").FontSize(fontSizeSm);
                            });
                        });
                        col.Item().Inlined(right =>
                        {
                            right.AlignRight();
                            right.Item().Text(text =>
                            {
                                text.Span("Delivery Location: ").FontColor(primaryColor).FontSize(fontSizeSm).Black();
                                text.Span(_purchaseOrder.DeliveryLocation.Name).FontSize(fontSizeSm);
                            });
                        });
                    });
                });

                // Main content block
                column.Item().Column(col =>
                {
                    col.Item().PaddingTop(80);
                    col.Item().Text(material.Name)
                       .FontColor(primaryColor).FontSize(fontSizeLg).AlignCenter().Bold();
                    col.Item().Text(material.CostCode)
                       .FontSize(fontSizeLg).AlignCenter().Bold();
                    col.Item().Svg(size =>
                    {
                        var content = material.Name.Trim();

                        var writer = new QRCodeWriter();
                        var qrCode = writer.encode(content, BarcodeFormat.QR_CODE, (int)size.Width, (int)size.Height);
                        var renderer = new SvgRenderer();
                        return renderer.Render(qrCode, BarcodeFormat.EAN_13, null).Content;
                    });
                });

                // Only break page if this isn’t the last item
                if (i < total - 1)
                {
                    column.Item().PageBreak();
                }
            }
        });
    }
}