﻿using ProcureBuilder.Common.Extensions;
using ProcureBuilder.Extensions;
using ProcureBuilder.Materials.Entities;
using ProcureBuilder.PurchaseOrders.Entities;
using QuestPDF.Fluent;
using QuestPDF.Helpers;
using QuestPDF.Infrastructure;

namespace ProcureBuilder.DocumentGenerators;

public class PODocument : IDocument
{
    private string _procureOrange = "#F56D36";
    private string? _logoPath;
    private string _companyName;

    private PurchaseOrder _purchaseOrder { get; }
    private CommonComponents _commonComponents = new CommonComponents();

    public PODocument(PurchaseOrder purchaseOrder, string? logoPath, string? companyName)
    {
        _purchaseOrder = purchaseOrder ?? throw new ArgumentNullException(nameof(purchaseOrder));
        _logoPath = logoPath;
        _companyName = companyName ?? "Procure Builder";
    }

    public void Compose(IDocumentContainer container)
    {
        container
            .Page(page =>
            {
                page.Margin(10);
                page.Content().Element(ComposeContent);
            });
    }

    void ComposeContent(IContainer container)
    {
        container.Column(column =>
        {
            column
            .Item()
            .PaddingTop(15)
            .PaddingBottom(10)
            .PaddingHorizontal(5)
            .Row(row =>
            {
                row.RelativeItem().Element(c => _commonComponents.ComposeLogo(c, _logoPath));
                row.RelativeItem().Element(c => _commonComponents.ComposeLogoName(c, _companyName));
                row.RelativeItem().AlignRight().PaddingHorizontal(20).Element(c => _commonComponents.ComposePOStatus(c, _purchaseOrder?.Status));
            });

            column
            .Item()
            .PaddingTop(50)
            .PaddingBottom(20)
            .Row(row =>
            {
                row.RelativeItem()
                    .PaddingHorizontal(5)
                    .Text("General Information")
                    .Underline()
                    .Style(PurchaseOrderTypography.Heading);

                row.RelativeItem()
                    .PaddingHorizontal(5)
                    .Text("Vendor Details")
                    .Underline()
                    .Style(PurchaseOrderTypography.Heading);
            });

            column
            .Item()
            .Row(row =>
            {
                row.RelativeItem()
                    .Border(1).BorderColor(Colors.Grey.Darken1)
                    .Padding(5)
                    .Element(ComposeHeading1Left);

                row.RelativeItem()
                    .Border(1).BorderColor(Colors.Grey.Darken1)
                    .Padding(5)
                    .Element(ComposeHeading1VendorDetails);
            });

            column.Item().PageBreak();

            //Heading 2
            column
            .Item()
            .PaddingTop(20)
            .PaddingRight(20)
            .Text("Material Details")
            .Underline()
            .Style(PurchaseOrderTypography.Heading);

            column.Item()
            .PaddingVertical(20)
            .Border(1)
            .BorderColor(Colors.Grey.Lighten1)
            .Column(subColumn =>
            {
                subColumn
                .Item()
                .Padding(5)
                .Element(ComposeHeading2);

                //Table
                subColumn
                .Item()
                .Padding(5)
                .Element(ComposeTable);

            });


            column.Item().PageBreak();

            //Heading 4
            column
            .Item()
            .PaddingVertical(20)
            .PaddingHorizontal(5)
            .Text("Additional Information")
            .Underline()
            .Style(PurchaseOrderTypography.Heading);

            column
            .Item()
            .Border(1)
            .Padding(5)
            .BorderColor(Colors.Grey.Darken1)
            .Element(ComposeHeading3);

            //Heading 4
            column
            .Item()
            .PaddingTop(40)
            .PaddingBottom(20)
            .PaddingHorizontal(5)
            .Text("Approval Details")
            .Underline()
            .Style(PurchaseOrderTypography.Heading);

            column
            .Item()
            .Element(ComposeHeading4);
        });
    }

    void ComposeTable(IContainer container)
    {
        container.Column(column =>
        {
            foreach (var material in _purchaseOrder.Materials)
            {
                column
                .Item()
                .Border(1)
                .BorderColor(Colors.Grey.Lighten1)
                .PreventPageBreak()
                .Element(c => ComposeRow(c, material));
            }

            column
            .Item()
            .PreventPageBreak()
            .PaddingTop(20)
            .PaddingLeft(450)
            .Element(ComposeTotal);
        });

    }

    void ComposeHeading1Left(IContainer container)
    {
        container.Padding(5).Column(column =>
        {
            column.Spacing(16);

            column
            .Item()
            .Text(text =>
            {
                text.Span("PO#: ").Style(PurchaseOrderVendorTypography.Label);
                text.Span(_purchaseOrder.PurchaseOrderNumber).Style(PurchaseOrderVendorTypography.LabelValue);
            });


            column
            .Item()
            .Text(text =>
            {
                text.Span("PO Title: ").Style(PurchaseOrderVendorTypography.Label);
                text.Span(_purchaseOrder.Title).Style(PurchaseOrderVendorTypography.LabelValue);
            });

            column
            .Item()
            .Text(text =>
            {
                text.Span("Project: ").Style(PurchaseOrderVendorTypography.Label);
                text.Span(_purchaseOrder.Project.Name).Style(PurchaseOrderVendorTypography.LabelValue);
            });

            column
            .Item()
            .Text(text =>
            {
                text.Span("Revision Number: ").Style(PurchaseOrderVendorTypography.Label);
                text.Span(string.IsNullOrEmpty(_purchaseOrder.RevisionNumber) ? "-" : _purchaseOrder.RevisionNumber).Style(PurchaseOrderVendorTypography.LabelValue);
            });

            column
            .Item()
            .Text(text =>
            {
                text.Span("Due Date: ").Style(PurchaseOrderVendorTypography.Label);
                text.Span(_purchaseOrder.DueDate.ToString("MM/dd/yyyy")).Style(PurchaseOrderVendorTypography.LabelValue);
            });

            column
            .Item()
            .Text(text =>
            {
                text.Span("Assigned To: ").Style(PurchaseOrderVendorTypography.Label);
                text.Span($"{_purchaseOrder.AssignedUser.FirstName} {_purchaseOrder.AssignedUser.LastName}").Style(PurchaseOrderVendorTypography.LabelValue);
            });
        });
    }

    void ComposeHeading1VendorDetails(IContainer container)
    {
        container.Padding(5).Column(column =>
        {
            column.Spacing(16);

            column
            .Item()
            .Text(text =>
            {
                text.Span("Name: ").Style(PurchaseOrderVendorTypography.Label);
                text.Span(_purchaseOrder.Vendor?.Name).Style(PurchaseOrderVendorTypography.LabelValue);
            });

            column
            .Item()
            .Text(text =>
            {
                text.Span("Address: ").Style(PurchaseOrderVendorTypography.Label);
                text.Span(_purchaseOrder.VendorAddress).Style(PurchaseOrderVendorTypography.LabelValue);
            });
        });
    }

    void ComposeHeading3(IContainer container)
    {
        container.Column(column =>
        {
            column.Spacing(16);

            column
            .Item()
            .Text(text =>
            {
                text.Span("Payment Term: ").Style(PurchaseOrderVendorTypography.Label);
                text.Span(StringExtensions.PaymentTermStatusToString(_purchaseOrder.PaymentTerm)).Style(PurchaseOrderVendorTypography.LabelValue);
            });

            column
                .Item()
                .Row(row =>
                {
                    row
                    .RelativeItem()
                    .Text(text =>
                    {
                        text.Span("Delivery Address: ").Style(PurchaseOrderVendorTypography.Label);
                        text.Span(_purchaseOrder.DeliveryLocation.Address).Style(PurchaseOrderVendorTypography.LabelValue);
                    });
                });

            column
                .Item()
                .Row(row =>
                {
                    row
                    .RelativeItem()
                    .Text(text =>
                    {
                        text.Span("Delivery Notes: ").Style(PurchaseOrderVendorTypography.Label);
                        text.Span(_purchaseOrder.DeliveryNotes).Style(PurchaseOrderVendorTypography.LabelValue);
                    });
                });

            foreach (var contact in _purchaseOrder.Contacts)
            {
                column
                .Item()
                .Row(row =>
                {
                    row
                    .RelativeItem()
                    .Text(text =>
                    {
                        text.Span("Delivery Contact: ").Style(PurchaseOrderVendorTypography.Label);
                        text.Span($"{contact.FirstName} {contact.LastName}").Style(PurchaseOrderVendorTypography.LabelValue);
                    });
                });

                column
                .Item()
                .Row(row =>
                {
                    row
                    .RelativeItem()
                    .Text(text =>
                    {
                        text.Span("Contact Phone: ").Style(PurchaseOrderVendorTypography.Label);
                        text.Span(contact.PhoneNumber).Style(PurchaseOrderVendorTypography.LabelValue);
                    });
                });
            }
        });

    }

    void ComposeHeading4(IContainer container)
    {
        var contractorApproval = _purchaseOrder.PurchaseOrderApprovals.FirstOrDefault(x => x.IsActive && x.AuthorizingEntity == AuthorizingEntity.Contractor);
        var vendorApproval = _purchaseOrder.PurchaseOrderApprovals.FirstOrDefault(x => x.IsActive && x.AuthorizingEntity == AuthorizingEntity.Vendor);

        container.Column(column =>
        {
            column
            .Item()
            .Row(row =>
            {
                row
                .RelativeItem()
                .Border(1)
                .Padding(5)
                .BorderColor(Colors.Grey.Darken1)
                .Column(column =>
                {
                    column.Spacing(16);

                    column.Item()
                    .AlignCenter()
                    .Text("Vendor")
                    .Underline()
                    .Style(PurchaseOrderTypography.Heading)
                    .FontSize(18);

                    column
                    .Item()
                    .Text(text =>
                    {
                        text.Span("Signature: ").Style(PurchaseOrderVendorTypography.Label);
                        text.Span(vendorApproval?.Signature).Style(PurchaseOrderVendorTypography.LabelValue);
                    });

                    column
                    .Item()
                    .Text(text =>
                    {
                        text.Span("Company: ").Style(PurchaseOrderVendorTypography.Label);
                        text.Span(vendorApproval?.Company).Style(PurchaseOrderVendorTypography.LabelValue);
                    });

                    column
                    .Item()
                    .Text(text =>
                    {
                        text.Span("Title: ").Style(PurchaseOrderVendorTypography.Label);
                        text.Span(vendorApproval?.Title).Style(PurchaseOrderVendorTypography.LabelValue);
                    });

                    column
                    .Item()
                    .Text(text =>
                    {
                        text.Span("Date: ").Style(PurchaseOrderVendorTypography.Label);
                        text.Span(vendorApproval?.DateSigned.HasValue ?? false ? vendorApproval?.DateSigned.Value.ToString("MM/dd/yyyy") : "-").Style(PurchaseOrderVendorTypography.LabelValue);
                    });

                    column
                    .Item()
                    .Text(text =>
                    {
                        text.Span("Vendor Comments: ").Style(PurchaseOrderVendorTypography.Label);
                        text.Span(vendorApproval?.ApprovalComments).Style(PurchaseOrderVendorTypography.LabelValue);
                    });
                });

                row
                .RelativeItem()
                .Border(1)
                .Padding(5)
                .BorderColor(Colors.Grey.Darken1)
                .Column(column =>
                {
                    column.Spacing(16);

                    column.Item()
                    .AlignCenter()
                    .Text("Contractor")
                    .Underline()
                    .Style(PurchaseOrderTypography.Heading)
                    .FontSize(18);

                    column
                        .Item()
                        .Text(text =>
                        {
                            text.Span("Signature: ").Style(PurchaseOrderVendorTypography.Label);
                            text.Span(contractorApproval?.Signature).Style(PurchaseOrderVendorTypography.LabelValue);
                        });


                    column
                        .Item()
                        .Text(text =>
                        {
                            text.Span("Company: ").Style(PurchaseOrderVendorTypography.Label);
                            text.Span(contractorApproval?.Company).Style(PurchaseOrderVendorTypography.LabelValue);
                        });

                    column
                        .Item()
                        .Text(text =>
                        {
                            text.Span("Title: ").Style(PurchaseOrderVendorTypography.Label);
                            text.Span(contractorApproval?.Title).Style(PurchaseOrderVendorTypography.LabelValue);
                        });

                    column
                       .Item()
                       .Text(text =>
                       {
                           text.Span("Date: ").Style(PurchaseOrderVendorTypography.Label);
                           text.Span(contractorApproval?.DateSigned.HasValue ?? false ? contractorApproval?.DateSigned.Value.ToString("MM/dd/yyyy") : "-").Style(PurchaseOrderVendorTypography.LabelValue);
                       });
                });
            });
        });
    }

    void ComposeHeading2(IContainer container)
    {
        string taxResponsibility = _purchaseOrder.IsContractorResponsibleForTax ? "Contractor is responsible for tax" : "Contractor is not responsible for tax";
        
        container.Column(column =>
        {
            column.Spacing(10);

            column.Item()
            .Text(taxResponsibility)
            .Style(PurchaseOrderTypography.Label);

            if (_purchaseOrder.IsContractorResponsibleForTax)
            {
                column.Item()
                .Text(text =>
                {
                    text.Span("Tax: ").Style(PurchaseOrderTypography.Label);
                    text.Span((_purchaseOrder.TaxPercentage.HasValue ? _purchaseOrder.TaxPercentage.Value.ToString("#,0.##") : "-") + "%").Style(PurchaseOrderTypography.LabelValue);
                });
            }
        });
    }

    void ComposeRow(IContainer container, Material material)
    {
        decimal amount = (decimal)material.Quantity * material.UnitRate;
        container.Table(table =>
        {
            table.ColumnsDefinition(columns =>
            {
                columns.RelativeColumn(1);
                columns.RelativeColumn(1);
                columns.RelativeColumn(1);
                columns.RelativeColumn(1);
                columns.RelativeColumn(1);
                columns.RelativeColumn(1);
                columns.RelativeColumn(1);
                columns.RelativeColumn(1);
            });

            //table head
            table
                .Cell()
                .ColumnSpan(2)
                .Element(CellHeadStyle)
                .Text("Material")
                .Style(PurchaseOrderTypography.TableHeaderStyle);

            table
                .Cell()
                .ColumnSpan(2)
                .Element(CellHeadStyle)
                .Text("Cost Code")
                .Style(PurchaseOrderTypography.TableHeaderStyle);

            table
                .Cell()
                .Element(CellHeadStyle)
                .Text("Quantity")
                .Style(PurchaseOrderTypography.TableHeaderStyle);

            table
                .Cell()
                .Element(CellHeadStyle)
                .Text("UoM")
                .Style(PurchaseOrderTypography.TableHeaderStyle);

            table
                .Cell()
                .Element(CellHeadStyle)
                .Text("Unit Rate")
                .Style(PurchaseOrderTypography.TableHeaderStyle);

            table
                .Cell()
                .Element(CellHeadStyle)
                .Text("Amount")
                .Style(PurchaseOrderTypography.TableHeaderStyle);

            //table body
            table
                .Cell()
                .ColumnSpan(2)
                .Element(CellDataStyle)
                .Text(material.Name)
                .Style(PurchaseOrderTypography.TableDataStyle);

            table
                .Cell()
                .ColumnSpan(2)
                .Element(CellDataStyle)
                .Text(material.CostCode)
                .Style(PurchaseOrderTypography.TableDataStyle);

            table
                .Cell()
                .Element(CellDataStyle)
                .Text(material.Quantity.ToString("#,0.##"))
                .Style(PurchaseOrderTypography.TableDataStyle);

            table
                .Cell()
                .Element(CellDataStyle)
                .Text(material.UnitOfMeasure)
                .Style(PurchaseOrderTypography.TableDataStyle);

            table
                .Cell()
                .Element(CellDataStyle)
                .Text($"${material.UnitRate.ToString("#,0.##")}")
                .Style(PurchaseOrderTypography.TableDataStyle);

            table
                .Cell()
                .Element(CellDataStyle)
                .Text($"${amount.ToString("#,0.##")}")
                .Style(PurchaseOrderTypography.TableDataStyle);

            if (material.IsMaterialAlreadyApproved)
            {
                table
                    .Cell()
                    .ColumnSpan(8)
                    .Element(container =>
                    {

                        container.PaddingHorizontal(5).PaddingBottom(5).Row(row =>
                        {
                            //if (!string.IsNullOrEmpty(_checkMarkPath))
                            //{
                            //    row
                            //    .ConstantItem(20)
                            //    .Svg(SvgImage.FromFile(_checkMarkPath));
                            //}

                            row
                            .ConstantItem(20)
                            .Svg("""
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 122.88 122.88">
                                    <title>confirm</title>
                                    <path d="M61.44,0A61.44,61.44,0,1,1,0,61.44,61.44,61.44,0,0,1,61.44,0Z"
                                          fill="#00a912" fill-rule="evenodd"/>
                                    <path d="M42.37,51.68,53.26,62,79,35.87c2.13-2.16,3.47-3.9,6.1-1.19l8.53,8.74
                                             c2.8,2.77,2.66,4.4,0,7L58.14,85.34c-5.58,5.46-4.61,5.79-10.26.19L28,65.77
                                             c-1.18-1.28-1.05-2.57.24-3.84l9.9-10.27c1.5-1.58,2.7-1.44,4.22,0Z"
                                          fill="#ffffff" fill-rule="evenodd"/>
                                </svg>
                            """);


                            row
                            .RelativeItem()
                            .PaddingLeft(5)
                            .PaddingTop(2)
                            .Text("Material is already approved")
                            .Style(PurchaseOrderTypography.TableHeaderStyle);

                        });
                    }
                    );

                return;
            }

            //table sub head

            table
                .Cell()
                .Element(CellSubHeadStyle)
                .Text("Max Submittal Lead Time")
                .Style(PurchaseOrderTypography.TableHeaderStyleSmall);

            table
                .Cell()
                .ColumnSpan(2)
                .Element(CellSubHeadStyle)
                .Text("Expected Submittal Date")
                .Style(PurchaseOrderTypography.TableHeaderStyleSmall);

            table
                .Cell()
                .ColumnSpan(2)
                .Element(CellSubHeadStyle)
                .Text("Expected Delivery Date")
                .Style(PurchaseOrderTypography.TableHeaderStyleSmall);

            table
                .Cell()
                .Element(CellSubHeadStyle)
                .Text("Max Material Lead Time")
                .Style(PurchaseOrderTypography.TableHeaderStyleSmall);

            table
                .Cell()
                .ColumnSpan(2)
                .Element(CellSubHeadStyle)
                .Text("Submittal Status")
                .Style(PurchaseOrderTypography.TableHeaderStyleSmall);

            table
                .Cell()
                .Element(CellDataStyle)
                .Text(material.MaxSubmittalLeadTime.HasValue ? material.MaxSubmittalLeadTime.Value.ToString("#,0.##") : string.Empty)
                .Style(PurchaseOrderTypography.TableDataStyleSmall);

            table
                .Cell()
                .ColumnSpan(2)
                .Element(CellDataStyle)
                .Text(material.ExpectedSubmittalDate.HasValue ? material.ExpectedSubmittalDate.Value.ToString("MM/dd/yyyy") : string.Empty)
                .Style(PurchaseOrderTypography.TableDataStyleSmall);

            table
                .Cell()
                .ColumnSpan(2)
                .Element(CellDataStyle)
                .Text(material.ExpectedDeliveryDate.HasValue ? material.ExpectedDeliveryDate.Value.ToString("MM/dd/yyyy") : string.Empty)
                .Style(PurchaseOrderTypography.TableDataStyleSmall);

            table
                .Cell()
                .Element(CellDataStyle)
                .Text(material.MaxMaterialLeadTime.HasValue ? material.MaxMaterialLeadTime.Value.ToString("#,0.##") : string.Empty)
                .Style(PurchaseOrderTypography.TableDataStyleSmall);

            table
                .Cell()
                .ColumnSpan(2)
                .Element(CellDataStyle)
                .Text(StringExtensions.SubmittalStatusToString(material.SubmittalStatus))
                .Style(PurchaseOrderTypography.TableDataStyleSmall);

        });
    }

    void ComposeTotal(IContainer container)
    {
        container.Column(column =>
        {
            column.Spacing(10);

            column
            .Item()
            .Text(text =>
            {
                text.Span("Sub Total:").Style(PurchaseOrderTypography.Label);
                text.Span($" ${_purchaseOrder.SubTotal.ToString("#,0.##")}").Style(PurchaseOrderTypography.LabelValue);
            });

            column
            .Item()
            .Text(text =>
            {
                text.Span("Tax:").Style(PurchaseOrderTypography.Label);
                text.Span($" ${_purchaseOrder.Tax.ToString("#,0.##")}").Style(PurchaseOrderTypography.LabelValue);
            });

            column
            .Item()
            .Text(text =>
            {
                text.Span("Total:").Style(PurchaseOrderTypography.Label);
                text.Span($" ${_purchaseOrder.Total.ToString("#,0.##")}").Style(PurchaseOrderTypography.LabelValue);
            });
        });
    }

    IContainer CellDataStyle(IContainer container)
    {
        return container
        .PaddingLeft(5)
        .PaddingVertical(10);
    }

    IContainer CellHeadStyle(IContainer container)
    {
        return container
        .Background(Color.FromHex("#cad5e2"))
        .PaddingLeft(5)
        .PaddingVertical(5)
        .AlignBottom();
    }

    IContainer CellSubHeadStyle(IContainer container)
    {
        return container
        .Background(Color.FromHex("#f1f5f9"))
        .PaddingLeft(5)
        .PaddingVertical(5)
        .AlignBottom();
    }
}
