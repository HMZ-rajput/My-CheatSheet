﻿using ProcureBuilder.Common.Extensions;
using ProcureBuilder.Extensions;
using ProcureBuilder.MaterialReceiptInspections.Entities;
using ProcureBuilder.PurchaseOrders.Entities;
using QuestPDF.Fluent;
using QuestPDF.Infrastructure;
using static QuestPDF.Helpers.Colors;

namespace ProcureBuilder.DocumentGenerators;

public class CommonComponents
{
    private string _procureOrange = "#F56D36";
    private string _lightGreen = "#E6FFEF";
    private string _darkGreen = "#137C48";
    private string _lightGrey = "#CCCCCD";
    private string _darkGrey = "#606366";
    private string _lightRed = "#FEF2F5";
    private string _darkRed = "#D62D45";
    private string _lightBlue = "#F0F7FF";
    private string _darkBlue = "#1976D2";
   
    public void ComposeLogo(IContainer container, string? logoPath)
    {
        if (string.IsNullOrEmpty(logoPath))
        {
            container.Column(column =>
            {
                column
                .Item()
                .Height(35)
                .Width(100)
                .Text(string.Empty);
            });
        }
        else
        {
            container.Column(column =>
            {
                column
                .Item()
                .Height(35)
                .Width(100)
                .Image(logoPath)
                .FitUnproportionally();
            });
        }
    }

    public void ComposeLogoName(IContainer container, string companyName)
    {
        container.Column(column =>
        {
            column
            .Item()
            .AlignCenter()
            .Text(companyName)
            .Style(PurchaseOrderVendorTypography.Heading)
            .FontColor(_procureOrange);
        });
    }

    public void ComposePOApprovalStatus(IContainer container, AprrovalStatus? status)
    {
        status = status ?? AprrovalStatus.Pending;
        var fontColor = status == AprrovalStatus.Approved ? _darkGreen : status == AprrovalStatus.Rejected ? _darkRed : _darkGrey;
        var backGroundColor = status == AprrovalStatus.Approved ? _lightGreen : status == AprrovalStatus.Rejected ? _lightRed : _lightGrey;

        container
            .Column(column =>
            {
                column
                .Item()
                .Background(backGroundColor)
                .BorderColor(fontColor)
                .Column(subColumn =>
                {
                    subColumn.Item()
                    .PaddingVertical(6)
                    .PaddingHorizontal(20)
                    .Text(status.ToString())
                    .Style(PurchaseOrderVendorTypography.Label)
                    .FontColor(fontColor);

                });
            });
    }

    public void ComposeMRIStatus(IContainer container, MaterialReceiptInspectionStatus? status)
    {
        var fontColor = _darkGrey;
        var backGroundColor = _lightGrey;

        switch (status)
        {
            case MaterialReceiptInspectionStatus.Approved:
                fontColor = _darkGreen;
                backGroundColor = _lightGreen;
                break;
            case MaterialReceiptInspectionStatus.ApprovedWithExceptions:
                fontColor = _darkBlue;
                backGroundColor = _lightBlue;
                break;
            case MaterialReceiptInspectionStatus.Rejected:
                fontColor = _darkRed;
                backGroundColor = _lightRed;
                break;
            default:
                fontColor = _darkGrey;
                backGroundColor = _lightGrey;
                break;
        }

        container
            .Column(column =>
            {
                column
                .Item()
                .Background(backGroundColor)
                .BorderColor(fontColor)
                .Column(subColumn =>
                {
                    subColumn.Item()
                    .PaddingVertical(6)
                    .PaddingHorizontal(20)
                    .Text(StringExtensions.MRIStatusToString(status))
                    .Style(PurchaseOrderVendorTypography.Label)
                    .FontColor(fontColor);

                });
            });
    }

    public void ComposePOStatus(IContainer container, PurchaseOrderStatus? status)
    {
        (string backgroundColor, string fontColor) = GetPOStatusColors(status);

        container
            .MaxHeight(50)
            .Background(backgroundColor)
            .BorderColor(fontColor)
            .Column(column =>
            {
                column
                .Item()
                .PaddingVertical(5)
                .PaddingHorizontal(20)
                .Text(EnumExtensions.GetDisplayName(status ?? PurchaseOrderStatus.PendingAdminApproval))
                .Style(PurchaseOrderVendorTypography.Label)
                .FontColor(fontColor);
            });
    }

    private (string backgroundColor, string fontColor) GetPOStatusColors(PurchaseOrderStatus? status) =>
        status switch
        {
            PurchaseOrderStatus.PendingAdminApproval => ("#ECECEC", "#53575A"),
            PurchaseOrderStatus.AdminApprovedPartial => ("#FFF5E8", "#FF8C00"),
            PurchaseOrderStatus.AdminApprovedAll => ("#EDFFF9", "#38C793"),
            PurchaseOrderStatus.AdminSigned => ("#C1FFF9", "#06AF9E"),
            PurchaseOrderStatus.AdminRejectedAll => ("#FFF2F5", "#DF1C41"),
            PurchaseOrderStatus.VendorApprovalPending => ("#EEEEFF", "#5B4C9E"),
            PurchaseOrderStatus.VendorApproved => ("#E5FFF2", "#307D57"),
            PurchaseOrderStatus.VendorRejected => ("#FFEBEB", "#FF4C4C"),
            PurchaseOrderStatus.PartiallyReceived => ("#F0F7FF", "#1976D2"),
            PurchaseOrderStatus.FullyReceived => ("#E9FFF3", "#2E8B57"),
            _ => ("#EDFFF9", "#38C793"),
        };

}
