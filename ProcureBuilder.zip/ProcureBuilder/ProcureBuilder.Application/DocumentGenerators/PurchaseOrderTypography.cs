﻿using QuestPDF.Fluent;
using QuestPDF.Helpers;
using QuestPDF.Infrastructure;

namespace ProcureBuilder.DocumentGenerators;

public static class PurchaseOrderTypography
{
    private const int _fontSize1 = 12;
    private const int _fontSize2 = 20;
    private const int _fontSize3 = 14;
    private const int _fontSize4 = 32;
    public static TextStyle LargeHeading => TextStyle
        .Default
        .FontColor(Colors.DeepOrange.Accent3)
        .FontSize(_fontSize4)
        .Bold();

    public static TextStyle Heading => TextStyle
        .Default
        .FontColor(Colors.DeepOrange.Accent3)
        .FontSize(_fontSize2)
        .Bold();

    public static TextStyle SmallHeading => TextStyle
        .Default
        .FontColor(Colors.DeepOrange.Accent3)
        .FontSize(_fontSize3)
        .Bold();

    public static TextStyle Label => TextStyle
    .Default
    .FontColor(Colors.Black)
    .FontSize(_fontSize1)
    .Bold();

    public static TextStyle LabelValue => TextStyle
    .Default
    .FontColor(Colors.Grey.Darken2)
    .FontSize(_fontSize1);

    public static TextStyle TableHeaderStyle => TextStyle
    .Default
    .FontColor(Colors.Grey.Darken4)
    .FontSize(13)
    .Bold();

    public static TextStyle TableHeaderStyleSmall => TextStyle
    .Default
    .FontColor(Colors.Grey.Darken4)
    .FontSize(11)
    .Bold();

    public static TextStyle TableDataStyle => TextStyle
    .Default
    .FontColor(Colors.Grey.Darken1)
    .FontSize(12);

    public static TextStyle TableDataStyleSmall => TextStyle
    .Default
    .FontColor(Colors.Grey.Darken1)
    .FontSize(10);

}
