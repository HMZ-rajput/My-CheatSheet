﻿using ProcureBuilder.Materials.Entities;
using ProcureBuilder.PurchaseOrders.Entities;
using QuestPDF.Fluent;
using QuestPDF.Helpers;
using QuestPDF.Infrastructure;

namespace ProcureBuilder.DocumentGenerators;

public class POVendorDocument : IDocument
{
    private string _termsAndCondition;
    private string? _logoPath;
    private string _companyName;
    private PurchaseOrder _purchaseOrder;
    private PurchaseOrderApproval? _purchaseOrderApproval;
    private CommonComponents _commonComponents = new CommonComponents();

    public POVendorDocument(PurchaseOrder purchaseOrder, string termsAndCondition, string? logoPath, string? companyName)
    {
        _purchaseOrder = purchaseOrder ?? throw new ArgumentNullException(nameof(purchaseOrder));
        _purchaseOrderApproval = purchaseOrder.PurchaseOrderApprovals.FirstOrDefault(x => x.IsActive && x.AuthorizingEntity == AuthorizingEntity.Vendor);
        _termsAndCondition = termsAndCondition ?? string.Empty;
        _logoPath = logoPath;
        _companyName = companyName ?? "Procure Builder";
    }

    public void Compose(IDocumentContainer container)
    {
        container
            .Page(page =>
            {
                page.Content().Element(ComposeContent);
            });
    }

    void ComposeContent(IContainer container)
    {
        container.Column(column =>
        {
            //Header
            column
            .Item()
            .PaddingTop(15)
            .PaddingBottom(10)
            .PaddingHorizontal(5)
            .Row(row =>
            {
                row.RelativeItem().Element(c => _commonComponents.ComposeLogo(c, _logoPath));
                row.RelativeItem().Element(c => _commonComponents.ComposeLogoName(c, _companyName));
                row.RelativeItem().AlignRight().PaddingHorizontal(20).Element(c => _commonComponents.ComposePOApprovalStatus(c, _purchaseOrderApproval?.Status));
            });

            //Material Details
            column
            .Item()
            .Padding(5)
            .Border(1)
            .BorderColor(Colors.Grey.Lighten1)
            .Column(subColumn =>
            {
                subColumn.Spacing(20);

                subColumn
                .Item()
                .Row(row =>
                {
                    row.RelativeItem()
                        .Border(1)
                        .BorderColor(Colors.Grey.Lighten1)
                        .Element(ComposePODetails);

                    row.RelativeItem()
                        .Border(1)
                        .BorderColor(Colors.Grey.Lighten1)
                        .Element(ComposeVendorDetails);
                });

                subColumn.Item()
                .PaddingHorizontal(7)
                .PaddingBottom(-20)
                .Element(ComposeTableHeader);

                subColumn.Item()
                .PaddingHorizontal(7)
                .PaddingBottom(10)
                .Element(ComposeTableBody);

                subColumn.Item()
                .PaddingLeft(450)
                .PaddingHorizontal(10)
                .PaddingBottom(10)
                .Element(ComposePOTotals);
            });

            column
            .Item()
            .PageBreak();

            //DeliveryNotes
            if (!string.IsNullOrEmpty(_purchaseOrder.DeliveryNotes))
            {
                column
                .Item()
                .PaddingHorizontal(5)
                .PaddingVertical(10)
                .Border(1)
                .BorderColor(Colors.Grey.Lighten1)
                .Column(subColumn =>
                {
                    subColumn.Item()
                    .Element(ComposeDeliveryNotes);
                });
            }

            column
                .Item()
                .PaddingHorizontal(5)
                .PaddingVertical(10)
                .Border(1)
                .BorderColor(Colors.Grey.Lighten1)
                .Element(ComposeSignatureDetails);

            column
            .Item()
            .PageBreak();

            column
                .Item()
                .PaddingHorizontal(5)
                .PaddingVertical(10)
                .Element(ComposeTermsAndCondition);
        });
    }

    void ComposeTableHeader(IContainer container)
    {

        container.Table(table =>
        {
            table.ColumnsDefinition(columns =>
            {
                columns.RelativeColumn(1);
                columns.RelativeColumn(1.2f);
                columns.RelativeColumn(0.5f);
                columns.RelativeColumn(0.4f);
                columns.RelativeColumn(0.6f);
                columns.RelativeColumn(0.6f);
            });

            //table head
            table
                .Cell()
                .BorderLeft(1)
                .BorderTop(1)
                .BorderColor(Colors.Grey.Lighten1)
                .Element(CellHeadStyle)
                .Text("Material")
                .Style(PurchaseOrderVendorTypography.TableHeaderStyle);

            table
                .Cell()
                .BorderTop(1)
                .BorderColor(Colors.Grey.Lighten1)
                .Element(CellHeadStyle)
                .Text("Cost Code")
                .Style(PurchaseOrderVendorTypography.TableHeaderStyle);

            table
                .Cell()
                .BorderTop(1)
                .BorderColor(Colors.Grey.Lighten1)
                .Element(CellHeadStyle)
                .Text("Quantity")
                .Style(PurchaseOrderVendorTypography.TableHeaderStyle);

            table
                .Cell()
                .BorderTop(1)
                .BorderColor(Colors.Grey.Lighten1)
                .Element(CellHeadStyle)
                .Text("UoM")
                .Style(PurchaseOrderVendorTypography.TableHeaderStyle);

            table
                .Cell()
                .BorderTop(1)
                .BorderColor(Colors.Grey.Lighten1)
                .Element(CellHeadStyle)
                .Text("Unit Rate")
                .Style(PurchaseOrderVendorTypography.TableHeaderStyle);

            table
                .Cell()
                .BorderTop(1)
                .BorderRight(1)
                .BorderColor(Colors.Grey.Lighten1)
                .Element(CellHeadStyle)
                .Text("Amount")
                .Style(PurchaseOrderVendorTypography.TableHeaderStyle);

        });

    }

    void ComposeTableBody(IContainer container)
    {
        container.Column(column =>
        {
            foreach (var material in _purchaseOrder.Materials)
            {
                column
                .Item()
                .PreventPageBreak()
                .Element(c => ComposeTableRow(c, material));
            }
        });
    }

    void ComposeTableRow(IContainer container, Material material)
    {
        decimal amount = (decimal)material.Quantity * material.UnitRate;

        container.Table(table =>
        {
            table.ColumnsDefinition(columns =>
            {
                columns.RelativeColumn(1);
                columns.RelativeColumn(1.2f);
                columns.RelativeColumn(0.5f);
                columns.RelativeColumn(0.4f);
                columns.RelativeColumn(0.6f);
                columns.RelativeColumn(0.6f);
            });

            //table body
            table
                .Cell()
                .BorderLeft(1)
                .BorderColor(Colors.Grey.Lighten1)
                .Element(CellDataStyle)
                .Text(material.Name)
                .Style(PurchaseOrderVendorTypography.TableDataStyle);

            table
                .Cell()
                .Element(CellDataStyle)
                .Text(material.CostCode)
                .Style(PurchaseOrderVendorTypography.TableDataStyle);

            table
                .Cell()
                .Element(CellDataStyle)
                .Text(material.Quantity.ToString("#,0.##"))
                .Style(PurchaseOrderVendorTypography.TableDataStyle);

            table
                .Cell()
                .Element(CellDataStyle)
                .Text(material.UnitOfMeasure)
                .Style(PurchaseOrderVendorTypography.TableDataStyle);

            table
                .Cell()
                .Element(CellDataStyle)
                .Text($"${material.UnitRate.ToString("#,0.##")}")
                .Style(PurchaseOrderVendorTypography.TableDataStyle);

            table
                .Cell()
                .BorderRight(1)
                .BorderColor(Colors.Grey.Lighten1)
                .Element(CellDataStyle)
                .Text($"${amount.ToString("#,0.##")}")
                .Style(PurchaseOrderVendorTypography.TableDataStyle);

            //table sub head

            table
            .Cell()
            .ColumnSpan(3)
            .BorderLeft(1)
            .BorderColor(Colors.Grey.Lighten1)
            .Element(CellSubHeadStyle)
            .Text("Max Submittal Lead Time")
            .Style(PurchaseOrderVendorTypography.TableSubHeaderStyle);

            table
            .Cell()
            .ColumnSpan(3)
            .BorderRight(1)
            .BorderColor(Colors.Grey.Lighten1)
            .Element(CellSubHeadStyle)
            .Text("Max Material Lead Time")
            .Style(PurchaseOrderVendorTypography.TableSubHeaderStyle);

            var submittalText = material.MaxSubmittalLeadTime.HasValue ? material.MaxSubmittalLeadTime.Value.ToString("#,0.##") : string.Empty;

            table
                .Cell()
                .ColumnSpan(3)
                .BorderLeft(1)
                .BorderBottom(1)
                .BorderColor(Colors.Grey.Lighten1)
                .Element(SubCellDataStyle)
                .Text(submittalText)
                .Style(PurchaseOrderVendorTypography.TableDataStyle);

            var leadTimeText = material.MaxMaterialLeadTime.HasValue ? material.MaxMaterialLeadTime.Value.ToString("#,0.##") : string.Empty;

            table
                .Cell()
                .ColumnSpan(3)
                .BorderRight(1)
                .BorderBottom(1)
                .BorderColor(Colors.Grey.Lighten1)
                .Element(SubCellDataStyle)
                .Text(leadTimeText)
                .Style(PurchaseOrderVendorTypography.TableDataStyle);
        });
    }

    void ComposePOTotals(IContainer container)
    {
        container.Column(column =>
        {
            column.Spacing(10);

            column
            .Item()
            .Text(text =>
            {
                text.Span("Sub Total:").Style(PurchaseOrderTypography.Label);
                text.Span($" ${_purchaseOrder.SubTotal.ToString("#,0.##")}").Style(PurchaseOrderTypography.LabelValue);
            });

            column
            .Item()
            .Text(text =>
            {
                text.Span("Tax:").Style(PurchaseOrderTypography.Label);
                text.Span($" ${_purchaseOrder.Tax.ToString("#,0.##")}").Style(PurchaseOrderTypography.LabelValue);
            });

            column
            .Item()
            .Text(text =>
            {
                text.Span("Total:").Style(PurchaseOrderTypography.Label);
                text.Span($" ${_purchaseOrder.Total.ToString("#,0.##")}").Style(PurchaseOrderTypography.LabelValue);
            });
        });
    }

    void ComposePODetails(IContainer container)
    {
        container.Padding(10).Column(column =>
        {
            column.Spacing(10);

            column.Item()
            .PaddingBottom(5)
            .Text("PO Details:")
            .Underline()
            .Style(PurchaseOrderTypography.Heading)
            .FontSize(20);

            column.Item()
            .Text(text =>
            {
                text.Span("PO#: ").Style(PurchaseOrderVendorTypography.Label);
                text.Span(_purchaseOrder.PurchaseOrderNumber).Style(PurchaseOrderVendorTypography.LabelValue);
            });

            column.Item()
            .Text(text =>
            {
                text.Span("Project: ").Style(PurchaseOrderVendorTypography.Label);
                text.Span(_purchaseOrder.Project?.Name).Style(PurchaseOrderVendorTypography.LabelValue);
            });

            column.Item()
            .Text(text =>
            {
                string percentage = _purchaseOrder.TaxPercentage.HasValue ? _purchaseOrder.TaxPercentage.Value.ToString("#,0.##") : "0";
                text.Span("Tax Percentage: ").Style(PurchaseOrderVendorTypography.Label);
                text.Span(percentage + "%").Style(PurchaseOrderVendorTypography.LabelValue);
            });
        });
    }

    void ComposeVendorDetails(IContainer container)
    {
        container.Padding(10).Column(column =>
        {
            column.Spacing(10);

            column.Item()
            .PaddingBottom(5)
            .Text("Vendor Details:")
            .Underline()
            .Style(PurchaseOrderTypography.Heading)
            .FontSize(20);

            column.Item()
            .Text(text =>
            {
                text.Span("Company: ").Style(PurchaseOrderVendorTypography.Label);
                text.Span(_purchaseOrder.Vendor?.Name).Style(PurchaseOrderVendorTypography.LabelValue);
            });

            column.Item()
            .Text(text =>
            {
                text.Span("Contact Person: ").Style(PurchaseOrderVendorTypography.Label);
                text.Span(_purchaseOrder.Vendor?.ContactName).Style(PurchaseOrderVendorTypography.LabelValue);
            });

            column.Item()
            .Text(text =>
            {
                text.Span("Phone: ").Style(PurchaseOrderVendorTypography.Label);
                text.Span(_purchaseOrder.Vendor?.PhoneNumber).Style(PurchaseOrderVendorTypography.LabelValue);
            });

            column.Item()
            .Text(text =>
            {
                text.Span("Email: ").Style(PurchaseOrderVendorTypography.Label);
                text.Span(_purchaseOrder.Vendor?.Emails.FirstOrDefault()).Style(PurchaseOrderVendorTypography.LabelValue);
            });

            column.Item()
            .Text(text =>
            {
                text.Span("Address: ").Style(PurchaseOrderVendorTypography.Label);
                text.Span(_purchaseOrder.Vendor?.Address).Style(PurchaseOrderVendorTypography.LabelValue);
            });

        });
    }

    void ComposeDeliveryNotes(IContainer container)
    {
        container.Padding(10).Column(column =>
        {
            column.Spacing(10);

            column.Item()
            .Text("Delivery Notes:")
            .Underline()
            .Style(PurchaseOrderVendorTypography.Heading);

            column.Item()
            .Text(_purchaseOrder.DeliveryNotes)
            .Style(PurchaseOrderVendorTypography.LabelValue);
        });
    }

    void ComposeTermsAndCondition(IContainer container)
    {
        container.Column(column =>
        {
            column.Item()
            .Border(1)
            .BorderColor(Colors.Grey.Lighten1)
            .Column(subColumn =>
            {
                subColumn.Item()
                .PaddingHorizontal(5)
                .PaddingVertical(10)
                .Text("Terms and Conditions:")
                .Underline()
                .Style(PurchaseOrderTypography.Heading);

                subColumn.Item()
                .PaddingHorizontal(5)
                .Text(_termsAndCondition)
                .Style(PurchaseOrderVendorTypography.LabelValue);
            });
        });
    }

    void ComposeSignatureDetails(IContainer container)
    {
        container.Padding(10).Column(column =>
        {
            column.Spacing(10);

            column.Item()
            .PaddingBottom(5)
            .Text("Approval Details:")
            .Underline()
            .Style(PurchaseOrderTypography.Heading)
            .FontSize(20);

            column.Item()
            .Text(text =>
            {
                text.Span("Signature: ").Style(PurchaseOrderVendorTypography.Label);
                text.Span(_purchaseOrderApproval?.Signature).Style(PurchaseOrderVendorTypography.LabelValue);
            });

            column.Item()
            .Text(text =>
            {
                text.Span("Company: ").Style(PurchaseOrderVendorTypography.Label);
                text.Span(_purchaseOrderApproval?.Company).Style(PurchaseOrderVendorTypography.LabelValue);
            });

            column.Item()
            .Text(text =>
            {
                text.Span("Title: ").Style(PurchaseOrderVendorTypography.Label);
                text.Span(_purchaseOrderApproval?.Title).Style(PurchaseOrderVendorTypography.LabelValue);
            });
            column.Item()
            .Text(text =>
            {
                string date = _purchaseOrderApproval?.DateSigned.HasValue ?? false ? _purchaseOrderApproval.DateSigned.Value.ToString("MM/dd/yyyy") : string.Empty;
                text.Span("Date: ").Style(PurchaseOrderVendorTypography.Label);
                text.Span(date).Style(PurchaseOrderVendorTypography.LabelValue);
            });
        });
    }

    IContainer CellDataStyle(IContainer container)
    {
        return container
            .PaddingLeft(5)
            .PaddingBottom(10)
            .PaddingTop(20);
    }

    IContainer SubCellDataStyle(IContainer container)
    {
        return container
            .PaddingLeft(5)
            .PaddingVertical(5);
    }

    IContainer CellHeadStyle(IContainer container)
    {
        return container
            .Background(Color.FromHex("#cad5e2"))
            .PaddingLeft(5)
            .PaddingVertical(5)
            .AlignBottom();
    }

    IContainer CellSubHeadStyle(IContainer container)
    {
        return container
            .Background(Color.FromHex("#f1f5f9"))
            .PaddingLeft(5)
            .PaddingVertical(5)
            .AlignBottom();
    }
}
