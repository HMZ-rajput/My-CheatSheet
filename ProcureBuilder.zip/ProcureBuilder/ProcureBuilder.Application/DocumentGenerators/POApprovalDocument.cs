﻿using Org.BouncyCastle.Crypto.Prng;
using ProcureBuilder.PurchaseOrders.Entities;
using QuestPDF.Fluent;
using QuestPDF.Helpers;
using QuestPDF.Infrastructure;

namespace ProcureBuilder.DocumentGenerators;

public class POApprovalDocument : IDocument
{
    private string _procureOrange = "#F56D36";
    private string _lightGreen = "#E6FFEF";
    private string _darkGreen = "#137C48";
    private string _lightGrey = "#CCCCCD";
    private string _darkGrey = "#606366";
    private string _lightRed = "#FEF2F5";
    private string _darkRed = "#D62D45";
    
    private string? _logoPath;
    private string _companyName;
    private PurchaseOrder _purchaseOrder;
    private PurchaseOrderApproval? _purchaseOrderVendorApproval;
    private PurchaseOrderApproval? _purchaseOrderContractorApproval;
    private CommonComponents _commonComponents = new CommonComponents();

    public POApprovalDocument(PurchaseOrder purchaseOrder, string? logoPath, string? companyName)
    {
        _purchaseOrder = purchaseOrder ?? throw new ArgumentNullException(nameof(purchaseOrder));
        _purchaseOrderVendorApproval = _purchaseOrder.PurchaseOrderApprovals.FirstOrDefault(x => x.IsActive && x.AuthorizingEntity == AuthorizingEntity.Vendor);
        _purchaseOrderContractorApproval = _purchaseOrder.PurchaseOrderApprovals.FirstOrDefault(x => x.IsActive && x.AuthorizingEntity == AuthorizingEntity.Contractor);
        _logoPath = logoPath;
        _companyName = companyName ?? "Procure Builder";
    }

    public void Compose(IDocumentContainer container)
    {
        container
            .Page(page =>
            {
                page.Margin(10);
                page.Content().Element(ComposeContent);
            });
    }

    void ComposeContent(IContainer container)
    {
        container.Column(column =>
        {
            //Header
            column
            .Item()
            .PaddingTop(15)
            .PaddingBottom(10)
            .PaddingHorizontal(5)
            .Row(row =>
            {
                row.RelativeItem().Element(c => _commonComponents.ComposeLogo(c, _logoPath));
                row.RelativeItem().Element(c => _commonComponents.ComposeLogoName(c, _companyName));
                row.RelativeItem().AlignRight().PaddingHorizontal(20).Element(c => _commonComponents.ComposePOApprovalStatus(c, _purchaseOrderContractorApproval?.Status ?? _purchaseOrderVendorApproval?.Status));
            });

            //Material Details
            column
            .Item()
            .PaddingVertical(10)
            .Element(ComposePODetails);

            column
            .Item()
            .Row(row =>
            {
                row
                .RelativeItem()
                .Border(1)
                .Padding(5)
                .BorderColor(Colors.Grey.Darken1)
                .Element(ComposeVendorSignatureDetails);

                row
                .RelativeItem()
                .Border(1)
                .BorderColor(Colors.Grey.Darken1)
                .Padding(5)
                .Element(ComposeContractorSignatureDetails);
            });

        });
    }

    void ComposePODetails(IContainer container)
    {
        container.Column(column =>
        {
            column.Spacing(10);

            column.Item()
            .Text(text =>
            {
                text.Span("PO#: ").Style(PurchaseOrderVendorTypography.Label);
                text.Span(_purchaseOrder.PurchaseOrderNumber).Style(PurchaseOrderVendorTypography.LabelValue);
            });

            column.Item()
            .Text(text =>
            {
                text.Span("PO Title: ").Style(PurchaseOrderVendorTypography.Label);
                text.Span(_purchaseOrder.Title).Style(PurchaseOrderVendorTypography.LabelValue);
            });

            column.Item()
            .Text(text =>
            {
                text.Span("Project: ").Style(PurchaseOrderVendorTypography.Label);
                text.Span(_purchaseOrder.Project?.Name).Style(PurchaseOrderVendorTypography.LabelValue);
            });

        });
    }

    void ComposeContractorSignatureDetails(IContainer container)
    {
        container.Column(column =>
        {
            column.Spacing(16);

            column.Item()
            .Text("Contractor")
            .Underline()
            .AlignCenter()
            .Style(PurchaseOrderTypography.Heading)
            .FontSize(18);

            column.Item()
               .PreventPageBreak()
               .Text(text =>
               {
                   text.Span("Signature: ").Style(PurchaseOrderVendorTypography.Label);
                   text.Span(_purchaseOrderContractorApproval?.Signature).Style(PurchaseOrderVendorTypography.LabelValue);
               });

            column.Item()
                .PreventPageBreak()
                .Text(text =>
                {
                    text.Span("Company: ").Style(PurchaseOrderVendorTypography.Label);
                    text.Span(_purchaseOrderContractorApproval?.Company).Style(PurchaseOrderVendorTypography.LabelValue);
                });

            column.Item()
                .PreventPageBreak()
                .Text(text =>
                {
                    text.Span("Title: ").Style(PurchaseOrderVendorTypography.Label);
                    text.Span(_purchaseOrderContractorApproval?.Title).Style(PurchaseOrderVendorTypography.LabelValue);
                });

            column.Item()
                .PreventPageBreak()
                .Text(text =>
                {
                    var date = _purchaseOrderContractorApproval?.DateSigned.HasValue ?? false
                        ? _purchaseOrderContractorApproval.DateSigned.Value.ToString("MM/dd/yyyy")
                        : string.Empty;

                    text.Span("Date: ").Style(PurchaseOrderVendorTypography.Label);
                    text.Span(date).Style(PurchaseOrderVendorTypography.LabelValue);
                });
        });
    }

    void ComposeVendorSignatureDetails(IContainer container)
    {
        container.Column(column =>
        {
            column.Spacing(16);

            column.Item()
            .AlignCenter()
            .Text("Vendor")
            .Underline()
            .Style(PurchaseOrderTypography.Heading)
            .FontSize(18);

            column.Item()
                .PreventPageBreak()
                .Text(text =>
                {
                    text.Span("Signature: ").Style(PurchaseOrderVendorTypography.Label);
                    text.Span(_purchaseOrderVendorApproval?.Signature).Style(PurchaseOrderVendorTypography.LabelValue);
                });

            column.Item()
                .PreventPageBreak()
                .Text(text =>
                {
                    text.Span("Company: ").Style(PurchaseOrderVendorTypography.Label);
                    text.Span(_purchaseOrderVendorApproval?.Company).Style(PurchaseOrderVendorTypography.LabelValue);
                });

            column.Item()
                .PreventPageBreak()
                .Text(text =>
                {
                    text.Span("Title: ").Style(PurchaseOrderVendorTypography.Label);
                    text.Span(_purchaseOrderVendorApproval?.Title).Style(PurchaseOrderVendorTypography.LabelValue);
                });

            column.Item()
                .PreventPageBreak()
                .Text(text =>
                {
                    var date = _purchaseOrderVendorApproval?.DateSigned.HasValue ?? false 
                        ? _purchaseOrderVendorApproval.DateSigned.Value.ToString("MM/dd/yyyy") 
                        : string.Empty;

                    text.Span("Date: ").Style(PurchaseOrderVendorTypography.Label);
                    text.Span(date).Style(PurchaseOrderVendorTypography.LabelValue);
                });

            column.Item()
                .PreventPageBreak()
                .Text(text =>
                {
                    text.Span("Vendor Comments: ").Style(PurchaseOrderVendorTypography.Label);
                    text.Span(_purchaseOrderVendorApproval?.ApprovalComments).Style(PurchaseOrderVendorTypography.LabelValue);
                });
        });
    }
}
