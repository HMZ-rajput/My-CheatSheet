﻿using ProcureBuilder.Extensions;
using ProcureBuilder.MaterialReceiptInspections.DTOs;
using ProcureBuilder.MaterialReceiptInspections.Entities;
using ProcureBuilder.Materials.Entities;
using ProcureBuilder.PurchaseOrders.Entities;
using QuestPDF.Fluent;
using QuestPDF.Helpers;
using QuestPDF.Infrastructure;

namespace ProcureBuilder.DocumentGenerators;

public class MRIDocument : IDocument
{
    private string? _logoPath;
    private string _companyName;

    private string _lightGreen = "#E6FFEF";
    private string _darkGreen = "#137C48";
    private string _lightGrey = "#CCCCCD";
    private string _darkGrey = "#606366";
    private string _lightRed = "#FEF2F5";
    private string _darkRed = "#D62D45";
    private string _lightBlue = "#F0F7FF";
    private string _darkBlue = "#1976D2";

    public IList<MaterialReceiptInspectionPDFDTO> _materialReceiptInspections { get; }
    public MaterialReceiptInspectionPDFDTO? _materialReceiptInspection { get; set; }
    private CommonComponents _commonComponents = new CommonComponents();

    public MRIDocument(IList<MaterialReceiptInspectionPDFDTO> materialReceiptInspections, string? logoPath, string? companyName)
    {
        _materialReceiptInspections = materialReceiptInspections ?? throw new ArgumentNullException(nameof(materialReceiptInspections));
        _logoPath = logoPath;
        _companyName = companyName ?? "Procure Builder";
    }

    public void Compose(IDocumentContainer container)
    {
        container
            .Page(page =>
            {
                page.Margin(10);
                page.Content().Element(ComposeContent);
            });
    }

    void ComposeContent(IContainer container)
    {
        container.Column(column =>
        {
            foreach (var materialReceipt in _materialReceiptInspections)
            {
                if (_materialReceiptInspections.IndexOf(materialReceipt) != 0)
                    column.Item().PageBreak();

                _materialReceiptInspection = materialReceipt;

                column.Item()
                .Element(ComposeMRIContent);
            }
        });
    }

    void ComposeMRIContent(IContainer container)
    {
        if (_materialReceiptInspection is null)
            return;

        container.Column(column =>
        {
            //Header
            column
            .Item()
            .PaddingVertical(5)
            .Row(row =>
            {
                row.RelativeItem().Element(c => _commonComponents.ComposeLogo(c, _logoPath));
                row.RelativeItem().Element(c => _commonComponents.ComposeLogoName(c, _companyName));
                row.RelativeItem().AlignRight().PaddingHorizontal(20).Element(c => _commonComponents.ComposeMRIStatus(c, _materialReceiptInspection?.Status));
            });

            column
            .Item()
            .Padding(5)
            .PaddingTop(-5)
            .Element(ComposeMRIDetails);

            column
            .Item()
            .PaddingHorizontal(5)
            .Element(ComposeTableHeader);

            column
            .Item()
            .PaddingBottom(5)
            .PaddingHorizontal(5)
            .Element(ComposeTableBody);

            //QualityQuestions
            if(_materialReceiptInspection.QualityQuestions.Count() > 0)
            {
                column
                .Item()
                .Padding(5)
                .PaddingTop(-5)
                .Column(subColumn =>
                {
                    subColumn.Spacing(5);

                    subColumn.Item()
                    .Text("Quality Questions")
                    .Style(MRITypography.Heading);

                    subColumn.Item()
                    .Element(ComposeQualityQuestions);
                });
            }

        });
    }

    void ComposeTableHeader(IContainer container)
    {
        container.Table(table =>
        {
            table.ColumnsDefinition(columns =>
            {
                columns.RelativeColumn(2);
                columns.RelativeColumn(1);
                columns.RelativeColumn(1);
            });

            //table head
            table
                .Cell()
                .BorderLeft(1)
                .BorderTop(1)
                .BorderColor(Colors.Grey.Lighten1)
                .Element(CellHeadStyle)
                .Text("Material")
                .Style(MRITypography.TableHeaderStyle);

            table
                .Cell()
                .BorderTop(1)
                .BorderColor(Colors.Grey.Lighten1)
                .Element(CellHeadStyle)
                .Text("Quantity")
                .Style(MRITypography.TableHeaderStyle);

            table
                .Cell()
                .BorderTop(1)
                .BorderColor(Colors.Grey.Lighten1)
                .Element(CellHeadStyle)
                .Text("Unit of Measure")
                .Style(MRITypography.TableHeaderStyle);

        });

    }

    void ComposeTableBody(IContainer container)
    {
        container.Column(column =>
        {
            foreach (var material in _materialReceiptInspection?.Materials ?? [])
            {
                column
                .Item()
                .PreventPageBreak()
                .Element(c => ComposeTableRow(c, material));
            }
        });
    }

    void ComposeTableRow(IContainer container, MaterialReceiptInspectionMaterialDTO material)
    {
        container.Table(table =>
        {
            table.ColumnsDefinition(columns =>
            {
                columns.RelativeColumn(2);
                columns.RelativeColumn(1);
                columns.RelativeColumn(1);
            });

            //table body
            table
                 .Cell()
                 .BorderLeft(1)
                 .BorderBottom(1)
                 .BorderColor(Colors.Grey.Lighten1)
                 .Element(CellDataStyle)
                 .Text(material.Name)
                 .Style(MRITypography.TableDataStyle);

            table
                .Cell()
                .BorderBottom(1)
                .BorderColor(Colors.Grey.Lighten1)
                .Element(CellDataStyle)
                .Text($"{material.Quantity.ToString("#,0.##")}/{material.TotalQuantity.ToString("#,0.##")}")
                .Style(MRITypography.TableDataStyle);

            table
                 .Cell()
                 .BorderRight(1)
                 .BorderBottom(1)
                 .BorderColor(Colors.Grey.Lighten1)
                 .Element(CellDataStyle)
                 .Text(material.UnitOfMeasure)
                 .Style(MRITypography.TableDataStyle);
        });
    }

    void ComposeMRIDetails(IContainer container)
    {
        container.Column(column =>
        {
            column.Spacing(5);

            column.Item()
            .Text($"Material Receipt Inspection #{(_materialReceiptInspection is null ? 0 : _materialReceiptInspections.IndexOf(_materialReceiptInspection) + 1)}")
            .Style(MRITypography.Heading);

            column.Item()
            .Row(row =>
            {
                row.Spacing(5);

                row.RelativeItem().Text(text =>
                {
                    text.Span("Title: ").Style(MRITypography.Label);
                    text.Span(_materialReceiptInspection?.Title).Style(MRITypography.LabelValue);
                });

                row.RelativeItem().Text(text =>
                {
                    text.Span("Project: ").Style(MRITypography.Label);
                    text.Span(_materialReceiptInspection?.ProjectName).Style(MRITypography.LabelValue);
                });
            });

            column.Item()
            .Row(row =>
            {
                row.Spacing(5);
                row.RelativeItem().Text(text =>
                {
                    text.Span("Location: ").Style(MRITypography.Label);
                    text.Span(_materialReceiptInspection?.LocationName).Style(MRITypography.LabelValue);
                });

                row.RelativeItem().Text(text =>
                {
                    text.Span("SubLocation: ").Style(MRITypography.Label);
                    text.Span(_materialReceiptInspection?.SubLocationName).Style(MRITypography.LabelValue);
                });
            });

            column.Item()
            .Row(row =>
            {
                row.Spacing(5);
                row.RelativeItem().Text(text =>
                {
                    text.Span("Received Date: ").Style(MRITypography.Label);
                    text.Span(_materialReceiptInspection?.ExpectedDate.ToString("MM/dd/yyyy")).Style(MRITypography.LabelValue);
                });

                row.RelativeItem().Text(text =>
                {
                    text.Span("Purchase Order Number: ").Style(MRITypography.Label);
                    text.Span(_materialReceiptInspection?.PurchaseOrderNumber).Style(MRITypography.LabelValue);
                });

            });

        });
    }

    void ComposeQualityQuestions(IContainer container)
    {
        container.Column(column =>
        {
            column.Spacing(5);

            foreach (var qualityQuestion in _materialReceiptInspection?.QualityQuestions ?? [])
            {
                column.Item()
                .PreventPageBreak()
                .Column(subColumn =>
                {
                    subColumn.Item()
                    .Border(1)
                    .BorderColor(Colors.Grey.Lighten1)
                    .Element(c => ComposeQuestion(c, qualityQuestion.Question));

                    subColumn.Item()
                    .Border(1)
                    .BorderColor(Colors.Grey.Lighten1)
                    .Element(c => ComposeAnswer(c, qualityQuestion.Answer));
                });
            }

        });
    }

    void ComposeQuestion(IContainer container, string question)
    {
        container
        .Background("#F6F8FA")
        .Column(column =>
        {
            column.Item()
            .Padding(5)
            .Text(question)
            .Style(MRITypography.LabelValue);
        });
    }

    void ComposeAnswer(IContainer container, string? answer)
    {
        container
        .Background("#F5F5F5")
        .Column(column =>
        {
            column.Item()
            .Padding(5)
            .Text(answer)
            .Style(MRITypography.LabelValue);
        });
    }

    IContainer CellDataStyle(IContainer container)
    {
        return container
        .PaddingLeft(2)
        .PaddingVertical(4);
    }

    IContainer CellHeadStyle(IContainer container)
    {
        return container
        .Background(Color.FromHex("#cad5e2"))
        .PaddingLeft(2)
        .PaddingVertical(2)
        .AlignBottom();
    }

}
