﻿using Microsoft.Extensions.DependencyInjection;
using ProcureBuilder.Services;

namespace ProcureBuilder;

public static class DependencyInjection
{
    public static IServiceCollection AddApplication(this IServiceCollection services)
    {
        services.AddHttpClient();

        services.AddScoped<IMailService, MailService>();
        services.AddScoped<IPDFService, PDFService>();

        return services;
    }
}
