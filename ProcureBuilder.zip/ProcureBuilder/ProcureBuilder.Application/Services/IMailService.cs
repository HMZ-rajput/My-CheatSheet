﻿
namespace ProcureBuilder.Services;
public interface IMailService
{
    ValueTask<bool> SendEmailAsync(string toEmailAddress, string subject, string body);
}
