﻿using ProcureBuilder.DocumentGenerators;
using ProcureBuilder.MaterialReceiptInspections.DTOs;
using ProcureBuilder.PurchaseOrders.Entities;
using QuestPDF.Companion;
using QuestPDF.Fluent;
using QuestPDF.Infrastructure;

namespace ProcureBuilder.Services;

public class PDFService : IPDFService
{
    public PDFService()
    {
        QuestPDF.Settings.License = LicenseType.Community;
    }

    MemoryStream? IPDFService.GeneratePOScanDocument(PurchaseOrder purchaseOrder) =>
        GenerateDocumentFile(new POScanDocument(purchaseOrder));

    MemoryStream? IPDFService.GeneratePODocument(PurchaseOrder purchaseOrder, string? logoPath, string? companyName)
    {
        var document = new PODocument(purchaseOrder, logoPath, companyName);
        //document.ShowInCompanion(12500);
        var data = GenerateDocumentFile(document);
        return data;
    }
    MemoryStream? IPDFService.GeneratePOVendorDocument(PurchaseOrder purchaseOrder, string termsAndCondition, string? logoPath, string? companyName)
    {
        var document = new POVendorDocument(purchaseOrder, termsAndCondition, logoPath, companyName);
        var data = GenerateDocumentFile(document);
        return data;
    }

    MemoryStream? IPDFService.GeneratePOApprovalDocument(PurchaseOrder purchaseOrder, string? logoPath, string? companyName)
    {
        var document = new POApprovalDocument(purchaseOrder, logoPath, companyName);
        var data = GenerateDocumentFile(document);
        return data;
    }

    MemoryStream? IPDFService.GenerateMRIDocument(IList<MaterialReceiptInspectionPDFDTO> materialReceiptInspections, string? logoPath, string? companyName) =>
        GenerateDocumentFile(new MRIDocument(materialReceiptInspections, logoPath,companyName));

    private static MemoryStream? GenerateDocumentFile(IDocument document)
    {
        var memoryStream = new MemoryStream();
        document.GeneratePdf(memoryStream);
        //document.ShowInCompanion(12500);
        memoryStream.Position = 0;
        return memoryStream;
    }
}