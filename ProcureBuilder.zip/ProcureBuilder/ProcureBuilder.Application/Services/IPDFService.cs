﻿using ProcureBuilder.MaterialReceiptInspections.DTOs;
using ProcureBuilder.PurchaseOrders.Entities;

namespace ProcureBuilder.Services;

public interface IPDFService
{
    MemoryStream? GeneratePOScanDocument(PurchaseOrder purchaseOrder);
    MemoryStream? GeneratePODocument(PurchaseOrder purchaseOrder, string? logoPath, string? companyName);
    MemoryStream? GeneratePOVendorDocument(PurchaseOrder purchaseOrder, string termsAndCondition, string? logoPath, string? companyName);
    MemoryStream? GeneratePOApprovalDocument(PurchaseOrder purchaseOrder, string? logoPath, string? companyName);
    MemoryStream? GenerateMRIDocument(IList<MaterialReceiptInspectionPDFDTO> materialReceiptInspections, string? logoPath, string? companyName);
}
