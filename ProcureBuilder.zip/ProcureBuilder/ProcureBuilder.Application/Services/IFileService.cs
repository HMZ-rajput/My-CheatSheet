﻿using Microsoft.AspNetCore.Http;

namespace ProcureBuilder.Services;

public interface IFileService
{
    ValueTask<(string fileName, string filePath)> UploadFileAndGetNewFileNameAndPath(IFormFile file, string fileName);
    ValueTask<byte[]?> DownloadImageAsByteArrayAsync(string imageUrl);
    ValueTask<string> GetLogoPath(string? fileName);
    bool DeleteFileFromPath(string filePath);
    string GetFileURL(string fileName);
    string GetContentPath();
    string GetAssetsPath();
}
