﻿namespace ProcureBuilder.Application;

public static class AppEnvironment
{
    public static EnvironmentType Type { get; private set; }

    public const string DefaultConnectionString = "Server=(local)\\SQLEXPRESS;Database=ProcureBuilder;TrustServerCertificate=True;Trusted_Connection=True;MultipleActiveResultSets=true";
    public static string ConnectionString { get; private set; } = DefaultConnectionString;
    public static string AuthSecretKey { get; set; } = "procurebuildertmm79!#!@#$*()&*($#Q#@$%@@$%&^!$@%#^@$^*&@%^%$@^$$@#%)@#$%@!!@#@$$$mmww@blvopgBN";
    public static string SenderEmailAddress { get; set; } = "qualixdev1@gmail.com";
    public static string SenderEmailPassword { get; set; } = "gpnb cswv icct dvac";
    public static string SMTPHost { get; set; } = "smtp.gmail.com";
    public static string EmailSenderUsername { get; set; } = "Procure Builder";
    public static int SMTPPort { get; set; } = 587;
    public static string BaseURL { get; set; } = "https://procurebuilder.naveedportfolio.com";
    public static string PurchaseOrderVendorApprovalURL => BaseURL + "/purchase-orders/vendor-approve";
    public static bool EnableMailSSL { get; set; } = true;
    public static string CreateUserEmailSubject { get; set; } = "Your Procure Builder App account";
    public static string CreateUserEmailBody { get; set; } = "Your Procure Builder App account has been successfully created. Please use this username: <b>{EMAIL}</b> and password: <b>{PASSWORD}</b> to login";
    public static string PasswordOTPEmailSubject { get; set; } = "OTP For Resetting Your Procure Builder App Password";
    public static string PasswordOTPEmailBody { get; set; } = "Dear Procure Builder User, Please use this OTP <b>{OTP}</b> to reset your password. Please ignore this email if you did not request a password reset and contact support@procurebuilder.org";
    public static int OTPExpiry { get; set; } = 10; // In minutes
    public static string GenericSQLDatabaseError { get; } = "An error occurred while processing the data.";
    public static string SuperAdminEmail { get; } = "superadmin@procurebuilder.com";

    static AppEnvironment()
    {
        Type = EnvironmentType.DEV;
        switch (Type)
        {
            case EnvironmentType.PROD:
                SetUpProd();
                break;
            case EnvironmentType.QA:
                SetUpQA();
                break;
            case EnvironmentType.DEV:
                SetUpDev();
                break;
            case EnvironmentType.LOCAL:
                SetUpLocal();
                break;
            default:
                break;
        }
    }

    public static void SetUpLocal()
    {
        ConnectionString = DefaultConnectionString;
    }

    public static void SetUpDev()
    {
        ConnectionString = "Server=154.12.241.246;Database=QA_ProcureBuilder;User ID=qualixadmin;Password=Qualix_Admin@156;MultipleActiveResultSets=true;TrustServerCertificate=True";
        BaseURL = "https://qa-procurebuilder.naveedportfolio.com";
    }

    public static void SetUpQA()
    {
        ConnectionString = "Server=154.12.241.246;Database=ProcureBuilder;User ID=qualixadmin;Password=Qualix_Admin@156;MultipleActiveResultSets=true;TrustServerCertificate=True";
    }

    public static void SetUpProd()
    {
        ConnectionString = "Server=154.12.243.96;Database=ProcureBuilder;User ID=ProcureAdmin73;Password=Procure_Admin@843;MultipleActiveResultSets=true;TrustServerCertificate=True";
        BaseURL = "https://procurebuilder.com";
        SenderEmailAddress = "donotreply@procurebuilder.com";
        SenderEmailPassword = "ezko hray dput tvxq";
    }
}

public enum EnvironmentType
{
    LOCAL = 0,
    DEV = 1,
    QA = 2,
    PROD = 3
}
