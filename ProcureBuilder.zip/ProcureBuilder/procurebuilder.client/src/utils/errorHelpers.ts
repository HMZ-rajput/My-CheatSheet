import {
  InternalUser,
  InventoryMaterial,
  Location,
  MaterialTransferAddMaterial,
  PurchaseOrderMaterials,
  QualityQuestion,
} from "@/src/utils/types";
import { FormikErrors } from "formik";

type ValidateStatusParams = {
  formik: any;
  field: keyof InternalUser;
  index: number;
};
type ValidateLocationsStatusParams = {
  errors?: any;
  touched?: any;
  field: keyof Location;
  index: number;
};
type ValidateInventoryStatusParams = {
  errors?: any;
  touched?: any;
  field: keyof InventoryMaterial;
  index: number;
};

type ValidateTransferStatusParams = {
  formik: any;
  field: keyof MaterialTransferAddMaterial;
  index: number;
};

export const getValidateStatusInPurchaseOrder = ({
  formik,
  field,
  index,
}: ValidateStatusParams): string => {
  const isTouched = formik.touched.deliveryContacts?.[index]?.[field];
  const isError = (formik.errors.deliveryContacts as FormikErrors<InternalUser>)
    ? (formik.errors.deliveryContacts as FormikErrors<InternalUser[]>)[index]?.[
        field
      ]
    : undefined;

  return isTouched && isError ? "error" : "";
};

export const getHelpMessageInPurchaseOrder = ({
  formik,
  field,
  index,
}: ValidateStatusParams): string => {
  const isTouched = formik.touched.deliveryContacts?.[index]?.[field];
  const errorMessage = (formik.errors
    .deliveryContacts as FormikErrors<InternalUser>)
    ? (formik.errors.deliveryContacts as FormikErrors<InternalUser[]>)[index]?.[
        field
      ]
    : undefined;

  return isTouched && errorMessage ? (errorMessage as string) : "";
};

export const getValidateStatusInLocation = ({
  errors,
  touched,
  field,
  index,
}: ValidateLocationsStatusParams): string => {
  const isTouched = touched.locations?.[index]?.[field];
  const isError = (errors.locations as FormikErrors<Location>)
    ? (errors.locations as FormikErrors<Location[]>)[index]?.[field]
    : undefined;

  return isTouched && isError ? "error" : "";
};

export const getHelpMessageInLocation = ({
  errors,
  touched,
  field,
  index,
}: ValidateLocationsStatusParams): string => {
  const isTouched = touched.locations?.[index]?.[field];
  const errorMessage = (errors.locations as FormikErrors<InternalUser>)
    ? (errors.locations as FormikErrors<Location[]>)[index]?.[field]
    : undefined;

  return isTouched && errorMessage ? (errorMessage as string) : "";
};
export const getValidateStatusInInventory = ({
  errors,
  touched,
  field,
  index,
}: ValidateInventoryStatusParams): string => {
  const isTouched = touched.inventory?.[index]?.materials?.[index]?.[field];
  const isError = (errors.inventory
    .materials as FormikErrors<InventoryMaterial>)
    ? (errors.inventory.materials as FormikErrors<InventoryMaterial[]>)[
        index
      ]?.[field]
    : undefined;

  return isTouched && isError ? "error" : "";
};

export const getHelpMessageInInventory = ({
  errors,
  touched,
  field,
  index,
}: ValidateInventoryStatusParams): string => {
  const isTouched = touched.inventory?.[index]?.materials?.[index]?.[field];
  const errorMessage = (errors.inventory
    .materials as FormikErrors<InventoryMaterial>)
    ? (errors.inventory.materials as FormikErrors<InventoryMaterial[]>)[
        index
      ]?.[field]
    : undefined;

  return isTouched && errorMessage ? (errorMessage as string) : "";
};

type ValidationPurchaseOrderMaterialsParams = {
  formik: any;
  field: keyof PurchaseOrderMaterials;
  index: number;
};

export const getPurchaseOrderMaterialsValidateStatus = ({
  formik,
  field,
  index,
}: ValidationPurchaseOrderMaterialsParams): string => {
  const isTouched = formik.touched.purchaseOrderMaterials?.[index]?.[field];
  const isError = (formik.errors.purchaseOrderMaterials as FormikErrors<
    PurchaseOrderMaterials[]
  >)
    ? (
        formik.errors.purchaseOrderMaterials as FormikErrors<
          PurchaseOrderMaterials[]
        >
      )[index]?.[field]
    : undefined;

  return isTouched && isError ? "error" : "";
};

export const getPurchaseOrderMaterialsHelpMessage = ({
  formik,
  field,
  index,
}: ValidationPurchaseOrderMaterialsParams): string => {
  const isTouched = formik.touched.purchaseOrderMaterials?.[index]?.[field];
  const errorMessage = (formik.errors.purchaseOrderMaterials as FormikErrors<
    PurchaseOrderMaterials[]
  >)
    ? (
        formik.errors.purchaseOrderMaterials as FormikErrors<
          PurchaseOrderMaterials[]
        >
      )[index]?.[field]
    : undefined;

  return isTouched && errorMessage ? errorMessage : "";
};

type QuestionsValidationStatusParams = {
  formik: any;
  field: keyof QualityQuestion;
  index: number;
};

export const getValidateStatusInQualityQuestions = ({
  formik,
  field,
  index,
}: QuestionsValidationStatusParams): string => {
  const isTouched = formik.touched.questionContent?.[index]?.[field];
  const isError = (formik.errors.questionContent as FormikErrors<
    QualityQuestion[]
  >)
    ? (formik.errors.questionContent as FormikErrors<QualityQuestion[]>)[
        index
      ]?.[field]
    : undefined;

  return isTouched && isError ? "error" : "";
};

export const getHelpMessageInQualityQuestions = ({
  formik,
  field,
  index,
}: QuestionsValidationStatusParams): string => {
  const isTouched = formik.touched.questionContent?.[index]?.[field];
  const errorMessage = (formik.errors.questionContent as FormikErrors<
    QualityQuestion[]
  >)
    ? (formik.errors.questionContent as FormikErrors<QualityQuestion[]>)[
        index
      ]?.[field]
    : undefined;

  return isTouched && errorMessage ? (errorMessage as string) : "";
};






export const getValidateStatusTransferMaterials = ({
  formik,
  field,
  index,
}: ValidateTransferStatusParams): string => {
  const isTouched = formik.touched.materials?.[index]?.[field];
  const isError = (formik.errors.materials as FormikErrors<MaterialTransferAddMaterial[]>)
    ? (formik.errors.materials as FormikErrors<MaterialTransferAddMaterial[]>)[index]?.[field]
    : undefined;

  return isTouched && isError ? "error" : "";
};

export const getHelpMessageTransferMaterials = ({
  formik,
  field,
  index,
}: ValidateTransferStatusParams): string => {
  const isTouched = formik.touched.materials?.[index]?.[field];
  const errorMessage = (formik.errors.materials as FormikErrors<MaterialTransferAddMaterial[]>)
    ? (formik.errors.materials as FormikErrors<MaterialTransferAddMaterial[]>)[index]?.[field]
    : undefined;

  return isTouched && errorMessage ? errorMessage : "" ;
};
