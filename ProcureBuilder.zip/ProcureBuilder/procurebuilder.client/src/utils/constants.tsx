import { IconType } from "../components/common/CustomIcon";
import {
  BudgetStatusEnum,
  ChangeOrderStatusEnum,
  EntityTypeEnum,
  InvoicesStatusEnum,
  MaterialReceiptInspectionStatusEnum,
  MaterialTransferStatusEnum,
  PaymentTermEnum,
  ProductSortingFilterEnum,
  ProjectComparisonTypeEnum,
  ProjectStatusEnum,
  PurchaseOrderMaterialStatusEnum,
  PurchaseOrderMaterialTypeEnum,
  PurchaseOrderStatusEnum,
  PurchaseOrderSubmittalStatusEnum,
  ReorderStatusEnum,
  UserRoleEnum,
  UserStatus,
} from "./enums";
import { RequestWithReportOption } from "./types";

export const dateFormat = "MM/DD/YYYY";

export const dateFormatDetailed = "MMM D, YYYY, hh:mm A";

export const allProjectStatusOption = {
  value: "all-status",
  label: "All Status",
};
export const allLocationOption = {
  value: "all-status",
  label: "All Status",
};

export const productSortingOptions = {
  value: "",
  label: "Sort by",
};

export const projectStatusOptions = [
  { value: ProjectStatusEnum.OPEN, label: "Open" },
  { value: ProjectStatusEnum.CLOSED, label: "Closed" },
];

export const allPurchaseOrderStatusOptions = {
  value: "all-status",
  label: "All Status",
};

export const statusOptions = {
  value: "all-status",
  label: "All Status",
};

export const purchaseOrderStatusOptions = [
  {
    value: PurchaseOrderStatusEnum.PendingAdminApproval,
    label: "Pending Admin Approval",
  },
  {
    value: PurchaseOrderStatusEnum.AdminApprovedPartial,
    label: "Admin Approved (Partial)",
  },
  {
    value: PurchaseOrderStatusEnum.AdminApprovedAll,
    label: "Admin Approved (All)",
  },
  { value: PurchaseOrderStatusEnum.AdminSigned, label: "Admin Signed" },
  { value: PurchaseOrderStatusEnum.AdminRejectedAll, label: "Admin Rejected" },
  {
    value: PurchaseOrderStatusEnum.VendorApprovalPending,
    label: "Vendor Approval Pending",
  },
  { value: PurchaseOrderStatusEnum.VendorApproved, label: "Vendor Approved" },
  { value: PurchaseOrderStatusEnum.VendorRejected, label: "Vendor Rejected" },
  {
    value: PurchaseOrderStatusEnum.PartiallyReceived,
    label: "Partially Received",
  },
  { value: PurchaseOrderStatusEnum.FullyReceived, label: "Fully Received" },
];

export const AuthorizingEntity = {
  Contractor: 0,
  Vendor: 1,
};

export const purchaseOrderStatusOptionsWithAll = [
  allPurchaseOrderStatusOptions,
  ...purchaseOrderStatusOptions,
];

export const allPurchaseOrderSubmittalStatusOptions = {
  value: "all-submittal-status",
  label: "All Submittal Status",
};

export const purchaseOrderSubmittalStatusOptions = [
  {
    value: PurchaseOrderSubmittalStatusEnum.Pending,
    label: "Pending",
  },
  {
    value: PurchaseOrderSubmittalStatusEnum.Recieved,
    label: "Received",
  },
  {
    value: PurchaseOrderSubmittalStatusEnum.UnderReview,
    label: "Under Review",
  },
  {
    value: PurchaseOrderSubmittalStatusEnum.NoExceptionsTaken,
    label: "No Exceptions Taken",
  },
  {
    value: PurchaseOrderSubmittalStatusEnum.ApprovedAsNoted,
    label: "Approved As Noted",
  },
  {
    value: PurchaseOrderSubmittalStatusEnum.ReviseAndResubmit,
    label: "Revise & Resubmit",
  },
  {
    value: PurchaseOrderSubmittalStatusEnum.Rejected,
    label: "Rejected",
  },
];

export const purchaseOrderSubmittalStatusOptionsWithAll = [
  allPurchaseOrderSubmittalStatusOptions,
  ...purchaseOrderSubmittalStatusOptions,
];

export const purchaseOrderMaterialStatusOptions = [
  {
    value: PurchaseOrderMaterialStatusEnum.Pending,
    label: "Pending",
  },
  {
    value: PurchaseOrderMaterialStatusEnum.PartiallyReceived,
    label: "Partially Received",
  },
  {
    value: PurchaseOrderMaterialStatusEnum.FullyReceived,
    label: "Fully Received",
  },
];

export const purchaseOrderMaterialTypeOptions = [
  {
    value: PurchaseOrderMaterialTypeEnum.Regular,
    label: "Regular",
  },
  {
    value: PurchaseOrderMaterialTypeEnum.Sample,
    label: "Samples",
  },
  {
    value: PurchaseOrderMaterialTypeEnum.Spare,
    label: "Spare",
  },
];

export const paymentTermOptions = [
  { value: PaymentTermEnum.Net30Days, label: "Net 30 Days" },
  { value: PaymentTermEnum.Net45Days, label: "Net 45 Days" },
  { value: PaymentTermEnum.Net60Days, label: "Net 60 Days" },
];

export const projectStatusOptionsWithAll = [
  allProjectStatusOption,
  ...projectStatusOptions,
];

export const allInternalUserStatusOption = {
  value: "all-status",
  label: "All Status",
};

export const internalUserStatusOptions = [
  { value: UserStatus.Active, label: "Active" },
  { value: UserStatus.InvitePending, label: "Invite Pending" },
];

export const internalUserStatusOptionsWithAll = [
  allInternalUserStatusOption,
  ...internalUserStatusOptions,
];

export const allInternalUserRoleOption = {
  value: "all-roles",
  label: "All Roles",
};

export const allProjectsOptions = {
  value: "",
  label: "All Projects",
};

export const internalUserRoleOptions = [
  { value: UserRoleEnum.Fieldcraft, label: "Fieldcraft" },
  { value: UserRoleEnum.Engineer, label: "Engineer" },
  { value: UserRoleEnum.Superintendent, label: "Superintendent" },

  { value: UserRoleEnum.Admin, label: "Admin" },
];

export const internalUserRoleOptionsWithAll = [
  allInternalUserRoleOption,
  ...internalUserRoleOptions,
];

export const allInvoicesStatusOption = {
  value: "all-status",
  label: "All Status",
};

export const invoicesStatusOptions = [
  { value: InvoicesStatusEnum.Pending, label: "Pending" },
  { value: InvoicesStatusEnum.PartiallyPaid, label: "Partially Paid" },
  { value: InvoicesStatusEnum.FullyPaid, label: "Fully Paid" },
];

export const invoicesStatusOptionsWithAll = [
  allInvoicesStatusOption,
  ...invoicesStatusOptions,
];

export const allMaterialTransferStatusOption = {
  value: "all-status",
  label: "All Status",
};

export const materialTransferStatusOptions = [
  { value: MaterialTransferStatusEnum.PENDING, label: "Pending" },
  { value: MaterialTransferStatusEnum.INPROGRESS, label: "In-Progress" },
  { value: MaterialTransferStatusEnum.TRANSFERRED, label: "Transferred" },
  { value: MaterialTransferStatusEnum.CANCELLED, label: "Cancelled" },
];

export const materialTransferStatusOptionsWithAll = [
  allMaterialTransferStatusOption,
  ...materialTransferStatusOptions,
];

export const allChangeOrderStatusOption = {
  value: "all-status",
  label: "All Status",
};

export const changeOrderStatusOptions = [
  { value: ChangeOrderStatusEnum.Pending, label: "Pending" },
  { value: ChangeOrderStatusEnum.Approved, label: "Approved" },
  { value: ChangeOrderStatusEnum.Rejected, label: "Rejected" },
  {
    value: ChangeOrderStatusEnum.AddedToBidMaterial,
    label: "Added to Bid Material",
  },
];

export const changeOrderStatusOptionsWithAll = [
  allChangeOrderStatusOption,
  ...changeOrderStatusOptions,
];

export const allReorderStatusOption = {
  value: "all-status",
  label: "All Status",
};

export const reorderStatusOptions = [
  { value: ReorderStatusEnum.PendingReQuote, label: "Pending Re-quote" },
  { value: ReorderStatusEnum.QuoteReceived, label: "Quote Received" },
  { value: ReorderStatusEnum.PoCreated, label: "P.O. Created" },
];

export const reorderStatusOptionsWithAll = [
  allReorderStatusOption,
  ...reorderStatusOptions,
];

export const allMaterialReceiptInspectionsStatusOption = {
  value: "all-status",
  label: "All Status",
};

export const MaterialReceiptInspectionsStatusOptions = [
  { value: MaterialReceiptInspectionStatusEnum.PENDING, label: "Pending" },
  { value: MaterialReceiptInspectionStatusEnum.APPROVED, label: "Approved" },
  {
    value: MaterialReceiptInspectionStatusEnum.APPROVEDWITHEXCEPTIONS,
    label: "Approved with Exceptions",
  },
  { value: MaterialReceiptInspectionStatusEnum.REJECTED, label: "Rejected" },
];

export const materialReceiptInspectionOptionsWithAll = [
  allMaterialReceiptInspectionsStatusOption,
  ...MaterialReceiptInspectionsStatusOptions,
];

export const productSortingFilterOptions = [
  {
    value: "",
    label: "Sort Products By",
  },
  {
    value: ProductSortingFilterEnum.QuantityHighToLow,
    label: "Quantity - High to Low",
  },
  {
    value: ProductSortingFilterEnum.QuantityLowToHigh,
    label: "Quantity - Low to High",
  },
  { value: ProductSortingFilterEnum.NameAscending, label: "Name - Ascending" },
  {
    value: ProductSortingFilterEnum.NameDescending,
    label: "Name - Descending",
  },
];

export const allCompanyOption = {
  value: "all-companies",
  label: "All Companies & Entities",
};

export const allInventoryLocationsOption = {
  value: "all-locations",
  label: "All Locations",
};
export const allInventorySublocationsOption = {
  value: "all-sub-locations",
  label: "All Sublocations",
};

export const selectComparisonOptions = [
  { value: ProjectComparisonTypeEnum.ALLTIME, label: "All Time" },
  { value: ProjectComparisonTypeEnum.LASTMONTH, label: "Last Month" },
  { value: ProjectComparisonTypeEnum.LASTSIXMONTHS, label: "Last Six Months" },
  { value: ProjectComparisonTypeEnum.LASTYEAR, label: "Last Year" },
];

export const invoiceOptions = {
  [BudgetStatusEnum.OverBudget]: "Over Budget",
  [BudgetStatusEnum.WithinBudget]: "Within Budget",
};

export const statesList = [
  "Alabama",
  "Alaska",
  "Arizona",
  "Arkansas",
  "California",
  "Colorado",
  "Connecticut",
  "Delaware",
  "Florida",
  "Georgia",
  "Hawaii",
  "Idaho",
  "Illinois",
  "Indiana",
  "Iowa",
  "Kansas",
  "Kentucky",
  "Louisiana",
  "Maine",
  "Maryland",
  "Massachusetts",
  "Michigan",
  "Minnesota",
  "Mississippi",
  "Missouri",
  "Montana",
  "Nebraska",
  "Nevada",
  "New Hampshire",
  "New Jersey",
  "New Mexico",
  "New York",
  "North Carolina",
  "North Dakota",
  "Ohio",
  "Oklahoma",
  "Oregon",
  "Pennsylvania",
  "Rhode Island",
  "South Carolina",
  "South Dakota",
  "Tennessee",
  "Texas",
  "Utah",
  "Vermont",
  "Virginia",
  "Washington",
  "West Virginia",
  "Wisconsin",
  "Wyoming",
];

export const storageTypeOptions = [
  "Warehouse",
  "Yard",
  "Office",
  "Space",
  "Parking Lot",
];

export const paginationPayload: {
  pageNumber: number;
  pageSize: number;
} & RequestWithReportOption = {
  pageNumber: 1,
  pageSize: 5,
  isForReport: false,
};
export const numberRegex = /^\d+(\.\d+)?$/;

// export const phoneNumberLengthRegex = /^1\d{10}$/;
export const phoneNumberLengthRegex = /^1[2-9]\d{2}[2-9]\d{6}$/;

export const getEntityIconType: { [key: number]: IconType } = {
  [EntityTypeEnum.PurchaseOrder]: "dashboard-purchase-order-icon",
  [EntityTypeEnum.Reorder]: "dashboard-reorder-icon",
  [EntityTypeEnum.MaterialTransfer]: "dashboard-material-transfer-icon",
  [EntityTypeEnum.MaterialToSite]: "dashboard-material-transfer-to-site-icon",
  [EntityTypeEnum.Invoice]: "dashboard-invoice-icon",
  [EntityTypeEnum.ChangeOrder]: "dashboard-partial-delivered-icon", // Assuming this icon, adjust if needed
  [EntityTypeEnum.MaterialReceiptInspection]:
    "dashboard-material-receipt-inspection-icon",
  [EntityTypeEnum.Project]: "dashboard-material-transfer-icon",
};

export const modulesConstant = {
  PROJECTS: "Projects",
  LOCATIONS: "Locations",
  PRODUCTS: "Products",
  PURCHASE_ORDERS: "Purchase Orders",
  REORDERS: "Reorders",
  MATERIAL_TRANSFER: "Material Transfer",
  INVOICES: "Invoices",
  MATERIAL_RECEIPT_INSPECTION: "Material Receipt Inspection",
  CHANGE_ORDERS: "Change Orders",
  PROJECT_MANAGEMENT: "Project Management",
  VENDORS: "Vendors",
  INTERNAL_USERS: "Internal Users",
  COMPANY_SETTINGS: "Company Settings",
  ACCOUNT_SETTINGS: "Account Settings",
  MATERIAL_GOING_TO_SITES: "Material Going To Sites",
  DASHBOARD: "Dashboard",
  REPORTS: "Reports",
  ORDERS: "Orders",
  LOGIN_MATERIAL: "Login Material",
  LOGOUT_MATERIAL: "Logout Material",
  LOGOUT: "Log Out",
  CONTACTS: "Contacts",
  CUSTOMER_MANAGEMENT: "Customer Management",
  CUSTOMERS: "Customers",
  CUSTOMER_CONTACTS: "Customer Contacts",
  CUSTOMERS_CONTACTS: "Customers Contacts",
  CUSTOMERS_LOCATIONS: "Customers Locations",
};

export const Roles = {
  Admin: "Admin",
  Fieldcraft: "Fieldcraft",
  Engineer: "Engineer",
  Superintendent: "Superintendent",
  SuperAdmin: "SuperAdmin",
};

export const allUsersAccess = [
  Roles.Admin,
  Roles.SuperAdmin,
  Roles.Engineer,
  Roles.Fieldcraft,
  Roles.Superintendent,
];
export const isCombineAdminSuperAdminAccess = [Roles.Admin, Roles.SuperAdmin];

export const isFreight = "freight";

export const fromLocations = "location";
