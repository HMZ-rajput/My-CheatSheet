export const toCapitalizedCase = (str: string): string => {
  return str
    .replace(/([a-z])([A-Z])/g, "$1 $2") // Insert space before each uppercase letter
    .replace(/\b\w/g, (match) => match.toUpperCase()); // Capitalize the first letter of each word
};
export const toCamelCase = (str: string): string => {
  return str
    .replace(/(?:^\w|[A-Z]|\b\w)/g, (match, index) =>
      index === 0 ? match.toLowerCase() : match.toUpperCase()
    )
    .replace(/\s+/g, "");
};
export const getFullName = (data: any) => {
  return `${data?.firstName || ""} ${data?.lastName || ""}`?.trim();
};
export const getLocaleNumberStringWithSigns = (
  num: number,
  prefix?: string
) => {
  const isNegativeNumber = num < 0;
  let str = Number(Math.abs(num || 0)?.toFixed(2))?.toLocaleString() || 0;

  if (prefix) {
    str = prefix + str;
  }

  return isNegativeNumber ? `-${str}` : str;
};
