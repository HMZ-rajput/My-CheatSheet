import dayjs, { Dayjs, ManipulateType } from "dayjs";
import { dateFormat } from "./constants";

export function getCurrentMonthYear(
  startDate: Date,
  endDate: Date,
  format = "numeric"
) {
  const startYear = startDate.getFullYear();
  const endYear = endDate.getFullYear();

  const monthNames = [
    "Jan",
    "Feb",
    "Mar",
    "Apr",
    "May",
    "Jun",
    "Jul",
    "Aug",
    "Sep",
    "Oct",
    "Nov",
    "Dec",
  ];

  // Get month depending on format
  const getMonth = (date: Date) =>
    format === "numeric" ? date.getMonth() + 1 : monthNames[date.getMonth()];

  const startMonth = getMonth(startDate);
  const endMonth = getMonth(endDate);

  // Case 1: Both the start and end of the week are in the same month
  if (startMonth === endMonth && startYear === endYear) {
    return `${startMonth} ${startYear}`;
  }

  // Case 2: The week spans across two months or years
  return `${startMonth} ${startYear} - ${endMonth} ${endYear}`;
}
/* Convert a Microsoft OADate to ECMAScript Date
 ** Treat all values as local.
 ** @param {number} oaDate - OADate value
 ** @returns {Date}
 */
export function getDateFromOADate(oaDate: number) {
  // Treat integer part is whole days
  var days = parseInt(`${oaDate}`);
  // Treat decimal part as part of 24hr day, always +ve
  var ms = Math.abs((oaDate - days) * 8.64e7);
  // Add days and add ms
  return new Date(1899, 11, 30 + days, 0, 0, 0, ms);
}

export const handleIncrementDate = (
  date: string | Dayjs | Date | null,
  reviewPeriod: number,
  period: ManipulateType
) => {
  return dayjs(date).add(reviewPeriod, period).locale("en").format(dateFormat);
};
