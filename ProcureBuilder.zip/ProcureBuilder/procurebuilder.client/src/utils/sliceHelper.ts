export const resetIntialValues = (state: any) => {
  state.isSuccess = false;
  state.isLoading = false;
  state.reqError = null;
  state.resError = null;
  state.successMessage = "";
};
