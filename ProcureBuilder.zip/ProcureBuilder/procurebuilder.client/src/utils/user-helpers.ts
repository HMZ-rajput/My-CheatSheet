import { store } from "@store/index"
export const getBearerToken = () => store.getState().user?.data?.bearerToken
