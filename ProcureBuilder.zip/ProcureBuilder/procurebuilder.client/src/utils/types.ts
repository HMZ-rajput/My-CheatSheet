export type BulkUploadLabelType = {
  originalIndex: number;
};
export type LabelSupportedMaterialType = BulkUploadLabelType &
  Material & {
    material: string;
    unitOfMeasurement: string;
  };
export type LabelSupportedReorderMaterial = BulkUploadLabelType &
  ReorderMaterial & {
    material: string;
    totalQuantity: number;
    unitOfMeasurement: string;
  };
export type LabelSupportedInventoryMaterial = BulkUploadLabelType &
  InventoryMaterial & {
    material: string;
    sublocation: string;
    refillable: boolean;
    unitOfMeasurement: string;
  };

export type LabelSupportedPOMaterial = BulkUploadLabelType &
  Omit<
    PurchaseOrderMaterials,
    "maxSubmittalLeadTime" | "maxMaterialLeadTime" | "isMaterialAlreadyApproved"
  > & {
    material: string;
    unitOfMeasurement: string;
    isMaterialAlreadyApproved: string | boolean;
    maxSubmittalLeadTime: string | number;
    maxMaterialLeadTime: string | number;
    submittalStatus: string;
  };

import {
  ActionTypeEnum,
  NotificationActionEnum,
  ProjectStatusEnum,
} from "@utils/enums";
import { ColumnType } from "antd/es/table";
import dayjs, { Dayjs } from "dayjs";
import { IconType } from "../components/common/CustomIcon";

export type VendorDivision = {
  id: string | null;
  name: string;
};

export type User = {
  userId: string;
  firstName: string;
  lastName: string;
  userName: string;
  userRole: string;
  bearerToken: string;
  isActive: boolean;
  isAuthenticated?: boolean;
  phoneNumber?: string | null;
  cellNumber?: string | null;
  createdDate?: string;
  role: string;
};

export type LocationsList = {
  id: string;
  name: string;
  subLocations?: LocationsList[];
  projectId?: string;
};

export type InternalUser = {
  id?: string | undefined;
  fullName: string;
  firstName: string;
  lastName: string;
  userName: string;
  email?: string;
  role?: number | string | null;
  phoneNumber: string;
  status: number;
  isEmailNotificationsEnabled: boolean;
  isTextNotificationsEnabled: boolean;
  cellNumber: string;
  createdBy: string;
  createdDate: Date;
  modifiedDate: Date | null;
  modifiedBy: string;
  lastModifiedDate?: Date | null;
  lastModifiedBy?: string;
  userId?: string;
};
export type Approver = Pick<
  InternalUser,
  | "id"
  | "userName"
  | "firstName"
  | "lastName"
  | "fullName"
  | "phoneNumber"
  | "email"
> & { role: string };

export type Project = {
  id: string;
  name: string;
  code: string;
  notes?: string;
  status: ProjectStatusEnum;
  createdBy: string;
  contractPrice?: number;
  isDraft?: boolean;
  isAccessible?: boolean;

  // Relations
  customer?: Customer;
  projectTypeId: string | null;
  projectTypeName?: string;
  projectManagersIds?: string[];
  bidMaterialDetails?: MaterialDetails | null;

  // Dates
  createdDate: Date;
  modifiedDate: Date;
  projectedStartDate?: Date | null;
  projectedCompletionDate?: Date | null;
  actualStartDate?: Date | null | string;
  actualCompletionDate?: Date | null | string;
  lastModifiedBy?: string;
  lastModifiedDate?: Date;
};
export type SummarizedProject = Pick<
  Project,
  "id" | "name" | "projectTypeId" | "isDraft"
>;

export type ProjectType = {
  id: string | null;
  name: string;
};

export type ProjectManager = {
  id: string;
  fullName: string;
  firstName: string;
  lastName: string;
  userName: string;
};

export type Customer = {
  id?: string;
  firstName: string;
  lastName: string;
  companyName: string;
  phoneNumber: string;
  cellPhoneNumber: string;
  primaryEmail: string;
  createdBy: string;
  createdDate?: Date;
  modifiedDate: Date | null;
  lastModifiedBy: string;
  lastModifiedDate: Date | null;

  // Address
  streetAddress: string;
  city: string;
  state: string | null;
  zipCode: string;

  // Relations
  projects: Project[];
};

export type InvoiceProject = {
  id: string;
  projectTypeId: string;
  name: string;
  purchaseOrders: [];
};
export type InvoiceVendor = {
  id: string;
  name: string;
};
export type InvoicePurchaseOrder = {
  id: string;
  purchaseOrderNumber: string;
  title: string;
  deliveryLocation: [];
};

export type Invoice = {
  id: string;
  invoiceNumber: string;
  title: string;
  vendor: InvoiceVendor;
  invoiceDate: Date | null;
  dueDate: Date | null;
  paymentTerm: number;
  total: number;
  status: number;
  purchaseOrderId?: string;
  purchaseOrder?: InvoicePurchaseOrder;
  tax: number;
  vendorInvoiceNumber: string;
  createdBy: string;
  createdDate: Date;
  modifiedDate: Date | null;
  modifiedBy: string;
  lastModifiedBy: string;
  lastModifiedDate?: Date | null;
  project: InvoiceProject;
  projectId: string;
  locationName: string;
  projectLocationId: string;
  location: LocationsList;
  vendorId: string;
  vendorName: string;
  notes: string;
  materials: Material[];
  freight: number;
  subTotal?: number;
  taxPercentage: number;
  purchaseOrderNumber: string;
  purchaseOrderDocument?: Attachment[] | null;
  vendorInvoiceDocument?: Attachment[] | null;
  documents: Attachment[];
  attachments?: Attachment[] | null;
  deleteAttachmentIds?: [] | null;
};

export type DeliveryLocation = {
  id: string;
  name: string;
  subLocations: SubLocation[];
};

export type PurchaseOrders = {
  id: string;
  purchaseOrderNumber: string;
  title?: string;
  deliveryLocation?: DeliveryLocation;
};

export type PurchaseOrdersResponse = {
  purchaseOrders: PurchaseOrders[];
};

export type MaterialTransferAddMaterial = {
  id: string;
  name: string;
  // materialType: number;
  quantity: number;
  unitOfMeasure: string;
  subLocationId: string;
  subLocationName: string;
  samples: number;
  spares: number;
  regular: number;
  // materialType: number;
};

//Material Transfer Types Start
export type OriginalProjectMaterialTransfer = {
  id: string;
  projectTypeId: string | null;
  name: string;
};
export type OriginalLocationMaterialTransfer = {
  id: string;
  name: string | null;
  subLocations: [];
};
export type DestinationLocationMaterialTransfer = {
  id: string;
  name: string | null;
  subLocations: [];
};
export type DestinationSubLocationMaterialTransfer = {
  id: string;
  name: string | null;
};

export type MaterialTransfer = {
  id?: string;
  title: string;
  transferDate: Dayjs | Date | null;
  status: number;
  createdBy?: string;
  createdDate?: Date;
  modifiedDate?: Date;
  modifiedBy?: string;
  lastModifiedBy?: string;
  lastModifiedDate?: Date;
  destinationSublocationName?: string;
  destinationSubLocationId: string;
  destinationLocationId: string | null;
  destinationLocationName?: string;
  originalLocationName?: string;
  originalLocationId: string | null;
  purchaseOrderIds?: string[];
  purchaseOrders?: { id: string; name: string }[];

  projectId: string | null;
  projectName?: string;
  materials: MaterialTransferAddMaterial[];

  originalProject?: OriginalProjectMaterialTransfer;
  originalLocation?: OriginalLocationMaterialTransfer;
  destinationLocation?: DestinationLocationMaterialTransfer;
  destinationSubLocation?: DestinationSubLocationMaterialTransfer;
};
//Material Transfer Types End

export type SubLocation = {
  id: string | null;
  projectLocationId: string | null;
  name: string | null;
};

export type StorageType = {
  id: string;
  name: string;
};
export type Inventory = {
  locationName?: string;
  locationId: string;
  materials: InventoryMaterial[];
};

type ProjectDetailsForInventory = {
  id: string;
  projectTypeId: string | null;
  projectTypeName: string;
  name: string;
  purchaseOrders: PurchaseOrder[];
};

export type InventoriesList = {
  inventories: Inventory[];
  Project: ProjectDetailsForInventory;
  modifiedDate?: Date | null;
  createdBy?: string | null;
  modifiedBy?: string | null;
  createdDate?: Date | null;
  lastModifiedBy?: string | null;
  lastModifiedDate?: Date;
};

export type LocationMaterials = {
  locationId: string;
  projectId: string;
  materials: Material[];
};

export type Location<T = SubLocation[]> = {
  id: string | null;
  storageTypeId: string | null;
  name: string;
  address: string;
  projectId?: string | null;
  nearestCrossStreets?: string | null;
  subLocations: T extends SubLocation[] ? SubLocation[] : (string | null)[];
  createdBy?: string;
  createdDate?: Date;
  modifiedDate?: Date | null;
  lastModifiedDate?: Date | null;
  lastModifiedBy?: string;
  modifiedBy?: string;
  // Relations
  project?: Project;
  storageType?: StorageType;
};

export type LocationInfo = {
  locations: Location[];
  projectId: string;
  projectTypeId: string;
};
export type Material = {
  key?: number;
  locationId?: string;
  id: string | null;
  name: string;
  material?: string; //for bulkUploader
  costCode: string;
  quantity: number;
  unitOfMeasure: string;
  unitOfMeasurement?: string; //for bulkUploader
  unitRate: number;
  totalBudget: number;
  projectId?: string;
  subLocationId?: string;
  subLocationName?: string;
  samples?: number;
  cost?: number;
  totalSamples?: number;
  totalSpares?: number;
  totalRegular?: number;
  description?: string;
  balanceQuantity?: number;
  remainingBudget?: number;
  previouslyBilled?: number;
  totalQuantity?: number;
  isRefillable?: boolean;
  initialCost?: number;
  previousQuantity?: number;
  previousBudget?: number;
};

export type BidMaterialDetails = {
  isMaterialReceiptInspectionFormRequired: boolean;
  assumedSubmittalReview: number;
  assumedSubmittalReviewPeriod: number;
  subTotal: number;
};

//Inventory
// export type InventoryMaterial = {
//   quantity: number | undefined;
// };
export type InventoryMaterial = {
  name: string;
  costCode: string;
  quantity: number;
  isRefillable: boolean;
  subLocationId: string | null;
  unitOfMeasure: string;
  isNewMaterialFromBulkUpload?: boolean;
  materialId?: string;
  id?: string;
};

export type InventoryFormValues = {
  projectId: string | null;
  inventories: {
    materials: InventoryMaterial[];
    locationId: string;
  }[];
};
export type MaterialDetails = BidMaterialDetails & {
  locationsData?: Material[];
  id: string;
  materials: Material[];
  createdBy?: string;
  createdDate?: Date;
  modifiedDate?: Date;
};

export type BidMaterialRequestType = {
  projectId: string;
  changeOrderIds: string[];
  isMaterialReceiptInspectionFormRequired: boolean;
  assumedSubmittalReview: number;
  assumedSubmittalReviewPeriod: number;
  subTotal: number;
  modifiedBy?: string;
  materials: Material[];
  taxPercentage: number;
  tax: number;
  otherCosts: number;
  total: number;
  createdBy?: string;
  createdDate?: Date;
  modifiedDate?: Date;
  lastModifiedDate?: Date;
  lastModifiedBy?: string;
};

export type Product = {
  productName: string;
  costCode: string;
  projects: number;
  locations: number;
  quantity: number;
  unitOfMeasure: string;
  spares: number;
  samples: number;
  isRefillable: boolean;
  projectIds: string[];
  locationIds: string[];
};
export type ProductMaterial = {
  projectId: string;
  projectName: string;
  projectLocationId: string;
  projectLocationName: string;
  subLocationId: string;
  subLocationName: string;
  quantity: number;
  unitOfMeasure: string;
  isRefillable: boolean;
};

export type ProjectWithBidMaterials = Project & BidMaterialRequestType;

export type BidMaterialsResponse = Response & {
  project: ProjectWithBidMaterials;
  materials: Material[];
  tax?: number;
  taxPercentage?: number;
  total?: number;
  otherCosts?: number;
};

export type BidMaterials = BidMaterialDetails & {
  materials: Material[];
  createdBy?: string;
  createdDate?: Date;
  projectId: string;
};

export type AssumedSubmittal = {
  assumedSubmittalReview: number;
  assumedSubmittalReviewPeriod: number;
};

export type SubLocations = Omit<LocationsList, "subLocations">;

export type Attachment = {
  id?: string;
  fileName?: string;
  documentType?: number;
  originFileObj: string;
  url: string;
};

export type ChangeOrder = {
  id: string;
  title: string;
  changeOrderNumber: string;
  approvalDeadline: Date | dayjs.Dayjs | string;
  attachments: Attachment[];
  deleteAttachmentIds?: string[];
  projectTypeId?: string | null;
  projectId: string | null;
  project?: Project;
  userId: string | null;
  notes: string;
  materials: Material[];
  otherCosts: number;
  subTotal: number;
  status: number;
  createdBy?: string;
  createdDate?: Date;
  lastModifiedBy?: string;
  lastModifiedDate?: Date | null;
  modifiedDate?: Date | null;
  taxPercentage: number;
  tax: number;
  total: number;
};

export type VendorEmailType = {
  email: string;
};

export type Vendor = {
  id?: string;
  name: string;
  divisionIds: string[];
  divisionNames?: string[];
  contactName: string;
  cellPhone: string;
  emails: string[] | VendorEmailType[];
  phoneNumber: string;
  fax: string;
  address: string;
  city: string;
  createdBy: string; // null in the response
  state: string;
  zipCode: string;
  notes: string;
  createdDate?: Date;
  modifiedDate?: Date; // null in the response
  modifiedBy: string; // null in the response
  lastModifiedBy: string; // null in the response
  lastModifiedDate: Date;
};

export type VendorsList = {
  id: string;
  name: string;
  address: string;
};

// Redux Helper Types
export type ReduxStateType = {
  isLoading?: boolean;
  successMessage?: string;
  isSuccess?: boolean;
  reqError: string | null;
  resError: string | null;
};

export type RouteType = {
  element: JSX.Element;
  path: string;
  roles?: string[];
};

export type PaginationProperties = {
  currentPage: number;
  hasNext: boolean;
  hasPrevious: boolean;
  pageSize: number;
  totalCount: number;
  totalPages: number;
};

export type Response = {
  errors: string[];
  isSuccess: boolean;
  createdDate?: Date;
  createdBy?: string;
};
export type QualityQuestion = {
  id: string | null;
  question: string;
  createdBy?: string;
  createdDate?: Date;
  modifiedDate?: Date;
  lastModifiedBy?: string;
  lastModifiedDate?: Date;
  qualityQuestionId?: string | null;
  answer?: string;
};

export type ReorderMaterial = {
  id: string;
  name: string;
  costCode: string;
  spares: number;
  samples: number;
  sample?: number;
  regular: number;
  quantity: number;
  unitOfMeasure: string;
};

export type RorderRecipient = {
  reorderId?: string;
  invitationMessage?: string | null;
  shouldSendQuote: boolean;
  requestQuoteDocument?: Attachment[];
  deleteRequestQuoteDocumentId?: string[];
  vendorIds?: string[];
};

export type Reorder = RorderRecipient & {
  id: string;
  reorderNumber: string;
  purchaseOrderId: string | null;
  title: string;
  notes: string;
  projectId: string | null;
  projectLocationId: string | null;
  projectTypeId: string | null;
  status: number;
  materials: ReorderMaterial[];
  attachments: Attachment[];
  documents?: Attachment[];
  deleteDocumentIds?: string[];
  RecentQuoteDocument: Attachment[];
  PurchaseOrderDocument: Attachment[];
  location?: { id: string; name: string; subLocations: [] };
  project?: { id: string; name: string; projectTypeId: string };
  vendor?: [{ id: string; name: string }];
  dueDate: Date | dayjs.Dayjs;
  quoteReceivedDate?: Date;
  requestDate?: Date;
  createdDate?: Date;
  modifiedDate?: Date | null;
  lastModifiedDate?: Date | null;
  createdBy?: string;
  modifiedBy?: string;
  lastModifiedBy?: string;
};

export type MaterialReceiptInspectionMaterial = {
  id: string | null;
  name: string;
  spares: number;
  samples: number;
  regular: number;
  quantity: number;
  totalQuantity: number;
  totalSamples: number;
  totalSpares: number;
  totalRegular: number;
  unitOfMeasure: string;
};

export type MaterialReceiptInspectionMaterialPhoto = {
  materialReceiptInspectionId: string | null;
  materialImages: Attachment[];
  deleteDocumentIds?: string[];
  modifiedBy?: string;
};

export type QualityQuestionAnswers = {
  id: string | null;
  answer?: string;
  qualityQuestionId?: string | null;
  question?: string | null;
  createdBy?: string | null;
  createdDate?: Date;
  lastModifiedBy?: string | null;
  lastModifiedDate?: Date;
  modifiedBy?: string | null;
  modifiedDate?: Date;
};

export type Question = {
  projectId?: string | undefined;
  // id: string;
  qualityQuestions: QualityQuestionAnswers[];
  createdBy?: string;
  // Relations
};
export type OnlyQuestion = {
  projectId?: string | undefined;
  // id: string;
  qualityQuestions: QualityQuestion[] | null;
  createdBy?: string;
  // Relations
};

export type QualityAnswersRequestType = {
  materialReceiptInspectionId: string | null;
  answers: QualityQuestionAnswers[];
  modifiedBy?: string;
};

export type MaterialReceiptInspection = {
  id: string;
  title: string;
  projectId: string | null;
  projectLocationId: string | null;
  subLocationId: string | null;
  expectedDate: Date | dayjs.Dayjs;
  requestedDate: Date | dayjs.Dayjs;
  purchaseOrderId: string | null;
  status: number;
  materials: MaterialReceiptInspectionMaterial[];
  billOfLanding: Attachment[];
  deleteBillOfLandingId?: string;
  documents?: Attachment[];
  qualityQuestions?: QualityQuestionAnswers[];
  answers: QualityQuestionAnswers[];
  location?: { id: string; name: string };
  subLocation?: { id: string; name: string };
  project?: { id: string; name: string; projectTypeId: string };
  purchaseOrder?: { id: string; name: string; purchaseOrderNumber: string };
  deleteDocumentIds?: string[];
  createdBy?: string;
  modifiedBy?: string;
  createdDate?: Date;
  modifiedDate?: Date | null;
  lastModifiedDate?: Date | null;
  lastModifiedBy?: string;
};

export type CompanySettings = {
  name: string;
  logo: Attachment | null;
  phoneNumber: string;
  email: string;
  modifiedBy: string;
  createdBy: string;
  createdDate: Date;
  modifiedDate: Date;
  shouldDeleteLogo: boolean;

  // Address
  address: string;
  city: string;
  state: string | null;
  zip: string;
  fax: string;
};

export type PurchaseOrderSettings = {
  limitOne: string;
  limitTwoFrom: string;
  limitTwoTo: string;
  superApprovers: Pick<InternalUser, "id" | "fullName">[];
  limitOneApprovers: Pick<InternalUser, "id" | "fullName">[];
  limitTwoApprovers: Pick<InternalUser, "id" | "fullName">[];
  termsAndConditionsDocument?: Attachment[];
  termsAndConditions: string;
  createdBy: string;
  createdDate: Date;
  modifiedDate: Date;
  modifiedBy: string;
  lastModifiedDate?: Date;
  lastModifiedBy?: string;
};

export type ReorderSettings = {
  reorderLimit: number;
  modifiedBy: string;
  createdDate: Date;
  modifiedDate: Date;
};

export type AccountSettings = {
  firstName: string;
  lastName: string;
  phoneNumber: string;
  cellNumber?: string;
  email?: string;
  createdBy: string;
  createdDate: Date;
  modifiedDate: Date;
};

export type PasswordSettings = {
  oldPassword: string;
  newPassword: string;
  retypePassword: string;
};
export type InternalUsers = {
  id: string;
  fullName: string;
  firstName: string;
  lastName: string;
  userName: string;
  email: string;
  role: number | null;
  phoneNumber: string;
  status: number;
  emailNotificationsEnabled: boolean;
  textNotificationsEnabled: boolean;
  cellNumber: string;
  createdBy: string;
  createdDate: Date;
  modifiedDate: Date;
  modifiedBy: string;
};

export type DashboardNotification = {
  id: string;
  description: string;
  entityType: number;
  entityId: string;
  action: NotificationActionEnum | null;
  projectId: string;
  materials?: ReorderMaterial[];
};
export type DashboardNotificationWithCustomProps = DashboardNotification & {
  entityIconType: IconType;
};

export type DashboardProjectComparison = {
  openProjects: number;
  closedProjects: number;
  openProjectsPerc: number;
  closedProjectsPerc: number;
};

export type ProjectDashboardDetailsType = {
  id: string;
  name: string;
  startDate: string;
  completionDate: string;
  actualStartDate: string;
  actualCompletionDate: string;
  contractPrice: number | null;
  status: number;
};

export type ProjectDashboardOwnerType = {
  id: string;
  name: string;
};

export type ProjectDashboardManagersType = {
  id: string;
  name: string;
};

export type SideNotificationsType = {
  id: string;
  title: string;
  description: string;
  date: string;
  entityType: number;
};
export type SideNotificationsTypeWithCustomProps = SideNotificationsType & {
  entityIconType: IconType;
};

export type Notifications = {
  notifications: SideNotificationsType[];
  date: string;
};

export type DashboardSideNotifications = {
  weeklySideNotifications: Notifications[];
};

type DashBoradMaterials = {
  materialsReceivedPerc: number;
  materialsExpectedPerc: number;
  materialsReceived: number;
  materialsExpected: number;
};

export type DashboardType = {
  projectDetails?: ProjectDashboardDetailsType | null;
  projectOwner?: ProjectDashboardOwnerType | null;
  projectManagers?: ProjectDashboardManagersType[] | null;
  projectComparision?: DashboardProjectComparison | null;
  actionItemNotifications?: DashboardNotification[] | null;
  upcomingDeliverableNotifications?: DashboardNotification[] | null;
  waitingForNotifications?: DashboardNotification[] | null;
  sideNotifications?: SideNotificationsType[] | null;
  materials?: DashBoradMaterials;
};
export type MaterialCostAnalysisRowType = {
  costCode: string;
  budgetQuantity: number;
  budgetCost: number;
  budgetUnitRate: number;
  committedQuantity: number;
  committedCost: number;
  committedUnitRate: number;
  unitOfMeasure: string;
  quantityDifference: number;
  costDifference: number;
  unitRateDifference: number;
  isOverBudget: boolean;
};

// type

export type PurchaseOrderMaterials = {
  id: string;
  name: string;
  costCode: string;
  samples: number;
  spares: number;
  regular: number;
  quantity: number;
  newQuantity: number;
  unitOfMeasure: string;
  unitRate: number;
  cost: number;
  checked: boolean;
  maxMaterialLeadTime: number;
  maxSubmittalLeadTime: number;
  expectedDeliveryDate: Date | dayjs.Dayjs | string | null;
  expectedSubmittalDate: Date | dayjs.Dayjs | string | null;
  submittalStatus: number;
  materialStatus: number;
  isMaterialApproved: boolean;
  isUniversalChecked: boolean;
  isMaterialRejected?: boolean;
};

export type PurchaseOrder = {
  id: string;
  purchaseOrderNumber: string;
  title: string;
  purchaseOrderProject: Pick<Project, "id" | "name">;
  purchaseOrderProjectId: string;
  purchaseOrderProjectLocation: Pick<Location, "id" | "name">;
  deliveryLocationId: string;
  contactNumber: string;
  dueDate: dayjs.Dayjs | Date | string;
  total: number;
  submittalStatus: number;
  vendor: Pick<Vendor, "id" | "name">;
  vendorId?: string;
  vendorAddress: string;
  toRelease?: boolean;
  paymentTerm: number;
  maxSubmittalLeadTime: number | null;
  expectedSubmittalDate: Date | null;
  maxMaterialLeadTime: number | null;
  expectedDeliveryDate: Date | null;
  status: number;
  revisionNumber: string;
  assignedUserId: string;
  assignedUser: Pick<Vendor, "id" | "name">;
  approvalStatus?: number;
  notes: string;
  // isMaterialApproved: boolean;
  isContractorResponsibleForTax: boolean;
  termsAndConditions?: string;
  taxPercentage: number;

  purchaseOrderDeliveryLocation: {
    id: string;
    name: string;
    subLocations: Omit<SubLocation, "projectLocationId">;
  };
  // Pick<Location, "id" | "name">;
  purchaseOrderMaterials: PurchaseOrderMaterials[];
  purchaseOrderMaterials2: PurchaseOrderMaterials[];
  purchaseOrderDocuments: Attachment[] | [];
  attachments: Attachment[] | [];
  recentQuoteDocument: Attachment[];
  deliveryContacts: Pick<InternalUser, "id" | "phoneNumber">[];
  deliveryContactsIdList: string[];
  deliveryContactsNumber: string[];
  deliveryNotes: string;
  subTotal: number;
  tax: number;
  // freight: number;
  createdBy?: string;
  createdDate?: dayjs.Dayjs | Date;
  modifiedBy?: string;
  modifiedDate?: Date | null;
  lastModifiedBy?: string;
  lastModifiedDate?: Date | null;
  deleteDocumentIds?: string[];
};
export type PurchaseOrderWithApproval = PurchaseOrder & {
  signature?: string;
  company?: string;
  approvalTitle?: string;
};
export type PurchaseOrdersList = {
  id: string;
  projectId: string;
  purchaseOrderNumber: string;
  expectedDate: dayjs.Dayjs | Date;
  title: string;
  deliveryLocation: DeliveryLocation;
  vendor?: Omit<DeliveryLocation, "SubLocation">;
};

export type ApprovalDetails = {
  id?: string;
  modifiedDate?: string;
  createdBy?: string;
  createdDate?: string;
  lastModifiedBy?: string;
  lastModifiedDate?: string;
  signature: string;
  company: string;
  title: string;
  status: number;
  dateSigned: string | null;
  authorizingEntity: number;
  purchaseOrderId: string;
  userId?: string;
  modifiedBy?: string;
  approvalComments?: string;
};

export type PurchaseOrderApprovalDetail = {
  vendorApproval: ApprovalDetails;
  contractorApproval: ApprovalDetails;
};

export type PurchaseOrderApprovalVendor = {
  id: string;
  name: string;
  vendorAddress: string;
};

export type RequestWithReportOption = { isForReport?: boolean };
export type ResponseWithPagination = Response & PaginationProperties;
export interface CustomColumnType<RecordType> extends ColumnType<RecordType> {
  isVisible?: boolean; // Optional isVisible property
}

export type ValidationSchemaType = {
  [key: string]:
    | "string"
    | "number"
    | "boolean"
    | "undefined"
    | "object"
    | "function"
    | "symbol"
    | "bigint"
    | "alphanumericString";
};
export type ValidatedRowType<T> = T & { invalidKeys: string[] };
export type ValidationResponse = {
  isValid: boolean;
  invalidRows: any[];
};

export type ActionTypeState = {
  delete?: ActionTypeEnum;
  save?: ActionTypeEnum;
  saveAndNew?: ActionTypeEnum;
  saveAndClose?: ActionTypeEnum;
  saveAndRelease?: ActionTypeEnum;
  downloadPdf?: ActionTypeEnum;
  createMRI?: ActionTypeEnum;
  createInvoice?: ActionTypeEnum;
  createRevision?: ActionTypeEnum;
  rejectAll?: ActionTypeEnum;
  approve?: ActionTypeEnum;
  approveAll?: ActionTypeEnum;
  approveWithComments?: ActionTypeEnum;
  cancel?: ActionTypeEnum;
  createRO?: ActionTypeEnum;
  approvedWithExceptions?: ActionTypeEnum;
  rejected?: ActionTypeEnum;
};

export type MaterialGoingToSite = Omit<
  MaterialTransfer,
  | "createdDate"
  | "modifiedDate"
  | "modifiedBy"
  | "destinationSublocationName"
  | "destinationLocationName"
  | "originalLocationName"
  | "projectName"
>;

export type BidReportMaterial = {
  projectId: string;
  projectName: string;
  isMRIFRequired: boolean;
  submittalReviewPeriod: string;
  materials: number;
  total: number;
};

// Invoice Report Types:
export type InvoiceReportFilters = {
  costCode?: string;
  invoiceNumber?: string;
  status?: number;
  paymentTerm?: number;
  vendorId?: string;
  amountFrom?: number;
  amountTo?: number;
  invoiceDateFrom?: string;
  invoiceDateTo?: string;
  dueDateFrom?: string;
  dueDateTo?: string;
};

export type InvoiceProjectReportRow = {
  invoicedToDatePerc: number;
  projectName: string;
  remainingToBePaid: number;
  sumOfInvoicesReceived: number;
  sumOfPurchaseOrders: number;
};

export type InvoiceProjectCostCodeReportRow = {
  costCode: string;
  invoicedToDatePerc: number;
  projectName: string;
  remainingToBePaidToCostCode: number;
  sumOfInvoiceReceivedToCostCode: number;
  sumOfMoneyCommittedToCostCode: number;
};

export type InvoicePOReportRow = {
  costCodes: string;
  isAboveBudget: boolean;
  projectName: string;
  purchaseOrderId: string;
  purchaseOrderNumber: string;
  remainingToBePaid: number;
  sumOfInvoicesReceived: number;
  sumOfPurchaseOrders: number;
  vendor: string;
};
export type InvoicePOInvoiceReportRow = {
  costBilledToDate: number;
  costCode: string;
  description: string;
  invoiceNumbers: string;
  material: string;
  purchaseOrderCostPerLineItem: number;
  purchaseOrderQuantity: number;
  quantityBilledToDate: number;
  remainderOfCostToBeBilled: number;
  remainderQuantity: number;
};
