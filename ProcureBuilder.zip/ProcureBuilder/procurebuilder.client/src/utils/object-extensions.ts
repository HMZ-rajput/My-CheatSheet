export function deepCopy(obj: object) {
    return JSON.parse(JSON.stringify(obj))
}
function sortObject<T extends object>(obj: T): { [key: string]: T[keyof T] } {
    return Object.keys(obj).sort().reduce<{ [key: string]: T[keyof T] }>((result, key) => {
        result[key] = obj[key as keyof T];
        return result;
    }, {});
}
export function compareByJson(obj1: object, obj2: object) {
    return JSON.stringify(sortObject(obj1)) === JSON.stringify(sortObject(obj2))
}