import {
  BadgeTypes,
  OrderStatusIconTypes,
} from "@/src/components/common/OrderStatus";
import {
  InternalUserBadgeTypes,
  InternalUserStatusIconTypes,
} from "../components/common/InternalUserStatus";
import { InvoicesBadgeTypes } from "../components/common/InvoicesStatus";
import { MaterialReceiptInspectionBadgeTypes } from "../components/common/MaterialReceiptInceptionStatusBadge";
import { MaterialTransferBadgeTypes } from "../components/common/MaterialTransferStatus";
import { PurchaseOrderBadgeTypes } from "../components/common/PurchaseOrderStatus";
import { PurchaseOrdersSubmittalBadgeTypes } from "../components/common/PurchaseOrderSubmittalStatus";
import { ReordersBadgeTypes } from "../components/common/ReorderStatus";
import {
  FilesDocumentTypeEnum,
  InvoicesStatusEnum,
  MaterialReceiptInspectionStatusEnum,
  MaterialTransferStatusEnum,
  OrderStatusEnum,
  PaymentTermEnum,
  PurchaseOrderStatusEnum,
  PurchaseOrderSubmittalStatusEnum,
  ReorderStatusEnum,
  UserStatus,
} from "./enums";
import { Attachment } from "./types";
import dayjs from "dayjs";

export function getOrderStatus(status: number): {
  iconType: OrderStatusIconTypes;
  badgeType: BadgeTypes;
} {
  switch (status) {
    case OrderStatusEnum.APPROVED:
      return { iconType: "check-mark", badgeType: "Approved" };
    case OrderStatusEnum.REJECTED:
      return { iconType: "cancel", badgeType: "Rejected" };
    case OrderStatusEnum.ADDED_TO_BID_MATERIAL:
      return {
        iconType: "check-mark-blue",
        badgeType: "Added to Bid Material",
      };
    case OrderStatusEnum.PENDING:
    default:
      return { iconType: "clock-icon", badgeType: "Pending" };
  }
}

export function getInternalUserStatus(status: number): {
  iconType: InternalUserStatusIconTypes;
  badgeType: InternalUserBadgeTypes;
} {
  switch (status) {
    case UserStatus.Active:
      return { iconType: "check-mark", badgeType: "Active" };
    case UserStatus.InActive:
      return { iconType: "cancel", badgeType: "Removed" };
    case UserStatus.InvitePending:
      return { iconType: "clock-icon", badgeType: "Invite Pending" };
    default:
      return { iconType: "clock-icon", badgeType: "Invite Pending" };
  }
}

export function getInvoicesStatus(status: number): {
  badgeType: InvoicesBadgeTypes;
} {
  switch (status) {
    case InvoicesStatusEnum.Pending:
      return { badgeType: "Pending" };
    case InvoicesStatusEnum.PartiallyPaid:
      return { badgeType: "Partially Paid" };
    case InvoicesStatusEnum.FullyPaid:
      return { badgeType: "Fully Paid" };
    default:
      return { badgeType: "Pending" };
  }
}

export function getPurchaseOrderStatus(
  status: number
): PurchaseOrderBadgeTypes {
  switch (status) {
    case PurchaseOrderStatusEnum.PendingAdminApproval:
      return "Pending Admin Approval";
    case PurchaseOrderStatusEnum.AdminApprovedPartial:
      return "Admin Approved (Partial)";
    case PurchaseOrderStatusEnum.AdminApprovedAll:
      return "Admin Approved (All)";
    case PurchaseOrderStatusEnum.AdminSigned:
      return "Admin Signed";
    case PurchaseOrderStatusEnum.AdminRejectedAll:
      return "Admin Rejected (All)";
    case PurchaseOrderStatusEnum.VendorApprovalPending:
      return "Vendor Approval Pending";
    case PurchaseOrderStatusEnum.VendorApproved:
      return "Vendor Approved";
    case PurchaseOrderStatusEnum.VendorRejected:
      return "Vendor Rejected";
    case PurchaseOrderStatusEnum.PartiallyReceived:
      return "Partially Received";
    case PurchaseOrderStatusEnum.FullyReceived:
      return "Fully Received";
    default:
      return "Pending Admin Approval";
  }
}

export const isPOMatchingStatusDFRecipient = (status: number | undefined) => {
  return (
    status === PurchaseOrderStatusEnum?.AdminSigned ||
    status === PurchaseOrderStatusEnum?.VendorApproved ||
    PurchaseOrderStatusEnum?.VendorRejected ||
    status === PurchaseOrderStatusEnum?.PartiallyReceived ||
    status === PurchaseOrderStatusEnum?.FullyReceived ||
    // PurchaseOrderStatusEnum?.AdminApprovedAll ||
    status === PurchaseOrderStatusEnum?.AdminRejectedAll
  );
};
export const isPOMatchingStatusVendorApprove = (status: number | undefined) => {
  return status !== PurchaseOrderStatusEnum.VendorApproved;
};
export const isPOMatchingStatusDF = (status: number | undefined) => {
  return status !== PurchaseOrderStatusEnum.PendingAdminApproval;
};

export const isPOVendorDisabled = (status: number | undefined) => {
  return (
    status === PurchaseOrderStatusEnum.AdminRejectedAll ||
    status === PurchaseOrderStatusEnum.VendorApproved ||
    status === PurchaseOrderStatusEnum.PartiallyReceived ||
    status === PurchaseOrderStatusEnum.FullyReceived ||
    status === PurchaseOrderStatusEnum.AdminSigned
  );
};

export const isPOMatchingStatusVendorRecipient = (
  status: number | undefined
) => {
  return status === PurchaseOrderStatusEnum?.AdminSigned;
};

export function getMaterialTransferStatus(status: number): {
  badgeType: MaterialTransferBadgeTypes;
} {
  switch (status) {
    case MaterialTransferStatusEnum.PENDING:
      return { badgeType: "Pending" };
    case MaterialTransferStatusEnum.INPROGRESS:
      return { badgeType: "In-Progress" };
    case MaterialTransferStatusEnum.TRANSFERRED:
      return { badgeType: "Transferred" };
    case MaterialTransferStatusEnum.CANCELLED:
      return { badgeType: "Cancelled" };
    default:
      return { badgeType: "Pending" };
  }
}

export function getSubmittalStatus(
  status: number
): PurchaseOrdersSubmittalBadgeTypes {
  switch (status) {
    case PurchaseOrderSubmittalStatusEnum.Pending:
      return "Pending";
    case PurchaseOrderSubmittalStatusEnum.Recieved:
      return "Recieved";
    case PurchaseOrderSubmittalStatusEnum.UnderReview:
      return "Under Review";
    case PurchaseOrderSubmittalStatusEnum.NoExceptionsTaken:
      return "No Exceptions Taken";
    case PurchaseOrderSubmittalStatusEnum.ApprovedAsNoted:
      return "Approved As Noted";
    case PurchaseOrderSubmittalStatusEnum.ReviseAndResubmit:
      return "Revise & Resubmit";
    case PurchaseOrderSubmittalStatusEnum.Rejected:
      return "Rejected";
    default:
      return "Pending";
  }
}

export function getReorderStatus(status: number): {
  badgeType: ReordersBadgeTypes;
} {
  switch (status) {
    case ReorderStatusEnum.PendingReQuote:
      return { badgeType: "Pending Re-quote" };
    case ReorderStatusEnum.QuoteReceived:
      return { badgeType: "Quote Received" };
    case ReorderStatusEnum.PoCreated:
      return { badgeType: "P.O. Created" };
    default:
      return { badgeType: "Pending Re-quote" };
  }
}

export function getMaterialReceiptInspectionStatus(status: number): {
  badgeType: MaterialReceiptInspectionBadgeTypes;
} {
  switch (status) {
    case MaterialReceiptInspectionStatusEnum.APPROVED:
      return { badgeType: "Approved" };
    case MaterialReceiptInspectionStatusEnum.APPROVEDWITHEXCEPTIONS:
      return { badgeType: "Approved with Exceptions" };
    case MaterialReceiptInspectionStatusEnum.REJECTED:
      return { badgeType: "Rejected" };
    case MaterialReceiptInspectionStatusEnum.PENDING:
      return { badgeType: "Pending" };
    default:
      return { badgeType: "Pending" };
  }
}

export function getPurchaseOrderPaymentTerm(netTerm: number) {
  switch (netTerm) {
    case PaymentTermEnum.Net30Days:
      return "Net 30 days";
    case PaymentTermEnum.Net45Days:
      return "Net 45 days";
    case PaymentTermEnum.Net60Days:
      return "Net 60 days";
  }
}

export function capitalizeFirstLetter(value: string) {
  return value.charAt(0).toUpperCase() + value.slice(1);
}

export function filterFileDocumentsByType(
  documents: Attachment[],
  type: FilesDocumentTypeEnum
): Attachment[] {
  const mapped =
    documents
      ?.filter((doc) => doc?.documentType === type)
      ?.map((doc) => ({
        ...doc,
        uid: doc?.id,
        name: doc?.fileName,
      })) || [];
  return mapped;
}

export function convertEmptyStringsToNull<T extends Record<string, any>>(
  obj: T
): T {
  return Object.fromEntries(
    Object.entries(obj).map(([key, value]) => [
      key,
      value === "" ? null : value,
    ])
  ) as T;
}

type FormSubmissionHandler = (
  validateForm: () => Promise<Record<string, any>>,
  submitForm: () => Promise<void>,
  handleSubmit: () => void,
  isSubmitting: boolean,
  callback?: () => void
) => Promise<void>;

export const handleCustomSaveAndClose: FormSubmissionHandler = async (
  validateForm,
  submitForm,
  handleSubmit,
  isSubmitting,
  callback
) => {
  const errors = await validateForm();

  if (Object.keys(errors).length === 0 && !isSubmitting) {
    try {
      await submitForm();
      if (typeof callback === "function") {
        callback();
      }
    } catch (error) {
      console.error("Form submission failed", error);
    }
  } else {
    handleSubmit();
  }
};

export const capitalizeString = (str: string): string => {
  if (!str) return "";
  return str.charAt(0).toUpperCase() + str.slice(1);
};

export function handleNumericInput(value: string | number): number {
  let numericValue = 0;
  if (typeof value === "string") {
    numericValue = parseFloat(value);
  } else if (typeof value === "number") {
    numericValue = value;
  }
  if (isNaN(numericValue) || numericValue < 0) {
    return 0;
  }
  return numericValue;
}

export const convertToLocaleString = (input: any): string | any => {
  if (typeof input === "number") {
    return input?.toLocaleString();
  }

  if (typeof input === "string") {
    const number = parseFloat(input);
    if (!isNaN(number)) {
      return number?.toLocaleString();
    }
  }

  if (input === null || input === undefined || input === "" || isNaN(input)) {
    return input;
  }

  return input;
};

export function formatDateToISO(date: Date): string {
  const isoDate = date.toISOString(); // "2024-11-26T12:08:39.769Z"
  const milliseconds = date.getMilliseconds().toString().padEnd(7, "0"); // Pad to 7 digits
  const timeZoneOffset = "+00:00";

  return `${isoDate.slice(0, -1)}${milliseconds}${timeZoneOffset}`;
}

export const formatDollarInput = (value: string): string => {
  let numericValue = value.replace(/[^0-9.]/g, "");

  // Prevent multiple decimal points
  if (numericValue.split(".").length > 2) {
    numericValue = numericValue.slice(0, numericValue.lastIndexOf("."));
  }

  return numericValue;
};

export const textSearchFormat = (value: string) => {
  return value?.toString()?.toLowerCase()?.trim();
};

export const getHtmlFromXMLPara = (paragraphs: any) => {
  let html = "";
  for (let p of paragraphs) {
    let text = "";
    const runs = p.getElementsByTagName("w:r");

    for (let r of runs) {
      let runText = r.getElementsByTagName("w:t")[0]?.textContent || "";

      // Check for bold formatting
      const bold = r.getElementsByTagName("w:b").length > 0;
      if (bold) runText = `<b>${runText}</b>`;

      // Check for italic formatting
      const italic = r.getElementsByTagName("w:i").length > 0;
      if (italic) runText = `<i>${runText}</i>`;

      text += runText;
    }

    html += `<p>${text}</p>`;
  }
  return html;
};

export const handleWeeksIncrement = (
  date: string,
  prevWeeks: number,
  newWeeks: number
) => {
  const difference = newWeeks - prevWeeks;
  return dayjs(date).add(difference, "week").format("YYYY-MM-DD");
};
