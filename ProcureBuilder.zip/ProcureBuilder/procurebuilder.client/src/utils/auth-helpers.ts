export const authService = {
  key: "USER_DATA",

  getUserData: function () {
    const stringifiedData = localStorage.getItem(this.key) || "{}";
    const parsedData = JSON.parse(stringifiedData);

    return parsedData;
  },
  //   setUserData: function (data) {
  //     localStorage.setItem(this.key, JSON.stringify(data));
  //   },
  //   getBearerToken: function () {
  //     return this.getUserData()?.data?.bearerToken || "";
  //   },
  //   getFirstName: function () {
  //     return this.getUserData()?.user?.firstName || "";
  //   },
  //   getLastName: function () {
  //     return this.getUserData()?.user?.lastName || "";
  //   },
  //   getFullName: function () {
  //     const firstName = this.getFirstName();
  //     const lastName = this.getLastName();

  //     if (!firstName && !lastName) {
  //       return "";
  //     }

  //     return `${firstName} ${lastName}`;
  //   },
  //   getUsername: function () {
  //     return this.getUserData()?.user?.username || "";
  //   },
  //   logOut: function () {
  //     this.setUserData({});
  //   },
};
