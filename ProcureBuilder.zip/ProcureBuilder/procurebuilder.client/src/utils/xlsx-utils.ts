import dayjs from "dayjs";
import ExcelJS from "exceljs";
import { store } from "../store";

const getCompanyImageFromServer = async () => {
  const backupLogoBase64 =
    "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIcAAAAxCAYAAADwdLpiAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAA+zSURBVHgB7VzNbxxJFX9VPWOPYyc7RgIh8bGTA4hbJnvguDtG2sUOSLFv3DKWuHCKLbQoiTZxORGbCA6e/AV2btziCGnjBSRPlhNaJM8ihEC7wr17YGHZxONvO57u4r366Klpz5cdf8XMk9vTXV1VXd316/d+71VVM3gBEeJaHn98AJYW4u4sdORUCYcXEA7sMv4vd4BxOoXBPgQ1RoZLNhwyicC4NwMdOZXStua4I67l6BeBkcNCuVuTdwvQkVMtbYMjAMjcnrg+RmbklqMtSIvcFtenoCOnTtoChzIjyC9CtjkjxLslm86AoRZhC2ibstCRUycNwSHEjaz+vT5MZiQE+UiIQtmeJ22BoHhDgnwAHTmV0kRzhFltRpgfNyOT4rrWFhLuS4BSCJCGjpw6qQsOAgAjbREzI1qLsAVALXJT3B0gb4XSCSioSR5SOThgmRTXCkKMdcB3DLILHNYbQY1QdM0IB/4Gpk+heRmZEPeEWwbBUULzsozAmb+tA2MHJshrLicSva9AR45casChI567vREyI6gtiHcMYFyjWKeeMgImj+cnsTsniI903vaXX2LguNfQjFDH43m/WWVUngCEWifLoWfhMMxMR45OEo1OeMCuYienyYyQthBtmgsDoAHkCgKBtXhn8oa4OfHuJByiLA1CJgneNII4UzcDgzJIVtqBYLJ/jsaCOtKO7AKHJqPsIXog6IwoM+I3KvwDf/7C+eV/5rywkh0f4gssZL5k8KhvLpghXoJ1zXAJ82iWkMPI0VaaZ/83wfP4k2s4GiDV/ywCKL82JMf7Hoed6G4bwncnaDOCnXm/UWfSm7o26M2/9u8/j/VvPs2e217BIiyLwBjG09Prg94i5aHyt8Td83jyyWGQ1foifWz7pN0Yg1lKq55mU0u5juvdjtRzZdNeglR0fVkf5BP4Bi6CelNJWFF1gqx2AL6opOYXKS8dkxZBTTSuyeqN6cPlIsw/OxcKu/U+DkZ2IBzARkWeV7JHaZqOtJBEuxlf+89Cen0osSCljELlqMT93rlggPbxbSx09SQW8Xz0VkpgArVI/jkEA/04rI+gKDGQxEXmhXgbucyvS3AEQjxjZVA+wuteUe2W7II9tz7kDUsJVzHx0c5mONOV4si1WA5P+XGOsjoIOSYTlzFvVtcDZWtGG12btFSym+fRVL+Bee2zQe0WPDg7B8V43q5ub5ry4bVH4/xo6RJkuwJvAi9c6p0LJ/dzD+oaeN5oet0e4mOscj9+vbbAQRpALv5ByPgJKaO3sb8I5fUhc4CNp4urLEgStRaRolfcoxvK38GAGQePzh8JOHST2CuWkoRSLtt0GUp82CyL5zPJlHcB7zFvzxFHkZeCDHsPPl0b5KhNWZ4QEZXV9Q3jCzChXoB6nRl6D0mTxp8dA+I/rND3uDJu07wuL2dMMyQZx99abpQMvSk8n8PSw/ISzFC72rmHpVzQT/2zOehdCSQUyNGooWdM5pLMy28OwljPXBANhzQdeKObU9oCNYBmddEtFhEYJYkNIuCsvQnZtSE+ZcAyio1Mu48BG44P0kMtklRcBD2gZThCUW+8eeiqRYyVnOaptlIH4k9e6nsoqjTcL4fA1L0RMEyalOw+7oxH+bBsF3jzLpeh+7TAMEnK/KJ5fRBxICnHVge5iNrCq+VRE7TPi1rcA6QgTe3BkfUZyqvuARhyMjag7oNMLl6Pzq8OJnK22oaa4/LHv72CSJ2WESCqUCN1+nw7HKGLIjIFeN4Cpvn09uDxhG4k5udcbYzpX2A8k6wkF1//7IPyH7/9ehEOQxgCerDKmSSZAKPFTAqq2rBYv6wsIU+5SLtRR+M9YvkxW7bCQtQQoW9KFFaHEgXkW+T2ZxIpjvlCQSeqz0FpmNmzyH3sZZTrLb0F6ihj6gQclNS5B9Ia5EBEWRgb75urzJjD4spbns8ZPFTnQBJPLNL+Ls3xzZXP4Gd/KhS/8/TvuSgRYaw2e4hvIZK6ediCMtrbPCbcJ2DQkwQvkWfJLmBdKbP1AHSdwVN9uPUCO/cV+P7qx+mff1iYoIcEBy34BpBatZsLDHpjdng40jDWQRrBCD1Q2oybbIQV42UrmxURnWXsarQfEXbMI4NxtwzVEUoYJbChYjrQUe0wYBEXsfdgQJIzDSvHOdK53wWzEWFn1ekXkeZQxKkHvYu//YYOMzVXZPXiByybPJNEdbsz2vd+Rb1Z68Nd06C0hKc1hZcw2sMjrYF/lIb7Z84CnO3PdK08Qy7yTLjk6kWFAFBjNkATZ0z/qLIdztDDalg4CHZzICKvlquE8Ch+Wr+VZCZYhoBp39bInGBn9D/eDUbVIUBudggHKVwGfjwtkaqdb+NqEUcMOa2aMwUOxWB7EvOuJ0LCiCvImFlh2lwwBQAvvzrc++DsbLm49JOvZ5Dp5VXnG3AwAwqVxjz9q8yLOd+LGnvlnFgb8pcPKjBFwOgzHtRepTcJS03r5qwMLSR9Bl4hnhKVkdCyTNtCniBrPu231T2Yzs/Vrx5fLO5Nqnl/YMBBGiMODJNZdy43b72rFXhC7XucYhnlYjKZyuHDc/J4NVojSkOAKA5i6/3aqxBurGAdXx571NKyf1eQsywz09esUXgeWMatQ2mPlC1fn1hql9KbYlyWzrwX3t+VoR4hZa1Jar17qKDmTEb1ylLf+5qT1JeqJlOcA72LYdISCpXMdLyXBJZ0eQNu3cgdunvN1gOsm9J6cqs//V7O605dqeZxN51GeVVdyW5EI264r34lNub5dvnkRi1Z0Tm4Ej+LKjrvHKq82nRZjwTSrgdgBV3OKeJEYcgK9e4d++OCe6z5GcvAPkTxpIhTsGy961H96z/0HtrAJQnX7Uc/HAHBFCC6q4AwHQsps6lOxnO4z8wxkUwv2T0hu8/kagBhCWmyRwMi4QBCHXcRe4LwkwX/+fbqQFMucIwSbAVu+D3nPjzlImMA2MkekUvp7HOQ05SX9qljtGtsYxHSt/eOGsp36sphvjF7HXKV4QUENWCknSjQ5p6z9ZOjgcZi2KZrQooagzqyqvqtOUAT4DnmweUQNeaC5yLCySyvYDX8ItJKzOw/34TwHx/6z7dWBk7ySKkinJe8EQjCeRUjwJgPagth3sS0ZWQUNzhbdQ+BQvcYubxAD5tePgx6za8NRpn1D8UgGB+1qhzLFzHY5kcaAseB8FpqZn+o8rIia8AXWkllKyxgpPYyaQ4CAY1/YTtKkqOppGipbRrj47Y92pWlDrPaIUXm4ozeUo72iEyEOe7qqTEVClxohhCWRjukFE2GRFKZqOgXgSWf/gvCv35wgMDgRedgj66hfVudwbmY9L23g+HlgOx0sVrMeCW6g8exY0W8HI3rEGga1F2seOEAAcJNVONAu/OrvAzD47attdyi9T0QyIlr2CCcshYUGKy6+sUdHlx026OY1tqPuiX/6rdqNYQhj5Y41rijDqGsu6+0BgMbHVW/QQDy808g/OIzgO11CkS1BYzb4voiT/DcO+/88tNm+VRgiSfT1JGwRyFOUNmqlNoxbWQWEqmEeqAJSPg9c1s+tCFrl5JZDHOnyePZ2djxW13L5o9fo1Fb93oPGIbIUP103KicBsePU5J/47sxcOiOVmYF4ibCNRvWZBizYQFBW2UHYOUphAgKWF8GScc6Qtm2xmgXHB05eIk4hzIXNtTtuqwRELzdQFDagWuIEW/BNLmOYfqVL9F0fO4AwsregNGR4xUTIWXKbVWdHYGAxzSDBQGPIqZyexPYxiqEy/8F2FiuAwZXOsB42aSqOYhQRiAwJoN4QoCdjSAg74LAAFsbGgjbG02AEJfDB0ajCUQvOjVRz6JPpd16aOI13lOpnbrN3NviYU2RPEzR4AgqEC7+Rf3aTQbPkTNUooxmzGIfgarDB4ZemQd1F3MjZ6Gfwi1xdxz2ITSLHn8yQrx9kSYn3UFgINPHoXg1fnOxWVmTl0a2ycsYhpdMtCtLYCh/AXL1GciNFdQQG7XAQHcMB63OU+gV9iRHY0pQ0V02u2XUeUW70bFJH6PZ8LB/8dF1U3WhLlUvCGtjCajNi0zupVyU1XImmAnuCNpfyoUDGEiZp0AKtJSj5xi08o6Wabppk+L6PAWOkFXRcLqAPYqeIP3/KU3B4QKDRM8NaAcgJ4l8yieg51NGfrz5csAULQR3P0JTLx1NA4Wt0wFsDrjLQ+NCZZHKX9XRUCjT7P2wYd5rOYw902QgPRdVLyd94K40VKaSwdUQ5CjXwM7S1IPgEJd4xKUhOOLAsNIaIMcHDFrtHyOmtAZHDZa5n4rA0dUshaiNOSo46cMqdM1kNOglo3B1iu61WO+6RDq54hZKCEA+1jPN6syRNQCk6YNgTZ9UfITlEBBpC0pqGwENgUHjIBnTFgIe8asxOALhDdKL9YBhhQCys03T/eMc5Hg1BlPLMNmis9FbnyFgxBd/H6Tgdezg22wIm+fVFwgARup91IYb4kzzSSkfbiO0hNTcwESdNcY05xbr2+ynOiVsCTgiaQSOmtHHerIbICfClNQQUvvmkvY4rE9TmY/cZGg/VAvBtOmhLyzKmKYR+rtqKi92smPO1OJ0NZDHIVXj1TDtBqsvHgi1vKNwZKPXzcyKQIBAsyl81sQkerzpigzHj5tj1COkVo3j7pgQv3gixK9m4UAlTEM08Wsrrkk/MnzHSsbuoIu8ZNzs2tqg9hnKJoNphy1NlyYYgLTUIDSz+qRGPt1vpDLgTb2s/bmcPHqT498RwfpebVRKm4r4xi42+MTFsUjLD8YRQGgxDLykcmfyRnVGuKydAyodTkC2Xu7rw3ddPhhPKKgEoy3qK7oH2lzojUDmgdz1XROs49gGHNta8UaLXRAg4K6GOoki1eenbkSznMgrcebG+iGTSovgG10ynkWa8ocQPjFxkAzsUYQQZQyw3cfyE0yvBX61UX3kgqIpoTbQd09ozTCByfcYv4LtHFMr0TBUD3AyZsUZzdHarhmAnEgNEqpYhhJ8sDJvNyeOUESVPWLjAzc1WbREOk8dxXVsQvErPOeuyDMdFahfjE+UTZ6oAyWkClXyqevT6XJyd1u7R41bTW7qPHlVCAyhz8GIE8M4doAozUGLgRktxG0hZrncp/HZS8ct+lsgN2Y1ObRCXCDEbatcj+FPiLsXHe/Bt7YeCSyCZqto84W0ZBDrtYu+byqP4foIDbzZPKQ98GegcX278uaFCudTnEiF2H0is247MdhFY0E4JrN1wAS6fVE0W38ZB4NawDJtlChDhQ/0/X7vM672I53JPscnyqyQp9Fg7uJuofUUiXB+7c3kPshbR14miQipdkXD8ytvecOMy+YdT2udEkEOjuITCjjOUamsH+mq/I5o+R8/a7/ojfh5cwAAAABJRU5ErkJggg==";
  const companyLogoUrl =
    store.getState()["company"]?.companyData?.logo?.url || "";

  if (companyLogoUrl) {
    const response = await fetch(companyLogoUrl);
    const companyLogoBlob = await response.blob();

    const base64String = await new Promise<string>((resolve, reject) => {
      const reader = new FileReader();
      reader.onloadend = () => resolve(reader?.result as string);
      reader.onerror = reject;
      reader.readAsDataURL(companyLogoBlob);
    });

    return base64String;
  }

  return backupLogoBase64;
};

async function getImageAspectRatioFromBase64(base64String: string) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = function () {
      const aspectRatio = img.width / img.height;
      resolve(aspectRatio);
    };
    img.onerror = function () {
      reject(new Error("Failed to load image from Base64"));
    };
    img.src = base64String;
  });
}
function getExtensionFromBase64(base64String: string): "jpeg" | "png" | "gif" {
  const match = base64String.match(/^data:(image\/(jpeg|png|gif));base64,/);
  if (match) {
    const extension = match[2];
    return extension as "jpeg" | "png" | "gif";
  }
  throw new Error("Invalid Base64 image string or unsupported format");
}

export const exportToExcel = async <T>(
  data: T,
  title: string,
  fileName: string
) => {
  const totalCols =
    Array.isArray(data) && data.length > 0 ? Object.keys(data[0]).length : 1;

  const leftCount = Math.floor(totalCols / 3);
  const rightCount = Math.floor(totalCols / 3);
  const middleCount = totalCols - leftCount - rightCount;

  const workbook = new ExcelJS.Workbook();
  const worksheet = workbook.addWorksheet("Sheet1");

  const headerRow = new Array(totalCols).fill(null);
  const middleStart = leftCount;
  const rightStart = leftCount + middleCount;
  headerRow[middleStart] = title;
  headerRow[rightStart] = dayjs().format("MM/DD/YYYY");
  worksheet.addRow(headerRow);

  if (leftCount > 0) {
    worksheet.mergeCells(1, 1, 1, leftCount);
  }
  if (middleCount > 0) {
    worksheet.mergeCells(1, leftCount + 1, 1, leftCount + middleCount);
  }
  if (rightCount > 0) {
    worksheet.mergeCells(1, leftCount + middleCount + 1, 1, totalCols);
  }

  const base64 = await getCompanyImageFromServer();

  const aspectRatio = ((await getImageAspectRatioFromBase64(base64)) ||
    0) as number;
  const splittedBase64 = base64?.split(",")?.[1];
  const extension = getExtensionFromBase64(base64);

  if (splittedBase64 && leftCount > 0) {
    const imageId = workbook.addImage({
      base64: splittedBase64,
      extension,
    });

    const fixedWidth = 120;
    const calculatedHeight = fixedWidth / aspectRatio;
    worksheet.addImage(imageId, {
      tl: {
        col: 0,
        row: 0,
      },
      ext: {
        width: fixedWidth,
        height: calculatedHeight,
      },
    });

    worksheet.getRow(1).height = calculatedHeight * 0.75;

    const columnWidths = new Array(totalCols).fill(10);

    if (Array.isArray(data) && data.length > 0) {
      const dataHeader = Object.keys(data[0]);

      dataHeader.forEach((header, index) => {
        const headerLength = header.length;
        columnWidths[index] = Math.max(columnWidths[index], headerLength + 2);
      });

      worksheet.addRow(dataHeader);

      data.forEach((row) => {
        const values = Object.values(row);
        worksheet.addRow(values);

        values.forEach((value, index) => {
          const cellValue = String(value || "");
          const contentLength = cellValue.length;
          columnWidths[index] = Math.max(
            columnWidths[index],
            contentLength + 2
          );
        });
      });
    }

    columnWidths.forEach((width, index) => {
      const cappedWidth = Math.min(width, 50);
      worksheet.getColumn(index + 1).width = cappedWidth;
    });

    if (middleCount > 0) {
      const titleCell = worksheet.getCell(1, leftCount + 1);
      titleCell.font = { bold: true, name: "Calibri", size: 12 };
      titleCell.alignment = { horizontal: "center", vertical: "middle" };
      titleCell.fill = {
        type: "pattern",
        pattern: "solid",
        fgColor: { argb: "F0F0F0" },
      };
    }

    if (rightCount > 0) {
      const dateCell = worksheet.getCell(1, leftCount + middleCount + 1);
      dateCell.font = { bold: true, name: "Calibri", size: 12 };
      dateCell.alignment = { horizontal: "center", vertical: "middle" };
      dateCell.fill = {
        type: "pattern",
        pattern: "solid",
        fgColor: { argb: "F0F0F0" },
      };
    }

    if (Array.isArray(data) && data.length > 0) {
      const dataHeaderRow = 2;
      for (let c = 1; c <= totalCols; c++) {
        const cell = worksheet.getCell(dataHeaderRow, c);
        cell.font = { bold: true, name: "Calibri", size: 11 };
        cell.fill = {
          type: "pattern",
          pattern: "solid",
          fgColor: { argb: "E0E0E0" },
        };
        cell.alignment = { horizontal: "center", vertical: "middle" };
        cell.border = {
          top: { style: "thin" },
          left: { style: "thin" },
          bottom: { style: "thin" },
          right: { style: "thin" },
        };
      }
    }

    const buffer = await workbook.xlsx.writeBuffer();

    const blob = new Blob([buffer], { type: "application/octet-stream" });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = `${fileName}-${Date.now()}.xlsx`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }
};
