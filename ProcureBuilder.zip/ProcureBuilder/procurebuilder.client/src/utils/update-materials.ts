type Material = {
  id: string;
  name: string;
  unitOfMeasure: string;
  quantity: number;
  samples: number;
  spares: number;
  regular: number;
};

type SubLocation = {
  subLocationId: string;
  subLocationName: string;
  materials: Material[];
};

type LocationData = SubLocation[];

export const updateMaterials: (
  existingArray: any[],
  newData: any[]
) => LocationData = (existingArray, newData) => {
  newData.forEach((newItem) => {
    // Find the sub-location by ID in the existing array
    const subLocationIndex = existingArray?.findIndex(
      (subLoc) => subLoc?.subLocationId === newItem?.subLocationId
    );

    if (subLocationIndex > -1) {
      // Sublocation found, now find the material by name
      const materialIndex = existingArray[
        subLocationIndex
      ]?.materials?.findIndex(
        (material: any) => material.name === newItem.name
      );

      if (materialIndex > -1) {
        // Replace the existing material with the new one
        existingArray[subLocationIndex].materials[materialIndex] = {
          id: newItem?.id,
          name: newItem?.name,
          unitOfMeasure: newItem?.unitOfMeasure,
          quantity: newItem?.quantity,
          samples: newItem?.samples,
          spares: newItem?.spares,
          regular: newItem?.regular,
        };
      } else {
        // If material not found, add the new material to the sub-location
        existingArray[subLocationIndex].materials?.push({
          id: newItem?.id,
          name: newItem?.name,
          unitOfMeasure: newItem?.unitOfMeasure,
          quantity: newItem?.quantity,
          samples: newItem?.samples,
          spares: newItem?.spares,
          regular: newItem?.regular,
        });
      }
    } else {
      // If sub-location not found, add a new sub-location with the material
      existingArray?.push({
        subLocationId: newItem?.subLocationId,
        subLocationName: newItem?.subLocationName,
        materials: [
          {
            id: newItem?.id,
            name: newItem?.name,
            unitOfMeasure: newItem?.unitOfMeasure,
            quantity: newItem?.quantity,
            samples: newItem?.samples,
            spares: newItem?.spares,
            regular: newItem?.regular,
          },
        ],
      });
    }
  });

  return existingArray;
};
