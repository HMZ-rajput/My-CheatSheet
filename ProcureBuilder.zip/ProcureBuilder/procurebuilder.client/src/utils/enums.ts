export enum ProjectStatusEnum {
  OPEN = 0,
  CLOSED = 1,
}

export enum TagTypeEnum {
  GREEN,
  ORANGE,
}

export enum MaterialReviewPeriod {
  DAYS = 0,
  WEEKS = 1,
  MONTH = 2,
  YEARS = 3,
}

export enum OrderStatusEnum {
  PENDING = 0,
  APPROVED = 1,
  REJECTED = 2,
  ADDED_TO_BID_MATERIAL = 3,
}

export enum UserStatus {
  Active = 0,
  InvitePending = 1,
  InActive = 2,
}

export enum UserRoleEnum {
  Fieldcraft = 0,
  Engineer = 1,
  Superintendent = 2,
  Admin = 3,
  // SuperAdmin = 4,
}

export enum InvoicesStatusEnum {
  Pending = 0,
  PartiallyPaid = 1,
  FullyPaid = 2,
}

export enum BudgetStatusEnum {
  WithinBudget = 0,
  OverBudget = 1,
}

export enum PurchaseOrderStatusEnum {
  PendingAdminApproval = 0,
  AdminApprovedPartial = 1,
  AdminApprovedAll = 2,
  AdminRejectedAll = 3,
  VendorApprovalPending = 4,
  VendorApproved = 5,
  VendorRejected = 6,
  PartiallyReceived = 7,
  FullyReceived = 8,
  AdminSigned = 9,
}

export enum PurchaseOrderSubmittalStatusEnum {
  Pending = 0,
  Recieved = 1,
  UnderReview = 2,
  NoExceptionsTaken = 3,
  ApprovedAsNoted = 4,
  ReviseAndResubmit = 5,
  Rejected = 6,
}

export enum PurchaseOrderMaterialStatusEnum {
  Pending = 0,
  PartiallyReceived = 1,
  FullyReceived = 2,
}

export enum PurchaseOrderMaterialTypeEnum {
  Regular = 0,
  Sample = 1,
  Spare = 2,
}

export enum PaymentTermEnum {
  Net30Days = 0,
  Net45Days = 1,
  Net60Days = 2,
}

export enum ChangeOrderStatusEnum {
  Pending = 0,
  Approved = 1,
  Rejected = 2,
  AddedToBidMaterial = 3,
}

export enum ReorderStatusEnum {
  PendingReQuote = 0,
  QuoteReceived = 1,
  PoCreated = 2,
}

export enum MaterialReceiptInspectionStatusEnum {
  PENDING = 0,
  APPROVED = 2,
  APPROVEDWITHEXCEPTIONS = 1,
  REJECTED = 3,
}

export enum MaterialGoingToSiteStatusEnum {
  PENDING = 0,
  INPROGRESS = 1,
  TRANSFERRED = 2,
  CANCELLED = 3,
}

export enum MaterialTransferStatusEnum {
  PENDING = 0,
  INPROGRESS = 1,
  TRANSFERRED = 2,
  CANCELLED = 3,
}

export enum FilesDocumentTypeEnum {
  OTHER = 0,
  PURCHASEORDER = 1,
  VENDORINVOICE = 2,
  INVOICEATTACHMENTS = 3,
  PURCHASEORDERATTACHMENTS = 4,
  RECENTQUOTE = 5,
  CHANGEORDERATTACHMENTS = 6,
  COMPANYIMAGE = 7,
  MATERIALIMAGE = 8,
  QUOTEREQUEST = 9,
  REORDERATTACHMENTS = 10,
  REQUESTQUOTE = 11,
  BILLOFLANDING = 12,
}

export enum ActionTypeEnum {
  DELETE = -1,
  NEUTRAL = 0,
  SAVE = 1,
  SAVE_AND_CLOSE = 2,
  SAVE_AND_NEW = 3,
  SAVE_AND_RELEASE = 4,
  DOWNLOAD_PDF = 5,
  CREATE_MRI = 6,
  CREATE_INVOICE = 7,
  CREATE_REVISION = 8,
  REJECT_ALL = 9,
  APPROVE = 10,
  APPROVE_ALL = 11,
  CANCEL = 12,
  CREATE_RO = 13,
  APPROVEDWITHEXCEPTIONS = 14,
  APPROVE_WITH_COMMENTS = 15,
  REJECTED = 15,
}

export enum ProjectComparisonTypeEnum {
  LASTMONTH = 0,
  LASTSIXMONTHS = 1,
  LASTYEAR = 2,
  ALLTIME = 3,
}

export enum ProductSortingFilterEnum {
  QuantityHighToLow = 0,
  QuantityLowToHigh = 1,
  NameAscending = 2,
  NameDescending = 3,
}

export enum AuthorizingEntityEnum {
  Contractor = 0,
  Vendor = 1,
}

export enum ApprovalStatusEnum {
  Approved = 0,
  Rejected = 1,
}

export enum EntityTypeEnum {
  PurchaseOrder = 1,
  Reorder = 2,
  MaterialTransfer = 3,
  MaterialToSite = 4,
  Invoice = 5,
  ChangeOrder = 6,
  MaterialReceiptInspection = 7,
  Project = 8,
}

export enum NotificationActionEnum {
  PurchaseOrderApproval = 0,
  ChangeOrderApproval = 1,
  MaterialTransferApproval = 2,
  MaterialToSiteApproval = 3,
  CreateReorder = 4,
  ExpectingMaterials = 5,
  VendorApproval = 6,
}

export enum NotificationSectionTypeEnum {
  ACTION_ITEMS = "actionItemNotifications",
  UPCOMING_ITEMS = "upcomingDeliverableNotifications",
  WAITING_FOR_ITEMS = "waitingForNotifications",
}
export enum PoReportTypeEnum {
  PurchaseOrder = 0,
  PurchaseOrderVendor = 1,
  PurchaseOrderApproval = 2,
}
