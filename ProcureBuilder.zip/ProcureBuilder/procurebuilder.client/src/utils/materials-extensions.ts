export const staticEmptyMaterialField = {
    id: null,
    name: "",
    costCode: "",
    quantity: 1,
    unitOfMeasure: "",
    unitRate: 0,
    totalBudget: 0,
}