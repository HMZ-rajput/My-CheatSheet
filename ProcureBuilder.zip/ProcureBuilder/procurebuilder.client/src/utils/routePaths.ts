export const routePathsWithParams = {
  // Dashboard Routes
  HOME: "/",

  // Auth Routes
  LOGIN: "/login",
  FORGOTPASSWORD: "/forgot-password",
  VERIFY_OTP: "/verify-otp",
  RESET_PASSWORD: "/reset-password",
  UNAUTHORIZED: "/unauthorized",

  // Projects Routes
  PROJECTS: "/projects",
  PROJECTS_DETAILS_BY_ID: "/projects/:projectId",
  PROJECTS_NEW: "/projects/new",
  PROJECTS_EDIT_BY_ID: "/projects/edit/:projectId",

  //Customer Routes
  CUSTOMERS_EDIT_BY_ID: "/customers/edit/:customerId",
  CUSTOMERS: "/customers",
  CUSTOMERS_NEW: "/customers/new",
  // Location Routes
  LOCATIONS: "/locations/:name?",
  LOCATIONSWITHOUTNAME: "/locations",
  LOCATION_NEW: "/locations/new",
  LOCATIONS_EDIT_BY_ID: "/locations/edit/:projectId",

  //CHANGE ORDER Routes
  CHANGE_ORDERS: "/change-orders",
  CHANGE_ORDERS_NEW: "/change-orders/new",
  CHANGE_ORDERS_NEW_BY_PROJECT: "/change-orders/new/project/:projectId",
  CHANGE_ORDER_EDIT_BY_ID: "/change-orders/edit/:projectId/:changeOrderId",

  //Vendor Routes
  VENDORS: "/vendors",
  VENDORS_NEW: "/vendors/new",
  VENDORS_EDIT_BY_ID: "/vendors/edit/:vendorCompanyId",
  //Company Settings
  COMPANY_SETTINGS: "/company/settings",

  //Account Settings
  ACCOUNT_SETTINGS: "/account/settings",

  //Products Routes
  PRODUCTS: "/products",
  PRODUCTS_DETAILS: "/products/:name",
  PRODUCTS_CREATE: "/products/new",
  PRODUCTS_EDIT_BY_ID: "/products/:name/:projectId",

  //Internal Users Routes
  INTERNAL_USERS_EDIT_BY_ID: "/internal-users/edit/:internalUserId",
  INTERNAL_USERS: "/internal-users",
  INTERNAL_USERS_NEW: "/internal-users/new",

  // Reorders Routes
  REORDERS: "/reorders",
  REORDERS_NEW: "/reorders/new",
  REORDERS_EDIT_BY_ID: "/reorders/edit/:projectId/:reorderId",

  //Purchase Orders Routes
  PURCHASE_ORDERS: "/purchase-orders",
  PURCHASE_ORDERS_NEW: "/purchase-orders/new",
  PURCHASE_ORDERS_EDIT_BY_ID: "/purchase-orders/edit/:purchaseOrderId",
  PURCHASE_ORDERS_VENDOR_APPROVE:
    "/purchase-orders/vendor-approve/:purchaseOrderId",

  //Invoices
  INVOICES: "/invoices",
  INVOICES_EDIT_BY_ID: "/invoices/edit/:invoiceId",
  INVOICES_NEW: "/invoices/new",

  //Material Transfer
  MATERIAL_TRANSFER: "/material-transfer",
  MATERIAL_TRANSFER_EDIT_BY_ID: "/material-transfer/edit/:materialTransferId",
  MATERIAL_TRANSFER_NEW: "/material-transfer/new",

  //Material Going To Sites
  MATERIAL_GOING_TO_SITES: "/material-going-to-sites",
  MATERIAL_GOING_TO_SITES_EDIT_BY_ID:
    "/material-going-to-sites/edit/:materialGoingToSitesId",
  MATERIAL_GOING_TO_SITES_NEW: "/material-going-to-sites/new",

  //Material Receipt Inspections Routes
  MATERIAL_RECEIPT_INSPECTION: "/material-receipt-inspection",
  MATERIAL_RECEIPT_INSPECTION_NEW: "/material-receipt-inspection/new",
  MATERIAL_RECEIPT_INSPECTION_EDIT_BY_ID:
    "/material-receipt-inspection/edit/:projectId/:materialReceiptInspectionId/",

  // REPORTS
  REPORTS: "/reports",
  PROJECTS_REPORT: "/reports/projects",
  BID_MATERIALS_REPORT: "/reports/bid-materials",
  CHANGE_ORDERS_REPORT: "/reports/change-orders",
  PROJECT_BUDGET_VS_COMMITTED_COSTS_REPORT:
    "/reports/project-budget-vs-committed-costs",
  PURCHASE_ORDERS_REPORT: "/reports/purchase-orders",
  REORDERS_REPORT: "/reports/reorders",
  INVOICES_REPORT: "/reports/invoices",
  INVENTORY_REPORT: "/reports/inventory",
  MATERIAL_TRANSFER_REPORT: "/reports/material-transfer",
  MATERIAL_GOING_TO_SITE_REPORT: "/reports/material-going-to-site",
  MATERIAL_INSPECTION_REPORT: "/reports/material-inspection",

  // MISC
  NOT_FOUND: "/not-found",
};

function getRoutePathsWithoutParams() {
  // Make a copy of routePaths
  const routePathsCopy = { ...routePathsWithParams };

  // Loop through each key in the copied object
  for (const key in routePathsCopy) {
    // Check if the key exists in the object
    if (Object.prototype.hasOwnProperty.call(routePathsCopy, key)) {
      // Remove parameters from the route path
      let pathWithoutParams =
        routePathsCopy[key as keyof typeof routePathsCopy].split(":")[0];

      // If the last character is a slash, remove it
      if (pathWithoutParams.endsWith("/")) {
        pathWithoutParams = pathWithoutParams.slice(0, -1);
      }

      // Update the route path in the copied object
      routePathsCopy[key as keyof typeof routePathsCopy] = pathWithoutParams;
    }
  }

  // Return the modified copy
  return routePathsCopy;
}

const routePaths = getRoutePathsWithoutParams();

export default routePaths;
