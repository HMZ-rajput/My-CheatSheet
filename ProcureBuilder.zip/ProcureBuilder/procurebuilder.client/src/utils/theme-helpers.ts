import theme from "@theme/index";

const SPACING_CONSTANT = 8;

export const getConsistentSpacing = (
  spacingNumber: number,
  spacingNumber2?: number,
  spacingNumber3?: number,
  spacingNumber4?: number
) => {
  let calculated = "";

  spacingNumber *= SPACING_CONSTANT;

  if (!spacingNumber2) {
    calculated = `${spacingNumber}px`;
  } else if (!spacingNumber3) {
    spacingNumber2 *= SPACING_CONSTANT;
    calculated = `${spacingNumber}px ${spacingNumber2}px`;
  } else if (!spacingNumber4) {
    spacingNumber2 *= SPACING_CONSTANT;
    spacingNumber3 *= SPACING_CONSTANT;
    calculated = `${spacingNumber}px ${spacingNumber2}px ${spacingNumber3}px`;
  } else {
    spacingNumber2 *= SPACING_CONSTANT;
    spacingNumber3 *= SPACING_CONSTANT;
    spacingNumber4 *= SPACING_CONSTANT;
    calculated = `${spacingNumber}px ${spacingNumber2}px ${spacingNumber3}px ${spacingNumber4}px`;
  }

  return calculated;
};

export const getRandomColor = () => {
  const token = theme.token;

  const colors = [
    token?.green8 || "",
    token?.pink3 || "",
    token?.purple8 || "",
    token?.yellow5 || "",
    token?.cyan3 || "",
  ];

  return colors[Math.floor(Math.random() * colors.length)];
};
