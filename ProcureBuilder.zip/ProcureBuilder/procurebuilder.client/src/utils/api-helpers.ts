import axios, { AxiosError, ResponseType } from "axios";
import { getBearerToken } from "@utils/user-helpers";
import routePaths from "./routePaths";
import { AppSetting } from "@/src/AppSetting";

export const manuallyDownloadBlob = (blob: Blob, name: string) => {
  const link = document.createElement("a");
  link.href = URL.createObjectURL(blob);
  link.download = name;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};

export const getServerUrl = () => {
  return AppSetting.apiUrl;
};

export function getUrlParams(urlParams: {
  [key: string]: string | number | boolean | null;
}) {
  const params = new URLSearchParams();

  Object.entries(urlParams)
    .filter(([_, value]) => value !== null && value !== undefined)
    .forEach(([key, value]) => {
      if (typeof value === "number" || typeof value === "boolean") {
        value = value?.toString() || "";
      }

      params.append(key, value || "");
    });

  return params;
}

type CallParams = {
  payload?: object;
  url: string;
  method?: "GET" | "POST" | "PUT" | "DELETE";
  isFormData?: boolean;
  responseType?: ResponseType;
};

export const call = async <ResponseType>({
  payload,
  url,
  method = "POST",
  isFormData,
  responseType = "json",
}: CallParams) => {
  const token = getBearerToken();
  const URL = `${getServerUrl()}/api/${url}`;

  const headers = {
    Authorization: token ? `Bearer ${token}` : undefined,
    "Cache-Control": "no-cache",
  };
  const formDataHeaders = {
    ...headers,
    "Content-Type": "multipart/form-data",
  };

  let response = { data: null };

  try {
    switch (method) {
      default: {
        response = await axios.post(URL, payload, {
          headers: isFormData ? formDataHeaders : headers,
          responseType,
        });
        break;
      }

      case "GET": {
        response = await axios.get(URL, { headers, responseType });
        break;
      }

      case "PUT": {
        response = await axios.put(URL, payload, {
          headers: isFormData ? formDataHeaders : headers,
        });
        break;
      }

      case "DELETE": {
        response = await axios.delete(URL, {
          headers,
          data: payload,
        });
        break;
      }
    }
    return response.data as ResponseType;
  } catch (error: unknown) {
    if (axios.isCancel(error)) {
      console.log("Request cancelled:", error.message);
      throw error;
    }

    if (error instanceof AxiosError) {
      if (error.response?.status === 401) {
        localStorage.clear();
        window.location.href = routePaths.UNAUTHORIZED;
      }

      const errorMessage = error.response?.data?.message ?? error.message;
      throw new Error(errorMessage);
    }

    throw new Error("An unexpected error occurred");
  }
};

export const serializeArrayQueryParam = (key: string, arr: any[]) =>
  Array.isArray(arr) && arr.length > 0
    ? arr
        .map((val) => `${encodeURIComponent(key)}=${encodeURIComponent(val)}`)
        .join("&")
    : null;
