import { FormikErrors, FormikTouched } from "formik";

export type FormikFieldValue = string | boolean | number | object[];
export type FormikLibraryHelperType<T> = {
  values: T;
  touched: FormikTouched<T>;
  errors: FormikErrors<T>;
  setFieldValue: (
    field: string,
    value: FormikFieldValue,
    shouldValidate?: boolean
  ) => Promise<void> | Promise<FormikErrors<T>>;
};
