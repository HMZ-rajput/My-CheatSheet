export function formatDecimals(decimal: number) {
  if (typeof decimal !== "number") {
    decimal = 0;
  }

  return parseFloat(decimal.toFixed(5));
}
export function formatDecimalsOnlyTwo(decimal: number) {
  if (typeof decimal !== "number") {
    decimal = 0;
  }

  return parseFloat(decimal.toFixed(2));
}
export const getFirstValidNumber = (
  maybe: number | string | null | undefined,
  fallback?: number
): number | undefined => {
  const num = typeof maybe === "string" ? +maybe : maybe;
  return Number.isFinite(num as number) ? (num as number) : fallback;
};
