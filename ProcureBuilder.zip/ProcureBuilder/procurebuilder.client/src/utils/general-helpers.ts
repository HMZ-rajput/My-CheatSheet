import { projectStatusOptionsWithAll } from "./constants";
import { ProjectStatusEnum } from "./enums";

export function getFullNameInitials(fullName: string) {
  if (!fullName || typeof fullName !== "string") return "";

  const names = fullName.split(" ");

  const firstNameInitial = names[0].charAt(0);
  const lastNameInitial = names[names.length - 1].charAt(0);

  return firstNameInitial + lastNameInitial;
}

export function getStatusLabelByEnumValue(enumVal: ProjectStatusEnum) {
  const statusLabel =
    projectStatusOptionsWithAll.find((f) => f.value === enumVal)?.label || "";

  return statusLabel;
}

export function getProjectName() {
  return document.body.getAttribute("data-draft-project-name") || "";
}
export function setProjectName(name: string) {
  document.body.setAttribute("data-draft-project-name", name);
}
