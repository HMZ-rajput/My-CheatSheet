import { ThemeConfig } from "antd"
import { AliasToken } from "antd/es/theme/internal"

const token: Partial<AliasToken> = {
  colorPrimary: "#F44803",
  colorPrimaryHover: "#FF672B",
  colorPrimaryActive: "#FF672B",

  colorTextBase: "#000000E0",
  colorBorder: "#E2E4E9",
  colorBgBase: "#FFFFFF",
  colorWhite: "#FFFFFF",

  colorNeutral1: "#F6F8FA",
  colorNeutral5: "#E2E4E9",
  colorNeutral6: "#CDD0D5",
  colorNeutral7: "#868C98",
  colorNeutral8: "#313B4F",
  colorNeutral9: "#111827",

  // Green
  green1: "#E7F7EF",
  green5: "#0CAF60",
  green8: "#228B22",

  // Orange
  orange1: "#FEF3EB",
  orange5: "#F17B2C",

  pink3: "#F7C3FF",
  purple8: "#7851A9",
  yellow5: "#FFD700",
  cyan3: "#9CD8E5",

  fontFamily: "Inter",
}

const theme: ThemeConfig = {
  token,
  components: {
    Button: {
      colorLink: token.colorTextBase,
      colorLinkHover: token.colorTextBase,
      colorLinkActive: token.colorTextBase,
    },
    Layout: {
      bodyBg: token.colorBgBase,
    },
    Input: {
      colorBorder: token.colorNeutral5,
    },
  },
}

export default theme
