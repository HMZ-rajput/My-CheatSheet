export function getLowerCasedMaterialName(material: any) {
  let name = (material?.name || material?.material) as string;

  if (typeof name !== "string") return "";

  name = name?.toLowerCase();

  return name;
}
