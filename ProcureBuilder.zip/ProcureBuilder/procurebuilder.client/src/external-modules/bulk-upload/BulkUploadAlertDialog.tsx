import CustomModal from "@/src/components/common/CustomModal";
import { useAppDispatch } from "@/src/hooks/useAppDispatch";
import { useAppSelector } from "@/src/hooks/useAppSelector";
import {
  getDialogState,
  resetDialogState,
} from "@/src/store/slices/dialogStateSlice";
import { List } from "antd";

export default function BulkUploadAlertDialog() {
  const dispatch = useAppDispatch();
  const { data, isDialogOpen, title } = useAppSelector(getDialogState);

  return (
    <CustomModal
      width={1200}
      title={title}
      isOpen={isDialogOpen}
      isPrimaryButtonHidden
      cancelButtonAction={() => dispatch(resetDialogState())}
      cancelButtonText="Close"
    >
      <div className="my-8">
        <p className="font-medium mb-4 text-lg">{data?.message || ""}</p>
        {Boolean(data?.lines?.length) && (
          <List
            style={{
              maxHeight: 294,
              overflow: "auto",
            }}
          >
            {data?.lines?.map((m, i) => (
              <List.Item key={i} className="!text-error text-sm">
                {m}
              </List.Item>
            ))}
          </List>
        )}
      </div>
    </CustomModal>
  );
}
