import { store } from "@/src/store";
import { updateDialogState } from "@/src/store/slices/dialogStateSlice";
import { numberRegex } from "@/src/utils/constants";
import { toCamelCase, toCapitalizedCase } from "@/src/utils/string-extensions";
import { SubLocation, ValidationSchemaType } from "@/src/utils/types";
import * as XLSX from "xlsx";
import { getLowerCasedMaterialName } from "./bulk-upload-utils";
import { formatDecimals } from "@/src/utils/number-extensions";
import { getDateFromOADate } from "@/src/utils/date-helpers";

class BulkUploaderParser<T> {
  private convertXlsxToCsvString(data: Uint8Array): string {
    const workBook: XLSX.WorkBook = XLSX.read(data, { type: "array" });
    const workSheetName: string = workBook.SheetNames[0];
    const workSheet: XLSX.WorkSheet = workBook.Sheets[workSheetName];
    const jsonArray: any[] = XLSX.utils.sheet_to_json(workSheet, {
      defval: "",
      blankrows: false,
    });
    const filteredArray = jsonArray
      ?.filter(
        (row) => Object.values(row).some((cell) => cell !== "") // Keep rows with at least one non-empty cell
      )
      ?.map((m) => {
        const obj = { ...m };
        const keys = Object.keys(obj);

        keys.forEach((e) => {
          // Remove properties that start with __EMPTY
          if (e.startsWith("__EMPTY")) {
            delete obj[e];
            return;
          }

          const value = obj[e];
          const isDate = e?.toLowerCase()?.includes("date");

          if (isDate && typeof value === "number") {
            obj[e] = getDateFromOADate(value);
          }
        });

        return obj;
      });
    const csvString: string = XLSX.utils.sheet_to_csv(
      XLSX.utils.json_to_sheet(filteredArray)
    );
    return csvString;
  }

  private parseCsv(
    csvString: string,
    alphanumericKeys?: string[]
  ): Record<string, string>[] {
    const lines: string[] = csvString.split("\n");

    const headers: string[] = lines[0]
      .split(",")
      .map((header) => header?.trim()?.toLowerCase() || "")
      .map(toCamelCase);

    const numberOfColumns: number = headers.length;
    const rows: Record<string, string>[] = new Array(lines.length - 1);

    for (let i = 1; i < lines.length; i++) {
      const values: string[] = lines[i]
        .split(",", numberOfColumns)
        .map((value) => value?.trim());
      const rowObject: Record<string, any> = {};

      try {
        for (let j = 0; j < numberOfColumns; j++) {
          const key = headers[j];
          let currentValue: string | boolean | number | null = null;

          if (values[j]?.toString()?.toLowerCase() === "true") {
            currentValue = true;
          } else if (values[j]?.toString()?.toLowerCase() === "false") {
            currentValue = false;
          } else if (numberRegex.test(values[j])) {
            if (alphanumericKeys?.includes(key)) {
              currentValue = values[j] as string;
            } else {
              currentValue = parseFloat(values[j] as string);
            }
          } else if (values[j]?.toString()?.toLowerCase() === "null") {
            currentValue = null;
          } else {
            currentValue = values[j];
          }

          rowObject[key] = currentValue;
        }
      } catch (e) {
        console.log("BulkUploaderParser.parseCsv: Crashed while parsing!", e);
      }

      rows[i - 1] = rowObject;
    }
    return rows;
  }
  private async readFileContentAsync(file: File): Promise<string> {
    return new Promise((resolve, reject) => {
      if (!file) {
        reject(new Error("No file selected"));
        return;
      }
      const fileReader: FileReader = new FileReader();

      fileReader.readAsText(file);

      fileReader.onload = () => {
        const fileContent: string = ((fileReader.result as string) || "")
          ?.trim()
          ?.replace(/"/g, "");
        resolve(fileContent);
      };

      fileReader.onerror = () => reject(fileReader.error);
    });
  }

  public async readAndParseAsync(file: File, alphanumericKeys?: string[]) {
    const fileName = file?.name || "";
    if (!fileName) {
      console.error(
        "BulkUploaderParser.readAndParseCsvAsync: fileName doesn't exist."
      );
      return [];
    }
    const fileExtension = (fileName?.split(".")?.[1] || "")?.toLowerCase();
    if (!fileExtension) {
      console.error(
        "BulkUploaderParser.readAndParseCsvAsync: fileExtension doesn't exist."
      );
      return [];
    }

    let fileContent: string;
    if (fileExtension === "xlsx") {
      const uint8File = new Uint8Array(await file.arrayBuffer());
      fileContent = this.convertXlsxToCsvString(uint8File);
    } else {
      fileContent = await this.readFileContentAsync(file);
    }

    const mappedRows = this.parseCsv(fileContent, alphanumericKeys) as T;

    return mappedRows;
  }
  public async validateMaterials<X extends { [key: string]: any }>({
    rows,
    schema,
    stringToBooleanKeys,
    sublocations,
    requiredKeys,
  }: {
    rows: X;
    schema: ValidationSchemaType;
    sublocations?: Omit<SubLocation, "projectLocationId">[];
    requiredKeys?: string[];
    stringToBooleanKeys?: string[];
  }) {
    if (!Array.isArray(rows)) {
      console.error(`validateMaterials: "rows" must be an array.`);
      return false;
    }

    // DUPLICATE NAME VALIDATION
    const materialNames = rows.map((m) => m?.name?.toLowerCase() || "");
    const nameToIndexes = new Map<string, number>();
    const duplicateNameIndexes: number[] = [];
    materialNames.forEach((name, index) => {
      if (!name) return; // Skip undefined or null names

      if (nameToIndexes.has(name)) {
        // If this name has been seen before, push both its first occurrence (if not already added)
        const firstIndex = nameToIndexes.get(name);
        if (
          firstIndex !== undefined &&
          !duplicateNameIndexes.includes(firstIndex)
        ) {
          duplicateNameIndexes.push(firstIndex); // Add the first occurrence
        }
        duplicateNameIndexes.push(index); // Add the current occurrence
      } else {
        // If it's the first time the name is encountered, store its index
        nameToIndexes.set(name, index);
      }
    });
    if (duplicateNameIndexes.length) {
      const invalidRows =
        rows
          .map((m, i) => ({ ...m, originalIndex: i }))
          .filter((_, i) => duplicateNameIndexes.includes(i)) || [];

      const errors = invalidRows.map(
        (e) =>
          `Row #${(e?.originalIndex || 0) + 1}: ${toCapitalizedCase(
            e.name
          )} is duplicate.`
      );

      store.dispatch(
        updateDialogState({
          isDialogOpen: true,
          title: "Alert: An issue occured while uploading the CSV file",
          data: {
            message: `Total ${
              invalidRows?.length || 0
            } rows have duplicate file names`,
            lines: errors,
          },
        })
      );

      return false;
    }

    // INVALID TYPE VALIDATION
    const invalidRows = rows
      .map((row: X, index) => {
        const keys = Object.keys(row);
        const invalidKeys = keys.filter((key) => {
          let isInvalid = typeof row[key] !== schema[key];

          const isStringOrNumber =
            typeof row[key] === "number" || typeof row[key] === "string";

          if (schema[key] === "alphanumericString" && isStringOrNumber) {
            isInvalid = false;
          }

          return isInvalid;
        });
        if (invalidKeys?.length) {
          return { keys: invalidKeys, originalIndex: index };
        } else {
          return { keys: [], originalIndex: index };
        }
      })
      .filter((f) => (f?.keys.length || 0) > 0);
    if (invalidRows?.length) {
      const errors = invalidRows.map(
        (e) =>
          `Row #${e.originalIndex + 1}: ${(e.keys || [])
            ?.map(toCapitalizedCase)
            .join(", ")}.`
      );

      store.dispatch(
        updateDialogState({
          isDialogOpen: true,
          title: "Alert: An issue occured while uploading the CSV file",
          data: {
            message: `Total ${invalidRows?.length} rows have issues in the columns mentioned below:`,
            lines: errors,
          },
        })
      );
    }

    let hasAnyValidationIssue = false;
    // INVALID SUBLOCATION VALIDATION
    if (sublocations?.length && rows?.some((s) => s.sublocation)) {
      const invalidRows = rows
        .map((row, index) => ({ row, originalIndex: index }))
        .filter(
          ({ row }) =>
            row?.sublocation &&
            !sublocations.find(
              (s) => s.name === row?.sublocation?.toLowerCase()
            )
        );

      if (invalidRows?.length) {
        const errors = invalidRows.map(
          (e) =>
            `Row #${
              e.originalIndex + 1
            }: The provided sublocation does not exist.`
        );

        store.dispatch(
          updateDialogState({
            isDialogOpen: true,
            title: "Alert: An issue occured while uploading the CSV file",
            data: {
              message: `Total ${invalidRows?.length} rows have issues in the columns mentioned below:`,
              lines: errors,
            },
          })
        );

        hasAnyValidationIssue = errors?.length > 0;
      }
    }

    // NON EMPTY KEYS VALIDATION
    if (requiredKeys?.length) {
      const emptyRows = rows
        .map((row: X, index) => {
          const emptyKeys = requiredKeys?.filter((key) => !row[key]) || [];
          return emptyKeys.length
            ? { keys: emptyKeys, originalIndex: index }
            : null;
        })
        .filter(Boolean);
      if (emptyRows.length) {
        const errors = emptyRows.map(
          (e) =>
            `Row #${
              (e?.originalIndex || 0) + 1
            }: The following fields must not be empty: ${e?.keys
              ?.map(toCapitalizedCase)
              .join(", ")}.`
        );

        store.dispatch(
          updateDialogState({
            isDialogOpen: true,
            title: "Alert: An issue occurred while uploading the CSV file",
            data: {
              message: `Total ${emptyRows.length} rows have empty fields that are required.`,
              lines: errors,
            },
          })
        );

        hasAnyValidationIssue = errors?.length > 0;
      }
    }

    // STRING TO BOOLEAN VALIDATION
    if (stringToBooleanKeys?.length) {
      const invalidRows = rows
        .map((row, index) => {
          const invalidKeys = stringToBooleanKeys.filter((key) => {
            const value = `${row[key]}`?.toLowerCase() || "";

            return (
              typeof value === "string" &&
              value !== "true" &&
              value !== "false" &&
              value !== "yes" &&
              value !== "no"
            );
          });
          return invalidKeys.length
            ? { keys: invalidKeys, originalIndex: index }
            : null;
        })
        .filter(Boolean);
      if (invalidRows.length) {
        const errors = invalidRows.map(
          (e) =>
            `Row #${
              (e?.originalIndex || 0) + 1
            }: The following fields must be yes or no: ${e?.keys
              ?.map(toCapitalizedCase)
              .join(", ")}.`
        );

        store.dispatch(
          updateDialogState({
            isDialogOpen: true,
            title: "Alert: An issue occurred while uploading the CSV file",
            data: {
              message: `Total ${invalidRows.length} rows have issues in the columns mentioned below:`,
              lines: errors,
            },
          })
        );

        hasAnyValidationIssue = errors?.length > 0;
      }
    }

    if (hasAnyValidationIssue) {
      return false;
    } else {
      return invalidRows?.length === 0;
    }
  }
  public mergeMaterials({
    oldMaterials = [],
    newMaterials = [],
    keysToBeUpdated = [],
  }: {
    oldMaterials: any[];
    newMaterials: any[];
    keysToBeUpdated: string[];
  }) {
    if (!Array.isArray(oldMaterials) || !Array.isArray(newMaterials)) {
      return oldMaterials;
    }
    let oldMaterialNames = oldMaterials.map((m) =>
      getLowerCasedMaterialName(m)
    );
    let alreadyExistingMaterialsObj: { [key: string]: any } = {};
    let newlyAddedMaterialsObj: { [key: string]: any } = {};
    newMaterials.forEach((material) => {
      const name = getLowerCasedMaterialName(material);
      if (!name) return;

      if (oldMaterialNames?.includes(name)) {
        alreadyExistingMaterialsObj[name] = material;
      } else {
        newlyAddedMaterialsObj[name] = material;
      }
    });

    let materials = [...oldMaterials];
    materials = materials.map((material) => {
      if (Object.keys(material || {})?.length === 0) return;

      const name = getLowerCasedMaterialName(material);
      if (!name) return material;

      const updatedMaterial = alreadyExistingMaterialsObj?.[name] || null;
      if (updatedMaterial === null) material;

      // Old Quantity
      let oldQuantity = 0;
      if (typeof material?.quantity === "number") {
        oldQuantity = material.quantity;
      }

      // New Quantity
      let newQuantity = 0;
      if (typeof updatedMaterial?.quantity === "number") {
        newQuantity = updatedMaterial.quantity;
      }

      // Sum of Quantity Calculation
      const quantitySum = formatDecimals(oldQuantity + newQuantity);
      material.quantity = quantitySum;

      // Old Quantity
      let oldUnitRate = 0;
      if (typeof material?.unitRate === "number") {
        oldUnitRate = material.unitRate;
      }

      // New Quantity
      let newUnitRate = 0;
      if (typeof updatedMaterial?.unitRate === "number") {
        newUnitRate = updatedMaterial.unitRate;
      }

      // Merged Unit Rate Calculation
      const oldBudget = oldUnitRate * oldQuantity;
      const newBudget = newUnitRate * newQuantity;
      const budgetSum = oldBudget + newBudget;
      const mergedUnitRate = formatDecimals(budgetSum / quantitySum);
      material.unitRate = isNaN(mergedUnitRate) ? 0 : mergedUnitRate;

      if (keysToBeUpdated.includes("totalBudget")) {
        material.totalBudget = formatDecimals(mergedUnitRate * quantitySum);
      }

      return material;
    });

    const newlyAddedMaterialValues = Object.values(newlyAddedMaterialsObj);
    if (newlyAddedMaterialValues?.length > 0) {
      newlyAddedMaterialValues.forEach((e) => {
        materials.push(e);
      });
    }

    return materials;
  }
}

export default BulkUploaderParser;
