import CustomIcon from "@/src/components/common/CustomIcon";
import { Button } from "antd";
import { SizeType } from "antd/es/config-provider/SizeContext";
import { ChangeEvent, useEffect, useRef, useState } from "react";

type BulkUploaderProps = {
  disabled?: boolean;
  btnClassName?: string;
  btnSize?: SizeType;
  shouldReset: number;
  updateMaterialsCallback: (file: File) => void;
};

function BulkUploadButton({
  disabled = false,
  btnClassName = "",
  btnSize = "large",
  shouldReset = 0,
  updateMaterialsCallback,
}: BulkUploaderProps) {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [file, setFile] = useState<File | null>(null);

  function handleButtonClick() {
    const input = fileInputRef.current || null;

    if (input) {
      input.click();
    }
  }
  function handleInputChange(event: ChangeEvent<HTMLInputElement>) {
    const newFile = event?.target?.files?.[0] || null;

    console.log("f", file);

    if (newFile) {
      setFile(() => newFile);
    }
  }

  useEffect(() => {
    if (!file) return;

    updateMaterialsCallback(file);
  }, [file]);

  useEffect(() => {
    setFile(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  }, [shouldReset]);

  return (
    <>
      <input
        accept=".csv,.xlsx"
        type="file"
        ref={fileInputRef}
        style={{ display: "none" }}
        onChange={handleInputChange}
        disabled={disabled}
      />
      <Button
        className={`hover:fill-primaryHover disabled:fill-neutral-7 ${btnClassName}`}
        size={btnSize}
        disabled={disabled}
        icon={<CustomIcon type="cloud-upload" />}
        onClick={handleButtonClick}
      >
        Bulk Upload
      </Button>
    </>
  );
}

export default BulkUploadButton;
