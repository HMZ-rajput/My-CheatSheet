export const AppSetting = {
  //apiUrl: "https://qa-procurebuilder.naveedportfolio.com",
  apiUrl: "https://localhost:7001",
};
