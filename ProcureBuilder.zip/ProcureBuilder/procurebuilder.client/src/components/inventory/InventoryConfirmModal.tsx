// import CustomModal from "../common/CustomModal";

// export default function InventoryConfirmModal() {
//   return (
//     <div>
//       <CustomModal />
//     </div>
//   );
// }
