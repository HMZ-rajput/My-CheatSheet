import { useAppDispatch } from "@/src/hooks/useAppDispatch";
import useAuthorization from "@/src/hooks/useAuthorization";
import { resetUser } from "@/src/store/slices/userSlice";
import { modulesConstant } from "@/src/utils/constants";
import routePaths from "@/src/utils/routePaths";
import { DownOutlined, UserOutlined } from "@ant-design/icons";
import { Avatar, Button, Dropdown, Flex, Layout, List, Space } from "antd";
import { useState } from "react";
import { Link } from "react-router-dom";
import CustomIcon from "../../common/CustomIcon";
import ControlPanel from "./RightSidebar";

export default function Navbar() {
  const [isRightSidebarOpen, setIsRightSidebarOpen] = useState(false);

  const dispatch = useAppDispatch();
  const { isCominedAdminAuthorized, isFieldsCraftAuthorized } =
    useAuthorization();
  function getIsLinkActive(link: string) {
    return location.pathname === link;
  }
  const navLinks = [
    {
      title: "Home",
      link: routePaths.HOME,
    },
    {
      title: "Log In Material",
      link: routePaths.MATERIAL_RECEIPT_INSPECTION_NEW,
    },
    {
      title: "Log Out Material",
      link: "",
      items: [
        {
          key: "01",
          link: routePaths.MATERIAL_TRANSFER_NEW,
          label: (
            <Link
              to={routePaths.MATERIAL_TRANSFER_NEW}
              className={`p-0 m-0 ${
                getIsLinkActive(routePaths.MATERIAL_TRANSFER_NEW)
                  ? "!text-primary"
                  : ""
              }`}
            >
              Move Locations
            </Link>
          ),
        },
        {
          key: "02",
          link: routePaths.MATERIAL_GOING_TO_SITES_NEW,
          label: (
            <Link
              to={routePaths.MATERIAL_GOING_TO_SITES_NEW}
              className={`p-0 m-0 ${
                getIsLinkActive(routePaths.MATERIAL_GOING_TO_SITES_NEW)
                  ? "!text-primary"
                  : ""
              }`}
            >
              Move to Site
            </Link>
          ),
        },
      ],
    },
    ...(!isFieldsCraftAuthorized()
      ? [
          {
            title: "Projects",
            link: routePaths.PROJECTS_NEW,
          },
        ]
      : []),
    ...(!isFieldsCraftAuthorized()
      ? [{ title: "Locations", link: routePaths.LOCATION_NEW }]
      : []),

    { title: "Products", link: routePaths.PRODUCTS_CREATE },

    {
      title: "PO",
      link: "",
      items: [
        {
          key: "01",
          link: routePaths.PURCHASE_ORDERS_NEW,
          label: (
            <Link
              to={routePaths.PURCHASE_ORDERS_NEW}
              className={`p-0 m-0 ${
                getIsLinkActive(routePaths.PURCHASE_ORDERS_NEW)
                  ? "!text-primary"
                  : ""
              }`}
            >
              P.O. Entry
            </Link>
          ),
        },
        {
          key: "02",
          link: routePaths.REORDERS_NEW,
          label: (
            <Link
              to={routePaths.REORDERS_NEW}
              className={`p-0 m-0 ${
                getIsLinkActive(routePaths.REORDERS_NEW) ? "!text-primary" : ""
              }`}
            >
              Reorder Entry
            </Link>
          ),
        },
      ],
    },
    ...(!isFieldsCraftAuthorized()
      ? [{ title: "Vendor", link: routePaths.VENDORS_NEW }]
      : []),
    {
      title: "COR",
      link: routePaths.CHANGE_ORDERS_NEW,
    },
    { title: "Reports", link: routePaths.REPORTS },
  ];

  return (
    <>
      <Layout.Header
        className="flex justify-between items-center top-0 left-[15vw] fixed w-[calc(100%-15vw)] bg-bgBase z-50 h-[72px] border-b border-border !px-6"
        style={{ zIndex: 100 }}
      >
        <Flex>
          {navLinks.map((m, i) => {
            const isHomeLink =
              (m?.title || "")?.toLowerCase() === "home" &&
              getIsLinkActive("/");
            const hasChildren = Array.isArray(m?.items) && m?.items?.length > 0;
            const isAnyChildActive = hasChildren
              ? m?.items?.some((s) => getIsLinkActive(s?.link))
              : false;
            const isActiveLink =
              isHomeLink || isAnyChildActive || getIsLinkActive(m.link);

            return (
              <List.Item
                key={i}
                className="!p-0 list-none mr-2 lg:mr-3 xl:mr-5"
              >
                {hasChildren ? (
                  <>
                    <Dropdown
                      menu={{ items: m.items }}
                      placement="bottomLeft"
                      key={m.link}
                    >
                      <Button
                        type="text"
                        className={`p-2.5 rounded-lg font-medium !text-sm leading-5 transition-all duration-[250ms] lg:!text-base hover:!text-primary ${
                          isActiveLink && "text-primary"
                        }`}
                      >
                        {m.title}
                        <DownOutlined />
                      </Button>
                    </Dropdown>
                  </>
                ) : (
                  <>
                    <Link to={m.link} className={`p-0 m-0`} key={m.link}>
                      <Button
                        type="text"
                        className={`p-2.5 rounded-lg !text-sm font-medium leading-5 transition-all duration-[250ms] lg:!text-base hover:!text-primary ${
                          isActiveLink && "text-primary"
                        }`}
                      >
                        {m.title}
                      </Button>
                    </Link>
                  </>
                )}
              </List.Item>
            );
          })}
        </Flex>

        <Flex align="center" className="gap-4">
          {/* Internal Users and Customer Contacts */}
          <Dropdown
            placement="bottom"
            menu={{
              items: [
                ...(isCominedAdminAuthorized()
                  ? [
                      {
                        key: "01",
                        label: (
                          <Link
                            to={routePaths.INTERNAL_USERS_NEW}
                            className={`p-0 m-0`}
                          >
                            {modulesConstant.INTERNAL_USERS}
                          </Link>
                        ),
                      },
                    ]
                  : []),
                {
                  key: "02",
                  label: (
                    <Link to={routePaths.CUSTOMERS_NEW} className={`p-0 m-0`}>
                      {modulesConstant.CUSTOMER_CONTACTS}
                    </Link>
                  ),
                },
              ],
            }}
          >
            <Button className="p-0 rounded-full border-0 w-8 hover:fill-primary">
              <CustomIcon type="contacts" width={24} height={24} />
            </Button>
          </Dropdown>

          {/* Avatar */}
          <Dropdown
            placement="bottomRight"
            menu={{
              items: [
                {
                  key: "01",
                  label: (
                    <Link
                      to={routePaths.ACCOUNT_SETTINGS}
                      className={`p-0 m-0 flex items-center gap-2`}
                    >
                      <CustomIcon type="accounts" />
                      {modulesConstant.ACCOUNT_SETTINGS}
                    </Link>
                  ),
                },
                ...(isCominedAdminAuthorized()
                  ? [
                      {
                        key: "02",
                        label: (
                          <Link
                            to={routePaths.COMPANY_SETTINGS}
                            className={`p-0 m-0 flex items-center gap-2`}
                          >
                            <CustomIcon type="company-settings" />
                            {modulesConstant.COMPANY_SETTINGS}
                          </Link>
                        ),
                      },
                    ]
                  : []),

                {
                  key: "03",
                  label: (
                    <span
                      className={`p-0 m-0 flex items-center gap-2`}
                      onClick={() => {
                        // localStorage.clear();
                        dispatch(resetUser());
                        // localStorage.setItem("USER_DATA", "");
                        // setTimeout(() => {
                        //   location.reload();
                        // }, 100);
                      }}
                    >
                      <CustomIcon type="log-out" />
                      {modulesConstant.LOGOUT}
                    </span>
                  ),
                },
              ],
            }}
          >
            <Space>
              <Avatar rootClassName="w-12 h-12" className="cursor-pointer">
                <UserOutlined className="text-2xl mt-1" />
              </Avatar>
              <Button size="small" className="p-1 rounded-full">
                <DownOutlined />
              </Button>
            </Space>
          </Dropdown>

          {/* Customer Contacts */}
          <Button
            size="large"
            className="px-1 rounded-full border-0 hover:fill-primary"
            onClick={() => setIsRightSidebarOpen(() => true)}
          >
            <CustomIcon type="more-grid" width={32} height={32} />
          </Button>
        </Flex>
      </Layout.Header>

      <ControlPanel open={isRightSidebarOpen} toggle={setIsRightSidebarOpen} />
    </>
  );
}
