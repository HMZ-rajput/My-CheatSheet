import { Button, Divider, Drawer, Flex, Input } from "antd";
import CustomIcon from "../../common/CustomIcon";
import { Fragment, useState } from "react";
import routePaths from "@/src/utils/routePaths";
import { useLocation, useNavigate } from "react-router-dom";
import HighlightedText from "../../common/HighlightedText";
import useAuthorization from "@/src/hooks/useAuthorization";
import { modulesConstant } from "@/src/utils/constants";

export type ControlPanelIconTypes =
  | "cp-change-orders"
  | "cp-customers"
  | "cp-internal-users"
  | "cp-invoices"
  | "cp-locations"
  | "cp-material-going-to-site"
  | "cp-material-receipt-inspection"
  | "cp-material-transfer"
  | "cp-products"
  | "cp-projects"
  | "cp-purchase-orders"
  | "cp-reorders"
  | "cp-vendors";

type ControlPanelProps = {
  open: boolean;
  toggle: React.Dispatch<React.SetStateAction<boolean>>;
};

export default function ControlPanel(props: ControlPanelProps) {
  const { open, toggle } = props;
  const navigate = useNavigate();
  const location = useLocation();
  const [searchTerm, setSearchTerm] = useState("");
  const { isCominedAdminAuthorized } = useAuthorization();
  const sections = [
    {
      name: "Project Management",
      links: [
        {
          icon: <CustomIcon className="fill-inherit" type="cp-projects" />,
          name: modulesConstant.PROJECTS,
          path: routePaths.PROJECTS,
        },
        {
          icon: <CustomIcon className="fill-inherit" type="cp-locations" />,
          name: modulesConstant.LOCATIONS,
          path: routePaths.LOCATIONS,
        },
        {
          icon: <CustomIcon className="fill-inherit" type="cp-products" />,
          name: modulesConstant.PRODUCTS,
          path: routePaths.PRODUCTS,
        },
      ],
    },
    {
      name: "Orders",
      links: [
        {
          icon: (
            <CustomIcon className="fill-inherit" type="cp-purchase-orders" />
          ),
          name: modulesConstant.PURCHASE_ORDERS,
          path: routePaths.PURCHASE_ORDERS,
        },
        {
          icon: <CustomIcon className="fill-inherit" type="cp-reorders" />,
          name: modulesConstant.REORDERS,
          path: routePaths.REORDERS,
        },
        {
          icon: <CustomIcon className="fill-inherit" type="cp-change-orders" />,
          name: modulesConstant.CHANGE_ORDERS,
          path: routePaths.CHANGE_ORDERS,
        },
        ...(isCominedAdminAuthorized()
          ? [
              {
                icon: (
                  <CustomIcon className="fill-inherit" type="cp-invoices" />
                ),
                name: modulesConstant.INVOICES,
                path: routePaths.INVOICES,
              },
            ]
          : []),
      ],
    },
    {
      name: modulesConstant.LOGIN_MATERIAL,
      links: [
        {
          icon: (
            <CustomIcon
              className="fill-inherit"
              type="cp-material-receipt-inspection"
            />
          ),
          name: modulesConstant.MATERIAL_RECEIPT_INSPECTION,
          path: routePaths.MATERIAL_RECEIPT_INSPECTION,
        },
      ],
    },
    {
      name: modulesConstant.LOGOUT_MATERIAL,
      links: [
        {
          icon: (
            <CustomIcon className="fill-inherit" type="cp-material-transfer" />
          ),
          name: modulesConstant.MATERIAL_TRANSFER,
          path: routePaths.MATERIAL_TRANSFER,
        },
        {
          icon: (
            <CustomIcon
              className="fill-inherit"
              type="cp-material-going-to-site"
            />
          ),
          name: modulesConstant.MATERIAL_GOING_TO_SITES,
          path: routePaths.MATERIAL_GOING_TO_SITES,
        },
      ],
    },
    {
      name: modulesConstant.CONTACTS,
      links: [
        ...(isCominedAdminAuthorized()
          ? [
              {
                icon: (
                  <CustomIcon
                    className="fill-inherit"
                    type="cp-internal-users"
                  />
                ),
                name: modulesConstant.INTERNAL_USERS,
                path: routePaths.INTERNAL_USERS,
              },
            ]
          : []),
        {
          icon: <CustomIcon className="fill-inherit" type="cp-vendors" />,
          name: modulesConstant.VENDORS,
          path: routePaths.VENDORS,
        },
        {
          icon: <CustomIcon className="fill-inherit" type="cp-customers" />,
          name: modulesConstant.CUSTOMERS,
          path: routePaths.CUSTOMERS,
        },
      ],
    },
  ]?.filter((f) => {
    const lowerCasedSearchTerm = (searchTerm || "").toLowerCase()?.trim() || "";
    const lowerCasedSectionName = (f.name || "").toLowerCase()?.trim() || "";
    const lowerCasedLinkNames =
      (
        f?.links?.map((link) => (link?.name || "")?.toLowerCase())?.join(",") ||
        ""
      )?.trim() || "";

    if (!searchTerm) {
      return f;
    }

    console.log(lowerCasedLinkNames, lowerCasedSearchTerm);

    if (
      lowerCasedSearchTerm.includes(lowerCasedSectionName) ||
      lowerCasedSectionName.includes(lowerCasedSearchTerm)
    ) {
      return f;
    } else if (
      lowerCasedSearchTerm.includes(lowerCasedLinkNames) ||
      lowerCasedLinkNames.includes(lowerCasedSearchTerm)
    ) {
      return f;
    } else {
      return null;
    }
  });

  function closeDrawer() {
    toggle(() => false);
  }

  return (
    <>
      <Drawer
        title={
          <h4 className="text-lg font-medium">Management Control Panel</h4>
        }
        open={open}
        onClose={closeDrawer}
        styles={{ wrapper: { width: 388 } }}
      >
        <Flex className="gap-8 flex-col">
          <Input
            value={searchTerm}
            onChange={(event) => setSearchTerm(event?.target?.value || "")}
            prefix={<CustomIcon type="search" />}
            placeholder="Search.."
            size="large"
          />

          <Flex className="gap-4 flex-col">
            {sections.map((section, index) => (
              <Fragment key={section.name}>
                <Flex className="flex-col">
                  <h5 className="p-1 text-xs font-medium text-neutral-7 spacing tracking-[1.5px] uppercase mb-1.5">
                    <HighlightedText
                      text={section.name}
                      searchTerm={searchTerm}
                    />
                  </h5>

                  <Flex className="gap-1 flex-col">
                    {section.links.map((link, index) => {
                      const isActive =
                        link?.path === location?.pathname || false;

                      return (
                        <Button
                          key={`${link?.path}-${index}`}
                          type="text"
                          className={`px-3 py-2 justify-start hover:!text-primary hover:!fill-primary ${
                            isActive && "fill-primary"
                          }`}
                          onClick={() => {
                            navigate(link.path);
                            closeDrawer();
                          }}
                        >
                          <span className="fill-inherit">{link.icon}</span>
                          <span
                            className={`text-sm font-medium ${
                              isActive && "text-primary"
                            }`}
                          >
                            <HighlightedText
                              text={link.name}
                              searchTerm={searchTerm}
                              styles={{
                                color: "inherit",
                              }}
                            />
                          </span>
                        </Button>
                      );
                    })}
                  </Flex>
                </Flex>

                {sections.length - 1 !== index ? (
                  <Divider className="my-0" />
                ) : null}
              </Fragment>
            ))}
          </Flex>
        </Flex>
      </Drawer>
    </>
  );
}
