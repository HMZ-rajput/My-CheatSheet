import {
  getAllCompanyDetails,
  getAllPurchaseOrderDetails,
  getAllReorderDetails,
} from "@/src/apis/companySettingsApis";
import { getAllCustomers } from "@/src/apis/customerApis";
import { getAllInternalUsers } from "@/src/apis/internalUsersApis";
import { getAllLocations } from "@/src/apis/locationApis";
import { getAllProducts } from "@/src/apis/productApis";
import {
  getAllProjects,
  getSummarizedProjectsList,
} from "@/src/apis/projectApis";
import { getAllProjectManagers } from "@/src/apis/projectManagersApis";
// import { getAllProjectTypes } from "@/src/apis/projectTypeApis";
// import { getAllStorageTypes } from "@/src/apis/storageTypeApis";
import BulkUploadAlertDialog from "@/src/external-modules/bulk-upload/BulkUploadAlertDialog";
import { useAppDispatch } from "@/src/hooks/useAppDispatch";
import { useAppSelector } from "@/src/hooks/useAppSelector";
import { getCompanyState } from "@/src/store/slices/companySettingsSlice";
import { getCustomersState } from "@/src/store/slices/customersSlice";
import { getInternalUsersState } from "@/src/store/slices/internalUsersSlice";
import { getLocationsState } from "@/src/store/slices/locationSlice";
import { getProductState } from "@/src/store/slices/productsSlice";
import { getProjectManagersState } from "@/src/store/slices/projectManagersSlice";
import { getProjectsState } from "@/src/store/slices/projectsSlice";
// import { getStorageTypesState } from "@/src/store/slices/storageTypeSlice";
// import { getTypesState } from "@/src/store/slices/typesSlice";
import { getUserState } from "@/src/store/slices/userSlice";
import routePaths from "@/src/utils/routePaths";
import { Layout } from "antd";
import React, { useEffect } from "react";
import { useLocation } from "react-router-dom";
import Navbar from "./navbar/Navbar";
import Sidebar from "./Sidebar";

const { Content } = Layout;

type LayoutProps = {
  children: React.ReactNode;
};

export default function LayoutContainer(props: LayoutProps) {
  const {
    projectsData,
    currentPage: projectsCurrentPage,
    pageSize: projectsPageSize,
    projectsSummarizedData,
  } = useAppSelector(getProjectsState);
  const {
    customersData,
    currentPage: customersCurrentPage,
    pageSize: customersPageSize,
  } = useAppSelector(getCustomersState);
  const {
    locationsData,
    currentPage: locationsCurrentPage,
    pageSize: locationsPageSize,
  } = useAppSelector(getLocationsState);

  //Products
  const {
    productsData,
    currentPage: productsCurrentPage,
    pageSize: productsPageSize,
  } = useAppSelector(getProductState);

  const { data: userData } = useAppSelector(getUserState);
  const { managersData } = useAppSelector(getProjectManagersState);
  // const { typesData } = useAppSelector(getTypesState);
  // const { storageTypesData } = useAppSelector(getStorageTypesState);
  const { companyData } = useAppSelector(getCompanyState);
  const {
    internalUsersData,
    currentPage: internalUsersCurrentPage,
    pageSize: internalUsersPageSize,
  } = useAppSelector(getInternalUsersState);

  const dispatch = useAppDispatch();
  const location = useLocation();
  const isVendorApprovePage = function () {
    return location?.pathname?.includes(
      routePaths.PURCHASE_ORDERS_VENDOR_APPROVE
    );
  };

  function showNavAndSidebar() {
    const restrictedFor = [
      "/login",
      "/forgot-password",
      "/verify-otp",
      "/reset-password",
      routePaths.UNAUTHORIZED,
      routePaths.PURCHASE_ORDERS_VENDOR_APPROVE,
      routePaths.NOT_FOUND,
    ];

    return !isVendorApprovePage() && !restrictedFor.includes(location.pathname);
  }

  useEffect(() => {
    if (isVendorApprovePage()) return;
    if (!userData?.isAuthenticated) return;

    if (projectsData == null && location.pathname !== routePaths.PROJECTS) {
      dispatch(
        getAllProjects({
          pageNumber: projectsCurrentPage,
          pageSize: projectsPageSize,
        })
      );
    }
  }, [
    dispatch,
    projectsData,
    userData,
    projectsCurrentPage,
    projectsPageSize,
    location.pathname,
  ]);

  useEffect(() => {
    if (isVendorApprovePage()) return;
    if (!userData?.isAuthenticated) return;

    if (productsData == null && location.pathname !== routePaths.PRODUCTS) {
      dispatch(
        getAllProducts({
          pageNumber: productsCurrentPage,
          pageSize: productsPageSize,
        })
      );
    }
  }, [
    dispatch,
    productsData,
    userData,
    productsCurrentPage,
    productsPageSize,
    location.pathname,
  ]);

  useEffect(() => {
    if (isVendorApprovePage()) return;
    if (!userData?.isAuthenticated) return;

    if (customersData == null && location.pathname !== routePaths.CUSTOMERS) {
      dispatch(
        getAllCustomers({
          pageNumber: customersCurrentPage,
          pageSize: customersPageSize,
        })
      );
    }
  }, [
    dispatch,
    customersData,
    userData,
    customersCurrentPage,
    customersPageSize,
    location.pathname,
  ]);

  useEffect(() => {
    if (isVendorApprovePage()) return;
    if (!userData?.isAuthenticated) return;

    if (locationsData == null && location.pathname !== routePaths.LOCATIONS) {
      dispatch(
        getAllLocations({
          pageNumber: locationsCurrentPage,
          pageSize: locationsPageSize,
        })
      );
    }
  }, [
    dispatch,
    locationsData,
    userData,
    locationsCurrentPage,
    locationsPageSize,
    location.pathname,
  ]);

  useEffect(() => {
    if (isVendorApprovePage()) return;
    if (!userData?.isAuthenticated) return;

    if (managersData == null) {
      dispatch(getAllProjectManagers());
    }
  }, [dispatch, managersData, userData]);

  // useEffect(() => {
  //   if (isVendorApprovePage()) return;
  //   if (!userData?.isAuthenticated) return;

  //   if (typesData == null) {
  //     dispatch(getAllProjectTypes());
  //   }
  // }, [dispatch, typesData, userData]);

  // useEffect(() => {
  //   if (isVendorApprovePage()) return;
  //   if (!userData?.isAuthenticated) return;

  //   if (storageTypesData === null) {
  //     dispatch(getAllStorageTypes());
  //   }
  // }, [dispatch, storageTypesData, userData]);

  useEffect(() => {
    if (isVendorApprovePage()) return;
    if (!userData?.isAuthenticated) return;

    if (companyData == null) {
      dispatch(getAllCompanyDetails());
      dispatch(getAllPurchaseOrderDetails());
      dispatch(getAllReorderDetails());
    }
  }, [dispatch, companyData, userData]);

  useEffect(() => {
    if (isVendorApprovePage()) return;
    if (!userData?.isAuthenticated) return;
    if(!userData?.bearerToken) return

    if (
      projectsSummarizedData == null &&
      ![routePaths.LOCATION_NEW, routePaths.LOCATIONS_EDIT_BY_ID].includes(
        location.pathname
      )
    ) {
      dispatch(getSummarizedProjectsList());
    }
  }, [dispatch, projectsSummarizedData, userData, location.pathname]);

  useEffect(() => {
    if (isVendorApprovePage()) return;
    if (!userData?.isAuthenticated) return;

    if (
      internalUsersData == null &&
      location.pathname !== routePaths.INTERNAL_USERS
    ) {
      dispatch(
        getAllInternalUsers({
          pageNumber: internalUsersCurrentPage,
          pageSize: internalUsersPageSize,
        })
      );
    }
  }, [
    dispatch,
    internalUsersData,
    userData,
    internalUsersCurrentPage,
    internalUsersPageSize,
    location.pathname,
  ]);

  //for UnAuthorized page
  // const fetchData = async () => {
  //   await call({
  //     url: "projects",
  //     method: "GET",
  //     dispatch,
  //   });
  // };

  // useEffect(() => {
  //   fetchData();
  // }, [fetchData]);

  return (
    <>
      <Layout style={{ minHeight: "100vh" }}>
        <Layout>
          {showNavAndSidebar() ? <Sidebar /> : null}
          <Layout>
            {showNavAndSidebar() ? <Navbar /> : null}
            <Content
              // pl-[15vw]
              className={` ${showNavAndSidebar() ? "mt-[72px] pb-[36px]" : ""}`}
            >
              {props.children}

              <BulkUploadAlertDialog />
            </Content>
          </Layout>
        </Layout>
      </Layout>
    </>
  );
}
