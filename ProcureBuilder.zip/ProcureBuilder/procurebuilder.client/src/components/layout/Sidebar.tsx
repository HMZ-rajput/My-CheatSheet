import SidebarImage from "@assets/images/sidebar-image.png";
import { getConsistentSpacing } from "@utils/theme-helpers";
import { Button, Flex, Image, Input, Layout, Menu, Typography } from "antd";

import { getLocationListForSideBar } from "@/src/apis/locationApis";
import { useAppDispatch } from "@/src/hooks/useAppDispatch";
import { useAppSelector } from "@/src/hooks/useAppSelector";
import useAuthorization from "@/src/hooks/useAuthorization";
import { getCompanyData } from "@/src/store/slices/companySettingsSlice";
import { getLocationsState } from "@/src/store/slices/locationSlice";
import { getProjectsState } from "@/src/store/slices/projectsSlice";
import { getUserState } from "@/src/store/slices/userSlice";
import { getProjectName } from "@/src/utils/general-helpers";
import routePaths from "@/src/utils/routePaths";
import { LocationsList, SummarizedProject } from "@/src/utils/types";
import CustomIcon from "@components/common/CustomIcon";
import useToken from "@hooks/useToken";
import type { MenuProps } from "antd";
import { useEffect, useMemo, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import HighlightedText from "../common/HighlightedText";

export default function Sidebar() {
  const location = useLocation();
  const dispatch = useAppDispatch();
  const { data: userData } = useAppSelector(getUserState);
  const [draftProjectName, setDraftProjectName] = useState("");
  const [searchTerm, setSearchTerm] = useState("");
  const [recentProjectsData, setRecentProjectsData] = useState<
    SummarizedProject[] | null
  >(null);
  const [recentLocationsData, setRecentLocationsData] = useState<
    LocationsList[] | null
  >(null);
  const company = useAppSelector(getCompanyData);
  const { isFieldsCraftAuthorized } = useAuthorization();
  const navigate = useNavigate();
  const token = useToken();

  const allProjectsKey = "all-projects";
  const allLocationsKey = "all-locations";

  type MenuItem = Required<MenuProps>["items"][number];

  const [selectedKeys, setSelectedKeys] = useState<string[]>([]);

  const { projectsSummarizedData } = useAppSelector(getProjectsState);
  const menuItemStyles: { style: React.CSSProperties } = useMemo(
    () => ({
      style: {
        margin: 0,
        width: "100%",
        borderRadius: 0,
        fontWeight: 500,
        paddingLeft: getConsistentSpacing(2),
      },
    }),
    []
  );

  const memoizedProjectsData = useMemo(() => {
    let projects = [...(recentProjectsData || [])];

    const draftProject = projects.find((f) => f.isDraft) || null;

    // Perform search using these filters:
    projects = projects?.filter(
      (f) =>
        f.id === allProjectsKey ||
        (searchTerm
          ? f.name?.toLowerCase()?.includes((searchTerm || "")?.toLowerCase())
          : true)
    );

    // Selects the top-5 results
    projects = projects.filter((f) => !f.isDraft).slice(0, 5);

    // Adds the draft project at the top of the list if it's there!
    if (draftProject) projects.unshift(draftProject);

    const data = [
      {
        id: allProjectsKey,
        name: "All Projects",
        isDraft: false,
      },
      ...(projects || []),
    ];

    const mappedData = data?.map((project) => {
      const name = project?.isDraft
        ? "(Draft) " + draftProjectName
        : project?.name;

      return {
        key: project.id,
        name,
        label: (
          <Typography.Text
            style={{ fontSize: getConsistentSpacing(1.75), color: "inherit" }}
          >
            {project?.id === allProjectsKey ? (
              name
            ) : (
              <HighlightedText searchTerm={searchTerm} text={name} />
            )}
          </Typography.Text>
        ),
        onClick: () => {
          if (project?.isDraft) return;

          navigate(
            project?.id === allProjectsKey
              ? routePaths.PROJECTS
              : `${routePaths.PROJECTS_DETAILS_BY_ID}/${project?.id}`
          );
        },
        ...menuItemStyles,
      };
    });

    return mappedData;
  }, [
    menuItemStyles,
    navigate,
    searchTerm,
    recentProjectsData,
    draftProjectName,
  ]);

  const { locationListForSideBar } = useAppSelector(getLocationsState);

  useEffect(() => {
    if (!userData?.bearerToken) return;
    dispatch(getLocationListForSideBar());
  }, [dispatch]);

  const recentLocations = recentLocationsData?.slice(0, 5);

  const memoizedLocationsData = useMemo(() => {
    const data = [
      {
        id: allLocationsKey,
        name: "All Locations",
      },
      ...(recentLocations || []),
    ];

    const mappedData = data?.map((location) => {
      const encodedProjectId = encodeURIComponent(location?.projectId || "");

      return {
        key: location.name,
        name: location.name,
        label: (
          <Typography.Text
            style={{ fontSize: getConsistentSpacing(1.75), color: "inherit" }}
          >
            {location.name}
          </Typography.Text>
        ),
        onClick: () => {
          setSelectedKeys([encodedProjectId]);

          navigate(
            location?.id === allLocationsKey
              ? routePaths.PRODUCTS
              : `${routePaths.PROJECTS_EDIT_BY_ID}/${encodedProjectId}?locationId=${location?.id}`
          );
        },
        ...menuItemStyles,
      };
    });

    // console.log("data", data);

    return mappedData;
  }, [menuItemStyles, navigate, recentLocationsData]);

  const items: MenuItem[] = [
    {
      key: "brandLogoContainer",
      label: (
        <Flex vertical justify="center" align="center">
          <Typography.Text
            style={{
              fontSize: getConsistentSpacing(2.5),
              fontWeight: 700,
              marginBlock: getConsistentSpacing(2),
            }}
          >
            {company?.name}
          </Typography.Text>
          {company?.logo ? (
            <Image
              src={company?.logo?.url}
              alt=""
              style={{
                maxWidth: 220,
                maxHeight: 160,
              }}
            />
          ) : (
            <Image preview={false} src={SidebarImage} width="160px" />
          )}
        </Flex>
      ),
      type: "group",
    },
    {
      key: "createProjectsContainer",
      label: (
        <Flex
          vertical
          style={{
            marginTop: getConsistentSpacing(2),
          }}
        >
          {!isFieldsCraftAuthorized() ? (
            <Button
              size="large"
              type="primary"
              icon={
                <CustomIcon
                  className="fill-white text-sm xl:text-base"
                  type="plus"
                  width={parseInt(getConsistentSpacing(3))}
                  height={parseInt(getConsistentSpacing(3))}
                />
              }
              onClick={() => navigate(routePaths.PROJECTS_NEW)}
            >
              <span className="text-sm xl:text-base">Create New Project</span>
            </Button>
          ) : (
            <Button
              size="large"
              type="primary"
              onClick={() => navigate(routePaths.PROJECTS)}
            >
              <span className="text-sm xl:text-base">View Projects</span>
            </Button>
          )}
        </Flex>
      ),
      type: "group",
    },
    {
      key: "projects",
      label: (
        <Flex vertical>
          <Flex align="center">
            <Typography.Text
              style={{
                fontSize: getConsistentSpacing(2),
                fontWeight: 700,
                marginRight: "auto",
              }}
            >
              Projects
            </Typography.Text>

            {/* <Button
              type="link"
              shape="circle"
              icon={<CustomIcon type="filter" />}
            /> */}
          </Flex>
          <Input
            value={searchTerm}
            onChange={(event) => setSearchTerm(event?.target?.value || "")}
            prefix={<CustomIcon type="search" />}
            placeholder="Search.."
            style={{ marginBlock: getConsistentSpacing(1) }}
          />
        </Flex>
      ),
      type: "group",
      children: memoizedProjectsData,
    },
    {
      key: "storage",
      label: (
        <Flex align="center" style={{ marginTop: getConsistentSpacing(3) }}>
          <Typography.Text
            style={{
              fontSize: getConsistentSpacing(2),
              fontWeight: 700,
              marginRight: "auto",
            }}
          >
            Storage
          </Typography.Text>

          {/* <Button
            type="link"
            shape="circle"
            icon={<CustomIcon type="filter" />}
          /> */}
        </Flex>
      ),
      type: "group",
      children: memoizedLocationsData,
    },
  ];

  useEffect(() => {
    const pathSegments = (location.pathname || "").split("/");
    const isLocationsRoute = pathSegments[1] === "locations";
    const name = pathSegments[2];

    if (
      location.pathname === routePaths.PROJECTS ||
      location.pathname === "/"
    ) {
      setSelectedKeys([allProjectsKey]);
    } else if (isLocationsRoute && !name) {
      // setSelectedKeys([allLocationsKey]);
    }
  }, [location.pathname]);

  useEffect(() => {
    if (projectsSummarizedData?.length === 0) return;
    setRecentProjectsData(projectsSummarizedData || null);
  }, [projectsSummarizedData]);

  useEffect(() => {
    if (!locationListForSideBar?.length) return;
    setRecentLocationsData(locationListForSideBar.slice(0, 15));
  }, [locationListForSideBar]);

  useEffect(() => {
    const interval = setInterval(() => {
      setDraftProjectName((_) => getProjectName());
    }, 500);

    return () => clearInterval(interval);
  }, []);

  return (
    <>
      <Layout.Sider
        width="15vw"
        style={{
          borderRight: "1px solid" + token.colorNeutral5,
          position: "sticky",
          top: 0,
          left: 0,
          height: "100vh",
          overflowY: "auto",
          background: "white",
        }}
      >
        <Menu
          // activeKey={}
          multiple
          selectedKeys={selectedKeys}
          onSelect={(info) => {
            setSelectedKeys(() => [info.key]);
          }}
          mode="vertical"
          style={{ height: "100%", borderRight: 0 }}
          items={items}
        />
      </Layout.Sider>
    </>
  );
}
