import { getConsistentSpacing } from "@utils/theme-helpers";
import { Flex, Typography } from "antd";
import React, { useMemo } from "react";
import { useNavigate } from "react-router-dom";
import CustomIcon, { IconType } from "../common/CustomIcon";

type PageLayoutProps = {
  children: React.ReactNode;
  backlink?: { title: string; route: string };
  title?: string;
  titleSibling?: React.ReactNode;
  titleBarJustifyContent?: React.CSSProperties["justifyContent"];
  isActive?: boolean;
  titlePrefixIcon?: IconType;
};

export default function PageLayout(props: PageLayoutProps) {
  const navigate = useNavigate();
  const hasBacklink = useMemo(
    () => props.backlink?.title && props.backlink?.route,
    [props.backlink?.title, props.backlink?.route]
  );

  return (
    <>
      <Flex
        vertical
        style={{ minHeight: "100vh", padding: getConsistentSpacing(3) }}
      >
        <Flex
          align="center"
          justify={props.titleBarJustifyContent || "space-between"}
          gap={getConsistentSpacing(3)}
          style={{ width: "100%", paddingBottom: getConsistentSpacing(3) }}
        >
          <div className="flex gap-2  items-center">
            {props?.titlePrefixIcon && (
              <CustomIcon type={props?.titlePrefixIcon} />
            )}

            {hasBacklink && (
              <p
                className="text-lg font-semibold text-primary cursor-pointer hover:text-primaryHover underline"
                onClick={() => navigate(props.backlink?.route || "")}
              >
                {props.backlink?.title || ""}
              </p>
            )}

            {props.title && (
              <Typography.Title
                level={4}
                style={{
                  margin: 0,
                  fontSize: getConsistentSpacing(2.25),
                  color: props?.isActive ? "#F44803" : "#000",
                }}
              >
                {hasBacklink ? <span>&gt;&nbsp;</span> : null}
                {props.title}
              </Typography.Title>
            )}
          </div>

          {props.titleSibling}
        </Flex>
        {props.children}
      </Flex>
    </>
  );
}
