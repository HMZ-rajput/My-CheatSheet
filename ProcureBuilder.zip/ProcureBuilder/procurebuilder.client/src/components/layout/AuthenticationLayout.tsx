import React from "react";
import { Col, ConfigProvider, Image, Row, Typography } from "antd";
import { getConsistentSpacing } from "@utils/theme-helpers";

// Images
import ProcureBuilderLogo from "@components/common/ProcureBuilderLogo";
import CopyrightText from "@components/common/CopyrightText";
import LoginPageImage from "@assets/images/login-page-image.png";

type AuthenticationLayoutProps = {
  children: React.ReactNode;
};

export default function AuthenticationLayout(props: AuthenticationLayoutProps) {
  return (
    <>
      <Row>
        <Col span={24}>
          <Row>
            <Col span={12} style={{ position: "relative" }}>
              <div
                style={{
                  position: "absolute",
                  top: getConsistentSpacing(3),
                  left: getConsistentSpacing(7),
                }}
              >
                <ProcureBuilderLogo />
              </div>
              {props.children}
              <div
                style={{
                  position: "absolute",
                  bottom: getConsistentSpacing(3),
                  left: getConsistentSpacing(7),
                }}
              >
                <CopyrightText />
              </div>
            </Col>
            <Col
              span={12}
              style={{
                padding: getConsistentSpacing(1.5),
                position: "relative",
              }}
            >
              <Image
                preview={false}
                src={LoginPageImage}
                height={`calc(100vh - ${getConsistentSpacing(3)}px)`}
                width="100%"
                style={{
                  borderRadius: getConsistentSpacing(2),
                  objectFit: "cover",
                }}
              />
              <Row
                justify="center"
                style={{ position: "absolute", top: "65%", left: 0, right: 0 }}
              >
                <ConfigProvider
                  typography={{
                    style: {
                      color: "white",
                    },
                  }}
                >
                  <Typography.Title
                    level={2}
                    style={{ margin: 0, width: "100%", textAlign: "center" }}
                  >
                    Welcome to Procure Builder
                  </Typography.Title>
                  <Typography.Paragraph
                    style={{
                      fontSize: getConsistentSpacing(2.5),
                      margin: 0,
                      maxWidth: "70%",
                      textAlign: "center",
                    }}
                  >
                    Log in to access essential tools and resources. At Procure
                    Builder, we empower our team with a seamless platform to
                    manage projects efficiently. Let&apos;s build excellence
                    together, every step of the way.
                  </Typography.Paragraph>
                </ConfigProvider>
              </Row>
            </Col>
          </Row>
        </Col>
      </Row>
    </>
  );
}
