import { Flex } from "antd";

type SectionLayoutProps = {
  children?: React.ReactNode;
  borderStyle?: "solid" | "dashed";
  className?: string;
  isHidden?: boolean;
};
export default function SectionLayout(props: SectionLayoutProps) {
  return (
    <>
      <Flex
        className={`
          ${props.isHidden ? "" : `${props.className || "p-6 rounded-2xl"} 
          ${props?.borderStyle === "dashed"
              ? `border-2 border-dashed border-neutral-6`
              : `border border-neutral-5`
            }`}`}
        vertical
      >
        {props.children}
      </Flex>
    </>
  );
}
