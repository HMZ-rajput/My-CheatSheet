import { numberRegex } from "@/src/utils/constants";
import { ChangeEvent } from "react";

type CustomInputProps = {
  label?: string;
  endAdornment?: React.ReactNode;
  checked?: boolean;
  value: string | number | boolean;
  type?: "text" | "number" | "checkbox";
  placeholder?: string;
  min?: number;
  disabled?: boolean;
  error?: string;
  isLineThrough?: boolean;
  step?: "any" | number;
  onChange: (value: boolean | string | number) => void;
};

export default function CustomInput({
  label,
  endAdornment,
  value,
  type = "text",
  checked,
  onChange,
  error,
  step,
  ...props
}: CustomInputProps) {
  function handleChange(e: ChangeEvent<HTMLInputElement>) {
    let value: string | number | boolean =
      type === "checkbox" ? e.target.checked : `${e.target.value}`.toString();

    if (value === "true") {
      value = true;
    } else if (value === "false") {
      value = false;
    } else if (typeof value === "string" && numberRegex.test(value)) {
      value = parseFloat(value);
    }

    onChange(value);
  }

  return (
    <div className="custom-input-control-container">
      {label && <label className="custom-input-label">{label}</label>}
      <div
        className="custom-input-container"
        data-has-adornment={Boolean(endAdornment)}
      >
        {type === "checkbox" ? (
          <>
            <input
              {...props}
              onChange={handleChange}
              className="custom-input "
              checked={checked}
              type={type}
            />
            <div className="checkmark"></div>
          </>
        ) : (
          <input
            {...props}
            value={`${value}`}
            onChange={handleChange}
            className={`custom-input ${
              props.isLineThrough ? "line-through" : ""
            }`}
            type={type}
            step={step}
          />
        )}

        {error && <div className="mt-1 text-error break-words">{error}</div>}
        <div className="custom-input-end-adornment">{endAdornment || null}</div>
      </div>
    </div>
  );
}
