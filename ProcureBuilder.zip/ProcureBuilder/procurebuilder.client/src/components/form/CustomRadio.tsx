import { InputHTMLAttributes } from "react";

type CustomRadioProps = {
  title: string;
  fieldValue: string | boolean | number;
  options: { label: string; value: string | boolean | number }[];
  disabled?: boolean;
  fieldOnChange: (value: string | boolean | number) => void;
} & InputHTMLAttributes<HTMLInputElement>; // & ControllerRenderProps

export default function CustomRadio({
  disabled = false,
  title,
  fieldValue,
  options,
  fieldOnChange,
}: CustomRadioProps) {
  return (
    <div className="custom-radio-container">
      <p>{title}</p>
      <div className="custom-radio-options">
        {options?.map((m) => (
          <div
            className="custom-radio"
            onClick={() => {
              if (!disabled) {
                fieldOnChange(m.value as boolean);
              }
            }}
          >
            <input
              disabled={disabled}
              type="radio"
              value={`${m.value}`}
              checked={`${fieldValue}` === `${m.value}`}
            />
            <label>{m.label}</label>
          </div>
        ))}
      </div>
    </div>
  );
}
