import { useAppDispatch } from "@/src/hooks/useAppDispatch";
import { Button, Form } from "antd";
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

type CustomFormButtonsProps = {
  isEditMode?: boolean;
  isSuccess?: boolean;

  // hasValidationErrors -> checks if the form has any VALIDATION errors thrown by Formik or React-Hook-Form.
  hasValidationErrors?: boolean;

  // hasHttpErrors -> checks if the form has any REQUEST or RESPONSE errors in it's redux state/slice.
  hasHttpErrors?: boolean;

  isDeletingProgress?: boolean;
  isStaticLoading?: boolean;
  navigationRoute?: string;

  disableSaveButton?: boolean;

  showCancelButton?: boolean;
  showSaveButton?: boolean;
  showSaveAndCloseButton?: boolean;
  showSaveAndNewButton?: boolean;
  showDeleteButton?: boolean;
  saveButtonName?: string;
  saveAndCloseButtonName?: string;
  cancelButtonName?: string;
  deleteButtonName?: string;
  isSaveAndCloseLoading?: boolean;
  handleCancel?: () => void;
  handleDelete?: () => void;
  handleSubmit: () => void;
  handleSaveAndClose?: () => void;
  resetStateisSuccess?: () => void;
};

export default function CustomFormButtons({
  showCancelButton = true,
  showDeleteButton = true,
  showSaveAndCloseButton = true,
  resetStateisSuccess,
  ...props
}: CustomFormButtonsProps) {
  type SelectedButtonType =
    | null
    | typeof isSaving
    | typeof isSavingAndClosing
    | typeof isDeleting;

  const navigate = useNavigate();
  const dispatch = useAppDispatch();
  const isSaving = 1;
  const isSavingAndClosing = 2;
  const isDeleting = -1;

  const [selectedButton, setSelectedButton] =
    useState<SelectedButtonType>(null);

  function handleSelectedType(type: SelectedButtonType) {
    if (type === isDeleting && props?.handleDelete) {
      props.handleDelete();
    } else {
      props.handleSubmit();
    }

    setSelectedButton(type);
  }

  useEffect(() => {
    const hasAnyError = props?.hasValidationErrors || props?.hasHttpErrors;

    // If there are any validation or http errors, it won't save & close the page.

    if (props?.isSuccess && !hasAnyError) {
      if (selectedButton === isSavingAndClosing) {
        if (props?.navigationRoute) {
          navigate(props.navigationRoute);
          if (resetStateisSuccess) {
            dispatch(resetStateisSuccess() as any);
          }
        } else if (props?.handleCancel) {
          props?.handleCancel();
        } else {
          console.error(
            `CustomFormButtons: Neither "navigationRoute" or "handleCancel" have been passed.`
          );
        }
      } else {
        setSelectedButton(null);
        if (resetStateisSuccess) {
          dispatch(resetStateisSuccess() as any);
        }
      }
    }
  }, [props.isSuccess, props.navigationRoute, navigate, selectedButton, props]);

  useEffect(() => {
    const hasAnyError = props?.hasValidationErrors || props?.hasHttpErrors;

    if (hasAnyError) {
      // Stop loading state of buttons.
      setSelectedButton(null);
    } else {
      // Do not stop loading state.
    }
  }, [props.hasValidationErrors, props.hasHttpErrors]);

  return (
    <>
      {showCancelButton ? (
        <Button
          disabled={selectedButton !== null}
          onClick={() => {
            if (props?.handleCancel) {
              props?.handleCancel();
            } else {
              navigate(-1);
            }
          }}
        >
          {props?.cancelButtonName || "Cancel"}
        </Button>
      ) : null}
      {props?.isEditMode && props?.handleDelete && showDeleteButton && (
        <Button
          loading={selectedButton === isDeleting || props?.isDeletingProgress}
          disabled={Boolean(selectedButton) && selectedButton !== isDeleting}
          onClick={() => handleSelectedType(isDeleting)}
        >
          {selectedButton === isDeleting
            ? "Deleting.."
            : props?.deleteButtonName || "Delete"}
        </Button>
      )}
      <Form.Item>
        <Button
          loading={selectedButton === isSaving || props?.isStaticLoading}
          disabled={
            props.disableSaveButton ||
            props?.hasValidationErrors ||
            (Boolean(selectedButton) && selectedButton !== isSaving) ||
            props?.isStaticLoading
          }
          type="primary"
          onClick={() => handleSelectedType(isSaving)}
        >
          {selectedButton === isSaving
            ? "Saving.."
            : props?.saveButtonName || "Save"}
        </Button>
      </Form.Item>
      {showSaveAndCloseButton && (
        <Form.Item>
          <Button
            loading={
              selectedButton === isSavingAndClosing ||
              props?.isSaveAndCloseLoading
            }
            disabled={
              props.disableSaveButton ||
              props?.hasValidationErrors ||
              (Boolean(selectedButton) && selectedButton !== isSavingAndClosing)
            }
            type="primary"
            onClick={() =>
              props?.handleSaveAndClose
                ? props?.handleSaveAndClose()
                : handleSelectedType(isSavingAndClosing)
            }
          >
            {selectedButton === isSavingAndClosing
              ? "Saving and closing.."
              : props?.saveAndCloseButtonName || "Save & Close"}
          </Button>
        </Form.Item>
      )}
    </>
  );
}
