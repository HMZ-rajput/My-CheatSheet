import { Row } from "antd";
import { ReactNode } from "react";

type CustomFormRowProps = {
  children: ReactNode;
};
export default function CustomFormRow(props: CustomFormRowProps) {
  return (
    <>
      <Row className="custom-ant-form-row">{props.children}</Row>
    </>
  );
}
