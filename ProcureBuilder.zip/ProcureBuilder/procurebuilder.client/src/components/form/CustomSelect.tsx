import { useState } from "react";

type CustomSelectProps = {
  fieldValue: string | boolean | number;
  fieldOnChange: (value: string | boolean | number) => void;
  options: { label: string; value: string | boolean | number }[];
  label?: string;
  isLineThrough?: boolean;
  disabled?: boolean;
};

export default function CustomSelect({
  fieldValue,
  fieldOnChange,
  options,
  label,
  isLineThrough,
  disabled = false,
}: CustomSelectProps) {
  const [isVisible, setIsVisible] = useState(false);

  return (
    <div className="custom-select-control-container">
      {label && <label className={`custom-select-label `}>{label}</label>}
      <div
        data-disabled={disabled}
        className={`custom-select ${isLineThrough ? "line-through" : ""}`}
        onClick={() => {
          if (disabled) return;
          setIsVisible(true);
        }}
      >
        {options.find((f) => f.value === fieldValue)?.label}
      </div>
      <ul
        className="custom-select-list"
        style={{ display: !isVisible ? "none" : "" }}
      >
        {options.map((m) => (
          <li
            data-active={`${m.value}` === `${fieldValue}`}
            className={`custom-select-list-item w-100`}
            onClick={() => {
              if (disabled) return;
              fieldOnChange(m.value);
              setIsVisible(false);
            }}
          >
            {m.label}
          </li>
        ))}
      </ul>

      <div
        className="custom-select-backdrop"
        onClick={() => setIsVisible(false)}
        style={{ display: !isVisible ? "none" : "" }}
      ></div>
    </div>
  );
}
