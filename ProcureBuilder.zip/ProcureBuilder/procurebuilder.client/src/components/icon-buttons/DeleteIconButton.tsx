import { Button } from "antd";
import CustomIcon from "../common/CustomIcon";

type DeleteIconButtonProps = {
  handleDelete: () => void;
  disabled?: boolean;
};
export default function DeleteIconButton(props: DeleteIconButtonProps) {
  return (
    <>
      <Button
        className="border border-danger-510 !stroke-danger-5 hover:!border-danger-5 hover:!bg-danger-510 disabled:!bg-neutral-1 disabled:!border-neutral-5 disabled:!text-neutral-75 disabled:!fill-gray-2 disabled:!stroke-gray-2"
        onClick={props.handleDelete}
        disabled={props.disabled}
        icon={<CustomIcon type="delete-icon" className="fill-white " />}
      />
    </>
  );
}
