import { useAppDispatch } from "@/src/hooks/useAppDispatch";
import { deleteDraftProject } from "@/src/store/slices/projectsSlice";
import ProtectedRoute from "@components/routing/ProtectedRoute";
import { routePathsWithParams } from "@utils/routePaths";
import { RouteType } from "@utils/types";
import { useEffect } from "react";
import { Navigate, Route, Routes, useLocation } from "react-router-dom";

import NotFoundPage from "@/src/features/404/NotFound404";
import AccountDetailsPage from "@/src/features/account-settings/pages/AccountSettingsDetailsPage";
import ChangeOrderDetailsPage from "@/src/features/change-orders/pages/ChangeOrderDetails";
import ChangeOrderPage from "@/src/features/change-orders/pages/ChangeOrders";
import CompanyDetailsPage from "@/src/features/company-settings/pages/CompanyDetailsPage";
import CustomersDetailsPage from "@/src/features/customers/pages/CustomerDetails";
import CustomersPage from "@/src/features/customers/pages/Customers";
import InternalUserDetailsPage from "@/src/features/internal-users/pages/InternalUserDetails";
import InternalUsersPage from "@/src/features/internal-users/pages/InternalUsers";
import InvoicesPage from "@/src/features/invoices/pages/Invoices";
import InvoicesDetailsPage from "@/src/features/invoices/pages/InvoicesDetails";
import LocationDetailsPage from "@/src/features/locations/pages/LocationDetails";
import Locations from "@/src/features/locations/pages/Locations";
import MaterialGoingToSites from "@/src/features/material-going-to-sites/pages/MaterialGoingToSites";
import MaterialGoingToSitesDetailsPage from "@/src/features/material-going-to-sites/pages/MaterialGoingToSitesDetails";
import MaterialReceiptInceptionsDetailsPage from "@/src/features/material-receipt-inceptions/pages/MaterialReceiptInceptionDetailsForm";
import MaterialReceiptInceptionsPage from "@/src/features/material-receipt-inceptions/pages/MaterialReceiptInceptions";
import MaterialTransferPage from "@/src/features/material-transfer/pages/MaterialTransfer";
import MaterialTransferDetailsPage from "@/src/features/material-transfer/pages/MaterialTransferDetails";
import Product from "@/src/features/products/pages/Product";
import ProductDetailForm from "@/src/features/products/pages/ProductDetailForm";
import ProductView from "@/src/features/products/pages/ProductView";
import ProjectDetailsByIdPage from "@/src/features/projects/pages/ProjectDashboard";
import ProjectDetailsPage from "@/src/features/projects/pages/ProjectDetailsPage";
import POVendorApprovalPage from "@/src/features/purchase-orders/pages/POVendorApprovalPage";
import PurchaseOrderDetailsPage from "@/src/features/purchase-orders/pages/PurchaseOrderDetailsPage";
import PurchaseOrders from "@/src/features/purchase-orders/pages/PurchaseOrders";
import ReorderDetailsPage from "@/src/features/re-oders/pages/ReorderDetailsPage";
import ReorderPage from "@/src/features/re-oders/pages/Reorders";
import ReportPage from "@/src/features/reports";
import BidMaterialsReportPage from "@/src/features/reports/bid-materials-report";
import ChangeOrdersReportPage from "@/src/features/reports/change-orders-report";
import InventoryReportPage from "@/src/features/reports/inventory-report";
import InvoicesReportPage from "@/src/features/reports/invoices-report";
import MaterialReceiptInspectionReportPage from "@/src/features/reports/material-receipt-inspection-report";
import MaterialTransferReportPage from "@/src/features/reports/material-transfer-report";
import MaterialTransferToSiteReportPage from "@/src/features/reports/material-transfer-to-site-report";
import ProjectBudgetVsCommittedCostsReportPage from "@/src/features/reports/project-budget-vs-committed-costs-report";
import ProjectReportPage from "@/src/features/reports/projects-report";
import PurchaseOrdersReportPage from "@/src/features/reports/purchase-orders-report";
import ReordersReportPage from "@/src/features/reports/reorders-report";
import UnauthorizedPage from "@/src/features/unauthorized/Unauthorized";
import VendorComapaniesPage from "@/src/features/vendor-companies/pages/VendorCompaniesPage";
import VendorCompanyDetailsPage from "@/src/features/vendor-companies/pages/VendorCompanyDetailsPage";
import { call } from "@/src/utils/api-helpers";
import {
  allUsersAccess,
  isCombineAdminSuperAdminAccess,
} from "@/src/utils/constants";
import ChangePasswordPage from "@features/auth/pages/ChangePassword";
import ForgotPasswordPage from "@features/auth/pages/ForgotPassword";
import LoginPage from "@features/auth/pages/Login";
import VerifyOtpPage from "@features/auth/pages/VerifyOtp";
import HomePage from "@features/dashboard/pages/Home";
import ProjectsPage from "@features/projects/pages/Projects";

// Keep this check, out of the component so it stays here as a global variable.
// "DO NOT MOVE THIS IN TO THE COMPONENT" - Ustad Inshal on 11:56 AM, 11th November, 2024.
let appVersionKey = "app_version";

// 0 ==> App has mounted.
// 1 ==> Will check for new version.
// 2 ==> Has checked for new version -- will not check again.
let appVersionCheckingStep = 0;

export default function Routing() {
  async function checkAppVersion() {
    if (appVersionCheckingStep === 2) {
      return;
    } else if (appVersionCheckingStep === 0) {
      appVersionCheckingStep = 1;
      return;
    }
    appVersionCheckingStep = 2;

    const prevAppVersion = localStorage.getItem(appVersionKey);

    const response = await call<{ version: string }>({
      url: "config/version",
      method: "GET",
    });
    const newAppVersion = response?.version || "0.0.0";

    if (prevAppVersion !== newAppVersion) {
      localStorage.setItem(appVersionKey, newAppVersion);
      window.location.reload();
    }
  }

  const dispatch = useAppDispatch();
  const location = useLocation();

  const routes: RouteType[] = [
    // Dashboard Routes
    {
      element: <HomePage />,
      path: routePathsWithParams.HOME,
      roles: allUsersAccess,
    },

    // Auth Routes
    {
      element: <LoginPage />,
      path: routePathsWithParams.LOGIN,
      roles: [],
    },
    {
      element: <ForgotPasswordPage />,
      path: routePathsWithParams.FORGOTPASSWORD,
      roles: [],
    },
    {
      element: <VerifyOtpPage />,
      path: routePathsWithParams.VERIFY_OTP,
      roles: [],
    },
    {
      element: <ChangePasswordPage />,
      path: routePathsWithParams.RESET_PASSWORD,
      roles: [],
    },
    {
      element: <UnauthorizedPage />,
      path: routePathsWithParams.UNAUTHORIZED,
      roles: allUsersAccess,
    },
    // Project route
    {
      element: <ProjectsPage />,
      path: routePathsWithParams.PROJECTS,
      roles: allUsersAccess,
    },
    {
      element: <ProjectDetailsPage />,
      path: routePathsWithParams.PROJECTS_NEW,
      roles: allUsersAccess,
    },
    {
      element: <ProjectDetailsPage />,
      path: routePathsWithParams.PROJECTS_EDIT_BY_ID,
      roles: allUsersAccess,
    },
    {
      element: <ProjectDetailsByIdPage />,
      path: routePathsWithParams.PROJECTS_DETAILS_BY_ID,
      roles: allUsersAccess,
    },
    // Location Routes
    {
      element: <Locations />,
      path: routePathsWithParams.LOCATIONS,
      roles: allUsersAccess,
    },
    {
      element: <LocationDetailsPage />,
      path: routePathsWithParams.LOCATION_NEW,
      roles: allUsersAccess,
    },
    {
      element: <LocationDetailsPage />,
      path: routePathsWithParams.LOCATIONS_EDIT_BY_ID,
      roles: allUsersAccess,
    },
    // Customer Routes
    {
      element: <CustomersPage />,
      path: routePathsWithParams.CUSTOMERS,
      roles: allUsersAccess,
    },
    {
      element: <CustomersDetailsPage />,
      path: routePathsWithParams.CUSTOMERS_NEW,
      roles: allUsersAccess,
    },
    {
      element: <CustomersDetailsPage />,
      path: routePathsWithParams.CUSTOMERS_EDIT_BY_ID,
      roles: allUsersAccess,
    },
    // Change Order Routes
    {
      element: <ChangeOrderPage />,
      path: routePathsWithParams.CHANGE_ORDERS,
      roles: allUsersAccess,
    },
    {
      element: <ChangeOrderDetailsPage />,
      path: routePathsWithParams.CHANGE_ORDERS_NEW,
      roles: allUsersAccess,
    },
    {
      element: <ChangeOrderDetailsPage />,
      path: routePathsWithParams.CHANGE_ORDER_EDIT_BY_ID,
      roles: allUsersAccess,
    },
    {
      element: <CompanyDetailsPage />,
      path: routePathsWithParams.COMPANY_SETTINGS,
      roles: isCombineAdminSuperAdminAccess,
    },
    {
      element: <AccountDetailsPage />,
      path: routePathsWithParams.ACCOUNT_SETTINGS,
      roles: allUsersAccess,
    },
    // Vendor Comapnies Routes
    {
      element: <VendorComapaniesPage />,
      path: routePathsWithParams.VENDORS,
      roles: allUsersAccess,
    },
    {
      element: <VendorCompanyDetailsPage />,
      path: routePathsWithParams.VENDORS_NEW,
      roles: allUsersAccess,
    },
    {
      element: <VendorCompanyDetailsPage />,
      path: routePathsWithParams.VENDORS_EDIT_BY_ID,
      roles: allUsersAccess,
    },

    // Internal Users Routes
    {
      element: <InternalUsersPage />,
      path: routePathsWithParams.INTERNAL_USERS,
      roles: isCombineAdminSuperAdminAccess,
    },
    {
      element: <InternalUserDetailsPage />,
      path: routePathsWithParams.INTERNAL_USERS_NEW,
      roles: isCombineAdminSuperAdminAccess,
    },
    {
      element: <InternalUserDetailsPage />,
      path: routePathsWithParams.INTERNAL_USERS_EDIT_BY_ID,
      roles: isCombineAdminSuperAdminAccess,
    },

    //Products
    {
      element: <Product />,
      path: routePathsWithParams.PRODUCTS,
      roles: allUsersAccess,
    },
    {
      element: <ProductDetailForm />,
      path: routePathsWithParams.PRODUCTS_CREATE,
      roles: allUsersAccess,
    },
    {
      element: <ProductView />,
      path: routePathsWithParams.PRODUCTS_DETAILS,
      roles: allUsersAccess,
    },

    {
      element: <ProductDetailForm />,
      path: routePathsWithParams.PRODUCTS_EDIT_BY_ID,
      roles: allUsersAccess,
    },

    //Reorders Routhes (Static)
    {
      element: <ReorderPage />,
      path: routePathsWithParams.REORDERS,
      roles: allUsersAccess,
    },
    {
      element: <ReorderDetailsPage />,
      path: routePathsWithParams.REORDERS_NEW,
      roles: allUsersAccess,
    },
    {
      element: <ReorderDetailsPage />,
      path: routePathsWithParams.REORDERS_EDIT_BY_ID,
      roles: allUsersAccess,
    },

    //Purchase Orders Routes
    {
      element: <PurchaseOrders />,
      path: routePathsWithParams.PURCHASE_ORDERS,
      roles: allUsersAccess,
    },
    {
      element: <PurchaseOrderDetailsPage />,
      path: routePathsWithParams.PURCHASE_ORDERS_NEW,
      roles: allUsersAccess,
    },
    {
      element: <PurchaseOrderDetailsPage />,
      path: routePathsWithParams.PURCHASE_ORDERS_EDIT_BY_ID,
      roles: allUsersAccess,
    },

    //Invoices Routes
    {
      element: <InvoicesPage />,
      path: routePathsWithParams.INVOICES,
      roles: isCombineAdminSuperAdminAccess,
    },
    {
      element: <InvoicesDetailsPage />,
      path: routePathsWithParams.INVOICES_NEW,
      roles: isCombineAdminSuperAdminAccess,
    },
    {
      element: <InvoicesDetailsPage />,
      path: routePathsWithParams.INVOICES_EDIT_BY_ID,
      roles: isCombineAdminSuperAdminAccess,
    },

    //Material Transfer Routes
    {
      element: <MaterialTransferPage />,
      path: routePathsWithParams.MATERIAL_TRANSFER,
      roles: allUsersAccess,
    },
    {
      element: <MaterialTransferDetailsPage />,
      path: routePathsWithParams.MATERIAL_TRANSFER_NEW,
      roles: allUsersAccess,
    },
    {
      element: <MaterialTransferDetailsPage />,
      path: routePathsWithParams.MATERIAL_TRANSFER_EDIT_BY_ID,
      roles: allUsersAccess,
    },

    //Material Going To Sites Routes
    {
      element: <MaterialGoingToSites />,
      path: routePathsWithParams.MATERIAL_GOING_TO_SITES,
      roles: allUsersAccess,
    },
    {
      element: <MaterialGoingToSitesDetailsPage />,
      path: routePathsWithParams.MATERIAL_GOING_TO_SITES_NEW,
      roles: allUsersAccess,
    },
    {
      element: <MaterialGoingToSitesDetailsPage />,
      path: routePathsWithParams.MATERIAL_GOING_TO_SITES_EDIT_BY_ID,
      roles: allUsersAccess,
    },

    //Material Receipt Inceptions Routes
    {
      element: <MaterialReceiptInceptionsPage />,
      path: routePathsWithParams.MATERIAL_RECEIPT_INSPECTION,
      roles: allUsersAccess,
    },
    {
      element: <MaterialReceiptInceptionsDetailsPage />,
      path: routePathsWithParams.MATERIAL_RECEIPT_INSPECTION_NEW,
      roles: allUsersAccess,
    },
    {
      element: <MaterialReceiptInceptionsDetailsPage />,
      path: routePathsWithParams.MATERIAL_RECEIPT_INSPECTION_EDIT_BY_ID,
      roles: allUsersAccess,
    },

    // Reports
    {
      element: <ReportPage />,
      path: routePathsWithParams.REPORTS,
      roles: allUsersAccess,
    },
    {
      element: <ProjectReportPage />,
      path: routePathsWithParams.PROJECTS_REPORT,
      roles: allUsersAccess,
    },
    {
      element: <BidMaterialsReportPage />,
      path: routePathsWithParams.BID_MATERIALS_REPORT,
      roles: allUsersAccess,
    },
    {
      element: <ChangeOrdersReportPage />,
      path: routePathsWithParams.CHANGE_ORDERS_REPORT,
      roles: allUsersAccess,
    },
    {
      element: <ProjectBudgetVsCommittedCostsReportPage />,
      path: routePathsWithParams.PROJECT_BUDGET_VS_COMMITTED_COSTS_REPORT,
      roles: allUsersAccess,
    },
    {
      element: <PurchaseOrdersReportPage />,
      path: routePathsWithParams.PURCHASE_ORDERS_REPORT,
      roles: allUsersAccess,
    },
    {
      element: <ReordersReportPage />,
      path: routePathsWithParams.REORDERS_REPORT,
      roles: allUsersAccess,
    },
    {
      element: <InvoicesReportPage />,
      path: routePathsWithParams.INVOICES_REPORT,
      roles: allUsersAccess,
    },
    {
      element: <InventoryReportPage />,
      path: routePathsWithParams.INVENTORY_REPORT,
      roles: allUsersAccess,
    },
    {
      element: <MaterialTransferReportPage />,
      path: routePathsWithParams.MATERIAL_TRANSFER_REPORT,
      roles: allUsersAccess,
    },
    {
      element: <MaterialTransferToSiteReportPage />,
      path: routePathsWithParams.MATERIAL_GOING_TO_SITE_REPORT,
      roles: allUsersAccess,
    },
    {
      element: <MaterialReceiptInspectionReportPage />,
      path: routePathsWithParams.MATERIAL_INSPECTION_REPORT,
      roles: allUsersAccess,
    },
  ];

  useEffect(() => {
    if (location.pathname !== routePathsWithParams.PROJECTS_NEW) {
      dispatch(deleteDraftProject());
    }

    checkAppVersion();
  }, [dispatch, location.pathname]);

  return (
    <>
      <Routes>
        {routes.map((m) => (
          <Route
            key={m.path}
            path={m.path}
            element={
              <ProtectedRoute path={m.path} roles={m.roles || [""]}>
                {m.element}
              </ProtectedRoute>
            }
          />
        ))}
        <Route
          path={routePathsWithParams.PURCHASE_ORDERS_VENDOR_APPROVE}
          element={<POVendorApprovalPage />}
        />

        <Route
          path={routePathsWithParams.NOT_FOUND}
          element={<NotFoundPage />}
        />

        <Route
          path="*"
          element={<Navigate to={routePathsWithParams.NOT_FOUND} />}
        />
      </Routes>
    </>
  );
}
