import { useAppSelector } from "@hooks/useAppSelector";
import { getUserState } from "@store/slices/userSlice";
import { routePathsWithParams } from "@utils/routePaths";
import { useEffect } from "react";
import { Navigate, useNavigate } from "react-router-dom";

type ProtectedRouteTypes = {
  children: React.ReactNode;
  path: string;
  roles: string[];
};

export default function ProtectedRoute(props: ProtectedRouteTypes) {
  // const { children, path, roles } = props;
  // const { data } = useAppSelector(getUserState);

  // if (!data?.userRole) {
  //   <Navigate to={routePathsWithParams.LOGIN} />;
  // }

  // if (
  //   !data?.bearerToken &&
  //   ![
  //     routePathsWithParams.LOGIN,
  //     routePathsWithParams.FORGOTPASSWORD,
  //     routePathsWithParams.VERIFY_OTP,
  //     routePathsWithParams.RESET_PASSWORD,
  //     routePathsWithParams.UNAUTHORIZED,
  //   ].includes(path)
  // ) {
  //   return <Navigate to={routePathsWithParams.LOGIN} />;
  // } else if (data?.bearerToken && path === routePathsWithParams.LOGIN) {
  //   return <Navigate to={routePathsWithParams.HOME} />;
  // }

  // if (!roles.includes(data?.userRole || "")) {
  //   if (data?.userRole === Roles.SuperAdmin) {
  //     return <Navigate to={routePathsWithParams.HOME} />;
  //   } else if (data?.userRole === Roles.Admin) {
  //     return <Navigate to={routePathsWithParams.HOME} />;
  //   } else if (data?.userRole === Roles.Engineer) {
  //     return <Navigate to={routePathsWithParams.HOME} />;
  //   } else if (data?.userRole === Roles.Superintendent) {
  //     return <Navigate to={routePathsWithParams.HOME} />;
  //   } else if (data?.userRole === Roles.Fieldcraft) {
  //     return <Navigate to={routePathsWithParams.HOME} />;
  //   }
  // }

  // return <>{children}</>;

  // const { userData } = useDataContext();
  const { data: userData } = useAppSelector(getUserState);
  const { children, path, roles } = props;
  const navigate = useNavigate();

  Object.keys(routePathsWithParams).map((v) => v);

  useEffect(() => {
    if (userData?.bearerToken && path === routePathsWithParams.HOME) {
      navigate(routePathsWithParams.HOME);
    }
  }, [path, userData, navigate]);

  if (!userData?.bearerToken) {
    if (
      ![
        routePathsWithParams.LOGIN,
        routePathsWithParams.FORGOTPASSWORD,
        routePathsWithParams.VERIFY_OTP,
        routePathsWithParams.RESET_PASSWORD,
        routePathsWithParams.UNAUTHORIZED,
        routePathsWithParams.NOT_FOUND,
      ].includes(path)
    ) {
      return <Navigate to={routePathsWithParams.LOGIN} replace />;
    }
  } else {
    if (path === routePathsWithParams.LOGIN) {
      return <Navigate to={routePathsWithParams.HOME} replace />;
    }

    if (!roles?.includes(userData?.userRole)) {
      return <Navigate to={routePathsWithParams.HOME} replace />;
    }
  }

  return <>{children}</>;
}
