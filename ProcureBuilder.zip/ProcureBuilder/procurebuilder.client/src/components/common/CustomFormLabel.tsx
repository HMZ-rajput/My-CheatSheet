import { Typography } from "antd";

type CustomFormLabelProps = {
  text: string;
  hasMarginBottom?: boolean;
  required?: boolean;
  isHidden?: boolean;
  textSize?: "sm" | "md" | "lg";
  fontWeight?: "normal" | "bold" | "medium";
};

export default function CustomFormLabel(props: CustomFormLabelProps) {
  const getFontSize = () => {
    switch (props.textSize) {
      case "lg":
        return "18px";
      case "md":
        return "16px";
      default:
        return "14px";
    }
  };

  const getFontWeight = () => {
    switch (props.fontWeight) {
      case "bold":
        return 700;
      case "normal":
        return 400;
      default:
        return 500;
    }
  };

  return (
    <Typography.Text
      style={{
        fontSize: getFontSize(),
        fontWeight: getFontWeight(),
        marginBottom: props.hasMarginBottom ? "8px" : "0",
      }}
      className={props.isHidden ? "invisible" : ""}
    >
      {props.text}{" "}
      {props?.required && <span className="text-[#DF1C41] w-2 h-5">*</span>}
    </Typography.Text>
  );
}
