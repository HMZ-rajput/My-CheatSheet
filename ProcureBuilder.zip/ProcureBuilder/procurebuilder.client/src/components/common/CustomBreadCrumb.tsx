import React from "react";
import { Breadcrumb } from "antd";

const CustomBreadCrumb: React.FC = (items: any) => (
  <Breadcrumb separator=">" items={items} />
);

export default CustomBreadCrumb;
