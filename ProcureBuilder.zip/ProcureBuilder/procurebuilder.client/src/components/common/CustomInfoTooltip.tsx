import { Tooltip } from "antd";
import CustomIcon from "./CustomIcon";
import type { TooltipPlacement } from "antd/es/tooltip";

type InfoTooltipArgs = {
  placement: TooltipPlacement;
  title: string;
};

export default function CustomInfoTooltip({ placement, title }: InfoTooltipArgs) {
  return (
    <Tooltip placement={placement} title={title} overlayClassName="max-w-96">
      <span>
        <CustomIcon type="info-icon" width={25} height={23} />
      </span>
    </Tooltip>
  );
}
