import React, { useState, useEffect } from "react";
import { PlusOutlined } from "@ant-design/icons";
import { Image, message, Upload } from "antd";
import type { GetProp, UploadFile, UploadProps } from "antd";
import { Attachment } from "@/src/utils/types";

type FileType = Parameters<GetProp<UploadProps, "beforeUpload">>[0];

const getBase64 = (file: FileType): Promise<string> =>
  new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = (error) => reject(error);
  });

type CustomAvatarUploadProps = {
  onChange?: (file: File | string) => void;
  error?: any;
  value?: Attachment | null;
};

const uploadButton = (
  <button style={{ border: 0, background: "none" }} type="button">
    <PlusOutlined />
    <div style={{ marginTop: 8 }}>Upload</div>
  </button>
);

const CustomAvatarUpload: React.FC<CustomAvatarUploadProps> = ({
  value,
  onChange,
}) => {
  const [previewOpen, setPreviewOpen] = useState(false);
  const [previewImage, setPreviewImage] = useState("");
  const [fileList, setFileList] = useState<UploadFile[]>([]);

  const handlePreview = async (file: UploadFile) => {
    if (!file.url && !file.preview) {
      file.preview = await getBase64(file.originFileObj as FileType);
    }
    setPreviewImage(file.url || (file.preview as string));
    setPreviewOpen(true);
  };

  const handleChange: UploadProps["onChange"] = ({ fileList: newFileList }) => {
    const updatedList = newFileList.slice(-1);
    setFileList(updatedList);

    if (onChange) {
      const file = updatedList[0]?.originFileObj;
      if (file) {
        onChange(file);
      } else {
        onChange("");
      }
    }
  };

  const beforeUpload = (file: FileType) => {
    const isValidType = ["image/jpeg", "image/png", "image/webp"].includes(
      file.type
    );
    if (!isValidType) {
      message.error("You can only upload PNG, JPEG, or WEBP files!");
      setFileList([]);
      return false;
    }

    const isLt10M = file.size / 1024 / 1024 < 10;
    if (!isLt10M) {
      message.error("Image must be smaller than 10MB!");
      setFileList([]);
      return false;
    }

    return true;
  };

  console.log("fileList", fileList);

  useEffect(() => {
    if (value && typeof value === "object" && "url" in value) {
      setFileList([
        {
          uid: value.id || "-1",
          name: value.fileName || "Uploaded Image",
          status: "done",
          url: value.url,
          thumbUrl: value.url,
        },
      ]);
    }
  }, [value]);

  return (
    <div>
      <Upload
        action="https://660d2bd96ddfa2943b33731c.mockapi.io/api/upload"
        listType="picture-card"
        fileList={fileList}
        onPreview={handlePreview}
        onChange={handleChange}
        accept={".png,.jpeg,.jpg,.webp"}
        beforeUpload={beforeUpload}
        maxCount={1}
      >
        {fileList.length >= 1 ? null : uploadButton}
      </Upload>

      <Image
        wrapperStyle={{ display: "none" }}
        preview={{
          visible: previewOpen,
          onVisibleChange: (visible) => setPreviewOpen(visible),
          afterOpenChange: (visible) => !visible && setPreviewImage(""),
        }}
        src={previewImage}
      />
    </div>
  );
};

export default CustomAvatarUpload;
