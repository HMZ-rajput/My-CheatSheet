import React from "react";
import { Typography } from "antd";

const { Text } = Typography;

interface HighlightedTextProps {
  text?: string;
  searchTerm?: string;
  styles?: React.CSSProperties;
}

function escapeRegExp(string: string) {
  return string.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
const HighlightedText: React.FC<HighlightedTextProps> = ({
  text = "",
  searchTerm,
  styles,
}) => {
  if (!searchTerm) return <Text style={styles}>{text}</Text>;
  const escaped = escapeRegExp(searchTerm);
  const parts = text?.split(new RegExp(`(${escaped})`, "gi"));
  return (
    <>
      {parts?.map((part, index) => (
        <Text
          key={index}
          mark={part.toLowerCase() === searchTerm.toLowerCase()}
          style={styles}
        >
          {part}
        </Text>
      ))}
    </>
  );
};

export default HighlightedText;
