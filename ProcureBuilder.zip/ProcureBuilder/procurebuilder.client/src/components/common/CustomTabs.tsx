import { Segmented } from "antd";
import { getConsistentSpacing } from "../../utils/theme-helpers";

type CustomTabsOptionsType = { value: string; label: string };
type CustomTabsProps = {
  options: CustomTabsOptionsType[];
  tabLabel: string;
  tabValue?: string;
  shouldReturnValueOnChange?: boolean;
  shouldFilterByValue?: boolean;
  isRounded?: boolean;
  onChange: (tab: string) => void;
};

export default function CustomTabs({
  isRounded = true,
  ...props
}: CustomTabsProps) {
  return (
    <>
      <Segmented
        style={{
          padding: getConsistentSpacing(0.5),
          fontSize: getConsistentSpacing(1.75),
          fontWeight: "500",
        }}
        className={isRounded ? "rounded" : ""}
        options={props.options}
        value={
          props.options?.find((option) =>
            props?.shouldFilterByValue
              ? option?.value === props.tabValue
              : option?.label === props.tabLabel
          )?.value
        }
        onChange={(value) => {
          const matchingTab = props.options?.find(
            (option) => option?.value === value
          );
          props.onChange(
            (props.shouldReturnValueOnChange
              ? matchingTab?.value
              : matchingTab?.label) || ""
          );
        }}
      />
    </>
  );
}
