import Loader from "./Loader";

export default function CustomRelativeLoader({
  display,
}: {
  display?: boolean;
}) {
  return (
    <div
      style={{ display: display ? "block" : "none" }}
      id="custom-relative-loader"
      className="absolute min-h-[calc(100vh-72px)] inset-0 z-[30] backdrop-blur-sm"
    >
      <div className="h-full w-full flex items-center justify-center">
        <Loader />
      </div>
    </div>
  );
}
