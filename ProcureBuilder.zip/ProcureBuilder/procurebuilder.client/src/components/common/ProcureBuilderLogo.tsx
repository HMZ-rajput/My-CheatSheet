import { Image } from "antd"
import ProcureBuilderLogoImage from "@assets/images/procure-builder-logo.png"

export default function ProcureBuilderLogo() {
  return <Image preview={false} src={ProcureBuilderLogoImage} />
}
