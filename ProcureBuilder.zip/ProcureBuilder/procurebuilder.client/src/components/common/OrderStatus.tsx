import CustomIcon from "./CustomIcon";

export type BadgeTypes =
  | "Pending"
  | "Approved"
  | "Rejected"
  | "Added to Bid Material";
export type OrderStatusIconTypes =
  | "check-mark-blue"
  | "clock-icon"
  | "check-mark"
  | "cancel";
type OrderStatusProps = {
  badgeIconType: OrderStatusIconTypes;
  badgeType: BadgeTypes;
};

export default function OrderStatus(props: OrderStatusProps) {
  let colorStylesClasses: string;

  switch (props.badgeType) {
    case "Added to Bid Material":
      colorStylesClasses = "bg-blue-1-12 text-blue-1";
      break;
    case "Approved":
      colorStylesClasses = "bg-green-8-12 text-green-8";
      break;
    case "Rejected":
      colorStylesClasses = "bg-danger-5-12 text-danger-5";
      break;
    default:
      colorStylesClasses = "bg-orange-5-12 text-orange-5";
      break;
  }

  return (
    <span
      className={`inline-flex items-center rounded-md ${colorStylesClasses} px-2 py-1 text-xs font-medium `}
    >
      <CustomIcon
        className="mr-1 fill-danger-5"
        type={props.badgeIconType}
        width={13}
      />
      {props.badgeType}
    </span>
  );
}
