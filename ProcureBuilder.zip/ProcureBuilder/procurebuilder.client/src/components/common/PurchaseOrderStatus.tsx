export type PurchaseOrderBadgeTypes =
  | "Pending Admin Approval"
  | "Admin Approved (Partial)"
  | "Admin Approved (All)"
  | "Admin Rejected (All)"
  | "Vendor Approval Pending"
  | "Vendor Approved"
  | "Vendor Rejected"
  | "Partially Received"
  | "Fully Received"
  | "Admin Signed"
  | "Rejected"
  | "Approved";
type PurchaseOrdersStatusProps = {
  badgeType: PurchaseOrderBadgeTypes;
};

export default function PurchaseOrderStatus(props: PurchaseOrdersStatusProps) {
  let colorStylesClasses: string;

  switch (props.badgeType) {
    case "Pending Admin Approval":
      colorStylesClasses = "bg-[#ECECEC] text-[#53575A]";
      break;
    case "Admin Approved (Partial)":
      colorStylesClasses = "bg-[#FFF5E8] text-[#FF8C00]";
      break;
    case "Admin Approved (All)":
      colorStylesClasses = "bg-[#EDFFF9] text-[#38C793]";
      break;
    case "Admin Signed":
      colorStylesClasses = "bg-[#C1FFF9] text-[#06AF9E]";
      break;
    case "Admin Rejected (All)":
      colorStylesClasses = "bg-[#FFF2F5] text-[#DF1C41]";
      break;
    case "Vendor Approval Pending":
      colorStylesClasses = "bg-[#EEEEFF] text-[#5B4C9E]";
      break;
    case "Vendor Approved":
      colorStylesClasses = "bg-[#E5FFF2] text-[#307D57]";
      break;
    case "Vendor Rejected":
      colorStylesClasses = "bg-[#FFEBEB] text-[#FF4C4C]";
      break;
    case "Partially Received":
      colorStylesClasses = "bg-[#F0F7FF] text-[#1976D2]";
      break;
    case "Fully Received":
      colorStylesClasses = "bg-[#E9FFF3] text-[#2E8B57]";
      break;
    case "Approved":
      colorStylesClasses = "bg-[#E5FFF2] text-[#307D57]";
      break;
    case "Rejected":
      colorStylesClasses = "bg-[#FFEBEB] text-[#FF4C4C]";
      break;
    default:
      colorStylesClasses = "bg-[#] text-[#]";
      break;
  }

  return (
    <span
      className={`inline-flex items-center rounded-md ${colorStylesClasses} px-2 py-1 text-xs font-medium`}
    >
      {props.badgeType}
    </span>
  );
}
