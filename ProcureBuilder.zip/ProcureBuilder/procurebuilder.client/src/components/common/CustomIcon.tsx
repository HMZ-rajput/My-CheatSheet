/// <reference types="vite-plugin-svgr/client" />

import { Flex } from "antd";
import { getConsistentSpacing } from "@utils/theme-helpers";
import { OrderStatusIconTypes } from "./OrderStatus";
import { ControlPanelIconTypes } from "../layout/navbar/RightSidebar";

// Icons
import ArrowBackIcon from "@assets/icons/arrow-back-icon.svg?react";
import PlusIcon from "@assets/icons/plus-icon.svg?react";
import FilterIcon from "@assets/icons/filter-icon.svg?react";
import SearchIcon from "@assets/icons/search-icon.svg?react";
import EditIcon from "@assets/icons/edit-icon.svg?react";
import InfoIcon from "@assets/icons/info-icon.svg?react";
import DeleteIcon from "@assets/icons/delete-icon.svg?react";
import Inventory from "@assets/icons/add-inventory-small.svg?react";
import CloudUploadIcon from "@assets/icons/cloud-upload-icon.svg?react";
import AddCircleIcon from "@assets/icons/add-circle-orange-icon.svg?react";
import AddFileIcon from "@assets/icons/add-file-icon.svg?react";
import ClockIcon from "@assets/icons/clock-orange-icon.svg?react";
import CheckMarkIcon from "@assets/icons/check-mark-green-icon.svg?react";
import CheckMarkBlueIcon from "@assets/icons/check-mark-blue-icon.svg?react";
import CheckMarkOutlineIcon from "@assets/icons/check-mark-outline-icon.svg?react";
import CancelIcon from "@assets/icons/cancel-cross-red-icon.svg?react";
import CancelOutlineIcon from "@assets/icons/cancel-close-outline-icon.svg?react";
import AccountsIcon from "@assets/icons/accounts-icon.svg?react";
import LogOutIcon from "@assets/icons/log-out-icon.svg?react";
import ContactsIcon from "@assets/icons/contacts-icon.svg?react";
import MoreGridIcon from "@assets/icons/more-grid-icon.svg?react";
import InventoryIcon from "@assets/icons/inventory-icon.svg?react";
import CompanySettingsIcon from "@assets/icons/company-settings.svg?react";
import NotInvitedIcon from "@assets/icons/not-invited-icon.svg?react";
import SortDescIcon from "@assets/icons/sort-desc-icon.svg?react";
import EyeIcon from "@assets/icons/eye-icon.svg?react";
import ActionItemIcon from "@assets/icons/action-items.svg?react";
import CartIcon from "@assets/icons/cart-icon.svg?react";
import DoneAllIcon from "@assets/icons/done-all.svg?react";
import ThumbDownIcon from "@assets/icons/thumb-down.svg?react";
import ReorderIcon from "@assets/icons/reorder-icon.svg?react";
import TruckIcon from "@assets/icons/truck-icon.svg?react";
import PartialDeliveredIcon from "@assets/icons/partial-delivered-icon.svg?react";
import CalendarIcon from "@assets/icons/calendar-icon.svg?react";
import LowStockIcon from "@assets/icons/low-stock-icon.svg?react";
import TimelapseIcon from "@assets/icons/timelapse-icon.svg?react";
import ClockGrayIcon from "@assets/icons/clock-icon.svg?react";
import TruckPinkIcon from "@assets/icons/truck-pink-icon.svg?react";
import PieChartIcon from "@assets/icons/pie-chart-icon.svg?react";
import BudgetAnalysisIcon from "@assets/icons/budget-analysis-icon.svg?react";
import ProjectDetailsIcon from "@assets/icons/project-details-icon.svg?react";
import CalendarGreenIcon from "@assets/icons/calendar-green-icon.svg?react";
import DollarIcon from "@assets/icons/dollar-icon.svg?react";
import OwnerIcon from "@assets/icons/owner-icon.svg?react";
import ProjectManagerIcon from "@assets/icons/project-manager-icon.svg?react";
import CartGrayIcon from "@assets/icons/cart-gray-icon.svg?react";
import ProductNameTitleIcon from "@assets/icons/box-icon.svg?react";
import PODisLikeIcon from "@assets/icons/disLike-icon.svg?react";
import DownloadIcon from "@assets/icons/download-line.svg?react";

// Control panel icons
import CpChangeOrdersIcon from "@assets/icons/cp-change-orders-icon.svg?react";
import CpCustomersIcon from "@assets/icons/cp-customers-icon.svg?react";
import CpInternalUsersIcon from "@assets/icons/cp-internal-users-icon.svg?react";
import CpInvoicesIcon from "@assets/icons/cp-invoices-icon.svg?react";
import CpLocationsIcon from "@assets/icons/cp-locations-icon.svg?react";
import CpMaterialGoingToSiteIcon from "@assets/icons/cp-material-going-to-site-icon.svg?react";
import CpMaterialReceiptInspectionIcon from "@assets/icons/cp-material-receipt-inspection-icon.svg?react";
import CpMaterialTransferIcon from "@assets/icons/cp-material-transfer-icon.svg?react";
import CpProductsIcon from "@assets/icons/cp-products-icon.svg?react";
import CpProjectsIcon from "@assets/icons/cp-projects-icon.svg?react";
import CpPurchaseOrdersIcon from "@assets/icons/cp-purchase-orders-icon.svg?react";
import CpReordersIcon from "@assets/icons/cp-reorders-icon.svg?react";
import CpVendorsIcon from "@assets/icons/cp-vendors-icon.svg?react";

// Dashboard Icons
import DashboardInvoiceIcon from "@assets/icons/dashboard-icons/invoice.svg?react";
import DashboardLowStockIcon from "@assets/icons/dashboard-icons/low-stock.svg?react";
import DashboardMaterialReceiptInspectionIcon from "@assets/icons/dashboard-icons/material-receipt-inspection.svg?react";
import DashboardMaterialTransferToSiteIcon from "@assets/icons/dashboard-icons/material-transfer-to-site.svg?react";
import DashboardMaterialTransferIcon from "@assets/icons/dashboard-icons/material-transfer.svg?react";
import DashboardMaterialExpectedIcon from "@assets/icons/dashboard-icons/material-expected.svg?react";
import DashboardPartialDeliveredIcon from "@assets/icons/dashboard-icons/partial-delivered.svg?react";
import DashboardPurchaseOrderIcon from "@assets/icons/dashboard-icons/purchase-order.svg?react";
import DashboardReorderIcon from "@assets/icons/dashboard-icons/reorder.svg?react";
import DashboardSubmittalDueIcon from "@assets/icons/dashboard-icons/submittal-due.svg?react";
import DashboardChangeOrder from "@assets/icons/dashboard-icons/change-order.svg?react";

export type IconType =
  | "arrow-back"
  | "plus"
  | "filter"
  | "search"
  | "edit"
  | "cloud-upload"
  | "delete-icon"
  | "info-icon"
  | "inventory"
  | "add-circle"
  | "add-file"
  | "accounts"
  | "log-out"
  | "contacts"
  | "more-grid"
  | "company-settings"
  | "inventory-list"
  | "not-invited"
  | "sort-desc"
  | "check-mark-outline"
  | "cancel-close-outline"
  | "eye-icon"
  | "action-item-icon"
  | "cart-icon"
  | "done-all-icon"
  | "thumb-down-icon"
  | "reorder-icon"
  | "truck-icon"
  | "partial-delivered-icon"
  | "low-stock-icon"
  | "calendar-icon"
  | "timelapse-icon"
  | "clock-gray-icon"
  | "truck-pink-icon"
  | "pie-chart-icon"
  | "budget-analysis-icon"
  | "project-details-icon"
  | "calendar-green-icon"
  | "dollar-icon"
  | "owner-icon"
  | "project-manager-icon"
  | "cart-gray-icon"
  | OrderStatusIconTypes
  | ControlPanelIconTypes
  | "product-name"
  | "dislike-icon"
  | "download-icon"

  // Dashboard Icons
  | "dashboard-invoice-icon"
  | "dashboard-low-stock-icon"
  | "dashboard-material-receipt-inspection-icon"
  | "dashboard-material-transfer-to-site-icon"
  | "dashboard-material-transfer-icon"
  | "dashboard-material-expected-icon"
  | "dashboard-partial-delivered-icon"
  | "dashboard-purchase-order-icon"
  | "dashboard-reorder-icon"
  | "dashboard-submittal-due-icon"
  | "dashboard-changeOrder-icon";

type CustomIconProps = {
  type: IconType;
  hasContainer?: boolean;
  width?: number;
  height?: number;
  fill?: string;
  containerWidth?: number;
  containerHeight?: number;
  className?: string;
};

export default function CustomIcon(props: CustomIconProps) {
  function renderIcon() {
    const iconProps = {
      width: props?.width || getConsistentSpacing(2.5),
      height: props?.height || getConsistentSpacing(2.5),
      className: props?.className,
      fill: "",
    };

    if (props?.className?.includes("fill")) {
      iconProps.fill = props?.fill || "inherit";
    }

    switch (props.type) {
      case "info-icon": {
        return <InfoIcon {...iconProps} />;
      }
      case "delete-icon": {
        return <DeleteIcon {...iconProps} />;
      }
      case "arrow-back": {
        return <ArrowBackIcon {...iconProps} />;
      }
      case "plus": {
        return <PlusIcon {...iconProps} />;
      }
      case "filter": {
        return <FilterIcon {...iconProps} />;
      }
      case "search": {
        return <SearchIcon {...iconProps} />;
      }
      case "edit": {
        return <EditIcon {...iconProps} />;
      }
      case "inventory": {
        return <Inventory {...iconProps} />;
      }
      case "cloud-upload": {
        return <CloudUploadIcon {...iconProps} />;
      }
      case "add-circle": {
        return <AddCircleIcon {...iconProps} />;
      }
      case "add-file": {
        return <AddFileIcon {...iconProps} />;
      }
      case "clock-icon": {
        return <ClockIcon {...iconProps} />;
      }
      case "check-mark": {
        return <CheckMarkIcon {...iconProps} />;
      }
      case "check-mark-blue": {
        return <CheckMarkBlueIcon {...iconProps} />;
      }
      case "check-mark-outline": {
        return <CheckMarkOutlineIcon {...iconProps} />;
      }
      case "cancel": {
        return <CancelIcon {...iconProps} />;
      }
      case "cancel-close-outline": {
        return <CancelOutlineIcon {...iconProps} />;
      }
      case "accounts": {
        return <AccountsIcon {...iconProps} />;
      }
      case "log-out": {
        return <LogOutIcon {...iconProps} />;
      }
      case "contacts": {
        return <ContactsIcon {...iconProps} />;
      }
      case "more-grid": {
        return <MoreGridIcon {...iconProps} />;
      }
      case "company-settings": {
        return <CompanySettingsIcon {...iconProps} />;
      }
      case "inventory-list": {
        return <InventoryIcon {...iconProps} />;
      }
      case "not-invited": {
        return <NotInvitedIcon {...iconProps} />;
      }
      case "sort-desc": {
        return <SortDescIcon {...iconProps} />;
      }
      case "eye-icon": {
        return <EyeIcon {...iconProps} />;
      }
      case "cp-change-orders": {
        return <CpChangeOrdersIcon {...iconProps} />;
      }
      case "cp-customers": {
        return <CpCustomersIcon {...iconProps} />;
      }
      case "cp-internal-users": {
        return <CpInternalUsersIcon {...iconProps} />;
      }
      case "cp-invoices": {
        return <CpInvoicesIcon {...iconProps} />;
      }
      case "cp-locations": {
        return <CpLocationsIcon {...iconProps} />;
      }
      case "cp-material-going-to-site": {
        return <CpMaterialGoingToSiteIcon {...iconProps} />;
      }
      case "cp-material-receipt-inspection": {
        return <CpMaterialReceiptInspectionIcon {...iconProps} />;
      }
      case "cp-material-transfer": {
        return <CpMaterialTransferIcon {...iconProps} />;
      }
      case "cp-products": {
        return <CpProductsIcon {...iconProps} />;
      }
      case "cp-projects": {
        return <CpProjectsIcon {...iconProps} />;
      }
      case "cp-purchase-orders": {
        return <CpPurchaseOrdersIcon {...iconProps} />;
      }
      case "cp-reorders": {
        return <CpReordersIcon {...iconProps} />;
      }
      case "cp-vendors": {
        return <CpVendorsIcon {...iconProps} />;
      }
      case "product-name": {
        return <ProductNameTitleIcon {...iconProps} />;
      }
      case "action-item-icon": {
        return <ActionItemIcon {...iconProps} />;
      }
      case "cart-icon": {
        return <CartIcon {...iconProps} />;
      }
      case "done-all-icon": {
        return <DoneAllIcon {...iconProps} />;
      }
      case "thumb-down-icon": {
        return <ThumbDownIcon {...iconProps} />;
      }
      case "reorder-icon": {
        return <ReorderIcon {...iconProps} />;
      }
      case "truck-icon": {
        return <TruckIcon {...iconProps} />;
      }
      case "partial-delivered-icon": {
        return <PartialDeliveredIcon {...iconProps} />;
      }
      case "low-stock-icon": {
        return <LowStockIcon {...iconProps} />;
      }
      case "calendar-icon": {
        return <CalendarIcon {...iconProps} />;
      }
      case "timelapse-icon": {
        return <TimelapseIcon {...iconProps} />;
      }
      case "clock-gray-icon": {
        return <ClockGrayIcon {...iconProps} />;
      }
      case "truck-pink-icon": {
        return <TruckPinkIcon {...iconProps} />;
      }
      case "pie-chart-icon": {
        return <PieChartIcon {...iconProps} />;
      }
      case "budget-analysis-icon": {
        return <BudgetAnalysisIcon {...iconProps} />;
      }
      case "project-details-icon": {
        return <ProjectDetailsIcon {...iconProps} />;
      }
      case "calendar-green-icon": {
        return <CalendarGreenIcon {...iconProps} />;
      }
      case "dollar-icon": {
        return <DollarIcon {...iconProps} />;
      }
      case "owner-icon": {
        return <OwnerIcon {...iconProps} />;
      }
      case "project-manager-icon": {
        return <ProjectManagerIcon {...iconProps} />;
      }
      case "cart-gray-icon": {
        return <CartGrayIcon {...iconProps} />;
      }
      case "dislike-icon": {
        return <PODisLikeIcon {...iconProps} />;
      }
      case "download-icon": {
        return <DownloadIcon {...iconProps} />;
      }

      // Dashboard Icons
      case "dashboard-invoice-icon": {
        return <DashboardInvoiceIcon />;
      }
      case "dashboard-low-stock-icon": {
        return <DashboardLowStockIcon />;
      }
      case "dashboard-material-receipt-inspection-icon": {
        return <DashboardMaterialReceiptInspectionIcon />;
      }
      case "dashboard-material-transfer-to-site-icon": {
        return <DashboardMaterialTransferToSiteIcon />;
      }
      case "dashboard-material-transfer-icon": {
        return <DashboardMaterialTransferIcon />;
      }
      case "dashboard-material-expected-icon": {
        return <DashboardMaterialExpectedIcon />;
      }
      case "dashboard-partial-delivered-icon": {
        return <DashboardPartialDeliveredIcon />;
      }
      case "dashboard-purchase-order-icon": {
        return <DashboardPurchaseOrderIcon />;
      }
      case "dashboard-reorder-icon": {
        return <DashboardReorderIcon />;
      }
      case "dashboard-submittal-due-icon": {
        return <DashboardSubmittalDueIcon />;
      }
      case "dashboard-changeOrder-icon": {
        return <DashboardChangeOrder />;
      }

      default: {
        console.error(props.type, "Icon type not added");
        return <></>;
      }
    }
  }

  if (props.hasContainer) {
    return (
      <Flex
        justify="center"
        align="center"
        style={{
          width: props?.containerWidth || 0,
          height: props?.containerHeight || 0,
        }}
      >
        {renderIcon()}
      </Flex>
    );
  } else {
    return renderIcon();
  }
}
