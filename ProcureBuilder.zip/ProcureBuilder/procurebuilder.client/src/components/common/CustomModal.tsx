import { Modal } from "antd";
import { ReactNode } from "react";

type CustomModalProps = {
  title: string;
  width?: number;
  height?: number;
  isOpen: boolean;
  isLoading?: boolean;
  children: ReactNode;
  primaryButtonText?: string;
  primaryButtonLoadingText?: string;
  isPrimaryButtonDisabled?: boolean;
  isPrimaryButtonHidden?: boolean;

  cancelButtonText?: string;

  isfooter?: ReactNode;
  primaryButtonAction?: () => void;
  cancelButtonAction?: () => void;
};

export default function CustomModal(props: CustomModalProps) {
  return (
    <>
      <Modal
        confirmLoading={props?.isLoading || false}
        width={props?.width || 1600}
        title={props.title}
        open={props.isOpen}
        onOk={props.primaryButtonAction}
        footer={props.isfooter}
        onCancel={props.cancelButtonAction}
        cancelText={props?.cancelButtonText || "Cancel"}
        okText={
          props.isLoading && props.primaryButtonLoadingText
            ? props.primaryButtonLoadingText
            : props.primaryButtonText
        }
        okButtonProps={{
          disabled: props?.isPrimaryButtonDisabled || false,
          style: {
            display: (props?.isPrimaryButtonHidden && "none") || "",
          },
        }}
      >
        {props.children}
      </Modal>
    </>
  );
}
