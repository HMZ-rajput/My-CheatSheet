import CustomIcon from "./CustomIcon";

export type InternalUserBadgeTypes = "Invite Pending" | "Active" | "Removed";
export type InternalUserStatusIconTypes = "clock-icon"
  | "check-mark"
  | "cancel"
type InternalUserStatusProps = {
  badgeIconType: InternalUserStatusIconTypes;
  badgeType: InternalUserBadgeTypes;
};

export function InternalUserStatus(props: InternalUserStatusProps) {
  return (
    <span
      className={`inline-flex items-center rounded-md px-2 py-1 text-xs font-medium bg-transparent border border-neutral-5`}
    >
      <CustomIcon className="mr-1" type={props.badgeIconType} width={13} />
      {props.badgeType}
    </span>
  );
}
