export type InvoicesBadgeTypes = "Pending" | "Partially Paid" | "Fully Paid";
type InvoicesStatusProps = {
  badgeType: InvoicesBadgeTypes;
};

export default function InvoicesStatus(props: InvoicesStatusProps) {
  let colorStylesClasses: string;

  switch (props.badgeType) {
    case "Fully Paid":
      colorStylesClasses = "bg-green-4-12 text-green-4";
      break;
    case "Partially Paid":
      colorStylesClasses = "bg-blue-1-12 text-blue-1";
      break;
    default:
      colorStylesClasses = "bg-gray-1-12 text-gray--12";
      break;
  }

  return (
    <span
      className={`inline-flex items-center rounded-md ${colorStylesClasses} px-2 py-1 text-xs font-medium whitespace-nowrap`}
    >
      {props.badgeType}
    </span>
  );
}
