interface ICustomListTags<T> {
  data?: T[];
  className?: string;
}

const CustomListTags = <T extends { name: string | null }>({
  data = [],
  className = "",
}: ICustomListTags<T>) => {
  return (
    <ul className={`${className}`}>
      {data?.map((val, index) => (
        <li key={index}>{val?.name}</li>
      ))}
    </ul>
  );
};

export default CustomListTags;
