import { dateFormatDetailed } from "@/src/utils/constants";
import { getFullNameInitials } from "@/src/utils/general-helpers";
import { Avatar } from "antd";
import dayjs from "dayjs";

type CreatedByUserBadgeProps = {
  userName?: string;
  date?: Date | null;
  isModifiedBadge?: boolean;
  isUpdatedBadge?: boolean;
};

export default function CreatedByUserBadge(props: CreatedByUserBadgeProps) {
  const date = dayjs(props.date).format(dateFormatDetailed);

  return (
    <div className="flex items-center px-3 py-2 rounded-lg bg-primary25">
      <p className="font-normal text-sm text-black900">
        {props.isModifiedBadge ? "Modified" : props.isUpdatedBadge ? "Updated" : "Created"} by{" "}
        <Avatar className="h-6 w-6 bg-pink3">
          {getFullNameInitials(props?.userName || "")}
        </Avatar>{" "}
        {props.userName} on {date}
      </p>
    </div>
  );
}
