export type MaterialTransferBadgeTypes = "Pending" | "In-Progress" | "Transferred" | "Cancelled";
type MaterialTransferStatusProps = {
  badgeType: MaterialTransferBadgeTypes;
};

export default function MaterialTransferStatus(props: MaterialTransferStatusProps) {
  let colorStylesClasses: string;

  switch (props.badgeType) {
    case "Transferred":
      colorStylesClasses = "bg-green-4-12 text-green-4";
      break;
    case "In-Progress":
      colorStylesClasses = "bg-purple-5-12 text-purple-5";
      break;
      case "Cancelled":
      colorStylesClasses = "bg-danger-5-14 text-danger-5";
      break;
    default:
      colorStylesClasses = "bg-gray-1-12 text-gray--12";
      break;
  }

  return (
    <span
      className={`inline-flex items-center rounded-md ${colorStylesClasses} px-2 py-1 text-xs font-medium whitespace-nowrap`}
    >
      {props.badgeType}
    </span>
  );
}
