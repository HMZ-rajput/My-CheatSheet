import { Button, ConfigProvider } from "antd";
import { BaseButtonProps } from "antd/es/button/button";
import useToken from "@hooks/useToken";

type CustomButtonProps = BaseButtonProps & {
  onClick: React.MouseEventHandler<HTMLElement> | undefined;
  variant?: "solid" | "outlined";
  type?: "primary" | "secondary";
  icon?: React.ReactNode;
};

export default function CustomButton(props: CustomButtonProps) {
  const token = useToken();

  const variant = props.variant || "solid";

  return (
    <>
      {variant === "outlined" ? (
        <Button {...props} onClick={props.onClick}>
          {props.children}
        </Button>
      ) : variant === "solid" ? (
        <ConfigProvider
          theme={{
            components: {
              Button: {
                defaultBg: token.colorNeutral9,
                defaultHoverBg: token.colorNeutral8,
                defaultActiveBg: token.colorNeutral8,

                defaultColor: token.colorWhite,
                defaultHoverColor: token.colorWhite,
                defaultHoverBorderColor: token.colorWhite,
              },
            },
          }}
        >
          <Button
            icon={props?.icon}
            {...props}
            onClick={props.onClick}
            type={props?.type}
          >
            {props.children}
          </Button>
        </ConfigProvider>
      ) : null}
    </>
  );
}
