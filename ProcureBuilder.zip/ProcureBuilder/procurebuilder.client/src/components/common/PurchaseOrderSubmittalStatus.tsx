export type PurchaseOrdersSubmittalBadgeTypes =
  | "Pending"
  | "Recieved"
  | "Under Review"
  | "No Exceptions Taken"
  | "Approved As Noted"
  | "Revise & Resubmit"
  | "Rejected";
type PurchaseOrdersSubmittalBadgeStatusTypes = {
  badgeType: PurchaseOrdersSubmittalBadgeTypes;
};
import { Badge, Button } from "antd";

export default function PurchaseOrderSubmittalStatus(
  props: PurchaseOrdersSubmittalBadgeStatusTypes
) {
  let statusBasedColor: string;


  switch (props.badgeType) {
    case "Pending":
      statusBasedColor = "#747786";
      break;
    case "Recieved":
      statusBasedColor = "#735FCC";
      break;
    case "Under Review":
      statusBasedColor = "#FF8C00";
      break;
    case "No Exceptions Taken":
      statusBasedColor = "#38C793";
      break;
    case "Approved As Noted":
      statusBasedColor = "#525866";
      break;
    case "Revise & Resubmit":
      statusBasedColor = "#FF7373 ";
      break;
    case "Rejected":
      statusBasedColor = "#DF1C41";
      break;
    default:
      statusBasedColor = "#747786";
      break;
  }

  return (
    <>
      <Button style={{ borderColor: "#E2E4E9", cursor: "default" }}>
        <Badge
          color={statusBasedColor}
          text={props.badgeType}
          style={{ color: statusBasedColor }}
        />
      </Button>
    </>
  );
}
