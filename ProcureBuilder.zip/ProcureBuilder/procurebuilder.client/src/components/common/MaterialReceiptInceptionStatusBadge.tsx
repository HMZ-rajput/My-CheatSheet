export type MaterialReceiptInspectionBadgeTypes =
  | "Pending"
  | "Approved"
  | "Approved with Exceptions"
  | "Rejected";
type MaterialReceiptInspectionsStatusProps = {
  badgeType: MaterialReceiptInspectionBadgeTypes;
};

export default function MaterialReceiptInspectionStatus(
  props: MaterialReceiptInspectionsStatusProps
) {
  let colorStylesClasses: string;

  switch (props.badgeType) {
    case "Approved":
      colorStylesClasses = "bg-green-4-12 text-green-4";
      break;
    case "Approved with Exceptions":
      colorStylesClasses = "bg-blue-1-12 text-blue-1";
      break;
    case "Rejected":
      colorStylesClasses = "bg-danger-5-12 text-danger-5";
      break;
    case "Pending":
      colorStylesClasses = "bg-gray-1-12 text-gray-1";
      break;
    default:
      colorStylesClasses = "bg-gray-1-12 text-gray-1";
      break;
  }

  return (
    <span
      className={`inline-flex items-center rounded-md ${colorStylesClasses} px-2 py-1 text-xs font-medium`}
    >
      {props.badgeType}
    </span>
  );
}
