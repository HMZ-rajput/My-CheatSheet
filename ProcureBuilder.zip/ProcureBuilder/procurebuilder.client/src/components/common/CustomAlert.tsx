import { Alert } from "antd";

type CustomAlertProps = {
  message: string;
  type: "success" | "info" | "warning" | "error";
  hasMargin?: boolean;
};
export default function CustomAlert({
  message,
  type,
  hasMargin = true,
}: CustomAlertProps) {
  return (
    <Alert
      className={`w-full ${hasMargin ? "mt-4 mb-8" : ""}`}
      message={message}
      type={type}
      showIcon
    />
  );
}
