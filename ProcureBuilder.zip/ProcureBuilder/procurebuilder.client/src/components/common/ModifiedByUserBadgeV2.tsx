import { dateFormatDetailed } from "@/src/utils/constants";
import { getFullNameInitials } from "@/src/utils/general-helpers";
import { Avatar } from "antd";
import dayjs from "dayjs";

type ModifiedByUserBadgeV2Props<T> = {
  userName?: string;
  date?: Date | null;

  isModifiedBadge?: boolean;

  data: T & {
    modifiedDate: Date;
    modifiedBy: string;
    createdDate: Date;
    createdBy: string;
  };
};

export default function ModifiedByUserBadgeV2<T>(
  props: ModifiedByUserBadgeV2Props<T>
) {
  const isModified = props?.data?.modifiedDate;

  const name =
    props?.data?.modifiedBy || props?.data?.createdBy
      ? isModified
        ? props?.data?.modifiedBy
        : props?.data?.createdBy
      : "";

  const date =
    props?.data?.modifiedDate || props?.data?.createdDate
      ? dayjs(
          isModified ? props?.data?.modifiedDate : props?.data?.createdDate
        ).format(dateFormatDetailed)
      : "";

  return (
    <div className="flex items-center px-3 py-2 rounded-lg bg-primary25">
      <p className="font-normal text-sm text-black900">
        {props?.data?.modifiedDate ? "Modified" : "Created"} by{" "}
        <Avatar className="h-6 w-6 bg-pink3">
          {getFullNameInitials(name)}
        </Avatar>{" "}
        {name} on {date}
      </p>
    </div>
  );
}
