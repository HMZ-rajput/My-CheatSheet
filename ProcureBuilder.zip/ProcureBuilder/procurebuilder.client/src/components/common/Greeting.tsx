import React, { useMemo } from "react";
import { useAppSelector } from "@hooks/useAppSelector";
import useToken from "@hooks/useToken";
import { getUserState } from "@store/slices/userSlice";
import { Flex, Typography } from "antd";

const Greeting = React.memo(() => {
  const { data } = useAppSelector(getUserState);
  const token = useToken();

  const greeting = useMemo(() => {
    const hour = new Date().getHours();
    if (hour < 12) {
      return "Good Morning";
    } else if (hour < 18) {
      return "Good Afternoon";
    } else {
      return "Good Evening";
    }
  }, []);

  function getDisplayName() {
    let displayName = "";

    if (data?.firstName || data?.lastName) {
      if (data?.firstName) {
        displayName = data.firstName;
      }

      if (data?.lastName) {
        displayName = `${displayName} ${data.lastName}`;
      }
    } else if (data?.userName) {
      displayName = data.userName;
    } else {
      displayName = "";
    }

    return displayName;
  }

  return (
    <Flex
      style={{
        border: `1px solid ${token.colorBorder}`,
      }}
      className="w-full rounded-2xl px-6 py-4"
    >
      <Typography.Title
        className="font-medium !text-xl"
        level={3}
        style={{ margin: 0 }}
      >
        {greeting}, {getDisplayName()}
      </Typography.Title>
    </Flex>
  );
});

export default Greeting;
