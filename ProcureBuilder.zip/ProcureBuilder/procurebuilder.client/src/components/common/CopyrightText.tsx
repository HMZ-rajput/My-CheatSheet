import { Typography } from "antd";

export default function CopyrightText() {
  return (
    <Typography.Paragraph style={{ margin: 0 }}>
      © {new Date().getFullYear()} Procure Builder
    </Typography.Paragraph>
  );
}
