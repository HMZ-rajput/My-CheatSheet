import React from "react";
import { Upload, Button } from "antd";
import { UploadFile } from "antd/es/upload";
import { UseFormGetValues, UseFormSetValue } from "react-hook-form";
import { FileOutlined } from "@ant-design/icons";

type DynamicUploadComponentProps = {
  fieldName: string;
  deletedFileName?: string;
  maxCount?: number;
  hasOnlyImages?: boolean;
  hasOnlyText?: boolean;
  buttonText: string;
  buttonIcon?: React.ReactNode;
  buttonClassName?: string;

  setValue: UseFormSetValue<any>;
  getValues: UseFormGetValues<any>;
  onFileChange?: (fileList: UploadFile[]) => void;
  disabled?: boolean;
};

const CustomFileUploadRHF: React.FC<DynamicUploadComponentProps> = ({
  fieldName,
  hasOnlyImages = false,
  hasOnlyText = false,
  deletedFileName,
  buttonText,
  buttonIcon,
  maxCount = 1,
  buttonClassName = "",
  setValue,
  getValues,
  onFileChange,
  disabled,
}) => {
  const handleRemove = (file: UploadFile) => {
    const newFileList = (getValues(fieldName) as UploadFile[]).filter(
      (f) => f.uid !== file.uid
    );
    setValue(fieldName, newFileList);

    if (deletedFileName) {
      const deletedFiles = getValues(deletedFileName) || [];
      const fileId = (file as any).id || file.uid;
      if (fileId && !deletedFiles.includes(fileId)) {
        setValue(deletedFileName, [...deletedFiles, fileId]);
      }
    }
  };

  const handleChange = ({ fileList }: { fileList: UploadFile[] }) => {
    const formattedFileList = fileList.map((file) => {
      return {
        ...file,
        originFileObj: file.originFileObj || file,
      };
    });

    if (onFileChange) {
      setValue("invitationMessage", "");
      onFileChange(formattedFileList as UploadFile[]);
    } else {
      setValue(fieldName, formattedFileList);
    }
  };

  return (
    <>
      <Upload
        disabled={disabled}
        className="custom-file-upload-container"
        accept={
          hasOnlyImages
            ? ".png,.jpg,.jpeg"
            : hasOnlyText
            ? ".txt,.docx,.doc"
            : ".png,.jpg,.jpeg,.xlsx,.xls,.csv,.doc,.docx,.txt,.pdf"
        }
        fileList={getValues(fieldName) as UploadFile[]}
        onRemove={handleRemove}
        beforeUpload={() => false}
        onChange={handleChange}
        maxCount={maxCount}
        multiple={maxCount > 1}
        iconRender={() => (
          <>
            <FileOutlined />
          </>
        )}
      >
        <Button
          disabled={disabled}
          size="large"
          className={buttonClassName}
          icon={buttonIcon}
        >
          {buttonText}
        </Button>
      </Upload>
    </>
  );
};

export default CustomFileUploadRHF;
