import { Tag, Typography } from "antd"
import { ProjectStatusEnum, TagTypeEnum } from "@utils/enums"
import useToken from "@hooks/useToken"
import { getConsistentSpacing } from "@utils/theme-helpers"
import { getStatusLabelByEnumValue } from "@/src/utils/general-helpers"

type CustomTagProps = {
  status: ProjectStatusEnum
  type?: TagTypeEnum
  isWide?: boolean
}

export default function CustomTag(props: CustomTagProps) {
  const token = useToken()

  function getColorByType() {
    let bgColor = ""
    let color = ""

    switch (props.type) {
      case TagTypeEnum.GREEN: {
        bgColor = token.green1
        color = token.green5
        break
      }

      case TagTypeEnum.ORANGE: {
        bgColor = token.orange1
        color = token.orange5
        break
      }

      default: {
        bgColor = token.green1
        color = token.green5
        break
      }
    }

    return { bgColor, color }
  }

  return (
    <>
      <Tag
        style={{ borderRadius: getConsistentSpacing(1) }}
        bordered={false}
        color={getColorByType().bgColor}
      >
        <Typography.Paragraph
          style={{
            color: getColorByType().color,
            fontWeight: 500,
            minWidth: props.isWide ? getConsistentSpacing(10.25) : "auto",
            paddingInline: getConsistentSpacing(1),
            margin: 0,
            textAlign: "center",
          }}
        >
          {getStatusLabelByEnumValue(props.status)?.toUpperCase()}
        </Typography.Paragraph>
      </Tag>
    </>
  )
}
