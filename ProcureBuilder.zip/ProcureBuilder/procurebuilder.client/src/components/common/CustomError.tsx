type PropsError = {
  errors: { message: string };
  //   touched :{}
};

const CustomError = ({ errors }: PropsError) => {
  return <div>{errors?.message}</div>;
};

export default CustomError;
