import Loader from "./Loader";

const CustomOverlayLoader = () => {
  return (
    <div className="fixed inset-0  z-[1000] backdrop-blur-sm">
      <div className="h-full w-full flex items-center justify-center">
        <Loader />
      </div>
    </div>
  );
};

export default CustomOverlayLoader;
