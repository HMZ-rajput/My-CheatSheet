export type ReordersBadgeTypes =
  | "Pending Re-quote"
  | "Quote Received"
  | "P.O. Created";
type ReordersStatusProps = {
  badgeType: ReordersBadgeTypes;
};

export default function ReorderStatus(props: ReordersStatusProps) {
  let colorStylesClasses: string;

  switch (props.badgeType) {
    case "P.O. Created":
      colorStylesClasses = "bg-green-4-12 text-green-4";
      break;
    case "Quote Received":
      colorStylesClasses = "bg-purple-5-12 text-purple-5";
      break;
    default:
      colorStylesClasses = "bg-orange-5-12 text-orange-5";
      break;
  }

  return (
    <span
      className={`inline-flex items-center rounded-md ${colorStylesClasses} px-2 py-1 text-xs font-medium`}
    >
      {props.badgeType}
    </span>
  );
}
