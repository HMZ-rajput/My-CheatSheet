import { Select, Button, Flex } from "antd";
import React from "react";
import CustomIcon, { IconType } from "../common/CustomIcon";

type CustomFilterOptionType = {
  value: string | number | null;
  label: string;
};

export enum CustomFilterDataType {
  STR = "string",
  NUM = "number",
}

export type CustomFilterChildType = {
  options: CustomFilterOptionType[];
  value: number | string | null;
  suffixIcon?: IconType | null;
  isHidden?: boolean;
  className?: string;
  dataType?: CustomFilterDataType;
};

export type CustomFiltersType = { [key: string]: CustomFilterChildType };

type ButtonConfigType = {
  value: string;
  isActive: boolean;
  onClick: (value: string) => void;
  label: string;
};

type CustomTableFiltersType = {
  filters?: CustomFiltersType;
  setFilters?: React.Dispatch<React.SetStateAction<CustomFiltersType>>;
  buttons?: ButtonConfigType[];
};

export default function CustomTableFilters(props: CustomTableFiltersType) {
  const { filters, setFilters, buttons } = props;

  const handleChange = (filterName: string, value: string | number) => {
    setFilters?.((prev) => {
      const currentFilter = prev[filterName];

      return { ...prev, [filterName]: { ...currentFilter, value } };
    });
  };

  return (
    <>
      <Flex align="center" className="w-full">
        {buttons?.map((button, index) => (
          <Button
            key={`button-${index}`}
            onClick={() => button.onClick(button.value)}
            // onClick={button.onClick}
            size="large"
            className={button.isActive ? "text-primary" : "text-transparent"}
            style={{
              marginRight: 8,
              width: "100%",
              // backgroundColor: , // added dummy colors
            }}
          >
            {button.label}
          </Button>
        ))}
        {Object.entries(filters || [])
          .filter(([_, value]) => !value.isHidden)
          .map(([filterName, filterObj]) => (
            <React.Fragment key={`filter-${filterName}`}>
              <Select
                className={filterObj?.className || ""}
                suffixIcon={
                  filterObj?.suffixIcon && (
                    <CustomIcon
                      className="w-4"
                      type={`${filterObj?.suffixIcon}`}
                    />
                  )
                }
                size="large"
                value={filterObj.value}
                onChange={(value) => handleChange(filterName, value)}
                style={{ marginRight: 8, width: "100%" }}
                options={filterObj.options}
                showSearch
                filterOption={(input, option) =>
                  (option?.label ?? "")
                    .toLowerCase()
                    .includes(input.toLowerCase())
                }
              />
            </React.Fragment>
          ))}
      </Flex>
    </>
  );
}
