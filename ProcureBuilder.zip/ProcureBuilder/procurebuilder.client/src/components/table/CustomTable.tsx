import useSyncFilters from "@/src/hooks/useSyncFilters";
import { getConsistentSpacing } from "@/src/utils/theme-helpers";
import { Col, Divider, Flex, Input, Table } from "antd";
import { AnyObject } from "antd/es/_util/type";
import { ColumnsType } from "antd/es/table";
import { TableRowSelection } from "antd/es/table/interface";
import React, { useEffect, useRef } from "react";
import CustomButton from "../common/CustomButton";
import CustomIcon from "../common/CustomIcon";
import Loader from "../common/Loader";
import { CustomFilterDataType, CustomFiltersType } from "./CustomTableFilters";

export const defaultPageSizes = [10, 25, 50, 100];

type CustomTableProps<T> = {
  data: T[];
  columns: ColumnsType<T>;
  className?: string;
  isLoading?: boolean;
  totalCount?: number;
  tableFilters?: CustomFiltersType;
  setTableFilters?: React.Dispatch<React.SetStateAction<CustomFiltersType>>;
  filterElements?: React.ReactNode;
  customTopLayout?: React.ReactNode;
  filterElementContainFullWidth?: boolean;

  page?: number;
  setPage?: React.Dispatch<React.SetStateAction<number>>;

  pageSize?: number;
  setPageSize?: React.Dispatch<React.SetStateAction<number>>;

  lastSearchTimestamp?: number;
  searchTerm?: string;
  handleSearch?: () => void;
  setSearchTerm?: React.Dispatch<React.SetStateAction<string>>;

  dueTimeButtons?: {
    label: string;
    value: string;
    isActive: boolean;
    onClick: (value: string) => void;
  }[];
  updateDueTimeButtons?: (value: string) => void;

  hasRowSelection?: boolean;
  hasPagination?: boolean;
  rowSelection?: TableRowSelection<T>;
  hasCursorPointer?: boolean;
  hasDetailedColumns?: boolean;
  hasSearch?: boolean;
  hasSearchInNextLine?: boolean;
  hasBorders?: boolean;
  searchPlaceholder?: string;
  isInsideReports?: boolean;
  exportButtonEl?: React.ReactNode | null;
  hideSearchBtn?: boolean;
  hasTopBar?: boolean;
  isSmallTable?: boolean;
  isNormalTable?: boolean;
  onRowClick?: (record: T) => void;
  reportFilterForParamsUseOnly?: any;
};

function CustomTable<T extends AnyObject>({
  hasSearch = true,
  hasRowSelection = false,
  isInsideReports = false,
  exportButtonEl = null,
  hideSearchBtn = false,
  hasTopBar = true,
  isSmallTable = false,
  isNormalTable = false,
  reportFilterForParamsUseOnly = null,
  ...props
}: CustomTableProps<T>) {
  const {
    tableFilters,
    setTableFilters,
    data,
    columns,
    isLoading,
    totalCount,
    filterElements,
    searchTerm,
    setSearchTerm,
    setPage,
    page,
    pageSize,
    setPageSize,
    handleSearch,
    filterElementContainFullWidth,
    customTopLayout,
    rowSelection,
    hasSearchInNextLine,
    searchPlaceholder = "Search...",
    lastSearchTimestamp,

    dueTimeButtons,
    updateDueTimeButtons,
  } = props;

  const previousDueTimeButton = useRef("");
  const previousFiltersJson = useRef("");
  const { searchParams, updateSearchParams } = useSyncFilters();
  const defaultTableFilters = useRef(tableFilters);

  const maxNum = 2147483647;
  const total = totalCount || 0;

  const pageSizes = [
    isSmallTable ? 5 : null,
    ...defaultPageSizes,
    isInsideReports ? maxNum : null,
  ].filter((f) => f !== null);
  const sizeChangerOptions = pageSizes.map((size) => ({
    value: String(size),
    label: size === maxNum ? "All Records" : `${size} / page`,
  }));

  useEffect(() => {
    const mappedTableFilters: {
      [key: string]: string | number | null;
    } = {};
    Object.entries(tableFilters || {}).forEach(([name, filter]) => {
      mappedTableFilters[name] =
        defaultTableFilters.current?.[name]?.value !== filter?.value
          ? filter?.value
          : null;
    });

    const activeDueTimeButton =
      dueTimeButtons?.find((d) => d.isActive)?.value || "";
    const filters: { [key: string]: any } = {
      page: page !== 1 ? page : undefined,
      pageSize: pageSize !== 10 ? pageSize : undefined,
      searchTerm: lastSearchTimestamp! > 0 ? searchTerm : undefined,
      ...mappedTableFilters,
    };

    if (
      previousFiltersJson.current === JSON.stringify(filters) &&
      (dueTimeButtons || [])?.length > 0 &&
      activeDueTimeButton === previousDueTimeButton.current
    )
      return;

    const params = new URLSearchParams(window.location.search);
    dueTimeButtons?.forEach((btn) => {
      if (btn.isActive) {
        if (params.has(btn.label)) {
          params.set(btn.label, "true");
        } else {
          params.append(btn.label, "true");
        }
        previousDueTimeButton.current = btn.label;
      } else if (params.has(btn.label)) {
        params.delete(btn.label);
      }
    });

    Object.entries(filters).forEach(([key, value]) => {
      const hasValue = value !== null && value !== undefined && value !== "";
      if (params.get(key) && !hasValue) {
        params.delete(key);
        return;
      }
      if (!params.get(key) && !hasValue) return;
      params.set(key, String(value));
    });

    if (reportFilterForParamsUseOnly) {
      const ignoredFilterParams = ["pageSize", "page", "searchTerm"];
      Object.entries(reportFilterForParamsUseOnly).forEach(([key, value]) => {
        const hasValue = value !== null && value !== undefined && value !== "";
        if (ignoredFilterParams?.includes(key)) return;
        if (params.get(key) && !hasValue) {
          params.delete(key);
          return;
        }
        if (!params.get(key) && !hasValue) return;
        params.set(key, String(value));
      });
    }

    setTimeout(() => {
      updateSearchParams(params);
      previousFiltersJson.current = JSON.stringify(filters);
    }, 100);
  }, [page, pageSize, lastSearchTimestamp, tableFilters, dueTimeButtons]);
  useEffect(() => {
    // if (!isSmallTable) return;

    const page = searchParams.get("page");
    const pageSize = searchParams.get("pageSize");
    const searchTerm = searchParams.get("searchTerm");

    // setTimeout(() => {
    if (typeof setPage === "function") setPage(Number(page) || 1);
    if (typeof setPageSize === "function")
      setPageSize(Number(pageSize) || (isSmallTable ? 5 : 10));
    if (typeof setSearchTerm === "function") setSearchTerm(searchTerm || "");
    // }, 500);

    const tableFilterEntries = Object.entries(tableFilters || {});
    const tableFilterValues: {
      [key: string]: string | number | null;
    } = {};
    tableFilterEntries.forEach(([name, filter]) => {
      let value: string | number | null = searchParams.get(name) || null;
      if (!value) return;
      if (filter.dataType === CustomFilterDataType.NUM) {
        value = Number(value);
      }

      tableFilterValues[name] = value;
    });
    // if (Object.keys(tableFilterValues).length === 0) return;

    if (
      typeof setTableFilters === "function" &&
      Object.keys(tableFilterValues).length !== 0
    ) {
      setTableFilters((prev) => {
        const previousCopy = { ...prev };

        Object.entries(tableFilterValues).forEach(([key, value]) => {
          previousCopy[key] = { ...(previousCopy[key] || {}), value };
        });

        return previousCopy;
      });
    }

    let dueTimeButtonKey = "";

    dueTimeButtons?.forEach((btn) => {
      const value: boolean = searchParams.get(btn.label) === "true";

      if (value) {
        dueTimeButtonKey = btn.value;
      }
    });

    if (typeof updateDueTimeButtons === "function")
      updateDueTimeButtons(dueTimeButtonKey);
  }, []);

  return (
    <>
      {customTopLayout}

      {hasTopBar && (
        <Flex justify="space-between">
          {hasSearch ? (
            <Flex className="gap-3">
              <Input
                value={searchTerm}
                onChange={(event) => {
                  if (typeof setSearchTerm === "function")
                    setSearchTerm(event?.target?.value);
                }}
                prefix={<CustomIcon type="search" />}
                placeholder={searchPlaceholder}
                style={{ maxWidth: getConsistentSpacing(49.5) }}
                onKeyDown={(e) => {
                  if (e.key === "Enter" && typeof handleSearch === "function") {
                    handleSearch();
                  }
                }}
              />
              {!hideSearchBtn && (
                <CustomButton
                  size={isInsideReports ? "middle" : "large"}
                  onClick={handleSearch}
                >
                  Search
                </CustomButton>
              )}
            </Flex>
          ) : null}
          <Flex
            className={`gap-3 ${
              filterElementContainFullWidth ? "w-full" : ""
            } `}
          >
            {filterElements}
            {exportButtonEl}
          </Flex>
        </Flex>
      )}
      {hasSearchInNextLine ? (
        <Flex className="gap-3 mt-5">
          <Col xs={12}>
            <Flex gap={10}>
              <Input
                size={isInsideReports ? "small" : "large"}
                value={searchTerm}
                onChange={(event) => {
                  if (typeof setSearchTerm === "function")
                    setSearchTerm(event?.target?.value);
                }}
                prefix={<CustomIcon type="search" />}
                placeholder={searchPlaceholder}
                onKeyDown={(e) => {
                  if (e.key === "Enter" && typeof handleSearch === "function") {
                    handleSearch();
                  }
                }}
                // style={{ maxWidth: getConsistentSpacing(109.5) }}
              />
              <CustomButton
                size={isInsideReports ? "middle" : "large"}
                onClick={handleSearch}
              >
                Search
              </CustomButton>
            </Flex>
          </Col>
        </Flex>
      ) : null}
      {hasSearch || filterElements ? (
        <Divider className={isInsideReports ? "my-4" : "my-6"} />
      ) : null}

      <Table
        className={props?.className || ""}
        data-compact={isInsideReports}
        loading={{ spinning: isLoading, indicator: <Loader /> }}
        style={{ width: "100%", overflowX: "auto" }}
        columns={columns}
        dataSource={data}
        rowKey="id"
        rowSelection={hasRowSelection ? rowSelection : undefined}
        onRow={(record) => {
          const handlers: React.HTMLAttributes<HTMLElement> = {};

          if (props.hasCursorPointer) {
            handlers.style = { cursor: "pointer" };
          }

          if (typeof props.onRowClick === "function") {
            handlers.onClick = () => props.onRowClick!(record);
          }

          return handlers;
        }}
        pagination={
          props.hasPagination
            ? {
                position: ["bottomRight"],
                current: page,
                pageSize: pageSize,
                pageSizeOptions: pageSizes,
                showSizeChanger: { options: sizeChangerOptions },
                total,
                showTotal: (total) => "Total: " + total,
                onChange: (page, pageSize) => {
                  if (typeof setPageSize === "function") setPageSize(pageSize);
                  if (typeof setPage === "function") setPage(page);
                },
              }
            : false
        }
        scroll={
          isNormalTable ? { y: 300 } : isSmallTable ? { y: 150 } : undefined
        }
      />
    </>
  );
}

export default CustomTable;
