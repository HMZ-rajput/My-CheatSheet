import { Material } from "@/src/utils/types";
import { FormikErrors } from "formik";

type ValidateStatusParams = {
  formik: any;
  field: keyof Material;
  index: number;
};

export const getValidateStatus = ({
  formik,
  field,
  index,
}: ValidateStatusParams): string => {
  const isTouched = formik.touched.materials?.[index]?.[field];
  const isError = (formik.errors.materials as FormikErrors<Material[]>)
    ? (formik.errors.materials as FormikErrors<Material[]>)[index]?.[field]
    : undefined;

  return isTouched && isError ? "error" : "";
};

export const getHelpMessage = ({
  formik,
  field,
  index,
}: ValidateStatusParams): string => {
  const isTouched = formik.touched.materials?.[index]?.[field];
  const errorMessage = (formik.errors.materials as FormikErrors<Material[]>)
    ? (formik.errors.materials as FormikErrors<Material[]>)[index]?.[field]
    : undefined;

  return isTouched && errorMessage ? errorMessage : "";
};
