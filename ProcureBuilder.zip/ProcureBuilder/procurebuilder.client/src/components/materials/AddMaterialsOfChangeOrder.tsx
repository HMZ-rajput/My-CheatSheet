import CustomIcon from "@/src/components/common/CustomIcon";
import CustomFormRow from "@/src/components/form/CustomFormRow";
import DeleteIconButton from "@/src/components/icon-buttons/DeleteIconButton";
import useAuthorization from "@/src/hooks/useAuthorization";
import { ChangeOrderStatusEnum } from "@/src/utils/enums";
import { convertToLocaleString } from "@/src/utils/helper";
import { formatDecimalsOnlyTwo } from "@/src/utils/number-extensions";
import { ChangeOrder } from "@/src/utils/types";
import {
  Button,
  Col,
  Flex,
  Form,
  Input,
  InputNumber,
  Row,
  Typography,
} from "antd";
import {
  Control,
  Controller,
  useFieldArray,
  UseFormGetValues,
} from "react-hook-form";

const { Text } = Typography;

type AddMaterialOfChangeOrderProps = {
  control: Control<ChangeOrder>;
  shouldDisable: boolean;
  getValues: UseFormGetValues<ChangeOrder>;
  handleUpdateTotals: () => void;
};

export default function AddMaterialOfChangeOrder({
  control,
  shouldDisable,
  getValues,
  handleUpdateTotals,
}: AddMaterialOfChangeOrderProps) {
  const { isFieldsCraftAuthorized } = useAuthorization();

  const {
    fields: materialFields,
    append: appendMaterial,
    remove: removeMaterial,
  } = useFieldArray({
    control,
    name: "materials",
  });

  const deleteMaterial = (index: number) => {
    removeMaterial(index);
    handleUpdateTotals();
  };

  const handleAddMaterial = () => {
    const newMaterial = {
      id: "",
      name: "",
      costCode: "",
      quantity: 0,
      unitOfMeasure: "",
      unitRate: 0,
      totalBudget: 0,
    };
    appendMaterial(newMaterial);
  };

  return (
    <div>
      {!isFieldsCraftAuthorized() ? (
        <div
          style={{ backgroundColor: "whitesmoke" }}
          className="py-1.5 px-2 rounded-lg mb-4"
        >
          <Row className="bg-slate-400">
            <Col xs={4} className="mr-1.5">
              <Text className="font-medium">Material</Text>
            </Col>
            <Col xs={4} className="mr-1.5">
              <Text className="font-medium">Cost Code</Text>
            </Col>
            <Col xs={3} className="mr-1.5">
              <Text className="font-medium">Quantity</Text>
            </Col>
            <Col xs={4} className="mr-1.5">
              <Text className="font-medium">Unit of Measurement</Text>
            </Col>
            <Col xs={4} className="mr-1.5">
              <Text className="font-medium">Unit Rate</Text>
            </Col>
            <Col xs={4} className="mr-1.5">
              <Text className="font-medium">Total Budget</Text>
            </Col>
          </Row>
        </div>
      ) : (
        <div
          style={{ backgroundColor: "whitesmoke" }}
          className="py-1.5 px-3 rounded-lg mb-4"
        >
          <Row className="bg-slate-400">
            <Col xs={6} className="">
              <Text className="font-medium">Material</Text>
            </Col>
            <Col xs={6} className="">
              <Text className="font-medium">Cost Code</Text>
            </Col>
            <Col xs={6} className="">
              <Text className="font-medium ml-2">Quantity</Text>
            </Col>
            <Col xs={6} className="">
              <Text className="font-medium ml-4">Unit of Measurement</Text>
            </Col>
          </Row>
        </div>
      )}

      {materialFields?.map((materials, index) => (
        <>
          {isFieldsCraftAuthorized() ? (
            <CustomFormRow key={materials.id}>
              {/* Material */}
              <Col xs={4}>
                <Controller
                  control={control}
                  name={`materials.${index}.name`}
                  render={({ field, formState: { errors } }) => {
                    const materialError = errors?.materials?.[index];
                    return (
                      <Form.Item
                        labelAlign="right"
                        help={materialError?.name?.message}
                        validateStatus={materialError?.name ? "error" : ""}
                      >
                        <Input
                          {...field}
                          value={field.value}
                          onChange={(value) => {
                            field.onChange(value);
                          }}
                          size="large"
                          placeholder="Material"
                        />
                      </Form.Item>
                    );
                  }}
                />
              </Col>
              <Col xs={2}></Col>
              {/* Cost Code */}
              <Col xs={4}>
                <Controller
                  control={control}
                  name={`materials.${index}.costCode`}
                  render={({ field, formState: { errors } }) => {
                    const materialError = errors?.materials?.[index];
                    return (
                      <Form.Item
                        labelAlign="right"
                        help={materialError?.costCode?.message}
                        validateStatus={materialError?.costCode ? "error" : ""}
                      >
                        <Input
                          {...field}
                          value={field.value}
                          onChange={(value) => {
                            field.onChange(value);
                          }}
                          size="large"
                          placeholder="Cost Code"
                        />
                      </Form.Item>
                    );
                  }}
                />
              </Col>
              <Col xs={2}></Col>
              {/* Quantity */}
              <Col xs={4}>
                <Controller
                  control={control}
                  name={`materials.${index}.quantity`}
                  render={({ field, formState: { errors } }) => {
                    const materialError = errors?.materials?.[index];
                    return (
                      <Form.Item
                        labelAlign="right"
                        help={materialError?.quantity?.message}
                        validateStatus={materialError?.quantity ? "error" : ""}
                      >
                        <InputNumber
                          {...field}
                          value={field.value}
                          onChange={(value) => {
                            field.onChange(value);
                            handleUpdateTotals();
                          }}
                          size="large"
                          type="number"
                          // min={0}
                          precision={0}
                          style={{ width: "100%" }}
                        />
                      </Form.Item>
                    );
                  }}
                />
              </Col>
              <Col xs={2}></Col>
              {/* Unit Of Measurement */}
              <Col xs={4}>
                <Controller
                  control={control}
                  name={`materials.${index}.unitOfMeasure`}
                  render={({ field, formState: { errors } }) => {
                    const materialError = errors?.materials?.[index];
                    return (
                      <Form.Item
                        labelAlign="right"
                        help={materialError?.unitOfMeasure?.message}
                        validateStatus={
                          materialError?.unitOfMeasure ? "error" : ""
                        }
                      >
                        <Input
                          {...field}
                          value={field.value}
                          onChange={(value) => {
                            field.onChange(value);
                          }}
                          size="large"
                          placeholder="FT"
                        />
                      </Form.Item>
                    );
                  }}
                />
              </Col>
            </CustomFormRow>
          ) : (
            <CustomFormRow key={materials.id}>
              {/* Material */}
              <Col xs={4}>
                <Controller
                  control={control}
                  name={`materials.${index}.name`}
                  render={({ field, formState: { errors } }) => {
                    const materialError = errors?.materials?.[index];
                    return (
                      <Form.Item
                        labelAlign="right"
                        help={materialError?.name?.message}
                        validateStatus={materialError?.name ? "error" : ""}
                      >
                        <Input
                          {...field}
                          value={field.value}
                          onChange={(value) => {
                            field.onChange(value);
                          }}
                          size="large"
                          placeholder="Material"
                        />
                      </Form.Item>
                    );
                  }}
                />
              </Col>

              {/* Cost Code */}
              <Col xs={4}>
                <Controller
                  control={control}
                  name={`materials.${index}.costCode`}
                  render={({ field, formState: { errors } }) => {
                    const materialError = errors?.materials?.[index];
                    return (
                      <Form.Item
                        labelAlign="right"
                        help={materialError?.costCode?.message}
                        validateStatus={materialError?.costCode ? "error" : ""}
                      >
                        <Input
                          {...field}
                          value={field.value}
                          onChange={(value) => {
                            field.onChange(value);
                          }}
                          size="large"
                          placeholder="Cost Code"
                        />
                      </Form.Item>
                    );
                  }}
                />
              </Col>

              {/* Quantity */}
              <Col xs={3}>
                <Controller
                  control={control}
                  name={`materials.${index}.quantity`}
                  render={({ field, formState: { errors } }) => {
                    const materialError = errors?.materials?.[index];
                    return (
                      <Form.Item
                        labelAlign="right"
                        help={materialError?.quantity?.message}
                        validateStatus={materialError?.quantity ? "error" : ""}
                      >
                        <InputNumber
                          {...field}
                          value={field.value}
                          onChange={(value) => {
                            field.onChange(value);
                            handleUpdateTotals();
                          }}
                          size="large"
                          type="number"
                          min={0}
                          precision={0}
                          style={{ width: "100%" }}
                        />
                      </Form.Item>
                    );
                  }}
                />
              </Col>

              {/* Unit Of Measurement */}
              <Col xs={4}>
                <Controller
                  control={control}
                  name={`materials.${index}.unitOfMeasure`}
                  render={({ field, formState: { errors } }) => {
                    const materialError = errors?.materials?.[index];
                    return (
                      <Form.Item
                        labelAlign="right"
                        help={materialError?.unitOfMeasure?.message}
                        validateStatus={
                          materialError?.unitOfMeasure ? "error" : ""
                        }
                      >
                        <Input
                          {...field}
                          value={field.value}
                          onChange={(value) => {
                            field.onChange(value);
                          }}
                          size="large"
                          placeholder="FT"
                        />
                      </Form.Item>
                    );
                  }}
                />
              </Col>

              {/* Unit Rate */}
              <Col xs={4}>
                <Controller
                  control={control}
                  name={`materials.${index}.unitRate`}
                  render={({ field, formState: { errors } }) => {
                    const materialError = errors?.materials?.[index];
                    return (
                      <Form.Item
                        labelAlign="right"
                        help={materialError?.unitRate?.message}
                        validateStatus={materialError?.unitRate ? "error" : ""}
                      >
                        <InputNumber
                          {...field}
                          value={field.value}
                          onChange={(value) => {
                            field.onChange(value);
                            handleUpdateTotals();
                          }}
                          size="large"
                          type="number"
                          min={0}
                          prefix="$"
                          style={{ width: "100%" }}
                        />
                      </Form.Item>
                    );
                  }}
                />
              </Col>

              {/* Total Budget */}
              <Col xs={4}>
                <Controller
                  control={control}
                  name={`materials.${index}.totalBudget`}
                  render={({ field, formState: { errors } }) => {
                    const materialError = errors?.materials?.[index];
                    return (
                      <Form.Item
                        labelAlign="right"
                        help={materialError?.totalBudget?.message}
                        validateStatus={
                          materialError?.totalBudget ? "error" : ""
                        }
                      >
                        <Input
                          disabled
                          {...field}
                          value={field.value}
                          onChange={(value) => {
                            field.onChange(value);
                          }}
                          size="large"
                          placeholder="$ 0.00"
                          readOnly
                        />
                      </Form.Item>
                    );
                  }}
                />
              </Col>

              {/* Delete Icon */}
              <Col className="mt-1" xs={1}>
                <DeleteIconButton
                  disabled={
                    (shouldDisable &&
                      getValues("status") === ChangeOrderStatusEnum.Approved) ||
                    getValues("status") ===
                      ChangeOrderStatusEnum.AddedToBidMaterial ||
                    getValues("status") === ChangeOrderStatusEnum.Rejected
                  }
                  handleDelete={() => deleteMaterial(index)}
                />
              </Col>
            </CustomFormRow>
          )}
        </>
      ))}

      {!isFieldsCraftAuthorized() && (
        <Flex justify="space-between">
          <Button
            className="border-0 shadow-none text-primary font-medium"
            size="small"
            icon={<CustomIcon width={16} type="add-circle" />}
            onClick={handleAddMaterial}
          >
            Add Material
          </Button>
        </Flex>
      )}

      <Flex justify="end" align="flex-end" vertical>
        <Controller
          name="otherCosts"
          control={control}
          render={({ field }) => (
            <Form.Item
              colon={false}
              layout="horizontal"
              initialValue={field.value || 0}
              label={
                <span
                  style={{
                    marginRight: "30px",
                    fontSize: "1.05rem",
                    textAlign: "left",
                  }}
                >
                  Other Costs
                </span>
              }
            >
              <InputNumber
                {...field}
                value={formatDecimalsOnlyTwo(field.value) || 0}
                onChange={(value) => {
                  field.onChange(value);
                  handleUpdateTotals();
                }}
                size="large"
                style={{ width: "80%" }}
                formatter={(value) => `$ ${convertToLocaleString(value)}`}
                parser={(value) =>
                  value?.replace(/\$\s?|(,*)/g, "") as unknown as number
                }
              />
            </Form.Item>
          )}
        />
      </Flex>

      {!isFieldsCraftAuthorized() && (
        <Flex justify="end" align="flex-end" vertical>
          <Controller
            name="subTotal"
            control={control}
            render={({ field }) => (
              <Form.Item
                colon={false}
                layout="horizontal"
                initialValue={field.value || 0}
                label={
                  <span
                    style={{
                      marginRight: "30px",
                      fontSize: "1.05rem",
                      textAlign: "left",
                    }}
                  >
                    Total
                  </span>
                }
              >
                <InputNumber
                  {...field}
                  disabled
                  size="large"
                  style={{ width: "80%" }}
                  // min={0}
                  value={formatDecimalsOnlyTwo(field.value) || 0}
                  formatter={(value) => `$ ${convertToLocaleString(value)}`}
                  parser={(value) =>
                    value?.replace(/\$\s?|(,*)/g, "") as unknown as number
                  }
                />
              </Form.Item>
            )}
          />
        </Flex>
      )}
    </div>
  );
}
