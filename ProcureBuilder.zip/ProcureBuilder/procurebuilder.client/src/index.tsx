import React from "react";
import ReactDOM from "react-dom/client";
import { Provider } from "react-redux";
import { BrowserRouter } from "react-router-dom";
import { ConfigProvider } from "antd";
import "@styles/global.css";
import "react-phone-input-2/lib/style.css";

// Constants
import theme from "@theme/index";
import { store } from "@store/index";

// Components
import App from "@/src/App";
import Layout from "@/src/components/layout/LayoutContainer";
import dayjs from "dayjs";
import advancedFormat from "dayjs/plugin/advancedFormat";
import customParseFormat from "dayjs/plugin/customParseFormat";
import localeData from "dayjs/plugin/localeData";
import weekday from "dayjs/plugin/weekday";
import weekOfYear from "dayjs/plugin/weekOfYear";
import weekYear from "dayjs/plugin/weekYear";
import ReportsProvider from "./features/reports/contexts/ReportsProvider";

dayjs.extend(customParseFormat);
dayjs.extend(advancedFormat);
dayjs.extend(weekday);
dayjs.extend(localeData);
dayjs.extend(weekOfYear);
dayjs.extend(weekYear);

// This is dayjs functions add for that error. TypeError: clone.weekday is not a function

ReactDOM.createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <ReportsProvider>
      <BrowserRouter>
        <Provider store={store}>
          <ConfigProvider theme={theme}>
            <Layout>
              <App />
            </Layout>
          </ConfigProvider>
        </Provider>
      </BrowserRouter>
    </ReportsProvider>
  </React.StrictMode>
);
