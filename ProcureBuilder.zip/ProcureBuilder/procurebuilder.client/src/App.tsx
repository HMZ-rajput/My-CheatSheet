import Routing from "@components/routing/Routing";

export default function App() {
  return (
    <>
      <Routing />
    </>
  );
}
