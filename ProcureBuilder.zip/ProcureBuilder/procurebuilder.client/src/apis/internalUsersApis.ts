import { createAsyncThunk } from "@reduxjs/toolkit";
import { call, getUrlParams } from "@utils/api-helpers";
import { paginationPayload } from "../utils/constants";
import { InternalUser, Response, ResponseWithPagination } from "../utils/types";

enum endpoints {
  GET_ALL_INTERNAL_USERS = "auth/users",
  CREATE_INTERNAL_USER = "auth/signUp",
  EDIT_INTERNAL_USER = "auth/updateInternalUser",
  GET_INTERNAL_USER_BY_ID = "auth/users",
  RESEND_INVITE = "auth/resendInvite",
}

type GetAllInternalUsersResponse = ResponseWithPagination & {
  users: InternalUser[];
};
type GetAllInternalUsersRequest = typeof paginationPayload & {
  status?: number;
  role?: number;
  search?: string;
};

export const getAllInternalUsers = createAsyncThunk<
  GetAllInternalUsersResponse,
  GetAllInternalUsersRequest
>(
  endpoints.GET_ALL_INTERNAL_USERS,
  async (payload: GetAllInternalUsersRequest = paginationPayload) => {
    const response = await call<GetAllInternalUsersResponse>({
      url: `${endpoints.GET_ALL_INTERNAL_USERS}?${getUrlParams(
        payload
      )?.toString()}`,
      method: "GET",
    });
    return response;
  }
);

type CreateInternalUserResponse = Response &
  Omit<InternalUser, "id" | "role" | "email"> & {
    userId: string;
    userRole: string;
    userName: string;
  };
export const createInternalUser = createAsyncThunk(
  endpoints.CREATE_INTERNAL_USER,
  async (
    payload: Omit<
      InternalUser,
      | "id"
      | "createdDate"
      | "modifiedDate"
      | "fullName"
      | "userName"
      | "status"
      | "modifiedBy"
      | "createdBy"
    >
  ) => {
    const response = await call<CreateInternalUserResponse>({
      payload,
      url: endpoints.CREATE_INTERNAL_USER,
    });
    return response;
  }
);

type EditInternalUserResponse = Response & InternalUser;
export const editInternalUser = createAsyncThunk(
  endpoints.EDIT_INTERNAL_USER,
  async (
    payload: Omit<
      InternalUser,
      | "createdDate"
      | "modifiedDate"
      | "fullName"
      | "userName"
      | "status"
      | "createdBy"
      | "email"
    >
  ) => {
    const response = await call<EditInternalUserResponse>({
      payload,
      url: endpoints.EDIT_INTERNAL_USER,
      method: "PUT",
    });
    return response;
  }
);

type GetInternalUserResponse = Response & {
  user: InternalUser;
};

export const getInternalUserById = async (
  id: string
): Promise<GetInternalUserResponse> => {
  const response = await call<GetInternalUserResponse>({
    url: `${endpoints.GET_INTERNAL_USER_BY_ID}/${id}`,
    method: "GET",
  });
  return response;
};

// type ChangePasswordRequest = {
//   payload: {
//     email: string;
//     oldPassword: string;
//     newPassword: string;
//     modifiedBy: string;
//   },
// }
// export const changePassword = createAsyncThunk(
//   endpoints.CHANGE_PASSWORD,
//   async ({ payload }: ChangePasswordRequest) => {
//     const response = await call({ payload, url: endpoints.CHANGE_PASSWORD, method: "POST" })
//     return response
//   }
// )
type ResendingInviteResponse = Response;
export const resendingInvite = async (userId: string) => {
  const response = await call<ResendingInviteResponse>({
    url: `${endpoints.RESEND_INVITE}/${userId}`,
    method: "PUT",
  });
  return response;
};
