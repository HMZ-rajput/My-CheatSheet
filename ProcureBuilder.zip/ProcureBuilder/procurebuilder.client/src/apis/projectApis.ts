import { createAsyncThunk } from "@reduxjs/toolkit";
import {
  Project,
  SummarizedProject,
  Response,
  ResponseWithPagination,
} from "../utils/types";
import { call, getUrlParams } from "@utils/api-helpers";
import { paginationPayload } from "../utils/constants";

enum ProjectEndpointsEnum {
  GET_ALL_PROJECTS = "projects",
  CREATE_PROJECT = "projects/create",
  CREATE_PROJECT_TYPE = "projects/createType",
  UPDATE_PROJECT_TYPE = "projects/updateType",
  UPDATE_PROJECT = "projects/update",
  DELETE_PROJECT = "projects/delete",
  GET_PROJECT_NEW_CODE = "projects/newCode",
  GET_ALL_SUMMARIZED_PROJECTS = "projects/list",
  GET_PROJECT_BY_ID = "projects",
  ADD_CUSTOMER_TO_PROJECT = "projects/addCustomerToProject",
  UPDATE_USER_ACCESS = "projects/access/user",
}

type GetAllProjectsResponse = ResponseWithPagination & {
  projects: Project[];
} & {
  totalContractsPrice?: number;
  totalOpenProjects?: number;
  totalClosedProjects?: number;
};
type GetAllProjectsRequest = typeof paginationPayload & {
  status?: string | number;
  type?: string;
  search?: string;
  userId?: string;
  projectManagerId?: string | undefined;
  contractPriceStart?: number | undefined;
  contractPriceEnd?: number | undefined;
  projectedStartDateStart?: string | undefined;
  projectedStartDateEnd?: string | undefined;
  projectedCompletionDateStart?: string | undefined;
  projectedCompletionDateEnd?: string | undefined;
};
export const getAllProjects = createAsyncThunk<
  GetAllProjectsResponse,
  GetAllProjectsRequest
>(
  ProjectEndpointsEnum.GET_ALL_PROJECTS,
  async (payload: GetAllProjectsRequest = paginationPayload) => {
    const response = await call<GetAllProjectsResponse>({
      url: `${ProjectEndpointsEnum.GET_ALL_PROJECTS}?${getUrlParams(
        payload
      )?.toString()}`,
      method: "GET",
    });
    return response;
  }
);

type CreateProjectRequest = Omit<
  Project,
  "id" | "createdDate" | "modifiedDate"
>;
type CreateProjectResponse = Response & {
  project: Project;
};
export const createProject = createAsyncThunk<
  CreateProjectResponse,
  CreateProjectRequest
>(
  ProjectEndpointsEnum.CREATE_PROJECT,
  async (payload: CreateProjectRequest) => {
    const response = await call<CreateProjectResponse>({
      payload,
      url: ProjectEndpointsEnum.CREATE_PROJECT,
    });
    return response;
  }
);

type CreateProjectTypeRequest = {
  name: string;
  modifiedBy: string;
};
type CreateProjectTypeResponse = Response & {
  projectType: Project;
};
export const createProjectType = createAsyncThunk(
  ProjectEndpointsEnum.CREATE_PROJECT_TYPE,

  async (payload: CreateProjectTypeRequest) => {
    const response = await call<CreateProjectTypeResponse>({
      payload,
      url: ProjectEndpointsEnum.CREATE_PROJECT_TYPE,
    });
    return response;
  }
);

type UpdateProjectTypeRequest = {
  name: string;
  modifiedBy: string;
  id: string;
};
type UpdateProjectTypeResponse = Response & {
  projectType: {
    id: string;
    name: string;
  };
};
export const UpdateProjectType = createAsyncThunk(
  ProjectEndpointsEnum.UPDATE_PROJECT_TYPE,

  async (payload: UpdateProjectTypeRequest) => {
    const response = await call<UpdateProjectTypeResponse>({
      payload,
      url: ProjectEndpointsEnum.UPDATE_PROJECT_TYPE,
      method: "PUT",
    });
    return response;
  }
);

type EditProjectRequest = Project;
type EditProjectResponse = Response & {
  project: Project;
};
export const editProjectById = createAsyncThunk(
  ProjectEndpointsEnum.UPDATE_PROJECT,
  async (payload: EditProjectRequest) => {
    const response = await call<EditProjectResponse>({
      payload,
      url: `${ProjectEndpointsEnum.UPDATE_PROJECT}/${payload?.id}`,
      method: "PUT",
    });
    return response;
  }
);

type DeleteProjectResponse = Response & {
  project: Project;
};
export const deleteProjectById = createAsyncThunk(
  ProjectEndpointsEnum.DELETE_PROJECT,
  async (projectId: string) => {
    const response = await call<DeleteProjectResponse>({
      url: `${ProjectEndpointsEnum.DELETE_PROJECT}/${projectId}`,
      method: "DELETE",
    });
    return response;
  }
);

export type GetSummarizedProjectsList = Response & {
  projects: SummarizedProject[];
};
export const getSummarizedProjectsList = createAsyncThunk(
  ProjectEndpointsEnum.GET_ALL_SUMMARIZED_PROJECTS,
  async () => {
    const response = await call<GetSummarizedProjectsList>({
      url: ProjectEndpointsEnum.GET_ALL_SUMMARIZED_PROJECTS,
      method: "GET",
    });

    return response;
  }
);

type AddCustomerToProjectRequest = {
  customerId: string;
  projectId: string;
};
export const addCustomerToProject = createAsyncThunk(
  ProjectEndpointsEnum.ADD_CUSTOMER_TO_PROJECT,
  async (payload: AddCustomerToProjectRequest) => {
    const response = await call<CreateProjectResponse>({
      url: `${ProjectEndpointsEnum.ADD_CUSTOMER_TO_PROJECT}?projectId=${
        payload?.projectId || ""
      }&customerId=${payload?.customerId}`,
    });
    return response;
  }
);

export type GetProjectCodeNumberResponse = Response & {
  code: string;
};
export const getProjectCodeNumber = async () => {
  const response = await call<GetProjectCodeNumberResponse>({
    url: ProjectEndpointsEnum.GET_PROJECT_NEW_CODE,
    method: "GET",
  });

  return response;
};
type UpdateUserAccessRequest = {
  payload: {
    projectIds: string[];
  };
  userId: string;
};
type UpdateUserAccessResponse = Response & {
  projectIds: string[];
};
export const updateUserAccessById = createAsyncThunk(
  ProjectEndpointsEnum.UPDATE_USER_ACCESS,
  async ({ payload, userId }: UpdateUserAccessRequest) => {
    const response = await call<UpdateUserAccessResponse>({
      payload,
      url: `${ProjectEndpointsEnum.UPDATE_USER_ACCESS}/${userId}`,
      method: "PUT",
    });
    return response;
  }
);

type GetProjectByIdRequest = {
  projectId?: string;
};
type GetProjectByIdResponse = Response & {
  project: Project;
};
export const getProjectById = async (payload: GetProjectByIdRequest) => {
  const response = await call<GetProjectByIdResponse>({
    payload,
    url: `${ProjectEndpointsEnum.GET_PROJECT_BY_ID}/${payload?.projectId}`,
    method: "GET",
  });
  return response;
};
