import { createAsyncThunk } from "@reduxjs/toolkit";
import { paginationPayload } from "../utils/constants";
import { call, getUrlParams } from "@utils/api-helpers";
import {
  Response,
  ResponseWithPagination,
  MaterialReceiptInspection,
  MaterialReceiptInspectionMaterial,
  MaterialReceiptInspectionMaterialPhoto,
  Attachment,
} from "../utils/types";

export enum MaterialReceiptInspectionsEndpoints {
  GET_ALL_MATERIAL_RECEIPT_INSPECTION = "materialReceiptInspection",
  GET_MATERIAL_RECEIPT_INSPECTION_BY_ID = "materialReceiptInspection/",
  GET_MATERIAL_RECEIPT_INSPECTION_MATERIAL_LIST = "materialReceiptInspection/materialList",
  CREATE_MATERIAL_RECEIPT_INSPECTION = "materialReceiptInspection/create",
  UPDATE_MATERIAL_RECEIPT_INSPECTION = "materialReceiptInspection/update",
  UPDATE_MATERIAL_IMAGE = "materialReceiptInspection/updateMaterialImage",
  DELETE_MATERIAL_IMAGE = "materialReceiptInspection/deleteMaterialImage",
  DELETE_MATERIAL_RECEIPT_INSPECTION = "materialReceiptInspection/delete",
  DOWNLOAD_PDF = "materialReceiptInspection/pdf",
}

// Get All Material Receipt Inspection
type GetAllMaterialReceiptInspectionResponse = ResponseWithPagination & {
  materialReceiptInspections: MaterialReceiptInspection[];

  totalRejected?: number;
  totalApproved?: number;
  totalApprovedWithExceptions?: number;
  totalPending?: number;
  totalTransferred?: number;
};
type GetAllMaterialReceiptInspectionRequest = typeof paginationPayload & {
  pageNumber?: number;
  pageSize?: number;
  search?: string;
  isUpComing?: string;
  isOverDue?: string;
  isDueToday?: string;
  status?: string | number;
  projectId?: string;

  locationId?: string;
  purchaseOrderId?: string;
  materialType?: number;
  originalLocationId?: string;
  destinationLocationId?: string;
  transferDateFrom?: string;
  transferDateTo?: string;
  requestedDateFrom?: string;
  requestedDateTo?: string;
};
export const getAllMaterialReceiptInspections = createAsyncThunk<
  GetAllMaterialReceiptInspectionResponse,
  GetAllMaterialReceiptInspectionRequest
>(
  MaterialReceiptInspectionsEndpoints.GET_ALL_MATERIAL_RECEIPT_INSPECTION,
  async (
    payload: GetAllMaterialReceiptInspectionRequest = paginationPayload
  ) => {
    const response = await call<GetAllMaterialReceiptInspectionResponse>({
      url: `${
        MaterialReceiptInspectionsEndpoints.GET_ALL_MATERIAL_RECEIPT_INSPECTION
      }?${getUrlParams(payload)?.toString()}`,
      method: "GET",
    });
    return response;
  }
);

// Get Material Receipt Inspection (Material List) By Purchase Order id
type GetMaterialReceiptInspectionByPoResponse = Response & {
  materials: MaterialReceiptInspectionMaterial[];
};
export type GetMaterialReceiptInspectionByPoArgs = {
  purchaseOrderId: string | null;
};
export const getMaterialReceiptInspectionsMaterialList = createAsyncThunk<
  GetMaterialReceiptInspectionByPoResponse,
  GetMaterialReceiptInspectionByPoArgs
>(
  MaterialReceiptInspectionsEndpoints.GET_MATERIAL_RECEIPT_INSPECTION_MATERIAL_LIST,
  async ({ purchaseOrderId }) => {
    const response = await call<GetMaterialReceiptInspectionByPoResponse>({
      url: `${MaterialReceiptInspectionsEndpoints.GET_MATERIAL_RECEIPT_INSPECTION_MATERIAL_LIST}/${purchaseOrderId}`,
      method: "GET",
    });
    return response;
  }
);

// Get Material Receipt Inspection By MRI Id
type GetMaterialReceiptInspectionByIdResponse = Response & {
  materialReceiptInspection: MaterialReceiptInspection;
};
type GetMaterialReceiptInspectionByIdArgs = {
  id: string | null;
};
export const getMaterialReceiptInspectionById = createAsyncThunk<
  GetMaterialReceiptInspectionByIdResponse,
  GetMaterialReceiptInspectionByIdArgs
>(
  MaterialReceiptInspectionsEndpoints.GET_MATERIAL_RECEIPT_INSPECTION_BY_ID,
  async ({ id }) => {
    const response = await call<GetMaterialReceiptInspectionByIdResponse>({
      url: `${MaterialReceiptInspectionsEndpoints.GET_MATERIAL_RECEIPT_INSPECTION_BY_ID}${id}`,
      method: "GET",
    });
    return response;
  }
);

// Create New Material Receipt Inspection
type CreateMaterialReceiptInspectionResponse = Response & {
  materialReceiptInspection: MaterialReceiptInspection;
};
type CreateMaterialReceiptInspectionArgs = {
  payload: MaterialReceiptInspection | FormData;
};
export const createMaterialReceiptInspection = createAsyncThunk(
  MaterialReceiptInspectionsEndpoints.CREATE_MATERIAL_RECEIPT_INSPECTION,
  async ({ payload }: CreateMaterialReceiptInspectionArgs) => {
    const response = await call<CreateMaterialReceiptInspectionResponse>({
      payload,
      url: `${MaterialReceiptInspectionsEndpoints.CREATE_MATERIAL_RECEIPT_INSPECTION}`,
      method: "POST",
      isFormData: true,
    });
    return response;
  }
);

// Edit Material Receipt Inspection
type EditMaterialReceiptInspectionResponse = Response & {
  materialReceiptInspection: MaterialReceiptInspection;
};
type EditMaterialReceiptInspectionArgs = {
  payload: MaterialReceiptInspection | FormData;
  id: string | undefined;
};
export const editMaterialReceiptInspectionById = createAsyncThunk(
  MaterialReceiptInspectionsEndpoints.UPDATE_MATERIAL_RECEIPT_INSPECTION,
  async ({ payload, id }: EditMaterialReceiptInspectionArgs) => {
    const response = await call<EditMaterialReceiptInspectionResponse>({
      payload,
      url: `${MaterialReceiptInspectionsEndpoints.UPDATE_MATERIAL_RECEIPT_INSPECTION}/${id}`,
      method: "PUT",
      isFormData: true,
    });
    return response;
  }
);

// Update Material Photos
type EditMaterialPhotoResponse = Response & {
  materialImages: Attachment[];
  materialReceiptInspectionId: string;
};
type EditMaterialPhotoArgs = {
  payload: MaterialReceiptInspectionMaterialPhoto | FormData;
  id: string | null;
};
export const editMaterialPhotoById = createAsyncThunk(
  MaterialReceiptInspectionsEndpoints.UPDATE_MATERIAL_IMAGE,
  async ({ payload, id }: EditMaterialPhotoArgs) => {
    const response = await call<EditMaterialPhotoResponse>({
      payload,
      url: `${MaterialReceiptInspectionsEndpoints.UPDATE_MATERIAL_IMAGE}/${id}`,
      method: "PUT",
      isFormData: true,
    });
    return response;
  }
);

// Delete Material Receipt Inspection
type DeleteMaterialReceiptInspectionResponse = Response & {
  materialReceiptInspection: MaterialReceiptInspection;
};
type DeleteMaterialReceiptInspectionArgs = Response & {
  id: string | undefined;
};
export const deleteMaterialReceiptInspectionById = createAsyncThunk(
  MaterialReceiptInspectionsEndpoints.DELETE_MATERIAL_RECEIPT_INSPECTION,
  async ({ id }: DeleteMaterialReceiptInspectionArgs) => {
    const response = await call<DeleteMaterialReceiptInspectionResponse>({
      url: `${MaterialReceiptInspectionsEndpoints.DELETE_MATERIAL_RECEIPT_INSPECTION}/${id}`,
      method: "DELETE",
    });
    return response;
  }
);

// Delete Material Photos
type DeleteMaterialPhotoResponse = Response & {
  materialImages: MaterialReceiptInspectionMaterialPhoto;
};
type DeleteMaterialPhotoArgs = {
  id: string | null;
};
export const deleteMaterialImageById = createAsyncThunk(
  MaterialReceiptInspectionsEndpoints.DELETE_MATERIAL_IMAGE,
  async ({ id }: DeleteMaterialPhotoArgs) => {
    const response = await call<DeleteMaterialPhotoResponse>({
      url: `${MaterialReceiptInspectionsEndpoints.DELETE_MATERIAL_IMAGE}/${id}`,
      method: "DELETE",
    });
    return response;
  }
);

export const downloadPdf = createAsyncThunk(
  MaterialReceiptInspectionsEndpoints.DOWNLOAD_PDF,
  async (ids: string[]) => {
    const response = await call<Blob>({
      url: `${MaterialReceiptInspectionsEndpoints.DOWNLOAD_PDF}`,
      method: "POST",
      responseType: "blob",
      payload: {
        materialReceiptInspectionIds: ids,
      },
    });

    return response;
  }
);
