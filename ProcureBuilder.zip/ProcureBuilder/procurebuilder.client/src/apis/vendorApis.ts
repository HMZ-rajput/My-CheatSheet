import { createAsyncThunk } from "@reduxjs/toolkit";
import { call, getUrlParams } from "@utils/api-helpers";
import { paginationPayload } from "../utils/constants";
import {
  Response,
  ResponseWithPagination,
  Vendor,
  VendorsList,
} from "../utils/types";

enum VendorEndpointsEnum {
  GET_ALL_VENDORS = "vendors",
  GET_VENDOR_BY_ID = "vendors/",
  CREATE_VENDOR = "vendors/create",
  UPDATE_VENDOR = "vendors/update",
  DELETE_VENDOR = "vendors/delete",
  GET_VENDORS_LIST = "vendors/list",
}

type GetAllVendorsResponse = ResponseWithPagination & { vendors: Vendor[] };
type GetAllVendorsRequest = typeof paginationPayload & {
  divisionId?: string;
  search?: string;
};

export const getAllVendors = createAsyncThunk<
  GetAllVendorsResponse,
  GetAllVendorsRequest
>(
  VendorEndpointsEnum.GET_ALL_VENDORS,
  async (payload: GetAllVendorsRequest = paginationPayload) => {
    const response = await call<GetAllVendorsResponse>({
      url: `${VendorEndpointsEnum.GET_ALL_VENDORS}?${getUrlParams(
        payload
      )?.toString()}`,
      method: "GET",
    });
    return response;
  }
);
type GetVendorByIdResponse = Response & {
  vendor: Vendor;
};
type GetVendorByIdRequest = {
  id: string | null;
};
export const getVendorById = createAsyncThunk<
  GetVendorByIdResponse,
  GetVendorByIdRequest
>(VendorEndpointsEnum.GET_VENDOR_BY_ID, async ({ id }) => {
  const response = await call<GetVendorByIdResponse>({
    url: `${VendorEndpointsEnum.GET_VENDOR_BY_ID}${id}`,
    method: "GET",
  });
  return response;
});

type LocationResponse = Response & {
  vendors: VendorsList[];
};
export const getVendorslist = createAsyncThunk(
  VendorEndpointsEnum.GET_VENDORS_LIST,
  async () => {
    const response = await call<LocationResponse>({
      url: VendorEndpointsEnum.GET_VENDORS_LIST,
      method: "GET",
    });
    return response;
  }
);

type CreateVendorRequest = Omit<Vendor, "id" | "createdDate" | "modifiedDate">;
type CreateVendorResponse = Response & {
  vendor: Vendor;
};
export const createVendor = createAsyncThunk<
  CreateVendorResponse,
  CreateVendorRequest
>(VendorEndpointsEnum.CREATE_VENDOR, async (payload: CreateVendorRequest) => {
  const response = await call<CreateVendorResponse>({
    payload,
    url: VendorEndpointsEnum.CREATE_VENDOR,
  });
  return response;
});

type EditVendorRequest = Vendor;
type EditVendorResponse = Response & {
  id: string;
  vendor: Vendor;
};
export const editVendorById = createAsyncThunk(
  VendorEndpointsEnum.UPDATE_VENDOR,
  async (payload: EditVendorRequest) => {
    const response = await call<EditVendorResponse>({
      payload,
      url: `${VendorEndpointsEnum.UPDATE_VENDOR}/${payload?.id}`,
      method: "PUT",
    });
    return response;
  }
);

type DeleteVendorResponse = Response & {
  vendor: Vendor;
};
export const deleteVendorById = createAsyncThunk(
  VendorEndpointsEnum.DELETE_VENDOR,
  async (vendorId: string) => {
    const response = await call<DeleteVendorResponse>({
      url: `${VendorEndpointsEnum.DELETE_VENDOR}/${vendorId}`,
      method: "DELETE",
    });
    return response;
  }
);
