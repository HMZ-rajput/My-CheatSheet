import { createAsyncThunk } from "@reduxjs/toolkit";
import {
  Reorder,
  RorderRecipient,
  Response,
  ResponseWithPagination,
} from "../utils/types";
import { call, getUrlParams } from "@utils/api-helpers";
import { paginationPayload } from "../utils/constants";

export enum ReorderEndpoints {
  GET_ALL_REORDERS = "reorders",
  GET_REORDER_BY_ID = "reorders/",
  GET_REORDERS_BY_PROJECT = "reorders/project",
  GET_REORDER_NUMBER = "reorders/newReorderNumber",
  CREATE_REORDER = "reorders/create/project",
  UPDATE_REORDER = "reorders/update/project",
  UPDATE_REORDER_RECIPIENT = "reorders/updateRecipient",
  DELETE_REORDER = "reorders/delete",
}

type GetAllReordersResponse = ResponseWithPagination & {
  reorders: Reorder[];
  totalPendingReQuote?: number;
  totalQuoteReceived?: number;
  totalPOCreated?: number;
};
type GetAllReordersRequest = typeof paginationPayload & {
  pageNumber?: number;
  pageSize?: number;
  search?: string;
  status?: string | number;
  isUpComing?: string | undefined;
  isOverDue?: string | undefined;
  isDueToday?: string | undefined;
  projectId?: string;

  locationId?: string;
  requestDateFrom?: string;
  requestDateTo?: string;
  dueDateFrom?: string;
  dueDateTo?: string;
  quoteReceivedDateFrom?: string;
  quoteReceivedDateTo?: string;
};
export const getAllReorders = createAsyncThunk<
  GetAllReordersResponse,
  GetAllReordersRequest
>(
  ReorderEndpoints.GET_ALL_REORDERS,
  async (payload: GetAllReordersRequest = paginationPayload) => {
    const response = await call<GetAllReordersResponse>({
      url: `${ReorderEndpoints.GET_ALL_REORDERS}?${getUrlParams(
        payload
      )?.toString()}`,
      method: "GET",
    });
    return response;
  }
);

type GetReordersByProjectResponse = ResponseWithPagination & {
  reorders: Reorder[];
  projectId: string | undefined;
};
export type GetReordersByProjectArgs = typeof paginationPayload & {
  projectId: string | undefined;
  pageNumber?: number;
  pageSize?: number;
};
export const getReordersByProject = createAsyncThunk<
  GetReordersByProjectResponse,
  GetReordersByProjectArgs
>(ReorderEndpoints.GET_REORDERS_BY_PROJECT, async (payload) => {
  const { projectId, ...values } = payload;
  const response = await call<GetReordersByProjectResponse>({
    url: `${
      ReorderEndpoints.GET_REORDERS_BY_PROJECT
    }/${projectId}?${getUrlParams(values)?.toString()}`,
    method: "GET",
  });
  return response;
});

type GetReorderByIdResponse = Response & { reorder: Reorder };
type GetReorderByIdArg = {
  id: string | undefined;
};
export const getReorderById = createAsyncThunk<
  GetReorderByIdResponse,
  GetReorderByIdArg
>(ReorderEndpoints.GET_REORDER_BY_ID, async ({ id }) => {
  const response = await call<GetReorderByIdResponse>({
    url: `${ReorderEndpoints.GET_REORDER_BY_ID}${id}`,
    method: "GET",
  });
  return response;
});

type CreateReorderResponse = Response & {
  reorder: Reorder;
};
type CreateReorderArgs = {
  payload: Reorder | FormData;
  projectId: string | undefined;
};
export const createReorder = createAsyncThunk(
  ReorderEndpoints.CREATE_REORDER,
  async ({ payload, projectId }: CreateReorderArgs) => {
    const response = await call<CreateReorderResponse>({
      payload,
      url: `${ReorderEndpoints.CREATE_REORDER}/${projectId}`,
      method: "POST",
      isFormData: true,
    });
    return response;
  }
);

type EditReorderResponse = Response & {
  reorder: Reorder;
};
type EditReorderArgs = {
  payload: Reorder | FormData;
  projectId: string | undefined;
  reorderId: string | undefined;
};
export const editReorderById = createAsyncThunk(
  ReorderEndpoints.UPDATE_REORDER,
  async ({ payload, projectId, reorderId }: EditReorderArgs) => {
    const response = await call<EditReorderResponse>({
      payload,
      url: `${ReorderEndpoints.UPDATE_REORDER}/${projectId}/reorder/${reorderId}`,
      method: "PUT",
      isFormData: true,
    });
    return response;
  }
);

type EditReorderRecipientRequest = {
  payload: RorderRecipient | FormData;
  reorderId: string | undefined;
};
type EditReorderRecipientResponse = Response & {
  reorder: Reorder;
};
export const editReorderRecipientById = createAsyncThunk(
  ReorderEndpoints.UPDATE_REORDER_RECIPIENT,
  async ({ payload, reorderId }: EditReorderRecipientRequest) => {
    const response = await call<EditReorderRecipientResponse>({
      payload,
      url: `${ReorderEndpoints.UPDATE_REORDER_RECIPIENT}/${reorderId}`,
      method: "PUT",
      isFormData: true,
    });
    return response;
  }
);

type DeleteReorderResponse = Response & {
  reorder: Reorder;
};
type DeleteReorderArgs = Response & {
  reorderId: string | undefined;
};
export const deleteReorderById = createAsyncThunk(
  ReorderEndpoints.DELETE_REORDER,
  async ({ reorderId }: DeleteReorderArgs) => {
    const response = await call<DeleteReorderResponse>({
      url: `${ReorderEndpoints.DELETE_REORDER}/${reorderId}`,
      method: "DELETE",
    });
    return response;
  }
);

export type GetReorderCodeNumberResponse = Response & {
  reorderNumber: string;
};
export const getReorderCodeNumber = async () => {
  const response = await call<GetReorderCodeNumberResponse>({
    url: ReorderEndpoints.GET_REORDER_NUMBER,
    method: "GET",
  });
  return response;
};
