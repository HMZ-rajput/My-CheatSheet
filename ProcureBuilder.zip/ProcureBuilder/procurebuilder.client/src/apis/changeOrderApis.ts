import { createAsyncThunk } from "@reduxjs/toolkit";
import { ChangeOrder, Response, ResponseWithPagination } from "../utils/types";
import { call, getUrlParams } from "@utils/api-helpers";
import { paginationPayload } from "../utils/constants";

export enum ChangeOrderEndpoints {
  GET_CHANGE_ORDERS = "changeOrders",
  GET_CHANGE_ORDER_BY_ID = "changeOrders/",
  GET_CHANGE_ORDERS_BY_PROJECT = "changeOrders/project",
  GET_APPROVED_CHANGE_ORDERS = "changeOrders/project/",
  CREATE_CHANGE_ORDER = "changeOrders/create/project",
  UPDATE_CHANGE_ORDER = "changeOrders/update/project",
  DELETE_CHANGE_ORDER = "changeOrders/delete/project",
  GET_CO_NUMBER = "changeOrders/newChangeOrderNumber",
}

type GetAllChangeOrdersResponse = ResponseWithPagination & {
  changeOrders: ChangeOrder[];
  combinedSubtotal?: number;
  totalApproved?: number;
  totalRejected?: number;
  totalPending?: number;
  totalAddedToBidMaterial?: number;
};
export type GetAllChangeOrderRequest = typeof paginationPayload & {
  pageNumber?: number;
  pageSize?: number;
  search?: string;
  isUpComing?: string;
  isOverDue?: string;
  isDueToday?: string;
  status?: string | number;
  projectId?: string;
  subtotalFrom?: number;
  subtotalTo?: number;
  approvalDeadlineFrom?: string;
  approvalDeadlineTo?: string;
};
export const getAllChangeOrders = createAsyncThunk<
  GetAllChangeOrdersResponse,
  GetAllChangeOrderRequest
>(
  ChangeOrderEndpoints.GET_CHANGE_ORDERS,
  async (payload: GetAllChangeOrderRequest = paginationPayload) => {
    const response = await call<GetAllChangeOrdersResponse>({
      url: `${ChangeOrderEndpoints.GET_CHANGE_ORDERS}?${getUrlParams(
        payload
      )?.toString()}`,
      method: "GET",
    });
    return response;
  }
);

type GetChangeOrdersByProjectResponse = ResponseWithPagination & {
  changeOrders: ChangeOrder[];
  projectId: string | undefined;
};
export type GetChangeOrdersByProjectArgs = {
  projectId: string | undefined;
};
export const getChangeOrdersByProject = createAsyncThunk<
  GetChangeOrdersByProjectResponse,
  GetChangeOrdersByProjectArgs
>(ChangeOrderEndpoints.GET_CHANGE_ORDERS_BY_PROJECT, async ({ projectId }) => {
  const response = await call<GetChangeOrdersByProjectResponse>({
    url: `${ChangeOrderEndpoints.GET_CHANGE_ORDERS_BY_PROJECT}/${projectId}`,
    method: "GET",
  });
  return response;
});

type GetApprovedChangeOrdersResponse = ResponseWithPagination & {
  changeOrders: ChangeOrder[];
  projectId: string | undefined;
};
export type GetApprovedChangeOrdersArgs = {
  projectId: string | undefined;
};
export const getApprovedChangeOrdersByProject = createAsyncThunk<
  GetApprovedChangeOrdersResponse,
  GetApprovedChangeOrdersArgs
>(ChangeOrderEndpoints.GET_APPROVED_CHANGE_ORDERS, async ({ projectId }) => {
  const response = await call<GetApprovedChangeOrdersResponse>({
    url: `${ChangeOrderEndpoints.GET_APPROVED_CHANGE_ORDERS}${projectId}/approved`,
    method: "GET",
  });
  return response;
});

type GetChangeOrderByIdResponse = Response & {
  changeOrder: ChangeOrder;
};
type GetChangeOrderByIdArgs = {
  id: string | null;
};
export const getChangeOrderById = createAsyncThunk<
  GetChangeOrderByIdResponse,
  GetChangeOrderByIdArgs
>(ChangeOrderEndpoints.GET_CHANGE_ORDER_BY_ID, async ({ id }) => {
  const response = await call<GetChangeOrderByIdResponse>({
    url: `${ChangeOrderEndpoints.GET_CHANGE_ORDER_BY_ID}${id}`,
    method: "GET",
  });
  return response;
});

type CreateChangeOrderResponse = Response & {
  changeOrder: ChangeOrder;
};
type CreateChangeOrderArgs = {
  payload:
    | Omit<ChangeOrder, "id" | "createdDate" | "modifiedDate" | "projects">
    | FormData;
  projectId: string | undefined;
};
export const createChangeOrder = createAsyncThunk(
  ChangeOrderEndpoints.CREATE_CHANGE_ORDER,
  async ({ payload, projectId }: CreateChangeOrderArgs) => {
    const response = await call<CreateChangeOrderResponse>({
      payload,
      url: `${ChangeOrderEndpoints.CREATE_CHANGE_ORDER}/${projectId}`,
      isFormData: true,
    });
    return response;
  }
);

type EditChangeOrderResponse = Response & { changeOrder: ChangeOrder };

type EditChangeOrderArgs = {
  payload: ChangeOrder | FormData;
  projectId: string | undefined;
  changeOrderId: string | undefined;
};
export const editChangeOrderById = createAsyncThunk(
  ChangeOrderEndpoints.UPDATE_CHANGE_ORDER,
  async ({ payload, projectId, changeOrderId }: EditChangeOrderArgs) => {
    const response = await call<EditChangeOrderResponse>({
      payload,
      url: `${ChangeOrderEndpoints.UPDATE_CHANGE_ORDER}/${projectId}/changeOrder/${changeOrderId}`,
      method: "PUT",
      isFormData: true,
    });
    return response;
  }
);

type DeleteChangeOrderResponse = Response & {
  changeOrder: ChangeOrder;
};
type DeleteChangeOrderArgs = Response & {
  projectId: string | undefined;
  changeOrderId: string | undefined;
};
export const deleteChangeOrderById = createAsyncThunk(
  ChangeOrderEndpoints.DELETE_CHANGE_ORDER,
  async ({ projectId, changeOrderId }: DeleteChangeOrderArgs) => {
    const response = await call<DeleteChangeOrderResponse>({
      url: `${ChangeOrderEndpoints.DELETE_CHANGE_ORDER}/${projectId}/changeOrder/${changeOrderId}`,
      method: "DELETE",
    });
    return response;
  }
);

export type GetChangeOrderCodeNumberResponse = Response & {
  changeOrderNumber: string;
};
export const getChangeOrderCodeNumber = async () => {
  const response = await call<GetChangeOrderCodeNumberResponse>({
    url: ChangeOrderEndpoints.GET_CO_NUMBER,
    method: "GET",
  });

  return response;
};
