import { createAsyncThunk } from "@reduxjs/toolkit";
import { call, getUrlParams } from "@utils/api-helpers";
import {
  DashboardSideNotifications,
  DashboardType,
  MaterialCostAnalysisRowType,
  RequestWithReportOption,
  Response,
} from "../utils/types";

enum endpoints {
  GET_DASHBOARD = "dashboard",
  GET_DASHBOARD_BY_PROJECTID = "dashboardByProjectId",
  GET_MATERIAL_COST_ANALYSIS = "dashboard/materialCostAnalysis",
  UPDATE_DASHBOARD = "dashboard/update",
  DELETE_NOTIFICATION = "dashboard/notification/delete",
  GET_DASHBOARD_SIDE_NOTIFICATION = "dashboard/sideNotification",
  updateDashboardNotificationByEntityId = "dashboard/updateNotification",
}

type GetDashboardRequest = {
  projectComparisonType: number | null;
  date: string | null;
};
type GetDashboardResponse = Response & { dashboard: DashboardType };
export const getDashboard = createAsyncThunk(
  endpoints.GET_DASHBOARD,
  async (request: GetDashboardRequest) => {
    const response = await call<GetDashboardResponse>({
      url: `${endpoints.GET_DASHBOARD}?${getUrlParams(request)?.toString()}`,
      method: "GET",
    });

    return response;
  }
);

type GetDashboardByProjectIdRequest = {
  date: string | null;
  projectId: string | null;
};
type GetDashboardByProjectIdResponse = Response & {
  dashboard: DashboardType;
};
export const getDashboardByProjectId = createAsyncThunk(
  endpoints.GET_DASHBOARD_BY_PROJECTID,
  async ({ projectId, date }: GetDashboardByProjectIdRequest) => {
    const response = await call<GetDashboardByProjectIdResponse>({
      url: `${endpoints.GET_DASHBOARD}/${projectId}?${getUrlParams({
        date,
      })?.toString()}`,
      method: "GET",
    });

    return response;
  }
);

type GetMaterialCostAnalysisByProjectIdRequest = {
  projectId: string | null;
} & RequestWithReportOption;
export type GetMaterialCostAnalysisByProjectIdResponse = Response & {
  materials: MaterialCostAnalysisRowType[];

  totalBudgetCost?: number;
  totalBudgetQuantity?: number;
  totalBudgetUnitRate?: number;
  totalCommittedCost?: number;
  totalCommittedQuantity?: number;
  totalCommittedUnitRate?: number;
  totalCostDifference?: number;
  totalQuantityDifference?: number;
  totalUnitRateDifference?: number;
};
export const getMaterialCostAnalysisByProjectId = async ({
  projectId,
  ...request
}: GetMaterialCostAnalysisByProjectIdRequest) => {
  const response = await call<GetMaterialCostAnalysisByProjectIdResponse>({
    url: `${endpoints.GET_MATERIAL_COST_ANALYSIS}/${
      projectId || ""
    }?${getUrlParams(request)?.toString()}`,
    method: "GET",
  });

  return response;
};

type GetDashboardSideNotificationRequest = {
  date: string | null;
  projectId: string | null;
};

type GetDashboardSideNotificationResponse = Response &
  DashboardSideNotifications;
export const getDashboardSideNotification = createAsyncThunk(
  endpoints.GET_DASHBOARD_SIDE_NOTIFICATION,
  async (payload: GetDashboardSideNotificationRequest) => {
    const response = await call<GetDashboardSideNotificationResponse>({
      url: `${endpoints.GET_DASHBOARD_SIDE_NOTIFICATION}?date=${
        payload?.date || ""
      }&projectId=${payload?.projectId || ""}`,
      method: "GET",
    });

    return response;
  }
);

type UpdateDashboardNotificationByEntityIdRequest = {
  entityId: string;
  notificationId: string;
  isApproved: boolean;
};
export type UpdateDashboardNotificationByEntityIdResponse = Response & {
  text: string;
  materials: any[];
  errors: string[];
  isSuccess: boolean;
};
export const updateDashboardNotificationByEntityId = createAsyncThunk(
  endpoints.updateDashboardNotificationByEntityId,
  async ({
    entityId,
    notificationId,
    isApproved,
  }: UpdateDashboardNotificationByEntityIdRequest) => {
    const response = await call<UpdateDashboardNotificationByEntityIdResponse>({
      payload: { notificationId, isApproved },
      url: `${endpoints.UPDATE_DASHBOARD}/${entityId}`,
      method: "PUT",
    });

    return response;
  }
);

type DeleteNotificationRequest = {
  notificationId: string;
};

export type DeleteNotificationResponse = Response & {
  errors: string[];
  isSuccess: boolean;
};

export const deleteNotificationById = createAsyncThunk(
  endpoints.DELETE_NOTIFICATION,
  async ({
    notificationId,
  }: DeleteNotificationRequest) => {
    const response = await call<DeleteNotificationResponse>({
      url: `${endpoints.DELETE_NOTIFICATION}/${notificationId}`,
      method: "PUT",
    });

    return response;
  }
);
