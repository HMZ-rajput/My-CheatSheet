import { createAsyncThunk } from "@reduxjs/toolkit";
import { Response, StorageType } from "../utils/types";
import { call } from "@utils/api-helpers";

enum endpoints {
  GET_ALL_STORAGE_TYPES = "storageType",
  CREATE_STORAGETYPE = "storageType/create",
  UPDATE_STORAGETYPE = "storageType/update",
}

type GetAllStorageTypesResponse = Response & { storageTypes: StorageType[] };
export const getAllStorageTypes = createAsyncThunk(
  endpoints.GET_ALL_STORAGE_TYPES,
  async () => {
    const response = await call<GetAllStorageTypesResponse>({
      url: endpoints.GET_ALL_STORAGE_TYPES,
      method: "GET",
    });

    return response;
  }
);

type CreateStorageTypeRequest = {
  name: string;
};
type CreateStorageTypeResponse = Response & {
  storageType: StorageType;
};
export const createStorageType = createAsyncThunk(
  endpoints.CREATE_STORAGETYPE,
  async (payload: CreateStorageTypeRequest) => {
    const response = await call<CreateStorageTypeResponse>({
      payload,
      url: endpoints.CREATE_STORAGETYPE,
    });
    return response;
  }
);

type updateStorageTypeRequest = {
  name: string;
  id: string;
};

type updateStorageTypeResponse = Response & {
  storageType: {
    id: string;
    name: string;
    modifiedBy: string;
  };
};
export const updateStorageType = createAsyncThunk(
  endpoints.UPDATE_STORAGETYPE,
  async (payload: updateStorageTypeRequest) => {
    const response = await call<updateStorageTypeResponse>({
      payload,
      url: `${endpoints.UPDATE_STORAGETYPE}/${payload.id}`,
      method: "PUT",
    });
    return response;
  }
);
