import { createAsyncThunk } from "@reduxjs/toolkit";
import { call, getUrlParams } from "@utils/api-helpers";
import { paginationPayload } from "../utils/constants";
import {
  Product,
  ProductMaterial,
  ResponseWithPagination,
} from "../utils/types";

enum ProjectEndpointsEnum {
  GET_ALL_PRODUCTS = "products",
  GET_PRODUCT_By_Name = "products/",
}

type GetAllProductsResponse = ResponseWithPagination & {
  products: Product[];
};
type GetProductByNameResponse = ResponseWithPagination & {
  product: ProductMaterial[];
};
type GetAllProductsRequest = typeof paginationPayload & {
  search?: string;
  sortingFilter?: number;
  projectId?: string;
  locationId?: string;
  materialType?: number;
};

// type GetProducts
export const getAllProducts = createAsyncThunk<
  GetAllProductsResponse,
  GetAllProductsRequest
>(
  ProjectEndpointsEnum.GET_ALL_PRODUCTS,
  async (payload: GetAllProductsRequest = paginationPayload) => {
    const response = await call<GetAllProductsResponse>({
      url: `${ProjectEndpointsEnum.GET_ALL_PRODUCTS}?${getUrlParams(
        payload
      )?.toString()}`,
      method: "GET",
    });
    return response;
  }
);

type GetProductsByNameRequest = typeof paginationPayload & {
  search?: string;
  productName?: string;
  projectId?: string;
  projectLocationId?: string;
};

export const getAllProductByName = createAsyncThunk<
  GetProductByNameResponse,
  GetProductsByNameRequest
>(
  ProjectEndpointsEnum.GET_PRODUCT_By_Name,
  async (payload: GetProductsByNameRequest = paginationPayload) => {
    const { productName, ...values } = payload;
    const response = await call<GetProductByNameResponse>({
      url: `${
        ProjectEndpointsEnum.GET_PRODUCT_By_Name
      }${productName}?${getUrlParams(values)?.toString()}`,
      method: "GET",
    });
    return response;
  }
);
