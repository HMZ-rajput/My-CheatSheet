import { createAsyncThunk } from "@reduxjs/toolkit";
import { call, getUrlParams } from "@utils/api-helpers";
import {
  InventoriesList,
  InventoryFormValues,
  LocationMaterials,
  Response,
  ResponseWithPagination,
} from "../utils/types";
import { paginationPayload } from "../utils/constants";

export enum InventoryEndpoints {
  GET_INVENTORY = "inventory/project",
  GET_ALL_INVENTORY = "inventory/allMaterials/project",
  CREATE_INVENTORY = "inventory/create/project",
  UPDATE_INVENTORY = "inventory/update/project",
  DELETE_INVENTORY = "inventory/delete/project",
}

type GetAllInventoryResponse = Response & InventoriesList;
type GetInventoryResponse = ResponseWithPagination & InventoriesList;

type GetAllInventoryRequest = typeof paginationPayload & {
  projectId: string;
  LocationId?: string | number | null;
  search?: string | undefined;
  SubLocationId?: string | number | null;
};

export const getInventoryListByProjectId = createAsyncThunk<
  GetInventoryResponse,
  GetAllInventoryRequest
>(InventoryEndpoints.GET_INVENTORY, async (payload) => {
  const { projectId, ...value } = payload;
  const response = await call<GetInventoryResponse>({
    url: `${InventoryEndpoints.GET_INVENTORY}/${projectId}?${getUrlParams(
      value as any
    )?.toString()}`,
    method: "GET",
  });
  return response;
});

type Payload = {
  projectId?: string | null;
  LocationId?: string | number | null;
  search?: string | undefined;
  SubLocationId?: string | number | null;
};

export const getAllInventoryListByProjectId = createAsyncThunk<
  GetAllInventoryResponse,
  Payload
>(InventoryEndpoints.GET_ALL_INVENTORY, async (payload) => {
  const { projectId, ...value } = payload;
  const response = await call<GetAllInventoryResponse>({
    url: `${InventoryEndpoints.GET_ALL_INVENTORY}/${projectId}?${getUrlParams(
      value as any
    )?.toString()}`,
    method: "GET",
  });
  return response;
});

export const getAllInventoryListByProjectIdOnlyInventoryMaterial =
  createAsyncThunk<GetAllInventoryResponse, Payload>(
    InventoryEndpoints.GET_ALL_INVENTORY,
    async (payload) => {
      const { projectId, ...value } = payload;
      const response = await call<GetAllInventoryResponse>({
        url: `${
          InventoryEndpoints.GET_ALL_INVENTORY
        }/${projectId}?${getUrlParams(value as any)?.toString()}`,
        method: "GET",
      });
      return response;
    }
  );

type CreateInventoryResponse = Response & {
  payload: LocationMaterials;
} & InventoriesList;
export const createInventory = createAsyncThunk(
  InventoryEndpoints.CREATE_INVENTORY,
  async (payload: InventoryFormValues) => {
    const response = await call<CreateInventoryResponse>({
      payload,
      url: `${InventoryEndpoints.CREATE_INVENTORY}/${payload?.projectId}`,
    });
    return response;
  }
);
type EditInventoryResponse = Response & {
  payload: LocationMaterials;
  projectId: string;
} & InventoriesList;
export const editInventoryById = createAsyncThunk(
  InventoryEndpoints.UPDATE_INVENTORY,
  async (payload: InventoryFormValues) => {
    const { projectId, ...value } = payload;
    const response = await call<EditInventoryResponse>({
      payload: value,
      url: `${InventoryEndpoints.UPDATE_INVENTORY}/${projectId}`,
      method: "PUT",
    });
    return response;
  }
);

export const deleteInventoryById = createAsyncThunk(
  InventoryEndpoints.DELETE_INVENTORY,
  async (projectId: string | null) => {
    const response = await call<CreateInventoryResponse>({
      url: `${InventoryEndpoints.DELETE_INVENTORY}/${projectId}`,
      method: "DELETE",
    });
    return response;
  }
);
