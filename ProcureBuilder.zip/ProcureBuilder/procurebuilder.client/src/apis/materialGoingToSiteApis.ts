import { createAsyncThunk } from "@reduxjs/toolkit";
import { call, getUrlParams } from "@utils/api-helpers";
import {
  MaterialTransfer,
  Response,
  ResponseWithPagination,
} from "@utils/types";
import { paginationPayload } from "../utils/constants";
import { Dayjs } from "dayjs";

export enum MaterialToSiteEndpointsEnum {
  GET_ALL_MATERIAL_GOING_TO_SITE = "materialToSite",
  GET_ALL_MATERIAL_GOING_TO_SITE_BY_ID = "materialToSite",
  //   GET_MATERIAL_TRANSFER_LIST = "materialTransfer/list",
  CREATE_MATERIAL_GOING_TO_SITE = "materialToSite/create",
  UPDATE_MATERIAL_GOING_TO_SITE = "materialToSite/update",

  DELETE_MATERIAL_GOING_TO_SITE = "materialToSite/delete",
}

type GetAllMaterialGoingToSiteResponse = ResponseWithPagination & {
  materialToSites: MaterialTransfer[];

  totalCancelled?: number;
  totalInProgress?: number;
  totalPending?: number;
  totalTransferred?: number;
};
type GetAllMaterialGoingToSiteRequest = typeof paginationPayload & {
  search?: string;
  isUpComing?: string;
  isOverDue?: string;
  isDueToday?: string;
  projectId?: string;
  status?: number;

  materialType?: number;
  originalLocationId?: string;
  destinationLocationId?: string;
  transferDateFrom?: string;
  transferDateTo?: string;
};
export const getAllMaterialGoingToSite = createAsyncThunk<
  GetAllMaterialGoingToSiteResponse,
  GetAllMaterialGoingToSiteRequest
>(
  MaterialToSiteEndpointsEnum.GET_ALL_MATERIAL_GOING_TO_SITE,
  async (payload: GetAllMaterialGoingToSiteRequest = paginationPayload) => {
    const response = await call<GetAllMaterialGoingToSiteResponse>({
      url: `${
        MaterialToSiteEndpointsEnum.GET_ALL_MATERIAL_GOING_TO_SITE
      }?${getUrlParams(payload)?.toString()}`,
      method: "GET",
    });
    return response;
  }
);

export type MaterialGoingToSite = Omit<
  MaterialTransfer,
  | "createdDate"
  | "modifiedDate"
  | "modifiedBy"
  | "destinationSublocationName"
  | "destinationLocationName"
  | "originalLocationName"
  | "projectName"
  | "transferDate"
> & { transferDate: Dayjs | Date | string };

type CreateMaterialGoingToSiteResponse = Response & {
  materialToSite: MaterialGoingToSite;
};

export const createMaterialGoingToSite = createAsyncThunk(
  MaterialToSiteEndpointsEnum.CREATE_MATERIAL_GOING_TO_SITE,
  async (payload: Omit<MaterialGoingToSite, "id">) => {
    const response = await call<CreateMaterialGoingToSiteResponse>({
      url: MaterialToSiteEndpointsEnum.CREATE_MATERIAL_GOING_TO_SITE,
      method: "POST",
      payload,
    });
    return response;
  }
);

type EditMaterialGoingToSiteResponse = Response & {
  materialToSite: MaterialGoingToSite;
};
export const editMaterialGoingToSiteById = createAsyncThunk(
  MaterialToSiteEndpointsEnum.UPDATE_MATERIAL_GOING_TO_SITE,
  async (payload: MaterialGoingToSite & { materialGoingToSiteId: string }) => {
    const response = await call<EditMaterialGoingToSiteResponse>({
      payload,
      url: `${MaterialToSiteEndpointsEnum.UPDATE_MATERIAL_GOING_TO_SITE}/${payload.materialGoingToSiteId}`,
      method: "PUT",
    });
    return response;
  }
);

type DeleteMaterialGoingToSiteResponse = Response & {
  id: string;
};
export const deleteMaterialGoingToSiteById = createAsyncThunk(
  MaterialToSiteEndpointsEnum.DELETE_MATERIAL_GOING_TO_SITE,
  async (materialTransferId: string) => {
    const response = await call<DeleteMaterialGoingToSiteResponse>({
      url: `${MaterialToSiteEndpointsEnum.DELETE_MATERIAL_GOING_TO_SITE}/${materialTransferId}`,
      method: "DELETE",
    });
    return response;
  }
);
type getAllMaterialGoingToSiteByIdResponse = Response & {
  materialToSite: MaterialTransfer & {};
};

export const getMaterialGoingToSiteByIdAsync = async (
  materialGoingToSiteId: string | undefined
) => {
  const response = await call<getAllMaterialGoingToSiteByIdResponse>({
    url: `${MaterialToSiteEndpointsEnum.GET_ALL_MATERIAL_GOING_TO_SITE_BY_ID}/${materialGoingToSiteId}`,
    method: "GET",
  });
  return response;
};
