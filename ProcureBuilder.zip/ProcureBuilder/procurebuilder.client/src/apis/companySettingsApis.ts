import { createAsyncThunk } from "@reduxjs/toolkit";
import {
  CompanySettings,
  PurchaseOrderSettings,
  Response,
  ReorderSettings,
} from "../utils/types";
import { call } from "@utils/api-helpers";

enum endpoints {
  //Company
  GET_ALL_COMPANY_DETAILS = "company/info",
  UPDATE_COMPANY = "company/updateInfo",

  //Purchase Order
  GET_ALL_PURCHASE_ORDER_DETAILS = "company/purchaseOrderSettings",
  UPDATE_PURCHASE_ORDER = "company/updatePurchaseOrderSettings",

  //Reorder
  GET_ALL_REORDER_DETAILS = "company/reorderSettings",
  UPDATE_REORDER = "company/updateReorderSettings",
}

//Company
type GetAllCompanyDetailsResponse = Response & { companyInfo: CompanySettings };
export const getAllCompanyDetails = createAsyncThunk(
  endpoints.GET_ALL_COMPANY_DETAILS,
  async () => {
    const response = await call<GetAllCompanyDetailsResponse>({
      url: endpoints.GET_ALL_COMPANY_DETAILS,
      method: "GET",
    });
    return response;
  }
);

type EditCompanyResponse = Response & { companyInfo: CompanySettings };

type EditCompanyRequest = {
  payload: FormData;
};
export const editCompanyDetails = createAsyncThunk(
  endpoints.UPDATE_COMPANY,
  async ({ payload }: EditCompanyRequest) => {
    const response = await call<EditCompanyResponse>({
      payload,
      url: endpoints.UPDATE_COMPANY,
      method: "POST",
      isFormData: true,
    });
    return response;
  }
);

//Purchase Order
type GetAllPurchaseOrderDetailsResponse = Response & {
  settings: PurchaseOrderSettings;
};
export const getAllPurchaseOrderDetails = createAsyncThunk(
  endpoints.GET_ALL_PURCHASE_ORDER_DETAILS,
  async () => {
    const response = await call<GetAllPurchaseOrderDetailsResponse>({
      url: endpoints.GET_ALL_PURCHASE_ORDER_DETAILS,
      method: "GET",
    });
    return response;
  }
);

type EditPurchaseOrderRequest = Pick<
  PurchaseOrderSettings,
  | "limitOne"
  | "limitTwoFrom"
  | "limitTwoTo"
  | "termsAndConditions"
  | "createdBy"
> & {
  superApproverIds: string[];
  limitOneApproverIds: string[];
  limitTwoApproverIds: string[];
};
type EditPurchaseOrderResponse = Response & { settings: PurchaseOrderSettings };
export const editPurchaseOrderDetails = createAsyncThunk(
  endpoints.UPDATE_PURCHASE_ORDER,
  async (payload: EditPurchaseOrderRequest) => {
    const response = await call<EditPurchaseOrderResponse>({
      payload,
      url: endpoints.UPDATE_PURCHASE_ORDER,
      method: "POST",
    });
    return response;
  }
);

//Reorder
type GetAllReorderResponse = Response & ReorderSettings;
export const getAllReorderDetails = createAsyncThunk(
  endpoints.GET_ALL_REORDER_DETAILS,
  async () => {
    const response = await call<GetAllReorderResponse>({
      url: endpoints.GET_ALL_REORDER_DETAILS,
      method: "GET",
    });
    return response;
  }
);

type EditReorderResponse = Response & ReorderSettings;
export const editReorderDetails = createAsyncThunk(
  endpoints.UPDATE_REORDER,
  async (payload: ReorderSettings) => {
    const response = await call<EditReorderResponse>({
      payload,
      url: endpoints.UPDATE_REORDER,
      method: "POST",
    });
    return response;
  }
);
