import { createAsyncThunk } from "@reduxjs/toolkit";
import { call } from "@utils/api-helpers";
import { UserRoleEnum } from "../utils/enums";
import { Approver, Response, User } from "../utils/types";

enum endpoints {
  LOGIN = "auth/login",
  FORGOTPASS = "auth/sendForgotPasswordEmail",
  VERIFYOTP = "auth/verifyOTP",
  RESET_PASSWORD = "auth/resetPassword",
  UPDATE_PERSONAL_INFO = "auth/updatePersonalInfo",
  Delete_INTERNAL_USER = "auth/deleteInternalUser",
  CHANGE_PASSWORD = "auth/changePassword",
  ALL_USERS_SUMMARY_LIST = "auth/list",
}
type LoginUserByEmailRequest = { UserName: string; Password: string };
type LoginUserByEmailResponse = Response & User;
export const loginUserByEmail = createAsyncThunk(
  endpoints.LOGIN,
  async (payload: LoginUserByEmailRequest) => {
    const response = await call<LoginUserByEmailResponse>({
      payload,
      url: endpoints.LOGIN,
    });
    return response;
  }
);

type ForgotPasswordByEmailRequest = Response & { Email: string | null };

export const forgotPasswordByEmail = async (payload: {
  Email: string | null;
}) => {
  const response: ForgotPasswordByEmailRequest = await call({
    payload,
    url: endpoints.FORGOTPASS,
  });
  return response;
};

type VerifyOtpByEmailRequest = Response & { resetPasswordToken: string };

export const verifyOtpByEmail = async (payload: {
  Email: string | null;
  OTP: number | null | undefined;
}) => {
  const response: VerifyOtpByEmailRequest = await call({
    payload,
    url: endpoints.VERIFYOTP,
  });
  return response;
};

type ResetPasswordFormRequest = Response & { Password?: string };

export const resetPasswordForm = async (payload: {
  Password: string | null;
  Email: string | null;
  ModifiedBy?: string | null | undefined;
  resetPasswordToken: string | null;
}) => {
  const response: ResetPasswordFormRequest = await call({
    payload,
    url: endpoints.RESET_PASSWORD,
  });
  return response;
};
export const deleteInternalUser = createAsyncThunk(
  endpoints.Delete_INTERNAL_USER,
  async (payload: { userId: string | null }) => {
    const response: ResetPasswordFormRequest = await call({
      url: `${endpoints.Delete_INTERNAL_USER}/${payload.userId}`,
      method: "DELETE",
    });
    return response;
  }
);
type UpdatePersonalInfoRequest = {
  payload: {
    firstName: string;
    lastName: string;
    phoneNumber: string;
    cellNumber?: string;
    modifiedBy: string;
  };
  userId: string;
};
type UpdatePersonalInfoResponse = Response & User;
export const updatePersonalInfo = createAsyncThunk(
  endpoints.UPDATE_PERSONAL_INFO,
  async ({ payload, userId }: UpdatePersonalInfoRequest) => {
    const response = await call<UpdatePersonalInfoResponse>({
      payload,
      url: `${endpoints.UPDATE_PERSONAL_INFO}/${userId || ""}`,
      method: "PUT",
    });
    return response;
  }
);

type UpdatePasswordResponse = Response & User;

type ChangePasswordRequest = {
  payload: {
    email: string;
    oldPassword: string;
    newPassword: string;
    modifiedBy: string;
  };
};
export const changePassword = createAsyncThunk(
  endpoints.CHANGE_PASSWORD,
  async ({ payload }: ChangePasswordRequest) => {
    const response = await call<UpdatePasswordResponse>({
      payload,
      url: endpoints.CHANGE_PASSWORD,
      method: "POST",
    });
    return response;
  }
);

type GetAllUsersSummaryListRequest = {
  roles: UserRoleEnum[];
};
type GetAllUsersSummaryListResponse = Response & {
  users: Array<Approver>;
};
export const getAllUsersSummaryList = createAsyncThunk(
  endpoints.ALL_USERS_SUMMARY_LIST,
  async (payload: GetAllUsersSummaryListRequest) => {
    // console.log(payload);
    const response = await call<GetAllUsersSummaryListResponse>({
      payload,
      url: endpoints.ALL_USERS_SUMMARY_LIST,
      method: "POST",
    });
    return response;
  }
);
