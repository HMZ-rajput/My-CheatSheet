import { createAsyncThunk } from "@reduxjs/toolkit";
import { Customer, Response, ResponseWithPagination } from "../utils/types";
import { call, getUrlParams } from "@utils/api-helpers";
import { paginationPayload } from "../utils/constants";

enum endpoints {
  GET_ALL_CUSTOMERS = "customers",
  GET_CUSTOMER_BY_ID = "customers/",
  CREATE_CUSTOMER = "customers/create",
  UPDATE_CUSTOMER = "customers/update",
  DELETE_CUSTOMER = "customers/delete",
  REMOVE_CUSTOMER = "customers/remove",
}

type GetAllCustomersResponse = ResponseWithPagination & {
  customers: Customer[];
};

type GetAllCustomersRequest = typeof paginationPayload & {
  search?: string;
};

export const getAllCustomers = createAsyncThunk<
  GetAllCustomersResponse,
  GetAllCustomersRequest
>(
  endpoints.GET_ALL_CUSTOMERS,
  async (payload: GetAllCustomersRequest = paginationPayload) => {
    const response = await call<GetAllCustomersResponse>({
      // url: `${endpoints.GET_ALL_CUSTOMERS}?PageNumber=${payload?.pageNumber}&PageSize=${payload?.pageSize}&Search=${payload.search}`,
      url: `${endpoints.GET_ALL_CUSTOMERS}?${getUrlParams(
        payload
      )?.toString()}`,
      method: "GET",
    });
    return response;
  }
);

type GetCustomerByIdResponse = Response & { customer: Customer };
type GetCustomerByIdRequest = string;
export const getCustomerById = createAsyncThunk<
  GetCustomerByIdResponse,
  GetCustomerByIdRequest
>(endpoints.GET_CUSTOMER_BY_ID, async (customerId) => {
  const response = await call<GetCustomerByIdResponse>({
    url: `${endpoints.GET_CUSTOMER_BY_ID}${customerId || ""}`,
    method: "GET",
  });
  return response;
});

type CreateCustomerResponse = Response & {
  customer: Customer;
};
export const createCustomer = createAsyncThunk(
  endpoints.CREATE_CUSTOMER,
  async (
    payload: Omit<Customer, "id" | "createdDate" | "modifiedDate" | "projects">
  ) => {
    const response = await call<CreateCustomerResponse>({
      payload,
      url: endpoints.CREATE_CUSTOMER,
    });
    return response;
  }
);
type EditCustomerResponse = Response & {
  customer: Customer;
};
export const editCustomerById = createAsyncThunk(
  endpoints.UPDATE_CUSTOMER,
  async (payload: Customer) => {
    const response = await call<EditCustomerResponse>({
      payload,
      url: `${endpoints.UPDATE_CUSTOMER}/${payload.id}`,
      method: "PUT",
    });
    return response;
  }
);

type DeleteCustomerResponse = Response & {
  customer: Customer;
};
export const deleteCustomerById = createAsyncThunk(
  endpoints.DELETE_CUSTOMER,
  async (customerId: string) => {
    const response = await call<DeleteCustomerResponse>({
      url: `${endpoints.DELETE_CUSTOMER}/${customerId}`,
      method: "DELETE",
    });
    return response;
  }
);

type RemoveCustomerResponse = Response & {
  customer: Customer;
};
type RemoveCustomerRequest = {
  customerId: string;
  projectId: string;
};

export const removeCustomerById = createAsyncThunk(
  endpoints.REMOVE_CUSTOMER,
  async ({ customerId, projectId }: RemoveCustomerRequest) => {
    const response = await call<RemoveCustomerResponse>({
      url: `${endpoints.REMOVE_CUSTOMER}/${customerId}/project/${projectId}`,
      method: "PUT",
    });
    return response;
  }
);
