import { createAsyncThunk } from "@reduxjs/toolkit";
import {
  QualityAnswersRequestType,
  QualityQuestionAnswers,
  Response,
} from "@utils/types";
import { call } from "@utils/api-helpers";

enum QualityAnswersEndpoints {
  GET_ALL_ANSWERS = "qualityAnswer",
  CREATE_ANSWERS = "qualityAnswer/create",
  UPDATE_ANSWERS = "qualityAnswer/update",
  DELETE_ANSWERS = "qualityAnswer/delete/materialReceiptInspection",
}

// Get All Answers By Project Id
type GetAllAnsersResponse = Response & {
  qualityAnswers: QualityQuestionAnswers[];
};
type GetAllAnswersArg = {
  materialReceiptInspectionId: string | null;
};
export const getAllQualityAnswers = createAsyncThunk<
  GetAllAnsersResponse,
  GetAllAnswersArg
>(
  QualityAnswersEndpoints.GET_ALL_ANSWERS,
  async ({ materialReceiptInspectionId }) => {
    const response = await call<GetAllAnsersResponse>({
      url: `${QualityAnswersEndpoints.GET_ALL_ANSWERS}/${materialReceiptInspectionId}`,
      method: "GET",
    });
    return response;
  }
);

// Create Quality Answer
type CreateAnswersResponse = Response & {
  qualityAnswers: QualityQuestionAnswers[];
};
export const createQualityAnswers = createAsyncThunk(
  QualityAnswersEndpoints.CREATE_ANSWERS,
  async (payload: QualityAnswersRequestType) => {
    const response = await call<CreateAnswersResponse>({
      payload,
      url: QualityAnswersEndpoints.CREATE_ANSWERS,
    });
    return response;
  }
);

// Edit/Update Quality Answer
type EditAnswersResponse = Response & {
  qualityAnswers: QualityQuestionAnswers[];
};
export const updateQualityAnswers = createAsyncThunk(
  QualityAnswersEndpoints.UPDATE_ANSWERS,
  async (payload: QualityAnswersRequestType) => {
    const response = await call<EditAnswersResponse>({
      payload,
      url: QualityAnswersEndpoints.UPDATE_ANSWERS,
      method: "PUT",
    });
    return response;
  }
);

// Delete Quality Answers By material Receipt Inspection Id
type DeleteAnswersResponse = Response & {
  qualityAnswers: QualityQuestionAnswers[];
};
type DeleteAnswersArg = {
  materialReceiptInspectionId: string | null;
};
export const deleteQualityAnswers = createAsyncThunk(
  QualityAnswersEndpoints.DELETE_ANSWERS,
  async ({ materialReceiptInspectionId }: DeleteAnswersArg) => {
    const response = await call<DeleteAnswersResponse>({
      url: `${QualityAnswersEndpoints.DELETE_ANSWERS}/${materialReceiptInspectionId}`,
      method: "DELETE",
    });
    return response;
  }
);
