import { createAsyncThunk } from "@reduxjs/toolkit";
import { call, getUrlParams } from "@utils/api-helpers";
import { paginationPayload } from "../utils/constants";
import {
  BidMaterialRequestType,
  BidMaterialsResponse,
  BidReportMaterial,
  Response,
} from "../utils/types";

enum endpoints {
  GET_BID_MATERIAL_BY_PROJECT = "bidMaterial",
  DELETE_BID_MATERIAL = "bidMaterial/delete",
  CREATE_BID_MATERIAL = "bidMaterial/create",
  UPDATE_BID_MATERIAL = "bidMaterial/update",
  GET_BID_MATERIALS_LIST = "bidMaterial/list",
  GET_BID_MATERIALS_FOR_REPORTS = "bidMaterial/report",
}

type BidMaterialOrderArgs = {
  projectId: string | undefined;
};
export const getBidMaterialsById = createAsyncThunk(
  endpoints.GET_BID_MATERIAL_BY_PROJECT,
  async ({ projectId }: BidMaterialOrderArgs) => {
    const response = await call<BidMaterialsResponse>({
      url: `${endpoints.GET_BID_MATERIAL_BY_PROJECT}/${projectId}`,
      method: "GET",
    });

    const bidMaterials: Omit<BidMaterialRequestType, "changeOrderIds"> &
      Response = {
      assumedSubmittalReview: response.project.assumedSubmittalReview || 0,
      isMaterialReceiptInspectionFormRequired:
        response.project.isMaterialReceiptInspectionFormRequired || false,
      assumedSubmittalReviewPeriod:
        response.project.assumedSubmittalReviewPeriod || 0,
      subTotal: response.project.subTotal || 0,
      materials: response.materials,
      isSuccess: response.isSuccess,
      errors: response.errors,
      createdDate: response.createdDate,
      createdBy: response.createdBy,
      projectId: response.project?.id,
      tax: response.tax || 0,
      taxPercentage: response.taxPercentage || 0,
      total: response.total || 0,
      otherCosts: response.otherCosts || 0,
    };

    return bidMaterials;
  }
);

export const createBidMaterials = createAsyncThunk(
  endpoints.CREATE_BID_MATERIAL,
  async (payload: BidMaterialRequestType) => {
    const response = await call<BidMaterialsResponse>({
      payload,
      url: `${endpoints.CREATE_BID_MATERIAL}`,
      method: "POST",
    });

    const bidMaterials: Omit<BidMaterialRequestType, "changeOrderIds"> &
      Response = {
      assumedSubmittalReview: response.project.assumedSubmittalReview || 0,
      isMaterialReceiptInspectionFormRequired:
        response.project.isMaterialReceiptInspectionFormRequired || false,
      assumedSubmittalReviewPeriod:
        response.project.assumedSubmittalReviewPeriod || 0,
      subTotal: response.project.subTotal || 0,
      materials: response.materials,
      isSuccess: response.isSuccess,
      errors: response.errors,
      createdDate: response.createdDate,
      createdBy: response.createdBy,
      projectId: response.project?.id,
      tax: response.project.tax || 0,
      taxPercentage: response.project.taxPercentage || 0,
      total: response.project.total || 0,
      otherCosts: response.project.otherCosts || 0,
    };

    return bidMaterials;
  }
);

export const editBidMaterials = createAsyncThunk(
  endpoints.UPDATE_BID_MATERIAL,
  async (payload: BidMaterialRequestType) => {
    const response = await call<BidMaterialsResponse>({
      payload,
      url: `${endpoints.UPDATE_BID_MATERIAL}`,
      method: "PUT",
    });

    const bidMaterials: Omit<BidMaterialRequestType, "changeOrderIds"> &
      Response = {
      assumedSubmittalReview: response.project.assumedSubmittalReview || 0,
      isMaterialReceiptInspectionFormRequired:
        response.project.isMaterialReceiptInspectionFormRequired || false,
      assumedSubmittalReviewPeriod:
        response.project.assumedSubmittalReviewPeriod || 0,
      subTotal: response.project.subTotal || 0,
      materials: response.materials,
      isSuccess: response.isSuccess,
      errors: response.errors,
      createdDate: response.createdDate,
      createdBy: response.createdBy,
      projectId: response.project?.id,
      tax: response.project.tax || 0,
      taxPercentage: response.project.taxPercentage || 0,
      total: response.project.total || 0,
      otherCosts: response.project.otherCosts || 0,
    };

    return bidMaterials;
  }
);

type BidMaterialsListRequestType = string;
type BidMaterialsListResponseType = {
  name: string;
  costCode: string;
};
type BidMaterialsApiResponse = {
  bidMaterials: BidMaterialsListResponseType[];
};

export const getBidMaterialsList = createAsyncThunk(
  endpoints.GET_BID_MATERIALS_LIST,
  async (payload: BidMaterialsListRequestType) => {
    const response = await call<BidMaterialsApiResponse>({
      url: `${endpoints.GET_BID_MATERIALS_LIST}?projectId=${payload}`,
      method: "GET",
    });
    return response.bidMaterials;
  }
);

type BidMaterialDeleteRequestType = {
  projectId?: string;
  materials: string[] | [];
};

export const deleteBidMaterialById = createAsyncThunk(
  endpoints.DELETE_BID_MATERIAL,
  async (payload: BidMaterialDeleteRequestType) => {
    const response = await call<BidMaterialsResponse>({
      payload,
      url: `${endpoints.DELETE_BID_MATERIAL}`,
      method: "DELETE",
    });

    return response;
  }
);

type GetBidMaterialsForReportRequest = typeof paginationPayload & {
  projectId?: string;
  projectTypeId?: string;
  isMRIRequired?: string;
  totalPriceFrom?: number;
  totalPriceTo?: number;
  assumedSubmittalReview?: number;
  assumedSubmittalReviewPeriod?: string;
};
type GetBidMaterialsForReportResponse = Response & {
  bidMaterials: BidReportMaterial[];
  totalCount: number;
  totalBudget: number;
  totalMRIFNotRequired: number;
  totalMRIFRequired: number;
  totalMaterials: number;
};
export const getBidMaterialsForReport = async (
  payload: GetBidMaterialsForReportRequest = paginationPayload
) => {
  const response = await call<GetBidMaterialsForReportResponse>({
    payload,
    url: `${endpoints.GET_BID_MATERIALS_FOR_REPORTS}?${getUrlParams(payload)}`,
    method: "GET",
  });

  return response;
};
