import { createAsyncThunk } from "@reduxjs/toolkit";
import { call } from "@utils/api-helpers";
import { OnlyQuestion, Response } from "@utils/types";

enum endpoints {
  GET_ALL_QUESTIONS = "qualityQuestion/project", // projectId in params as payload in getAllQuestions function
  CREATE_QUESTIONS = "qualityQuestion/create",
  UPDATE_QUESTIONS = "qualityQuestion/update/project",
  DELETE_QUESTIONS = "qualityQuestion/delete/project", // projectId in params as payload in getAllQuestions function
}

type GetAllQuestionsResponse = Response & OnlyQuestion;
export const getAllQuestions = createAsyncThunk(
  endpoints.GET_ALL_QUESTIONS,
  async (payload: { projectId: string }) => {
    const response = await call<GetAllQuestionsResponse>({
      url: `${endpoints.GET_ALL_QUESTIONS}/${payload.projectId}`,
      method: "GET",
    });
    return response;
  }
);
// type GetQuestionByIdResponse = Response & { questions: Question };
// export const getQuestionById = async (questionId: string) => {
//   const response = await call<GetQuestionByIdResponse>({
//     url: `${endpoints.GET_ALL_QUESTIONS}/${questionId || ""}`,
//     method: "GET",
//   });
//   return response;
// };

type CreateQuestionsRequest = {
  projectId: string | undefined;
  createdBy: string;
  qualityQuestions: string[];
};
type CreateQuestionsResponse = Response & OnlyQuestion;
export const createQuestion = createAsyncThunk(
  endpoints.CREATE_QUESTIONS,
  async (payload: CreateQuestionsRequest) => {
    const response = await call<CreateQuestionsResponse>({
      payload,
      url: endpoints.CREATE_QUESTIONS,
    });
    return response;
  }
);

type EditQuestionRequest = OnlyQuestion;
// type EditQuestionRequest = {
//   projectId: string | undefined;
//   createdBy: string;
//   qualityQuestions:
//     | QualityQuestion[]
//     | {
//         question: string;
//       }[];
// };
type EditQuestionResponse = Response & OnlyQuestion;
export const editQuestions = createAsyncThunk(
  endpoints.UPDATE_QUESTIONS,
  async (payload: EditQuestionRequest) => {
    const { projectId, createdBy, qualityQuestions } = payload;
    const response = await call<EditQuestionResponse>({
      payload: {
        createdBy,
        qualityQuestions,
      },
      url: `${endpoints.UPDATE_QUESTIONS}/${projectId}`,
      method: "PUT",
    });
    return response;
  }
);

type DeleteQuestionsResponse = Response & OnlyQuestion;

export const deleteQuestions = createAsyncThunk(
  endpoints.DELETE_QUESTIONS,
  async (projectId: string) => {
    const response = await call<DeleteQuestionsResponse>({
      url: `${endpoints.DELETE_QUESTIONS}/${projectId}`,
      method: "DELETE",
    });
    return response;
  }
);
