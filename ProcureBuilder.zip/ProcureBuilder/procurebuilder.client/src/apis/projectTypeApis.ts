import { createAsyncThunk } from "@reduxjs/toolkit";
import { ProjectType, Response } from "../utils/types";
import { call } from "@utils/api-helpers";

enum endpoints {
  GET_ALL_PROJECT_TYPES = "projects/types",
}

type GetAllProjectTypesResponse = Response & { projectTypes: ProjectType[] };
export const getAllProjectTypes = createAsyncThunk(
  endpoints.GET_ALL_PROJECT_TYPES,
  async () => {
    const response = await call<GetAllProjectTypesResponse>({
      url: endpoints.GET_ALL_PROJECT_TYPES,
      method: "GET",
    });

    return response;
  }
);
