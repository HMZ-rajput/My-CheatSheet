import { createAsyncThunk } from "@reduxjs/toolkit";
import { call, getUrlParams } from "@utils/api-helpers";
import { paginationPayload } from "../utils/constants";
import {
  Invoice,
  InvoicePOInvoiceReportRow,
  InvoicePOReportRow,
  InvoiceProjectCostCodeReportRow,
  InvoiceProjectReportRow,
  InvoiceReportFilters,
  Material,
  Response,
  ResponseWithPagination,
} from "../utils/types";

enum endpoints {
  GET_ALL_INVOICES = "invoice",
  GET_MATERIALS_BY_PO = "invoice/materialList",
  CREATE_INVOICES = "invoice/create",
  UPDATE_INVOICES = "invoice/update",
  DELETE_INVOICE = "invoice/delete",
  GET_INVOICE_PROJECT_REPORT_LIST = "invoice/projectReport",
  GET_INVOICE_PROJECT_COST_CODE_REPORT_LIST = "invoice/projectCostCodeReport",
  GET_INVOICE_PO_REPORT_LIST = "invoice/purchaseOrderReport",
  GET_INVOICE_PO_INVOICES_REPORT_LIST = "invoice/purchaseOrderInvoicesReport",
}

type GetAllInvoicesResponse = ResponseWithPagination & {
  invoices: Invoice[];

  totalAmount?: number;
  totalPending?: number;
  totalPartiallyPaid?: number;
  totalFullyPaid?: number;
  totalNet60?: number;
  totalNet45?: number;
  totalNet30?: number;
};
type GetAllInvoicesRequest = typeof paginationPayload & {
  status?: string | number;
  search?: string;
  isUpComing?: string;
  isOverDue?: string;
  isDueToday?: string;
  projectId?: string;
};

export const getAllInvoices = createAsyncThunk<
  GetAllInvoicesResponse,
  GetAllInvoicesRequest
>(
  endpoints.GET_ALL_INVOICES,
  async (payload: GetAllInvoicesRequest = paginationPayload) => {
    const response = await call<GetAllInvoicesResponse>({
      url: `${endpoints.GET_ALL_INVOICES}?${getUrlParams(payload)?.toString()}`,
      method: "GET",
    });
    return response;
  }
);

type GetInvoicesByIdResponse = ResponseWithPagination & {
  invoice: Invoice;
};
type GetInvoicesByIdRequest = {
  invoiceId: string;
};

export const getAllInvoicesById = createAsyncThunk<
  GetInvoicesByIdResponse,
  GetInvoicesByIdRequest
>(endpoints.GET_ALL_INVOICES, async (payload: GetInvoicesByIdRequest) => {
  const response = await call<GetInvoicesByIdResponse>({
    url: `${endpoints.GET_ALL_INVOICES}/${payload?.invoiceId}`,
    method: "GET",
  });
  return response;
});

type GetMaterialsByPurchaseOrderByIdReq = {
  purchaseOrderId: string;
};
type GetMaterialsByPurchaseOrderByIdRes = {
  materials: Material[];
  purchaseOrderTaxPercentage?: number;
};

export const getMaterialsByPurchaseOrderById = createAsyncThunk<
  GetMaterialsByPurchaseOrderByIdRes,
  GetMaterialsByPurchaseOrderByIdReq
>(
  endpoints.GET_MATERIALS_BY_PO, // Action type
  async (payload: GetMaterialsByPurchaseOrderByIdReq) => {
    const response = await call<GetMaterialsByPurchaseOrderByIdRes>({
      url: `${endpoints.GET_MATERIALS_BY_PO}?${getUrlParams(
        payload
      )?.toString()}`,
      method: "GET",
    });
    return response;
  }
);

type CreateInvoiceResponse = Response & {
  invoice: Invoice;
};
export const createInvoice = createAsyncThunk(
  endpoints.CREATE_INVOICES,
  async (payload: FormData) => {
    const response = await call<CreateInvoiceResponse>({
      payload,
      isFormData: true,
      url: endpoints.CREATE_INVOICES,
    });
    return response;
  }
);

type UpdateInvoiceResponse = Response & {
  // payload: FormData;
  // invoiceId?: string;
  invoice: Invoice;
};
type UpdateInvoiceRequest = {
  formData: FormData;
  invoiceId?: string;
};
export const updateInvoiceById = createAsyncThunk(
  endpoints.UPDATE_INVOICES,
  async (payload: UpdateInvoiceRequest) => {
    const response = await call<UpdateInvoiceResponse>({
      payload: payload.formData,
      url: `${endpoints.UPDATE_INVOICES}/${payload.invoiceId}`,
      method: "PUT",
    });
    return response;
  }
);

export const deleteInvoiceById = createAsyncThunk(
  endpoints.DELETE_INVOICE,
  async (invoiceId: string) => {
    const response = await call<GetAllInvoicesResponse>({
      url: `${endpoints.DELETE_INVOICE}/${invoiceId}`,
      method: "DELETE",
    });
    return response;
  }
);

// Invoice Report APIs
type GetInvoiceProjectReportListRequest = typeof paginationPayload &
  InvoiceReportFilters;
type GetInvoiceProjectReportListResponse = Response & {
  data: InvoiceProjectReportRow[];
  totalCount: number;
};
export const getInvoiceProjectReportList = async (
  payload: GetInvoiceProjectReportListRequest = paginationPayload
) => {
  const response = await call<GetInvoiceProjectReportListResponse>({
    payload,
    url: `${endpoints.GET_INVOICE_PROJECT_REPORT_LIST}?${getUrlParams(
      payload
    )}`,
    method: "GET",
  });

  return response;
};

type GetInvoiceProjectCostCodeReportListRequest = typeof paginationPayload &
  InvoiceReportFilters;
type GetInvoiceProjectCostCodeReportListResponse = Response & {
  data: InvoiceProjectCostCodeReportRow[];
  totalCount: number;
};
export const getInvoiceProjectCostCodeReportList = async (
  payload: GetInvoiceProjectCostCodeReportListRequest = paginationPayload
) => {
  const response = await call<GetInvoiceProjectCostCodeReportListResponse>({
    payload,
    url: `${endpoints.GET_INVOICE_PROJECT_COST_CODE_REPORT_LIST}?${getUrlParams(
      payload
    )}`,
    method: "GET",
  });

  return response;
};

type GetInvoicePOReportListRequest = typeof paginationPayload &
  InvoiceReportFilters;
type GetInvoicePOReportListResponse = Response & {
  data: InvoicePOReportRow[];
  totalCount: number;
};
export const getInvoicePOReportList = async (
  payload: GetInvoicePOReportListRequest = paginationPayload
) => {
  const response = await call<GetInvoicePOReportListResponse>({
    payload,
    url: `${endpoints.GET_INVOICE_PO_REPORT_LIST}?${getUrlParams(payload)}`,
    method: "GET",
  });

  return response;
};

type GetInvoicePODetailsReportListRequest = typeof paginationPayload &
  InvoiceReportFilters & { purchaseOrderId?: string };
type GetInvoicePODetailsReportListResponse = Response & {
  data: InvoicePOInvoiceReportRow[];
  totalCount: number;
};
export const getInvoicePODetailsReportList = async ({
  purchaseOrderId,
  ...payload
}: GetInvoicePODetailsReportListRequest = paginationPayload) => {
  const response = await call<GetInvoicePODetailsReportListResponse>({
    payload,
    url: `${
      endpoints.GET_INVOICE_PO_INVOICES_REPORT_LIST
    }/${purchaseOrderId}?${getUrlParams(payload)}`,
    method: "GET",
  });

  return response;
};
