import { createAsyncThunk } from "@reduxjs/toolkit";
import { ProjectManager, Response } from "../utils/types";
import { call } from "@utils/api-helpers";

enum endpoints {
  GET_ALL_MANAGERS = "auth/managers",
}

type GetAllProjectManagersResponse = Response & { managers: ProjectManager[] };
export const getAllProjectManagers = createAsyncThunk(
  endpoints.GET_ALL_MANAGERS,
  async () => {
    const response = await call<GetAllProjectManagersResponse>({
      url: endpoints.GET_ALL_MANAGERS,
      method: "GET",
    });

    return response;
  }
);
