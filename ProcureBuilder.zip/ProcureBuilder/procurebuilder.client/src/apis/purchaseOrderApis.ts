import { createAsyncThunk } from "@reduxjs/toolkit";
import { call, getUrlParams } from "@utils/api-helpers";
import { paginationPayload } from "../utils/constants";
import { ApprovalStatusEnum, AuthorizingEntityEnum } from "../utils/enums";
import {
  ApprovalDetails,
  PurchaseOrder,
  PurchaseOrderApprovalDetail,
  PurchaseOrderApprovalVendor,
  PurchaseOrderMaterials,
  PurchaseOrdersList,
  PurchaseOrderWithApproval,
  Response,
  ResponseWithPagination,
  Vendor,
} from "../utils/types";

enum PurchaseOrderEndpointsEnum {
  GET_ALL_PURCHASE_ORDERS = "purchaseOrders",
  GET_ALL_PURCHASE_ORDER_By_ID = "purchaseOrders/",
  GET_ALL_PURCHASE_ORDERS_LIST = "purchaseOrders/list",
  GET_ALL_PURCHASE_ORDERS_MATERIALS = "purchaseOrders/materialList",
  GET_PURCHASE_ORDER_NEW_NUMBER = "purchaseOrders/newPurchaseOrderNumber",
  CREATE_PURCHASE_ORDER = "purchaseOrders/createPurchaseOrder",
  UPDATE_PURCHASE_ORDER_VENDOR = "purchaseOrders/updateVendor",
  UPDATE_PURCHASE_ORDER_PROCUREMENT_DETAILS = "purchaseOrders/updateProcurement",
  UPDATE_PURCHASE_ORDER = "purchaseOrders/update",
  DELETE_PURCHASE_ORDER = "purchaseOrders/delete",
  VENDOR_APPROVE_BY_PO_ID = "purchaseOrders/vendorApprove",

  //Vendor Details
  PO_VENDOR_GET_By_ID = "purchaseOrders/vendorDetails",
  // PO APPROVAL
  PO_APPROVAL_CREATE = "purchaseOrderApprovals/create",
  PO_APPROVAL_GET_By_ID = "purchaseOrderApprovals",

  // Download PDF
  DOWNLOAD_PDF_FOR_PO = "purchaseOrders/document/:purchaseOrderId",
  DOWNLOAD_PDF_FOR_SINGLE_MATERIAL = "purchaseOrders/document/:purchaseOrderId/material/:materialId",
  DOWNLOAD_PO_REPORT = "purchaseOrders/:purchaseOrderId/PDF/:pdfType",
}

type GetAllPurchaseOrdersResponse = ResponseWithPagination & {
  purchaseOrders: PurchaseOrder[];
  totalPurchaseOrders?: number;
  totalCost?: number;
  totalPendingAdminApproval?: number;
  totalAdminApprovedPartial?: number;
  totalAdminApprovedAll?: number;
  totalAdminRejected?: number;
  totalVendorApprovalPending?: number;
  totalVendorApproved?: number;
  totalVendorRejected?: number;
  totalPartiallyReceived?: number;
  totalFullyReceived?: number;
  totalAdminSigned?: number;
  totalNet60?: number;
  totalNet45?: number;
  totalNet30?: number;
};
type GetAllPurchaseOrdersRequest = typeof paginationPayload & {
  purchaseOrderSubmittalStatus?: string | number;
  purchaseOrderStatus?: string | number;
  search?: string;
  isUpComing?: string;
  isOverDue?: string;
  isDueToday?: string;
  projectId?: string;
  vendorId?: string;
  locationId?: string;
  paymentTerm?: number;
  priceFrom?: number;
  priceTo?: number;
  dueDateFrom?: string;
  dueDateTo?: string;
};
export const getAllPurchaseOrders = createAsyncThunk<
  GetAllPurchaseOrdersResponse,
  GetAllPurchaseOrdersRequest
>(
  PurchaseOrderEndpointsEnum.GET_ALL_PURCHASE_ORDERS,
  async (payload: GetAllPurchaseOrdersRequest = paginationPayload) => {
    const response = await call<GetAllPurchaseOrdersResponse>({
      url: `${
        PurchaseOrderEndpointsEnum.GET_ALL_PURCHASE_ORDERS
      }?${getUrlParams(payload)?.toString()}`,
      method: "GET",
    });
    return response;
  }
);

export type GetPurchaseOrderNewNumberResponse = Response & {
  purchaseOrderNumber: string;
};
export const getPurchaseOrderNumber = async () => {
  const response = await call<GetPurchaseOrderNewNumberResponse>({
    url: PurchaseOrderEndpointsEnum.GET_PURCHASE_ORDER_NEW_NUMBER,
    method: "GET",
  });

  return response;
};

// type CreatePurchaseOrderRequestType = Omit<
//   PurchaseOrder,
//   "id" | "createdDate" | "modifiedDate"
// >;
export type CreatePurchaseOrderResponseType = Response & {
  purchaseOrder: PurchaseOrder;
};
export type getPurchaseOrderMaterialsResponseType = Response & {
  materials: PurchaseOrderMaterials[];
};

export const createPurchaseOrder = createAsyncThunk(
  PurchaseOrderEndpointsEnum.CREATE_PURCHASE_ORDER,
  async (payload: FormData) => {
    const response = await call<CreatePurchaseOrderResponseType>({
      payload: payload,
      url: `${PurchaseOrderEndpointsEnum.CREATE_PURCHASE_ORDER}`,
      method: "POST",
    });
    return response;
  }
);

// type PurchaseOrderApproval = {
//   signature: string;
//   company: string;
//   title: string;
//   status: number;
//   dateSigned: string;
//   authorizingEntity: number;
//   purchaseOrderId: string;
//   userId: string;
//   modifiedBy: string;
// };
type PurchaseOrderApprovalResponse = Response & {
  purchaseOrderApprovalDTO: null;
};

export const createPurchaseOrderApprovals = createAsyncThunk(
  PurchaseOrderEndpointsEnum.PO_APPROVAL_CREATE,
  async (payload: ApprovalDetails) => {
    const response = await call<PurchaseOrderApprovalResponse>({
      payload: payload,
      url: `${PurchaseOrderEndpointsEnum.PO_APPROVAL_CREATE}`,
      method: "POST",
    });
    return response;
  }
);

type PurchaseOrderListResponse = Response & {
  purchaseOrders: PurchaseOrdersList[];
};

type PayloadPurchaseOrdersRequest = {
  purchaseOrderId?: string;
  projectId?: string;
};
type PayloadPurchaseOrdersListRequest = {
  projectId?: string | null;
  isForMRI?: boolean;
  MRIStatus?: number;
};

// type PurchaseOrderApprovalsListResponse = Response & {
//   purchaseOrderApprovals: PurchaseOrder[];
// };

export const getPurchaseOrderApprovalsById = createAsyncThunk(
  PurchaseOrderEndpointsEnum.PO_APPROVAL_GET_By_ID,
  async (payload: PayloadPurchaseOrdersRequest) => {
    const response = await call<PurchaseOrderApprovalDetail & Response>({
      url: `${PurchaseOrderEndpointsEnum.PO_APPROVAL_GET_By_ID}/${payload?.purchaseOrderId}`,
      method: "GET",
    });
    return response;
  }
);

type PurchaseOrderVendorResponse = Response & {
  vendor: PurchaseOrderApprovalVendor;
};

type PurchaseOrderVendorReq = {
  purchaseOrderId: string;
};

export const getPurchaseOrderVendorById = createAsyncThunk(
  PurchaseOrderEndpointsEnum.PO_VENDOR_GET_By_ID,
  async (payload: PurchaseOrderVendorReq) => {
    const response = await call<PurchaseOrderVendorResponse & Response>({
      url: `${PurchaseOrderEndpointsEnum.PO_VENDOR_GET_By_ID}/${payload?.purchaseOrderId}`,
      method: "GET",
    });
    return response;
  }
);

export const getPurchaseOrdersList = createAsyncThunk(
  PurchaseOrderEndpointsEnum.GET_ALL_PURCHASE_ORDERS_LIST,
  async ({
    projectId,
    isForMRI = false,
    MRIStatus = 0,
  }: PayloadPurchaseOrdersListRequest) => {
    const response = await call<PurchaseOrderListResponse>({
      url: `${PurchaseOrderEndpointsEnum.GET_ALL_PURCHASE_ORDERS_LIST}?projectId=${projectId}&isForMRI=${isForMRI}&MRIStatus=${MRIStatus}`,
      method: "GET",
    });
    return response;
  }
);

type PayloadPurchaseOrdersById = {
  purchaseOrderId: string;
};

export const getPurchaseOrdersById = createAsyncThunk(
  PurchaseOrderEndpointsEnum.GET_ALL_PURCHASE_ORDER_By_ID,
  async (payload: PayloadPurchaseOrdersById) => {
    const response = await call<CreatePurchaseOrderResponseType>({
      url: `${PurchaseOrderEndpointsEnum.GET_ALL_PURCHASE_ORDER_By_ID}${payload?.purchaseOrderId}`,
      method: "GET",
    });
    return response;
  }
);
type PayloadPurchaseOrdersMaterialsById = {
  purchaseOrderId: string;
};

export const getPurchaseOrdersMaterialsById = createAsyncThunk(
  PurchaseOrderEndpointsEnum.GET_ALL_PURCHASE_ORDERS_MATERIALS,
  async (payload: PayloadPurchaseOrdersMaterialsById) => {
    const response = await call<getPurchaseOrderMaterialsResponseType>({
      url: `${PurchaseOrderEndpointsEnum.GET_ALL_PURCHASE_ORDERS_MATERIALS}?purchaseOrderId=${payload?.purchaseOrderId}`,
      method: "GET",
    });
    return response;
  }
);

type PurchaseOrderVendorRequestType = {
  id: string;
  payload: Pick<PurchaseOrder, "vendorAddress" | "modifiedBy"> & {
    vendorId: string;
  };
};

type PurchaseOrderVendor = {
  id: string;
  vendor: Pick<Vendor, "id" | "name">;
  vendorAddress: string;
  termsAndConditions: string;
  toRelease: boolean;
  modifiedBy: string;
  modifiedDate: string;
};

type PurchaseOrderVendorResponseType = Response & {
  purchaseOrderVendor: PurchaseOrderVendor;
};

export const updatePurchaseOrderVendor = createAsyncThunk(
  PurchaseOrderEndpointsEnum.UPDATE_PURCHASE_ORDER_VENDOR,
  async (payload: PurchaseOrderVendorRequestType) => {
    const response = await call<PurchaseOrderVendorResponseType>({
      payload: payload.payload,
      url: `${PurchaseOrderEndpointsEnum.UPDATE_PURCHASE_ORDER_VENDOR}/${payload.id}`,
      method: "PUT",
    });
    return response;
  }
);

type PurchaseOrderProcurementRequestType = Pick<
  PurchaseOrder,
  | "id"
  | "maxSubmittalLeadTime"
  | "expectedSubmittalDate"
  | "maxMaterialLeadTime"
  | "expectedDeliveryDate"
  | "submittalStatus"
  | "modifiedBy"
>;
type PurchaseOrderProcurmentUpdateType = {
  purchaseOrderProcurementUpdate: Pick<
    PurchaseOrder,
    | "maxSubmittalLeadTime"
    | "expectedSubmittalDate"
    | "maxMaterialLeadTime"
    | "expectedDeliveryDate"
    | "submittalStatus"
    | "modifiedBy"
  >;
};
type PurchaseOrderProcurementResponseType = Response &
  PurchaseOrderProcurmentUpdateType &
  Pick<PurchaseOrder, "id">;
export const updatePurchaseOrderProcurementDetails = createAsyncThunk(
  PurchaseOrderEndpointsEnum.UPDATE_PURCHASE_ORDER_PROCUREMENT_DETAILS,
  async (payload: PurchaseOrderProcurementRequestType) => {
    const response = await call<PurchaseOrderProcurementResponseType>({
      payload: payload,
      url: `${PurchaseOrderEndpointsEnum.UPDATE_PURCHASE_ORDER_PROCUREMENT_DETAILS}/${payload.id}`,
      method: "PUT",
    });
    return response;
  }
);

type PurchaseOrderEditRequestType = {
  id: string;
  formData: FormData;
};
type PurchaseOrderEditResponeType = Response & {
  purchaseOrder: PurchaseOrder;
};
export const updatePurchaseOrderById = createAsyncThunk(
  PurchaseOrderEndpointsEnum.UPDATE_PURCHASE_ORDER,
  async (payload: PurchaseOrderEditRequestType) => {
    const response = await call<PurchaseOrderEditResponeType>({
      payload: payload.formData,
      url: `${PurchaseOrderEndpointsEnum.UPDATE_PURCHASE_ORDER}/${payload.id}`,
      method: "PUT",
    });
    return response;
  }
);

type PurchaseOrderDeleteRequestType = {
  purchaseOrderId: string;
};
export const deletePurchaseOrderById = createAsyncThunk(
  PurchaseOrderEndpointsEnum.DELETE_PURCHASE_ORDER,
  async (payload: PurchaseOrderDeleteRequestType) => {
    const response = await call<PurchaseOrderEditResponeType>({
      payload,
      url: `${PurchaseOrderEndpointsEnum.DELETE_PURCHASE_ORDER}/${payload.purchaseOrderId}`,
      method: "DELETE",
    });
    return response;
  }
);

type POVendorApproveByPOIdRequest = {
  purchaseOrderId: string;
};
type POVendorApproveByPOIdResponse = Response & {
  purchaseOrder: PurchaseOrderWithApproval;
};
export const getPOVendorApproveByPOId = async (
  payload: POVendorApproveByPOIdRequest
) => {
  const response = await call<POVendorApproveByPOIdResponse>({
    payload,
    url: `${PurchaseOrderEndpointsEnum.VENDOR_APPROVE_BY_PO_ID}/${
      payload?.purchaseOrderId || ""
    }`,
    method: "GET",
  });
  return response;
};

type CreatePOApprovalRequest = {
  signature: string;
  company: string;
  title: string;
  status: ApprovalStatusEnum;
  dateSigned: string;
  approvalComments?: string;
  authorizingEntity: AuthorizingEntityEnum;
  purchaseOrderId: null | string;
  userId?: string;
};

type PurchaseOrderDTO = {
  id: string;
  modifiedDate: string;
  createdBy: string;
  createdDate: string;
  lastModifiedBy: string;
  lastModifiedDate: string;
  signature: string;
  company: string;
  title: string;
  approvalComments: string | null;
  status: number;
  dateSigned: string;
  authorizingEntity: number;
  purchaseOrderId: string;
  modifiedBy: string;
};

type CreatePOApprovalResponse = Response & {
  purchaseOrderApprovalDTO: PurchaseOrderDTO;
};
export const createPOApproval = async (payload: CreatePOApprovalRequest) => {
  const response = await call<CreatePOApprovalResponse>({
    payload,
    url: PurchaseOrderEndpointsEnum.PO_APPROVAL_CREATE,
    method: "POST",
  });
  return response;
};

// Download PDF
type DownloadPdfForPORequest = {
  purchaseOrderId: string;
};
export const downloadPdfForPO = async (payload: DownloadPdfForPORequest) => {
  const response = await call({
    payload,
    url: PurchaseOrderEndpointsEnum.DOWNLOAD_PDF_FOR_PO?.replace(
      ":purchaseOrderId",
      payload.purchaseOrderId
    ),
    method: "GET",
    responseType: "blob",
  });
  return response;
};

type DownloadPdfForSingleMaterialRequest = DownloadPdfForPORequest & {
  materialId: string;
};
export const downloadPdfForSingleMaterial = async (
  payload: DownloadPdfForSingleMaterialRequest
) => {
  const response = await call({
    payload,
    url: PurchaseOrderEndpointsEnum.DOWNLOAD_PDF_FOR_SINGLE_MATERIAL?.replace(
      ":purchaseOrderId",
      payload.purchaseOrderId
    )?.replace(":materialId", payload.materialId),
    method: "GET",
    responseType: "blob",
  });
  return response;
};

type POReportRequest = DownloadPdfForPORequest & {
  pdfType: string;
};
export const downloadPOReport = async (payload: POReportRequest) => {
  const response = await call({
    url: PurchaseOrderEndpointsEnum.DOWNLOAD_PO_REPORT?.replace(
      ":purchaseOrderId",
      payload.purchaseOrderId
    )?.replace(":pdfType", payload.pdfType),
    method: "GET",
    responseType: "blob",
  });

  return response;
};
