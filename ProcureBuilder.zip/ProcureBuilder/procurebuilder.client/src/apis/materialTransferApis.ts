import { createAsyncThunk } from "@reduxjs/toolkit";
import { call, getUrlParams } from "@utils/api-helpers";
import {
  MaterialTransfer,
  MaterialTransferAddMaterial,
  Response,
  ResponseWithPagination,
} from "@utils/types";
import { paginationPayload } from "../utils/constants";

export enum MaterialTransferEndpointsEnum {
  GET_ALL_MATERIAL_TRANSFER = "materialTransfer",
  GET_MATERIAL_TRANSFER_LIST = "materialTransfer/list",
  CREATE_MATERIAL_TRANSFER = "materialTransfer/create",
  UPDATE_MATERIAL_TRANSFER = "materialTransfer/update",
  DELETE_MATERIAL_TRANSFER = "materialTransfer/delete",
}

export type MaterialTransferListRequest = {
  purchaseOrderIds: string[] | [];
  projectLocationId: string;
};

type MaterialTransferListResponse = Response & {
  materials: MaterialTransferAddMaterial[];
  inventory: MaterialTransferAddMaterial[];
};

export const getAllMaterialTransferlist = createAsyncThunk(
  MaterialTransferEndpointsEnum.GET_MATERIAL_TRANSFER_LIST,
  async (payload: MaterialTransferListRequest) => {
    const url = `${MaterialTransferEndpointsEnum.GET_MATERIAL_TRANSFER_LIST}/${payload?.projectLocationId}`;
    const response = await call<MaterialTransferListResponse>({
      url: url,
      payload: { purchaseOrderIds: payload.purchaseOrderIds },
      method: "POST",
    });
    return response;
  }
);

type GetAllMaterialTransferResponse = ResponseWithPagination & {
  materialTransfers: MaterialTransfer[];

  totalCancelled?: number;
  totalInProgress?: number;
  totalPending?: number;
  totalTransferred?: number;
};
type GetAllMaterialTransferRequest = typeof paginationPayload & {
  search?: string;
  isUpComing?: string;
  isOverDue?: string;
  isDueToday?: string;
  projectId?: string;
  status?: number;

  materialType?: number;
  originalLocationId?: string;
  destinationLocationId?: string;
  transferDateFrom?: string;
  transferDateTo?: string;
};
export const getAllMaterialTransfer = createAsyncThunk<
  GetAllMaterialTransferResponse,
  GetAllMaterialTransferRequest
>(
  MaterialTransferEndpointsEnum.GET_ALL_MATERIAL_TRANSFER,
  async (payload: GetAllMaterialTransferRequest = paginationPayload) => {
    const response = await call<GetAllMaterialTransferResponse>({
      url: `${
        MaterialTransferEndpointsEnum.GET_ALL_MATERIAL_TRANSFER
      }?${getUrlParams(payload)?.toString()}`,
      method: "GET",
    });
    return response;
  }
);

type CreateMaterialTransferResponse = Response & {
  materialTransfer: MaterialTransfer;
};
export const createMaterialTransfer = createAsyncThunk(
  MaterialTransferEndpointsEnum.CREATE_MATERIAL_TRANSFER,
  async (
    payload: Omit<
      MaterialTransfer,
      | "id"
      | "createdDate"
      | "modifiedDate"
      | "modifiedBy"
      | "destinationSublocationName"
      | "destinationLocationName"
      | "originalLocationName"
      | "projectName"
      | "transferDate"
      | "destinationSubLocationId"
    > & { transferDate: string; destinationSubLocationId: string | null }
  ) => {
    const response = await call<CreateMaterialTransferResponse>({
      payload,
      url: MaterialTransferEndpointsEnum.CREATE_MATERIAL_TRANSFER,
    });
    return response;
  }
);

type EditMaterialTransferResponse = Response & {
  materialTransfer: MaterialTransfer;
};
export const editMaterialTransferById = createAsyncThunk(
  MaterialTransferEndpointsEnum.UPDATE_MATERIAL_TRANSFER,
  async (
    payload: Omit<
      MaterialTransfer,
      "transferDate" | "destinationSubLocationId"
    > & {
      transferDate: string;
    } & { materialTransferId: string; destinationSubLocationId: string | null }
  ) => {
    const response = await call<EditMaterialTransferResponse>({
      payload,
      url: `${MaterialTransferEndpointsEnum.UPDATE_MATERIAL_TRANSFER}/${payload.materialTransferId}`,
      method: "PUT",
    });
    return response;
  }
);

type DeleteMaterialTransferResponse = Response & {
  materialTransfer: MaterialTransfer;
};
export const deleteMaterialTransferById = createAsyncThunk(
  MaterialTransferEndpointsEnum.DELETE_MATERIAL_TRANSFER,
  async (materialTransferId: string) => {
    const response = await call<DeleteMaterialTransferResponse>({
      url: `${MaterialTransferEndpointsEnum.DELETE_MATERIAL_TRANSFER}/${materialTransferId}`,
      method: "DELETE",
    });
    return response;
  }
);

type MaterialTransferResponse = Response & {
  materialTransfer: MaterialTransfer;
};

export const getMaterialTransferByIdAsync = async (
  materialTransferId: string
) => {
  const response = await call<MaterialTransferResponse>({
    url: `${MaterialTransferEndpointsEnum.GET_ALL_MATERIAL_TRANSFER}/${materialTransferId}`,
    method: "GET",
  });
  return response;
};
