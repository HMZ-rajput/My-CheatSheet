import { createAsyncThunk } from "@reduxjs/toolkit";
import { call, getUrlParams } from "@utils/api-helpers";
import { paginationPayload } from "@utils/constants";
import {
  Location,
  LocationsList,
  Response,
  ResponseWithPagination,
  SubLocation,
} from "@utils/types";

export enum LocationEndpointsEnum {
  GET_ALL_LOCATIONS = "locations",
  GET_LOCATIONS_LIST = "locations/list",
  GET_LOCATIONS_SIDEBAR_LIST = "locations/list",
  CREATE_LOCATION = "locations/create/project",
  CREATE_SINGLE_LOCATION = "locations/createSingle/project",
  UPDATE_LOCATION = "locations/update/project",
  DELETE_LOCATION = "locations/delete/project",
}

export type GetAllLocationsResponse = ResponseWithPagination & {
  locations: Location[];
};
type GetAllLocationsRequest = typeof paginationPayload & {
  status?: string | number;
  storageType?: string;
  search?: string;
};

export const getAllLocations = createAsyncThunk<
  GetAllLocationsResponse,
  GetAllLocationsRequest
>(
  LocationEndpointsEnum.GET_ALL_LOCATIONS,
  async (payload: GetAllLocationsRequest = paginationPayload) => {
    const response = await call<GetAllLocationsResponse>({
      url: `${LocationEndpointsEnum.GET_ALL_LOCATIONS}?${getUrlParams(
        payload
      )?.toString()}`,
      method: "GET",
    });
    return response;
  }
);
// export const getAllLocations = createAsyncThunk<GetAllLocationsResponse, typeof paginationPayload>(
//   endpoints.GET_ALL_LOCATIONS,
//   async (payload = paginationPayload) => {
//     const response = await call<GetAllLocationsResponse>({ url: `${endpoints.GET_ALL_LOCATIONS}?PageNumber=${payload?.pageNumber}&PageSize=${payload?.pageSize}`, method: "GET" })
//     return response
//   }
// )

type LocationResponse = Response & {
  locations: LocationsList[];
  assumedSubmittalReviewPeriod?: number;
  taxPercentage?: number;
  assumedSubmittalReview?: number;
};
export const getLocationslist = createAsyncThunk(
  LocationEndpointsEnum.GET_LOCATIONS_LIST,
  async (projectId?: string) => {
    const url = projectId
      ? `${LocationEndpointsEnum.GET_LOCATIONS_LIST}?projectId=${
          projectId || ""
        }`
      : LocationEndpointsEnum.GET_LOCATIONS_LIST;
    const response = await call<LocationResponse>({
      url: url,
      method: "GET",
    });
    return response;
  }
);

export const getLocationListForSideBar = createAsyncThunk(
  LocationEndpointsEnum.GET_LOCATIONS_SIDEBAR_LIST + "t", //this "t" is separate from the endpoint. the reason is same action type is not allowed in redux
  async (projectId?: string) => {
    const url = projectId
      ? `${LocationEndpointsEnum.GET_LOCATIONS_SIDEBAR_LIST + "t"}?projectId=${
          projectId || ""
        }`
      : LocationEndpointsEnum.GET_LOCATIONS_LIST;
    const response = await call<LocationResponse>({
      url: url,
      method: "GET",
    });
    return response;
  }
);

type GetLocationByIdResponse = Response & { location: Location };
export const getLocationById = async (locationId: string) => {
  const response = await call<GetLocationByIdResponse>({
    url: `${LocationEndpointsEnum.GET_ALL_LOCATIONS}/${locationId || ""}`,
    method: "GET",
  });
  return response;
};

export const getLocationByProjectId = async (projectId: string) => {
  const response = await call<GetLocationByIdResponse>({
    url: `${LocationEndpointsEnum.GET_ALL_LOCATIONS}/${projectId || ""}`,
    method: "GET",
  });
  return response;
};

type CreateLocationResponse = Response & {
  locations: Location[];
  projectId: string;
};

export type CreateLocationRequest = {
  locations: Location<SubLocation>[];
  projectId?: string | null;
  projectTypeId?: string | null;
};
export const createLocation = createAsyncThunk(
  LocationEndpointsEnum.CREATE_LOCATION,
  async (payload: CreateLocationRequest) => {
    const response = await call<CreateLocationResponse>({
      payload,
      url: `${LocationEndpointsEnum.CREATE_LOCATION}/${payload?.projectId}`,
    });
    return response;
  }
);

export type CreateSingleLocationRequest = Location<string>;
export type CreateSingleLocationResponse = Response & { location: Location };
export const createSingleLocation = createAsyncThunk(
  LocationEndpointsEnum.CREATE_SINGLE_LOCATION,
  async (payload: CreateSingleLocationRequest) => {
    const response = await call<CreateSingleLocationResponse>({
      payload,
      url: `${LocationEndpointsEnum.CREATE_SINGLE_LOCATION}/${payload?.projectId}`,
    });
    return response;
  }
);

export type EditLocationRequest = {
  locations:
    | Omit<
        Location,
        | "createdDate"
        | "modifiedDate"
        | "project"
        | "storageType"
        | "createdBy"
        | "lastModifiedDate"
        | "lastModifiedBy"
      >[]
    | null;
  projectId?: string;
  ProjectTypeId?: string;
};
type EditLocationResponse = Response & {
  projectId: string;
  locations: Location[];
};
export const editLocationById = createAsyncThunk(
  LocationEndpointsEnum.UPDATE_LOCATION,
  async (payload: EditLocationRequest) => {
    const response = await call<EditLocationResponse>({
      payload,
      url: `${LocationEndpointsEnum.UPDATE_LOCATION}/${payload.projectId}`,
      method: "PUT",
    });
    return response;
  }
);

type PayloadForDelete = {
  projectId: string;
  locationsIdArray: (string | null)[];
};
type DeletedResponse = Response & {
  projectId: string;
  locationsIdArray: (string | null)[];
};

export const deleteLocationById = createAsyncThunk(
  LocationEndpointsEnum.DELETE_LOCATION,
  async (payload: PayloadForDelete) => {
    console.log("payload.locationsIdArray", payload.locationsIdArray);

    const response = await call<DeletedResponse>({
      payload: payload.locationsIdArray,
      url: `${LocationEndpointsEnum.DELETE_LOCATION}/${payload.projectId}`,
      method: "DELETE",
    });

    return response;
  }
);
