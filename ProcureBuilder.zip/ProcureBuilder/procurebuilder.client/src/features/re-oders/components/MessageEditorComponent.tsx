import { useEffect, useState } from "react";
import ReactQuill, { Quill } from "react-quill";
import "react-quill/dist/quill.snow.css";
import quillEmoji from "react-quill-emoji";
import "react-quill-emoji/dist/quill-emoji.css";

const modules = {
  toolbar: {
    container: [
      ["bold", "italic", "underline"],
      ["emoji"],
      ["link"],
      [{ list: "bullet" }],
      [{ align: [] }],
    ],
  },
  "emoji-toolbar": true,
  "emoji-shortname": true,
};

type MessageEditorProps = {
  value: string | null;
  onChange: (value: string) => void;
};

export default function MessageEditor({ value, onChange }: MessageEditorProps) {
  Quill.register(
    {
      "formats/emoji": quillEmoji.EmojiBlot,
      "modules/emoji-toolbar": quillEmoji.ToolbarEmoji,
      "modules/emoji-shortname": quillEmoji.ShortNameEmoji,
    },
    true
  );

  const [editorValue, setEditorValue] = useState<string | null>(value);

  useEffect(() => {
    setEditorValue(value);
  }, [value]);

  const handleChange = (value: string) => {
    setEditorValue(value);
    onChange(value);
  };

  return (
    <ReactQuill
      className="w-full css-dev-only-do-not-override-13i9ogo ant-input-outlined bg-white border border-[#E2E4E9] rounded-xl min-h-64"
      placeholder="Write Something..."
      theme="snow"
      value={editorValue ?? undefined}
      onChange={handleChange}
      modules={modules}
    />
  );
}
