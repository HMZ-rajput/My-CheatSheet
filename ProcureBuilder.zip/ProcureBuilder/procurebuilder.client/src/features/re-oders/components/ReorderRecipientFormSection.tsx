import {
  Avatar,
  Button,
  Col,
  Divider,
  Flex,
  Form,
  Select,
  SelectProps,
  Tag,
  Typography,
  UploadFile,
} from "antd";
import { useEffect, useMemo, useState } from "react";
import { RorderRecipient, Reorder, Attachment } from "@/src/utils/types";
import { getConsistentSpacing, getRandomColor } from "@utils/theme-helpers";
import CustomIcon from "@components/common/CustomIcon";
import SectionLayout from "@/src/components/layout/SectionLayout";
import CustomFormRow from "@/src/components/form/CustomFormRow";
import CustomFormLabel from "@/src/components/common/CustomFormLabel";
import { useAppSelector } from "@/src/hooks/useAppSelector";
// import routePaths from "@/src/utils/routePaths";
// import CustomFormButtons from "@/src/components/form/CustomFormButtons";
import CreatedByUserBadge from "@/src/components/common/CreatedByUserBadge";
import CustomAlert from "@/src/components/common/CustomAlert";
import { getVendorslist } from "@/src/apis/vendorApis";
import { getVendorsState } from "@/src/store/slices/vendorSlice";
import { useAppDispatch } from "@/src/hooks/useAppDispatch";
import MessageEditor from "./MessageEditorComponent";
import { getFullNameInitials } from "@/src/utils/general-helpers";
import {
  getReorderState,
  resetState,
  // resetStateisSuccess,
} from "@/src/store/slices/reordersSlice";
import {
  deleteReorderById,
  editReorderRecipientById,
} from "@/src/apis/reorderApis";
import { yupResolver } from "@hookform/resolvers/yup";
import { Controller, Resolver, useForm } from "react-hook-form";
import { FilesDocumentTypeEnum } from "@/src/utils/enums";
import {
  filterFileDocumentsByType,
  getHtmlFromXMLPara,
} from "@/src/utils/helper";
import { ReorderRecipientValidationSchema } from "@/src/data/validationsSchema";
import CustomFileUploadRHF from "@/src/components/common/CustomFileUploadRHF";
import JSZip from "jszip";
type ReorderGeneralFormSectionProps = {
  reorder: Reorder | null;
  handleCancelForm: () => void;
};
export default function ReorderRecipientFormSection({
  reorder,
  handleCancelForm,
}: ReorderGeneralFormSectionProps) {
  type FieldType = RorderRecipient;
  const dispatch = useAppDispatch();
  const [isDeleting, setIsDeleting] = useState(false);
  const [validationError, setValidationError] = useState("");
  const { successMessage, resError, reqError } =
    useAppSelector(getReorderState);
  const [actionType, setActionType] = useState<
    "save" | "saveAndClose" | "saveAndRelease" | ""
  >("");

  useEffect(() => {
    dispatch(getVendorslist());
  }, [dispatch]);

  const { vendorsList } = useAppSelector(getVendorsState);
  const memoizedVendorsOptions = useMemo(() => {
    return (
      vendorsList?.map((f) => ({
        value: f.id,
        label: f.name,
      })) || []
    );
  }, [vendorsList]);

  const getDefaultValues = (reorder: Reorder | null) => {
    return {
      reorderId: reorder?.id || "",
      invitationMessage: reorder?.invitationMessage || null,
      shouldSendQuote: false,
      vendorIds: reorder?.vendor?.map((f) => f?.id) || [],
      requestQuoteDocument: filterFileDocumentsByType(
        reorder?.documents || [],
        FilesDocumentTypeEnum.REQUESTQUOTE
      ),
      deleteRequestQuoteDocumentId: [],
    };
  };

  const {
    control,
    reset,
    handleSubmit,
    setValue,
    getValues,
    formState: { errors, isSubmitting },
  } = useForm<FieldType>({
    resolver: yupResolver(
      ReorderRecipientValidationSchema
    ) as unknown as Resolver<FieldType>,
    defaultValues: getDefaultValues(reorder),
    shouldUnregister: false,
  });

  const onSubmit = async (values: FieldType) => {
    const formData = new FormData();

    formData.append("reorderId", reorder?.id as string);
    values?.invitationMessage &&
      formData.append("invitationMessage", values?.invitationMessage as string);
    formData.append("shouldSendQuote", JSON.stringify(values.shouldSendQuote));
    if (Array.isArray(values.vendorIds)) {
      values?.vendorIds?.forEach((id) => {
        formData.append(`vendorIds`, id);
      });
    }

    if (Array.isArray(values.requestQuoteDocument)) {
      values?.requestQuoteDocument?.forEach((file: Attachment) => {
        if (file?.originFileObj) {
          formData.append("RequestQuoteDocument", file.originFileObj);
        }
      });
    }

    if (Array.isArray(values.deleteRequestQuoteDocumentId)) {
      const filteredDeleteDocumentIds =
        values?.deleteRequestQuoteDocumentId?.filter(
          (id: string) => !id?.startsWith("rc-upload-")
        );
      filteredDeleteDocumentIds?.forEach((id) => {
        formData.append("deleteRequestQuoteDocumentId", id);
      });
    }

    try {
      if (reorder?.id) {
        const response = await dispatch(
          editReorderRecipientById({
            payload: formData,
            reorderId: reorder?.id,
          })
        ).unwrap();
        if (response?.isSuccess) {
          if (actionType === "saveAndClose") {
            handleCancelForm();
          }
        }
      }
    } catch (error) {
      console.error("Error submitting form:", error);
      setValidationError("An error occurred while submitting the form.");
    } finally {
      setValue("shouldSendQuote", false);
    }
  };

  const handleFileChange = (fileList: UploadFile[]) => {
    const isAllDocxTxtFiles = fileList.every(
      (file) =>
        file?.type === "text/plain" ||
        file?.name.endsWith(".txt") ||
        file?.name.endsWith(".docx") ||
        file?.name.endsWith(".doc")
    );

    if (!isAllDocxTxtFiles) {
      setValidationError("Only .doc,.docx and .txt files are allowed!");
      return;
    } else {
      setValidationError("");
    }

    const file = fileList[0]?.originFileObj as File;
    if (!(file instanceof File)) {
      setValue("requestQuoteDocument", []);
      return;
    }

    const reader = new FileReader();

    if (file.name.endsWith(".docx") || file.name.endsWith(".doc")) {
      reader.onload = async (e) => {
        try {
          const result = e.target?.result;
          if (result instanceof ArrayBuffer) {
            const zip = await JSZip.loadAsync(result);
            const documentXml = await zip
              .file("word/document.xml")
              ?.async("text");

            if (documentXml) {
              const parser = new DOMParser();
              const xmlDoc = parser.parseFromString(documentXml, "text/xml");
              const paragraphs = xmlDoc.getElementsByTagName("w:p");
              setValue("invitationMessage", getHtmlFromXMLPara(paragraphs));
              setValue("requestQuoteDocument", []);
            } else {
              setValidationError(
                "This .docx file does not contain valid text!"
              );
              setValue("requestQuoteDocument", []);
            }
          }
        } catch (error) {
          console.error("Error processing .docx file:", error);
          setValidationError("Error reading .docx file!");
        }
      };
      reader.readAsArrayBuffer(file);
    } else if (file.name.endsWith(".txt")) {
      reader.onload = (e) => {
        const text = e.target?.result;
        if (typeof text === "string" && text?.trim() !== "") {
          setValue("invitationMessage", text);
          setValue("requestQuoteDocument", []);
        } else {
          setValidationError("This .txt file does not contain valid text!");
          setValue("requestQuoteDocument", []);
        }
      };
      reader.readAsText(file);
    }

    setValue("requestQuoteDocument", fileList as any);
  };

  const handleMessageChange = (value: string) => {
    setValue("invitationMessage", value);
  };

  type DeleteReorderFunctionArgs = {
    reorderId: string | undefined;
  };
  async function handleDeleteReorderById({
    reorderId,
  }: DeleteReorderFunctionArgs) {
    if (reorderId) {
      try {
        setIsDeleting(true);
        const res = await dispatch(
          deleteReorderById({
            reorderId: reorderId,
            errors: [],
            isSuccess: true,
          })
        ).unwrap();
        if (res.isSuccess) {
          handleCancelForm();
        }
      } catch (error) {
        console.error("Error Deleting Reorder:", error);
      } finally {
        setIsDeleting(false);
      }
    }
  }

  type TagRender = SelectProps["tagRender"];
  const backgroundColor = useMemo(() => getRandomColor(), []);
  const tagRender: TagRender = (props: any) => {
    const { label, closable, onClose } = props;
    const onPreventMouseDown = (event: React.MouseEvent<HTMLSpanElement>) => {
      event.preventDefault();
      event.stopPropagation();
    };
    return (
      <Tag
        onMouseDown={onPreventMouseDown}
        closable={closable}
        onClose={onClose}
        className="flex items-center border-none rounded-lg p-1.5 m-1.5 text-xs font-medium bg-neutral-1"
      >
        <Avatar style={{ backgroundColor: backgroundColor, marginRight: 8 }}>
          {getFullNameInitials(label?.toString())}
        </Avatar>
        {label}
      </Tag>
    );
  };

  useEffect(() => {
    if (!reorder) return;
    const reorderValues = getDefaultValues(reorder);
    reset(reorderValues);
  }, [reorder, reset]);

  useEffect(() => {
    dispatch(resetState());
  }, []);

  return (
    <>
      <SectionLayout>
        <Form
          onFinish={handleSubmit(onSubmit)}
          layout="vertical"
          autoComplete="off"
        >
          {/* Reorder Details */}
          <CustomFormRow>
            <Col xs={24} className="mb-5">
              <Flex align="start" gap={"large"}>
                <Typography.Title level={5}>Vendors</Typography.Title>
              </Flex>
            </Col>

            {/* Vendor */}
            <Col xs={12}>
              <Controller
                control={control}
                name="vendorIds"
                render={({ field }) => (
                  <Form.Item<FieldType>
                    label={
                      <CustomFormLabel text="Add Vendors" required={true} />
                    }
                    labelAlign="right"
                    initialValue={field.value}
                    validateStatus={errors.vendorIds ? "error" : ""}
                    help={errors.vendorIds?.message}
                  >
                    <Select
                      size="large"
                      mode="multiple"
                      placeholder={"Select Vendors"}
                      style={{ width: "100%" }}
                      showSearch
                      value={field.value}
                      tagRender={tagRender}
                      onChange={(value) => field.onChange(value)}
                      options={memoizedVendorsOptions}
                      filterOption={(input, option) =>
                        (option?.label || "")
                          .toLowerCase()
                          .includes(input.toLowerCase())
                      }
                    />
                  </Form.Item>
                )}
              />
            </Col>
          </CustomFormRow>

          <Divider />

          {/* Vendor Invitation Message */}
          <Typography.Title level={5}>Request for Quote</Typography.Title>
          <Flex
            className="mt-6 mb-0"
            justify="space-between"
            align="end"
            gap={5}
          >
            <Typography.Text className="font-medium">
              Vendor Invitation Message
            </Typography.Text>
            <Controller
              control={control}
              name="requestQuoteDocument"
              render={({ field }) => (
                <Form.Item<FieldType>
                  labelAlign="right"
                  style={{ marginBottom: 0 }}
                  initialValue={field.value}
                >
                  <CustomFileUploadRHF
                    setValue={setValue}
                    getValues={getValues}
                    fieldName={field.name}
                    deletedFileName="deleteRequestQuoteDocumentId"
                    buttonText="Upload Document"
                    buttonIcon={<CustomIcon type="cloud-upload" />}
                    buttonClassName="hover:!fill-primaryHover"
                    onFileChange={handleFileChange}
                    hasOnlyText
                    maxCount={1}
                  />
                </Form.Item>
              )}
            />
          </Flex>
          <Flex className="mt-3 border-none">
            <Controller
              control={control}
              name="invitationMessage"
              render={({ field }) => (
                <Form.Item<FieldType>
                  labelAlign="right"
                  className="w-full"
                  initialValue={field.value}
                >
                  <MessageEditor
                    value={getValues("invitationMessage") as string}
                    onChange={handleMessageChange}
                  />
                </Form.Item>
              )}
            />
          </Flex>

          {/* Validation handling */}
          {validationError && (
            <CustomAlert message={validationError || ""} type="error" />
          )}
          {!validationError && (reqError || resError || successMessage) && (
            <CustomAlert
              message={resError || successMessage || ""}
              type={successMessage ? "success" : "error"}
            />
          )}

          {/* Form Buttons */}
          {/* <Flex
            justify="flex-end"
            className="mt-8"
            gap={parseInt(getConsistentSpacing(2))}
          >
            <CustomFormButtons
              isSuccess={isSuccess}
              resetStateisSuccess={resetStateisSuccess}
              isEditMode={Boolean(reorder)}
              hasValidationErrors={
                Object.values(formik.touched)?.length > 0 &&
                Object.values(formik.errors)?.length > 0
              }
              hasHttpErrors={Boolean(resError || reqError)}
              navigationRoute={routePaths.REORDERS}
              handleCancel={handleCancelForm}
              handleSubmit={formik.handleSubmit}
              isDeletingProgress={isDeleting}
              handleDelete={() =>
                handleDeleteReorderById({
                  reorderId: reorder?.id,
                })
              }
            />
          </Flex> */}

          <Flex
            justify="flex-end"
            className="mt-8 mb-5"
            gap={parseInt(getConsistentSpacing(2))}
          >
            <Button
              disabled={isSubmitting || isDeleting}
              type="default"
              onClick={handleCancelForm}
            >
              Cancel
            </Button>
            {Boolean(reorder) && (
              <Button
                loading={isDeleting}
                disabled={isSubmitting || isDeleting}
                type="default"
                onClick={() =>
                  handleDeleteReorderById({
                    reorderId: reorder?.id,
                  })
                }
              >
                {isDeleting ? "Deleting.." : "Delete"}
              </Button>
            )}
            <Button
              loading={actionType === "save" && isSubmitting}
              disabled={isSubmitting || isDeleting}
              type="primary"
              htmlType="submit"
              onClick={() => setActionType("save")}
            >
              {actionType === "save" && isSubmitting ? "Saving.." : "Save"}
            </Button>

            <Button
              loading={actionType === "saveAndClose" && isSubmitting}
              disabled={isSubmitting || isDeleting}
              type="primary"
              htmlType="submit"
              onClick={() => setActionType("saveAndClose")}
            >
              {actionType === "saveAndClose" && isSubmitting
                ? "Saving and closing.."
                : "Save & Close"}
            </Button>
            <Button
              loading={actionType === "saveAndRelease" && isSubmitting}
              disabled={isSubmitting || isDeleting}
              type="primary"
              htmlType="submit"
              onClick={() => {
                setValue("shouldSendQuote", true);
                setActionType("saveAndRelease");
              }}
            >
              {actionType === "saveAndRelease" && isSubmitting
                ? "Saving and Releasing.."
                : "Save & Release"}
            </Button>
          </Flex>

          {/* Edited Badge */}
          {reorder?.id && (
            <Flex justify="flex-end">
              <CreatedByUserBadge
                // userName={reorder?.createdBy as string}
                // date={reorder?.createdDate as Date}
                userName={
                  reorder?.modifiedDate === null
                    ? reorder?.createdBy
                    : reorder?.lastModifiedBy
                }
                date={reorder?.lastModifiedDate}
                isUpdatedBadge={reorder?.modifiedDate === null ? false : true}
              />
            </Flex>
          )}
        </Form>
      </SectionLayout>
    </>
  );
}
