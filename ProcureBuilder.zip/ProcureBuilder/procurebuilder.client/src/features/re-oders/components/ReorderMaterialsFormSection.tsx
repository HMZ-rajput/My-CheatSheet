import CustomIcon from "@/src/components/common/CustomIcon";
import CustomFormRow from "@/src/components/form/CustomFormRow";
import DeleteIconButton from "@/src/components/icon-buttons/DeleteIconButton";
import { Reorder } from "@/src/utils/types";
import {
  Button,
  Col,
  Flex,
  Form,
  Input,
  InputNumber,
  Row,
  Typography,
} from "antd";
import { Control, Controller, useFieldArray } from "react-hook-form";

const { Text } = Typography;

type ReorderFormProps = {
  control: Control<Reorder>;
};

export default function ReorderMaterialsFormSection({
  control,
}: ReorderFormProps) {
  const {
    fields: materialFields,
    append: appendMaterial,
    remove: removeMaterial,
  } = useFieldArray({
    control,
    name: "materials",
  });

  const deleteMaterial = (index: number) => {
    removeMaterial(index);
  };

  const handleAddMaterial = () => {
    const newMaterial = {
      id: "",
      name: "",
      costCode: "",
      spares: 0,
      samples: 0,
      regular: 0,
      quantity: 0,
      unitOfMeasure: "",
    };

    appendMaterial(newMaterial);
  };

  // const handleChange = (
  //   fieldName: string,
  //   value: string | number,
  //   index: number
  // ) => {
  //   const updatedMaterials = getValues("materials").map(
  //     (material: ReorderMaterial, id: number) => {
  //       if (id === index) {
  //         let updatedMaterial = {
  //           ...material,
  //           [fieldName]: value,
  //         };

  //         if (
  //           fieldName === "spares" ||
  //           fieldName === "samples" ||
  //           fieldName === "regular"
  //         ) {
  //           const newSpares = fieldName === "spares" ? value : material.spares;
  //           const newSamples =
  //             fieldName === "samples" ? value : material.samples;
  //           const newRegular =
  //             fieldName === "regular" ? value : material.regular;

  //           updatedMaterial.quantity =
  //             Number(newSpares) + Number(newSamples) + Number(newRegular);
  //         }
  //         return updatedMaterial;
  //       }
  //       return material;
  //     }
  //   );
  //   setValue("materials", updatedMaterials);
  // };

  return (
    <>
      <div>
        <div
          style={{ backgroundColor: "whitesmoke" }}
          className="py-1.5 px-2 rounded-lg mb-4"
        >
          <Row className="bg-slate-400">
            <Col xs={8} className="mr-1.5">
              <Text className="font-medium">Material</Text>
            </Col>
            <Col xs={6} className="mr-1.5">
              <Text className="font-medium">Cost Code</Text>
            </Col>
            <Col xs={4} className="mr-1.5">
              <Text className="font-medium">Quantity</Text>
            </Col>
            <Col xs={5} className="mr-1.5">
              <Text className="font-medium">Unit of Measurement</Text>
            </Col>
          </Row>
        </div>

        {materialFields.map((materials, index) => (
          <CustomFormRow key={materials.id}>
            {/* Material */}
            <Col xs={8}>
              <Controller
                control={control}
                name={`materials.${index}.name`}
                render={({ field, formState: { errors } }) => {
                  const materialError = errors?.materials?.[index];
                  return (
                    <Form.Item
                      labelAlign="right"
                      help={materialError?.name?.message}
                      validateStatus={materialError?.name ? "error" : ""}
                    >
                      <Input
                        {...field}
                        value={field.value}
                        onChange={(value) => {
                          field.onChange(value);
                        }}
                        size="large"
                        placeholder="Material"
                      />
                    </Form.Item>
                  );
                }}
              />
            </Col>

            {/* Cost Code */}
            <Col xs={6}>
              <Controller
                control={control}
                name={`materials.${index}.costCode`}
                render={({ field, formState: { errors } }) => {
                  const materialError = errors?.materials?.[index];
                  return (
                    <Form.Item
                      labelAlign="right"
                      help={materialError?.costCode?.message}
                      validateStatus={materialError?.costCode ? "error" : ""}
                    >
                      <Input
                        {...field}
                        value={field.value}
                        onChange={(value) => {
                          field.onChange(value);
                        }}
                        size="large"
                        placeholder="Cost Code"
                      />
                    </Form.Item>
                  );
                }}
              />
            </Col>

            {/* Quantity */}
            <Col xs={4}>
              <Controller
                control={control}
                name={`materials.${index}.quantity`}
                render={({ field, formState: { errors } }) => {
                  const materialError = errors?.materials?.[index];
                  return (
                    <Form.Item
                      labelAlign="right"
                      help={materialError?.quantity?.message}
                      validateStatus={materialError?.quantity ? "error" : ""}
                    >
                      <InputNumber
                        {...field}
                        type="number"
                        value={field.value}
                        onChange={(value) => {
                          field.onChange(value);
                        }}
                        min={0}
                        size="large"
                        style={{ width: "100%" }}
                      />
                    </Form.Item>
                  );
                }}
              />
            </Col>

            {/* Unit of Measurement */}
            <Col xs={5}>
              <Controller
                control={control}
                name={`materials.${index}.unitOfMeasure`}
                render={({ field, formState: { errors } }) => {
                  const materialError = errors?.materials?.[index];
                  return (
                    <Form.Item
                      labelAlign="right"
                      help={materialError?.unitOfMeasure?.message}
                      validateStatus={
                        materialError?.unitOfMeasure ? "error" : ""
                      }
                    >
                      <Input
                        {...field}
                        value={field.value}
                        onChange={(value) => {
                          field.onChange(value);
                        }}
                        size="large"
                        placeholder="FT"
                      />
                    </Form.Item>
                  );
                }}
              />
            </Col>

            {/* Delete Icon */}
            <Col className="mt-1" xs={1}>
              <DeleteIconButton
                disabled={materialFields.length === 1}
                handleDelete={() => deleteMaterial(index)}
              />
            </Col>
          </CustomFormRow>
        ))}

        <Flex justify="space-between">
          <Button
            className="border-0 shadow-none text-primary font-medium"
            size="small"
            icon={<CustomIcon width={16} type="add-circle" />}
            onClick={handleAddMaterial}
          >
            Add Material
          </Button>
        </Flex>
      </div>
    </>
  );
}
