import { getLocationslist } from "@/src/apis/locationApis";
import { getSummarizedProjectsList } from "@/src/apis/projectApis";
import {
  createReorder,
  deleteReorderById,
  editReorderById,
} from "@/src/apis/reorderApis";
import CreatedByUserBadge from "@/src/components/common/CreatedByUserBadge";
import CustomAlert from "@/src/components/common/CustomAlert";
import CustomFileUploadRHF from "@/src/components/common/CustomFileUploadRHF";
import CustomFormLabel from "@/src/components/common/CustomFormLabel";
import CustomInfoTooltip from "@/src/components/common/CustomInfoTooltip";
import { getReorderState, resetState } from "@/src/store/slices/reordersSlice";
// import CustomFormButtons from "@/src/components/form/CustomFormButtons";
import { getAllProjectTypes } from "@/src/apis/projectTypeApis";
import {
  getPurchaseOrdersList,
  getPurchaseOrdersMaterialsById,
} from "@/src/apis/purchaseOrderApis";
import { getAllStorageTypes } from "@/src/apis/storageTypeApis";
import CustomOverlayLoader from "@/src/components/common/CustomOverlayloader";
import CustomFormRow from "@/src/components/form/CustomFormRow";
import SectionLayout from "@/src/components/layout/SectionLayout";
import {
  reorderInitialMaterials,
  reOrderInitialMaterialsUpdate,
} from "@/src/data/intialsValues";
import { ReorderGeneralValidationSchema } from "@/src/data/validationsSchema";
import { getLowerCasedMaterialName } from "@/src/external-modules/bulk-upload/bulk-upload-utils";
import BulkUploadButton from "@/src/external-modules/bulk-upload/BulkUploadButton";
import BulkUploaderParser from "@/src/external-modules/bulk-upload/BulkUploadParser";
import LocationModal from "@/src/features/locations/components/LocationModal";
import { useAppDispatch } from "@/src/hooks/useAppDispatch";
import { useAppSelector } from "@/src/hooks/useAppSelector";
import { getLocationsState } from "@/src/store/slices/locationSlice";
import { getProjectsState } from "@/src/store/slices/projectsSlice";
import { getPurchaseOrdersState } from "@/src/store/slices/purchaseOrderSlice";
import { dateFormat, reorderStatusOptions } from "@/src/utils/constants";
import { FilesDocumentTypeEnum } from "@/src/utils/enums";
import { filterFileDocumentsByType } from "@/src/utils/helper";
import routePaths from "@/src/utils/routePaths";
import {
  LabelSupportedReorderMaterial,
  PurchaseOrder,
  Reorder,
  ReorderMaterial,
} from "@/src/utils/types";
import { PlusOutlined } from "@ant-design/icons";
import CustomIcon from "@components/common/CustomIcon";
import { yupResolver } from "@hookform/resolvers/yup";
import { getTypesState } from "@store/slices/typesSlice";
import { getConsistentSpacing } from "@utils/theme-helpers";
import {
  Button,
  Col,
  DatePicker,
  Divider,
  Flex,
  Form,
  Input,
  Row,
  Select,
  Space,
  Typography,
} from "antd";
import dayjs from "dayjs";
import { useEffect, useMemo, useState } from "react";
import { Controller, Resolver, useForm } from "react-hook-form";
import { useLocation, useNavigate } from "react-router-dom";
import ReorderMaterialsFormSection from "./ReorderMaterialsFormSection";

type ReorderGeneralFormSectionProps = {
  reorder: Reorder | null;
  poData: PurchaseOrder;
  handleCancelForm: () => void;
  dashboardMaterials: ReorderMaterial[];
  dashboardProjectId: string;
};
export default function ReorderGeneralFormSection({
  reorder,
  handleCancelForm,
  poData,
  dashboardMaterials,
  dashboardProjectId,
}: ReorderGeneralFormSectionProps) {
  const { state: navigationState, pathname } = useLocation();
  const [isLocationModalOpen, setIsLocationModalOpen] = useState<{
    open: boolean;
    title?: string | null;
    field?: string;
  }>({ open: false, title: null, field: "" });
  type FieldType = Reorder;
  const navigate = useNavigate();
  const dispatch = useAppDispatch();
  const [isDeleting, setIsDeleting] = useState(false);
  const [isLoadROMaterial, setIsLoadROMaterial] = useState(false);
  const [validationError, setValidationError] = useState("");
  const { successMessage, resError, reqError } =
    useAppSelector(getReorderState);
  const [selectedProjectId, setSelectedProjectId] = useState<string | null>(
    reorder?.project?.id ?? null
  );
  const { locationsList } = useAppSelector(getLocationsState);
  const { purchaseOrdersList } = useAppSelector(getPurchaseOrdersState);
  const [actionType, setActionType] = useState<
    "save" | "saveAndClose" | "createPO" | ""
  >("");
  const RecentQuoteInfoText = `Upload your Recent Quote here`;

  const { typesData: typesData } = useAppSelector(getTypesState);
  const memoizedProjectTypesOptions = useMemo(() => {
    return [
      {
        value: "",
        label: "Select Project Type",
      },
      ...(typesData?.map((pt) => ({
        value: pt?.id,
        label: pt?.name,
      })) || []),
    ];
  }, [typesData]);

  useEffect(() => {
    dispatch(getSummarizedProjectsList());
    dispatch(getAllProjectTypes());
  }, [dispatch]);

  const { projectsSummarizedData } = useAppSelector(getProjectsState);
  const memoizedProjectsOptions = useMemo(() => {
    return [
      {
        value: "",
        label: "Select Project",
      },
      ...(projectsSummarizedData?.map((f) => ({
        value: f?.id,
        label: f?.name,
      })) || []),
    ];
  }, [projectsSummarizedData]);
  const memoizedPurchaseOrdersOptions = useMemo(() => {
    return [
      {
        value: "",
        label: "Select P.O. Number",
      },
      ...(purchaseOrdersList?.map((f) => ({
        value: f?.id,
        label: f?.purchaseOrderNumber,
      })) || []),
    ];
  }, [purchaseOrdersList]);

  const memoizedLoctionOptions = useMemo(() => {
    return [
      {
        value: "",
        label: "Select Location",
      },
      ...(locationsList?.map((f) => ({
        value: f?.id,
        label: f?.name,
      })) || []),
    ];
  }, [locationsList]);

  useEffect(() => {
    if (dashboardProjectId) return;

    if (selectedProjectId) {
      dispatch(getLocationslist(selectedProjectId));

      const selectedProject = projectsSummarizedData?.find(
        (project) => project?.id === selectedProjectId
      );

      if (selectedProject?.projectTypeId) {
        setValue("projectTypeId", selectedProject?.projectTypeId);
      } else {
        setValue("projectTypeId", null);
      }
    } else {
      setValue("projectTypeId", null);
      setValue("projectLocationId", null);
    }
  }, [selectedProjectId, projectsSummarizedData, dispatch, dashboardProjectId]);

  useEffect(() => {
    dispatch(getLocationslist(selectedProjectId || ""));
  }, [dispatch, selectedProjectId]);

  const getDefaultValues = (reorder: Reorder | null) => {
    return {
      id: reorder?.id || "",
      reorderNumber: reorder?.reorderNumber || "",
      title: reorder?.title || "",
      attachments: filterFileDocumentsByType(
        reorder?.documents || [],
        FilesDocumentTypeEnum.REORDERATTACHMENTS
      ),
      RecentQuoteDocument: filterFileDocumentsByType(
        reorder?.documents || [],
        FilesDocumentTypeEnum.RECENTQUOTE
      ),
      PurchaseOrderDocument: filterFileDocumentsByType(
        reorder?.documents || [],
        FilesDocumentTypeEnum.PURCHASEORDER
      ),
      deleteDocumentIds: [],
      dueDate: dayjs(reorder?.dueDate || new Date()),
      projectId: reorder?.project?.id || null,
      projectLocationId: reorder?.location?.id || null,
      projectTypeId: reorder?.project?.projectTypeId || null,
      purchaseOrderId: reorder?.purchaseOrderId || null,
      notes: reorder?.notes || "",
      status: reorder?.status || 0,
      createdBy: reorder?.createdBy || "",
      lastModifiedBy: reorder?.lastModifiedBy || "",
      lastModifiedDate: reorder?.lastModifiedDate || null,
      modifiedDate: reorder?.modifiedDate || null,
      materials:
        reorder?.materials?.map((material) => ({
          id: material.id,
          name: material.name,
          costCode: material.costCode,
          quantity: material.quantity,
          unitOfMeasure: material.unitOfMeasure,
        })) || reorderInitialMaterials,
    };
  };

  const {
    reset,
    control,
    handleSubmit,
    setValue,
    getValues,
    register,
    formState: { errors, isSubmitting },
  } = useForm<Reorder>({
    resolver: yupResolver(
      ReorderGeneralValidationSchema
    ) as unknown as Resolver<Reorder>,
    defaultValues: getDefaultValues(reorder),
    shouldUnregister: false,
  });

  const onSubmit = async (values: Reorder) => {
    setValidationError("");
    const formData = new FormData();
    const appendIfValid = (key: string, value: any) => {
      if (value !== null && value !== undefined && value !== "") {
        formData.append(key, value);
      }
    };
    const fields = [
      { key: "id", value: reorder?.id || "" },
      { key: "reorderNumber", value: values.reorderNumber },
      { key: "title", value: values.title },
      { key: "dueDate", value: dayjs(values.dueDate).toISOString() },
      { key: "projectId", value: values.projectId },
      { key: "projectLocationId", value: values.projectLocationId },
      { key: "projectTypeId", value: values.projectTypeId },
      { key: "purchaseOrderId", value: values.purchaseOrderId },
      { key: "notes", value: values.notes },
      { key: "status", value: values.status.toString() },
    ];

    for (const field of fields) {
      appendIfValid(field.key, field.value);
    }

    if (Array.isArray(values?.materials)) {
      for (let i = 0; i < values.materials.length; i++) {
        const material = values.materials[i];
        for (const [key, value] of Object.entries(material)) {
          if (["spares", "samples", "regular"].includes(key)) continue;

          appendIfValid(`materials[${i}][${key}]`, value);
        }
      }
    }

    const fileFields = [
      { key: "attachments", value: values?.attachments },
      { key: "RecentQuoteDocument", value: values?.RecentQuoteDocument },
      { key: "PurchaseOrderDocument", value: values?.PurchaseOrderDocument },
    ];

    for (const field of fileFields) {
      if (Array.isArray(field.value)) {
        for (const file of field.value) {
          if (file?.originFileObj) {
            formData.append(field.key, file.originFileObj);
          }
        }
      }
    }

    if (Array.isArray(values?.deleteDocumentIds)) {
      const filteredDeleteDocumentIds = values.deleteDocumentIds.filter(
        (id) => !id.startsWith("rc-upload-")
      );
      for (const id of filteredDeleteDocumentIds) {
        appendIfValid("deleteDocumentIds", id);
      }
    }

    try {
      let response;
      if (reorder?.id && selectedProjectId) {
        response = await dispatch(
          editReorderById({
            payload: formData,
            projectId: selectedProjectId,
            reorderId: reorder?.id,
          })
        ).unwrap();
        if (response?.isSuccess) {
          reset(getDefaultValues(response?.reorder));
          if (actionType === "saveAndClose") {
            handleCancelForm();
            return;
          }
        }
      } else if (selectedProjectId) {
        response = await dispatch(
          createReorder({ payload: formData, projectId: selectedProjectId })
        ).unwrap();
        if (response?.isSuccess) {
          reset(getDefaultValues(response.reorder));
          if (actionType === "saveAndClose") {
            handleCancelForm();
            return;
          }
          navigate(
            `${routePaths.REORDERS_EDIT_BY_ID}/${selectedProjectId}/${response?.reorder?.id}`
          );
        }
      }
    } catch (error) {
      console.error("Error submitting form:", error);
      setValidationError("An error occurred while submitting the form.");
    }
  };

  type DeleteReorderFunctionArgs = {
    reorderId: string | undefined;
  };
  async function handleDeleteReorderById({
    reorderId,
  }: DeleteReorderFunctionArgs) {
    if (reorderId) {
      try {
        setIsDeleting(true);
        const res = await dispatch(
          deleteReorderById({
            reorderId: reorderId,
            errors: [],
            isSuccess: true,
          })
        ).unwrap();
        if (res.isSuccess) {
          handleCancelForm();
        }
      } catch (error) {
        console.error("Error Deleting Reorder:", error);
      } finally {
        setIsDeleting(false);
      }
    }
  }

  // Bulk upload handling
  const [resetBulkUploadFile, setBulkUploadFile] = useState(0);

  async function updateMaterials(file: File) {
    const bulkUploadParser = new BulkUploaderParser<
      LabelSupportedReorderMaterial[]
    >();
    const rows = await bulkUploadParser.readAndParseAsync(file);

    const isValid = await bulkUploadParser.validateMaterials<
      LabelSupportedReorderMaterial[]
    >({
      rows,
      schema: {
        material: "alphanumericString",
        costCode: "alphanumericString",
        quantity: "alphanumericString",
        unitOfMeasurement: "alphanumericString",
      },
      requiredKeys: ["material", "costCode", "unitOfMeasurement"],
    });

    setBulkUploadFile(Date.now());

    if (!isValid) {
      return;
    }

    rows?.forEach((m) => {
      m.name = m.material;
      m.unitOfMeasure = m?.unitOfMeasurement;
    });

    reset((values) => {
      let materials = [];
      const oldMaterials =
        values?.materials?.filter((f) => getLowerCasedMaterialName(f)) || [];

      if (oldMaterials?.length) {
        materials = bulkUploadParser.mergeMaterials({
          oldMaterials,
          newMaterials: rows,
          keysToBeUpdated: ["quantity"],
        });
      } else {
        materials = rows;
      }

      return { ...values, materials };
    });
  }

  const delay = (ms: number) =>
    new Promise((resolve) => setTimeout(resolve, ms));
  const handlePoData = async (poData: PurchaseOrder) => {
    try {
      setIsLoadROMaterial(true);
      window.scrollTo(0, 0);
      await delay(1000);
      setSelectedProjectId(poData?.purchaseOrderProject?.id || "");
      setValue("projectId", poData?.purchaseOrderProject?.id || "");
      setValue("purchaseOrderId", poData?.id || "");
      setValue(
        "projectLocationId",
        poData?.purchaseOrderDeliveryLocation.id || ""
      );

      setValue(
        "materials",
        poData?.purchaseOrderMaterials || reOrderInitialMaterialsUpdate
      );
    } catch (error) {
      console.error("error", error);
    } finally {
      setIsLoadROMaterial(false);
    }
  };

  useEffect(() => {
    if (poData) {
      handlePoData(poData);
    }
  }, [poData]);

  useEffect(() => {
    if (!reorder) return;
    // if (navigationState?.materials?.length) {
    if (reorder?.project?.id) {
      setSelectedProjectId(reorder.project.id);
    }

    reset(getDefaultValues(reorder));
    // }
  }, [reorder, reset]);

  useEffect(() => {
    dispatch(resetState());
  }, []);

  useEffect(() => {
    const materials = navigationState?.materials;
    if (!materials?.length) return;
    setValue(
      "materials",
      materials?.length ? materials : reorderInitialMaterials
    );
    if (navigationState?.projectId) {
      setValue("projectId", navigationState.projectId);
      setSelectedProjectId(navigationState.projectId);
      handleChangeProject(navigationState.projectId);
    }
  }, [pathname]);

  useEffect(() => {
    if (
      pathname === routePaths.REORDERS_NEW &&
      !navigationState?.materials?.length &&
      !navigationState?.projectId &&
      !poData
    ) {
      reset(getDefaultValues(null));
      dispatch(resetState());
    }
  }, [pathname]);

  //purchaseOrder List
  // useEffect(() => {
  //   dispatch(
  //     getPurchaseOrdersList({ projectId: getValues("projectId") || "" })
  //   );
  // }, [getValues("projectId")]);

  const handleChangeProject = (id: string) => {
    setValue("purchaseOrderId", null);
    setValue("projectLocationId", null);
    dispatch(getPurchaseOrdersList({ projectId: id || "" }));

    // dispatch(getLocationslist(id));
    const projectType = projectsSummarizedData?.find((v) => {
      return v.id === id;
    });
    setValue("projectTypeId", projectType?.projectTypeId || "");
  };

  useEffect(() => {
    dispatch(
      getPurchaseOrdersList({ projectId: getValues("projectId") || "" })
    );
  }, [dispatch]);

  // useEffect(() => {}, [getValues("projectId"), dispatch, getValues]);

  //Materials get By purchaseOrder

  const handleChangePurchaseOrder = async (value: string) => {
    try {
      setIsLoadROMaterial(true);
      const res = await dispatch(
        getPurchaseOrdersMaterialsById({ purchaseOrderId: value })
      ).unwrap();
      setValue("materials", res?.materials || reOrderInitialMaterialsUpdate);
    } catch (error) {
      console.error("error", error);
      setValue("materials", reOrderInitialMaterialsUpdate);
    } finally {
      setIsLoadROMaterial(false);
    }
  };

  async function updateDashboardProjectId() {
    handleChangeProject(dashboardProjectId);
    setValue("projectId", dashboardProjectId);
  }
  useEffect(() => {
    if (dashboardMaterials) {
      setValue("materials", dashboardMaterials);
    }

    if (dashboardProjectId) {
      updateDashboardProjectId();
    }
  }, [dashboardMaterials, dashboardProjectId]);

  useEffect(() => {
    if (isLocationModalOpen?.open) {
      dispatch(getAllStorageTypes());
    } else {
      dispatch(getLocationslist(getValues("projectId") || ""));
    }
  }, [dispatch, isLocationModalOpen?.open]);
  const handleOpenLocationModal = (title: string, field: string) => {
    setIsLocationModalOpen({
      title: title,
      open: true,
      field: field,
    });
  };

  return (
    <>
      <LocationModal
        setLocationValue={setValue}
        projectId={getValues("projectId")}
        isLocationModalOpen={isLocationModalOpen}
        setIsLocationModalOpen={setIsLocationModalOpen}
      />
      {isLoadROMaterial ? (
        <CustomOverlayLoader />
      ) : (
        <SectionLayout>
          <Form
            onFinish={handleSubmit(onSubmit)}
            layout="vertical"
            autoComplete="off"
          >
            {/* Reorder Details */}
            <CustomFormRow>
              <Col xs={24} className="mb-1">
                <Flex align="start" gap={"large"}>
                  <Typography.Title level={5}>
                    Reorders Details
                  </Typography.Title>
                </Flex>
              </Col>

              {/* Reorder Number* */}
              <Col xs={12}>
                <Controller
                  control={control}
                  name="reorderNumber"
                  render={({ field }) => (
                    <Form.Item<FieldType>
                      label={
                        <>
                          <CustomFormLabel
                            text="Reorder Number"
                            required={true}
                          />
                        </>
                      }
                      labelAlign="right"
                      initialValue={field.value}
                      validateStatus={errors.reorderNumber ? "error" : ""}
                      help={errors.reorderNumber?.message}
                    >
                      <Input
                        disabled={Boolean(reorder?.id)}
                        ref={register(`reorderNumber`).ref}
                        value={field.value}
                        onChange={(event) =>
                          field.onChange(event?.target?.value)
                        }
                        size="large"
                        placeholder="Reorder Number"
                      />
                    </Form.Item>
                  )}
                />
              </Col>

              {/* Title* */}
              <Col xs={12}>
                <Controller
                  control={control}
                  name="title"
                  render={({ field }) => (
                    <Form.Item<FieldType>
                      label={<CustomFormLabel text="Title" required={true} />}
                      labelAlign="right"
                      initialValue={field.value}
                      validateStatus={errors.title ? "error" : ""}
                      help={errors.title?.message}
                    >
                      <Input
                        ref={register(`title`).ref}
                        value={field.value}
                        onChange={(event) =>
                          field.onChange(event?.target?.value)
                        }
                        size="large"
                        placeholder="Reorder Title"
                      />
                    </Form.Item>
                  )}
                />
              </Col>

              {/* Project* */}
              <Col xs={12}>
                <Controller
                  control={control}
                  name="projectId"
                  render={({ field, fieldState: { error } }) => (
                    <Form.Item<FieldType>
                      label={<CustomFormLabel text="Project" required={true} />}
                      labelAlign="right"
                      validateStatus={error ? "error" : ""}
                      help={error?.message}
                    >
                      <Select
                        ref={register(`projectId`).ref}
                        value={field.value}
                        onChange={(value) => {
                          setSelectedProjectId(value);
                          field.onChange(value);
                          handleChangeProject(value);
                        }}
                        showSearch
                        size="large"
                        placeholder={"Select Project"}
                        style={{ width: "100%" }}
                        options={memoizedProjectsOptions}
                        filterOption={(input, option) =>
                          (option?.label || "")
                            .toLowerCase()
                            .includes(input.toLowerCase())
                        }
                      />
                    </Form.Item>
                  )}
                />
              </Col>

              {/* Project Type */}
              <Col xs={12}>
                <Controller
                  control={control}
                  name="projectTypeId"
                  render={({ field }) => (
                    <Form.Item<FieldType>
                      label={<CustomFormLabel text="Project Type" />}
                      labelAlign="right"
                      initialValue={field.value}
                    >
                      <Select
                        value={field.value}
                        onChange={(value) => {
                          field.onChange(value);
                        }}
                        size="large"
                        disabled
                        placeholder="Select Project Type"
                        options={memoizedProjectTypesOptions}
                        filterOption={(input, option) =>
                          (option?.label || "")
                            .toLowerCase()
                            .includes(input.toLowerCase())
                        }
                      />
                    </Form.Item>
                  )}
                />
              </Col>

              {/* Location* */}
              <Col xs={12}>
                <Controller
                  control={control}
                  name="projectLocationId"
                  render={({ field }) => (
                    <Form.Item<FieldType>
                      label={
                        <CustomFormLabel text="Location" required={true} />
                      }
                      labelAlign="right"
                      initialValue={field.value}
                      validateStatus={errors.projectLocationId ? "error" : ""}
                      help={errors.projectLocationId?.message}
                    >
                      <Select
                        size="large"
                        style={{ width: "100%" }}
                        placeholder={"Select Location"}
                        disabled={!selectedProjectId}
                        ref={register(`projectLocationId`).ref}
                        value={field.value}
                        onChange={(value) => {
                          field.onChange(value);
                        }}
                        options={memoizedLoctionOptions}
                        showSearch
                        filterOption={(input, option) =>
                          (option?.label || "")
                            .toLowerCase()
                            .includes(input.toLowerCase())
                        }
                        dropdownRender={(menu) => (
                          <>
                            {menu}
                            <Divider className="mt-2 mb-1" />
                            <Space className="p-1">
                              <Button
                                type="text"
                                icon={<PlusOutlined />}
                                onClick={() =>
                                  handleOpenLocationModal(
                                    "Add New Location",
                                    "projectLocationId"
                                  )
                                }
                              >
                                Add New Location
                              </Button>
                            </Space>
                          </>
                        )}
                      />
                    </Form.Item>
                  )}
                />
              </Col>

              {/* Due Date */}
              <Col xs={12}>
                <Controller
                  control={control}
                  name="dueDate"
                  render={({ field }) => (
                    <Form.Item<FieldType>
                      label={<CustomFormLabel text="Due Date" />}
                      labelAlign="right"
                      initialValue={field.value}
                    >
                      <DatePicker
                        size="large"
                        style={{ width: "100%" }}
                        placeholder="MM/DD/YYYY"
                        format={dateFormat}
                        value={
                          dayjs(field.value).isValid()
                            ? dayjs(field.value)
                            : null
                        }
                        onChange={(date) => {
                          field.onChange(dayjs(date).locale("en").format());
                        }}
                      />
                    </Form.Item>
                  )}
                />
              </Col>

              {/* Notes */}

              {/* Status* */}
              <Col xs={12}>
                <Controller
                  control={control}
                  name="status"
                  render={({ field }) => (
                    <Form.Item<FieldType>
                      label={<CustomFormLabel text="Status" required={true} />}
                      labelAlign="right"
                      initialValue={field.value}
                      validateStatus={errors.status ? "error" : ""}
                      help={errors.status?.message}
                    >
                      <Select
                        size="large"
                        placeholder={"Select Status"}
                        style={{ width: "100%" }}
                        showSearch
                        ref={register(`status`).ref}
                        value={field.value}
                        onChange={(value) => {
                          field.onChange(value);
                        }}
                        options={reorderStatusOptions}
                        filterOption={(input, option) =>
                          (option?.label || "")
                            .toLowerCase()
                            .includes(input.toLowerCase())
                        }
                      />
                    </Form.Item>
                  )}
                />
              </Col>
              <Col xs={12}>
                <Controller
                  control={control}
                  name="purchaseOrderId"
                  render={({ field }) => (
                    <Form.Item<FieldType>
                      label={<CustomFormLabel text="Purchase Order Number" />}
                      labelAlign="right"
                      initialValue={field.value}
                    >
                      <Select
                        disabled={getValues("projectId") ? false : true}
                        size="large"
                        placeholder={"Select P.O. Number"}
                        style={{ width: "100%" }}
                        showSearch
                        ref={register(`purchaseOrderId`).ref}
                        value={field.value}
                        onChange={(value) => {
                          field.onChange(value);
                          handleChangePurchaseOrder(value);
                        }}
                        options={memoizedPurchaseOrdersOptions}
                        filterOption={(input, option) =>
                          (option?.label || "")
                            .toLowerCase()
                            .includes(input.toLowerCase())
                        }
                      />
                    </Form.Item>
                  )}
                />
              </Col>

              <Col xs={12}>
                <Controller
                  control={control}
                  name="notes"
                  render={({ field }) => (
                    <Form.Item<FieldType>
                      label={
                        <CustomFormLabel text="Notes (For Internal Users)" />
                      }
                      labelAlign="right"
                      initialValue={field.value}
                    >
                      <Input.TextArea
                        value={field.value}
                        onChange={(event) =>
                          field.onChange(event?.target?.value)
                        }
                        style={{ minHeight: getConsistentSpacing(20) }}
                        size="large"
                        placeholder="Write your notes here..."
                      />
                    </Form.Item>
                  )}
                />
              </Col>
            </CustomFormRow>

            <Divider />

            {/* Quote & Purchase Order Uploads */}
            <Row className="my-9" justify="space-between">
              <Col xs={24}>
                <Typography.Title level={5}>
                  Quote & Purchase Order
                </Typography.Title>
              </Col>
              <Col xs={11}>
                <Controller
                  control={control}
                  name="RecentQuoteDocument"
                  render={({ field }) => (
                    <Form.Item<FieldType>
                      label={
                        <>
                          <CustomFormLabel text="Recent Quote" />
                          <CustomInfoTooltip
                            placement="top"
                            title={RecentQuoteInfoText}
                          />
                        </>
                      }
                      labelAlign="right"
                      initialValue={field.value}
                    >
                      <CustomFileUploadRHF
                        setValue={setValue}
                        getValues={getValues}
                        fieldName={field.name}
                        deletedFileName="deleteDocumentIds"
                        buttonText="Browse Files"
                        maxCount={1}
                      />
                    </Form.Item>
                  )}
                />
              </Col>
              <Col xs={11}>
                <Controller
                  control={control}
                  name="PurchaseOrderDocument"
                  render={({ field }) => (
                    <Form.Item<FieldType>
                      label={<CustomFormLabel text="Purchase Order" />}
                      labelAlign="right"
                      initialValue={field.value}
                    >
                      <CustomFileUploadRHF
                        setValue={setValue}
                        getValues={getValues}
                        fieldName={field.name}
                        deletedFileName="deleteDocumentIds"
                        buttonText="Browse Files"
                        maxCount={1}
                      />
                    </Form.Item>
                  )}
                />
              </Col>
            </Row>

            <Divider />

            {/* Reorder Materials */}
            <Flex
              className="mt-9"
              justify="space-between"
              align="center"
              gap={5}
            >
              <Typography.Title level={5}>Reorders Materials</Typography.Title>

              <BulkUploadButton
                updateMaterialsCallback={updateMaterials}
                shouldReset={resetBulkUploadFile}
              />
            </Flex>
            <div className="mt-6 mb-9">
              {isLoadROMaterial ? (
                <CustomOverlayLoader />
              ) : (
                <ReorderMaterialsFormSection control={control} />
              )}
            </div>

            {/* Validation handling of Reorder Materials*/}
            {validationError && (
              <CustomAlert message={validationError || ""} type="error" />
            )}

            <Divider />

            {/* Attachments */}
            <Typography.Title level={5} className="mt-9">
              Attachments
            </Typography.Title>
            <SectionLayout
              className="rounded-xl flex items-center max-h-full min-h-52 my-5"
              borderStyle="dashed"
            >
              <div className="flex flex-col justify-center items-center max-h-full min-h-52 p-8">
                <div className="mb-4">
                  <CustomIcon type="add-file" className="fill-white" />
                </div>

                <h6 className="font-medium text-sm !mb-2">
                  Select a file to import
                </h6>

                <Flex justify="center" gap={5} className="mt-2">
                  <Controller
                    control={control}
                    name="attachments"
                    render={({ field }) => (
                      <Form.Item<FieldType>
                        labelAlign="right"
                        initialValue={field.value}
                      >
                        <CustomFileUploadRHF
                          setValue={setValue}
                          getValues={getValues}
                          fieldName={field.name}
                          deletedFileName="deleteDocumentIds"
                          buttonText="Browse Files"
                          maxCount={10}
                        />
                      </Form.Item>
                    )}
                  />
                </Flex>
              </div>
            </SectionLayout>

            {/* Validation handling */}
            {!validationError && (reqError || resError || successMessage) && (
              <CustomAlert
                message={resError || successMessage || ""}
                type={successMessage ? "success" : "error"}
              />
            )}

            {/* Form Buttons */}

            <Flex
              justify="flex-end"
              className="mt-8 mb-5"
              gap={parseInt(getConsistentSpacing(2))}
            >
              <Button
                disabled={isSubmitting || isDeleting}
                type="default"
                onClick={handleCancelForm}
              >
                Cancel
              </Button>
              {Boolean(reorder) && (
                <Button
                  loading={isDeleting}
                  disabled={isSubmitting || isDeleting}
                  type="default"
                  onClick={() =>
                    handleDeleteReorderById({
                      reorderId: reorder?.id,
                    })
                  }
                >
                  {isDeleting ? "Deleting.." : "Delete"}
                </Button>
              )}

              {Boolean(reorder) && (
                <Button
                  loading={actionType === "createPO" && isSubmitting}
                  disabled={isSubmitting || isDeleting}
                  onClick={() => {
                    navigate(routePaths.PURCHASE_ORDERS_NEW, {
                      state: reorder,
                    });
                  }}
                  // onClick={() => setActionType("createPO")}
                >
                  Create PO
                </Button>
              )}

              <Button
                loading={actionType === "save" && isSubmitting}
                disabled={isSubmitting || isDeleting}
                type="primary"
                htmlType="submit"
                onClick={() => setActionType("save")}
              >
                {actionType === "save" && isSubmitting ? "Saving.." : "Save"}
              </Button>

              <Button
                loading={actionType === "saveAndClose" && isSubmitting}
                disabled={isSubmitting || isDeleting}
                type="primary"
                htmlType="submit"
                onClick={() => setActionType("saveAndClose")}
              >
                {actionType === "saveAndClose" && isSubmitting
                  ? "Saving and closing.."
                  : "Save & Close"}
              </Button>
            </Flex>

            {/* Edited Badge */}
            {getValues("id") && (
              <Flex justify="flex-end">
                <CreatedByUserBadge
                  // userName={reorder?.createdBy as string}
                  // date={reorder?.createdDate as Date}
                  userName={
                    getValues("modifiedDate")
                      ? getValues("createdBy")
                      : getValues("lastModifiedBy")
                  }
                  date={getValues("lastModifiedDate")}
                  isModifiedBadge={
                    getValues("modifiedDate") == null ? false : true
                  }
                />
              </Flex>
            )}
          </Form>
        </SectionLayout>
      )}
    </>
  );
}
