import { getReorderById } from "@/src/apis/reorderApis";
import CustomTabs from "@/src/components/common/CustomTabs";
import ReorderStatus from "@/src/components/common/ReorderStatus";
import PageLayout from "@/src/components/layout/PageLayout";
import { useAppDispatch } from "@/src/hooks/useAppDispatch";
import { useAppSelector } from "@/src/hooks/useAppSelector";
import { getReorderDataById } from "@/src/store/slices/reordersSlice";
import { getReorderStatus } from "@/src/utils/helper";
import routePaths from "@/src/utils/routePaths";
import { Flex } from "antd";
import { useEffect, useMemo, useState } from "react";
import { useLocation, useNavigate, useParams } from "react-router-dom";
import ReorderGeneralFormSection from "../components/ReorderGeneralFormSection";
import ReorderRecipientFormSection from "../components/ReorderRecipientFormSection";

export default function ReorderDetailsPage() {
  const location = useLocation();
  const FormSections = {
    General: "General",
    Recipient: "Recipient",
  };

  const navigate = useNavigate();
  const dispatch = useAppDispatch();
  const { reorderId } = useParams();

  const [selectedSection, setSelectedSection] = useState(FormSections.General);

  const catchReorder = useAppSelector((state) =>
    getReorderDataById(state, reorderId || "")
  );

  useEffect(() => {
    if (catchReorder) {
      return;
    }

    if (location.pathname?.includes("/edit/") && reorderId) {
      const fetchReorderById = async () => {
        await dispatch(getReorderById({ id: reorderId })).unwrap();
      };
      fetchReorderById();
    } else {
      return;
    }
  }, [reorderId, dispatch]);

  function renderRenderFormSections() {
    switch (selectedSection) {
      default:
        return (
          <ReorderGeneralFormSection
            dashboardMaterials={location.state?.materials}
            dashboardProjectId={location.state?.projectId}
            poData={location?.state?.isFromDashboard ? null : location.state}
            reorder={catchReorder}
            handleCancelForm={handleCancelForm}
          />
        );
      case FormSections.Recipient:
        return (
          <ReorderRecipientFormSection
            reorder={catchReorder}
            handleCancelForm={handleCancelForm}
          />
        );
    }
  }

  useEffect(() => {
    if (
      location.pathname === routePaths.REORDERS_NEW &&
      selectedSection !== FormSections.General
    ) {
      setSelectedSection(FormSections.General);
    }
  }, [location]);

  const { badgeType } = useMemo(() => {
    return getReorderStatus(catchReorder?.status || 0);
  }, [catchReorder]);

  const handleCancelForm = () => {
    const previousPath = location?.state?.previousPath || "";
    if (previousPath) {
      navigate(previousPath);
    } else {
      navigate(routePaths.REORDERS);
    }
  };

  return (
    <>
      <PageLayout
        title={catchReorder ? "Edit Reorder" : "Reorder"}
        titleSibling={<ReorderStatus badgeType={badgeType} />}
        titleBarJustifyContent="flex-start"
      >
        <Flex className="mb-7">
          <CustomTabs
            options={Object.entries(FormSections)?.map(([key, value]) => ({
              value: key,
              label: value,
              disabled: !reorderId ? value !== FormSections.General : false,
            }))}
            tabLabel={selectedSection}
            onChange={(tab) => setSelectedSection(tab)}
          />
        </Flex>
        {renderRenderFormSections()}
      </PageLayout>
    </>
  );
}
