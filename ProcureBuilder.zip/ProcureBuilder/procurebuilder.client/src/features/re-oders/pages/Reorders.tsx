import { Button } from "antd";
import ReordersList from "../components/ReordersList";
import CustomIcon from "@components/common/CustomIcon";
import { getConsistentSpacing } from "@utils/theme-helpers";
import PageLayout from "@components/layout/PageLayout";
import { useNavigate } from "react-router-dom";
import routePaths from "@/src/utils/routePaths";

export default function ReorderPage() {
  const navigate = useNavigate();

  return (
    <>
      <PageLayout
        title="Reorders"
        titleSibling={
          <Button
            size="large"
            type="primary"
            icon={
              <CustomIcon
                type="plus"
                className="fill-white"
                width={parseInt(getConsistentSpacing(3))}
                height={parseInt(getConsistentSpacing(3))}
              />
            }
            onClick={() => navigate(routePaths.REORDERS_NEW)}
          >
            New Reorder
          </Button>
        }
      >
        <ReordersList />
      </PageLayout>
    </>
  );
}
