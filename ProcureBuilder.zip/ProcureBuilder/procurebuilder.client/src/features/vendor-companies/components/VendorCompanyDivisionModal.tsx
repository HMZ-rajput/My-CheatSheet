import CustomAlert from "@/src/components/common/CustomAlert";
import CustomFormLabel from "@/src/components/common/CustomFormLabel";
import CustomModal from "@/src/components/common/CustomModal";
import { useAppSelector } from "@/src/hooks/useAppSelector";
import { getUserFullName } from "@/src/store/slices/userSlice";
import { call } from "@/src/utils/api-helpers";
import { Response, VendorDivision } from "@/src/utils/types";
import { Form, Input } from "antd";
import { useFormik } from "formik";
import { useEffect, useState } from "react";
import * as Yup from "yup";

type FieldType = {
  name?: string;
};

type VendorCompanyDivisionModalProps = {
  isOpen: boolean;
  setIsOpen: React.Dispatch<React.SetStateAction<boolean>>;
  setDivisions: React.Dispatch<React.SetStateAction<VendorDivision[]>>;
  setSelectedDivisionId: (id: string) => void;
  editDivisionType: { label: string; value: string | null } | null;
  setEditDivisionType: React.Dispatch<
    React.SetStateAction<{ label: string; value: string | null } | null>
  >;
};
const VendorCompanyDivisionModal = ({
  setSelectedDivisionId,
  ...props
}: VendorCompanyDivisionModalProps) => {
  const userFullName = useAppSelector(getUserFullName);

  const [message, setMessage] = useState("");

  const [isSuccess, setIsSuccess] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const {
    setIsOpen,
    isOpen,
    setDivisions,
    editDivisionType,
    setEditDivisionType,
  } = props;

  const formik = useFormik({
    initialValues: {
      name: "",
      id: "",
    },
    validationSchema: Yup.object({
      name: Yup.string().required("Please enter a division name!"),
      id: Yup.string(),
    }),
    onSubmit: async (values) => {
      setIsLoading(true);

      try {
        if (editDivisionType?.value) {
          const response = await call<
            { division: VendorDivision & { id: string } } & Response
          >({
            payload: {
              name: values?.name,
              modifiedBy: userFullName,
              id: values?.id,
            },
            url: `vendors/updateDivision`,
            method: "PUT",
          });

          const success = response?.isSuccess || false;
          setIsSuccess(success);

          if (success) {
            setMessage("Division Updated successfully.");
            if (response?.division?.id) {
              setDivisions((prev) => {
                const index = prev.findIndex((d) => d?.id === values?.id);
                prev[index] = response?.division;
                return [...prev];
              });
              setSelectedDivisionId(response?.division?.id || "");
            }
          } else {
            setMessage(response?.errors?.[0] || "");
          }
        } else {
          const response = await call<{ division: VendorDivision } & Response>({
            payload: {
              name: values.name,
              modifiedBy: userFullName,
            },
            url: `vendors/createDivision`,
            method: "POST",
          });

          const success = response?.isSuccess || false;
          setIsSuccess(success);

          if (success) {
            setDivisions((prev) => [...prev, response.division]);
            setMessage("Division created successfully.");
            if (response?.division?.id) {
              setSelectedDivisionId(response?.division?.id || "");
            }
          } else {
            setMessage(response?.errors?.[0] || "");
          }
        }
      } catch (err) {
        console.error(err);
        setIsSuccess(false);
      }

      setIsLoading(false);
    },
  });

  useEffect(() => {
    if (isSuccess) {
      setIsOpen(false);
      formik.resetForm();
    }
  }, [isSuccess, setIsOpen]);

  useEffect(() => {
    setIsSuccess(false);
    setMessage("");
    setIsLoading(false);
    formik.resetForm();
    if (!isOpen) {
      setEditDivisionType(null);
    }
  }, [isOpen]);

  useEffect(() => {
    setMessage("");
  }, [formik.values]);

  useEffect(() => {
    if (editDivisionType?.value) {
      formik.setFieldValue("name", editDivisionType.label);
      formik.setFieldValue("id", editDivisionType.value);
    }
  }, [editDivisionType]);

  return (
    <>
      <CustomModal
        width={500}
        isLoading={isLoading}
        title={
          editDivisionType?.value
            ? "Edit Division / Trade"
            : "Add New Division / Trade"
        }
        primaryButtonText={editDivisionType?.value ? "Update" : "Add"}
        primaryButtonLoadingText={
          editDivisionType?.value ? "Updating..." : "Adding..."
        }
        isOpen={isOpen}
        primaryButtonAction={formik.handleSubmit}
        cancelButtonAction={() => {
          setIsOpen(false);
        }}
      >
        <Form
          name="basic"
          labelCol={{ span: 7 }}
          wrapperCol={{ span: 16 }}
          style={{
            maxWidth: 500,
          }}
          onFinish={formik.handleSubmit}
          autoComplete="off"
        >
          <Form.Item<FieldType>
            label={<CustomFormLabel text="Division Name" />}
            validateStatus={
              formik.touched.name && formik.errors.name ? "error" : ""
            }
            help={
              formik.touched.name && formik.errors.name
                ? formik.errors.name
                : ""
            }
          >
            <Input
              name="name"
              value={formik.values.name}
              onChange={formik.handleChange}
            />
          </Form.Item>
        </Form>

        {message && (
          <CustomAlert
            message={message}
            type={isSuccess ? "success" : "error"}
          />
        )}
      </CustomModal>
    </>
  );
};

export default VendorCompanyDivisionModal;
