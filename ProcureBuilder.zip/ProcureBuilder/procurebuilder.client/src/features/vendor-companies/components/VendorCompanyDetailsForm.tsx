import { yupResolver } from "@hookform/resolvers/yup";
import {
  Button,
  Col,
  Divider,
  Flex,
  Form,
  Input,
  Select,
  Space,
  Typography,
} from "antd";
import { useEffect, useMemo, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import * as Yup from "yup";

import CustomFormLabel from "@components/common/CustomFormLabel";
import SectionLayout from "@components/layout/SectionLayout";
import { useAppDispatch } from "@hooks/useAppDispatch";
import { useAppSelector } from "@hooks/useAppSelector";

import {
  createVendor,
  deleteVendorById,
  editVendorById,
  getVendorslist,
} from "@/src/apis/vendorApis";
import CreatedByUserBadge from "@/src/components/common/CreatedByUserBadge";
import CustomAlert from "@/src/components/common/CustomAlert";
import CustomFormRow from "@/src/components/form/CustomFormRow";
import { getUserFullName } from "@/src/store/slices/userSlice";
import { getVendorsState, resetState } from "@/src/store/slices/vendorSlice";
import { call } from "@/src/utils/api-helpers";
import { phoneNumberLengthRegex, statesList } from "@/src/utils/constants";
import routePaths, { routePathsWithParams } from "@/src/utils/routePaths";
import { Vendor, VendorDivision, VendorEmailType } from "@/src/utils/types";
import { EditFilled } from "@ant-design/icons";
import { Controller, Resolver, useFieldArray, useForm } from "react-hook-form";
import PhoneInput from "react-phone-input-2";
import VendorCompanyDivisionModal from "./VendorCompanyDivisionModal";

import CustomIcon from "@/src/components/common/CustomIcon";
import useAuthorization from "@/src/hooks/useAuthorization";

type VendorCompanyDetailsFormProps = {
  vendorCompany: Vendor | null;
};

type InputValues = Vendor;

const VendorCompanyDetailsForm = ({
  vendorCompany,
}: VendorCompanyDetailsFormProps) => {
  const [divisions, setDivisions] = useState<VendorDivision[]>([]);
  const { isFieldsCraftAuthorized } = useAuthorization();
  const [actionType, setActionType] = useState("");
  const { successMessage, resError, reqError } =
    useAppSelector(getVendorsState);
  const [isOpen, setIsOpen] = useState(false);
  const [editDivisionType, setEditDivisionType] = useState<{
    label: string;
    value: string | null;
  } | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);
  const userFullName = useAppSelector(getUserFullName);
  const dispatch = useAppDispatch();
  const navigate = useNavigate();

  const { vendorCompanyId } = useParams();

  type FieldType = {
    vendorCompanyName: string;
    emails: string[];
    vendorCompanyDivision: string;
    primaryContactName: string;
    businessPhoneNumber: string;
    cellPhoneNumber: string;
    fax: string;

    streetAddress: string;
    city: string;
    state: string;
    zipCode: string;

    vendorCompanyNotes: string;
  };

  useEffect(() => {
    const getDivisions = async () => {
      const response = await call<{ divisions: VendorDivision[] }>({
        url: `vendors/divisions`,
        method: "GET",
      });

      setDivisions(response?.divisions || []);
      return;
    };
    getDivisions();
  }, []);

  const memoizedDivisionsOptions = useMemo(() => {
    return [
      ...(divisions?.map((division) => ({
        value: division?.id,
        label: division?.name,
      })) || []),
    ];
  }, [divisions]);

  const validationSchema = Yup.object().shape({
    name: Yup.string().required("Company Name is required."),
    divisionIds: Yup.array()
      .min(1, "At least one Division / Trade is required.")
      .of(Yup.string())
      .required("Division / Trade is required."),
    contactName: Yup.string().required("Primary Contact Name is required."),
    emails: Yup.array().of(
      Yup.object({
        email: Yup.string()
          .email("Invalid email format")
          .matches(
            /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/,
            "Invalid email format (e.g., example@domain.com)"
          ),
      })
    ),
    // .min(1, "At least one valid email is required.")
    zipCode: Yup.string()
      .trim()
      .test(
        "len",
        "Invalid Zip Code. Please enter in the format: 12345 or 12345-6789",
        (val) => !val || val.length === 5 || val.length === 10
      ),
    phoneNumber: Yup.string()
      .optional()
      .trim()
      .matches(phoneNumberLengthRegex, {
        message: "Phone Number is not valid in the US",
        excludeEmptyString: true,
      }),
    cellPhone: Yup.string().optional().trim().matches(phoneNumberLengthRegex, {
      message: "Cell Phone Number is not valid in the US",
      excludeEmptyString: true,
    }),
    fax: Yup.string().optional().trim().matches(phoneNumberLengthRegex, {
      message: "Fax Number is not valid in the US",
      excludeEmptyString: true,
    }),
  });

  const getDefaultValues = (vendorCompany: Vendor | null) => {
    return vendorCompany
      ? {
          ...vendorCompany,
          emails: vendorCompany?.emails.length
            ? (vendorCompany.emails.map((email) => ({
                email,
              })) as VendorEmailType[])
            : [{ email: "" }],
        }
      : {
          name: "",
          divisionIds: [],
          contactName: "",
          phoneNumber: "",
          cellPhone: "",
          emails: [{ email: "" }],
          fax: "",
          address: "",
          city: "",
          state: "",
          zipCode: "",
          notes: "",
        };
  };

  const {
    setValue,
    getValues,
    handleSubmit,
    control,
    reset,
    formState: { errors, isSubmitting },
    register,
  } = useForm<InputValues>({
    resolver: yupResolver(validationSchema) as unknown as Resolver<InputValues>,
    defaultValues: getDefaultValues(vendorCompany ? vendorCompany : null),
  });

  const { fields, append, remove } = useFieldArray({
    control,
    name: "emails",
  });

  useEffect(() => {
    if (!vendorCompany) {
      reset({
        name: "",
        divisionIds: [],
        contactName: "",
        phoneNumber: "",
        cellPhone: "",
        emails: [{ email: "" }],
        fax: "",
        address: "",
        city: "",
        state: "",
        zipCode: "",
        notes: "",
      });
      return;
    }

    const vendorCompanyValues = getDefaultValues(vendorCompany);
    reset(vendorCompanyValues);
  }, [vendorCompany, reset, vendorCompanyId]);

  async function handleDeleteVendorCompanyById() {
    if (vendorCompany?.id) {
      try {
        setIsDeleting(true);
        const res = await dispatch(
          deleteVendorById(vendorCompany?.id || "")
        ).unwrap();
        if (res.isSuccess) {
          navigate(routePathsWithParams.VENDORS);
        }
      } catch (error) {
        // setIsDeletingError(error.message);
        console.error("Error deleting project:", error);
      } finally {
        setIsDeleting(false);
      }
    }
  }

  const handleOpenModal = () => {
    setIsOpen(!isOpen);
  };

  // Handler to add a new email field

  const deleteVendorEmail = (index: number) => {
    remove(index);
  };

  useEffect(() => {
    dispatch(resetState());
  }, []);

  const handleSave = async (data: InputValues) => {
    if (vendorCompanyId) {
      const res = await dispatch(
        editVendorById({ id: vendorCompanyId, ...data })
      ).unwrap();
      // if (res.isSuccess) {
      //   reset(res.vendor);
      // }
      return res;
    } else {
      const res = await dispatch(
        createVendor({ ...data, createdBy: userFullName })
      ).unwrap();
      if (res?.isSuccess) {
        navigate(`${routePaths.VENDORS_EDIT_BY_ID}/${res?.vendor?.id}`);
      }
      return res;
    }
  };

  const onSubmit = async (data: InputValues) => {
    const emails = data.emails.map((email) => {
      const vendorEmail = email as VendorEmailType;

      return vendorEmail.email;
    });
    data = {
      ...data,
      emails,
    };
    try {
      if (actionType === "save") {
        await handleSave(data);
      } else if (actionType === "saveAndClose") {
        const res = await handleSave(data);
        if (res?.isSuccess) {
          navigate(`${routePaths.VENDORS}`);
        }
      }
    } catch (error) {
      console.error("Error during form submission:", error);
    } finally {
      dispatch(getVendorslist());
    }
  };

  const handleEditStorageType = (item: {
    label: string;
    value: string | null;
  }) => {
    setIsOpen(true);
    setEditDivisionType(item);
  };

  return (
    <>
      <VendorCompanyDivisionModal
        setIsOpen={setIsOpen}
        isOpen={isOpen}
        editDivisionType={editDivisionType}
        setEditDivisionType={setEditDivisionType}
        setDivisions={setDivisions}
        setSelectedDivisionId={(id) => {
          let previousDivisionIds = getValues("divisionIds") || [];
          const index = previousDivisionIds?.indexOf(id);
          if (index === -1) {
            previousDivisionIds.push(id);
          } else {
            previousDivisionIds[index] = id;
          }
          setValue(`divisionIds`, [...previousDivisionIds]);
        }}
      />

      <SectionLayout>
        <Form
          onFinish={handleSubmit(onSubmit)}
          layout="vertical"
          autoComplete="off"
          disabled={isFieldsCraftAuthorized()}
        >
          <CustomFormRow>
            <Col xs={24} className="mb-4">
              <Typography.Title level={5}>Contact Information</Typography.Title>
            </Col>

            <Col xs={12}>
              <CustomFormLabel text="Company Name" required />
              <Controller
                name="name"
                control={control}
                render={({ field }) => (
                  <Form.Item<FieldType>
                    validateStatus={errors.name ? "error" : ""}
                    help={errors.name?.message}
                  >
                    <Input
                      {...field}
                      ref={register("name").ref}
                      size="large"
                      placeholder="Vendor Company Name"
                      className="mt-3"
                    />
                  </Form.Item>
                )}
              />
            </Col>
            <Col xs={12}>
              <Form.Item<FieldType>
                validateStatus={
                  //   // touched.vendorCompanyDivision &&
                  errors.divisionIds ? "error" : ""
                }
                help={
                  //   // touched.vendorCompanyDivision &&
                  errors.divisionIds?.message
                  //     ? errors.vendorCompanyDivision
                  //     : ""
                }
              >
                <CustomFormLabel text="Division / Trade" required />
                <Controller
                  name="divisionIds"
                  control={control}
                  render={({ field }) => (
                    <Select
                      mode="multiple"
                      {...field}
                      // value={formik.values.vendorCompanyDivision}
                      // onChange={(value) =>
                      //   formik.setFieldValue("vendorCompanyDivision", value || "")
                      // }
                      size="large"
                      placeholder="Select Divison / Trade"
                      rootClassName="z-50"
                      className="mt-3"
                      // options={memoizedDivisionsOptions}
                      dropdownRender={(menu) => (
                        <>
                          {menu}
                          <Divider className="mt-2 mb-1" />
                          <Space className="p-1">
                            <Button
                              className="border-0 shadow-none text-primary font-medium"
                              type="text"
                              icon={<EditFilled />}
                              onClick={handleOpenModal}
                            >
                              Add New
                            </Button>
                          </Space>
                        </>
                      )}
                      showSearch
                      filterOption={(input, option) =>
                        (option?.key ?? "")
                          .toLowerCase()
                          .includes(input.toLowerCase())
                      }
                    >
                      {memoizedDivisionsOptions?.map((item) => (
                        <Select.Option key={item.label} value={item.value}>
                          <div
                            style={{
                              display: "flex",
                              justifyContent: "space-between",
                              alignItems: "center",
                            }}
                          >
                            <span>{item.label}</span>
                            {item.value && (
                              <Button
                                type="link"
                                size="small"
                                icon={
                                  <EditFilled
                                    size={18}
                                    // className="px-3 py-1 rounded-md text-textBase"
                                  />
                                }
                                onMouseDown={(e) => e.stopPropagation()} // Prevent dropdown from toggling
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleEditStorageType(item);
                                }}
                              />
                            )}
                          </div>
                        </Select.Option>
                      ))}
                    </Select>
                  )}
                />
              </Form.Item>
            </Col>

            <Col xs={12}>
              <Form.Item<FieldType>
                labelAlign="right"
                validateStatus={
                  //   // touched.primaryContactName &&
                  errors.contactName ? "error" : ""
                }
                help={
                  //   // touched.primaryContactName &&
                  errors.contactName?.message
                }
              >
                <CustomFormLabel text="Primary Contact Name" required />
                <Controller
                  name="contactName"
                  control={control}
                  render={({ field }) => (
                    <Input
                      {...field}
                      // {...register("primaryContactName")}
                      // value={formik.values.primaryContactName}
                      // onChange={(event) =>
                      //   formik.setFieldValue(
                      //     "primaryContactName",
                      //     event?.target?.value || ""
                      //   )
                      // }
                      className="mt-3"
                      size="large"
                      placeholder="Contact Name"
                    />
                  )}
                />
              </Form.Item>
            </Col>

            <Col xs={12}>
              <Form.Item<FieldType>
                label={<CustomFormLabel text="Business Phone" />}
                labelAlign="right"
                validateStatus={errors.phoneNumber ? "error" : ""}
                help={errors.phoneNumber ? errors.phoneNumber.message : ""}
              >
                <Controller
                  name="phoneNumber"
                  control={control}
                  render={({ field }) => (
                    <div ref={register("phoneNumber").ref}>
                      <PhoneInput
                        country={"us"}
                        value={field.value}
                        onChange={(phoneNumber) => field.onChange(phoneNumber)}
                      />
                    </div>
                  )}
                />
              </Form.Item>
            </Col>

            <Col xs={12}>
              <Form.Item<FieldType>
                label={<CustomFormLabel text="Cell Phone" />}
                labelAlign="right"
                validateStatus={errors.cellPhone ? "error" : ""}
                help={errors.cellPhone ? errors.cellPhone.message : ""}
              >
                <Controller
                  name="cellPhone"
                  control={control}
                  render={({ field }) => (
                    <div ref={register("cellPhone").ref}>
                      <PhoneInput
                        country={"us"}
                        value={field.value}
                        onChange={(cellPhone) => field.onChange(cellPhone)}
                      />
                    </div>
                  )}
                />
              </Form.Item>
            </Col>

            <Col xs={12}>
              {fields.map((field, index) => (
                <Form.Item
                  key={field.id}
                  validateStatus={
                    typeof errors.emails?.[index] === "object" &&
                    "email" in errors.emails[index]
                      ? "error"
                      : ""
                  }
                  help={
                    typeof errors.emails?.[index] === "object" &&
                    "email" in errors.emails[index]
                      ? errors.emails[index].email?.message
                      : ""
                  }
                  labelAlign="right"
                >
                  <CustomFormLabel text={`Email ${index + 1}`} required />
                  <Flex align="center">
                    <Controller
                      name={`emails.${index}.email`}
                      control={control}
                      // defaultValue={field.email} // Set the default value for the email
                      render={({ field }) => (
                        <Input
                          {...field}
                          size="large"
                          placeholder="Vendor Email"
                          className="mt-3"
                        />
                      )}
                    />
                    <Button
                      disabled={fields.length <= 1}
                      onClick={() => deleteVendorEmail(index)}
                      className="border-0 shadow-none text-primary font-medium"
                    >
                      Delete
                    </Button>
                  </Flex>
                </Form.Item>
              ))}

              <Flex justify="space-between">
                <Button
                  className="border-0 shadow-none text-primary font-medium"
                  size="small"
                  icon={<CustomIcon width={16} type="add-circle" />}
                  onClick={() => append({ email: "" })}
                  disabled={fields.length >= 5}
                >
                  Add Email
                </Button>
              </Flex>
            </Col>

            <Col xs={12}>
              <Controller
                name="fax"
                control={control}
                render={({ field, fieldState: { error } }) => (
                  <Form.Item<FieldType>
                    label={<CustomFormLabel text="Fax" />}
                    labelAlign="right"
                    validateStatus={error ? "error" : ""}
                    help={error ? error.message : ""}
                  >
                    <div ref={register("fax")?.ref}>
                      <PhoneInput
                        {...field}
                        containerClass="phoneNumberInput"
                        country={"us"}
                        preferredCountries={["us"]}
                        value={field.value}
                        onChange={(phoneNumber) => {
                          field.onChange(phoneNumber);
                        }}
                      />
                    </div>
                  </Form.Item>
                )}
              />
            </Col>
          </CustomFormRow>
          <CustomFormRow>
            <Col xs={24} className="my-4">
              <Typography.Title level={5}>Address Information</Typography.Title>
            </Col>
            <Col xs={12}>
              <Form.Item<FieldType>
                label={<CustomFormLabel text="Street Address" />}
                labelAlign="right"
              >
                <Controller
                  name="address"
                  control={control}
                  render={({ field }) => (
                    <Input {...field} size="large" placeholder="Your Address" />
                  )}
                />
              </Form.Item>
            </Col>
            <Col xs={12}>
              <Form.Item<FieldType>
                label={<CustomFormLabel text="City" />}
                labelAlign="right"
                // initialValue={formik.values.city}
              >
                <Controller
                  name="city"
                  control={control}
                  render={({ field }) => (
                    <Input
                      {...field}
                      placeholder="Enter your city"
                      size="large"
                    />
                  )}
                />
              </Form.Item>
            </Col>
            <Col xs={12}>
              <Form.Item<FieldType>
                label={<CustomFormLabel text="State" />}
                labelAlign="right"
                // initialValue={watch("state") || null}
              >
                <Controller
                  name="state"
                  control={control}
                  render={({ field }) => (
                    <Select
                      {...field}
                      size="large"
                      options={statesList?.map((state) => ({
                        label: state,
                        value: state,
                      }))}
                      placeholder="Select State"
                      showSearch
                      filterOption={(input, option) =>
                        (option?.label ?? "")
                          .toLowerCase()
                          .includes(input.toLowerCase())
                      }
                    />
                  )}
                />
              </Form.Item>
            </Col>
            <Col xs={12}>
              <Form.Item<FieldType>
                label={<CustomFormLabel text="Zip Code" />}
                labelAlign="right"
                validateStatus={errors.zipCode ? "error" : ""}
                help={errors.zipCode ? errors.zipCode.message : ""}
              >
                <Controller
                  name="zipCode"
                  control={control}
                  render={({ field }) => (
                    <Input
                      {...field}
                      size="large"
                      placeholder="Your Zip Code"
                    />
                  )}
                />
              </Form.Item>
            </Col>
          </CustomFormRow>
          <CustomFormRow>
            <Col xs={24} className="my-4">
              <Typography.Title level={5}>Notes</Typography.Title>
            </Col>
            <Col xs={24}>
              <Form.Item<FieldType>
                label={<CustomFormLabel text="Notes (for Internal Users)" />}
                labelAlign="right"
                // initialValue={formik.values.vendorCompanyNotes}
              >
                <Controller
                  name="notes"
                  control={control}
                  render={({ field }) => (
                    <Input.TextArea
                      {...field}
                      className="min-h-40"
                      placeholder="Write your notes here.."
                    />
                  )}
                />
              </Form.Item>
            </Col>
          </CustomFormRow>
          {(successMessage || resError || reqError) && (
            <CustomAlert
              message={resError || reqError || successMessage || ""}
              type={successMessage ? "success" : "error"}
            />
          )}
          {isFieldsCraftAuthorized() ? (
            <Flex justify="flex-end" className="gap-4">
              <Button
                disabled={isSubmitting || isDeleting}
                type="default"
                onClick={() => navigate(`${routePaths.VENDORS}`)}
              >
                Back
              </Button>
            </Flex>
          ) : (
            <Flex justify="flex-end" className="gap-4">
              <Button
                disabled={isSubmitting || isDeleting}
                type="default"
                onClick={() => navigate(`${routePaths.VENDORS}`)}
              >
                Cancel
              </Button>
              {vendorCompanyId && vendorCompany && (
                <Button
                  loading={isDeleting}
                  disabled={isSubmitting || isDeleting}
                  type="default"
                  onClick={handleDeleteVendorCompanyById}
                >
                  {isDeleting ? "Deleting.." : "Delete"}
                </Button>
              )}
              <Button
                loading={actionType === "save" && isSubmitting}
                disabled={isSubmitting || isDeleting}
                type="primary"
                htmlType="submit"
                onClick={() => setActionType("save")}
              >
                {actionType === "save" && isSubmitting ? "Saving.." : "Save"}
              </Button>

              <Button
                loading={actionType === "saveAndClose" && isSubmitting}
                disabled={isSubmitting || isDeleting}
                type="primary"
                htmlType="submit"
                onClick={() => setActionType("saveAndClose")}
              >
                {actionType === "saveAndClose" && isSubmitting
                  ? "Saving and closing.."
                  : "Save & Close"}
              </Button>
            </Flex>
          )}
          <div className="mt-5"></div>
          {vendorCompany?.id && (
            <Flex justify="flex-end">
              <CreatedByUserBadge
                userName={
                  getValues("modifiedDate") === null
                    ? getValues("createdBy")
                    : getValues("lastModifiedBy")
                }
                date={getValues("lastModifiedDate")}
                isModifiedBadge={
                  getValues("modifiedDate") === null ? false : true
                }
              />
            </Flex>
          )}
        </Form>
      </SectionLayout>
    </>
  );
};

export default VendorCompanyDetailsForm;
