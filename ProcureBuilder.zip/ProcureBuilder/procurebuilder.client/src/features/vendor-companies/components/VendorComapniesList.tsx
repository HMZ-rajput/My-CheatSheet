import { getAllVendors } from "@/src/apis/vendorApis";
import CustomIcon from "@/src/components/common/CustomIcon";
import HighlightedText from "@/src/components/common/HighlightedText";
import SectionLayout from "@/src/components/layout/SectionLayout";
import CustomTable from "@/src/components/table/CustomTable";
// import CustomTableFilters, {
//   CustomFiltersType,
// } from "@/src/components/table/CustomTableFilters";
import { useAppDispatch } from "@/src/hooks/useAppDispatch";
import { useAppSelector } from "@/src/hooks/useAppSelector";
import useAuthorization from "@/src/hooks/useAuthorization";
import useSyncFilters from "@/src/hooks/useSyncFilters";
import { getVendorsState } from "@/src/store/slices/vendorSlice";
import { call } from "@/src/utils/api-helpers";
import routePaths from "@/src/utils/routePaths";
import { getConsistentSpacing } from "@/src/utils/theme-helpers";
import { Vendor, VendorDivision } from "@/src/utils/types";
import { Button, TableProps, Typography } from "antd";
import { useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";

const VendorCompaniesList = () => {
  const dispatch = useAppDispatch();
  const { isFieldsCraftAuthorized } = useAuthorization();
  const navigate = useNavigate();
  const {
    vendorsData,
    isLoading,
    totalCount,
    currentPage: vendorsCurrentPage,
    pageSize: vendorsPageSize,
  } = useAppSelector(getVendorsState);

  const [divisions, setDivisions] = useState<VendorDivision[]>([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [hasSearched, setHasSearched] = useState(false);
  const { searchParams } = useSyncFilters();
  const [previousSearchTerm, setPreviousSearchTerm] = useState(
    searchParams.get("searchTerm")
  );
  const [page, setPage] = useState<number>(vendorsCurrentPage);
  const [pageSize, setPageSize] = useState(vendorsPageSize);
  const isFirstCallComplete = useRef(false);
  // const [isFirstCall, setIsFirstCall] = useState(false);

  console.log(divisions);
  // const allDivisionsOption = useMemo(
  //   () => ({
  //     value: "all-divisions",
  //     label: "Division / Trade",
  //   }),
  //   []
  // );

  useEffect(() => {
    const getDivisions = async () => {
      const response = await call<{ divisions: VendorDivision[] }>({
        url: `vendors/divisions`,
        method: "GET",
      });

      setDivisions(response?.divisions || []);
      return;
    };
    getDivisions();
  }, []);

  // const divisionOptions = useMemo(() => {
  //   const mappedDivisions =
  //     divisions?.map((division) => ({
  //       value: division.id || "",
  //       label: division.name,
  //     })) || [];
  //   return [allDivisionsOption, ...mappedDivisions];
  // }, [allDivisionsOption, divisions]);

  // const [filters, setFilters] = useState<CustomFiltersType>({
  //   division: {
  //     value: allDivisionsOption?.value || "",
  //     options: divisionOptions,
  //   },
  // });

  // useMemo(() => {
  //   setFilters({
  //     division: {
  //       value: allDivisionsOption?.value,
  //       options: divisionOptions,
  //     },
  //   });
  // }, [allDivisionsOption, divisionOptions]);

  function handleGetResults(pageNumber?: number) {
    // const division =
    //   filters.division?.value !== allDivisionsOption?.value
    //     ? filters?.division?.value?.toString()
    //     : undefined;

    dispatch(
      getAllVendors({
        // divisionId: division,
        pageNumber: pageNumber || page,
        pageSize: vendorsPageSize,
        search: searchTerm || undefined,
      })
    );
  }

  function resetPaginationAndGetFirstPageResults() {
    if (isFirstCallComplete?.current === true) {
      // if (filters) {
      //   setPage(1);
      // }

      handleGetResults(1);
    } else {
      handleGetResults();
    }
  }

  useEffect(() => {
    if (!hasSearched) return;
    const timer = setTimeout(() => {
      if (searchTerm === "" && previousSearchTerm !== "") {
        resetPaginationAndGetFirstPageResults();
        setPreviousSearchTerm(searchTerm);
      }
    }, 500);

    return () => {
      clearTimeout(timer);
    };
  }, [searchTerm, hasSearched, previousSearchTerm]);

  const handleSearch = () => {
    if (searchTerm !== previousSearchTerm) {
      setHasSearched(true);
      resetPaginationAndGetFirstPageResults();
      setPreviousSearchTerm(searchTerm);
    }
  };

  // useEffect(() => {
  //   resetPaginationAndGetFirstPageResults();
  // }, []);

  useEffect(() => {
    if (
      !isFirstCallComplete?.current ||
      vendorsCurrentPage !== page ||
      vendorsPageSize !== pageSize
    ) {
      handleGetResults();
      if (!isFirstCallComplete?.current) {
        setTimeout(() => {
          isFirstCallComplete.current = true;
        }, 1000);
      }
    }
  }, [page, pageSize]);

  const columns: TableProps<Vendor>["columns"] = [
    {
      title: "Company Name",
      dataIndex: "name",
      sorter: (a, b) => a.name?.localeCompare(b.name),
      render: (_, record) => (
        <Typography.Title
          level={5}
          style={{ fontSize: getConsistentSpacing(1.75), margin: 0 }}
        >
          <HighlightedText text={record.name} searchTerm={searchTerm} />
        </Typography.Title>
      ),
    },
    {
      title: "Division / Trade",
      dataIndex: "divisionName",
      sorter: (a, b) => {
        return (a.divisionNames?.[0] || "").localeCompare(
          b.divisionNames?.[0] || ""
        );
      },
      render: (divisionName) => {
        return divisionName?.map((tradeName: string) => {
          return (
            <Typography.Text
              code
              style={{ fontSize: getConsistentSpacing(1.75), margin: 0 }}
            >
              <HighlightedText text={tradeName} searchTerm={searchTerm} />
            </Typography.Text>
          );
        });
      },
    },
    {
      title: "Primary Contact",
      dataIndex: "contactName",
      sorter: (a, b) => a.contactName?.localeCompare(b.contactName),
    },
    // {
    //   title: "Business Phone",
    //   dataIndex: "phoneNumber",
    //   sorter: (a, b) => {
    //     return Number(a.phoneNumber) - Number(b.phoneNumber);
    //   },
    // },
    {
      title: "City",
      dataIndex: "city",
      sorter: (a, b) => a.city?.localeCompare(b.city),
    },
    {
      title: "State",
      dataIndex: "state",
      sorter: (a, b) => a.state?.localeCompare(b.state),
    },
    {
      title: "Zip code",
      dataIndex: "zipCode",
      sorter: (a, b) => Number(a.zipCode) - Number(b.zipCode),
    },
    {
      title: "Emails",
      dataIndex: "emails",
      sorter: (a, b) => {
        const firstIndex = a.emails[0] as string;
        const secondIndex = b.emails[0] as string;
        return firstIndex?.localeCompare(secondIndex);
      },
      render: (emails) => {
        return emails.map((email: string) => {
          return (
            <Typography.Text
              keyboard
              style={{ fontSize: getConsistentSpacing(1.75), margin: 0 }}
            >
              <HighlightedText text={email} searchTerm={searchTerm} />
            </Typography.Text>
          );
        });
      },
    },
    ...(!isFieldsCraftAuthorized()
      ? [
          {
            title: "",
            dataIndex: "",
            key: "",
            render: (_: unknown, record: Vendor) => (
              <Button
                shape="circle"
                icon={<CustomIcon type="edit" />}
                onClick={() =>
                  navigate(`${routePaths.VENDORS_EDIT_BY_ID}/${record?.id}`)
                }
              />
            ),
          },
        ]
      : []),
  ];

  return (
    <>
      <SectionLayout>
        <CustomTable
          data={vendorsData || []}
          columns={columns || []}
          searchTerm={searchTerm}
          setSearchTerm={setSearchTerm}
          handleSearch={handleSearch}
          isLoading={isLoading}
          totalCount={totalCount}
          page={page}
          setPage={setPage}
          pageSize={pageSize}
          setPageSize={setPageSize}
          // filterElements={
          //   <CustomTableFilters filters={filters} setFilters={setFilters} />
          // }
          hasPagination={true}
        />
      </SectionLayout>
    </>
  );
};

export default VendorCompaniesList;
