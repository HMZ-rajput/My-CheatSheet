import PageLayout from "@/src/components/layout/PageLayout";
import { useParams } from "react-router-dom";
import VendorCompanyDetailsForm from "../components/VendorCompanyDetailsForm";
import { useEffect, useState } from "react";
import { getVendorById } from "@/src/apis/vendorApis";
import { useAppDispatch } from "@/src/hooks/useAppDispatch";
import { Vendor } from "@/src/utils/types";
import { useAppSelector } from "@/src/hooks/useAppSelector";
import { getVendorDataById } from "@/src/store/slices/vendorSlice";
// import { useState } from "react";

export default function VendorCompanyDetailsPage() {
  const [vendorData, setVendorData] = useState<Vendor | null>(null);
  const dispatch = useAppDispatch();
  const { vendorCompanyId } = useParams();
  const vendorCompany = useAppSelector((state) =>
    getVendorDataById(state, vendorCompanyId || "")
  );

  useEffect(() => {
    if (vendorCompany) {
      setVendorData(vendorCompany);
      return;
    }

    const fetchVendorById = async () => {
      if (vendorCompanyId) {
        const response = await dispatch(
          getVendorById({ id: vendorCompanyId })
        ).unwrap();
        console.log(response.vendor, "vendor response");
        setVendorData(response.vendor);
      } else {
        setVendorData(null);
      }
    };
    fetchVendorById();
    // return;
  }, [vendorCompanyId, vendorCompany]);

  return (
    <>
      <PageLayout title={`${vendorData ? "Edit" : "Add"} Vendor Company`}>
        <VendorCompanyDetailsForm vendorCompany={vendorData} />
      </PageLayout>
    </>
  );
}
