import { getMaterialTransferByIdAsync } from "@/src/apis/materialTransferApis";
import MaterialTransferStatus from "@/src/components/common/MaterialTransferStatus";
import { useAppSelector } from "@/src/hooks/useAppSelector";
import { getMaterialTransferById } from "@/src/store/slices/materialTransferSlice";
import { getMaterialTransferStatus } from "@/src/utils/helper";
import routePaths from "@/src/utils/routePaths";
import { MaterialTransfer } from "@/src/utils/types";
import PageLayout from "@components/layout/PageLayout";
import { useEffect, useState } from "react";
import { useLocation, useParams } from "react-router-dom";
import MaterialTransferDetailsFormRHF from "../components/MaterialTransferDetailsFormRHF";

export default function MaterialTransferDetailsPage() {
  const { materialTransferId } = useParams();
  const [materialTransferData, setMaterialTransferData] =
    useState<MaterialTransfer | null>(null);
  const location = useLocation();

  const materialTransfer = useAppSelector((state) =>
    getMaterialTransferById(state, materialTransferId || "")
  );

  useEffect(() => {
    if (!materialTransfer && materialTransferId) {
      const fetchGetMaterialTransferById = async () => {
        const response = await getMaterialTransferByIdAsync(
          materialTransferId || ""
        );

        if (response?.isSuccess) {
          setMaterialTransferData(response?.materialTransfer);
        }
      };
      fetchGetMaterialTransferById();
    }
    if (location.pathname === routePaths.MATERIAL_TRANSFER_NEW) {
      setMaterialTransferData(null);
    }
  }, [materialTransfer, materialTransferId, location]);

  const { badgeType } = getMaterialTransferStatus(
    materialTransfer?.status || materialTransferData?.status || 0
  );

  return (
    <>
      <PageLayout
        title={`${
          materialTransfer || materialTransferData ? "Edit" : "Create New"
        } Material Transfer`}
        titleBarJustifyContent="flex-start"
        titleSibling={<MaterialTransferStatus badgeType={badgeType} />}
      >
        {/* <MaterialTransferDetailsForm materialTransfer={materialTransfer} /> */}
        <MaterialTransferDetailsFormRHF
          materialTransfer={materialTransfer || materialTransferData}
        />
      </PageLayout>
    </>
  );
}
