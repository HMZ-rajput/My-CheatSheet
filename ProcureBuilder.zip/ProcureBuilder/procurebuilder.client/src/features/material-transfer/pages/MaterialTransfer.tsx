import CustomIcon from "@components/common/CustomIcon";
import PageLayout from "@components/layout/PageLayout";
import { getConsistentSpacing } from "@utils/theme-helpers";
import { Button } from "antd";
import routePaths from "@/src/utils/routePaths";
import { useNavigate } from "react-router-dom";
import MaterialTransferList from "../components/MaterialTransferList";
export default function MaterialTransferPage() {
  const navigate = useNavigate();
  return (
    <>
      <PageLayout
        title="Material Transfer"
        titleSibling={
          <Button
            size="large"
            type="primary"
            icon={
              <CustomIcon
                type="plus"
                className="fill-white"
                width={parseInt(getConsistentSpacing(3))}
                height={parseInt(getConsistentSpacing(3))}
              />
            }
            onClick={() => navigate(routePaths.MATERIAL_TRANSFER_NEW)}
          >
            New Material Transfer
          </Button>
        }
      >
        <MaterialTransferList hasPagination hasDetailedColumns />
      </PageLayout>
    </>
  );
}
