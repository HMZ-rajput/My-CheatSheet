// import {
//   Col,
//   DatePicker,
//   Divider,
//   Flex,
//   Form,
//   Input,
//   Select,
//   Typography,
// } from "antd";
// import { useFormik } from "formik";
// import { useEffect, useMemo, useState } from "react";

// import { getLocationslist } from "@/src/apis/locationApis";
// import { getSummarizedProjectsList } from "@/src/apis/projectApis";
// import CustomFormRow from "@/src/components/form/CustomFormRow";
// import { useAppDispatch } from "@/src/hooks/useAppDispatch";
// import { getLocationsState } from "@/src/store/slices/locationSlice";
// import { getProjectsState } from "@/src/store/slices/projectsSlice";
// import { getUserFullName } from "@/src/store/slices/userSlice";
// import {
//   MaterialTransfer,
//   MaterialTransferAddMaterial,
// } from "@/src/utils/types";
// import CustomFormLabel from "@components/common/CustomFormLabel";
// import SectionLayout from "@components/layout/SectionLayout";
// import { useAppSelector } from "@hooks/useAppSelector";
// import { dateFormat, materialTransferStatusOptions } from "@utils/constants";
// import AddMaterialDetailsForm from "./AddMaterialTransferDetailsForm";
// import {
//   createMaterialTransfer,
//   deleteMaterialTransferById,
//   editMaterialTransferById,
//   getAllMaterialTransferlist,
// } from "@/src/apis/materialTransferApis";
// import CustomFormButtons from "@/src/components/form/CustomFormButtons";
// import {
//   getMaterialTransferState,
//   resetStateisSuccess,
// } from "@/src/store/slices/materialTransferSlice";
// import dayjs from "dayjs";
// import CreatedByUserBadge from "@/src/components/common/CreatedByUserBadge";
// import CustomAlert from "@/src/components/common/CustomAlert";
// import CustomOverlayLoader from "@/src/components/common/CustomOverlayloader";
// import { useNavigate } from "react-router-dom";
// import { routePathsWithParams } from "@/src/utils/routePaths";
// import * as Yup from "yup";

// type MaterialDetailsFormProps = {
//   materialTransfer?: MaterialTransfer | null;
//   projectLocationId?: string;
//   handleCancelForm?: () => void;
// };

// export default function MaterialTransferDetailsForm({
//   materialTransfer,
//   handleCancelForm,
// }: MaterialDetailsFormProps) {
//   const userFullName = useAppSelector(getUserFullName);
//   const dispatch = useAppDispatch();
//   const { isSuccess, resError, successMessage, reqError } = useAppSelector(
//     getMaterialTransferState
//   );
//   const [hasMadeApiCall, setHasMadeApiCall] = useState(false);
//   const [isLoading, setIsLoading] = useState(false);
//   const [isLoadingProjectSelection, setIsLoadingProjectSelection] =
//     useState(false);
//   const [materialTableData, setMaterialTableData] = useState<
//     MaterialTransferAddMaterial[]
//   >([]);
//   const isEditMode = Boolean(materialTransfer?.id);
//   const navigate = useNavigate();

//   type FieldType = MaterialTransfer[];

//   useEffect(() => {
//     dispatch(getSummarizedProjectsList());
//   }, [dispatch]);

//   const { projectsSummarizedData } = useAppSelector(getProjectsState);
//   const memoizedProjectsOptions = useMemo(() => {
//     return [
//       {
//         value: "",
//         label: "Select Project",
//       },
//       ...(projectsSummarizedData?.map((f) => ({
//         value: f.id,
//         label: f.name,
//       })) || []),
//     ];
//   }, [projectsSummarizedData]);

//   // useEffect(() => {
//   //   if ((projectsSummarizedData || [])?.length > 0) {
//   //     handleProjectChange("bf8f96cc-b8c6-41d6-b378-d27c649f275c")
//   //   }
//   // }, [projectsSummarizedData])

//   const { locationsList } = useAppSelector(getLocationsState);
//   const memoizedLocationOptions = useMemo(() => {
//     return [
//       {
//         value: "",
//         label: "Select Location",
//       },
//       ...(locationsList?.map((f) => ({
//         value: f.id,
//         label: f.name,
//       })) || []),
//     ];
//   }, [locationsList]);
//   const validationSchema = Yup.object().shape({
//     title: Yup.string().required("Title is required."),
//     transferDate: Yup.string().required("Transfer Date is required."),
//     originalLocationId: Yup.string().required("Original Location is required."),
//     destinationLocationId: Yup.string().required(
//       "Destination Location is required."
//     ),
//     materials: Yup.array().of(
//       Yup.object().shape({
//         subLocationName: Yup.string().required("Sublocation Name is required"),
//         name: Yup.string().required("Material Name is required"),
//         quantity: Yup.number()
//           .required("Quantity is required")
//           .test(
//             "quantity-match",
//             "Quantity must be equal to the sum of spares, samples, and regular",
//             function (value) {
//               const { spares, samples, regular } = this.parent;
//               const totalQuantity =
//                 (spares || 0) + (samples || 0) + (regular || 0);
//               return value === totalQuantity;
//             }
//           ),
//         unitOfMeasure: Yup.string().required("Unit of Measurement is required"),
//       })
//     ),
//   });

//   const initialValues = useMemo(
//     () => ({
//       title: materialTransfer?.title || "",
//       transferDate: materialTransfer?.transferDate || new Date(),
//       status: materialTransfer?.status || 0,
//       destinationSubLocationId:
//         materialTransfer?.destinationSubLocation?.id || "",
//       originalLocationId: materialTransfer?.originalLocation?.id || null,
//       destinationLocationId: materialTransfer?.destinationLocation?.id || null,
//       projectId: materialTransfer?.originalProject?.id || null,
//       materials: materialTransfer?.materials?.length
//         ? materialTransfer?.materials
//         : [
//             {
//               id: "",
//               name: "",
//               subLocationId: "",
//               subLocationName: "",
//               quantity: 0,
//               unitOfMeasure: "",
//               samples: 0,
//               spares: 0,
//               regular: 0,
//             },
//           ],
//     }),
//     [materialTransfer]
//   );

//   const formik = useFormik<MaterialTransfer>({
//     initialValues: initialValues,
//     validationSchema,
//     enableReinitialize: true,
//     onSubmit: async (values) => {
//       setHasMadeApiCall(true);
//       const payload = {
//         createdBy: userFullName,
//         ...values,
//       };
//       try {
//         formik.setSubmitting(true);
//         if (materialTransfer?.id) {
//           await dispatch(
//             editMaterialTransferById({ ...materialTransfer, ...payload })
//           );
//         } else {
//           await dispatch(createMaterialTransfer({ ...payload })).unwrap();
//         }
//       } catch (err) {
//         console.log(err);
//       } finally {
//         formik.setSubmitting(false);
//       }
//     },
//   });

//   // console.log("initial values")

//   const resetFormFields = () => {
//     // formik.setFieldValue("originalLocationId", "");
//     formik.setFieldValue("destinationLocationId", "");
//     formik.setFieldValue("destinationSubLocationId", "");
//     formik.setFieldValue("materials", [
//       {
//         id: "",
//         name: "",
//         subLocationId: "",
//         subLocationName: "",
//         quantity: 0,
//         unitOfMeasure: "",
//         sample: 0,
//         spares: 0,
//       },
//     ]);
//     setMaterialTableData([]);
//   };

//   const initialMaterials = [
//     {
//       id: "",
//       name: "",
//       subLocationId: "",
//       subLocationName: "",
//       quantity: 0,
//       unitOfMeasure: "",
//       sample: 0,
//       spares: 0,
//     },
//   ];

//   const handleProjectChange = (value: string | null) => {
//     formik.setFieldValue("projectId", value);
//     formik.setFieldValue("originalLocationId", "");
//     fetchLocationsList(value);
//     resetFormFields();
//     formik.setFieldValue("materials", initialMaterials);
//   };

//   useEffect(() => {
//     fetchLocationsList(materialTransfer?.originalProject?.id || "");
//     formik.setFieldValue("materials", initialMaterials);
//   }, [isEditMode]);

//   const fetchLocationsList = async (projectId: string | null) => {
//     try {
//       setIsLoadingProjectSelection(true);

//       await dispatch(getLocationslist(projectId || ""));
//     } catch (error) {
//       console.error("Failed to fetch locations list:", error);
//     } finally {
//       setIsLoadingProjectSelection(false);
//     }
//   };
//   useEffect(() => {
//     if (materialTransfer) {
//       if (materialTransfer.materials && materialTransfer.materials.length > 0) {
//         formik.setFieldValue("materials", materialTransfer.materials);
//         setMaterialTableData(materialTransfer.materials);
//       } else {
//         resetFormFields();
//       }
//     }
//   }, [materialTransfer]);

//   const handleLocationChange = async (originalLocationId: string | null) => {
//     formik.setFieldValue("originalLocationId", originalLocationId);
//     resetFormFields();
//     fetchMaterialTransferList(originalLocationId);
//   };

//   const fetchMaterialTransferList = async (
//     originalLocationId: string | null
//   ) => {
//     // if (!originalLocationId) return;
//     try {
//       setIsLoading(true);
//       const response = await dispatch(
//         getAllMaterialTransferlist(originalLocationId)
//       ).unwrap();
//       console.log("response----", response);

//       if (response.materials && response.materials.length > 0) {
//         setMaterialTableData(response.materials);
//         formik.setFieldValue("materials", response.materials);
//       } else {
//         setMaterialTableData([]);
//         resetFormFields();
//       }
//     } catch (error) {
//       console.error("Failed to fetch material transfer list:", error);
//     } finally {
//       setIsLoading(false);
//     }
//   };

//   const memoizedSubLocationOptions = useMemo(() => {
//     if (!formik.values.destinationLocationId) return [];
//     const selectedLocation = locationsList?.find(
//       (location) => location.id === formik.values.destinationLocationId
//     );

//     return [
//       {
//         value: "",
//         label: "Select Sublocation",
//       },
//       ...(selectedLocation?.subLocations?.map((subLocation) => ({
//         value: subLocation.id,
//         label: subLocation.name,
//       })) || []),
//     ];
//   }, [formik?.values.destinationLocationId, locationsList]);

//   async function handleDeleteMaterialTransferById() {
//     if (materialTransfer?.id) {
//       const res = await dispatch(
//         deleteMaterialTransferById(materialTransfer?.id)
//       ).unwrap();
//       if (res.isSuccess) {
//         navigate(routePathsWithParams.MATERIAL_TRANSFER);
//       }
//     }
//   }

//   return (
//     <>
//       <SectionLayout>
//         {isLoading || isLoadingProjectSelection ? (
//           <CustomOverlayLoader />
//         ) : (
//           <Form
//             onFinish={formik.handleSubmit}
//             layout="vertical"
//             autoComplete="off"
//             disabled={materialTransfer?.status === 2}
//           >
//             <CustomFormRow>
//               <Col xs={24} className="mb-4">
//                 <Typography.Title level={5}>
//                   New Material Transfer
//                 </Typography.Title>
//               </Col>

//               <Col xs={12}>
//                 <Form.Item<FieldType>
//                   label={<CustomFormLabel text="Title" />}
//                   labelAlign="right"
//                   initialValue={formik.values.title}
//                   required
//                   validateStatus={
//                     formik.touched.title && formik.errors.title ? "error" : ""
//                   }
//                   help={
//                     formik.touched.title && formik.errors.title
//                       ? formik.errors.title
//                       : ""
//                   }
//                 >
//                   <Input
//                     value={formik.values.title}
//                     onChange={(event) =>
//                       formik.setFieldValue("title", event?.target?.value || "")
//                     }
//                     size="large"
//                     placeholder="Title"
//                   />
//                 </Form.Item>
//               </Col>

//               <Col xs={12}>
//                 <Form.Item<FieldType>
//                   label={<CustomFormLabel text="Project" />}
//                   labelAlign="right"
//                   initialValue={formik.values.projectId}
//                   required
//                   validateStatus={
//                     formik.touched.projectId && formik.errors.projectId
//                       ? "error"
//                       : ""
//                   }
//                   help={
//                     formik.touched.projectId && formik.errors.projectId
//                       ? formik.errors.projectId
//                       : ""
//                   }
//                 >
//                   <Select
//                     value={formik.values.projectId}
//                     onChange={(value) => {
//                       handleProjectChange(value);
//                     }}
//                     size="large"
//                     placeholder="Select Project"
//                     options={memoizedProjectsOptions}
//                     showSearch
//                     allowClear
//                     filterOption={(input, option) =>
//                       (option?.label ?? "")
//                         .toLowerCase()
//                         .includes(input.toLowerCase())
//                     }
//                   />
//                 </Form.Item>
//               </Col>

//               <Col xs={12}>
//                 <Form.Item<FieldType>
//                   label={<CustomFormLabel text="Transfer Date" />}
//                   labelAlign="right"
//                   initialValue={formik.values.transferDate || null}
//                   required
//                   validateStatus={
//                     formik.touched.transferDate && formik.errors.transferDate
//                       ? "error"
//                       : ""
//                   }
//                   help={
//                     formik.touched.transferDate && formik.errors.transferDate
//                       ? formik.errors.transferDate
//                       : ""
//                   }
//                 >
//                   <DatePicker
//                     value={dayjs(formik.values.transferDate || new Date())}
//                     // value={formik.values.transferDate || null}
//                     onChange={(date) =>
//                       formik.setFieldValue("transferDate", date)
//                     }
//                     size="large"
//                     style={{ width: "100%" }}
//                     placeholder="MM/DD/YYYY"
//                     format={dateFormat}
//                   />
//                 </Form.Item>
//               </Col>

//               <Col xs={12}>
//                 <Form.Item<FieldType>
//                   label={<CustomFormLabel text="Original Location" />}
//                   labelAlign="right"
//                   initialValue={formik.values.originalLocationId}
//                   required
//                   validateStatus={
//                     formik.touched.originalLocationId &&
//                     formik.errors.originalLocationId
//                       ? "error"
//                       : ""
//                   }
//                   help={
//                     formik.touched.originalLocationId &&
//                     formik.errors.originalLocationId
//                       ? formik.errors.originalLocationId
//                       : ""
//                   }
//                 >
//                   <Select
//                     value={formik.values.originalLocationId || undefined}
//                     onChange={handleLocationChange}
//                     // onChange={(value) => {
//                     //   formik.setFieldValue("originalLocationId", value || "")
//                     // }
//                     // }
//                     size="large"
//                     placeholder="Select Location"
//                     options={memoizedLocationOptions}
//                     showSearch
//                     disabled={
//                       !formik?.values?.projectId ||
//                       materialTransfer?.status === 2
//                     }
//                     allowClear
//                     filterOption={(input, option) =>
//                       (option?.label ?? "")
//                         .toLowerCase()
//                         .includes(input.toLowerCase())
//                     }
//                   />
//                 </Form.Item>
//               </Col>

//               <Col xs={12}>
//                 <Form.Item<FieldType>
//                   label={<CustomFormLabel text="Delivering To" />}
//                   labelAlign="right"
//                   initialValue={formik.values.destinationLocationId}
//                   required
//                   validateStatus={
//                     formik.touched.destinationLocationId &&
//                     formik.errors.destinationLocationId
//                       ? "error"
//                       : ""
//                   }
//                   help={
//                     formik.touched.destinationLocationId &&
//                     formik.errors.destinationLocationId
//                       ? formik.errors.destinationLocationId
//                       : ""
//                   }
//                 >
//                   <Select
//                     value={formik.values.destinationLocationId || undefined}
//                     onChange={(value) => {
//                       formik.setFieldValue(
//                         "destinationLocationId",
//                         value || ""
//                       );
//                       formik.setFieldValue("destinationSubLocationId", "");
//                     }}
//                     size="large"
//                     placeholder="Select Location"
//                     options={memoizedLocationOptions.filter(
//                       (f) =>
//                         f.value === "" ||
//                         f.value !== formik.values.originalLocationId
//                     )}
//                     showSearch
//                     disabled={
//                       !formik?.values?.originalLocationId ||
//                       materialTransfer?.status === 2
//                     }
//                     allowClear
//                     filterOption={(input, option) =>
//                       (option?.label ?? "")
//                         .toLowerCase()
//                         .includes(input.toLowerCase())
//                     }
//                     // onSearch={onSearch}
//                   />
//                 </Form.Item>
//               </Col>

//               <Col xs={12}>
//                 <Form.Item<FieldType>
//                   label={<CustomFormLabel text="Destination Sublocation" />}
//                   labelAlign="right"
//                   initialValue={formik.values.destinationSubLocationId}
//                 >
//                   <Select
//                     value={formik.values.destinationSubLocationId || undefined}
//                     onChange={(value) =>
//                       formik.setFieldValue(
//                         "destinationSubLocationId",
//                         value || ""
//                       )
//                     }
//                     size="large"
//                     placeholder="Select Sublocation"
//                     options={memoizedSubLocationOptions}
//                     showSearch
//                     disabled={
//                       !formik?.values?.destinationLocationId ||
//                       materialTransfer?.status === 2
//                     }
//                     allowClear
//                     filterOption={(input, option) =>
//                       (option?.label ?? "")
//                         .toLowerCase()
//                         .includes(input.toLowerCase())
//                     }
//                   />
//                 </Form.Item>
//               </Col>

//               <Col xs={12}>
//                 <Form.Item<FieldType>
//                   label={<CustomFormLabel text="Status" />}
//                   labelAlign="right"
//                   initialValue={formik.values.status}
//                 >
//                   <Select
//                     value={formik.values.status}
//                     onChange={(value) => formik.setFieldValue("status", value)}
//                     size="large"
//                     options={[
//                       { value: "", label: "Select Status" },
//                       ...materialTransferStatusOptions,
//                     ]}
//                     showSearch
//                     filterOption={(input, option) =>
//                       (option?.label ?? "")
//                         .toLowerCase()
//                         .includes(input.toLowerCase())
//                     }
//                   />
//                 </Form.Item>
//               </Col>
//             </CustomFormRow>
//             <Divider />
//             <Typography.Title level={5}>Materials</Typography.Title>
//             <div className="!mb-6">
//               {materialTableData && (
//                 <AddMaterialDetailsForm
//                   formik={formik}
//                   data={materialTableData}
//                 />
//               )}
//             </div>
//             {hasMadeApiCall && (resError || successMessage) && (
//               <CustomAlert
//                 message={resError || successMessage || ""}
//                 type={successMessage ? "success" : "error"}
//               />
//             )}
//             {materialTransfer?.status != 2 ? (
//               <Flex justify="flex-end" className="gap-4">
//                 <CustomFormButtons
//                   resetStateisSuccess={resetStateisSuccess}
//                   isSuccess={isSuccess}
//                   isEditMode={Boolean(materialTransfer)}
//                   hasValidationErrors={
//                     Object.values(formik.errors)?.length > 0 &&
//                     Object.values(formik.touched)?.length > 0
//                   }
//                   navigationRoute={routePathsWithParams.MATERIAL_TRANSFER}
//                   handleSubmit={formik.handleSubmit}
//                   handleDelete={handleDeleteMaterialTransferById}
//                   handleCancel={handleCancelForm}
//                   hasHttpErrors={Boolean(resError || reqError)}
//                 />
//               </Flex>
//             ) : null}
//             {materialTransfer?.id && (
//               <Flex justify="flex-end">
//                 <CreatedByUserBadge
//                   userName={materialTransfer?.createdBy}
//                   date={materialTransfer?.createdDate}
//                 />
//               </Flex>
//             )}
//           </Form>
//         )}
//       </SectionLayout>
//     </>
//   );
// }
