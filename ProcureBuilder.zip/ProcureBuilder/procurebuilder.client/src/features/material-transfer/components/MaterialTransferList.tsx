import { getAllMaterialTransfer } from "@/src/apis/materialTransferApis";
import { getSummarizedProjectsList } from "@/src/apis/projectApis";
import HighlightedText from "@/src/components/common/HighlightedText";
import MaterialTransferStatus from "@/src/components/common/MaterialTransferStatus";
import CustomTable, {
  defaultPageSizes,
} from "@/src/components/table/CustomTable";
import CustomTableFilters, {
  CustomFilterDataType,
  CustomFiltersType,
} from "@/src/components/table/CustomTableFilters";
import { useAppDispatch } from "@/src/hooks/useAppDispatch";
import { useDebouncedCallback } from "@/src/hooks/useDebouncedCallback";
import { getMaterialTransferState } from "@/src/store/slices/materialTransferSlice";
import { getProjectsState } from "@/src/store/slices/projectsSlice";
import {
  allMaterialTransferStatusOption,
  allProjectsOptions,
  dateFormat,
  materialTransferStatusOptionsWithAll,
} from "@/src/utils/constants";
import { getMaterialTransferStatus } from "@/src/utils/helper";
import { getFirstValidNumber } from "@/src/utils/number-extensions";
import routePaths from "@/src/utils/routePaths";
import { MaterialTransfer } from "@/src/utils/types";
import CustomIcon from "@components/common/CustomIcon";
import SectionLayout from "@components/layout/SectionLayout";
import { useAppSelector } from "@hooks/useAppSelector";
import { getConsistentSpacing } from "@utils/theme-helpers";
import { Button, TableProps, Typography } from "antd";
import dayjs from "dayjs";
import { useEffect, useMemo, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useReports } from "../../reports/contexts/ReportsProvider";
import useSyncFilters from "@/src/hooks/useSyncFilters";

type MaterialTransferListProps = {
  materials?: MaterialTransfer[] | null;
  hasPagination?: boolean;
  hasDetailedColumns?: boolean;
  hasSearch?: boolean;
  hasFilters?: boolean;
  hasBorders?: boolean;

  setReportStats?: null | React.Dispatch<
    React.SetStateAction<{
      totalTransfers: number;
      totalCancelled: number;
      totalInProgress: number;
      totalPending: number;
      totalTransferred: number;
    }>
  >;
  exportButtonEl?: React.ReactNode | null;
};
export default function MaterialTransferList({
  hasPagination = true,
  hasSearch = true,
  hasFilters = true,
  hasBorders = true,
  setReportStats = null,
  exportButtonEl = null,
}: MaterialTransferListProps) {
  const { filterValues } = useReports();

  const isInsideReports = useMemo(
    () => Boolean(exportButtonEl),
    [exportButtonEl]
  );
  const dispatch = useAppDispatch();
  const navigate = useNavigate();

  const isFirstCallComplete = useRef(false);
  // const [isFirstCall, setIsFirstCall] = useState(false);
  const {
    materialTransferData,
    isLoading,
    totalCount,
    currentPage: materialTransferCurrentPage,
    pageSize: materialTransferPageSize,
  } = useAppSelector(getMaterialTransferState);
  const { projectsSummarizedData } = useAppSelector(getProjectsState);
  const [page, setPage] = useState<number>(materialTransferCurrentPage);
  const [pageSize, setPageSize] = useState(
    !isInsideReports && !defaultPageSizes.includes(materialTransferPageSize)
      ? 10
      : materialTransferPageSize
  );
  const [searchTerm, setSearchTerm] = useState("");
  const [hasSearched, setHasSearched] = useState(false);
  const { searchParams } = useSyncFilters();
  const [previousSearchTerm, setPreviousSearchTerm] = useState(
    searchParams.get("searchTerm")
  );
  const [lastSearchTimestamp, setLastSearchTimestamp] = useState(0);

  useEffect(() => {
    setLastSearchTimestamp(Date.now());
  }, [previousSearchTerm]);

  useEffect(() => {
    dispatch(getSummarizedProjectsList());
  }, [page, pageSize]);

  const memoizedProjectsOptions = useMemo(() => {
    return [
      allProjectsOptions,
      ...(projectsSummarizedData?.map((f) => ({
        value: f.id,
        label: f.name,
      })) || []),
    ];
  }, [projectsSummarizedData]);

  const [filters, setFilters] = useState<CustomFiltersType>({
    status: {
      value: allMaterialTransferStatusOption?.value || 0,
      options: materialTransferStatusOptionsWithAll,
      className: "!min-w-[131px]",
      dataType: CustomFilterDataType.NUM,
    },
    projectId: {
      value: memoizedProjectsOptions[0]?.value || "",
      options: memoizedProjectsOptions,
      dataType: CustomFilterDataType.STR,
    },
  });

  const [buttonsFilterStatus, setButtonsFilterStatus] = useState({
    isDueToday: false,
    isOverDue: false,
    isUpComing: false,
  });
  const [buttonActive, setButtonActive] = useState({
    isDueTodayActive: false,
    isOverDueActive: false,
    isUpComingActive: false,
  });

  function updateDueTimeButtons(value: string) {
    switch (value) {
      case "dueToday":
        setButtonsFilterStatus((prev) => ({
          ...prev,
          isDueToday: !prev.isDueToday,
          isOverDue: false,
          isUpComing: false,
        }));
        setButtonActive((prev) => ({
          ...prev,
          isDueTodayActive: !prev.isDueTodayActive,
          isOverDueActive: false,
          isUpComingActive: false,
        }));
        break;
      case "overDue":
        setButtonsFilterStatus((prev) => ({
          ...prev,
          isDueToday: false,
          isOverDue: !prev.isOverDue,
          isUpComing: false,
        }));
        setButtonActive((prev) => ({
          ...prev,
          isDueTodayActive: false,
          isOverDueActive: !prev.isOverDueActive,
          isUpComingActive: false,
        }));
        break;
      case "upComing":
        setButtonsFilterStatus((prev) => ({
          ...prev,
          isDueToday: false,
          isOverDue: false,
          isUpComing: !prev.isUpComing,
        }));
        setButtonActive((prev) => ({
          ...prev,
          isDueTodayActive: false,
          isOverDueActive: false,
          isUpComingActive: !prev.isUpComingActive,
        }));
    }
  }

  const filterButtons = [
    {
      label: "Due Today",
      value: "dueToday",
      isActive: buttonActive.isDueTodayActive,
      onClick: updateDueTimeButtons,
    },
    {
      label: "Overdue",
      value: "overDue",
      isActive: buttonActive.isOverDueActive,
      onClick: updateDueTimeButtons,
    },
    {
      label: "Upcoming",
      value: "upComing",
      isActive: buttonActive.isUpComingActive,
      onClick: updateDueTimeButtons,
    },
  ];

  useEffect(() => {
    // Only update filters if the options actually change
    setFilters((prevFilters) => {
      const currentOptions = prevFilters.projectId.options;
      const newOptions = memoizedProjectsOptions;

      // Check if options are different (by comparing their length or individual items)
      const optionsChanged =
        currentOptions.length !== newOptions.length ||
        currentOptions.some(
          (option, index) => option.value !== newOptions[index]?.value
        );

      // If options are the same, return the previous filters to avoid unnecessary state update
      if (!optionsChanged) {
        return prevFilters;
      }

      // If options have changed, update the filters
      return {
        ...prevFilters,
        projectId: {
          ...prevFilters.projectId,
          options: newOptions,
        },
      };
    });
  }, [memoizedProjectsOptions]);

  useEffect(() => {
    resetPaginationAndGetFirstPageResults();
  }, [filters, buttonsFilterStatus, filterValues]);

  const navigateToEditPage = (mt: MaterialTransfer) => {
    const path = `${routePaths.MATERIAL_TRANSFER_EDIT_BY_ID}/${mt?.id}`;

    if (isInsideReports || new URLSearchParams(location.search).size > 0) {
      navigate(path, {
        state: {
          previousPath: `${location.pathname}${location.search}`,
        },
      });
    } else {
      navigate(path);
    }
  };

  const columns: TableProps<MaterialTransfer>["columns"] = [
    {
      title: "Title",
      dataIndex: "title",
      key: "title",
      sorter: (a, b) => a.title.localeCompare(b.title),
      render: (title) => (
        <Typography.Title
          level={5}
          style={{ fontSize: getConsistentSpacing(1.75), margin: 0 }}
        >
          <HighlightedText text={title} searchTerm={searchTerm} />
        </Typography.Title>
      ),
    },
    {
      title: "Project",
      dataIndex: ["originalProject", "name"],
      key: "originalProject",
      sorter: (a, b) => {
        const nameA = a.originalProject?.name || "";
        const nameB = b.originalProject?.name || "";
        return nameA.localeCompare(nameB);
      },
      render: (projectName) => (
        <HighlightedText text={projectName} searchTerm={searchTerm} />
      ),
    },
    {
      title: "Original Location",
      dataIndex: ["originalLocation", "name"],
      key: "originalLocation",
      sorter: (a, b) => {
        const nameA = a.originalLocation?.name || "";
        const nameB = b.originalLocation?.name || "";
        return nameA.localeCompare(nameB);
      },
      render: (originalLocation) => (
        <HighlightedText text={originalLocation} searchTerm={searchTerm} />
      ),
    },
    {
      title: "Delivering To",
      dataIndex: ["destinationLocation", "name"],
      key: "destinationLocation",
      sorter: (a, b) => {
        const nameA = a.destinationLocation?.name || "";
        const nameB = b.destinationLocation?.name || "";
        return nameA.localeCompare(nameB);
      },
      render: (destinationLocation) => (
        <HighlightedText text={destinationLocation} searchTerm={searchTerm} />
      ),
    },
    {
      title: "Destination Sublocation",
      dataIndex: ["destinationSubLocation", "name"],
      key: "destinationSubLocation",
      sorter: (a, b) => {
        const nameA = a.destinationSubLocation?.name || "";
        const nameB = b.destinationSubLocation?.name || "";
        return nameA.localeCompare(nameB);
      },
      render: (destinationSubLocation) => (
        <HighlightedText
          text={destinationSubLocation}
          searchTerm={searchTerm}
        />
      ),
    },
    {
      title: "Transfer Date",
      dataIndex: "transferDate",
      key: "transferDate",
      sorter: (a, b) =>
        dayjs(a.transferDate).unix() - dayjs(b.transferDate).unix(),
      render: (transferDate) => (
        <HighlightedText
          text={dayjs(transferDate).format(dateFormat)}
          searchTerm={searchTerm}
        />
      ),
    },
    {
      title: "Status",
      dataIndex: "status",
      key: "status",
      render: (status) => {
        const { badgeType } = getMaterialTransferStatus(status);
        return <MaterialTransferStatus badgeType={badgeType} />;
      },
    },
    {
      title: "",
      key: "actions",
      render: (record) =>
        !isInsideReports && (
          <Button
            shape="circle"
            className="hover:!fill-primary"
            icon={<CustomIcon type="edit" />}
            onClick={() => navigateToEditPage(record)}
          />
        ),
    },
  ];

  const handleGetResults = useDebouncedCallback(getResults, 100);

  async function getResults(pageNumber?: number) {
    const status =
      filters.status?.value !== allMaterialTransferStatusOption?.value
        ? (filters?.status?.value as number)
        : undefined;

    const projectId =
      filters.projectId?.value !== memoizedProjectsOptions[0]?.value
        ? filters?.projectId?.value?.toString()
        : undefined;

    const isDueToday = buttonsFilterStatus.isDueToday
      ? buttonsFilterStatus.isDueToday.toString()
      : undefined;

    const isOverDue = buttonsFilterStatus.isOverDue
      ? buttonsFilterStatus.isOverDue.toString()
      : undefined;

    const isUpComing = buttonsFilterStatus.isUpComing
      ? buttonsFilterStatus.isUpComing.toString()
      : undefined;

    const reportFilters = isInsideReports ? filterValues : {};

    const res = await dispatch(
      getAllMaterialTransfer({
        isForReport: isInsideReports,
        pageNumber: pageNumber || page,
        pageSize,
        isDueToday,
        isUpComing,
        isOverDue,
        search: searchTerm || undefined,
        projectId: reportFilters?.projectId || projectId,
        status: getFirstValidNumber(reportFilters?.status, status),
        materialType: getFirstValidNumber(
          reportFilters?.materialType,
          undefined
        ),
        originalLocationId: reportFilters?.originalLocationId || undefined,
        destinationLocationId:
          reportFilters?.destinationLocationId || undefined,
        transferDateFrom: reportFilters?.transferDate?.[0] || undefined,
        transferDateTo: reportFilters?.transferDate?.[1] || undefined,
      })
    ).unwrap();

    if (typeof setReportStats === "function") {
      setReportStats({
        totalTransfers: res?.totalCount || 0,
        totalCancelled: res?.totalCancelled || 0,
        totalInProgress: res?.totalInProgress || 0,
        totalPending: res?.totalPending || 0,
        totalTransferred: res?.totalTransferred || 0,
      });
    }
  }

  function resetPaginationAndGetFirstPageResults(newPageNumber?: number) {
    if (newPageNumber) {
      setPageSize(() => newPageNumber);
    }
    if (isFirstCallComplete?.current === true) {
      if (filters) {
        setPage(1);
      }

      handleGetResults(1);
    } else {
      handleGetResults();
    }
  }

  useEffect(() => {
    if (!hasSearched) return;
    const timer = setTimeout(() => {
      if (searchTerm === "" && previousSearchTerm !== "") {
        resetPaginationAndGetFirstPageResults();
        setPreviousSearchTerm(searchTerm);
      }
    }, 500);

    return () => {
      clearTimeout(timer);
    };
  }, [searchTerm, hasSearched, previousSearchTerm]);

  const handleSearch = () => {
    if (searchTerm !== previousSearchTerm) {
      setHasSearched(true);
      resetPaginationAndGetFirstPageResults();
      setPreviousSearchTerm(searchTerm);
    }
  };

  useEffect(() => {
    if (
      !isFirstCallComplete?.current ||
      materialTransferCurrentPage !== page ||
      materialTransferPageSize !== pageSize
    ) {
      handleGetResults();

      if (!isFirstCallComplete?.current) {
        setTimeout(() => {
          isFirstCallComplete.current = true;
        }, 1000);
      }
    }
  }, [page, pageSize]);

  return (
    <>
      <SectionLayout isHidden={isInsideReports || !hasBorders}>
        <CustomTable
          data={materialTransferData || []}
          columns={columns || []}
          searchTerm={searchTerm}
          setSearchTerm={setSearchTerm}
          handleSearch={handleSearch}
          isLoading={isLoading}
          totalCount={totalCount}
          page={page}
          setPage={setPage}
          pageSize={pageSize}
          setPageSize={setPageSize}
          filterElements={
            !isInsideReports && hasFilters ? (
              <CustomTableFilters
                filters={filters}
                setFilters={setFilters}
                buttons={filterButtons}
              />
            ) : null
          }
          hasPagination={hasPagination}
          hasSearch={hasSearch}
          exportButtonEl={exportButtonEl}
          isInsideReports={isInsideReports}
          hasCursorPointer={isInsideReports}
          onRowClick={
            isInsideReports ? (co) => navigateToEditPage(co) : undefined
          }
          tableFilters={filters}
          reportFilterForParamsUseOnly={
            isInsideReports ? filterValues : undefined
          }
          setTableFilters={!isInsideReports ? setFilters : undefined}
          lastSearchTimestamp={lastSearchTimestamp}
          dueTimeButtons={filterButtons?.map((m) => ({
            ...m,
            isActive:
              m.value === "dueToday"
                ? buttonActive.isDueTodayActive
                : m.value === "overDue"
                ? buttonActive.isOverDueActive
                : buttonActive.isUpComingActive,
          }))}
          updateDueTimeButtons={updateDueTimeButtons}
        />
      </SectionLayout>
    </>
  );
}
