import { getLocationslist as getLocationsList } from "@/src/apis/locationApis";
import {
  createMaterialTransfer,
  deleteMaterialTransferById,
  editMaterialTransferById,
  getAllMaterialTransferlist,
} from "@/src/apis/materialTransferApis";
import { getSummarizedProjectsList } from "@/src/apis/projectApis";
import CreatedByUserBadge from "@/src/components/common/CreatedByUserBadge";
import CustomAlert from "@/src/components/common/CustomAlert";
import CustomOverlayLoader from "@/src/components/common/CustomOverlayloader";
import CustomFormRow from "@/src/components/form/CustomFormRow";
import { useAppDispatch } from "@/src/hooks/useAppDispatch";
import { getLocationsState } from "@/src/store/slices/locationSlice";
import { getMaterialTransferState } from "@/src/store/slices/materialTransferSlice";
import { getProjectsState } from "@/src/store/slices/projectsSlice";
import { getUserFullName } from "@/src/store/slices/userSlice";
import { ActionTypeEnum, MaterialTransferStatusEnum } from "@/src/utils/enums";
import routePaths, { routePathsWithParams } from "@/src/utils/routePaths";
import {
  ActionTypeState,
  MaterialTransfer,
  MaterialTransferAddMaterial,
  PurchaseOrdersList,
} from "@/src/utils/types";
import { updateMaterials } from "@/src/utils/update-materials";
import { PlusOutlined } from "@ant-design/icons";
import CustomFormLabel from "@components/common/CustomFormLabel";
import SectionLayout from "@components/layout/SectionLayout";
import { yupResolver } from "@hookform/resolvers/yup";
import { useAppSelector } from "@hooks/useAppSelector";
import { dateFormat, materialTransferStatusOptions } from "@utils/constants";
import {
  Button,
  Col,
  DatePicker,
  Divider,
  Flex,
  Form,
  Input,
  Select,
  Space,
  Typography,
} from "antd";
import dayjs from "dayjs";
import { useEffect, useMemo, useState } from "react";
import { Controller, Resolver, useForm } from "react-hook-form";
import { useLocation, useNavigate } from "react-router-dom";
// import AddMaterialDetailsFormRHF from "./AddMaterialTransferDetailsFormRHF";
import { getPurchaseOrdersList } from "@/src/apis/purchaseOrderApis";
import { getAllStorageTypes } from "@/src/apis/storageTypeApis";
import LocationModal from "@/src/features/locations/components/LocationModal";
import AddMaterialDetailsFormRHF2 from "./AddMaterialTransferDetailsFormRHF2";
import { validationSchema } from "./MaterialTransferValidationSchema";

type MaterialDetailsFormProps = {
  materialTransfer: MaterialTransfer | null;
  projectLocationId?: string;
  handleCancelForm?: () => void;
};

type SubLocation = {
  subLocationId: string;
  subLocationName: string;
  materials: MaterialTransferAddMaterial[];
};

type LocationData = SubLocation[];

const initialsMaterialsValues = Array.from({ length: 5 }, () => ({
  id: "",
  name: "",
  subLocationId: "",
  subLocationName: "",
  quantity: 0,
  unitOfMeasure: "",
  samples: 0,
  spares: 0,
  regular: 0,
}));

export default function MaterialTransferDetailsFormRFH({
  materialTransfer,
}: MaterialDetailsFormProps) {
  const userFullName = useAppSelector(getUserFullName);
  const dispatch = useAppDispatch();
  const location = useLocation();
  const [isLocationModalOpen, setIsLocationModalOpen] = useState<{
    open: boolean;
    title?: string | null;
    field?: string;
  }>({ open: false, title: null, field: "" });
  const { reqError, resError, successMessage } = useAppSelector(
    getMaterialTransferState
  );
  const { locationsList } = useAppSelector(getLocationsState);
  const [tableData, setTableData] = useState<LocationData>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isLoadingProjectSelection, setIsLoadingProjectSelection] =
    useState(false);
  const [actionType, setActionType] = useState<ActionTypeState>({
    delete: ActionTypeEnum.NEUTRAL,
    downloadPdf: ActionTypeEnum.NEUTRAL,
    save: ActionTypeEnum.NEUTRAL,
    saveAndNew: ActionTypeEnum.NEUTRAL,
    saveAndClose: ActionTypeEnum.SAVE_AND_CLOSE,
    cancel: ActionTypeEnum.SAVE,
  });
  const { projectsSummarizedData } = useAppSelector(getProjectsState);
  const [purchaseOrdersList, setPurchaseOrdersList] =
    useState<PurchaseOrdersList[]>();

  const navigate = useNavigate();

  type FieldType = MaterialTransfer[];

  const getMaterialTransferFormData = (
    materialTransfer: MaterialTransfer | null
  ) => {
    return {
      title: materialTransfer?.title || "",
      transferDate: materialTransfer?.transferDate || new Date(),
      status: materialTransfer?.status || 0,
      destinationSubLocationId:
        materialTransfer?.destinationSubLocation?.id || "",
      originalLocationId: materialTransfer?.originalLocation?.id || null,
      destinationLocationId: materialTransfer?.destinationLocation?.id || null,
      projectId: materialTransfer?.originalProject?.id || null,
      purchaseOrderIds:
        materialTransfer?.purchaseOrders?.map((v) => v.id) || [],
      materials:
        materialTransfer && materialTransfer?.materials?.length > 0
          ? materialTransfer?.materials
          : [],
    };
  };

  useEffect(() => {
    dispatch(getSummarizedProjectsList());
  }, [dispatch]);
  useEffect(() => {
    setTableData([]);
  }, [location.pathname]);

  const memoizedProjectsOptions = useMemo(() => {
    return [
      {
        value: "",
        label: "Select Project",
      },
      ...(projectsSummarizedData?.map((f) => ({
        value: f.id,
        label: f.name,
      })) || []),
    ];
  }, [projectsSummarizedData]);

  const memoizedLocationOptions = useMemo(() => {
    return [
      {
        value: "",
        label: "Select Location",
      },
      ...(locationsList?.map((f) => ({
        value: f.id,
        label: f.name,
      })) || []),
    ];
  }, [locationsList]);

  const memoizedPurchaseOrderOption = useMemo(() => {
    return [
      {
        value: "",
        label: "Select Project",
      },
      ...(purchaseOrdersList?.map((f) => ({
        value: f.id,
        label: f.purchaseOrderNumber,
      })) || []),
    ];
  }, [purchaseOrdersList]);

  const {
    watch,
    handleSubmit,
    control,
    getValues,
    setValue,
    reset,

    formState: { isSubmitting },
  } = useForm<MaterialTransfer>({
    defaultValues: getMaterialTransferFormData(materialTransfer),
    resolver: yupResolver(
      validationSchema
    ) as unknown as Resolver<MaterialTransfer>,
  });

  const onSubmit = async (values: MaterialTransfer) => {
    // setIsEditMode(false);
    if (actionType.save === ActionTypeEnum.SAVE) {
      const res = await handleSave(values);
      if (res?.isSuccess) {
        navigate(
          `${routePaths.MATERIAL_TRANSFER_EDIT_BY_ID}/${res.materialTransfer?.id}`
        );
      }
    } else if (actionType.saveAndClose === ActionTypeEnum.SAVE_AND_CLOSE) {
      const res = await handleSave(values);
      if (res?.isSuccess) {
        handleClose();
      }
    }
  };

  const handleSave = async (values: MaterialTransfer) => {
    const payload = {
      createdBy: userFullName,
      ...values,
      transferDate: dayjs(values?.transferDate).toISOString(),
      destinationSubLocationId: values?.destinationSubLocationId || null,
    };

    try {
      if (materialTransfer?.id) {
        const data = {
          ...payload,
          materials: payload?.materials?.map((mte) => ({
            ...mte,
            id:
              mte.id ||
              (tableData?.length > 0 &&
                tableData
                  .find((tbD) => tbD?.subLocationId === mte?.subLocationId)
                  ?.materials?.find((m) => m?.name === mte.name)?.id) ||
              "",
          })),
        };
        return dispatch(
          editMaterialTransferById({
            ...data,
            materialTransferId: materialTransfer?.id,
          })
        ).unwrap();
      } else {
        const data = {
          ...payload,
          materials: payload.materials?.map((mte) => ({
            ...mte,
            id:
              (tableData.length > 0 &&
                tableData
                  .find((tbD) => tbD?.subLocationId === mte?.subLocationId)
                  ?.materials?.find((m) => m?.name === mte.name)?.id) ||
              "",
          })),
        };
        return dispatch(createMaterialTransfer({ ...data })).unwrap();
      }
    } catch (err) {
      console.log(err);
    }
  };

  const getPurchaseOrderbyProjectId = async (value: string | null) => {
    try {
      const response = await dispatch(
        getPurchaseOrdersList({ projectId: value || "" })
      ).unwrap();
      setPurchaseOrdersList(response?.purchaseOrders);
    } catch (err) {
      console.log("err", err);
    }
  };

  const handleProjectChange = (value: string | null) => {
    setValue("projectId", value);
    setValue("originalLocationId", "");
    setValue("destinationLocationId", "");
    setValue("destinationSubLocationId", "");
    setTableData([]);
    getPurchaseOrderbyProjectId(value);
    if (materialTransfer?.id) {
      // setIsEditMode(true);
    }
    setValue("materials", initialsMaterialsValues);
    fetchLocationsList(value);
  };

  useEffect(() => {
    if (materialTransfer?.id) {
      dispatch(getLocationsList(materialTransfer?.originalProject?.id || ""));
      // fetchMaterialTransferList(materialTransfer?.originalLocationId);
      getPurchaseOrderbyProjectId(materialTransfer?.projectId || "");
      dispatch(
        getAllMaterialTransferlist({
          projectLocationId: materialTransfer?.originalLocation?.id || "",
          purchaseOrderIds: materialTransfer?.purchaseOrderIds || [],
        })
      )
        .unwrap()
        .then((data) => {
          if (data?.isSuccess) {
            const updateTableData = updateMaterials(
              data?.inventory,
              materialTransfer?.materials || []
            ) as LocationData;
            setTableData(() => [...updateTableData]);
          }
        });
    }
  }, [materialTransfer]);

  useEffect(() => {
    if (materialTransfer) {
      reset(getMaterialTransferFormData(materialTransfer));
    } else if (location.pathname === routePaths.MATERIAL_TRANSFER_NEW) {
      reset({
        title: "",
        transferDate: new Date(),
        status: 0,
        destinationSubLocationId: "",
        originalLocationId: null,
        destinationLocationId: null,
        projectId: null,
        materials: initialsMaterialsValues,
      });
    }
  }, [location.pathname, materialTransfer]);

  const fetchLocationsList = async (projectId: string | null) => {
    try {
      setIsLoadingProjectSelection(true);
      await dispatch(getLocationsList(projectId || ""));
    } catch (error) {
      console.error("Failed to fetch locations list:", error);
    } finally {
      setIsLoadingProjectSelection(false);
    }
  };

  const handleLocationChange = async (originalLocationId: string | null) => {
    setValue("originalLocationId", originalLocationId);
    setValue("destinationLocationId", null);

    setValue("destinationSubLocationId", "");

    setValue("materials", initialsMaterialsValues);
    await fetchMaterialTransferList(originalLocationId);
  };

  const fetchMaterialTransferList = async (
    originalLocationId: string | null
  ) => {
    const payload = {
      projectLocationId: originalLocationId || "",
      purchaseOrderIds: getValues("purchaseOrderIds") || [],
    };
    try {
      setIsLoading(true);
      const response = await dispatch(
        getAllMaterialTransferlist(payload)
      ).unwrap();

      if (response?.inventory && response?.inventory?.length > 0) {
        setTableData(response?.inventory as []);
      } else {
        setTableData([]);
      }
    } catch (error) {
      console.error("Failed to fetch material transfer list:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const memoizedSubLocationOptions = useMemo(() => {
    if (!getValues("destinationLocationId")) return [];
    const selectedLocation = locationsList?.find(
      (location) => location.id === getValues("destinationLocationId")
    );

    return [
      {
        value: "",
        label: "Select Sublocation",
      },
      ...(selectedLocation?.subLocations?.map((subLocation) => ({
        value: subLocation.id,
        label: subLocation.name,
      })) || []),
    ];
  }, [watch("destinationLocationId"), locationsList]);

  const handleDeleteMaterialTransferById = async () => {
    setActionType({ delete: ActionTypeEnum.DELETE });
    if (materialTransfer?.id) {
      const res = await dispatch(
        deleteMaterialTransferById(materialTransfer?.id)
      ).unwrap();
      if (res.isSuccess) {
        setActionType({ delete: ActionTypeEnum.NEUTRAL });
        handleClose();
        // navigate(routePathsWithParams.MATERIAL_TRANSFER);
      }
    }
    setActionType({ delete: ActionTypeEnum.NEUTRAL });
  };

  const handleClose = () => {
    const previousPath = location?.state?.previousPath || "";
    if (previousPath) {
      navigate(previousPath);
    } else {
      navigate(routePathsWithParams.MATERIAL_TRANSFER);
    }
  };

  useEffect(() => {
    if (isLocationModalOpen?.open) {
      dispatch(getAllStorageTypes());
    } else {
      dispatch(getLocationsList(getValues("projectId") || ""));
    }
  }, [dispatch, isLocationModalOpen?.open]);

  const handleOpenLocationModal = (title: string, field: string) => {
    setIsLocationModalOpen({
      title: title,
      open: true,
      field: field,
    });
  };

  return (
    <>
      <LocationModal
        projectId={getValues("projectId")}
        isLocationModalOpen={isLocationModalOpen}
        setIsLocationModalOpen={setIsLocationModalOpen}
        setLocationValue={setValue}
      />
      <SectionLayout>
        {isLoading || isLoadingProjectSelection ? (
          <CustomOverlayLoader />
        ) : (
          <Form
            onFinish={handleSubmit(onSubmit)}
            layout="vertical"
            autoComplete="off"
            disabled={
              materialTransfer?.status ===
              MaterialTransferStatusEnum.TRANSFERRED
            }
          >
            <CustomFormRow>
              <Col xs={24} className="mb-4">
                <Typography.Title level={5}>
                  {materialTransfer ? "Edit" : "New"} Material Transfer
                </Typography.Title>
              </Col>

              <Col xs={12}>
                <Controller
                  name="title"
                  control={control}
                  render={({ field, formState: { errors } }) => {
                    const error = errors.title;
                    return (
                      <Form.Item<FieldType>
                        label={<CustomFormLabel text="Title" required />}
                        labelAlign="right"
                        initialValue={field.value}
                        validateStatus={!field.value && error ? "error" : ""}
                        help={!field.value && error ? error.message : ""}
                      >
                        <Input {...field} size="large" placeholder="Title" />
                      </Form.Item>
                    );
                  }}
                />
              </Col>

              <Col xs={12}>
                <Controller
                  name="projectId"
                  control={control}
                  render={({ field, formState: { errors } }) => {
                    const error = errors.projectId;
                    return (
                      <Form.Item<FieldType>
                        label={<CustomFormLabel text="Project" required />}
                        labelAlign="right"
                        initialValue={field.value}
                        validateStatus={!field.value && error ? "error" : ""}
                        help={!field.value && error ? error.message : ""}
                      >
                        <Select
                          {...field}
                          value={field.value || undefined}
                          onChange={(value) => {
                            handleProjectChange(value);
                          }}
                          size="large"
                          placeholder="Select Project"
                          options={memoizedProjectsOptions}
                          showSearch
                          allowClear
                          filterOption={(input, option) =>
                            (option?.label ?? "")
                              .toLowerCase()
                              .includes(input.toLowerCase())
                          }
                        />
                      </Form.Item>
                    );
                  }}
                />
              </Col>

              <Col xs={12}>
                <Controller
                  name="transferDate"
                  control={control}
                  render={({ field, formState: { errors } }) => {
                    const error = errors.transferDate;
                    return (
                      <Form.Item<FieldType>
                        label={
                          <CustomFormLabel text="Transfer Date" required />
                        }
                        labelAlign="right"
                        initialValue={field.value || null}
                        validateStatus={error ? "error" : ""}
                        help={error ? error.message : ""}
                      >
                        <DatePicker
                          {...field}
                          value={
                            dayjs(field.value).isValid()
                              ? dayjs(field.value)
                              : dayjs(new Date())
                          }
                          onChange={(date) => {
                            field.onChange(dayjs(date).locale("en").format());
                          }}
                          size="large"
                          style={{ width: "100%" }}
                          placeholder="MM/DD/YYYY"
                          format={dateFormat}
                        />
                      </Form.Item>
                    );
                  }}
                />
              </Col>

              <Col xs={12}>
                <Controller
                  name="originalLocationId"
                  control={control}
                  render={({ field, formState: { errors } }) => {
                    const error = errors.originalLocationId;
                    return (
                      <Form.Item<FieldType>
                        label={
                          <CustomFormLabel text="Original Location" required />
                        }
                        labelAlign="right"
                        initialValue={field.value}
                        validateStatus={!field.value && error ? "error" : ""}
                        help={!field.value && error ? error.message : ""}
                      >
                        <Select
                          {...field}
                          value={field.value || undefined}
                          onChange={(value) => {
                            field.onChange(value);
                            setValue("purchaseOrderIds", []);
                            handleLocationChange(value);
                          }}
                          size="large"
                          placeholder="Select Location"
                          options={memoizedLocationOptions}
                          showSearch
                          disabled={
                            !getValues("projectId") ||
                            materialTransfer?.status === 2
                          }
                          allowClear
                          filterOption={(input, option) =>
                            (option?.label ?? "")
                              .toLowerCase()
                              .includes(input.toLowerCase())
                          }
                          dropdownRender={(menu) => (
                            <>
                              {menu}
                              <Divider className="mt-2 mb-1" />
                              <Space className="p-1">
                                <Button
                                  type="text"
                                  icon={<PlusOutlined />}
                                  onClick={() =>
                                    handleOpenLocationModal(
                                      " Add New Original Location ",
                                      "originalLocationId"
                                    )
                                  }
                                >
                                  Add New Original Location
                                </Button>
                              </Space>
                            </>
                          )}
                        />
                      </Form.Item>
                    );
                  }}
                />
              </Col>

              <Col xs={12}>
                <Controller
                  name="destinationLocationId"
                  control={control}
                  render={({ field, formState: { errors } }) => {
                    const error = errors.destinationLocationId;
                    return (
                      <Form.Item<FieldType>
                        label={
                          <CustomFormLabel text="Delivering To" required />
                        }
                        labelAlign="right"
                        initialValue={field.value}
                        validateStatus={!field.value && error ? "error" : ""}
                        help={!field.value && error ? error.message : ""}
                      >
                        <Select
                          value={field.value || undefined}
                          onChange={(value) => {
                            setValue("destinationSubLocationId", "");
                            setValue("destinationLocationId", value || "");
                          }}
                          size="large"
                          placeholder="Select Location"
                          options={memoizedLocationOptions.filter(
                            (f) =>
                              f.value === "" ||
                              f.value !== getValues("originalLocationId")
                          )}
                          showSearch
                          disabled={
                            !getValues("originalLocationId") ||
                            materialTransfer?.status === 2
                          }
                          allowClear
                          filterOption={(input, option) =>
                            (option?.label ?? "")
                              .toLowerCase()
                              .includes(input.toLowerCase())
                          }
                          dropdownRender={(menu) => (
                            <>
                              {menu}
                              <Divider className="mt-2 mb-1" />
                              <Space className="p-1">
                                <Button
                                  type="text"
                                  icon={<PlusOutlined />}
                                  onClick={() =>
                                    handleOpenLocationModal(
                                      " Add New Delivery Location ",
                                      "destinationLocationId"
                                    )
                                  }
                                >
                                  Add New Delivery Location
                                </Button>
                              </Space>
                            </>
                          )}
                        />
                      </Form.Item>
                    );
                  }}
                />
              </Col>

              <Col xs={12}>
                <Controller
                  name="destinationSubLocationId"
                  control={control}
                  render={({ field }) => (
                    <Form.Item<FieldType>
                      label={<CustomFormLabel text="Destination Sublocation" />}
                      labelAlign="right"
                      initialValue={field.value}
                    >
                      <Select
                        {...field}
                        value={field.value || undefined}
                        onChange={(value) => field.onChange(value)}
                        size="large"
                        placeholder="Select Sublocation"
                        options={memoizedSubLocationOptions}
                        showSearch
                        disabled={
                          !getValues("destinationLocationId") ||
                          materialTransfer?.status === 2
                        }
                        allowClear
                        filterOption={(input, option) =>
                          (option?.label ?? "")
                            .toLowerCase()
                            .includes(input.toLowerCase())
                        }
                      />
                    </Form.Item>
                  )}
                />
              </Col>

              <Col xs={12}>
                <Controller
                  name="status"
                  control={control}
                  render={({ field }) => (
                    <Form.Item<FieldType>
                      label={<CustomFormLabel text="Status" />}
                      labelAlign="right"
                      initialValue={field.value}
                    >
                      <Select
                        {...field}
                        size="large"
                        options={[...materialTransferStatusOptions]}
                        showSearch
                        filterOption={(input, option) =>
                          (option?.label ?? "")
                            .toLowerCase()
                            .includes(input.toLowerCase())
                        }
                      />
                    </Form.Item>
                  )}
                />
              </Col>
              <Col xs={12}>
                <Controller
                  name="purchaseOrderIds"
                  control={control}
                  render={({ field, formState: { errors } }) => {
                    const error = errors.projectId;
                    return (
                      <Form.Item<FieldType>
                        label={<CustomFormLabel text="Purchase Order" />}
                        labelAlign="right"
                        initialValue={field.value}
                        validateStatus={!field.value && error ? "error" : ""}
                        help={!field.value && error ? error.message : ""}
                      >
                        <Select
                          {...field}
                          value={field.value || undefined}
                          onChange={(value) => {
                            field.onChange(value);
                            handleLocationChange(
                              getValues("originalLocationId")
                            );
                          }}
                          disabled={
                            !getValues("originalLocationId") ||
                            materialTransfer?.status ===
                              MaterialTransferStatusEnum.TRANSFERRED
                          }
                          size="large"
                          placeholder="Select Purchase Order"
                          options={memoizedPurchaseOrderOption}
                          mode="multiple"
                          showSearch
                          allowClear
                          filterOption={(input, option) =>
                            ((option?.label as string) ?? "")
                              .toLowerCase()
                              .includes(input.toLowerCase())
                          }
                        />
                      </Form.Item>
                    );
                  }}
                />
              </Col>
            </CustomFormRow>
            <Divider />
            <Typography.Title level={5}>Materials</Typography.Title>
            <div className="!mb-6">
              <AddMaterialDetailsFormRHF2
                control={control}
                setValue={setValue}
                getValues={getValues}
                watch={watch}
                data={tableData}
                initialData={materialTransfer}
              />
            </div>
            {(reqError || resError || successMessage) && (
              <CustomAlert
                message={reqError || resError || successMessage || ""}
                type={successMessage ? "success" : "error"}
              />
            )}

            <Flex justify="flex-end" className="gap-4">
              <Button
                disabled={isSubmitting}
                htmlType="button"
                onClick={handleClose}
              >
                Cancel
              </Button>
              {materialTransfer &&
                Object.keys(materialTransfer)?.length > 0 && (
                  <Button
                    disabled={
                      isSubmitting ||
                      materialTransfer?.status ===
                        MaterialTransferStatusEnum.TRANSFERRED
                    }
                    type="default"
                    htmlType="button"
                    loading={actionType.delete === ActionTypeEnum.DELETE}
                    onClick={handleDeleteMaterialTransferById}
                  >
                    {actionType.delete === ActionTypeEnum.DELETE
                      ? "Deleting..."
                      : "Delete"}
                  </Button>
                )}
              <Button
                htmlType="submit"
                type="primary"
                onClick={() => setActionType({ save: ActionTypeEnum.SAVE })}
                disabled={
                  isSubmitting ||
                  materialTransfer?.status ===
                    MaterialTransferStatusEnum.TRANSFERRED
                }
                loading={
                  actionType.save === ActionTypeEnum.SAVE && isSubmitting
                }
              >
                {isSubmitting && actionType.save === ActionTypeEnum.SAVE
                  ? "Saving..."
                  : "Save"}
              </Button>

              <Button
                htmlType="submit"
                disabled={
                  isSubmitting ||
                  materialTransfer?.status ===
                    MaterialTransferStatusEnum.TRANSFERRED
                }
                type="primary"
                onClick={() =>
                  setActionType({
                    saveAndClose: ActionTypeEnum.SAVE_AND_CLOSE,
                  })
                }
                loading={
                  isSubmitting &&
                  actionType.saveAndClose === ActionTypeEnum.SAVE_AND_CLOSE
                }
              >
                {isSubmitting &&
                actionType.saveAndClose === ActionTypeEnum.SAVE_AND_CLOSE
                  ? "Save & Closing..."
                  : "Save & Close"}
              </Button>
            </Flex>

            {materialTransfer?.id && (
              <Flex justify="flex-end" className="mt-4">
                <CreatedByUserBadge
                  userName={
                    materialTransfer?.modifiedBy == null
                      ? materialTransfer?.createdBy
                      : materialTransfer?.lastModifiedBy
                  }
                  date={materialTransfer?.lastModifiedDate}
                  isUpdatedBadge={
                    materialTransfer.modifiedBy == null ? false : true
                  }
                />
              </Flex>
            )}
          </Form>
        )}
      </SectionLayout>
    </>
  );
}
