import * as Yup from "yup";

export const validationSchema = Yup.object().shape({
  title: Yup.string().required("Title is required."),
  projectId: Yup.string().required("Project is required"),
  transferDate: Yup.string().required("Transfer Date is required."),
  originalLocationId: Yup.string().required("Original Location is required."),
  destinationLocationId: Yup.string().required(
    "Destination Location is required."
  ),
  status: Yup.number().required("Status is required."),
  materials: Yup.array().of(
    Yup.object().shape({
      name: Yup.string().required("Material Name is required"),
      quantity: Yup.number().required("Quantity is required"),
      // .test(
      //   "quantity-match",
      //   "Quantity must be equal to the sum of spares, samples, and regular",
      //   function (value) {
      //     const { spares, samples, regular } = this.parent;
      //     const totalQuantity =
      //       (spares || 0) + (samples || 0) + (regular || 0);
      //     return value === totalQuantity;
      //   }
      // )
      unitOfMeasure: Yup.string().required("Unit of Measurement is required"),
    })
  ),
});
