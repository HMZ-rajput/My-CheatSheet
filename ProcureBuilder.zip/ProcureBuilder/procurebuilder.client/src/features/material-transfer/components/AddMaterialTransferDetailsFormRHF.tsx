import CustomIcon from "@/src/components/common/CustomIcon";
import DeleteIconButton from "@/src/components/icon-buttons/DeleteIconButton";
import { useAppDispatch } from "@/src/hooks/useAppDispatch";
import { resetState } from "@/src/store/slices/materialTransferSlice";
import { MaterialTransferStatusEnum } from "@/src/utils/enums";
import { ActionTypeState, MaterialTransfer } from "@/src/utils/types";
import { Button, Col, Flex, Form, Input, InputNumber, Row, Select } from "antd";
import { useCallback, useEffect, useMemo, useState } from "react";
import {
  Control,
  Controller,
  FieldErrors,
  useFieldArray,
  UseFormGetValues,
  UseFormReset,
  UseFormSetValue,
  UseFormWatch,
} from "react-hook-form";
import { useLocation } from "react-router-dom";
import MaterialGoingToSiteHeader from "../../material-going-to-sites/components/MaterialGoingToSiteHeader";

type AddMaterialFormProps = {
  data: LocationData;
  setValue: UseFormSetValue<MaterialTransfer>;
  getValues: UseFormGetValues<MaterialTransfer>;
  control: Control<MaterialTransfer>;
  watch: UseFormWatch<MaterialTransfer>;
  isProjectSelected: boolean;
  reset: UseFormReset<MaterialTransfer>;
  actionType?: ActionTypeState;
  initialData?: MaterialTransfer | null;
  isEditMode: boolean;
  errors: FieldErrors<MaterialTransfer>;
};

type Material = {
  id: string | null;
  name: string;
  unitOfMeasure: string;
  quantity: number;
  samples: number;
  spares: number;
  regular: number;
};

type SubLocation = {
  subLocationId?: string;
  subLocationName?: string;
  materials?: Material[];
};

type LocationData = SubLocation[];

export default function AddMaterialDetailsFormRHF(props: AddMaterialFormProps) {
  const {
    control,
    data,
    setValue,
    getValues,
    initialData,
    actionType,
    isEditMode,
    watch,
    errors,
  } = props;
  const location = useLocation();
  const dispatch = useAppDispatch();
  const [trackAll, setTrackAll] = useState<
    Record<
      string,
      {
        materials: Material[];
        subLocationId: string | null;
        materialsLength: number | undefined;
        availableMaterials: { label: string; value: string }[];
      }
    >
  >({});
  const [trackSublocationId, setTrackSublocationId] = useState<{
    [key: number]: string;
  }>({});

  const [subLocationsFilterOptions, setSubLocationFilterOptions] = useState<
    { label: string | undefined; value: string }[]
  >([]);

  const [materialList, setmaterialList] = useState<{ [key: number]: string }>(
    {}
  );

  const isMaterialEmpty = watch("materials")?.every(
    (data) => data?.name === "" && data?.subLocationId === ""
  );

  useEffect(() => {
    if (isMaterialEmpty) {
      setTrackAll({});
      setTrackSublocationId({});

      setSubLocationFilterOptions([]);

      setmaterialList({});
      dispatch(resetState());
    }
  }, [
    isMaterialEmpty,
    dispatch,
    errors,
    data,
    location.pathname,
    actionType,
    isEditMode,
    setSubLocationFilterOptions,
    setmaterialList,
  ]);

  useEffect(() => {
    if (data && data?.length > 0 && initialData?.id && !isEditMode) {
      let index = 0;
      for (const material of initialData?.materials) {
        handleEditChangeSubLocation(
          index,
          material?.subLocationId,
          material?.name
        );
        index++;
      }
    }
  }, [data, initialData, !isEditMode]);

  const handleEditChangeSubLocation = (
    index: number,
    value: string,
    materialName: string
  ) => {
    const availableMaterials = data
      ?.find((dbts) => dbts?.subLocationId === value)
      ?.materials?.map((mgts) => {
        return {
          value: mgts?.name,
          label: mgts?.name,
        };
      })
      ?.filter((data) => data?.value !== materialName);
    setTrackAll((prev: any) => {
      setTrackSublocationId((prevSub: any) => ({
        ...prevSub,
        [index]: value,
      }));

      return {
        ...prev,
        [value]: {
          materials: data?.find((dbts) => dbts?.subLocationId === value)
            ?.materials,
          subLocationId: value ? value : null,
          materialsLength: data?.find((dbts) => dbts?.subLocationId === value)
            ?.materials?.length,
          availableMaterials: [
            ...(!prev?.[value]?.availableMaterials ||
            prev?.[value]?.availableMaterials?.length === 0
              ? [
                  {
                    label: "Select Materials",
                    value: "",
                  },
                  ...(availableMaterials || []),
                ]
              : prev?.[value]?.availableMaterials?.filter(
                  (data: any) => data?.value !== materialName
                ) || []),
          ],
        },
      };
    });

    setmaterialList((prev) => ({ ...prev, [index]: materialName }));
  };

  const {
    fields: materialFields,
    remove,
    append,
  } = useFieldArray({
    name: "materials",
    control: control,
  });

  const handleAddMaterial = () => {
    append({
      id: "",
      name: "",
      quantity: 0,
      samples: 0,
      spares: 0,
      unitOfMeasure: "",
      subLocationName: "",
      regular: 0,
      subLocationId: "",
    });
  };

  useEffect(() => {
    const subLocationFilterOptions = [
      ...data?.map((location) => ({
        value: location.subLocationId!,
        label: !location.subLocationName
          ? "Unspecified"
          : location.subLocationName,
      })),
    ];
    setSubLocationFilterOptions(subLocationFilterOptions);
  }, [data, location.pathname, append]);

  const handleDelete = useCallback(
    (index: number) => {
      // CASE1: If the material is not selected
      // CASE2: If the material is selected
      // if it delete from the any of the list then it should be added to the available list

      const materialName = getValues(`materials.${index}.name`);
      const subLocationId = getValues(`materials.${index}.subLocationId`);

      // this is the case where the material and sublocation is not selected
      if (subLocationId === "" && materialName === "") {
        if (
          trackSublocationId?.[index + 1] !== undefined &&
          trackSublocationId?.[index] === ""
        ) {
          setTrackSublocationId((prevSub) => {
            function deleteAndReindex(
              state: { [key: number]: string },
              indexToDelete: number
            ) {
              // Delete the specified item
              delete state[indexToDelete];

              // Shift remaining items
              const newState: { [key: number]: string } = {};
              let newIndex = 0;

              for (let i in state) {
                if (state[i] !== undefined && Number(i) !== indexToDelete) {
                  newState[newIndex] = state[i];
                  newIndex++;
                }
              }

              return newState;
            }
            return deleteAndReindex(prevSub, index);
          });
          remove(index);
          return;
        }
        remove(index);
        return;
      }

      const subLocationTrack = trackAll?.[subLocationId];
      const subLocationTrackMaterials = subLocationTrack?.materials.find(
        (mte) => mte.name === materialName
      );
      // this is the case when the material is selected and then deleted
      if (subLocationTrack && subLocationId !== "") {
        setTrackAll((prev: any) => {
          setTrackSublocationId((prevSub) => {
            function deleteAndReindex(
              state: { [key: number]: string },
              indexToDelete: number
            ) {
              // Delete the specified item
              delete state[indexToDelete];

              // Shift remaining items
              const newState: { [key: number]: string } = {};
              let newIndex = 0;

              for (let i in state) {
                if (state[i] !== undefined && Number(i) !== indexToDelete) {
                  newState[newIndex] = state[i];
                  newIndex++;
                }
              }

              return newState;
            }
            return deleteAndReindex(prevSub, index);
          });
          return {
            ...prev,
            [subLocationId]: {
              ...prev?.[subLocationId],
              availableMaterials: subLocationTrackMaterials
                ? [
                    {
                      label: subLocationTrackMaterials?.name,
                      value: subLocationTrackMaterials?.name,
                    },
                    ...(prev?.[subLocationId]?.availableMaterials || []),
                  ]
                : prev?.[subLocationId]?.availableMaterials,
            },
          };
        });
      }
      remove(index);
    },
    [
      remove,
      trackAll,
      trackSublocationId,
      materialList,
      subLocationsFilterOptions,
    ]
  );

  const resetMaterialIfSubLocationChanges = (index: number) => {
    const materials = getValues(`materials.${index}.name`);
    const trackMaterials = trackAll?.[
      trackSublocationId?.[index]
    ]?.materials?.find((mgts: any) => mgts?.name === materials);

    if (trackMaterials && trackSublocationId?.[index] !== undefined) {
      setTrackAll((prev: any) => {
        return {
          ...prev,
          [trackSublocationId?.[index]]: {
            ...prev?.[trackSublocationId?.[index]],
            availableMaterials: [
              ...prev?.[trackSublocationId?.[index]]?.availableMaterials,
              {
                label: trackMaterials?.name,
                value: trackMaterials?.name,
              },
            ],
          },
        };
      });
    }

    setValue(`materials.${index}.name`, "");
    setValue(`materials.${index}.samples`, 0);
    setValue(`materials.${index}.spares`, 0);
    setValue(`materials.${index}.regular`, 0);
    setValue(`materials.${index}.quantity`, 0);
    setValue(`materials.${index}.unitOfMeasure`, "");
  };

  const maxValues = useMemo<(index: number) => Material | undefined>(() => {
    return (index: number) => {
      const materials = trackAll?.[trackSublocationId?.[index]]?.materials;
      const material = materials?.find(
        (mgts: any) => mgts?.name === getValues(`materials.${index}.name`)
      );

      return material;
    };
  }, [data, trackSublocationId, trackAll, initialData]);

  const handleChangeSubLocation = (index: number, value: string) => {
    resetMaterialIfSubLocationChanges(index);
    setValue(`materials.${index}.subLocationId`, value);
    if (!trackAll?.[value] && value !== "") {
      const materialsOfSelectedSubLocation = data?.find(
        (mgts) => mgts?.subLocationId === value
      )?.materials;

      setTrackAll((prev: any) => {
        return {
          ...prev,
          [value]: {
            materials: materialsOfSelectedSubLocation,
            subLocationId: value ? value : null,
            materialsLength: materialsOfSelectedSubLocation?.length,
            availableMaterials: [
              {
                label: "Select Materials",
                value: "",
              },
              ...(materialsOfSelectedSubLocation?.map((mgts) => {
                return {
                  value: mgts.name,
                  label: mgts.name,
                };
              }) || []),
            ],
          },
        };
      });
    }
    // this is the case where it is already selected but user has change their mind and want to change the sublocation
    if (trackSublocationId?.[index] !== undefined) {
      setTrackAll((prev: any) => {
        return {
          ...prev,
          [trackSublocationId?.[index]]: {
            ...prev?.[trackSublocationId?.[index]],
            availableMaterials: getValues(`materials.${index}.name`)
              ? [
                  ...prev?.[trackSublocationId?.[index]]?.availableMaterials,
                  {
                    label: getValues(`materials.${index}.name`),
                    value: getValues(`materials.${index}.name`),
                  },
                ]
              : prev?.[trackSublocationId?.[index]]?.availableMaterials,
          },
        };
      });
    }
    setTrackSublocationId((prev: any) => ({ ...prev, [index]: value }));
  };

  const handleChangeMaterial = (index: number, value: string) => {
    const material = trackAll?.[trackSublocationId?.[index]]?.materials?.find(
      (mgts: any) => mgts?.name === value
    );
    const materialName = getValues(`materials.${index}.name`);

    if (
      value === "" &&
      trackSublocationId?.[index] !== undefined &&
      trackSublocationId?.[index] !== ""
    ) {
      setTrackAll((prev: any) => {
        const materialsName = prev?.[
          trackSublocationId?.[index]
        ]?.materials?.find(
          (mgts: any) => mgts?.name === getValues(`materials.${index}.name`)
        )?.name;
        return {
          ...prev,
          [trackSublocationId?.[index]]: {
            ...prev?.[trackSublocationId?.[index]],
            availableMaterials: [
              ...prev?.[trackSublocationId?.[index]]?.availableMaterials,
              {
                label: materialsName,
                value: materialsName,
              },
            ],
          },
        };
      });
    } else {
      if (value !== "" && materialName !== "" && materialName !== value) {
        setTrackAll((prev: any) => {
          return {
            ...prev,
            [trackSublocationId?.[index]]: {
              ...prev?.[trackSublocationId?.[index]],
              availableMaterials: [
                ...(prev?.[
                  trackSublocationId?.[index]
                ]?.availableMaterials?.filter(
                  (data: any) => data?.value !== value
                ) || []),
                {
                  label: materialName,
                  value: materialName,
                },
              ],
            },
          };
        });
      } else {
        setTrackAll((prev: any) => {
          return {
            ...prev,
            [trackSublocationId?.[index]]: {
              ...prev?.[trackSublocationId?.[index]],
              availableMaterials:
                prev?.[trackSublocationId?.[index]]?.availableMaterials?.filter(
                  (data: any) => data?.value !== value
                ) || [],
            },
          };
        });
      }
    }
    setValue(`materials.${index}.name`, value);

    setValue(`materials.${index}.samples`, material?.samples || 0);
    setValue(`materials.${index}.spares`, material?.spares || 0);
    setValue(`materials.${index}.regular`, material?.regular || 0);
    setValue(`materials.${index}.quantity`, material?.quantity || 0);
    setValue(`materials.${index}.unitOfMeasure`, material?.unitOfMeasure || "");

    setmaterialList((prev) => ({ ...prev, [index]: value }));
  };
  const handleCalculateTotal = (index: number) => {
    let total = 0;
    const sample = getValues(`materials.${index}.samples`);
    const spares = getValues(`materials.${index}.spares`);
    const regular = getValues(`materials.${index}.regular`);
    total = sample + spares + regular;
    const quantity = maxValues(index)?.quantity;
    if (total <= quantity!) {
      setValue(`materials.${index}.quantity`, total);
    }
  };

  return (
    <>
      <div className="py-1.5">
        <div className="py-1.5 px-2 rounded-lg mb-4 bg-neutral-1">
          <MaterialGoingToSiteHeader />
        </div>

        {materialFields?.map((field, index) => (
          <Row key={field?.id} gutter={[16, 16]}>
            <Col xs={4}>
              <Controller
                name={`materials.${index}.subLocationId`}
                control={control}
                render={({ field, fieldState: { error } }) => (
                  <Form.Item
                    labelAlign="right"
                    validateStatus={error ? "error" : ""}
                    help={error ? error.message : ""}
                  >
                    <Select
                      {...field}
                      disabled={
                        (index !== 0 &&
                          (!materialList?.[index - 1] ||
                            Object.keys(materialList?.[index - 1])?.length ===
                              0) &&
                          field.value === "") ||
                        field?.value === undefined ||
                        subLocationsFilterOptions?.length === 0 ||
                        initialData?.status ===
                          MaterialTransferStatusEnum.TRANSFERRED
                      }
                      size="large"
                      placeholder={"Sublocations"}
                      style={{ width: "100%" }}
                      showSearch
                      value={field.value}
                      onChange={(value) => {
                        handleChangeSubLocation(index, value);
                      }}
                      options={[
                        {
                          label: "Select Sublocation",
                          value: "",
                          disabled:
                            watch("materials")?.filter(
                              (material) => material?.subLocationId !== ""
                            )?.length === 1,
                        },
                        ...subLocationsFilterOptions?.map((sbLocation) => {
                          const availableMaterials =
                            trackAll?.[sbLocation.value]?.availableMaterials;
                          return {
                            label:
                              sbLocation?.value === null
                                ? "Unspecified"
                                : sbLocation.label,
                            value: sbLocation.value,
                            disabled: availableMaterials?.length === 1,
                          };
                        }),
                      ]}
                      optionRender={(option) => {
                        return option.label;
                      }}
                      filterOption={(input, option) =>
                        (option?.value || "")
                          .toLowerCase()
                          .includes(input.toLowerCase())
                      }
                    />
                  </Form.Item>
                )}
              />
            </Col>
            {/* Material */}

            <Col xs={4}>
              <Controller
                name={`materials.${index}.name`}
                control={control}
                render={({ field, fieldState: { error } }) => (
                  <Form.Item
                    labelAlign="right"
                    validateStatus={!field.value && error ? "error" : ""}
                    help={!field.value && error ? error.message : ""}
                  >
                    <Select
                      {...field}
                      size="large"
                      placeholder={"Select Materials"}
                      style={{ width: "100%" }}
                      showSearch
                      disabled={
                        trackSublocationId?.[index] === undefined ||
                        trackSublocationId?.[index] === "" ||
                        initialData?.status ===
                          MaterialTransferStatusEnum.TRANSFERRED
                      }
                      value={field.value}
                      onChange={(value) => {
                        handleChangeMaterial(index, value);
                      }}
                      options={[
                        ...(trackAll?.[trackSublocationId?.[index]]
                          ?.availableMaterials || [
                          {
                            label: "Select Materials",
                            value: "",
                          },
                        ]),
                      ]}
                      filterOption={(input, option) =>
                        (option?.label || "")
                          ?.toLowerCase()
                          ?.includes(input.toLowerCase())
                      }
                    />
                  </Form.Item>
                )}
              />
            </Col>
            {/* Samples */}
            <Col xs={3} className="flex">
              <Controller
                name={`materials.${index}.samples`}
                control={control}
                render={({ field, fieldState: { error } }) => (
                  <Form.Item
                    labelAlign="right"
                    validateStatus={error ? "error" : ""}
                    help={error ? error.message : ""}
                  >
                    <InputNumber
                      {...field}
                      size="large"
                      precision={0}
                      disabled={
                        initialData?.status ===
                        MaterialTransferStatusEnum.TRANSFERRED
                      }
                      min={0}
                      max={maxValues(index)?.samples ?? 0}
                      style={{ width: "100%" }}
                      placeholder="sample"
                      value={field.value ?? 0}
                      onChange={(value) => {
                        field.onChange(value ?? 0);
                        handleCalculateTotal(index);
                      }}
                    />
                  </Form.Item>
                )}
              />
              <div className="mt-2 ml-2">/{maxValues(index)?.samples ?? 0}</div>
            </Col>
            {/* Spare */}
            <Col xs={3} className="flex">
              <Controller
                name={`materials.${index}.spares`}
                control={control}
                render={({ field, fieldState: { error } }) => (
                  <Form.Item
                    labelAlign="right"
                    validateStatus={error ? "error" : ""}
                    help={error ? error.message : ""}
                  >
                    <InputNumber
                      {...field}
                      precision={0}
                      size="large"
                      min={0}
                      max={maxValues(index)?.spares ?? 0}
                      style={{ width: "100%" }}
                      placeholder="spares"
                      value={field.value ?? 0}
                      disabled={
                        initialData?.status ===
                        MaterialTransferStatusEnum.TRANSFERRED
                      }
                      onChange={(value) => {
                        field.onChange(value ?? 0);
                        handleCalculateTotal(index);
                      }}
                    />
                  </Form.Item>
                )}
              />
              <div className="mt-2 ml-2">/{maxValues(index)?.spares ?? 0}</div>
            </Col>
            {/* Regular */}
            <Col xs={3} className="flex">
              <Controller
                name={`materials.${index}.regular`}
                control={control}
                render={({ field, fieldState: { error } }) => (
                  <Form.Item
                    labelAlign="right"
                    validateStatus={error ? "error" : ""}
                    help={error ? error.message : ""}
                  >
                    <InputNumber
                      {...field}
                      precision={0}
                      size="large"
                      min={0}
                      disabled={
                        initialData?.status ===
                        MaterialTransferStatusEnum.TRANSFERRED
                      }
                      max={maxValues(index)?.regular ?? 0}
                      style={{ width: "100%" }}
                      placeholder="spares"
                      value={field.value ?? 0}
                      onChange={(value) => {
                        field.onChange(value ?? 0);
                        handleCalculateTotal(index);
                      }}
                    />
                  </Form.Item>
                )}
              />
              <div className="mt-2 ml-2">/{maxValues(index)?.regular ?? 0}</div>
            </Col>
            {/* Quantity */}
            <Col xs={3} className="flex">
              <Controller
                name={`materials.${index}.quantity`}
                control={control}
                render={({ field, fieldState: { error } }) => (
                  <Form.Item
                    labelAlign="right"
                    validateStatus={error ? "error" : ""}
                    help={error ? error.message : ""}
                  >
                    <InputNumber
                      {...field}
                      precision={0}
                      size="large"
                      min={0}
                      disabled
                      max={maxValues(index)?.quantity}
                      style={{ width: "100%" }}
                      placeholder="Quantity"
                      value={field.value ?? 0}
                    />
                  </Form.Item>
                )}
              />
              <div className="mt-2 ml-2">
                /{maxValues(index)?.quantity ?? 0}
              </div>
            </Col>
            {/* Unit of Measurement */}
            <Col xs={3}>
              <Controller
                name={`materials.${index}.unitOfMeasure`}
                control={control}
                render={({ field, fieldState: { error } }) => (
                  <Form.Item
                    labelAlign="right"
                    validateStatus={!field.value && error ? "error" : ""}
                    help={!field.value && error ? error.message : ""}
                  >
                    <Input
                      {...field}
                      size="large"
                      disabled={
                        initialData?.status ===
                        MaterialTransferStatusEnum.TRANSFERRED
                      }
                      placeholder="FT"
                      value={field.value || ""}
                    />
                  </Form.Item>
                )}
              />
            </Col>
            <Col className="mt-1" xs={1}>
              <DeleteIconButton
                handleDelete={() => handleDelete(index)}
                disabled={
                  (index === 0 &&
                    materialFields?.length > 1 &&
                    !watch(`materials.${index + 1}`)?.name) ||
                  (!initialData && materialFields?.length === 1) ||
                  materialFields?.length === 1 ||
                  initialData?.status === MaterialTransferStatusEnum.TRANSFERRED
                }
              />
            </Col>
          </Row>
        ))}

        {initialData?.status !== MaterialTransferStatusEnum.TRANSFERRED && (
          <Flex justify="space-between">
            <Button
              className="border-0 shadow-none text-primary font-medium"
              size="small"
              icon={<CustomIcon width={16} type="add-circle" />}
              onClick={handleAddMaterial}
            >
              Add Material
            </Button>
          </Flex>
        )}
      </div>
    </>
  );
}
