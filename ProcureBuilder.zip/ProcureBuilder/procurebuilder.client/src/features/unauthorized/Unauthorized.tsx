import React from "react";
import { useNavigate } from "react-router-dom";
import { Button, Typography } from "antd";
import routePaths from "@/src/utils/routePaths";

const UnauthorizedPage: React.FC = () => {
  const navigate = useNavigate();

  const handleGoBack = () => {
    navigate(routePaths.LOGIN);
  };

  return (
    <div className="flex flex-col items-center justify-center h-[calc(100vh-80px)] text-center">
      <div>
        <Typography.Title level={1} className="!text-6xl font-bold !mb-4">
          401
        </Typography.Title>
        <Typography.Title level={4} className="!my-0">
          Unauthorized Access
        </Typography.Title>
        <Typography.Text className="text-lg block">
          You do not have permission to view this page.
        </Typography.Text>
        <Button
          className="mt-8"
          type="primary"
          size="large"
          onClick={handleGoBack}
        >
          Go Back to Login
        </Button>
      </div>
    </div>
  );
};

export default UnauthorizedPage;
