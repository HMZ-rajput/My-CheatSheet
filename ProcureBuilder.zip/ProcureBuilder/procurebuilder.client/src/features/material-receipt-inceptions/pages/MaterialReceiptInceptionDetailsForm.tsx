import { getMaterialReceiptInspectionById } from "@/src/apis/materialReceiptInceptionApis";
import { getAllQuestions } from "@/src/apis/questionApis";
import CustomTabs from "@/src/components/common/CustomTabs";
import MaterialReceiptInspectionStatus from "@/src/components/common/MaterialReceiptInceptionStatusBadge";
import PageLayout from "@/src/components/layout/PageLayout";
import { useAppDispatch } from "@/src/hooks/useAppDispatch";
import { useAppSelector } from "@/src/hooks/useAppSelector";
import { getMaterialReceiptInspectionStateById } from "@/src/store/slices/materialReceiptInceptionSlice";
// import { getQuestionsState } from "@/src/store/slices/questionsSlice";
import { getMaterialReceiptInspectionStatus } from "@/src/utils/helper";
import routePaths from "@/src/utils/routePaths";
import { Flex } from "antd";
import { useEffect, useMemo, useState } from "react";
import { useLocation, useNavigate, useParams } from "react-router-dom";
import GeneralForm from "../component/MaterialReceiptInceptionGeneralForm";
import MaterialPhotosForm from "../component/MaterialReceiptInceptionMaterialPhotoForm";

export default function MaterialReceiptInspectionsDetailsPage() {
  const FormSections = {
    General: "General",
    // QualityQuestions: "Quality Questions",
    MaterialPhotos: "Material Photos",
  };

  const navigate = useNavigate();
  const dispatch = useAppDispatch();
  const { materialReceiptInspectionId } = useParams();
  // const { questionsData } = useAppSelector(getQuestionsState);
  const [selectedSection, setSelectedSection] = useState(FormSections.General);
  const location = useLocation();
  const materialReceiptInspectionSate = useAppSelector((state) =>
    getMaterialReceiptInspectionStateById(
      state,
      materialReceiptInspectionId || ""
    )
  );

  useEffect(() => {
    if (materialReceiptInspectionSate) {
      return;
    }
    if (location.pathname?.includes("/edit/") && materialReceiptInspectionId) {
      const fetchMaterialReceiptInspectionById = async () => {
        await dispatch(
          getMaterialReceiptInspectionById({ id: materialReceiptInspectionId })
        ).unwrap();
      };
      fetchMaterialReceiptInspectionById();
    } else {
      return;
    }
  }, [materialReceiptInspectionId, dispatch]);

  useEffect(() => {
    // THIS CONDITION BELOW IS COMMENTED BECAUSE OF A BUG:
    // IF YOU HAVE QUALITY QUESTIONS OF ANOTHER MRI,
    // IT WILL NOT DISABLE IT FOR THIS ONE.
    // WE TRIED RESETTING REDUX BUT IT DIDNT WORK - Ustad Inshal.
    // if (questionsData) {
    //   return;
    // }

    if (materialReceiptInspectionSate?.project?.id) {
      const fetchQualityQuestions = async () => {
        await dispatch(
          getAllQuestions({
            projectId: materialReceiptInspectionSate?.project?.id || "",
          })
        ).unwrap();
      };
      fetchQualityQuestions();
    } else {
      return;
    }
  }, [materialReceiptInspectionSate, dispatch]);

  // const questions =
  //   questionsData?.qualityQuestions?.map((value) => ({
  //     id: value.id,
  //     question: value?.question,
  //   })) || [];

  const { badgeType } = useMemo(() => {
    return getMaterialReceiptInspectionStatus(
      materialReceiptInspectionSate?.status ?? 0
    );
  }, [materialReceiptInspectionSate]);

  const handleCancelForm = () => {
    const previousPath = location?.state?.previousPath || "";
    if (previousPath) {
      navigate(previousPath);
    } else {
      navigate(routePaths.MATERIAL_RECEIPT_INSPECTION);
    }
  };

  function renderRenderFormSections() {
    switch (selectedSection) {
      default:
        return (
          <GeneralForm
            POData={location.state}
            materialReceiptInspection={
              materialReceiptInspectionSate?.id
                ? materialReceiptInspectionSate
                : null
            }
            handleCancelForm={handleCancelForm}
          />
        );
      // case FormSections.QualityQuestions:
      //   return (
      //     <QualityQuestionsForm
      //       materialReceiptInspection={
      //         materialReceiptInspectionSate?.id
      //           ? materialReceiptInspectionSate
      //           : null
      //       }
      //       questions={questions}
      //       handleCancelForm={handleCancelForm}
      //     />
      //   );
      case FormSections.MaterialPhotos:
        return (
          <MaterialPhotosForm
            materialReceiptInspection={materialReceiptInspectionSate ?? null}
            handleCancelForm={handleCancelForm}
          />
        );
    }
  }

  useEffect(() => {
    if (
      location.pathname === routePaths.MATERIAL_RECEIPT_INSPECTION_NEW &&
      selectedSection !== FormSections.General
    ) {
      setSelectedSection(FormSections.General);
    }
  }, [location]);

  return (
    <>
      <PageLayout
        title={
          materialReceiptInspectionSate
            ? "Edit Material Receipt Inspection"
            : "New Material Receipt Inspection"
        }
        titleSibling={<MaterialReceiptInspectionStatus badgeType={badgeType} />}
        titleBarJustifyContent="flex-start"
      >
        <Flex className="mb-7">
          <CustomTabs
            options={Object.entries(FormSections)?.map(([key, value]) => ({
              value: key,
              label: value,
              disabled:
                !materialReceiptInspectionId && value !== FormSections.General,
            }))}
            tabLabel={selectedSection}
            onChange={(tab) => setSelectedSection(tab)}
          />
        </Flex>
        {renderRenderFormSections()}
      </PageLayout>
    </>
  );
}
