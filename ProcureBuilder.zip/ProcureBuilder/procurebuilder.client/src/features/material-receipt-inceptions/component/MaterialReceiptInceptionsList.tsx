import { getAllMaterialReceiptInspections } from "@/src/apis/materialReceiptInceptionApis";
import { getSummarizedProjectsList } from "@/src/apis/projectApis";
import CustomIcon from "@/src/components/common/CustomIcon";
import HighlightedText from "@/src/components/common/HighlightedText";
import MaterialReceiptInspectionStatus from "@/src/components/common/MaterialReceiptInceptionStatusBadge";
import CustomTable, {
  defaultPageSizes,
} from "@/src/components/table/CustomTable";
import CustomTableFilters, {
  CustomFilterDataType,
  CustomFiltersType,
} from "@/src/components/table/CustomTableFilters";
import { useAppDispatch } from "@/src/hooks/useAppDispatch";
import { useAppSelector } from "@/src/hooks/useAppSelector";
import { useDebouncedCallback } from "@/src/hooks/useDebouncedCallback";
import { getMaterialReceiptInspectionState } from "@/src/store/slices/materialReceiptInceptionSlice";
import { getProjectsState } from "@/src/store/slices/projectsSlice";
import {
  allMaterialReceiptInspectionsStatusOption,
  dateFormat,
  materialReceiptInspectionOptionsWithAll,
} from "@/src/utils/constants";
import { getMaterialReceiptInspectionStatus } from "@/src/utils/helper";
import { getFirstValidNumber } from "@/src/utils/number-extensions";
import routePaths from "@/src/utils/routePaths";
import { getConsistentSpacing } from "@/src/utils/theme-helpers";
import SectionLayout from "@components/layout/SectionLayout";
import { Button, TableProps, Typography } from "antd";
import dayjs from "dayjs";
import { useEffect, useMemo, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useReports } from "../../reports/contexts/ReportsProvider";
import useSyncFilters from "@/src/hooks/useSyncFilters";

type MaterialTransferListProps = {
  setReportStats?: null | React.Dispatch<
    React.SetStateAction<{
      totalInspections: number;
      totalRejected: number;
      totalApproved: number;
      totalApprovedWithExceptions: number;
      totalPending: number;
      totalTransferred: number;
    }>
  >;

  exportButtonEl?: React.ReactNode | null;
};
export default function MaterialReceiptInseptionsList({
  setReportStats = null,

  exportButtonEl = null,
}: MaterialTransferListProps) {
  const { filterValues } = useReports();

  const isInsideReports = useMemo(
    () => Boolean(exportButtonEl),
    [exportButtonEl]
  );
  const navigate = useNavigate();
  const dispatch = useAppDispatch();
  const {
    MaterialReceiptInspectionData,
    isLoading,
    totalCount,
    currentPage: materialReceiptInspectionCurrentPage,
    pageSize: materialReceiptInspectionPageSize,
  } = useAppSelector(getMaterialReceiptInspectionState);

  const [searchTerm, setSearchTerm] = useState("");
  const [hasSearched, setHasSearched] = useState(false);
  const { searchParams } = useSyncFilters();
  const [previousSearchTerm, setPreviousSearchTerm] = useState(
    searchParams.get("searchTerm")
  );
  const [lastSearchTimestamp, setLastSearchTimestamp] = useState(0);

  useEffect(() => {
    setLastSearchTimestamp(Date.now());
  }, [previousSearchTerm]);

  const isFirstCallComplete = useRef(false);
  // const [isFirstCall, setIsFirstCall] = useState(true);
  const [page, setPage] = useState<number>(
    materialReceiptInspectionCurrentPage
  );
  const [pageSize, setPageSize] = useState<number>(
    !isInsideReports &&
      !defaultPageSizes.includes(materialReceiptInspectionPageSize)
      ? 10
      : materialReceiptInspectionPageSize
  );

  useEffect(() => {
    dispatch(getSummarizedProjectsList());
  }, [dispatch]);

  const { projectsSummarizedData } = useAppSelector(getProjectsState);
  const memoizedProjectsOptions = useMemo(() => {
    return [
      {
        value: "",
        label: "All Projects",
      },
      ...(projectsSummarizedData?.map((f) => ({
        value: f?.id,
        label: f?.name,
      })) || []),
    ];
  }, [projectsSummarizedData]);

  const [filters, setFilters] = useState<CustomFiltersType>({
    status: {
      value: allMaterialReceiptInspectionsStatusOption?.value || 0,
      options: materialReceiptInspectionOptionsWithAll,
      className: "!min-w-[239px]",
      dataType: CustomFilterDataType.NUM,
    },
    projectId: {
      value: memoizedProjectsOptions[0]?.value || "",
      options: memoizedProjectsOptions,
      dataType: CustomFilterDataType.STR,
    },
  });

  useEffect(() => {
    // Only update filters if the options actually change
    setFilters((prevFilters) => {
      const currentOptions = prevFilters.projectId.options;
      const newOptions = memoizedProjectsOptions;

      // Check if options are different (by comparing their length or individual items)
      const optionsChanged =
        currentOptions.length !== newOptions.length ||
        currentOptions.some(
          (option, index) => option.value !== newOptions[index]?.value
        );

      // If options are the same, return the previous filters to avoid unnecessary state update
      if (!optionsChanged) {
        return prevFilters;
      }

      // If options have changed, update the filters
      return {
        ...prevFilters,
        projectId: {
          ...prevFilters.projectId,
          options: newOptions,
        },
      };
    });
  }, [memoizedProjectsOptions]);

  const [buttonsFilterStatus, setButtonsFilterStatus] = useState({
    isDueToday: false,
    isOverDue: false,
    isUpComing: false,
  });

  const [buttonActive, setButtonActive] = useState({
    isDueTodayActive: false,
    isOverDueActive: false,
    isUpComingActive: false,
  });

  function updateDueTimeButtons(value: string) {
    switch (value) {
      case "dueToday":
        setButtonsFilterStatus((prev) => ({
          ...prev,
          isDueToday: !prev.isDueToday,
          isOverDue: false,
          isUpComing: false,
        }));
        setButtonActive((prev) => ({
          ...prev,
          isDueTodayActive: !prev.isDueTodayActive,
          isOverDueActive: false,
          isUpComingActive: false,
        }));
        break;
      case "overDue":
        setButtonsFilterStatus((prev) => ({
          ...prev,
          isDueToday: false,
          isOverDue: !prev.isOverDue,
          isUpComing: false,
        }));
        setButtonActive((prev) => ({
          ...prev,
          isDueTodayActive: false,
          isOverDueActive: !prev.isOverDueActive,
          isUpComingActive: false,
        }));
        break;
      case "upComing":
        setButtonsFilterStatus((prev) => ({
          ...prev,
          isDueToday: false,
          isOverDue: false,
          isUpComing: !prev.isUpComing,
        }));
        setButtonActive((prev) => ({
          ...prev,
          isDueTodayActive: false,
          isOverDueActive: false,
          isUpComingActive: !prev.isUpComingActive,
        }));
    }
  }

  const filterButtons = [
    {
      label: "Due Today",
      value: "dueToday",
      isActive: buttonActive.isDueTodayActive,
      onClick: updateDueTimeButtons,
    },
    {
      label: "Overdue",
      value: "overDue",
      isActive: buttonActive.isOverDueActive,
      onClick: updateDueTimeButtons,
    },
    {
      label: "Upcoming",
      value: "upComing",
      isActive: buttonActive.isUpComingActive,
      onClick: updateDueTimeButtons,
    },
  ];

  // useEffect(() => {
  //   setFilters((prevFilters) => ({
  //     ...prevFilters,
  //     projectId: {
  //       ...prevFilters.projectId,
  //       options: memoizedProjectsOptions,
  //     },
  //   }));
  // }, [memoizedProjectsOptions]);

  useEffect(() => {
    resetPaginationAndGetFirstPageResults();
  }, [filters, buttonsFilterStatus, filterValues]);

  const navigateToEditPage = (mri: any) => {
    const path = `${routePaths.MATERIAL_RECEIPT_INSPECTION_EDIT_BY_ID}/${mri?.project?.id}/${mri?.id}`;

    if (isInsideReports || new URLSearchParams(location.search).size > 0) {
      navigate(path, {
        state: {
          previousPath: `${location.pathname}${location.search}`,
        },
      });
    } else {
      navigate(path);
    }
  };

  const columns: TableProps["columns"] = [
    {
      title: "Title",
      dataIndex: "title",
      key: "title",
      sorter: (a, b) => a.title?.localeCompare(b.title),
      render: (_, record) => (
        <HighlightedText text={record?.title} searchTerm={searchTerm} />
      ),
    },
    {
      title: "Project",
      dataIndex: "project",
      key: "project",
      sorter: (a, b) =>
        (a.project?.name || "").localeCompare(b.project?.name || ""),
      render: (_, record) => (
        <HighlightedText
          text={record.project?.name || ""}
          searchTerm={searchTerm}
        />
      ),
    },
    {
      title: "Original Location",
      dataIndex: "projectLocation",
      key: "projectLocation",
      sorter: (a, b) =>
        (a.projectLocation?.id || "").localeCompare(
          b.projectLocation?.id || ""
        ),
      render: (_, record) => (
        <HighlightedText
          text={record.location?.name || ""}
          searchTerm={searchTerm}
        />
      ),
    },

    {
      title: "P.O. Number",
      dataIndex: "poNumber",
      key: "poNumber",
      sorter: (a, b) => a.purchaseOrderId?.localeCompare(b.purchaseOrderId),
      render: (_, record) => {
        return (
          <Typography
            style={{
              fontSize: getConsistentSpacing(1.75),
              margin: 0,
            }}
          >
            <span className="text-primary font-medium">
              {record.purchaseOrder.purchaseOrderNumber}
            </span>
          </Typography>
        );
      },
    },
    {
      title: "Expected Date",
      dataIndex: "expectedDate",
      key: "expectedDate",
      sorter: (a, b) =>
        dayjs(a.expectedDate).unix() - dayjs(b.expectedDate).unix(),
      render: (_, record) => dayjs(record.expectedDate).format(dateFormat),
    },
    {
      title: "Received Date",
      dataIndex: "requestedDate",
      key: "requestedDate",
      sorter: (a, b) =>
        dayjs(a.requestedDate).unix() - dayjs(b.requestedDate).unix(),
      render: (_, record) =>
        !record?.requestedDate
          ? ""
          : dayjs(record.requestedDate).format(dateFormat),
    },
    {
      title: "Status",
      dataIndex: "status",
      key: "status",
      sorter: (a, b) => (a.status || 0) - (b.status || 0),
      render: (_, record) => {
        const { badgeType } = getMaterialReceiptInspectionStatus(record.status);
        return (
          <Typography
            style={{ fontSize: getConsistentSpacing(1.75), margin: 0 }}
          >
            <MaterialReceiptInspectionStatus badgeType={badgeType} />
          </Typography>
        );
      },
    },
    {
      title: "",
      dataIndex: "",
      key: "",
      render: (_, record) =>
        !isInsideReports && (
          <Button
            shape="circle"
            className="hover:!fill-primary"
            icon={<CustomIcon type="edit" />}
            onClick={() => navigateToEditPage(record)}
          />
        ),
    },
  ];

  const handleGetResults = useDebouncedCallback(getResults, 100);

  async function getResults(pageNumber?: number) {
    const status =
      filters.status?.value !== allMaterialReceiptInspectionsStatusOption?.value
        ? (filters?.status?.value as number)
        : undefined;

    const projectId =
      filters.projectId?.value !== memoizedProjectsOptions[0]?.value
        ? filters?.projectId?.value?.toString()
        : undefined;

    const isDueToday = buttonsFilterStatus.isDueToday
      ? buttonsFilterStatus.isDueToday.toString()
      : undefined;

    const isOverDue = buttonsFilterStatus.isOverDue
      ? buttonsFilterStatus.isOverDue.toString()
      : undefined;

    const isUpComing = buttonsFilterStatus.isUpComing
      ? buttonsFilterStatus.isUpComing.toString()
      : undefined;

    const reportFilters = isInsideReports ? filterValues : {};

    const res = await dispatch(
      getAllMaterialReceiptInspections({
        isForReport: isInsideReports,
        search: searchTerm || undefined,
        pageNumber: pageNumber || page,
        pageSize,
        isOverDue,
        isDueToday,
        isUpComing,
        projectId: reportFilters?.projectId || projectId,
        locationId: reportFilters?.locationId || undefined,
        purchaseOrderId: reportFilters?.purchaseOrderId || undefined,
        status: getFirstValidNumber(reportFilters?.status, status),
        materialType: getFirstValidNumber(
          reportFilters?.materialType,
          undefined
        ),
        originalLocationId: reportFilters?.originalLocationId || undefined,
        destinationLocationId:
          reportFilters?.destinationLocationId || undefined,
        transferDateFrom: reportFilters?.transferDate?.[0] || undefined,
        transferDateTo: reportFilters?.transferDate?.[1] || undefined,
        requestedDateFrom: reportFilters?.requestedDate?.[0] || undefined,
        requestedDateTo: reportFilters?.requestedDate?.[1] || undefined,
      })
    ).unwrap();

    if (typeof setReportStats === "function") {
      setReportStats({
        totalInspections: res?.totalCount || 0,
        totalRejected: res?.totalRejected || 0,
        totalApproved: res?.totalApproved || 0,
        totalApprovedWithExceptions: res?.totalApprovedWithExceptions || 0,
        totalPending: res?.totalPending || 0,
        totalTransferred: res?.totalTransferred || 0,
      });
    }
  }

  function resetPaginationAndGetFirstPageResults() {
    if (isFirstCallComplete?.current === true) {
      if (filters) {
        setPage(1);
      }

      handleGetResults(1);
    } else {
      handleGetResults();
    }
  }

  useEffect(() => {
    if (!hasSearched) return;
    const timer = setTimeout(() => {
      if (searchTerm === "" && previousSearchTerm !== "") {
        resetPaginationAndGetFirstPageResults();
        setPreviousSearchTerm(searchTerm);
      }
    }, 500);

    return () => {
      clearTimeout(timer);
    };
  }, [searchTerm, hasSearched, previousSearchTerm]);

  const handleSearch = () => {
    if (searchTerm !== previousSearchTerm) {
      setHasSearched(true);
      resetPaginationAndGetFirstPageResults();
      setPreviousSearchTerm(searchTerm);
    }
  };

  useEffect(() => {
    if (
      !isFirstCallComplete?.current ||
      materialReceiptInspectionCurrentPage !== page ||
      materialReceiptInspectionPageSize !== pageSize
    ) {
      handleGetResults();

      if (!isFirstCallComplete?.current) {
        setTimeout(() => {
          isFirstCallComplete.current = true;
        }, 1000);
      }
    }
  }, [page, pageSize]);

  return (
    <>
      <SectionLayout isHidden={isInsideReports}>
        <CustomTable
          data={MaterialReceiptInspectionData || []}
          columns={columns || []}
          searchTerm={searchTerm}
          setSearchTerm={setSearchTerm}
          handleSearch={handleSearch}
          isLoading={isLoading}
          totalCount={totalCount}
          page={page}
          setPage={setPage}
          pageSize={pageSize}
          setPageSize={setPageSize}
          filterElements={
            !isInsideReports && (
              <CustomTableFilters
                filters={filters}
                setFilters={setFilters}
                buttons={filterButtons}
              />
            )
          }
          hasPagination={true}
          exportButtonEl={exportButtonEl}
          isInsideReports={isInsideReports}
          hasCursorPointer={isInsideReports}
          onRowClick={
            isInsideReports ? (co) => navigateToEditPage(co) : undefined
          }
          tableFilters={filters}
          reportFilterForParamsUseOnly={
            isInsideReports ? filterValues : undefined
          }
          setTableFilters={!isInsideReports ? setFilters : undefined}
          lastSearchTimestamp={lastSearchTimestamp}
          dueTimeButtons={filterButtons?.map((m) => ({
            ...m,
            isActive:
              m.value === "dueToday"
                ? buttonActive.isDueTodayActive
                : m.value === "overDue"
                ? buttonActive.isOverDueActive
                : buttonActive.isUpComingActive,
          }))}
          updateDueTimeButtons={updateDueTimeButtons}
        />
      </SectionLayout>
    </>
  );
}
