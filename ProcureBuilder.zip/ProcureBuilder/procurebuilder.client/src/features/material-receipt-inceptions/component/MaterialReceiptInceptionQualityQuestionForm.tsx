import { useAppSelector } from "@/src/hooks/useAppSelector";
import SectionLayout from "@components/layout/SectionLayout";
import { useAppDispatch } from "@hooks/useAppDispatch";
import { getConsistentSpacing } from "@utils/theme-helpers";
import { Button, Col, Flex, Form, Input, Row, Typography } from "antd";
import * as Yup from "yup";
import {
  getAnswersState,
  resetState,
} from "@/src/store/slices/qualityAnswersSlice";
import {
  QualityAnswersRequestType,
  MaterialReceiptInspection,
  QualityQuestion,
} from "@/src/utils/types";
import CreatedByUserBadge from "@/src/components/common/CreatedByUserBadge";
import CustomAlert from "@/src/components/common/CustomAlert";
import { useEffect, useState } from "react";
import { Controller, Resolver, useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import {
  createQualityAnswers,
  updateQualityAnswers,
  deleteQualityAnswers,
} from "@/src/apis/qualityAnswers";
import routePaths from "@/src/utils/routePaths";
import { useNavigate } from "react-router-dom";
import { updateMriAnswersByMriId } from "@/src/store/slices/materialReceiptInceptionSlice";
import { MaterialGoingToSiteStatusEnum } from "@/src/utils/enums";

type QualityQuestionDetailsFormProps = {
  materialReceiptInspection?: MaterialReceiptInspection | null;
  questions?: QualityQuestion[] | null;
  handleCancelForm: () => void;
};

export default function QualityQuestionsForm({
  questions,
  handleCancelForm,
  materialReceiptInspection,
}: QualityQuestionDetailsFormProps) {
  const dispatch = useAppDispatch();
  const navigate = useNavigate();
  const [actionType, setActionType] = useState("");
  const [isDeleting, setIsDeleting] = useState(false);
  const [shouldDisable, setShouldDisable] = useState(false);
  const [validationError, setValidationError] = useState("");
  const { resError, reqError, successMessage } =
    useAppSelector(getAnswersState);

  const validationSchema = Yup.object().shape({
    answers: Yup.array()
      .of(
        Yup.object({
          answer: Yup.string().required("All Answers are required."),
        })
      )
      .min(Number(questions?.length), "All Answers are required.")
      .required("All Answers are required."),
  });

  console.log("materialReceiptInspection", materialReceiptInspection);

  const getDefaultValues = (
    materialReceiptInspection: MaterialReceiptInspection | null
  ) => {
    return {
      materialReceiptInspectionId: materialReceiptInspection?.id || null,
      answers:
        materialReceiptInspection?.qualityQuestions?.map((value, index) => ({
          id: value?.id || null,
          answer: value?.answer || "",
          question: value?.question || "",
          qualityQuestionId:
            questions?.[index]?.id || value?.qualityQuestionId || null,
        })) || [],
    };
  };

  const {
    handleSubmit,
    control,
    reset,
    getValues,
    formState: { errors, isSubmitting },
  } = useForm<QualityAnswersRequestType>({
    resolver: yupResolver(
      validationSchema
    ) as unknown as Resolver<QualityAnswersRequestType>,
    defaultValues: getDefaultValues(materialReceiptInspection || null),
  });

  const handleSave = async (data: QualityAnswersRequestType) => {
    setValidationError("");

    const payload = {
      materialReceiptInspectionId: materialReceiptInspection?.id || null,
      answers: data?.answers?.map((answer, index) => ({
        id: answer?.id,
        answer: answer?.answer,
        qualityQuestionId: questions?.[index]?.id || answer?.qualityQuestionId,
      })),
      modifiedBy: data?.modifiedBy || "",
    };

    try {
      let response;
      if (materialReceiptInspection?.qualityQuestions?.length) {
        response = await dispatch(
          updateQualityAnswers({
            ...payload,
          })
        ).unwrap();
        return response;
      } else {
        response = await dispatch(
          createQualityAnswers({
            ...payload,
          })
        ).unwrap();
        return response;
      }
    } catch (error) {
      console.error("Error during save:", error);
      setValidationError("An error occurred while submitting the Answers.");
    }
  };

  const onSubmit = async (data: QualityAnswersRequestType) => {
    try {
      if (actionType === "save") {
        const res = await handleSave(data);
        if (res?.isSuccess) {
          const answers = res?.qualityAnswers || [];
          if (materialReceiptInspection?.id && answers?.length > 0) {
            dispatch(
              updateMriAnswersByMriId({
                mriId: materialReceiptInspection?.id,
                answers: res?.qualityAnswers || [],
              })
            );
          }
          setShouldDisable(true);
        }
      } else if (actionType === "saveAndClose") {
        const res = await handleSave(data);
        if (res?.isSuccess) {
          handleCancelForm();
          const answers = res?.qualityAnswers || [];
          if (materialReceiptInspection?.id && answers?.length > 0) {
            dispatch(
              updateMriAnswersByMriId({
                mriId: materialReceiptInspection?.id,
                answers: res?.qualityAnswers || [],
              })
            );
          }
          setShouldDisable(true);
        }
      }
    } catch (error) {
      console.error("Error during form submission:", error);
    }
  };

  type DeleteAnswersFunctionArgs = {
    id: string | null | undefined;
  };

  async function handleDeleteAnswersById({ id }: DeleteAnswersFunctionArgs) {
    if (id) {
      try {
        setIsDeleting(true);
        const response = await dispatch(
          deleteQualityAnswers({
            materialReceiptInspectionId: id,
          })
        ).unwrap();
        if (response.isSuccess) {
          navigate(routePaths.MATERIAL_RECEIPT_INSPECTION);
        } else {
          console.error("Failed to Delete Quality Answers:", response);
        }
      } catch (error) {
        console.error("Error Deleting Quality Answers:", error);
      } finally {
        setIsDeleting(false);
      }
    } else {
      console.warn("Material Receipt Inspection not found!");
    }
  }

  useEffect(() => {
    if (!materialReceiptInspection) return;
    const QualityAnswersValues = getDefaultValues(
      materialReceiptInspection || null
    );
    if (
      materialReceiptInspection.qualityQuestions?.length &&
      materialReceiptInspection.status !== MaterialGoingToSiteStatusEnum.PENDING
    ) {
      setShouldDisable(true);
    }
    reset(QualityAnswersValues);
  }, [materialReceiptInspection, reset]);

  useEffect(() => {
    dispatch(resetState());
  }, []);

  return (
    <>
      <SectionLayout>
        <Form
          onFinish={handleSubmit(onSubmit)}
          disabled={
            shouldDisable &&
            (materialReceiptInspection?.status ===
              MaterialGoingToSiteStatusEnum.CANCELLED ||
              materialReceiptInspection?.status ===
                MaterialGoingToSiteStatusEnum.INPROGRESS ||
              materialReceiptInspection?.status ===
                MaterialGoingToSiteStatusEnum.TRANSFERRED)
          }
          layout="vertical"
          autoComplete="off"
        >
          <Row gutter={parseInt(getConsistentSpacing(2))}>
            <Col xs={24} style={{ marginBottom: getConsistentSpacing(2) }}>
              <Typography.Title level={5} className="flex items-center">
                Quality Questions
              </Typography.Title>
            </Col>
          </Row>
          {/* Questions and Ansers Input */}
          {questions &&
            questions?.map((question, index) => (
              <Form.Item
                key={question?.id}
                initialValue={getValues(`answers.${index}.answer`)}
                validateStatus={errors.answers?.[index]?.answer ? "error" : ""}
                help={errors.answers?.[index]?.answer?.message || ""}
              >
                <Col xs={24} className="mt-5">
                  <Controller
                    name={`answers.${index}.answer`}
                    control={control}
                    render={({ field }) => (
                      <div className="border rounded-xl border-neutral-5 w-full">
                        <p className="py-4 px-3 bg-neutral-1 font-normal text-sm rounded-t-xl">
                          {question?.question}
                        </p>
                        <Input.TextArea
                          {...field}
                          value={field.value}
                          onChange={(e) => field.onChange(e.target.value)}
                          className="rounded-xl px-5 py-3 placeholder:text-neutral-7"
                          placeholder="Write your answer here..."
                          rows={5}
                        />
                      </div>
                    )}
                  />
                </Col>
              </Form.Item>
            ))}
          {/* Validation handling of Submitting Form*/}
          {validationError && (
            <CustomAlert message={validationError || ""} type="error" />
          )}
          {/* Validation handling */}
          {!validationError && (reqError || resError || successMessage) && (
            <CustomAlert
              message={resError || successMessage || ""}
              type={successMessage ? "success" : "error"}
            />
          )}

          {/* Form Buttons */}
          <Flex justify="flex-end" className="gap-4 mt-5 mb-5">
            <Button
              disabled={isSubmitting || isDeleting}
              type="default"
              onClick={handleCancelForm}
            >
              Cancel
            </Button>
            {Boolean(materialReceiptInspection?.qualityQuestions?.length) && (
              <Button
                loading={isDeleting}
                disabled={
                  (shouldDisable &&
                    (materialReceiptInspection?.status ===
                      MaterialGoingToSiteStatusEnum.CANCELLED ||
                      materialReceiptInspection?.status ===
                        MaterialGoingToSiteStatusEnum.INPROGRESS ||
                      materialReceiptInspection?.status ===
                        MaterialGoingToSiteStatusEnum.TRANSFERRED)) ||
                  isSubmitting ||
                  isDeleting
                }
                type="default"
                onClick={() =>
                  handleDeleteAnswersById({
                    id: materialReceiptInspection?.id,
                  })
                }
              >
                {isDeleting ? "Deleting.." : "Delete"}
              </Button>
            )}
            <Button
              loading={actionType === "save" && isSubmitting}
              disabled={
                (shouldDisable &&
                  (materialReceiptInspection?.status ===
                    MaterialGoingToSiteStatusEnum.CANCELLED ||
                    materialReceiptInspection?.status ===
                      MaterialGoingToSiteStatusEnum.INPROGRESS ||
                    materialReceiptInspection?.status ===
                      MaterialGoingToSiteStatusEnum.TRANSFERRED)) ||
                isSubmitting ||
                isDeleting
              }
              type="primary"
              htmlType="submit"
              onClick={() => setActionType("save")}
            >
              {actionType === "save" && isSubmitting ? "Saving.." : "Save"}
            </Button>

            <Button
              loading={actionType === "saveAndClose" && isSubmitting}
              disabled={
                (shouldDisable &&
                  (materialReceiptInspection?.status ===
                    MaterialGoingToSiteStatusEnum.CANCELLED ||
                    materialReceiptInspection?.status ===
                      MaterialGoingToSiteStatusEnum.INPROGRESS ||
                    materialReceiptInspection?.status ===
                      MaterialGoingToSiteStatusEnum.TRANSFERRED)) ||
                isSubmitting ||
                isDeleting
              }
              type="primary"
              htmlType="submit"
              onClick={() => setActionType("saveAndClose")}
            >
              {actionType === "saveAndClose" && isSubmitting
                ? "Saving and closing.."
                : "Save & Close"}
            </Button>
          </Flex>

          {/* Custom Badge */}
          {materialReceiptInspection?.createdBy &&
            materialReceiptInspection?.createdDate && (
              <Flex justify="flex-end">
                <CreatedByUserBadge
                  userName={materialReceiptInspection?.createdBy as string}
                  date={materialReceiptInspection.createdDate as Date}
                  isUpdatedBadge
                />
              </Flex>
            )}
        </Form>
      </SectionLayout>
    </>
  );
}
