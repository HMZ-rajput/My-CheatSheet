import CreatedByUserBadge from "@/src/components/common/CreatedByUserBadge";
import CustomAlert from "@/src/components/common/CustomAlert";
import SectionLayout from "@/src/components/layout/SectionLayout";
import { useAppDispatch } from "@/src/hooks/useAppDispatch";
import { useAppSelector } from "@/src/hooks/useAppSelector";
import {
  getMaterialReceiptInspectionState,
  resetState,
} from "@/src/store/slices/materialReceiptInceptionSlice";
import { FilesDocumentTypeEnum } from "@/src/utils/enums";
import { filterFileDocumentsByType } from "@/src/utils/helper";
import {
  Attachment,
  MaterialReceiptInspectionMaterialPhoto,
  MaterialReceiptInspection,
} from "@/src/utils/types";
import CustomIcon from "@components/common/CustomIcon";
import { getConsistentSpacing } from "@utils/theme-helpers";
import { Button, Flex, Form, Typography } from "antd";
import { useState, useEffect } from "react";
import { MaterialImagesValidationSchemna } from "@/src/data/validationsSchema";
import { Controller, Resolver, useForm } from "react-hook-form";
import CustomFileUploadRHF from "@/src/components/common/CustomFileUploadRHF";
import { yupResolver } from "@hookform/resolvers/yup";
import {
  editMaterialPhotoById,
  deleteMaterialImageById,
} from "@/src/apis/materialReceiptInceptionApis";
import { useNavigate } from "react-router-dom";
import routePaths from "@/src/utils/routePaths";

type MaterialPhotosFormProps = {
  materialReceiptInspection: MaterialReceiptInspection | null;
  handleCancelForm: () => void;
};
export default function MaterialPhotosForm({
  materialReceiptInspection,
  handleCancelForm,
}: MaterialPhotosFormProps) {
  type FieldType = MaterialReceiptInspectionMaterialPhoto;
  const navigate = useNavigate();
  const dispatch = useAppDispatch();
  const [isDeleting, setIsDeleting] = useState(false);
  const [validationError, setValidationError] = useState("");
  const { successMessage, resError, reqError } = useAppSelector(
    getMaterialReceiptInspectionState
  );
  const [actionType, setActionType] = useState<"save" | "saveAndClose" | "">(
    ""
  );

  const getDefaultValues = (
    materialReceiptInspection: MaterialReceiptInspection | null
  ) => {
    return {
      materialReceiptInspectionId: materialReceiptInspection?.id || null,
      materialImages: filterFileDocumentsByType(
        materialReceiptInspection?.documents || [],
        FilesDocumentTypeEnum.MATERIALIMAGE
      ),
      deleteDocumentIds: [],
    };
  };

  const {
    control,
    reset,
    handleSubmit,
    setValue,
    getValues,
    formState: { errors, isSubmitting },
  } = useForm<FieldType>({
    resolver: yupResolver(
      MaterialImagesValidationSchemna
    ) as unknown as Resolver<FieldType>,
    defaultValues: getDefaultValues(materialReceiptInspection),
    shouldUnregister: false,
  });

  const onSubmit = async (values: FieldType) => {
    console.log("values", values);
    setValidationError("");
    const formData = new FormData();
    formData.append(
      "materialReceiptInspectionId",
      materialReceiptInspection?.id || ("" as string)
    );

    if (Array.isArray(values?.materialImages)) {
      values?.materialImages?.forEach((file: Attachment) => {
        if (file?.originFileObj) {
          formData.append("materialImages", file?.originFileObj);
        }
      });
    }

    if (Array.isArray(values?.deleteDocumentIds)) {
      const filteredDeleteDocumentIds = values?.deleteDocumentIds?.filter(
        (id: string) => !id?.startsWith("rc-upload-")
      );
      filteredDeleteDocumentIds?.forEach((id) => {
        formData.append("deleteDocumentIds", id);
      });
    }

    try {
      if (materialReceiptInspection?.id) {
        const response = await dispatch(
          editMaterialPhotoById({
            payload: formData,
            id: materialReceiptInspection?.id,
          })
        ).unwrap();
        if (response?.isSuccess) {
          if (actionType === "saveAndClose") {
            handleCancelForm();
          }
        }
      }
    } catch (error) {
      console.error("Error submitting form:", error);
      setValidationError("An error occurred while submitting the form.");
    }
  };

  type DeleteMaterialImagesFunctionArgs = {
    id: string | undefined;
  };
  async function handleDeleteMaterialReceiptInctionById({
    id,
  }: DeleteMaterialImagesFunctionArgs) {
    if (id) {
      try {
        setIsDeleting(true);
        const res = await dispatch(
          deleteMaterialImageById({
            id,
          })
        ).unwrap();
        if (res.isSuccess) {
          navigate(routePaths.MATERIAL_RECEIPT_INSPECTION);
        }
      } catch (error) {
        console.error("Error Deleting Materials Images:", error);
      } finally {
        setIsDeleting(false);
      }
    }
  }

  useEffect(() => {
    if (!materialReceiptInspection) return;
    const materialReceiptInspectionValues = getDefaultValues(
      materialReceiptInspection
    );
    reset(materialReceiptInspectionValues);
  }, [materialReceiptInspection, reset]);

  useEffect(() => {
    dispatch(resetState());
  }, [dispatch]);

  return (
    <>
      <SectionLayout>
        <Form
          onFinish={handleSubmit(onSubmit)}
          layout="vertical"
          autoComplete="off"
        >
          {/* Material Photos */}
          <Typography.Title level={5}>Material Photos</Typography.Title>
          <SectionLayout
            className="rounded-xl flex items-center max-h-full min-h-52 my-5"
            borderStyle="dashed"
          >
            <div className="flex flex-col justify-center items-center max-h-full min-h-52 p-8">
              <div className="mb-4">
                <CustomIcon type="add-file" className="fill-white" />
              </div>

              <h6 className="font-medium text-sm !mb-2">
                Select a file to import
              </h6>

              <Flex justify="center" gap={5} className="mt-2">
                <Controller
                  control={control}
                  name="materialImages"
                  render={({ field }) => (
                    <Form.Item<FieldType>
                      labelAlign="right"
                      initialValue={field.value}
                      required
                      validateStatus={errors.materialImages ? "error" : ""}
                      help={errors.materialImages?.message}
                    >
                      <CustomFileUploadRHF
                        setValue={setValue}
                        getValues={getValues}
                        fieldName={field.name}
                        deletedFileName="deleteDocumentIds"
                        buttonText="Browse Images"
                        maxCount={20}
                        hasOnlyImages
                      />
                    </Form.Item>
                  )}
                />
              </Flex>
            </div>
          </SectionLayout>

          {/* Validation handling of Submitting Form*/}
          {validationError && (
            <CustomAlert message={validationError || ""} type="error" />
          )}

          {/* Validation handling */}
          {!validationError && (reqError || resError || successMessage) && (
            <CustomAlert
              message={resError || successMessage || ""}
              type={successMessage ? "success" : "error"}
            />
          )}

          {/* Form Buttons */}
          <Flex
            justify="flex-end"
            className="mt-8 mb-5"
            gap={parseInt(getConsistentSpacing(2))}
          >
            <Button
              disabled={isSubmitting || isDeleting}
              type="default"
              onClick={handleCancelForm}
            >
              Cancel
            </Button>
            {Boolean(materialReceiptInspection?.id) && (
              <Button
                loading={isDeleting}
                disabled={isSubmitting || isDeleting}
                type="default"
                onClick={() =>
                  handleDeleteMaterialReceiptInctionById({
                    id: materialReceiptInspection?.id,
                  })
                }
              >
                {isDeleting ? "Deleting.." : "Delete"}
              </Button>
            )}
            <Button
              loading={actionType === "save" && isSubmitting}
              disabled={isSubmitting || isDeleting}
              type="primary"
              htmlType="submit"
              onClick={() => setActionType("save")}
            >
              {actionType === "save" && isSubmitting ? "Saving.." : "Save"}
            </Button>

            <Button
              loading={actionType === "saveAndClose" && isSubmitting}
              disabled={isSubmitting || isDeleting}
              type="primary"
              htmlType="submit"
              onClick={() => setActionType("saveAndClose")}
            >
              {actionType === "saveAndClose" && isSubmitting
                ? "Saving and closing.."
                : "Save & Close"}
            </Button>
          </Flex>

          {/* Edited Badge */}
          {materialReceiptInspection?.createdBy &&
            materialReceiptInspection?.createdDate && (
              <Flex justify="flex-end">
                <CreatedByUserBadge
                  userName={materialReceiptInspection?.createdBy as string}
                  date={materialReceiptInspection?.createdDate as Date}
                  isUpdatedBadge
                />
              </Flex>
            )}
        </Form>
      </SectionLayout>
    </>
  );
}
