import DeleteIconButton from "@/src/components/icon-buttons/DeleteIconButton";
import { MaterialGoingToSiteStatusEnum } from "@/src/utils/enums";
import { Material } from "@/src/utils/types";
import { Form, Input, InputNumber, Select } from "antd";
import React, { useEffect, useRef } from "react";
import {
  Control,
  Controller,
  FieldErrorsImpl,
  UseFormGetValues,
  UseFormSetValue,
} from "react-hook-form";
import { VariableSizeList as List } from "react-window";

type Props = {
  control: Control<Material | any>;
  materialFields: Material[] | any;
  fetchMaterialOptions: any;
  getValues: UseFormGetValues<Material | any>;
  deleteMaterial: any;
  isButtonDisabled: boolean;
  setValue: UseFormSetValue<Material | any>;
  newMaterials: Material[] | any;
  // handleUpdateTotalQty: () => void;
  errors: FieldErrorsImpl<Material> | any;
};

const MRIMaterialList = ({
  control,
  errors,
  newMaterials,
  materialFields,
  setValue,
  fetchMaterialOptions,
  getValues,
  deleteMaterial,
  // handleUpdateTotalQty,
  isButtonDisabled,
}: Props) => {
  const listRef = useRef<List>(null);
  const previousLength = useRef(materialFields.length);
  const MAX_HEIGHT = 600;
  const estimatedItemHeight = 100;
  const listHeight = Math.min(
    materialFields.length * estimatedItemHeight,
    MAX_HEIGHT
  );

  const handleMaterialChange = async (value: string, index: number) => {
    const selectedMaterial = newMaterials?.find(
      (f: Material) => f?.name == value
    );
    setValue(`materials.${index}`, {
      id: "",
      name: "",
      spares: 0,
      samples: 0,
      regular: 0,
      quantity: 0,
      totalQuantity: 0,
      totalSamples: 0,
      totalSpares: 0,
      totalRegular: 0,
      unitOfMeasure: "",
    });
    setValue(`materials.${index}.name`, value);
    setValue(
      `materials.${index}.totalQuantity`,
      selectedMaterial?.totalQuantity || 0
    );
    setValue(
      `materials.${index}.quantity`,
      selectedMaterial?.totalQuantity ||
        getValues(`materials.${index}.totalQuantity`) ||
        0
    );
    // setValue(
    //   `materials.${index}.totalSamples`,
    //   selectedMaterial?.totalSamples || 0
    // );
    // setValue(
    //   `materials.${index}.samples`,
    //   selectedMaterial?.totalSamples ||
    //     getValues(`materials.${index}.samples`) ||
    //     0
    // );
    // setValue(
    //   `materials.${index}.totalSpares`,
    //   selectedMaterial?.totalSpares || 0
    // );
    // setValue(`materials.${index}.spares`, selectedMaterial?.totalSpares || 0);
    // setValue(
    //   `materials.${index}.totalRegular`,
    //   selectedMaterial?.totalRegular || 0
    // );
    // setValue(`materials.${index}.regular`, selectedMaterial?.totalRegular || 0);
    setValue(
      `materials.${index}.unitOfMeasure`,
      selectedMaterial?.unitOfMeasure || ""
    );
  };

  const scrollToError = (index: number) => {
    if (listRef.current) {
      listRef.current.scrollToItem(index, "center");
    }
  };

  useEffect(() => {
    const firstErrorIndex = materialFields?.findIndex(
      (_: any, index: number) => {
        const materialError = errors?.materials?.[index];
        return (
          materialError?.name ||
          materialError?.costCode ||
          materialError?.unitOfMeasure ||
          materialError?.spares ||
          materialError?.samples ||
          materialError?.regular
        );
      }
    );

    if (firstErrorIndex !== -1 && firstErrorIndex !== undefined) {
      scrollToError(firstErrorIndex);
    }
  }, [errors]);

  useEffect(() => {
    if (listRef.current) {
      if (materialFields.length > previousLength.current) {
        listRef.current.scrollToItem(materialFields.length - 1, "end");
      }
      previousLength.current = materialFields.length;
    }
  }, [materialFields.length]);

  const renderRow = ({
    index,
    style,
  }: {
    index: number;
    style: React.CSSProperties;
  }) => {
    const materials = materialFields[index];

    return (
      <div className="" style={style} key={materials?.id}>
        <div className="materials-first-row flex mb-7" key={materials?.id}>
          {/* Material */}
          <div className="col col-xs-8 mr-3">
            <Controller
              control={control}
              name={`materials[${index}].name`}
              render={({ field, formState: { errors } }) => {
                const materialError = (
                  errors?.materials as unknown as FieldErrorsImpl<Material>[]
                )?.[index];
                return (
                  <Form.Item
                    labelAlign="right"
                    help={materialError?.name?.message}
                    validateStatus={materialError?.name ? "error" : ""}
                    initialValue={field.value}
                  >
                    <Select
                      {...field}
                      value={field.value}
                      onChange={(value) => {
                        field.onChange(value);
                        handleMaterialChange(value, index);
                      }}
                      showSearch
                      size="large"
                      placeholder={"Select Materials"}
                      style={{ width: "100%" }}
                      options={fetchMaterialOptions(index)}
                      filterOption={(input, option) =>
                        (option?.label ?? "")
                          .toLocaleString()
                          .includes(input.toLowerCase())
                      }
                    />
                  </Form.Item>
                );
              }}
            />
          </div>

          {/* Spare */}
          {/* <div className="col pr-4 col-xs-3">
            <Controller
              name={`materials[${index}].spares`}
              control={control}
              render={({ field, formState: { errors } }) => {
                const materialError = (
                  errors?.materials as unknown as FieldErrorsImpl<Material>[]
                )?.[index];
                return (
                  <Form.Item
                    labelAlign="right"
                    validateStatus={materialError ? "error" : ""}
                    help={materialError ? materialError?.spares?.message : ""}
                  >
                    <div className="flex items-center gap-2">
                      <InputNumber
                        type="number"
                        {...field}
                        value={field.value}
                        onChange={(value) => {
                          const newValue = value || 0;
                          setValue(`materials[${index}].spares`, newValue);
                          handleUpdateTotalQty();
                        }}
                        size="large"
                        min={0}
                        max={getValues(`materials.${index}.totalSpares`) ?? 0}
                        style={{ width: "100%" }}
                        placeholder="Spares"
                      />
                      /{getValues(`materials.${index}.totalSpares`) ?? 0}
                    </div>
                  </Form.Item>
                );
              }}
            />
          </div> */}

          {/* Samples */}
          {/* <div className="col pr-4 col-xs-3">
            <Controller
              name={`materials[${index}].samples`}
              control={control}
              render={({ field, formState: { errors } }) => {
                const materialError = (
                  errors?.materials as unknown as FieldErrorsImpl<Material>[]
                )?.[index];
                return (
                  <Form.Item
                    labelAlign="right"
                    required={index === 0}
                    validateStatus={materialError ? "error" : ""}
                    help={materialError ? materialError?.samples?.message : ""}
                  >
                    <div className="flex items-center gap-2">
                      <InputNumber
                        type="number"
                        {...field}
                        onChange={(value) => {
                          // field.onChange(value);
                          const newValue = value || 0;

                          setValue(`materials[${index}].samples`, newValue);
                          handleUpdateTotalQty();
                        }}
                        size="large"
                        min={0}
                        max={getValues(`materials.${index}.totalSamples`) ?? 0}
                        style={{ width: "100%" }}
                        placeholder="Samples"
                      />
                      /{getValues(`materials.${index}.totalSamples`) ?? 0}
                    </div>
                  </Form.Item>
                );
              }}
            />
          </div> */}

          {/* Regular */}
          {/* <div className="col pr-4 col-xs-3">
            <Controller
              name={`materials[${index}].regular`}
              control={control}
              render={({ field, formState: { errors } }) => {
                const materialError = (
                  errors?.materials as unknown as FieldErrorsImpl<Material>[]
                )?.[index];
                return (
                  <Form.Item
                    labelAlign="right"
                    required={index === 0}
                    validateStatus={materialError ? "error" : ""}
                    help={materialError ? materialError?.regular?.message : ""}
                  >
                    <div className="flex items-center gap-2">
                      <InputNumber
                        type="number"
                        {...field}
                        value={field.value}
                        onChange={(value) => {
                          const newValue = value || 0;
                          setValue(`materials[${index}].regular`, newValue);
                          handleUpdateTotalQty();
                        }}
                        size="large"
                        min={0}
                        max={getValues(`materials.${index}.totalRegular`) ?? 0}
                        style={{ width: "100%" }}
                        placeholder="Regular"
                      />
                      /{getValues(`materials.${index}.totalRegular`) ?? 0}
                    </div>
                  </Form.Item>
                );
              }}
            />
          </div> */}

          {/* Quantity */}
          <div className="col pr-4 col-xs-8">
            <Controller
              control={control}
              name={`materials.${index}.quantity`}
              render={({ field, formState: { errors } }) => {
                const materialError = (
                  errors?.materials as unknown as FieldErrorsImpl<Material>[]
                )?.[index];
                return (
                  <Form.Item
                    labelAlign="right"
                    help={materialError?.quantity?.message}
                    validateStatus={materialError?.quantity ? "error" : ""}
                  >
                    <div className="flex items-center gap-2">
                      <InputNumber
                        type="number"
                        {...field}
                        value={field.value}
                        onChange={(value) => {
                          field.onChange(value);
                        }}
                        min={0}
                        max={getValues(`materials.${index}.totalQuantity`) ?? 0}
                        size="large"
                        style={{ width: "100%" }}
                      />
                      /{getValues(`materials[${index}].totalQuantity`) ?? 0}
                    </div>
                  </Form.Item>
                );
              }}
            />
          </div>

          {/* Unit of Measurement */}
          <div className="col pr-4 !grow">
            <Controller
              control={control}
              name={`materials[${index}].unitOfMeasure`}
              render={({ field, formState: { errors } }) => {
                const materialError = (
                  errors?.materials as unknown as FieldErrorsImpl<Material>[]
                )?.[index];
                return (
                  <Form.Item
                    key={index}
                    labelAlign="right"
                    help={!field.value && materialError?.unitOfMeasure?.message}
                    validateStatus={
                      !field.value && materialError?.unitOfMeasure
                        ? "error"
                        : ""
                    }
                  >
                    <Input
                      {...field}
                      value={field.value}
                      onChange={(value) => {
                        setValue(
                          `materials[${index}].unitOfMeasure`,
                          value.target.value
                        );
                      }}
                      size="large"
                      placeholder="FT"
                    />
                  </Form.Item>
                );
              }}
            />
          </div>

          {/* Delete Icon */}
          <div className="col ml-auto col-xs-1">
            <DeleteIconButton
              disabled={
                materialFields.length === 1 ||
                (isButtonDisabled &&
                  (getValues("status") ===
                    MaterialGoingToSiteStatusEnum.CANCELLED ||
                    getValues("status") ===
                      MaterialGoingToSiteStatusEnum.INPROGRESS ||
                    getValues("status") ===
                      MaterialGoingToSiteStatusEnum.TRANSFERRED))
              }
              handleDelete={() => deleteMaterial(index)}
            />
          </div>
        </div>
      </div>
    );
  };

  const getItemSize = () => {
    return 70;
  };

  return (
    <>
      <List
        ref={listRef}
        height={listHeight}
        itemCount={materialFields.length}
        itemSize={getItemSize}
        width="100%"
        className="list-scroll-container"
      >
        {renderRow}
      </List>
    </>
  );
};

export default MRIMaterialList;
