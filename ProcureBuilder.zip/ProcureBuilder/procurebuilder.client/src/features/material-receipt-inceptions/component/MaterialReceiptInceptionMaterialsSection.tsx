import CustomIcon from "@/src/components/common/CustomIcon";
import { MaterialGoingToSiteStatusEnum } from "@/src/utils/enums";
import { capitalizeFirstLetter } from "@/src/utils/helper";
import {
  Material,
  MaterialReceiptInspectionMaterial,
  MaterialReceiptInspection,
} from "@/src/utils/types";
import { Button, Typography } from "antd";
import { useEffect, useMemo } from "react";
import {
  Control,
  FieldErrorsImpl,
  useFieldArray,
  UseFormGetValues,
  UseFormSetValue,
} from "react-hook-form";
import MRIMaterialList from "./MRIMaterialList";

const { Text } = Typography;

type MaterialsFormSectionProps = {
  // handleUpdateTotalQty: () => void;
  materials: MaterialReceiptInspectionMaterial[] | null;
  control: Control<MaterialReceiptInspection>;
  setValue: UseFormSetValue<MaterialReceiptInspection>;
  getValues: UseFormGetValues<MaterialReceiptInspection>;
  isButtonDisabled: boolean;
  errors: FieldErrorsImpl<Material> | any;
};

export default function MaterialsFormSection({
  // handleUpdateTotalQty,
  isButtonDisabled,
  materials,
  control,
  setValue,
  getValues,
  errors,
}: MaterialsFormSectionProps) {
  const {
    fields: materialFields,
    append: appendMaterial,
    remove: removeMaterial,
  } = useFieldArray({
    control,
    name: "materials",
  });

  const deleteMaterial = (index: number) => {
    removeMaterial(index);
    // handleUpdateTotalQty();
  };

  const materialsOptions = useMemo(() => {
    return [
      {
        value: "",
        label: "Select Materials",
      },
      ...(materials?.map((f) => ({
        value: f?.name,
        label: capitalizeFirstLetter(f?.name),
      })) ?? []),
    ];
  }, [materials]);

  const selectedMaterial = getValues("materials").map((f) => f.name);
  console.log(getValues("materials"));
  const fetchMaterialOptions = (index: number) => {
    const currentMaterial = selectedMaterial[index];
    return materialsOptions
      ?.map((option) => ({
        ...option,
        disabled:
          option.value === "" ||
          (option.value !== currentMaterial &&
            selectedMaterial.includes(option.value)),
      }))
      .filter(
        (option) =>
          option.value === currentMaterial ||
          !selectedMaterial.includes(option.value)
      );
  };

  const handleAddMaterial = () => {
    const newMaterial = {
      id: "",
      name: "",
      spares: 0,
      samples: 0,
      regular: 0,
      quantity: 0,
      totalQuantity: 0,
      totalSamples: 0,
      totalSpares: 0,
      totalRegular: 0,
      unitOfMeasure: "",
    };

    appendMaterial(newMaterial);
  };

  useEffect(() => {
    const materials = getValues("materials");

    materials.forEach((material: MaterialReceiptInspectionMaterial, index) => {
      setValue(`materials.${index}.totalQuantity`, material.totalQuantity);
      setValue(`materials.${index}.quantity`, material.quantity);
      setValue(`materials.${index}.totalSamples`, material.totalSamples);
      setValue(`materials.${index}.samples`, material.samples);
      setValue(`materials.${index}.totalSpares`, material.totalSpares);
      setValue(`materials.${index}.spares`, material.spares);
      setValue(`materials.${index}.totalRegular`, material.totalRegular);
      setValue(`materials.${index}.regular`, material.regular);
    });
  }, [getValues("materials")]);

  return (
    <>
      <div className="materials-header-row flex w-full py-1.5 px-2 rounded-lg mb-4 bg-neutral-0">
        <div className="col col-xs-8 mr-3">
          <Text className="font-medium">Material</Text>
        </div>
        {/* <div className="col pr-4 col-xs-3">
          <div className="font-normal">Spares</div>
        </div>
        <div className="col pr-4 col-xs-3">
          <div className="font-normal">Samples</div>
        </div>
        <div className="col pr-4 col-xs-3">
          <div className="font-normal">Regular</div>
        </div> */}
        <div className="col pr-4 col-xs-8">
          <div className="font-normal">Quantity</div>
        </div>
        <div className="col pr-4 !grow">
          <div className="font-normal">Unit of Measurement</div>
        </div>
        <div className="col pr-4 col-xs-1"></div>
      </div>

      <MRIMaterialList
        errors={errors}
        setValue={setValue}
        newMaterials={materials}
        isButtonDisabled={isButtonDisabled}
        control={control}
        materialFields={materialFields}
        deleteMaterial={deleteMaterial}
        getValues={getValues}
        fetchMaterialOptions={fetchMaterialOptions}
        // handleUpdateTotalQty={handleUpdateTotalQty}
      />
      <div className="float-end mt-5">{materialFields.length} Row(s)</div>
      <div>
        <Button
          className="border-0 shadow-none text-primary font-medium mt-5"
          size="small"
          icon={<CustomIcon width={16} type="add-circle" />}
          onClick={handleAddMaterial}
          disabled={
            isButtonDisabled &&
            (getValues("status") === MaterialGoingToSiteStatusEnum.CANCELLED ||
              getValues("status") ===
                MaterialGoingToSiteStatusEnum.INPROGRESS ||
              getValues("status") === MaterialGoingToSiteStatusEnum.TRANSFERRED)
          }
        >
          Add Material
        </Button>
      </div>
    </>
  );
}
