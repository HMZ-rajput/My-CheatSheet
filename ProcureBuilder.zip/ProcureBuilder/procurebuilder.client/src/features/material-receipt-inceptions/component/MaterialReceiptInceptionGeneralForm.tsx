import { getLocationslist as getLocationsList } from "@/src/apis/locationApis";
import {
  createMaterialReceiptInspection,
  deleteMaterialReceiptInspectionById,
  editMaterialReceiptInspectionById,
  getMaterialReceiptInspectionsMaterialList,
} from "@/src/apis/materialReceiptInceptionApis";
import { getSummarizedProjectsList } from "@/src/apis/projectApis";
import { getPurchaseOrdersList } from "@/src/apis/purchaseOrderApis";
import { getAllQuestions } from "@/src/apis/questionApis";
import { getAllStorageTypes } from "@/src/apis/storageTypeApis";
import CreatedByUserBadge from "@/src/components/common/CreatedByUserBadge";
import CustomAlert from "@/src/components/common/CustomAlert";
import CustomFileUploadRHF from "@/src/components/common/CustomFileUploadRHF";
import CustomFormLabel from "@/src/components/common/CustomFormLabel";
import CustomOverlayLoader from "@/src/components/common/CustomOverlayloader";
import CustomFormRow from "@/src/components/form/CustomFormRow";
import SectionLayout from "@/src/components/layout/SectionLayout";
import { MriDefaultMaterialValues } from "@/src/data/intialsValues";
import { MaterialReceiptInspectionValidationSchema } from "@/src/data/validationsSchema";
import LocationModal from "@/src/features/locations/components/LocationModal";
import { useAppDispatch } from "@/src/hooks/useAppDispatch";
import { useAppSelector } from "@/src/hooks/useAppSelector";
import { getLocationsState } from "@/src/store/slices/locationSlice";
import {
  getMaterialReceiptInspectionState,
  resetState,
} from "@/src/store/slices/materialReceiptInceptionSlice";
import { getProjectsState } from "@/src/store/slices/projectsSlice";
import {
  dateFormat,
  MaterialReceiptInspectionsStatusOptions,
} from "@/src/utils/constants";
import {
  ActionTypeEnum,
  FilesDocumentTypeEnum,
  MaterialGoingToSiteStatusEnum,
  MaterialReceiptInspectionStatusEnum,
} from "@/src/utils/enums";
import {
  capitalizeFirstLetter,
  filterFileDocumentsByType,
} from "@/src/utils/helper";
import routePaths from "@/src/utils/routePaths";
import {
  ActionTypeState,
  Attachment,
  MaterialReceiptInspection,
  MaterialReceiptInspectionMaterial,
  PurchaseOrder,
  PurchaseOrdersList,
  QualityQuestion,
} from "@/src/utils/types";
import { PlusOutlined, QuestionCircleOutlined } from "@ant-design/icons";
import CustomIcon from "@components/common/CustomIcon";
import { yupResolver } from "@hookform/resolvers/yup";
import {
  Button,
  Col,
  DatePicker,
  Divider,
  Flex,
  Form,
  Input,
  Select,
  Space,
  Typography,
} from "antd";
import dayjs from "dayjs";
import { useEffect, useMemo, useState } from "react";
import { Controller, Resolver, useForm } from "react-hook-form";
import { useLocation, useNavigate } from "react-router-dom";
import MaterialsFormSection from "../component/MaterialReceiptInceptionMaterialsSection";

type GeneralFormProps = {
  materialReceiptInspection: MaterialReceiptInspection | null;
  handleCancelForm: () => void;
  POData: PurchaseOrder; // This is the location object data from P.O. Details page.
};
export default function GeneralForm({
  materialReceiptInspection: materialReceiptInspectionData,
  handleCancelForm,
  POData,
}: GeneralFormProps) {
  type FieldType = MaterialReceiptInspection;

  const navigate = useNavigate();
  const dispatch = useAppDispatch();
  const locationPath = useLocation();
  const [loading, setLoading] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  const [validationError, setValidationError] = useState("");
  const [shouldDisable, setShouldDisable] = useState(false);
  const [selectedProjectId, setSelectedProjectId] = useState<string | null>();
  const [materialReceiptInspection, setMaterialReceiptInspection] = useState(
    materialReceiptInspectionData
  );

  const [isLocationModalOpen, setIsLocationModalOpen] = useState<{
    open: boolean;
    title?: string | null;
    field?: string;
  }>({ open: false, title: null, field: "" });

  useEffect(() => {
    setMaterialReceiptInspection(materialReceiptInspectionData);
  }, [materialReceiptInspectionData]);
  const [purchaseOrdersList, setPurchaseOrdersList] =
    useState<PurchaseOrdersList[]>();
  const [materialsList, setMaterialsList] = useState<
    MaterialReceiptInspectionMaterial[] | null
  >(materialReceiptInspection?.materials || null);
  const { successMessage, resError, reqError } = useAppSelector(
    getMaterialReceiptInspectionState
  );

  const [actionType, setActionType] = useState<ActionTypeState>({
    delete: ActionTypeEnum.NEUTRAL, // Default to SAVE state (0)
    approve: ActionTypeEnum.NEUTRAL,
    saveAndClose: ActionTypeEnum.NEUTRAL,
    save: ActionTypeEnum.NEUTRAL,
    cancel: ActionTypeEnum.NEUTRAL,
    approvedWithExceptions: ActionTypeEnum.NEUTRAL,
    rejected: ActionTypeEnum.NEUTRAL,
  });

  useEffect(() => {
    dispatch(getSummarizedProjectsList());
  }, [dispatch]);

  const { projectsSummarizedData } = useAppSelector(getProjectsState);
  const memoizedProjectsOptions = useMemo(() => {
    return [
      {
        value: "",
        label: "Select Project",
      },
      ...(projectsSummarizedData?.map((f) => ({
        value: f?.id,
        label: f?.name,
      })) || []),
    ];
  }, [projectsSummarizedData]);

  const { locationsList } = useAppSelector(getLocationsState);
  const memoizedLocationOptions = useMemo(() => {
    return [
      {
        value: "",
        label: "Select Location",
      },
      ...(locationsList?.map((f) => ({
        value: f?.id,
        label: f?.name,
      })) || []),
    ];
  }, [locationsList]);

  const memoizedPurchaseOrderNoOptions = useMemo(() => {
    return [
      {
        value: "",
        label: "Select Purchase Order",
      },
      ...(purchaseOrdersList?.map((f) => ({
        value: f?.id,
        label: capitalizeFirstLetter(f?.purchaseOrderNumber),
      })) || []),
    ];
  }, [purchaseOrdersList]);

  const getPurchaseOrderbyProjectId = async (value: string | null) => {
    try {
      const response = await dispatch(
        getPurchaseOrdersList({
          projectId: value || "",
          isForMRI: true,
          MRIStatus: getValues("status"),
        })
      ).unwrap();
      setPurchaseOrdersList(response?.purchaseOrders);
    } catch (err) {
      console.error("err", err);
    }
  };

  useEffect(() => {
    if (selectedProjectId || POData?.purchaseOrderProject?.id) {
      getPurchaseOrderbyProjectId(
        selectedProjectId || POData?.purchaseOrderProject?.id
      );
      dispatch(
        getLocationsList(selectedProjectId || POData?.purchaseOrderProject?.id)
      );
    }
  }, [selectedProjectId, dispatch, POData]);

  const getDefaultValues = (
    materialReceiptInspection: MaterialReceiptInspection | null
  ) => {
    return {
      id: materialReceiptInspection?.id || "",
      purchaseOrderId: materialReceiptInspection?.purchaseOrder?.id || null,
      title: materialReceiptInspection?.title || "",
      billOfLanding: filterFileDocumentsByType(
        materialReceiptInspection?.documents || [],
        FilesDocumentTypeEnum.BILLOFLANDING
      ),
      deleteBillOfLandingId: "",
      expectedDate: dayjs(
        materialReceiptInspection?.expectedDate || new Date()
      ),
      requestedDate: dayjs(
        materialReceiptInspection?.requestedDate ||
          materialReceiptInspection?.expectedDate ||
          new Date()
      ),
      projectId: materialReceiptInspection?.project?.id || null,
      projectLocationId: materialReceiptInspection?.location?.id || null,
      subLocationId: materialReceiptInspection?.subLocation?.id || null,
      status: materialReceiptInspection?.status || 0,
      qualityQuestions: materialReceiptInspection?.qualityQuestions || [],
      materials:
        materialReceiptInspection?.materials?.map((material) => ({
          id: material?.id || "",
          name: material?.name,
          spares: material?.spares,
          samples: material?.samples,
          regular: material?.regular,
          quantity: material?.quantity,
          totalQuantity: material?.totalQuantity,
          totalSamples: material?.totalSamples,
          totalSpares: material?.totalSpares,
          totalRegular: material?.totalRegular,
          unitOfMeasure: material?.unitOfMeasure,
        })) || MriDefaultMaterialValues,
      lastModifiedBy: materialReceiptInspection?.lastModifiedBy || "",
      lastModifiedDate: materialReceiptInspection?.lastModifiedDate || null,
      createdBy: materialReceiptInspection?.createdBy || "",
      modifiedDate: materialReceiptInspection?.modifiedDate || null,
    };
  };

  const {
    control,
    reset,
    handleSubmit,
    setValue,
    getValues,
    register,
    watch,
    formState: { errors, isSubmitting },
  } = useForm<MaterialReceiptInspection>({
    resolver: yupResolver(
      MaterialReceiptInspectionValidationSchema
    ) as unknown as Resolver<MaterialReceiptInspection>,
    defaultValues: getDefaultValues(materialReceiptInspection),
    shouldUnregister: false,
  });

  const onSubmit = async (values: MaterialReceiptInspection) => {
    const status =
      values?.status || MaterialReceiptInspectionStatusEnum.PENDING;

    setValidationError("");
    const formData = new FormData();

    formData.append("id", values?.id || "");
    formData.append("title", values.title);
    values.purchaseOrderId &&
      formData.append("purchaseOrderId", values.purchaseOrderId);
    values.projectId &&
      formData.append("projectId", values.projectId as string);
    values.projectLocationId &&
      formData.append("projectLocationId", values.projectLocationId as string);
    values.subLocationId &&
      formData.append("subLocationId", values.subLocationId as string);
    values.deleteBillOfLandingId &&
      formData.append(
        "deleteBillOfLandingId",
        values.deleteBillOfLandingId as string
      );
    formData.append("status", status?.toString());
    formData.append("expectedDate", values?.expectedDate?.toISOString());
    formData.append("requestedDate", values?.requestedDate?.toISOString());

    values?.materials?.forEach((material, index) => {
      Object.entries(material).forEach(([key, value]) => {
        if (value !== null && value !== "" && value !== undefined) {
          if (
            [
              "spares",
              "samples",
              "regular",
              "totalSamples",
              "totalSpares",
              "totalRegular",
            ].includes(key)
          )
            return;

          formData.append(`materials[${index}][${key}]`, String(value));
        }
      });
    });
    values?.qualityQuestions?.forEach((answer, index) => {
      Object.entries(answer).forEach(([key, value]) => {
        if (value !== null && value !== "" && value !== undefined) {
          if (key === "qualityQuestionId" || key === "answer") {
            formData.append(`answers[${index}][${key}]`, String(value));
          }
        }
      });
    });

    if (Array.isArray(values.billOfLanding)) {
      values?.billOfLanding?.forEach((file: Attachment) => {
        if (file?.originFileObj) {
          formData.append("billOfLanding", file.originFileObj);
        }
      });
    }

    try {
      let response;
      if (getValues("id")) {
        response = await dispatch(
          editMaterialReceiptInspectionById({
            payload: formData,
            id: getValues("id"),
          })
        ).unwrap();
        if (response?.isSuccess) {
          if (actionType.saveAndClose === ActionTypeEnum.SAVE_AND_CLOSE) {
            handleCancelForm();
            return;
          }
          getDefaultValues(response?.materialReceiptInspection);
          setMaterialReceiptInspection(response?.materialReceiptInspection);
          setShouldDisable(true);
        }
      } else {
        response = await dispatch(
          createMaterialReceiptInspection({ payload: formData })
        ).unwrap();
        if (response?.isSuccess) {
          if (actionType.saveAndClose === ActionTypeEnum.SAVE_AND_CLOSE) {
            handleCancelForm();
            return;
          }
          getDefaultValues(response?.materialReceiptInspection);
          setMaterialReceiptInspection(response?.materialReceiptInspection);
          setShouldDisable(true);
          const projectId = response?.materialReceiptInspection?.project?.id;
          const MaterialReceiptInspectionId =
            response?.materialReceiptInspection?.id;
          navigate(
            `${routePaths.MATERIAL_RECEIPT_INSPECTION_EDIT_BY_ID}/${projectId}/${MaterialReceiptInspectionId}`
          );
        }
      }
    } catch (error) {
      console.error("Error submitting form:", error);
      setValidationError("An error occurred while submitting the form.");
    }
  };

  const fetchMaterialsList = async (
    purchaseOrderId: string | null,
    shouldSetMaterialsList: boolean = true
  ) => {
    try {
      const response = await dispatch(
        getMaterialReceiptInspectionsMaterialList({
          purchaseOrderId: purchaseOrderId,
        })
      ).unwrap();
      if (response && response?.materials?.length) {
        const mappedMaterials = response?.materials?.map((material) => ({
          id: "",
          name: material?.name,
          spares: material?.totalSpares,
          samples: material?.totalSamples,
          regular: material?.totalRegular,
          quantity: material?.totalQuantity,
          totalQuantity: material?.totalQuantity,
          totalSamples: material?.totalSamples,
          totalSpares: material?.totalSpares,
          totalRegular: material?.totalRegular,
          unitOfMeasure: material?.unitOfMeasure,
        }));

        setMaterialsList(mappedMaterials);

        if (shouldSetMaterialsList) {
          setValue("materials", mappedMaterials);
        }
      } else {
        setValue("materials", MriDefaultMaterialValues);
        setMaterialsList([]);
      }
    } catch (err) {
      console.error("Error fetching Materials Form Purchase Order.", err);
    }
  };

  const handleChangePurchaseOrderId = async (
    purchaseOrderId: string | null
  ) => {
    setValue("purchaseOrderId", purchaseOrderId);
    setValue("materials", MriDefaultMaterialValues);
    setValue("projectLocationId", null);
    setValue("expectedDate", dayjs(new Date()));
    setValue("requestedDate", dayjs(new Date()));

    if (purchaseOrderId) {
      fetchMaterialsList(purchaseOrderId);
    }

    const selectedPurchaseOrder = purchaseOrdersList?.find(
      (f) => f?.id === purchaseOrderId
    );

    const deliveryLocationId = selectedPurchaseOrder?.deliveryLocation?.id;
    if (deliveryLocationId) {
      setValue("projectLocationId", deliveryLocationId);
    }

    const expectedDate = selectedPurchaseOrder?.expectedDate;
    if (expectedDate) {
      setValue("expectedDate", dayjs(expectedDate));
      setValue("requestedDate", dayjs(expectedDate));
    }
  };

  const memoizedSubLocationOptions = useMemo(() => {
    if (
      getValues("subLocationId") !== materialReceiptInspection?.subLocation?.id
    ) {
      setValue("subLocationId", "");
    }
    if (!watch("projectLocationId"))
      return [
        {
          value: "",
          label: "Select Sublocation",
        },
      ];
    const selectedLocation = locationsList?.find(
      (location) => location?.id === watch("projectLocationId")
    );

    return [
      {
        value: "",
        label: "Select Sublocation",
      },
      ...(selectedLocation?.subLocations?.map((subLocation) => ({
        value: subLocation?.id,
        label: subLocation?.name,
      })) || []),
    ];
  }, [watch("projectLocationId"), locationsList]);

  type DeleteMaterialReceiptInspectionFunctionArgs = {
    id: string | undefined;
  };
  async function handleDeleteMaterialReceiptInctionById({
    id,
  }: DeleteMaterialReceiptInspectionFunctionArgs) {
    if (id) {
      try {
        setIsDeleting(true);
        const res = await dispatch(
          deleteMaterialReceiptInspectionById({
            id,
            errors: [],
            isSuccess: true,
          })
        ).unwrap();
        if (res.isSuccess) {
          navigate(routePaths.MATERIAL_RECEIPT_INSPECTION);
        }
      } catch (error) {
        console.error("Error Deleting Material Receipt Inspection:", error);
      } finally {
        setIsDeleting(false);
      }
    }
  }

  useEffect(() => {
    if (!materialReceiptInspection) return;

    if (materialReceiptInspection?.project?.id) {
      setSelectedProjectId(materialReceiptInspection.project.id);
    }

    const materialReceiptInspectionValues = getDefaultValues(
      materialReceiptInspection
    );

    reset(materialReceiptInspectionValues);
  }, [materialReceiptInspection, reset]);

  useEffect(() => {
    if (
      materialReceiptInspection?.purchaseOrder?.id &&
      !POData?.id &&
      materialReceiptInspection.status ===
        MaterialReceiptInspectionStatusEnum.PENDING
    ) {
      fetchMaterialsList(materialReceiptInspection?.purchaseOrder?.id, false);
    }
  }, [materialReceiptInspection, POData]);

  useEffect(() => {
    if (materialReceiptInspection) {
      setShouldDisable(
        materialReceiptInspection?.status !==
          MaterialGoingToSiteStatusEnum.PENDING
      );
    }
  }, [materialReceiptInspection]);

  useEffect(() => {
    dispatch(resetState());
  }, []);

  // const calculateMaterialTotal = (
  //   material: MaterialReceiptInspectionMaterial
  // ) =>
  //   Number(material.samples || 0) +
  //   Number(material.spares || 0) +
  //   Number(material.regular || 0);

  // const handleUpdateTotalQty = () => {
  //   const materials = getValues("materials") || [];
  //   materials.forEach((material, index) => {
  //     const totalQty = calculateMaterialTotal(material);
  //     setValue(`materials.${index}.quantity`, formatDecimals(totalQty));
  //   });
  // };

  const handlePODataSetInMRI = async (POData: PurchaseOrder) => {
    if (!POData?.id) {
      return;
    }
    try {
      setLoading(true);
      await fetchMaterialsList(POData?.id);
      await dispatch(getLocationsList(POData?.purchaseOrderProject?.id));
      const res = await dispatch(
        getAllQuestions({
          projectId: POData?.purchaseOrderProject?.id,
        })
      ).unwrap();
      setValue(
        "qualityQuestions",
        res?.qualityQuestions?.map((v) => ({
          ...v,
          answer: v?.answer || "",
        })) as QualityQuestion[]
      );
      const projectId =
        getValues("projectId") || POData?.purchaseOrderProject?.id;
      getPurchaseOrderbyProjectId(projectId);
      setValue("projectId", POData?.purchaseOrderProject?.id);
      setValue("expectedDate", dayjs(POData?.dueDate || new Date()));
      setValue("requestedDate", dayjs(POData?.dueDate || new Date()));
      setValue("projectLocationId", POData?.purchaseOrderDeliveryLocation?.id);
      setValue("purchaseOrderId", POData?.id);
    } catch (error) {
      console.error("Error setting P.O. data:", error);
      setLoading(false);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (POData?.id) {
      handlePODataSetInMRI(POData);
    }
  }, [POData, setValue]);

  useEffect(() => {
    if (
      locationPath.pathname === routePaths.MATERIAL_RECEIPT_INSPECTION_NEW &&
      !POData?.id
    ) {
      reset(getDefaultValues(null));
      dispatch(resetState());
    }
  }, [locationPath.pathname]);

  useEffect(() => {
    if (isLocationModalOpen?.open) {
      dispatch(getAllStorageTypes());
    } else {
      dispatch(getLocationsList(getValues("projectId") || ""));
    }
  }, [dispatch, isLocationModalOpen?.open]);

  const handleOpenLocationModal = (title: string, field: string) => {
    setIsLocationModalOpen({
      title: title,
      open: true,
      field: field,
    });
  };

  const handleProjectChange = async (projectId: string) => {
    try {
      setLoading(true);
      const res = await dispatch(
        getAllQuestions({
          projectId,
        })
      ).unwrap();
      setSelectedProjectId(projectId);
      setValue("materials", MriDefaultMaterialValues);
      setValue(
        "qualityQuestions",
        res?.qualityQuestions?.map((v) => ({
          ...v,
          answer: v?.answer || "",
        })) as QualityQuestion[]
      );
      setValue("projectLocationId", null);
      setValue("subLocationId", null);
      setValue("purchaseOrderId", null);
      setValue("expectedDate", dayjs(new Date()));
      setValue("requestedDate", dayjs(new Date()));
      dispatch(resetState());
      setSelectedProjectId(projectId);
      // setValue("materials", MriDefaultMaterialValues);
    } catch (err) {
      console.error("err", err);
    } finally {
      setLoading(false);
    }
  };
  return (
    <>
      <LocationModal
        setLocationValue={setValue}
        projectId={getValues("projectId")}
        isLocationModalOpen={isLocationModalOpen}
        setIsLocationModalOpen={setIsLocationModalOpen}
      />
      {loading && <CustomOverlayLoader />}
      <SectionLayout>
        <Form
          disabled={
            materialReceiptInspection?.status ===
              MaterialGoingToSiteStatusEnum.CANCELLED ||
            materialReceiptInspection?.status ===
              MaterialGoingToSiteStatusEnum.INPROGRESS ||
            materialReceiptInspection?.status ===
              MaterialGoingToSiteStatusEnum.TRANSFERRED
          }
          onFinish={handleSubmit(onSubmit)}
          layout="vertical"
          autoComplete="off"
        >
          {/* General Form Details */}
          <CustomFormRow>
            <Col xs={24} className="mb-1">
              <Flex align="start" gap={"large"}>
                <Typography.Title level={5}>
                  General Information
                </Typography.Title>
              </Flex>
            </Col>

            {/* Title* */}
            <Col xs={12}>
              <Controller
                control={control}
                name="title"
                render={({ field }) => (
                  <Form.Item<FieldType>
                    label={<CustomFormLabel text="Title" required={true} />}
                    labelAlign="right"
                    initialValue={field.value}
                    validateStatus={errors.title ? "error" : ""}
                    help={errors.title?.message}
                  >
                    <Input
                      ref={register(`title`).ref}
                      value={field.value}
                      onChange={(event) => field.onChange(event?.target?.value)}
                      size="large"
                      placeholder="Title"
                    />
                  </Form.Item>
                )}
              />
            </Col>

            {/* Project* */}
            <Col xs={12}>
              <Controller
                control={control}
                name="projectId"
                render={({ field }) => (
                  <Form.Item<FieldType>
                    label={<CustomFormLabel text="Project" required={true} />}
                    labelAlign="right"
                    initialValue={field.value}
                    validateStatus={
                      !field.value && errors.projectId ? "error" : ""
                    }
                    help={!field.value && errors.projectId?.message}
                  >
                    <Select
                      ref={register(`projectId`).ref}
                      value={field.value}
                      onChange={(value) => {
                        field.onChange(value);
                        handleProjectChange(value);
                      }}
                      showSearch
                      size="large"
                      placeholder={"Select Project"}
                      style={{ width: "100%" }}
                      options={memoizedProjectsOptions}
                      filterOption={(input, option) =>
                        (option?.label || "")
                          .toLowerCase()
                          .includes(input.toLowerCase())
                      }
                    />
                  </Form.Item>
                )}
              />
            </Col>

            {/*Original Location* */}
            <Col xs={12}>
              <Controller
                control={control}
                name="projectLocationId"
                render={({ field }) => (
                  <Form.Item<FieldType>
                    label={<CustomFormLabel text="Location" required={true} />}
                    labelAlign="right"
                    initialValue={field.value}
                    validateStatus={
                      !field.value && errors.projectLocationId ? "error" : ""
                    }
                    help={!field.value && errors.projectLocationId?.message}
                  >
                    <Select
                      {...field}
                      size="large"
                      style={{ width: "100%" }}
                      placeholder={"Select Location"}
                      value={field.value}
                      onChange={(value) => {
                        field.onChange(value);
                      }}
                      options={memoizedLocationOptions}
                      showSearch
                      filterOption={(input, option) =>
                        (option?.label || "")
                          .toLowerCase()
                          .includes(input.toLowerCase())
                      }
                      dropdownRender={(menu) => (
                        <>
                          {menu}
                          <Divider className="mt-2 mb-1" />
                          <Space className="p-1">
                            <Button
                              type="text"
                              icon={<PlusOutlined />}
                              onClick={() =>
                                handleOpenLocationModal(
                                  "Add New Location",
                                  "projectLocationId"
                                )
                              }
                            >
                              Add New Location
                            </Button>
                          </Space>
                        </>
                      )}
                    />
                  </Form.Item>
                )}
              />
            </Col>

            {/* Sublocation* */}
            <Col xs={12}>
              <Controller
                control={control}
                name="subLocationId"
                render={({ field }) => (
                  <Form.Item<FieldType>
                    label={<CustomFormLabel text="Sublocation" />}
                    labelAlign="right"
                    initialValue={field.value}
                    validateStatus={errors.subLocationId ? "error" : ""}
                    help={errors.subLocationId?.message}
                  >
                    <Select
                      size="large"
                      style={{ width: "100%" }}
                      placeholder={"Select Sublocation"}
                      ref={register(`subLocationId`).ref}
                      value={field.value}
                      onChange={(value) => {
                        field.onChange(value);
                      }}
                      options={memoizedSubLocationOptions}
                      disabled={
                        !watch("projectLocationId") ||
                        materialReceiptInspection?.status ===
                          MaterialGoingToSiteStatusEnum.CANCELLED ||
                        materialReceiptInspection?.status ===
                          MaterialGoingToSiteStatusEnum.INPROGRESS ||
                        materialReceiptInspection?.status ===
                          MaterialGoingToSiteStatusEnum.TRANSFERRED
                      }
                      showSearch
                      filterOption={(input, option) =>
                        (option?.label || "")
                          .toLowerCase()
                          .includes(input.toLowerCase())
                      }
                    />
                  </Form.Item>
                )}
              />
            </Col>

            {/* Expected Date */}
            <Col xs={12}>
              <Controller
                control={control}
                name="expectedDate"
                render={({ field }) => (
                  <Form.Item<FieldType>
                    label={<CustomFormLabel text="Expected Date" />}
                    labelAlign="right"
                    initialValue={field.value}
                  >
                    <DatePicker
                      disabled
                      size="large"
                      style={{ width: "100%" }}
                      placeholder="MM/DD/YYYY"
                      format={dateFormat}
                      value={
                        dayjs(field.value).isValid() ? dayjs(field.value) : null
                      }
                      onChange={(date) => {
                        field.onChange(dayjs(date).locale("en").format());
                      }}
                    />
                  </Form.Item>
                )}
              />
            </Col>

            {/* Purchase Order Number */}
            <Col xs={12}>
              <Controller
                control={control}
                name="purchaseOrderId"
                render={({ field }) => (
                  <Form.Item<FieldType>
                    label={
                      <CustomFormLabel
                        text="Purchase Order Number"
                        required={true}
                      />
                    }
                    labelAlign="right"
                    initialValue={field.value}
                    validateStatus={
                      !field.value && errors.purchaseOrderId ? "error" : ""
                    }
                    help={!field.value && errors.purchaseOrderId?.message}
                  >
                    <Select
                      size="large"
                      style={{ width: "100%" }}
                      placeholder={"Select Purchase Order"}
                      ref={register(`purchaseOrderId`).ref}
                      disabled={
                        (!selectedProjectId && !POData?.id) ||
                        materialReceiptInspection?.status ===
                          MaterialGoingToSiteStatusEnum.CANCELLED ||
                        materialReceiptInspection?.status ===
                          MaterialGoingToSiteStatusEnum.INPROGRESS ||
                        materialReceiptInspection?.status ===
                          MaterialGoingToSiteStatusEnum.TRANSFERRED
                      }
                      value={field.value}
                      onChange={(value) => {
                        handleChangePurchaseOrderId(value);
                      }}
                      options={memoizedPurchaseOrderNoOptions}
                      showSearch
                      filterOption={(input, option) =>
                        (option?.label || "")
                          .toLowerCase()
                          .includes(input.toLowerCase())
                      }
                    />
                  </Form.Item>
                )}
              />
            </Col>

            {/* Status* */}
            <Col xs={12}>
              <Controller
                control={control}
                name="status"
                render={({ field }) => (
                  <Form.Item<FieldType>
                    label={<CustomFormLabel text="Status" required={true} />}
                    labelAlign="right"
                    initialValue={field.value}
                    validateStatus={
                      !field.value && errors.status ? "error" : ""
                    }
                    help={!field.value && errors.status?.message}
                  >
                    <Select
                      size="large"
                      placeholder={"Select Status"}
                      style={{ width: "100%" }}
                      showSearch
                      ref={register(`status`).ref}
                      value={field.value}
                      onChange={(value) => {
                        field.onChange(value);
                      }}
                      disabled
                      options={MaterialReceiptInspectionsStatusOptions}
                      filterOption={(input, option) =>
                        (option?.label || "")
                          .toLowerCase()
                          .includes(input.toLowerCase())
                      }
                    />
                  </Form.Item>
                )}
              />
            </Col>

            {/* Requested Date */}
            <Col xs={12}>
              <Controller
                control={control}
                name="requestedDate"
                render={({ field }) => (
                  <Form.Item<FieldType>
                    label={<CustomFormLabel text="Received Date" />}
                    labelAlign="right"
                    initialValue={field.value}
                  >
                    <DatePicker
                      size="large"
                      style={{ width: "100%" }}
                      placeholder="MM/DD/YYYY"
                      format={dateFormat}
                      value={
                        dayjs(field.value).isValid() ? dayjs(field.value) : null
                      }
                      onChange={(date) => {
                        field.onChange(dayjs(date).locale("en").format());
                      }}
                      allowClear={false}
                    />
                  </Form.Item>
                )}
              />
            </Col>
          </CustomFormRow>

          <Divider />
          {/* Materials */}
          <Flex className="mt-9" justify="space-between" align="center" gap={5}>
            <Typography.Title level={5}>Materials</Typography.Title>
          </Flex>
          <div className="mt-6 mb-9">
            <MaterialsFormSection
              errors={errors}
              materials={materialsList}
              // handleUpdateTotalQty={handleUpdateTotalQty}
              isButtonDisabled={shouldDisable}
              control={control}
              setValue={setValue}
              getValues={getValues}
            />
          </div>

          {/* Validation handling of Materials*/}
          {validationError && (
            <CustomAlert message={validationError || ""} type="error" />
          )}

          {/* Bill of Lading (BOL) */}
          <Typography.Title level={5} className="mt-9">
            Bill of Lading (BOL)
          </Typography.Title>
          <SectionLayout
            className="rounded-xl flex items-center max-h-full min-h-52 my-5"
            borderStyle="dashed"
          >
            <div className="flex flex-col justify-center items-center max-h-full min-h-52 p-8">
              <div className="mb-4">
                <CustomIcon type="add-file" className="fill-white" />
              </div>

              <h6 className="font-medium text-sm !mb-2">
                Select a file to import
              </h6>

              <Flex justify="center" gap={5} className="mt-2">
                <Controller
                  control={control}
                  name="billOfLanding"
                  render={({ field }) => (
                    <Form.Item<FieldType>
                      labelAlign="right"
                      initialValue={field.value}
                    >
                      <CustomFileUploadRHF
                        setValue={setValue}
                        getValues={getValues}
                        fieldName={field.name}
                        deletedFileName="deleteBillOfLandingId"
                        buttonText="Browse Files"
                        maxCount={1}
                      />
                    </Form.Item>
                  )}
                />
              </Flex>
            </div>
          </SectionLayout>

          {/* Quality Questions */}

          <Typography.Title level={5} className="mt-9">
            Quality Questions
          </Typography.Title>
          {getValues("qualityQuestions")?.length ? (
            getValues("qualityQuestions")?.map((v, index) => (
              <Col xs={24} className="mt-5">
                <Controller
                  name={`qualityQuestions.${index}.answer`}
                  control={control}
                  render={({ field, fieldState: { error } }) => (
                    <Form.Item
                      key={v?.id}
                      initialValue={getValues(
                        `qualityQuestions.${index}.answer`
                      )}
                      validateStatus={error ? "error" : ""}
                      help={error?.message || ""}
                    >
                      <div className="border rounded-xl border-neutral-5 w-full">
                        <p className="py-4 px-3 bg-neutral-1 font-normal text-sm rounded-t-xl">
                          {v?.question}
                        </p>
                        <Input.TextArea
                          {...field}
                          value={field.value}
                          onChange={(e) => field.onChange(e.target.value)}
                          className="rounded-xl px-5 py-3 placeholder:text-neutral-7"
                          placeholder="Write your answer here..."
                          rows={5}
                        />
                      </div>
                    </Form.Item>
                  )}
                />
              </Col>
            ))
          ) : (
            <div>
              <div className="flex flex-col justify-center items-center max-h-full min-h-52 p-8 ">
                <div className="mb-3">
                  <QuestionCircleOutlined />
                </div>

                <h6 className="font-medium text-sm !mb-2">
                  No Quality Questions available
                </h6>
              </div>
            </div>
          )}
          <Divider className="mt-12" />
          {/* Validation handling */}
          {!validationError && (reqError || resError || successMessage) && (
            <CustomAlert
              message={resError || successMessage || ""}
              type={successMessage ? "success" : "error"}
            />
          )}

          <Flex justify="flex-end" className="gap-4 mt-5 mb-5">
            <Button
              disabled={isSubmitting || isDeleting}
              type="default"
              onClick={handleCancelForm}
            >
              Cancel
            </Button>
            {Boolean(materialReceiptInspection) && (
              <Button
                loading={isDeleting}
                disabled={
                  materialReceiptInspection?.status ===
                    MaterialGoingToSiteStatusEnum.CANCELLED ||
                  materialReceiptInspection?.status ===
                    MaterialGoingToSiteStatusEnum.INPROGRESS ||
                  materialReceiptInspection?.status ===
                    MaterialGoingToSiteStatusEnum.TRANSFERRED ||
                  isSubmitting ||
                  isDeleting
                }
                type="default"
                onClick={() => {
                  setActionType({
                    delete: ActionTypeEnum.DELETE,
                  });
                  handleDeleteMaterialReceiptInctionById({
                    id: materialReceiptInspection?.id,
                  });
                }}
              >
                {isDeleting ? "Deleting.." : "Delete"}
              </Button>
            )}
            <Button
              loading={actionType.save === ActionTypeEnum.SAVE && isSubmitting}
              disabled={
                materialReceiptInspection?.status ===
                  MaterialGoingToSiteStatusEnum.CANCELLED ||
                materialReceiptInspection?.status ===
                  MaterialGoingToSiteStatusEnum.INPROGRESS ||
                materialReceiptInspection?.status ===
                  MaterialGoingToSiteStatusEnum.TRANSFERRED ||
                isSubmitting ||
                isDeleting
              }
              type="primary"
              htmlType="submit"
              onClick={() => {
                setValue("status", MaterialReceiptInspectionStatusEnum.PENDING);
                setActionType({
                  save: ActionTypeEnum.SAVE,
                });
              }}
            >
              {actionType.save === ActionTypeEnum.SAVE && isSubmitting
                ? "Saving.."
                : "Save"}
            </Button>
            <Button
              loading={
                actionType.saveAndClose === ActionTypeEnum.SAVE_AND_CLOSE &&
                isSubmitting
              }
              disabled={
                materialReceiptInspection?.status ===
                  MaterialGoingToSiteStatusEnum.CANCELLED ||
                materialReceiptInspection?.status ===
                  MaterialGoingToSiteStatusEnum.INPROGRESS ||
                materialReceiptInspection?.status ===
                  MaterialGoingToSiteStatusEnum.TRANSFERRED ||
                isSubmitting ||
                isDeleting
              }
              type="primary"
              htmlType="submit"
              onClick={() => {
                setValue("status", MaterialReceiptInspectionStatusEnum.PENDING);
                setActionType({
                  saveAndClose: ActionTypeEnum.SAVE_AND_CLOSE,
                });
              }}
            >
              {actionType.saveAndClose === ActionTypeEnum.SAVE_AND_CLOSE &&
              isSubmitting
                ? "Saving and closing.."
                : "Save & Close"}
            </Button>
            {Boolean(getValues("id")) && (
              <>
                <Button
                  className="font-medium !border-danger-5 !text-danger-5 bg-danger-510 hover:!bg-danger-5-18 hover:!border-danger-5-02 disabled:!bg-neutral-1 disabled:!border-neutral-5 disabled:!text-neutral-75"
                  loading={
                    actionType.rejected === ActionTypeEnum.REJECTED &&
                    isSubmitting
                  }
                  disabled={
                    materialReceiptInspection?.status ===
                      MaterialGoingToSiteStatusEnum.CANCELLED ||
                    materialReceiptInspection?.status ===
                      MaterialGoingToSiteStatusEnum.INPROGRESS ||
                    materialReceiptInspection?.status ===
                      MaterialGoingToSiteStatusEnum.TRANSFERRED ||
                    isSubmitting ||
                    isDeleting
                  }
                  type="primary"
                  htmlType="submit"
                  onClick={() => {
                    setValue(
                      "status",
                      MaterialReceiptInspectionStatusEnum.REJECTED
                    );
                    setActionType({
                      rejected: ActionTypeEnum.REJECTED,
                    });
                  }}
                >
                  {actionType.rejected === ActionTypeEnum.REJECTED &&
                  isSubmitting
                    ? "Rejecting.."
                    : "Reject"}
                </Button>
                <Button
                  loading={
                    actionType.approvedWithExceptions ===
                      ActionTypeEnum.APPROVEDWITHEXCEPTIONS && isSubmitting
                  }
                  disabled={
                    materialReceiptInspection?.status ===
                      MaterialGoingToSiteStatusEnum.CANCELLED ||
                    materialReceiptInspection?.status ===
                      MaterialGoingToSiteStatusEnum.INPROGRESS ||
                    materialReceiptInspection?.status ===
                      MaterialGoingToSiteStatusEnum.TRANSFERRED ||
                    isSubmitting ||
                    isDeleting
                  }
                  type="default"
                  htmlType="submit"
                  onClick={() => {
                    setValue(
                      "status",
                      MaterialReceiptInspectionStatusEnum.APPROVEDWITHEXCEPTIONS
                    );
                    setActionType({
                      approvedWithExceptions:
                        ActionTypeEnum.APPROVEDWITHEXCEPTIONS,
                    });
                  }}
                >
                  {actionType.approvedWithExceptions ===
                    ActionTypeEnum.APPROVEDWITHEXCEPTIONS && isSubmitting
                    ? "Approving.."
                    : "Approve with Exceptions"}
                </Button>
                <Button
                  className="font-medium !border-green-primary !text-white !bg-green-primary hover:!bg-green-primaryHover hover:!border-green-primaryHover disabled:!bg-neutral-1 disabled:!border-neutral-5 disabled:!text-neutral-75"
                  loading={
                    actionType.approve === ActionTypeEnum.APPROVE &&
                    isSubmitting
                  }
                  disabled={
                    materialReceiptInspection?.status ===
                      MaterialGoingToSiteStatusEnum.CANCELLED ||
                    materialReceiptInspection?.status ===
                      MaterialGoingToSiteStatusEnum.INPROGRESS ||
                    materialReceiptInspection?.status ===
                      MaterialGoingToSiteStatusEnum.TRANSFERRED ||
                    isSubmitting ||
                    isDeleting
                  }
                  type="primary"
                  htmlType="submit"
                  onClick={() => {
                    setValue(
                      "status",
                      MaterialReceiptInspectionStatusEnum.APPROVED
                    );
                    setActionType({
                      approve: ActionTypeEnum.APPROVE,
                    });
                  }}
                >
                  {actionType.approve === ActionTypeEnum.APPROVE && isSubmitting
                    ? "Approving.."
                    : "Approve"}
                </Button>
              </>
            )}
          </Flex>

          {/* Edited Badge */}
          {materialReceiptInspection?.createdBy &&
            materialReceiptInspection?.createdDate && (
              <Flex justify="flex-end">
                <CreatedByUserBadge
                  // userName={materialReceiptInspection?.createdBy as string}
                  // date={materialReceiptInspection?.createdDate as Date}
                  // isUpdatedBadge

                  userName={
                    getValues("modifiedDate") == null
                      ? getValues("createdBy")
                      : getValues("lastModifiedBy")
                  }
                  date={getValues("lastModifiedDate")}
                  isUpdatedBadge={
                    getValues("modifiedDate") == null ? false : true
                  }
                />
              </Flex>
            )}
        </Form>
      </SectionLayout>
    </>
  );
}
