import { getDashboard } from "@/src/apis/dashboardApis";
import CustomOverlayLoader from "@/src/components/common/CustomOverlayloader";
import Greeting from "@/src/components/common/Greeting";
import ActionItemsSection from "@/src/features/dashboard/components/ActionItemsSection";
import CalendarSection from "@/src/features/dashboard/components/CalendarSection";
import ProjectBudgetAnalysisSection from "@/src/features/dashboard/components/ProjectBudgetAnalysisSection";
import ProjectsComparisonSection from "@/src/features/dashboard/components/ProjectsComparison";
import TimelineSection from "@/src/features/dashboard/components/TimelineSection";
import DeliverablesSection from "@/src/features/dashboard/components/UpcomingDeliverablesSection";
import WaitingForSection from "@/src/features/dashboard/components/WaitingForSection";
import { useAppDispatch } from "@/src/hooks/useAppDispatch";
import { useAppSelector } from "@/src/hooks/useAppSelector";
import { getDashboardState } from "@/src/store/slices/dashboardSlice";
import { dateFormat, getEntityIconType } from "@/src/utils/constants";
import { ProjectComparisonTypeEnum } from "@/src/utils/enums";
import {
  DashboardNotification,
  DashboardNotificationWithCustomProps,
  SideNotificationsType,
  SideNotificationsTypeWithCustomProps,
} from "@/src/utils/types";
import { Flex, message } from "antd";
import dayjs from "dayjs";
import { useCallback, useEffect, useMemo, useState } from "react";

export default function HomePage() {
  const dispatch = useAppDispatch();
  const {
    isLoading,
    dashboardData,
    dashBoardSideNotifyData,
    text,
    reqError,
    resError,
  } = useAppSelector(getDashboardState);
  const {
    actionItemNotifications = [],
    upcomingDeliverableNotifications = [],
    waitingForNotifications = [],

    projectComparision = null,
  } = dashboardData || {};

  const today = new Date();
  const [selectedComparisonType, setSelectedComparisonType] = useState<number>(
    ProjectComparisonTypeEnum.ALLTIME
  );
  const [selectedWeekDate, setSelectedWeekDate] = useState(new Date());
  const [sideNotifications, setSideNotifications] =
    useState<SideNotificationsType[]>();

  useEffect(() => {
    const filters = {
      date: selectedWeekDate?.toISOString(),
      projectId: null,
    };

    const filterNotification = dashBoardSideNotifyData?.find(
      (item) =>
        dayjs(item.date).format(dateFormat) ===
        dayjs(filters.date).format(dateFormat)
    );
    setSideNotifications(filterNotification?.notifications);
  }, [selectedWeekDate, dashBoardSideNotifyData]);

  const fetchDashboard = useCallback(() => {
    const filters = {
      projectComparisonType:
        selectedComparisonType === -1 ? null : selectedComparisonType,
      date: selectedWeekDate?.toISOString(),
    };
    dispatch(getDashboard(filters));
  }, [dispatch, selectedComparisonType]);

  useEffect(() => {
    fetchDashboard();
  }, [fetchDashboard]);

  const mapNotificationWithCustomProps = useCallback(
    (
      item: DashboardNotification | SideNotificationsType
    ):
      | DashboardNotificationWithCustomProps
      | SideNotificationsTypeWithCustomProps => ({
      ...item,
      entityIconType: getEntityIconType[item.entityType],
    }),
    []
  );

  const memoizedActionItems = useMemo(
    () =>
      (actionItemNotifications || []).map(
        mapNotificationWithCustomProps
      ) as unknown as DashboardNotificationWithCustomProps[],
    [actionItemNotifications, mapNotificationWithCustomProps]
  );
  const memoizedDeliverables = useMemo(
    () =>
      (upcomingDeliverableNotifications || []).map(
        mapNotificationWithCustomProps
      ) as unknown as DashboardNotificationWithCustomProps[],
    [upcomingDeliverableNotifications, mapNotificationWithCustomProps]
  );
  const memoizedWaitingForItems = useMemo(
    () =>
      (waitingForNotifications || []).map(
        mapNotificationWithCustomProps
      ) as unknown as DashboardNotificationWithCustomProps[],
    [waitingForNotifications, mapNotificationWithCustomProps]
  );
  const memoizedSideNotifications = useMemo(
    () =>
      (sideNotifications || []).map(
        mapNotificationWithCustomProps
      ) as unknown as SideNotificationsTypeWithCustomProps[],
    [sideNotifications, mapNotificationWithCustomProps]
  );
  useEffect(() => {
    if (text || resError || reqError) {
      message.open({
        type: text ? "success" : "error",
        content: text || resError || reqError,
      });
    }
  }, [text, reqError, resError]);
  return (
    <Flex className="flex-row flex-wrap p-4 gap-4 relative">
      {isLoading ? (
        <CustomOverlayLoader />
      ) : (
        <>
          <Greeting />
          <Flex className="flex-col gap-4 flex-[3]">
            <ActionItemsSection actionItems={memoizedActionItems} />
            <DeliverablesSection deliverables={memoizedDeliverables} />
            <WaitingForSection
              waitingForNotifications={memoizedWaitingForItems}
            />
          </Flex>
          <Flex className="flex-col gap-4 basis-[30%] max-w-[30%]">
            <CalendarSection
              today={today}
              selectedWeekDate={selectedWeekDate}
              setSelectedWeekDate={setSelectedWeekDate}
            />
            <TimelineSection sideNotifications={memoizedSideNotifications} />
            <ProjectsComparisonSection
              selectedComparisonType={selectedComparisonType}
              setSelectedComparisonType={setSelectedComparisonType}
              projectComparision={projectComparision}
            />
          </Flex>
          <ProjectBudgetAnalysisSection />
        </>
      )}
    </Flex>
  );
}
