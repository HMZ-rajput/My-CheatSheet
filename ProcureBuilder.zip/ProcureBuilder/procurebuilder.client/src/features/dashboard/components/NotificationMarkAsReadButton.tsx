import { deleteNotificationById } from "@/src/apis/dashboardApis";
import CustomIcon from "@/src/components/common/CustomIcon";
import { useAppDispatch } from "@/src/hooks/useAppDispatch";
import { useAppSelector } from "@/src/hooks/useAppSelector";
import {
  getDashboardState,
  resetState,
  updateDashboardData,
  updatedDashBoardSideNotifyData,
} from "@/src/store/slices/dashboardSlice";
import { NotificationSectionTypeEnum } from "@/src/utils/enums";
import {
  DashboardNotification,
  DashboardType,
  Notifications,
} from "@/src/utils/types";
import { Button, Tooltip } from "antd";
import { useState } from "react";
import { useParams } from "react-router-dom";

type NotificationMarkAsReadButtonProps = {
  notificationId: string;
  notificationSectionType: NotificationSectionTypeEnum;
};

export const NotificationMarkAsReadButton = ({
  notificationId,
  notificationSectionType,
}: NotificationMarkAsReadButtonProps) => {
  const { projectId: paramsProjectId } = useParams();
  const dispatch = useAppDispatch();
  const { dashboardData } = useAppSelector(getDashboardState);
  const { dashboardDataByProjectId, dashBoardSideNotifyData } =
    useAppSelector(getDashboardState);

  const [isLoading, setIsLoading] = useState(false);

  const handleDeleteNotification = async (notificationId: string) => {
    dispatch(resetState());
    setIsLoading(true);

    try {
      const response = await dispatch(
        deleteNotificationById({ notificationId })
      ).unwrap();

      if (response?.isSuccess) {
        const previousDashboardData = paramsProjectId
          ? dashboardDataByProjectId
          : dashboardData;
        const previousDashboardDataCopy = {
          ...previousDashboardData,
        };
        const filteredSectionData =
          previousDashboardDataCopy?.[notificationSectionType]?.filter(
            (f: DashboardNotification) => f.id !== notificationId
          ) || [];
        const updatedDashboardData: DashboardType = {
          ...previousDashboardData,
          [notificationSectionType]: filteredSectionData,
        };

        dispatch(
          updateDashboardData({
            dashboard: updatedDashboardData,
            isProjectDashboard: Boolean(paramsProjectId),
          })
        );

        // clear from day notification
        let notificationMatchWithCalendar = false;
        let newDashBoardSideNotifyData: Notifications[] = [];

        if (Array?.isArray(dashBoardSideNotifyData)) {
          newDashBoardSideNotifyData = dashBoardSideNotifyData.map((n) => {
            if (Array.isArray(n.notifications) && n.notifications.length > 0) {
              const filteredNotifications = n.notifications.filter((nn) => {
                if (nn.id === notificationId) {
                  notificationMatchWithCalendar = true;
                  return false; // remove matching notification
                }
                return true;
              });
              return {
                ...n,
                notifications: filteredNotifications,
              };
            }
            return n;
          });
        }

        if (notificationMatchWithCalendar) {
          dispatch(
            updatedDashBoardSideNotifyData({
              dashBoardSideNotifyData: newDashBoardSideNotifyData,
            })
          );
        }

        setTimeout(() => {
          dispatch(resetState());
        }, 2000);
      }
    } catch (error) {
      console.log("err", error);
    } finally {
      setIsLoading(false);
      setTimeout(() => {
        dispatch(resetState());
      }, 2000);
    }
  };
  return (
    <Tooltip title="Mark As Read">
      <Button
        loading={isLoading}
        disabled={isLoading}
        className="hover:!fill-primaryHover mr-4"
        icon={<CustomIcon type="done-all-icon" className="!w-4 !h-4" />}
        onClick={() => handleDeleteNotification(notificationId)}
      />
    </Tooltip>
  );
};
