import { DashboardNotificationWithCustomProps } from "@/src/utils/types";
import React from "react";
import NotificationSection from "./NotificationSection";
import { NotificationSectionTypeEnum } from "@/src/utils/enums";

type WaitingForSectionProps = {
  waitingForNotifications: DashboardNotificationWithCustomProps[] | [];
};

const WaitingForSection = React.memo(
  ({ waitingForNotifications }: WaitingForSectionProps) => {
    return (
      <NotificationSection
        title="Waiting for"
        iconType="timelapse-icon"
        notifications={waitingForNotifications}
        notificationSectionType={NotificationSectionTypeEnum.WAITING_FOR_ITEMS}
      />
    );
  }
);

export default WaitingForSection;
