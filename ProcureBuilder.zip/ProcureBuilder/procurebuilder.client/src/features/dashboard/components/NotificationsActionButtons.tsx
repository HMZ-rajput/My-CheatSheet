import { updateDashboardNotificationByEntityId } from "@/src/apis/dashboardApis";
import CustomIcon from "@/src/components/common/CustomIcon";
import { useAppDispatch } from "@/src/hooks/useAppDispatch";
import { useAppSelector } from "@/src/hooks/useAppSelector";
import useAuthorization from "@/src/hooks/useAuthorization";
import {
  getDashboardState,
  resetState,
  updateDashboardData,
} from "@/src/store/slices/dashboardSlice";
import {
  ActionTypeEnum,
  EntityTypeEnum,
  NotificationActionEnum,
  NotificationSectionTypeEnum,
} from "@/src/utils/enums";
import { routePathsWithParams } from "@/src/utils/routePaths";
import {
  DashboardNotification,
  DashboardType,
  ReorderMaterial,
} from "@/src/utils/types";
import { DislikeOutlined, EyeOutlined, LikeOutlined } from "@ant-design/icons";
import { Button, Tooltip } from "antd";
import React, { useState } from "react";
import { useNavigate, useParams } from "react-router-dom";

type NotificationActionButtonsProps = {
  actionType: NotificationActionEnum | null;
  entityType: EntityTypeEnum | null;
  entityId: string;
  projectId: string;
  notificationId: string;
  notificationSectionType: NotificationSectionTypeEnum;
  materials: ReorderMaterial[];
};

type ButtonTooltipProps = {
  children: React.ReactNode;
};
const ViewDetailsTooltip = ({ children }: ButtonTooltipProps) => (
  <Tooltip title="View Details">{children}</Tooltip>
);
const CreateTooltip = ({ children }: ButtonTooltipProps) => (
  <Tooltip title="Create">{children}</Tooltip>
);
const ApproveTooltip = ({ children }: ButtonTooltipProps) => (
  <Tooltip title="Approve">{children}</Tooltip>
);
const RejectTooltip = ({ children }: ButtonTooltipProps) => (
  <Tooltip title="Reject">{children}</Tooltip>
);

const NotificationActionButtons = React.memo(
  ({
    actionType,
    entityId,
    entityType,
    projectId,
    notificationId,
    notificationSectionType,
    materials,
  }: NotificationActionButtonsProps) => {
    const navigate = useNavigate();
    const { isFieldsCraftAuthorized } = useAuthorization();
    const dispatch = useAppDispatch();
    const { projectId: paramsProjectId } = useParams();

    const { dashboardData } = useAppSelector(getDashboardState);
    const { dashboardDataByProjectId } = useAppSelector(getDashboardState);
    // const data = dashboardData?.[notificationSectionType] || [];

    type ActionType = ActionTypeEnum.APPROVE_ALL | ActionTypeEnum.REJECT_ALL;
    const [isActionLoading, setIsActionLoading] = useState<ActionType | null>(
      null
    );

    const handleRemoveNotification = () => {
      const updatedDashboardData: DashboardType = {
        ...(paramsProjectId ? dashboardDataByProjectId : dashboardData),
        [notificationSectionType]:
          { ...(paramsProjectId ? dashboardDataByProjectId : dashboardData) }?.[
            notificationSectionType
          ]?.filter((f: DashboardNotification) => f.id !== notificationId) ||
          [],
      };

      dispatch(
        updateDashboardData({
          dashboard: updatedDashboardData,
          isProjectDashboard: Boolean(paramsProjectId),
        })
      );
      setTimeout(() => {
        dispatch(resetState());
      }, 2000);
    };

    const handleNavigation = (
      materials?: ReorderMaterial[],
      projectId?: string
    ) => {
      console.log("actionType", actionType);

      if (actionType === NotificationActionEnum.VendorApproval) {
        navigate(`/purchase-orders/edit/${entityId}`, {
          state: { actionType },
        });
        return;
      }

      let routePath = "";
      dispatch(resetState());
      if (actionType === NotificationActionEnum.CreateReorder) {
        routePath = routePathsWithParams.REORDERS_NEW;
      } else if (entityId && entityType !== null) {
        switch (entityType) {
          case EntityTypeEnum.PurchaseOrder:
            routePath = "/purchase-orders/edit";
            break;
          case EntityTypeEnum.Reorder:
            routePath = routePathsWithParams.REORDERS_NEW;
            break;
          case EntityTypeEnum.MaterialTransfer:
            routePath = "/material-transfer/edit";
            break;
          case EntityTypeEnum.MaterialToSite:
            routePath = "/material-going-to-sites/edit";
            break;
          case EntityTypeEnum.Invoice:
            routePath = "/invoices/edit";
            break;
          case EntityTypeEnum.ChangeOrder:
            routePath = `/change-orders/edit/${projectId}`;
            break;
          case EntityTypeEnum.MaterialReceiptInspection:
            routePath = `/material-receipt-inspection/edit/${projectId}`;
            break;
          default:
            return;
        }
      }
      if (actionType === NotificationActionEnum.CreateReorder) {
        navigate(`${routePath}`, {
          state: { materials, projectId, isFromDashboard: true },
        });
      } else {
        navigate(`${routePath}/${entityId}`);
        // navigate(`${routePath}/${entityId}`, { state: { materials } });
      }
    };
    const handleApproval = async (type: ActionType) => {
      dispatch(resetState());
      setIsActionLoading(type);

      try {
        const response = await dispatch(
          updateDashboardNotificationByEntityId({
            entityId,
            isApproved: type === ActionTypeEnum.APPROVE_ALL,
            notificationId,
          })
        ).unwrap();
        if (response?.isSuccess) {
          handleRemoveNotification();
        }
      } catch (error) {
        console.log("err", error);
      } finally {
        setIsActionLoading(null);
        setTimeout(() => {
          dispatch(resetState());
        }, 2000);
      }
    };
    const handleCreate = () => {
      handleNavigation(materials, projectId);
    };

    const buttons = React.useMemo(() => {
      if (actionType === null) {
        return (
          <ViewDetailsTooltip>
            <Button
              className="hover:!fill-primaryHover"
              icon={<EyeOutlined className="!w-4" />}
              onClick={() => handleNavigation()}
            />
          </ViewDetailsTooltip>
        );
      }

      switch (actionType) {
        case NotificationActionEnum.MaterialToSiteApproval:
        case NotificationActionEnum.ChangeOrderApproval:
        case NotificationActionEnum.MaterialTransferApproval:
        case NotificationActionEnum.PurchaseOrderApproval:
          return (
            <>
              {(isFieldsCraftAuthorized() &&
                (actionType === NotificationActionEnum.MaterialToSiteApproval ||
                  actionType ===
                    NotificationActionEnum.MaterialTransferApproval)) ||
              !isFieldsCraftAuthorized() ? (
                <>
                  <RejectTooltip>
                    <Button
                      disabled={isActionLoading !== null}
                      className="hover:!fill-primaryHover"
                      loading={isActionLoading === ActionTypeEnum.REJECT_ALL}
                      icon={<DislikeOutlined className="-scale-x-100" />}
                      onClick={() => handleApproval(ActionTypeEnum.REJECT_ALL)}
                    />
                  </RejectTooltip>

                  <ApproveTooltip>
                    <Button
                      disabled={isActionLoading !== null}
                      loading={isActionLoading === ActionTypeEnum.APPROVE_ALL}
                      icon={<LikeOutlined />}
                      className="hover:!fill-primaryHover"
                      onClick={() => handleApproval(ActionTypeEnum.APPROVE_ALL)}
                    />
                  </ApproveTooltip>
                </>
              ) : null}

              <ViewDetailsTooltip>
                <Button
                  disabled={isActionLoading !== null}
                  className="hover:!fill-primaryHover"
                  icon={<EyeOutlined className="!w-4" />}
                  onClick={() => handleNavigation()}
                />
              </ViewDetailsTooltip>
            </>
          );
        case NotificationActionEnum.VendorApproval:
          return (
            <>
              {!isFieldsCraftAuthorized() &&
                actionType === NotificationActionEnum.VendorApproval && (
                  <ViewDetailsTooltip>
                    <Button
                      disabled={isActionLoading !== null}
                      className="hover:!fill-primaryHover"
                      icon={<EyeOutlined className="!w-4" />}
                      onClick={() => handleNavigation()}
                    />
                  </ViewDetailsTooltip>
                )}
            </>
          );
        case NotificationActionEnum.ExpectingMaterials:
          return (
            <ViewDetailsTooltip>
              <Button
                className="hover:!fill-primaryHover"
                icon={<EyeOutlined className="!w-4" />}
                onClick={() => handleNavigation()}
              />
            </ViewDetailsTooltip>
          );
        case NotificationActionEnum.CreateReorder:
          return (
            <>
              <CreateTooltip>
                <Button
                  className="hover:!fill-primaryHover"
                  icon={<CustomIcon type="plus" className="!w-4 !h-4" />}
                  onClick={() => handleCreate()}
                />
              </CreateTooltip>
            </>
          );

        default:
          <></>;
      }
    }, [actionType, entityId, entityType, isActionLoading]);

    return <>{buttons}</>;
  }
);

export default NotificationActionButtons;
