import { getDashboardSideNotification } from "@/src/apis/dashboardApis";
import CustomIcon from "@/src/components/common/CustomIcon";
import { useAppDispatch } from "@/src/hooks/useAppDispatch";
import { useAppSelector } from "@/src/hooks/useAppSelector";
import { getDashboardState } from "@/src/store/slices/dashboardSlice";
import { getCurrentMonthYear } from "@/src/utils/date-helpers";
import useToken from "@hooks/useToken";
import { Button, Flex } from "antd";
import dayjs from "dayjs";
import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";

type CalendarSectionProps = {
  today: Date;
  selectedWeekDate: Date;
  setSelectedWeekDate: React.Dispatch<React.SetStateAction<Date>>;
};
export default function CalendarSection({
  today,
  selectedWeekDate,
  setSelectedWeekDate,
}: CalendarSectionProps) {
  const token = useToken();
  const [isLoading, setIsLoading] = useState(false);
  const { projectId } = useParams();
  const dispatch = useAppDispatch();
  const { dashBoardSideNotifyData } = useAppSelector(getDashboardState);

  // State to manage the start of the current week
  const [currentWeekStart, setCurrentWeekStart] = useState<Date>(() => {
    const dayIndex = today.getDay();
    const startOfWeek = new Date(today);
    startOfWeek.setDate(today.getDate() - dayIndex);
    return startOfWeek;
  });

  useEffect(() => {
    if (selectedWeekDate) {
      const dayIndex = selectedWeekDate?.getDay();
      const startOfWeek = new Date(selectedWeekDate);
      startOfWeek.setDate(selectedWeekDate?.getDate() - dayIndex);
      setCurrentWeekStart(startOfWeek);
    }
  }, [selectedWeekDate]);

  const currentWeekEnd = new Date(currentWeekStart);
  currentWeekEnd.setDate(currentWeekStart.getDate() + 6);

  function getWeekDates(startOfWeek: Date) {
    const weekDays = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
    const result: Array<{
      day: string;
      date: string;
      dateObject: Date;
      isToday: boolean;
      hasEvent: boolean[] | undefined;
    }> = [];

    for (let i = 0; i < 7; i++) {
      const current = new Date(startOfWeek);
      current.setDate(startOfWeek.getDate() + i);

      // Pad the date with a leading zero if it's a single digit
      const dateWithLeadingZero = String(current.getDate()).padStart(2, "0");

      result.push({
        day: weekDays[current.getDay()],
        date: dateWithLeadingZero, // Use the padded date
        hasEvent: dashBoardSideNotifyData?.map(
          (item) => item.notifications.length > 0
        ),
        dateObject: current,
        isToday: current.toDateString() === today.toDateString(),
      });
    }

    return result;
  }

  const getSideBarNotifications = async (week: Date) => {
    try {
      setIsLoading(true);
      await dispatch(
        getDashboardSideNotification({
          date: dayjs(week).format("YYYY-MM-DDTHH:mm:ss.SSS") || null,
          projectId: projectId || null,
        })
      ).unwrap();
    } catch (e) {
      console.log("Error fetching sidebar notifications", e);
    } finally {
      setIsLoading(false);
    }
  };

  const handleNextWeek = async () => {
    const nextWeekStart = new Date(currentWeekStart);
    nextWeekStart.setDate(currentWeekStart.getDate() + 7);
    await getSideBarNotifications(nextWeekStart);
    setCurrentWeekStart(nextWeekStart);
  };

  const handlePrevWeek = async () => {
    const prevWeekStart = new Date(currentWeekStart);
    prevWeekStart.setDate(currentWeekStart.getDate() - 7);
    await getSideBarNotifications(prevWeekStart);
    setCurrentWeekStart(prevWeekStart);
  };

  const dates = getWeekDates(currentWeekStart);

  useEffect(() => {
    getSideBarNotifications(new Date());
  }, []);
  useEffect(() => {
    setSelectedWeekDate(today);
  }, []);
  return (
    <Flex
      style={{
        border: `1px solid ${token.colorBorder}`,
      }}
      className="w-full rounded-2xl px-4 py-5 gap-5"
      vertical
    >
      <Flex>
        {/* Previous Week Button */}
        <Button
          disabled={isLoading}
          className="shadow-none border-none"
          onClick={handlePrevWeek}
          icon={<CustomIcon type="arrow-back" />}
        ></Button>

        {/* Dynamically display the current month or range of months */}
        <h3 className="font-medium !text-base m-auto">
          {getCurrentMonthYear(currentWeekStart, currentWeekEnd, "name")}
        </h3>

        {/* Next Week Button */}
        <Button
          disabled={isLoading}
          className="border-none shadow-none"
          onClick={handleNextWeek}
          icon={<CustomIcon type="arrow-back" className="-scale-x-100" />}
        ></Button>
      </Flex>

      <Flex
        className="gap-3 !w-full font-normal !text-neutral-7"
        align="center"
      >
        {dates?.map((data, index) => (
          <Flex vertical className="w-full items-center gap-2" key={data?.day}>
            <span>{data?.day}</span>
            <Button
              onClick={() => setSelectedWeekDate(data?.dateObject)}
              className={`!border-0 w-full ${
                selectedWeekDate?.toDateString() ===
                data?.dateObject?.toDateString()
                  ? "!bg-lightOrange text-primary hover:!bg-lightOrange"
                  : "!bg-neutral-0 text-neutral-7 hover:!bg-neutral-0"
              }`}
            >
              <span
                className={`${
                  data?.hasEvent?.[index]
                    ? "border-b-2 border-b-primary"
                    : "border-transparent"
                } w-full`}
              >
                {data?.date}
              </span>
            </Button>
          </Flex>
        ))}
      </Flex>
    </Flex>
  );
}
