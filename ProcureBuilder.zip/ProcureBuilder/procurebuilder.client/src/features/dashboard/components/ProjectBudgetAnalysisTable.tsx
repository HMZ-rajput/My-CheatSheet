import {
  getMaterialCostAnalysisByProjectId,
  GetMaterialCostAnalysisByProjectIdResponse,
} from "@/src/apis/dashboardApis";
import HighlightedText from "@/src/components/common/HighlightedText";
import CustomTable from "@/src/components/table/CustomTable";
import { getLocaleNumberStringWithSigns } from "@/src/utils/string-extensions";
import { MaterialCostAnalysisRowType } from "@/src/utils/types";
import { TableProps } from "antd";
import { useEffect, useMemo, useState } from "react";
import { useReports } from "../../reports/contexts/ReportsProvider";

interface ProjectBudgetAnalysisTableProps {
  selectedProjectId: string;
  className?: string;
  isInsideReports?: boolean;
  exportButtonEl?: React.ReactNode | null;
  setReportStats?: null | React.Dispatch<
    React.SetStateAction<{
      totalBudgetCost: number;
      totalBudgetQuantity: number;
      totalBudgetUnitRate: number;
      totalCommittedCost: number;
      totalCommittedQuantity: number;
      totalCommittedUnitRate: number;
      totalCostDifference: number;
      totalQuantityDifference: number;
      totalUnitRateDifference: number;
    }>
  >;
  syncState?: null | React.Dispatch<
    React.SetStateAction<{
      data: MaterialCostAnalysisRowType[];
      isLoading: boolean;
    }>
  >;
}

const ProjectBudgetAnalysisTable = ({
  selectedProjectId,
  className,
  isInsideReports = false,
  syncState = null,
  setReportStats = null,
  exportButtonEl = null,
}: ProjectBudgetAnalysisTableProps) => {
  const { filterValues } = useReports();
  const [isLoading, setIsLoading] = useState(false);
  const [data, setData] = useState<MaterialCostAnalysisRowType[]>([]);
  const [searchTerm, setSearchTerm] = useState("");

  const calculateStats = (
    response: GetMaterialCostAnalysisByProjectIdResponse
  ) => {
    const stats = {
      totalBudgetCost: 0,
      totalBudgetQuantity: 0,
      totalBudgetUnitRate: 0,
      totalCommittedCost: 0,
      totalCommittedQuantity: 0,
      totalCommittedUnitRate: 0,
      totalCostDifference: 0,
      totalQuantityDifference: 0,
      totalUnitRateDifference: 0,
    };
    const materials = Array.isArray(response?.materials)
      ? response?.materials
      : [];

    materials.forEach((material) => {
      stats.totalBudgetCost += material?.budgetCost || 0;
      stats.totalBudgetQuantity += material?.budgetQuantity || 0;
      stats.totalBudgetUnitRate += material?.budgetUnitRate || 0;

      stats.totalCommittedCost += material?.committedCost || 0;
      stats.totalCommittedQuantity += material?.committedQuantity || 0;
      stats.totalCommittedUnitRate += material?.committedUnitRate || 0;

      stats.totalCostDifference += material?.costDifference || 0;
      stats.totalQuantityDifference += material?.quantityDifference || 0;
      stats.totalUnitRateDifference += material?.unitRateDifference || 0;
    });

    return stats;
  };

  const filteredData = useMemo(() => {
    let newData = data;
    const {
      budgetQuantityStart,
      budgetQuantityEnd,
      budgetCostStart,
      budgetCostEnd,
      committedQuantityStart,
      committedQuantityEnd,
      committedCostStart,
      committedCostEnd,
      quantityDifferenceStart,
      quantityDifferenceEnd,
      costDifferenceStart,
      costDifferenceEnd,
    } = filterValues || {};

    if (searchTerm) {
      const lowercasedSearchTerm = searchTerm?.toLowerCase()?.trim() || "";
      newData = data?.filter((f) => {
        const lowercasedCostCode = f?.costCode?.toLowerCase()?.trim();
        const lowercasedUnitOfMeasurement = f?.unitOfMeasure
          ?.toLowerCase()
          ?.trim();

        return (
          lowercasedCostCode?.includes(lowercasedSearchTerm) ||
          lowercasedUnitOfMeasurement?.includes(lowercasedSearchTerm)
        );
      });
    }

    if (budgetQuantityStart) {
      newData = newData?.filter((f) => f.budgetQuantity >= budgetQuantityStart);
    }
    if (budgetQuantityEnd) {
      newData = newData?.filter((f) => f.budgetQuantity <= budgetQuantityEnd);
    }
    if (budgetCostStart) {
      newData = newData?.filter((f) => f.budgetCost >= budgetCostStart);
    }
    if (budgetCostEnd) {
      newData = newData?.filter((f) => f.budgetCost <= budgetCostEnd);
    }
    if (committedQuantityStart) {
      newData = newData?.filter(
        (f) => f.committedQuantity >= committedQuantityStart
      );
    }
    if (committedQuantityEnd) {
      newData = newData?.filter(
        (f) => f.committedQuantity <= committedQuantityEnd
      );
    }
    if (committedCostStart) {
      newData = newData?.filter((f) => f.committedCost >= committedCostStart);
    }
    if (committedCostEnd) {
      newData = newData?.filter((f) => f.committedCost <= committedCostEnd);
    }

    if (quantityDifferenceStart) {
      newData = newData?.filter(
        (f) => f.quantityDifference >= quantityDifferenceStart
      );
    }
    if (quantityDifferenceEnd) {
      newData = newData?.filter(
        (f) => f.quantityDifference <= quantityDifferenceEnd
      );
    }

    if (costDifferenceStart) {
      newData = newData?.filter((f) => f.costDifference >= costDifferenceStart);
    }
    if (costDifferenceEnd) {
      newData = newData?.filter((f) => f.costDifference <= costDifferenceEnd);
    }

    return newData;
  }, [data, filterValues, searchTerm]);

  useEffect(() => {
    if (syncState && typeof syncState === "function") {
      syncState({ data: filteredData, isLoading });
    }
  }, [filteredData, isLoading]);
  useEffect(() => {
    if (!selectedProjectId) return;
    const fetchMaterialCostAnalysis = async () => {
      setIsLoading(true);
      setData(() => []);

      try {
        const res = await getMaterialCostAnalysisByProjectId({
          isForReport: isInsideReports,
          projectId: selectedProjectId,
        });

        if (res.isSuccess) {
          setData(() => res?.materials || []);
        } else {
          setData(() => []);
        }

        if (typeof setReportStats === "function") {
          const stats = calculateStats(res);
          setReportStats({
            totalBudgetCost: stats?.totalBudgetCost || 0,
            totalBudgetQuantity: stats?.totalBudgetQuantity || 0,
            totalBudgetUnitRate: stats?.totalBudgetUnitRate || 0,
            totalCommittedCost: stats?.totalCommittedCost || 0,
            totalCommittedQuantity: stats?.totalCommittedQuantity || 0,
            totalCommittedUnitRate: stats?.totalCommittedUnitRate || 0,
            totalCostDifference: stats?.totalCostDifference || 0,
            totalQuantityDifference: stats?.totalQuantityDifference || 0,
            totalUnitRateDifference: stats?.totalUnitRateDifference || 0,
          });
        }
      } catch (error) {
        setData(() => []);
        console.error(error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchMaterialCostAnalysis();
  }, [selectedProjectId, filterValues]);

  const columns: TableProps<MaterialCostAnalysisRowType>["columns"] = [
    {
      title: "Cost Code",
      dataIndex: "costCode",
      key: "costCode",
      render: (text: string) => (
        <HighlightedText searchTerm={searchTerm} text={text} />
      ),
    },
    {
      title: "Unit of Measurement",
      dataIndex: "unitOfMeasure",
      key: "unitOfMeasure",
      render: (text: string) => (
        <HighlightedText searchTerm={searchTerm} text={text} />
      ),
    },
    {
      title: "Budget Quantity",
      dataIndex: "budgetQuantity",
      key: "budgetQuantity",
    },
    {
      title: "Budget Unit Rate",
      dataIndex: "budgetUnitRate",
      key: "budgetUnitRate",
      render: (text: number) => (
        <p>{getLocaleNumberStringWithSigns(text, "$")}</p>
      ),
    },
    {
      title: "Budget Cost",
      dataIndex: "budgetCost",
      key: "budgetCost",
      render: (text: number) => (
        <p>{getLocaleNumberStringWithSigns(text, "$")}</p>
      ),
    },
    {
      title: "Committed Quantity",
      dataIndex: "committedQuantity",
      key: "committedQuantity",
    },
    {
      title: "Committed Unit Rate",
      dataIndex: "committedUnitRate",
      key: "committedUnitRate",
      render: (text: number) => (
        <p>{getLocaleNumberStringWithSigns(text, "$")}</p>
      ),
    },
    {
      title: "Committed Cost",
      dataIndex: "committedCost",
      key: "committedCost",
      render: (text: number) => (
        <p>{getLocaleNumberStringWithSigns(text, "$")}</p>
      ),
    },
    {
      title: "Quantity Difference",
      dataIndex: "quantityDifference",
      key: "quantityDifference",
    },
    {
      title: "Cost Difference",
      dataIndex: "costDifference",
      key: "costDifference",
      render: (text: number, { isOverBudget }: MaterialCostAnalysisRowType) => {
        return (
          <p
            className={`p-3 ${
              isOverBudget ? "text-danger-5 bg-danger-5-14" : ""
            }`}
          >
            {getLocaleNumberStringWithSigns(text, "$")}
          </p>
        );
      },
    },
  ];
  return (
    <CustomTable
      className={`cost-analysis-table ${className}`}
      data={filteredData || []}
      columns={columns || []}
      isLoading={isLoading || false}
      hasSearch={isInsideReports || false}
      setSearchTerm={setSearchTerm}
      isInsideReports={isInsideReports}
      // When filters are cleared, the URL does not update
      reportFilterForParamsUseOnly={{
        ...filterValues,
        budgetQuantityStart: filterValues?.budgetQuantityStart || null,
        budgetQuantityEnd: filterValues?.budgetQuantityEnd || null,
        budgetCostStart: filterValues?.budgetCostStart || null,
        budgetCostEnd: filterValues?.budgetCostEnd || null,
        committedQuantityStart: filterValues?.committedQuantityStart || null,
        committedQuantityEnd: filterValues?.committedQuantityEnd || null,
        committedCostStart: filterValues?.committedCostStart || null,
        committedCostEnd: filterValues?.committedCostEnd || null,
        quantityDifferenceStart: filterValues?.quantityDifferenceStart || null,
        quantityDifferenceEnd: filterValues?.quantityDifferenceEnd || null,
        costDifferenceStart: filterValues?.costDifferenceStart || null,
        costDifferenceEnd: filterValues?.costDifferenceEnd || null,
      }}
      exportButtonEl={exportButtonEl}
      hideSearchBtn
      // The URL parameter becomes empty because tableFilter is empty. The only job of tableFilter is to preset the URL when the page reloads.
      tableFilters={filterValues || undefined}
    />
  );
};

export default ProjectBudgetAnalysisTable;
