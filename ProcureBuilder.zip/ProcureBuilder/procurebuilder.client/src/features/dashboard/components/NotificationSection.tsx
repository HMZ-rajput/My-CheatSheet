import React, { useCallback, useMemo } from "react";
import { FixedSizeList as List, ListChildComponentProps } from "react-window";
import AutoSizer from "react-virtualized-auto-sizer";
import CustomIcon, { IconType } from "@/src/components/common/CustomIcon";
import { NotificationSectionTypeEnum } from "@/src/utils/enums";
import { DashboardNotificationWithCustomProps } from "@/src/utils/types";
import useToken from "@hooks/useToken";
import { Divider, Flex } from "antd";
import NotificationActionButtons from "./NotificationsActionButtons";
import { NotificationMarkAsReadButton } from "./NotificationMarkAsReadButton";

// NotificationItem Component
interface NotificationItemProps {
  notification: DashboardNotificationWithCustomProps;
  notificationSectionType: NotificationSectionTypeEnum;
}

const NotificationItem = React.memo<NotificationItemProps>(
  ({ notification, notificationSectionType }) => (
    <Flex className="w-full rounded-2xl px-4 py-4 justify-between items-center border border-gray-3">
      <NotificationMarkAsReadButton
        notificationId={notification.id}
        notificationSectionType={notificationSectionType}
      />

      <Flex align="center" className="gap-4 !basis-5/6">
        <div className="flex-shrink-0">
          <CustomIcon
            type={notification.entityIconType}
            width={48}
            height={48}
          />
        </div>
        <p className="font-normal !text-sm m-0 !text-gray-2 flex-1 min-w-0">
          {notification.description}
        </p>
      </Flex>

      <Flex className="ml-auto justify-between space-x-3">
        <NotificationActionButtons
          actionType={notification.action}
          entityId={notification.entityId}
          entityType={notification.entityType}
          projectId={notification.projectId}
          notificationId={notification.id}
          materials={notification.materials || []}
          notificationSectionType={notificationSectionType}
        />
      </Flex>
    </Flex>
  ),
  (prevProps, nextProps) => {
    const prev = prevProps.notification;
    const next = nextProps.notification;

    return (
      prev.id === next.id &&
      prev.description === next.description &&
      prev.entityIconType === next.entityIconType &&
      prev.action === next.action &&
      prevProps.notificationSectionType === nextProps.notificationSectionType
    );
  }
);

// VirtualizedNotificationList Component
interface VirtualizedNotificationListProps {
  notifications: DashboardNotificationWithCustomProps[];
  notificationSectionType: NotificationSectionTypeEnum;
}

const ITEM_HEIGHT = 90;
const MAX_HEIGHT = 276; // max-h-96

const VirtualizedNotificationList =
  React.memo<VirtualizedNotificationListProps>(
    ({ notifications, notificationSectionType }) => {
      const Row = useCallback(
        ({ index, style }: ListChildComponentProps) => (
          <div style={style}>
            <NotificationItem
              notification={notifications[index]}
              notificationSectionType={notificationSectionType}
            />
          </div>
        ),
        [notifications, notificationSectionType]
      );

      const listHeight = useMemo(
        () => Math.min(notifications.length * ITEM_HEIGHT, MAX_HEIGHT),
        [notifications.length]
      );

      if (notifications.length === 0) {
        return (
          <div className="flex items-center justify-center h-32">
            <p className="text-gray-400">No items available</p>
          </div>
        );
      }

      return (
        <div style={{ height: listHeight, width: "100%" }}>
          <AutoSizer>
            {({ height, width }: { height: number; width: number }) => (
              <List
                height={height}
                width={width}
                itemCount={notifications.length}
                itemSize={ITEM_HEIGHT}
                overscanCount={3}
              >
                {Row}
              </List>
            )}
          </AutoSizer>
        </div>
      );
    },
    (prevProps, nextProps) =>
      prevProps.notifications === nextProps.notifications &&
      prevProps.notificationSectionType === nextProps.notificationSectionType
  );

// NotificationSectionHeader Component
interface NotificationSectionHeaderProps {
  title: string;
  iconType: IconType;
}

const NotificationSectionHeader = React.memo<NotificationSectionHeaderProps>(
  ({ title, iconType }) => (
    <Flex align="center">
      <CustomIcon type={iconType} className="mr-3" width={32} height={32} />
      <h3 className="font-medium !text-base m-0">{title}</h3>
    </Flex>
  ),
  (prevProps, nextProps) =>
    prevProps.title === nextProps.title &&
    prevProps.iconType === nextProps.iconType
);

// Main NotificationSection Component
type NotificationSectionProps = {
  title: string;
  iconType: IconType;
  notifications: DashboardNotificationWithCustomProps[];
  notificationSectionType: NotificationSectionTypeEnum;
};

const NotificationSection = React.memo<NotificationSectionProps>(
  ({ title, iconType, notifications, notificationSectionType }) => {
    const token = useToken();

    const containerStyle = useMemo(
      () => ({
        border: `1px solid ${token.colorBorder}`,
      }),
      [token.colorBorder]
    );

    return (
      <Flex
        vertical
        style={containerStyle}
        className="w-full rounded-2xl px-4 py-4 max-h-96"
      >
        <NotificationSectionHeader title={title} iconType={iconType} />
        <Divider className="!my-4" />
        <div className="flex-1 min-h-0 px-4">
          <VirtualizedNotificationList
            notifications={notifications}
            notificationSectionType={notificationSectionType}
          />
        </div>
      </Flex>
    );
  },
  (prevProps, nextProps) => {
    if (prevProps.title !== nextProps.title) return false;
    if (prevProps.iconType !== nextProps.iconType) return false;
    if (prevProps.notificationSectionType !== nextProps.notificationSectionType)
      return false;
    if (prevProps.notifications.length !== nextProps.notifications.length)
      return false;

    // Reference equality check first (fastest)
    if (prevProps.notifications === nextProps.notifications) return true;

    // Shallow ID comparison as fallback
    for (let i = 0; i < prevProps.notifications.length; i++) {
      if (prevProps.notifications[i].id !== nextProps.notifications[i].id) {
        return false;
      }
    }

    return true;
  }
);

export default NotificationSection;
