import CustomIcon from "@/src/components/common/CustomIcon";
import { EntityTypeEnum } from "@/src/utils/enums";
import { SideNotificationsType } from "@/src/utils/types";
import useToken from "@hooks/useToken";
import { Flex } from "antd";
import { IconType } from "@/src/components/common/CustomIcon";
import dayjs from "dayjs";

type TimelineSectionProps = {
  sideNotifications: SideNotificationsType[];
};

export default function TimelineSection({
  sideNotifications,
}: TimelineSectionProps) {
  const token = useToken();

  const getEntityIconType = (entityType: number) => {
    switch (entityType) {
      case EntityTypeEnum.Project:
        return "project-manager-icon";
      case EntityTypeEnum.PurchaseOrder:
        return "dashboard-purchase-order-icon";
      case EntityTypeEnum.Reorder:
        return "dashboard-reorder-icon";
      case EntityTypeEnum.ChangeOrder:
        return "dashboard-changeOrder-icon";
      case EntityTypeEnum.Invoice:
        return "dashboard-invoice-icon";
      case EntityTypeEnum.MaterialTransfer:
        return "dashboard-material-transfer-icon";
      case EntityTypeEnum.MaterialToSite:
        return "dashboard-material-expected-icon";
      case EntityTypeEnum.MaterialReceiptInspection:
        return "dashboard-material-receipt-inspection-icon";
      default:
        return "dashboard-project-icon";
    }
  };
  return (
    <Flex
      vertical
      style={{
        border: `1px solid ${token.colorBorder}`,
        display: sideNotifications?.length === 0 ? "none" : "",
      }}
      className="w-full rounded-2xl px-3 py-6 gap-8 max-h-[500px] overflow-y-auto"
    >
      {sideNotifications ? (
        sideNotifications?.map((item, index) => (
          <Flex key={index} className="gap-4" align="center">
            <Flex>
              <CustomIcon
                type={getEntityIconType(item?.entityType) as IconType}
              />
            </Flex>
            <Flex vertical className="gap-1">
              <span className="font-medium text-neutral-7 text-xs">
                {item.title.toUpperCase()}
              </span>
              <span className="font-medium text-black900">
                {item.description}
              </span>
              <span className="font-normal text-neutral-7 text-xs flex flex-row items-center gap-1">
                {dayjs(item.date).format("MMM DD YYYY")}
              </span>
            </Flex>
          </Flex>
        ))
      ) : (
        <div>
          <h1>No Notifications</h1>
        </div>
      )}
    </Flex>
  );
}
