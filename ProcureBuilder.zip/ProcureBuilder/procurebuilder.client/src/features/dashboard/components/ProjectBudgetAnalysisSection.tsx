import CustomIcon from "@/src/components/common/CustomIcon";
import CustomTabs from "@/src/components/common/CustomTabs";
import { useAppSelector } from "@/src/hooks/useAppSelector";
import { getProjectsState } from "@/src/store/slices/projectsSlice";
import useToken from "@hooks/useToken";
import { Divider, Flex, Select } from "antd";
import { useMemo, useState } from "react";
import { useParams } from "react-router-dom";
import ProjectBudgetAnalysisTable from "./ProjectBudgetAnalysisTable";

export default function ProjectBudgetAnalysisSection() {
  const { projectId } = useParams();
  const { projectsSummarizedData } = useAppSelector(getProjectsState);

  const token = useToken();

  const memoizedTop5ProjectsData = useMemo(() => {
    return projectsSummarizedData?.slice(0, 5) || [];
  }, [projectsSummarizedData]);
  const memoizedRemainingProjectsData = useMemo(() => {
    return [
      {
        id: "",
        name: "Select Project",
      },
      ...(projectsSummarizedData?.slice(
        5,
        (projectsSummarizedData?.length || 0) - 1
      ) || []),
    ];
  }, [projectsSummarizedData]);

  const [selectedProjectId, setSelectedProjectId] = useState<string>(
    projectId || memoizedTop5ProjectsData?.[0]?.id || ""
  );

  const projectsTabs =
    memoizedTop5ProjectsData?.reduce<{ [key: string]: string }>(
      (acc, project) => {
        acc[project.id] = project.name;
        return acc;
      },
      {}
    ) || {};

  function handleTabChange(projectId: string) {
    const project = projectsSummarizedData?.find((f) => f.id === projectId);

    if (project) {
      setSelectedProjectId(project?.id);
    }
  }

  return (
    <Flex
      vertical
      style={{
        border: `1px solid ${token.colorBorder}`,
      }}
      className="w-full rounded-2xl px-4 py-4"
    >
      <Flex className="" align="center">
        <CustomIcon
          type="budget-analysis-icon"
          className="mr-2"
          width={24}
          height={24}
        />
        <h3 className="font-medium !text-base m-0">
          Project Budget vs. Committed Costs Analysis
        </h3>
      </Flex>
      <Divider className="!my-4" />

      {!projectId && (
        <Flex className="mb-7">
          <CustomTabs
            options={Object.entries(projectsTabs)?.map(([key, name]) => ({
              value: key,
              label: name,
            }))}
            tabLabel={
              projectsSummarizedData?.find((f) => f.id === selectedProjectId)
                ?.name || ""
            }
            tabValue={selectedProjectId || ""}
            onChange={handleTabChange}
            isRounded={false}
            shouldReturnValueOnChange
            shouldFilterByValue
          />
          <Select
            className="mt-0.5 ml-2 w-48"
            value={
              memoizedRemainingProjectsData?.find(
                (f) => f.id === selectedProjectId
              )?.id || ""
            }
            onChange={(value) => setSelectedProjectId(value)}
            options={(memoizedRemainingProjectsData || [])?.map((m) => ({
              value: m.id,
              label: m.name,
            }))}
            placeholder="More Projects"
            showSearch
            filterOption={(input, option) =>
              (option?.label ?? "").toLowerCase().includes(input.toLowerCase())
            }
          />
        </Flex>
      )}

      <ProjectBudgetAnalysisTable
        className="h-96"
        selectedProjectId={selectedProjectId}
      />
    </Flex>
  );
}
