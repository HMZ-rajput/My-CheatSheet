import { DashboardNotificationWithCustomProps } from "@/src/utils/types";
import React from "react";
import NotificationSection from "./NotificationSection";
import { NotificationSectionTypeEnum } from "@/src/utils/enums";

type DeliverablesSectionProps = {
  deliverables: DashboardNotificationWithCustomProps[] | [];
};

const DeliverablesSection = React.memo(
  ({ deliverables }: DeliverablesSectionProps) => {
    return (
      <NotificationSection
        title="Upcoming Deliverables"
        iconType="truck-icon"
        notifications={deliverables}
        notificationSectionType={NotificationSectionTypeEnum.UPCOMING_ITEMS}
      />
    );
  }
);

export default DeliverablesSection;
