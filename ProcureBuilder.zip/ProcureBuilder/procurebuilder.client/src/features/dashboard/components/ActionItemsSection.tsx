import { DashboardNotificationWithCustomProps } from "@/src/utils/types";
import React from "react";
import NotificationSection from "./NotificationSection";
import { NotificationSectionTypeEnum } from "@/src/utils/enums";

type ActionItemsSectionProps = {
  actionItems: DashboardNotificationWithCustomProps[] | [];
};

const ActionItemsSection = React.memo(
  ({ actionItems }: ActionItemsSectionProps) => {
    return (
      <NotificationSection
        title="Action Items for You"
        iconType="action-item-icon"
        notifications={actionItems}
        notificationSectionType={NotificationSectionTypeEnum.ACTION_ITEMS}
      />
    );
  }
);

export default ActionItemsSection;
