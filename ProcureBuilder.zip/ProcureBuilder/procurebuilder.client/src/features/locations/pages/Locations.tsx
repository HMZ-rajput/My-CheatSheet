import CustomIcon from "@/src/components/common/CustomIcon";
import PageLayout from "@/src/components/layout/PageLayout";
import routePaths from "@/src/utils/routePaths";
import { getConsistentSpacing } from "@/src/utils/theme-helpers";
import { Button, Flex } from "antd";
import { useNavigate } from "react-router-dom";
import LocationList from "../components/LocationList";
import useAuthorization from "@/src/hooks/useAuthorization";

const Locations = () => {
  const navigate = useNavigate();
  const { isFieldsCraftAuthorized } = useAuthorization();
  return (
    <PageLayout
      title="Locations"
      titleSibling={
        <Flex gap={"10px"}>
          {!isFieldsCraftAuthorized() && (
            <Button
              size="large"
              type="primary"
              icon={
                <CustomIcon
                  type="plus"
                  className="fill-white"
                  width={parseInt(getConsistentSpacing(3))}
                  height={parseInt(getConsistentSpacing(3))}
                />
              }
              onClick={() => navigate(routePaths.LOCATION_NEW)}
            >
              New Location
            </Button>
          )}
        </Flex>
      }
    >
      <LocationList />
    </PageLayout>
  );
};

export default Locations;
