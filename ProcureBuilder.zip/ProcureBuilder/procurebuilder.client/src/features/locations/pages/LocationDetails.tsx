import LocationDetailsForm from "@/src/features/locations/components/LocationDetailsFormRHF";
import routePaths from "@/src/utils/routePaths";
import { useLocation, useNavigate } from "react-router-dom";

export default function LocationDetailsPage() {
  const location = useLocation();
  const navigate = useNavigate();

  const handleCancel = () => {
    const previousPath = location?.state?.previousPath || "";
    if (previousPath) {
      navigate(previousPath);
    } else {
      navigate(routePaths.LOCATIONS);
    }
  };

  return (
    <>
      <LocationDetailsForm handleCancelForm={handleCancel} />
    </>
  );
}
