// import CustomFormLabel from "@/src/components/common/CustomFormLabel";
// import CustomIcon from "@/src/components/common/CustomIcon";
// import { FormikLibraryHelperType } from "@/src/utils/library-helper-types";
// import { LocationInfo, SubLocation } from "@/src/utils/types";
// import { Button, Col, Form, Input } from "antd";
// import React from "react";

// type SublocationFormSectionProps = {
//   formik: FormikLibraryHelperType<LocationInfo>;
//   parentLocationIndex: number;
//   parentLocationId: string | null;
//   handleChangeParentLocation: (
//     fieldName: string,
//     value: string | SubLocation[],
//     index: number
//   ) => void;
// };
// export default function SubLocationFormSection(
//   props: SublocationFormSectionProps
// ) {
//   const { formik } = props;

//   function handleChange(fieldName: string, value: string, index: number) {
//     const subLocations = (formik.values.locations[props.parentLocationIndex]
//       ?.subLocations || []) as SubLocation[];
//     const updatedSubLocations = subLocations.map((subLocation, id: number) => {
//       if (id === index) {
//         const updatedLocation = {
//           ...subLocation,
//           [fieldName]: value,
//         };

//         return updatedLocation;
//       }
//       return subLocation;
//     });

//     props.handleChangeParentLocation(
//       "subLocations",
//       updatedSubLocations,
//       props.parentLocationIndex
//     );
//   }
//   function handleAddSubLocation(add: () => void) {
//     const newSubLocation: SubLocation = {
//       id: null,
//       name: "",
//       projectLocationId: props.parentLocationId,
//     };
//     const subLocations = (formik.values.locations[props.parentLocationIndex]
//       .subLocations || []) as SubLocation[];

//     props.handleChangeParentLocation(
//       "subLocations",
//       [...subLocations, newSubLocation],
//       props.parentLocationIndex
//     );
//     add();
//   }
//   function handleRemoveSubLocation(
//     index: number,
//     remove: (index: number) => void
//   ) {
//     const subLocations = (formik.values.locations[props.parentLocationIndex]
//       .subLocations || []) as SubLocation[];

//     props.handleChangeParentLocation(
//       "subLocations",
//       subLocations?.filter((_, i) => i !== index),
//       props.parentLocationIndex
//     );
//     remove(index);
//   }

//   return (
//     <>
//       <Form.List
//         initialValue={
//           typeof props.parentLocationIndex === "number"
//             ? formik.values.locations[props.parentLocationIndex]?.subLocations
//             : []
//         }
//         name="subLocations"
//       >
//         {(fields, { add, remove }) => (
//           <>
//             {fields.map(({ key }, index) => (
//               <React.Fragment key={key}>
//                 <Col xs={24} className="flex items-end">
//                   <Form.Item
//                     className="w-1/2 pr-2"
//                     label={
//                       <CustomFormLabel
//                         text={`Sublocation ${String(index + 1).padStart(
//                           2,
//                           "0"
//                         )}`}
//                       />
//                     }
//                     // name="name"
//                     labelAlign="right"
//                     initialValue={
//                       (
//                         (formik.values.locations[props.parentLocationIndex]
//                           .subLocations || [])[index] as SubLocation
//                       )?.name
//                     }
//                     required
//                   >
//                     <Input
//                       value={
//                         (
//                           (formik.values.locations[props.parentLocationIndex]
//                             .subLocations || [])[index] as SubLocation
//                         )?.name
//                       }
//                       onChange={(event) =>
//                         handleChange("name", event?.target?.value || "", index)
//                       }
//                       size="large"
//                       placeholder="Sublocation"
//                     />
//                   </Form.Item>
//                   <Button
//                     onClick={() => handleRemoveSubLocation(index, remove)}
//                     className="px-2 py-1 mb-5 !text-primary"
//                     type="text"
//                   >
//                     Delete
//                   </Button>
//                 </Col>
//               </React.Fragment>
//             ))}

//             <Col xs={24}>
//               <Form.Item>
//                 <Button
//                   className="border-0 shadow-none text-primary font-medium"
//                   size="small"
//                   icon={<CustomIcon type="plus" className="fill-primary" />}
//                   onClick={() => handleAddSubLocation(add)}
//                 >
//                   Add another Sublocation
//                 </Button>
//               </Form.Item>
//             </Col>
//           </>
//         )}
//       </Form.List>
//     </>
//   );
// }

const SubLocationFormSection = () => {
  return <div>SubLocationFormSection</div>;
};

export default SubLocationFormSection;
