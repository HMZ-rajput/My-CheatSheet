import {
  createStorageType,
  updateStorageType,
} from "@/src/apis/storageTypeApis";
import { resetState } from "@/src/store/slices/storageTypeSlice";
import CustomModal from "@/src/components/common/CustomModal";
import { useAppDispatch } from "@/src/hooks/useAppDispatch";
import { useAppSelector } from "@/src/hooks/useAppSelector";
import { getStorageTypesState } from "@/src/store/slices/storageTypeSlice";
import { Form, Input } from "antd";
import { Dispatch, SetStateAction, useEffect } from "react";
import { useFormik } from "formik";
import * as Yup from "yup";
import CustomAlert from "@/src/components/common/CustomAlert";

type StorageTypeModalProps = {
  isOpen: boolean;
  setIsOpen: Dispatch<SetStateAction<boolean>>;
  setStorageTypeId: (id: string) => void;
  editStorageType: { label: string; value: string | null } | null;
  setEditStorageType: Dispatch<
    SetStateAction<{ label: string; value: string | null } | null>
  >;
};

const StorageTypeModal = ({
  setStorageTypeId,
  ...props
}: StorageTypeModalProps) => {
  const { reqError, resError, successMessage, isSuccess } =
    useAppSelector(getStorageTypesState);
  const dispatch = useAppDispatch();
  const { setIsOpen, isOpen, editStorageType, setEditStorageType } = props;
  const validationSchema = Yup.object({
    name: Yup.string().required("Please enter a storage type name!"),
    id: Yup.string(),
  });

  const formik = useFormik({
    initialValues: { name: "", id: "" },
    validationSchema,
    onSubmit: async (values, { resetForm, setSubmitting }) => {
      dispatch(resetState());
      try {
        if (editStorageType?.value) {
          setSubmitting(true);
          const res = await dispatch(
            updateStorageType({ id: values.id, name: values.name })
          ).unwrap();

          if (res?.isSuccess) {
            setStorageTypeId(res.storageType?.id);
            handleCancel();
            resetForm();
          }
        } else {
          setSubmitting(true);
          const res = await dispatch(createStorageType(values)).unwrap();

          if (res.isSuccess) {
            setStorageTypeId(res.storageType?.id);
            handleCancel();
            resetForm();
          }
        }
      } catch (err) {
        console.log(err);
      } finally {
        setSubmitting(false);
      }
    },
  });

  const handleCancel = () => {
    setIsOpen(false);
  };

  useEffect(() => {
    if (isSuccess) {
      setIsOpen(false);
      formik.resetForm();
    }
  }, [isSuccess, setIsOpen, formik]);

  useEffect(() => {
    dispatch(resetState());
    formik.resetForm();
    if (!isOpen) {
      setEditStorageType(null);
    }
  }, [isOpen]);

  useEffect(() => {
    if (reqError || resError) dispatch(resetState());
  }, [formik.values]);

  useEffect(() => {
    if (editStorageType?.value) {
      formik.setFieldValue("name", editStorageType.label);
      formik.setFieldValue("id", editStorageType.value);
    }
  }, [editStorageType]);

  return (
    <CustomModal
      title={
        editStorageType?.value ? "Edit New Storage" : "Add New Storage Type"
      }
      primaryButtonText={editStorageType?.value ? "Update" : "Add"}
      primaryButtonLoadingText={
        editStorageType?.value ? "Updating..." : "Adding..."
      }
      width={500}
      isLoading={formik.isSubmitting}
      isOpen={isOpen}
      primaryButtonAction={formik.handleSubmit} // Formik's handleSubmit
      cancelButtonAction={handleCancel}
    >
      <Form
        name="basic"
        labelCol={{ span: 7 }}
        wrapperCol={{ span: 16 }}
        style={{
          maxWidth: 500,
        }}
        onFinish={formik.handleSubmit}
        autoComplete="off"
      >
        <Form.Item
          label="Storage Type"
          required
          validateStatus={
            formik.touched.name && formik.errors.name ? "error" : ""
          }
          help={
            formik.touched.name && formik.errors.name ? formik.errors.name : ""
          }
        >
          <Input
            name="name"
            value={formik.values.name}
            onChange={formik.handleChange}
            placeholder="Enter Storage Type Name"
          />
        </Form.Item>
      </Form>
      {(reqError || successMessage || resError) && (
        <CustomAlert
          message={reqError || resError || successMessage || ""}
          type={successMessage ? "success" : "error"}
        />
      )}
    </CustomModal>
  );
};

export default StorageTypeModal;
