import {
  createLocation,
  CreateLocationRequest,
  deleteLocationById,
  editLocationById,
  getLocationListForSideBar,
  getLocationslist,
} from "@/src/apis/locationApis";
import CreatedByUserBadge from "@/src/components/common/CreatedByUserBadge";
import CustomAlert from "@/src/components/common/CustomAlert";
import CustomFormLabel from "@/src/components/common/CustomFormLabel";
import CustomIcon from "@/src/components/common/CustomIcon";
import CustomFormRow from "@/src/components/form/CustomFormRow";
import DeleteIconButton from "@/src/components/icon-buttons/DeleteIconButton";
import { useAppDispatch } from "@/src/hooks/useAppDispatch";
import { useAppSelector } from "@/src/hooks/useAppSelector";
import {
  getLocationsState,
  resetState,
} from "@/src/store/slices/locationSlice";
import { getStorageTypesState } from "@/src/store/slices/storageTypeSlice";
import { Location, LocationInfo, ProjectType } from "@/src/utils/types";
import { EditOutlined, PlusOutlined } from "@ant-design/icons";
import { yupResolver } from "@hookform/resolvers/yup";
import {
  Button,
  Col,
  Divider,
  Flex,
  Form,
  Input,
  Select,
  Space,
  Typography,
} from "antd";
import React, { useEffect, useMemo, useState } from "react";
import { Controller, Resolver, useFieldArray, useForm } from "react-hook-form";
import { useParams } from "react-router-dom";
import * as Yup from "yup";
import LocationInfoSubLocations from "./LocationInfoSublocationsRHF";
import StorageTypeModal from "./StorageTypeModal";
import useAuthorization from "@/src/hooks/useAuthorization";
import { getAllStorageTypes } from "@/src/apis/storageTypeApis";

type LocationInfoFormSectionProps = {
  locations: Location[] | null;
  handleCancelForm: () => void;
  getLocationsForProject: () => void;
  newLocations: Location[];
  setNewLocations: React.Dispatch<React.SetStateAction<Location[]>>;
  setLocations: React.Dispatch<React.SetStateAction<Location[]>>;
  tabToRender: string;
  setSelectedTab: React.Dispatch<React.SetStateAction<string>>;
  displayForm: boolean;
};

type FormValues = {
  projectId: string;
  locations: (
    | Location
    | {
        name: string;
        address: string;
        nearestCrossStreets: string;
        storageTypeId: null;
        id: null;
        subLocations: {
          id: null;
          name: string;
          projectLocationId: null;
        }[];
      }
  )[];
};

export default function LocationInfoFormSection(
  props: LocationInfoFormSectionProps
) {
  const { projectId } = useParams();
  const {
    locations,
    setLocations,
    handleCancelForm,
    getLocationsForProject,
    newLocations,
    setNewLocations,
    setSelectedTab,
    tabToRender,
  } = props;

  const [activeIndex, setActiveIndex] = useState<null | number>(null);
  const [isEdited, setIsEdited] = useState<boolean>(false);
  const [actionType, setActionType] = useState("");
  const [isDeleting, setIsDeleting] = useState(false);
  const [editStorageType, setEditStorageType] = useState<{
    label: string;
    value: string | null;
  } | null>(null);

  const { isFieldsCraftAuthorized } = useAuthorization();
  const dispatch = useAppDispatch();
  const [isOpen, setIsOpen] = useState(false);

  type FieldType = LocationInfo;
  const { successMessage, resError, reqError } =
    useAppSelector(getLocationsState);

  const [isCreated, setIsCreated] = useState<boolean>(
    locations?.length ? true : false
  );

  const { storageTypesData } = useAppSelector(getStorageTypesState);
  const memoizedStorageTypesOptions = useMemo(() => {
    return [
      {
        value: "",
        label: "Select Storage Type",
      },
      ...(storageTypesData?.map((f: ProjectType) => ({
        value: f?.id,
        label: f?.name,
      })) || []),
    ];
  }, [storageTypesData]);

  useEffect(() => {
    dispatch(getAllStorageTypes());
  }, [dispatch]);

  const handleOpenModal = (index: number) => {
    setIsOpen(!isOpen);
    setActiveIndex(index);
  };

  useEffect(() => {
    if (!isEdited) {
      return;
    }
    getLocationsForProject();
  }, [isEdited]);

  async function handleDeleteLocationById() {
    const payload = {
      projectId: projectId || "",
      locationsIdArray: locations?.map((m) => m.id) || [],
    };
    try {
      setIsDeleting(true);
      const res = await dispatch(deleteLocationById(payload)).unwrap();
      if (res.isSuccess) {
        dispatch(getLocationslist());
        dispatch(getLocationListForSideBar());
        setNewLocations([]);
        handleCancelForm();
      }
    } catch (error) {
      console.error("Error deleting project:", error);
    } finally {
      setIsDeleting(false);
    }
  }
  const initialStaticLocations = [
    {
      name: "",
      address: "",
      nearestCrossStreets: "",
      storageTypeId: null,
      id: null,
      subLocations: [
        {
          id: null,
          name: "",
          projectLocationId: null,
        },
      ],
    },
  ];

  const validationsSchema = Yup.object().shape({
    projectId: Yup.string().required("Project is required"),
    locations: Yup.array().of(
      Yup.object().shape({
        name: Yup.string().required("Location name is required"),
        address: Yup.string().required("Address is required"),
        storageTypeId: Yup.string().required("Storage Type is required"),
        subLocations: Yup.array().of(
          Yup.object().shape({
            name: Yup.string()
              .required("Sublocation name is required")
              .test(
                "unique-sublocation-name",
                "Sublocation names must be unique within a location",
                (value, ctx) => {
                  const [
                    { value: _ },
                    {
                      value: { subLocations },
                    },
                  ] = ctx.from as any;

                  if (!value) return false; // Fail validation if empty

                  // Count occurrences of this name
                  const occurrences = (subLocations || [])?.filter(
                    (sl: { name: string | null }) => sl.name === value
                  ).length;

                  // It's valid if there's exactly one occurrence
                  return occurrences === 1;
                }
              ),
          })
        ),
      })
    ),
  });
  useEffect(() => {
    dispatch(resetState());
  }, []);

  const {
    control,
    handleSubmit,
    setValue,
    formState: { isSubmitting, errors },
  } = useForm({
    resolver: yupResolver(validationsSchema) as unknown as Resolver<FormValues>,
    defaultValues: {
      projectId: projectId,
      locations: locations?.length ? locations : initialStaticLocations,
    },
  });

  const {
    fields: locationFields,
    append: appendLocation,
    remove: removeLocation,
  } = useFieldArray({
    control,
    name: "locations",
  });

  const handleSave = async (data: FormValues) => {
    const { locations: location, ...rest } = data;

    const payload = {
      ...rest,
      locations: location?.map((m) => ({
        ...m,
        nearestCrossStreets: m.nearestCrossStreets
          ? m.nearestCrossStreets
          : null,
        subLocations: m?.subLocations?.map((s) =>
          typeof s === "string" ? s : s.name
        ),
      })),
    };

    const editPayload = {
      ...rest,
      locations: location?.map((m) => ({
        ...m,
        nearestCrossStreets: m.nearestCrossStreets
          ? m.nearestCrossStreets
          : null,
      })),
    };
    try {
      if (locations?.length || isCreated) {
        const respone = await dispatch(editLocationById(editPayload)).unwrap();
        if (respone.isSuccess) {
          // @ts-ignore
          setLocations(respone?.locations);
          setIsEdited(respone.isSuccess);
          dispatch(getLocationslist());
          dispatch(getLocationListForSideBar());
        }
        return respone;
      } else {
        const response = await dispatch(
          createLocation(payload as CreateLocationRequest)
        ).unwrap();
        if (response.isSuccess) {
          setNewLocations(response.locations);
          dispatch(getLocationslist());
          dispatch(getLocationListForSideBar());
          setIsCreated(true);
        }
        return response;
      }
    } catch (err) {
      setTimeout(() => {
        dispatch(resetState());
      }, 3000);
    }
  };

  const onSubmit = async (data: FormValues) => {
    try {
      if (actionType === "save") {
        await handleSave(data);
      } else if (actionType === "saveAndClose") {
        const res = await handleSave(data);
        if (res?.isSuccess) {
          handleCancelForm();
        }
      }
    } catch (error) {
      console.error("Error during form submission:", error);
    }
  };
  const handleEditStorageType = (
    item: {
      label: string;
      value: string | null;
    },
    locationIndex: number
  ) => {
    setActiveIndex(locationIndex);
    setIsOpen(true);
    setEditStorageType(item);
  };

  return (
    <>
      <StorageTypeModal
        setIsOpen={setIsOpen}
        isOpen={isOpen && activeIndex !== null}
        editStorageType={editStorageType}
        setEditStorageType={setEditStorageType}
        setStorageTypeId={(id) => {
          if (activeIndex !== null) {
            setValue(`locations.${activeIndex}.storageTypeId`, id);
            setActiveIndex(null);
          }
        }}
      />
      <>
        <Form
          onFinish={handleSubmit(onSubmit)}
          layout="vertical"
          disabled={isFieldsCraftAuthorized()}
        >
          {locationFields.map((field, locationIndex) => (
            <React.Fragment key={field.id}>
              {locationIndex !== 0 ? <Divider className="mt-0" /> : <></>}
              <CustomFormRow>
                <>
                  <Col xs={20}>
                    <Typography.Title level={5} className="mt-2">
                      {`Location ${locationIndex + 1} Information`}
                    </Typography.Title>
                  </Col>
                  <Col xs={3}>
                    <Button
                      size="large"
                      className="hover:!fill-primary"
                      disabled={
                        !(locations || newLocations)
                          ? true
                          : (locations || newLocations)?.length === 0
                      }
                      icon={
                        <CustomIcon
                          type="inventory-list"
                          className="fill-white"
                        />
                      }
                      onClick={() => {
                        setSelectedTab(tabToRender);
                      }}
                      block
                    >
                      Add Inventory
                    </Button>
                  </Col>
                  <Col xs={1} className="mt-1">
                    <DeleteIconButton
                      disabled={locationFields?.length <= 1}
                      handleDelete={() => {
                        removeLocation(locationIndex);
                      }}
                    />
                  </Col>
                </>

                {/* Storage Type */}
                <Col xs={12} className="mt-4">
                  <Form.Item<FieldType>
                    validateStatus={
                      errors.locations?.[locationIndex]?.storageTypeId
                        ? "error"
                        : ""
                    }
                    help={
                      errors.locations?.[locationIndex]?.storageTypeId
                        ? errors.locations?.[locationIndex]?.storageTypeId
                            .message
                        : ""
                    }
                  >
                    <CustomFormLabel text="Storage Type" required={true} />
                    <Controller
                      name={`locations.${locationIndex}.storageTypeId`}
                      control={control}
                      render={({ field }) => (
                        <Select
                          className="mt-3"
                          {...field}
                          size="large"
                          placeholder="Select Storage Type"
                          // options={memoizedStorageTypesOptions}
                          showSearch
                          popupClassName="z-50"
                          filterOption={(input, option) =>
                            (option?.key || "")
                              .toLowerCase()
                              .includes(input.toLowerCase())
                          }
                          dropdownRender={(menu) => (
                            <>
                              {menu}
                              <Divider className="mt-2 mb-1" />
                              <Space className="p-1">
                                <Button
                                  type="text"
                                  icon={<PlusOutlined />}
                                  onClick={() => handleOpenModal(locationIndex)}
                                >
                                  Add New Storage Type
                                </Button>
                              </Space>
                            </>
                          )}
                        >
                          {memoizedStorageTypesOptions?.map((item) => (
                            <Select.Option
                              key={item?.label}
                              value={item?.value}
                            >
                              <div
                                style={{
                                  display: "flex",
                                  justifyContent: "space-between",
                                  alignItems: "center",
                                }}
                              >
                                <span>{item?.label}</span>
                                {item?.value && (
                                  <Button
                                    type="link"
                                    size="small"
                                    icon={
                                      <EditOutlined
                                        size={18}
                                        className="px-3 py-1 rounded-md text-textBase"
                                      />
                                    }
                                    onMouseDown={(e) => e?.stopPropagation()}
                                    onClick={(e) => {
                                      e?.stopPropagation();
                                      handleEditStorageType(
                                        item,
                                        locationIndex
                                      );
                                    }}
                                  />
                                )}
                              </div>
                            </Select.Option>
                          ))}
                        </Select>
                      )}
                    />
                  </Form.Item>
                </Col>

                {/* Location Name */}
                <Col xs={12} className="mt-4">
                  <Form.Item<FieldType>
                    validateStatus={
                      errors.locations?.[locationIndex]?.name ? "error" : ""
                    }
                    help={
                      errors.locations?.[locationIndex]?.name
                        ? errors.locations?.[locationIndex]?.name.message
                        : ""
                    }
                  >
                    <CustomFormLabel text="Location Name" required={true} />
                    <Controller
                      name={`locations.${locationIndex}.name`}
                      control={control}
                      render={({ field }) => (
                        <Input
                          className="mt-3"
                          {...field}
                          size="large"
                          placeholder="Location Name"
                        />
                      )}
                    />
                  </Form.Item>
                </Col>

                {/* Address */}
                <Col xs={12} className="mt-2">
                  <Form.Item<FieldType>
                    validateStatus={
                      errors.locations?.[locationIndex]?.address ? "error" : ""
                    }
                    help={
                      errors.locations?.[locationIndex]?.address
                        ? errors.locations?.[locationIndex]?.address.message
                        : ""
                    }
                  >
                    <CustomFormLabel text="Address" required={true} />

                    <Controller
                      name={`locations.${locationIndex}.address`}
                      control={control}
                      render={({ field }) => (
                        <Input
                          className="mt-3"
                          {...field}
                          size="large"
                          placeholder="Your Address"
                        />
                      )}
                    />
                  </Form.Item>
                </Col>

                {/* Nearest Cross Streets */}
                <Col xs={12} className="mt-2">
                  <Form.Item<FieldType>>
                    <CustomFormLabel text="Nearest Cross Streets" />
                    <Controller
                      name={`locations.${locationIndex}.nearestCrossStreets`}
                      control={control}
                      render={({ field }) => (
                        <Input
                          {...field}
                          value={field.value ?? ""}
                          className="mt-3"
                          size="large"
                          placeholder="Nearest Cross Streets"
                        />
                      )}
                    />
                  </Form.Item>
                </Col>

                <LocationInfoSubLocations
                  control={control}
                  locationIndex={locationIndex}
                />
              </CustomFormRow>
            </React.Fragment>
          ))}
          <Col xs={12}>
            <Flex className="gap-5" style={{ width: "220px" }}>
              <Button
                size="large"
                className="hover:!fill-primary text-sm "
                icon={<CustomIcon type="plus" />}
                onClick={() =>
                  appendLocation({
                    name: "",
                    address: "",
                    nearestCrossStreets: "",
                    storageTypeId: null,
                    id: null,
                    subLocations: [
                      {
                        id: null,
                        name: "",
                        projectLocationId: null,
                      },
                    ],
                  })
                }
                block
              >
                <span className="text-sm font-medium">Add New Location</span>
              </Button>
            </Flex>
          </Col>
          {(reqError || resError || successMessage) && (
            <CustomAlert
              message={reqError || resError || successMessage || ""}
              type={successMessage ? "success" : "error"}
            />
          )}
          <Flex justify="flex-end" className="gap-4">
            <Button
              disabled={isSubmitting || isDeleting}
              type="default"
              onClick={handleCancelForm}
            >
              Cancel
            </Button>
            {(locations || newLocations || [])?.length > 0 && (
              <Button
                loading={isDeleting}
                disabled={isSubmitting || isDeleting}
                type="default"
                onClick={handleDeleteLocationById}
              >
                {isDeleting ? "Deleting.." : "Delete"}
              </Button>
            )}
            <Button
              loading={actionType === "save" && isSubmitting}
              disabled={isSubmitting || isDeleting}
              type="primary"
              htmlType="submit"
              onClick={() => setActionType("save")}
            >
              {actionType === "save" && isSubmitting ? "Saving.." : "Save"}
            </Button>

            <Button
              loading={actionType === "saveAndClose" && isSubmitting}
              disabled={isSubmitting || isDeleting}
              type="primary"
              htmlType="submit"
              onClick={() => setActionType("saveAndClose")}
            >
              {actionType === "saveAndClose" && isSubmitting
                ? "Saving and closing.."
                : "Save & Close"}
            </Button>
          </Flex>
          <div className="mt-5"></div>
        </Form>
      </>
      {locations?.[0]?.id ? (
        <Flex justify="flex-end">
          <CreatedByUserBadge
            userName={
              locations?.[0]?.modifiedDate == null
                ? locations?.[0]?.createdBy
                : locations?.[0]?.lastModifiedBy
            }
            date={locations?.[0]?.lastModifiedDate}
            isModifiedBadge={
              locations?.[0]?.modifiedDate == null ? false : true
            }
          />
        </Flex>
      ) : (
        newLocations?.[0]?.id && (
          <Flex justify="flex-end">
            <CreatedByUserBadge
              // userName={newLocations?.[0]?.createdBy}
              // date={newLocations?.[0]?.createdDate}
              userName={
                newLocations?.[0]?.modifiedDate === null
                  ? newLocations?.[0]?.createdBy
                  : newLocations?.[0]?.lastModifiedBy
              }
              date={newLocations?.[0]?.lastModifiedDate}
              isModifiedBadge={
                newLocations?.[0]?.modifiedDate === null ? false : true
              }
            />
          </Flex>
        )
      )}
    </>
  );
}
