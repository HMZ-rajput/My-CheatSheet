import CustomFormLabel from "@/src/components/common/CustomFormLabel";
import CustomIcon from "@/src/components/common/CustomIcon";
import { Button, Col, Form, Input, Row } from "antd";
import { useEffect } from "react";
import { Controller } from "react-hook-form";

type LocationInfoSubLocationForModalProps = {
  control: any;
  getValues: any;
  setValue: any;
  isSuccess?: boolean;
  watch: any;
  isCancel: boolean;
};

export default function LocationInfoSubLocationForModal({
  control,
  setValue,
  watch,
  isCancel,
}: LocationInfoSubLocationForModalProps) {
  const subLocations = watch("subLocations") || [];

  const addSubLocation = () => {
    setValue("subLocations", [...subLocations, { id: null, name: "" }]);
  };

  const removeSubLocation = (index: number) => {
    const updatedSubLocations = subLocations.filter(
      (_: any, i: number) => i !== index
    );
    setValue("subLocations", updatedSubLocations);
  };

  useEffect(() => {
      setValue("subLocations", [{
        id: null,
        name: ""
      }]);
  }, [isCancel]);

  return (
    <>
      {subLocations?.map((_: any, index: number) => (
        <Col className="mt-2" xs={15} key={index}>
          <CustomFormLabel
            text={`Sublocation ${String(index + 1).padStart(2, "0")}`}
            required
          />
          <Row align={"bottom"}>
            <Col xs={19}>
              <Controller
                name={`subLocations.${index}.name`}
                control={control}
                render={({ field, fieldState: { error } }) => (
                  <Form.Item
                    help={error?.message}
                    validateStatus={error?.message ? "error" : ""}
                  >
                    <Input
                      className="mt-3"
                      {...field}
                      size="large"
                      placeholder="Sublocation Name"
                    />
                  </Form.Item>
                )}
              />
            </Col>
            <Col xs={4}>
              <Button
                onClick={() => removeSubLocation(index)}
                className="px-2 py-1 mb-5 !text-primary"
                type="text"
              >
                Delete
              </Button>
            </Col>
          </Row>
        </Col>
      ))}
      <Col xs={12}>
        <Form.Item>
          <Button
            className="border-0 shadow-none text-primary font-medium"
            size="small"
            icon={<CustomIcon type="plus" className="fill-primary " />}
            onClick={addSubLocation}
          >
            <span className="text-sm font-medium text-primary">
              Add another Sublocation
            </span>
          </Button>
        </Form.Item>
      </Col>
    </>
  );
}
