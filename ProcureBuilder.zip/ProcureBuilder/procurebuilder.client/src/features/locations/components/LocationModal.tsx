import { createSingleLocation } from "@/src/apis/locationApis";
import CustomAlert from "@/src/components/common/CustomAlert";
import CustomFormLabel from "@/src/components/common/CustomFormLabel";
import CustomModal from "@/src/components/common/CustomModal";
import CustomFormRow from "@/src/components/form/CustomFormRow";
import { SingleLocationValidationsSchema } from "@/src/data/validationsSchema";
import { useAppDispatch } from "@/src/hooks/useAppDispatch";
import { useAppSelector } from "@/src/hooks/useAppSelector";
import useAuthorization from "@/src/hooks/useAuthorization";
import {
  getLocationsState,
  resetState,
} from "@/src/store/slices/locationSlice";
import { getStorageTypesState } from "@/src/store/slices/storageTypeSlice";
import { Location } from "@/src/utils/types";
import { yupResolver } from "@hookform/resolvers/yup";
import { Col, Form, Input, Select } from "antd";
import { useEffect, useMemo, useState } from "react";
import { Controller, useForm } from "react-hook-form";
import LocationInfoSubLocationForModal from "./LocationInfoSubLocationForModal";

type LocationModalProps = {
  isLocationModalOpen: { open: boolean; title?: string | null; field?: string };
  setIsLocationModalOpen: React.Dispatch<
    React.SetStateAction<{
      open: boolean;
      title?: string | null;
      field?: string;
    }>
  >;
  projectId?: string | null;
  setLocationValue: any;
};

type FormValues = Location;

const LocationModal = ({ ...props }: LocationModalProps) => {
  const {
    isLocationModalOpen,
    setIsLocationModalOpen,
    projectId,
    setLocationValue,
  } = props;

  const { successMessage, resError, reqError } =
    useAppSelector(getLocationsState);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [isCancel, setIsCancel] = useState(false);

  const { isFieldsCraftAuthorized } = useAuthorization();

  const dispatch = useAppDispatch();

  const { storageTypesData } = useAppSelector(getStorageTypesState);

  useEffect(() => {
    if (reqError || resError) dispatch(resetState());
  }, []);

  const initialValues = {
    name: "",
    address: "",
    nearestCrossStreets: "",
    projectId: projectId || "",
    storageTypeId: null,
    id: null,
    subLocations: [
      {
        id: null,
        name: "",
      },
    ],
  };

  const {
    control,
    handleSubmit,
    setValue,
    reset,
    getValues,
    watch,

    // watch,
  } = useForm<Location | any>({
    resolver: yupResolver(SingleLocationValidationsSchema),
    defaultValues: {
      ...initialValues,
    },
  });

  const memoizedStorageTypesOptions = useMemo(() => {
    return [
      {
        value: "",
        label: "Select Storage Type",
      },
      ...(storageTypesData?.map((f) => ({
        value: f?.id,
        label: f?.name,
      })) || []),
    ];
  }, [storageTypesData]);

  const onSubmit = async (values: FormValues) => {
    try {
      setIsSubmitting(true);
      const res = await dispatch(
        createSingleLocation({
          ...values,
          subLocations: values?.subLocations?.map((v) => v?.name) || [],
        })
      ).unwrap();
      if (res?.isSuccess) {
        setLocationValue(isLocationModalOpen?.field, res?.location?.id);
        setIsSuccess(true);
        reset({
          initialValues,
          subLocations: [
            {
              id: null,
              name: "",
            },
          ],
        });

        dispatch(resetState());
        handleCancelForm();
      } else {
        console.log("Error in creating location");
      }
    } catch (error) {
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleCancelForm = () => {
    setIsLocationModalOpen((prev) => ({ ...prev, open: false }));
  };

  useEffect(() => {
    setValue("projectId", projectId || "");
  }, [projectId]);

  useEffect(() => {
    setValue("projectId", projectId || "");
    dispatch(resetState());
  }, [isLocationModalOpen?.open]);

  return (
    <CustomModal
      //   width={550}
      primaryButtonAction={() => handleSubmit(onSubmit)()}
      isPrimaryButtonDisabled={isSubmitting}
      isLoading={isSubmitting}
      title={isLocationModalOpen?.title || "Add New Location"}
      primaryButtonText={"Add"}
      primaryButtonLoadingText={"Adding..."}
      isOpen={isLocationModalOpen?.open}
      cancelButtonAction={() => {
        setIsLocationModalOpen((prev) => ({ ...prev, open: false }));
        reset({
          ...initialValues,
          subLocations: [
            {
              id: null,
              name: "",
            },
          ],
        });
        setValue("subLocations", [
          {
            id: null,
            name: "",
          },
        ]);
        setIsCancel(!isCancel);
      }}
    >
      <>
        <Form
          onFinish={handleSubmit(onSubmit)}
          layout="vertical"
          disabled={isFieldsCraftAuthorized()}
        >
          <>
            <CustomFormRow>
              {/* Storage Type */}
              <Col xs={12} className="mt-4">
                <Controller
                  name={`storageTypeId`}
                  control={control}
                  render={({ field, fieldState: { error } }) => (
                    <Form.Item
                      validateStatus={error ? "error" : ""}
                      help={error ? error.message : ""}
                      label={
                        <CustomFormLabel text="Storage Type" required={true} />
                      }
                    >
                      <Select
                        {...field}
                        size="large"
                        placeholder="Select Storage Type"
                        rootClassName="z-50"
                        showSearch
                        options={memoizedStorageTypesOptions}
                        filterOption={(input, option) =>
                          (option?.value || "")
                            .toLowerCase()
                            .includes(input.toLowerCase())
                        }
                      ></Select>
                    </Form.Item>
                  )}
                />
              </Col>

              {/* Location Name */}
              <Col xs={12} className="mt-4">
                <Controller
                  name={`name`}
                  control={control}
                  render={({ field, fieldState: { error } }) => (
                    <Form.Item
                      validateStatus={error ? "error" : ""}
                      help={error ? error.message : ""}
                      label={
                        <CustomFormLabel text="Location Name" required={true} />
                      }
                    >
                      <Input
                        {...field}
                        size="large"
                        placeholder="Location Name"
                      />
                    </Form.Item>
                  )}
                />
              </Col>

              {/* Address */}
              <Col xs={12} className="mt-2">
                <Controller
                  name={`address`}
                  control={control}
                  render={({ field, fieldState: { error } }) => (
                    <Form.Item
                      validateStatus={error ? "error" : ""}
                      help={error ? error.message : ""}
                      label={
                        <CustomFormLabel
                          text="Location Address"
                          required={true}
                        />
                      }
                    >
                      <Input
                        {...field}
                        size="large"
                        placeholder="Your Address"
                      />
                    </Form.Item>
                  )}
                />
              </Col>

              {/* Nearest Cross Streets */}
              <Col xs={12} className="mt-2">
                <Controller
                  name={`nearestCrossStreets`}
                  control={control}
                  render={({ field }) => (
                    <Form.Item
                      label={<CustomFormLabel text="Nearest Cross Streets" />}
                    >
                      <Input
                        {...field}
                        value={field.value ?? ""}
                        size="large"
                        placeholder="Nearest Cross Streets"
                      />
                    </Form.Item>
                  )}
                />
              </Col>

              <LocationInfoSubLocationForModal
                isCancel={isCancel}
                setValue={setValue}
                watch={watch}
                isSuccess={isSuccess}
                getValues={getValues}
                control={control}
              />
            </CustomFormRow>
          </>

          {(reqError || resError || successMessage) && (
            <CustomAlert
              message={reqError || resError || successMessage || ""}
              type={successMessage ? "success" : "error"}
            />
          )}

          <div className="mt-5"></div>
        </Form>
      </>
    </CustomModal>
  );
};

export default LocationModal;
