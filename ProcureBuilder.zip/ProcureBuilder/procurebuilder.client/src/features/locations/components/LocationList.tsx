import { Button, TableProps, Typography } from "antd";
// import dayjs from "dayjs";
import { useAppSelector } from "@hooks/useAppSelector";
// import { getFullNameInitials } from "@utils/general-helpers";
import CustomIcon from "@components/common/CustomIcon";
// import CustomTag from "@components/common/CustomTag";
import { getConsistentSpacing } from "@utils/theme-helpers";
// import { TagTypeEnum } from "@utils/enums";
import { getAllLocations } from "@/src/apis/locationApis";
import { getAllStorageTypes } from "@/src/apis/storageTypeApis";
import CustomListTags from "@/src/components/common/customListTags";
import HighlightedText from "@/src/components/common/HighlightedText";
import CustomTable from "@/src/components/table/CustomTable";
import CustomTableFilters, {
  CustomFilterDataType,
  CustomFiltersType,
} from "@/src/components/table/CustomTableFilters";
import { useAppDispatch } from "@/src/hooks/useAppDispatch";
import useAuthorization from "@/src/hooks/useAuthorization";
import { useDebouncedCallback } from "@/src/hooks/useDebouncedCallback";
import { getLocationsState } from "@/src/store/slices/locationSlice";
import { getStorageTypesState } from "@/src/store/slices/storageTypeSlice";
import routePaths from "@/src/utils/routePaths";
import { Location, StorageType, SubLocation } from "@/src/utils/types";
import SectionLayout from "@components/layout/SectionLayout";
import { Project } from "@utils/types";
import { useEffect, useMemo, useRef, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import useSyncFilters from "@/src/hooks/useSyncFilters";

type LocationListProps = {
  locations?: Location[] | null;

  hasPagination?: boolean;
  hasDetailedColumns?: boolean;
  hasSearch?: boolean;
  hasFilters?: boolean;
  hasBorders?: boolean;
};
export default function LocationList({
  hasPagination = true,
  hasDetailedColumns = true,
  hasSearch = true,
  hasFilters = true,
  hasBorders = true,
  ...props
}: LocationListProps) {
  const dispatch = useAppDispatch();
  const navigate = useNavigate();
  const { name } = useParams();
  const isFirstCallComplete = useRef(false);
  // const [isFirstCall, setIsFirstCall] = useState(false);
  const { isFieldsCraftAuthorized } = useAuthorization();
  const {
    locationsData,
    totalCount,
    isLoading,
    currentPage: locationsCurrentPage,
    pageSize: locationsPageSize,
  } = useAppSelector(getLocationsState);
  const { storageTypesData: storageTypesData } =
    useAppSelector(getStorageTypesState);

  const [page, setPage] = useState<number>(locationsCurrentPage);
  const [pageSize, setPageSize] = useState(locationsPageSize);
  const [searchTerm, setSearchTerm] = useState(name || "");
  const [hasSearched, setHasSearched] = useState(false);
  const { searchParams } = useSyncFilters();
  const [previousSearchTerm, setPreviousSearchTerm] = useState(
    searchParams.get("searchTerm")
  );
  const [lastSearchTimestamp, setLastSearchTimestamp] = useState(0);

  useEffect(() => {
    setLastSearchTimestamp(Date.now());
  }, [previousSearchTerm]);

  const memoizedTypesOptions = useMemo(() => {
    return [
      {
        value: "",
        label: "All Storage Types",
      },
      ...(storageTypesData?.map((f) => ({
        value: f?.id,
        label: f?.name,
      })) || []),
    ];
  }, [storageTypesData]);

  const [filters, setFilters] = useState<CustomFiltersType>({
    storageType: {
      value:
        memoizedTypesOptions.length > 0 ? memoizedTypesOptions[0].value : "",
      options: memoizedTypesOptions,
      dataType: CustomFilterDataType.STR,
    },
  });

  useEffect(() => {
    dispatch(getAllStorageTypes());
  }, [dispatch]);

  useEffect(() => {
    // Update filter options once memoizedTypesOptions has been populated
    setFilters((prevFilters) => ({
      ...prevFilters,
      storageType: {
        ...prevFilters?.storageType,
        options: memoizedTypesOptions,
      },
    }));

    if (name) {
      setSearchTerm(name);
      setLastSearchTimestamp(Date.now());
    }
  }, [memoizedTypesOptions, name]);

  const navigateToEditPage = (data: Location) => {
    const path = `${routePaths.LOCATIONS_EDIT_BY_ID}/${data?.project?.id}`;
    const hasParams = new URLSearchParams(location.search).size > 0;

    if (hasParams) {
      navigate(path, {
        state: {
          previousPath: `${location.pathname}${location.search}`,
        },
      });
    } else {
      navigate(path);
    }
  };

  const columns: TableProps<Location>["columns"] = [
    {
      title: "Location Name",
      dataIndex: "name",
      key: "name",
      sorter: (a, b) => a.name?.localeCompare(b.name),
      render: (_, record) => (
        <Typography.Title
          level={5}
          style={{ fontSize: getConsistentSpacing(1.75), margin: 0 }}
        >
          <HighlightedText text={record?.name} searchTerm={searchTerm} />
        </Typography.Title>
      ),
    },
    {
      title: "Storage Type",
      dataIndex: "storageType",
      key: "storageType",

      sorter: (a, b) =>
        a?.storageTypeId?.localeCompare(b?.storageTypeId || "") ?? 0,
      render: (storageType: StorageType) => (
        <HighlightedText text={storageType?.name} searchTerm={searchTerm} />
      ),
    },
    {
      title: "Address",
      dataIndex: "address",
      key: "address",

      sorter: (a, b) => a.address?.localeCompare(b.address),
    },
    {
      title: "Cross Streets",
      dataIndex: "nearestCrossStreets",
      key: "nearestCrossStreets",

      sorter: (a, b) =>
        a.nearestCrossStreets?.localeCompare(b?.nearestCrossStreets || "") ?? 0,
    },
    {
      title: "Sublocations",
      dataIndex: "subLocations",
      key: "subLocations",

      render: (_, record) => (
        <CustomListTags
          data={record?.subLocations as SubLocation[]}
          className="list-disc pl-5"
        />
      ),
    },
    {
      title: "Project",
      dataIndex: "project",
      key: "project",
      render: (project: Project) => (
        <HighlightedText text={project?.name} searchTerm={searchTerm} />
      ),
    },
    {
      title: "Project Type",
      dataIndex: "projectType",
      key: "projectType",
      render: (_, record) => <>{record?.project?.projectTypeName ?? "N/A"}</>,
    },
    ...(!isFieldsCraftAuthorized()
      ? [
          {
            title: "",
            dataIndex: "",
            key: "actions",
            render: (_: any, record: Location) => (
              <>
                <Button
                  shape="circle"
                  className="hover:!fill-primary"
                  icon={<CustomIcon type="edit" />}
                  onClick={() => navigateToEditPage(record)}
                />
              </>
            ),
          },
        ]
      : []),
  ];

  const handleGetResults = useDebouncedCallback(getResults, 100);

  function getResults(pageNumber?: number) {
    if (!hasPagination) {
      return;
    }

    const storageType =
      filters.storageType?.value !== memoizedTypesOptions[0]?.value
        ? filters?.storageType?.value?.toString()
        : undefined;

    dispatch(
      getAllLocations({
        pageNumber: pageNumber || page,
        pageSize,
        search: searchTerm || undefined,
        storageType,
      })
    );
  }

  function resetPaginationAndGetFirstPageResults() {
    if (isFirstCallComplete?.current === true) {
      if (filters) {
        setPage(1);
      }

      handleGetResults(1);
    } else {
      handleGetResults();
    }
  }

  useEffect(() => {
    if (!name) {
      if (!hasSearched) return;
    }

    const timer = setTimeout(() => {
      if (
        (searchTerm === "" && previousSearchTerm !== "") ||
        searchTerm === ""
      ) {
        resetPaginationAndGetFirstPageResults();
        setPreviousSearchTerm(searchTerm);
      }
    }, 500);

    return () => {
      clearTimeout(timer);
    };
  }, [searchTerm, hasSearched, previousSearchTerm, name]);

  const handleSearch = () => {
    if (searchTerm !== previousSearchTerm) {
      setHasSearched(true);
      resetPaginationAndGetFirstPageResults();
      setPreviousSearchTerm(searchTerm || "");
    }
  };

  useEffect(() => {
    resetPaginationAndGetFirstPageResults();
  }, [filters]);

  useEffect(() => {
    if (
      !isFirstCallComplete?.current ||
      locationsCurrentPage !== page ||
      locationsPageSize !== pageSize
    ) {
      handleGetResults();
      if (!isFirstCallComplete?.current) {
        setTimeout(() => {
          isFirstCallComplete.current = true;
        }, 1000);
      }
    }
  }, [page, pageSize, name]);

  return (
    <>
      <SectionLayout isHidden={!hasBorders}>
        <CustomTable
          data={props.locations || locationsData || []}
          columns={
            hasDetailedColumns
              ? columns || []
              : columns?.filter(
                  (f) =>
                    !["project", "projectType", "actions"]?.includes(
                      (f.key || "") as string
                    )
                )
          }
          isLoading={!hasPagination ? false : isLoading}
          searchTerm={searchTerm}
          setSearchTerm={setSearchTerm}
          handleSearch={handleSearch}
          totalCount={totalCount}
          page={page}
          setPage={setPage}
          pageSize={pageSize}
          setPageSize={setPageSize}
          tableFilters={filters}
          setTableFilters={setFilters}
          filterElements={
            hasFilters ? (
              <CustomTableFilters filters={filters} setFilters={setFilters} />
            ) : null
          }
          hasPagination={hasPagination}
          hasSearch={hasSearch}
          lastSearchTimestamp={lastSearchTimestamp}
        />
      </SectionLayout>
    </>
  );
}
