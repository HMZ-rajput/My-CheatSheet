import { LocationEndpointsEnum } from "@/src/apis/locationApis";
import CustomButton from "@/src/components/common/CustomButton";
import CustomIcon from "@/src/components/common/CustomIcon";
import SectionLayout from "@/src/components/layout/SectionLayout";
import { call } from "@/src/utils/api-helpers";
import { Location, Project } from "@/src/utils/types";
import LocationsImg from "@assets/images/locations/locations-orange.png";
import { Button, Flex, Typography } from "antd";
import { Dispatch, SetStateAction, useEffect, useState } from "react";
import LocationsList from "./LocationList";
// import LocationInfoFormSection from "./LocationInfoFormSection";
import CustomOverlayLoader from "@/src/components/common/CustomOverlayloader";
import LocationInfoFormSection from "./LocationInfoDetailsFormRHF";
import useAuthorization from "@/src/hooks/useAuthorization";
import { useParams } from "react-router-dom";

type LocationTabProps = {
  project: Project | null;
  tabToRender: string;
  setSelectedTab: Dispatch<SetStateAction<string>>;
};
export default function LocationTab({
  project,
  setSelectedTab,
  tabToRender,
}: LocationTabProps) {
  const { isFieldsCraftAuthorized } = useAuthorization();
  const [displayForm, setDisplayForm] = useState(false);
  const [locations, setLocations] = useState<Location[]>([]);
  const [newLocations, setNewLocations] = useState<Location[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const { projectId } = useParams();
  type GetAllLocationsByProjectIdResponse = Response & {
    locations: Location[];
  };

  const getLocationsForProject = async () => {
    try {
      const response = await call<GetAllLocationsByProjectIdResponse>({
        url: `${LocationEndpointsEnum.GET_ALL_LOCATIONS}/${projectId}`,
        method: "GET",
      });

      setLocations(response?.locations || []);
    } catch (error) {
      console.error("Failed to fetch locations:", error);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    getLocationsForProject();
  }, [project, projectId, newLocations, displayForm]);

  const NoLocationSection = (
    <>
      <SectionLayout>
        <SectionLayout
          className="p-8 rounded-xl items-center max-h-64"
          borderStyle="dashed"
        >
          <img src={LocationsImg} width="48" height="48" className="mb-5" />

          <h6 className="font-medium text-sm !mb-1">No Locations Added Yet</h6>

          <p className="font-normal text-xs mb-5 text-neutral-7">
            Please create a location to get started.
          </p>

          {!isFieldsCraftAuthorized() && (
            <Flex className="gap-5">
              <Button
                size="large"
                className="hover:!fill-primary"
                icon={<CustomIcon type="plus" />}
                onClick={() => {
                  setDisplayForm(true);
                }}
              >
                New Location
              </Button>
            </Flex>
          )}
        </SectionLayout>
      </SectionLayout>
    </>
  );
  const LocationsListView = (
    <SectionLayout>
      <Flex className="mb-6" justify="space-between">
        <Typography.Title level={4} style={{ margin: 0 }} className="!text-lg">
          Locations
        </Typography.Title>

        {!isFieldsCraftAuthorized() && (
          <CustomButton
            onClick={() => setDisplayForm(true)}
            variant="outlined"
            className="hover:!fill-primary"
            icon={<CustomIcon type="edit" />}
          >
            Edit
          </CustomButton>
        )}
      </Flex>
      <LocationsList
        locations={locations?.length > 0 ? locations : null}
        hasPagination={false}
        hasSearch={false}
        hasFilters={false}
        hasBorders={false}
        hasDetailedColumns={false}
      />
    </SectionLayout>
  );

  if (isLoading) {
    return <CustomOverlayLoader />;
  }

  return (
    <>
      {locations?.length && !displayForm ? (
        LocationsListView
      ) : displayForm ? (
        <LocationInfoFormSection
          displayForm={displayForm}
          newLocations={newLocations}
          setNewLocations={setNewLocations}
          setSelectedTab={setSelectedTab}
          tabToRender={tabToRender}
          getLocationsForProject={getLocationsForProject}
          locations={locations.length ? locations : null}
          setLocations={setLocations}
          handleCancelForm={() => setDisplayForm(false)}
        />
      ) : (
        NoLocationSection
      )}
    </>
  );
}
