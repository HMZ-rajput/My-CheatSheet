import CustomFormLabel from "@/src/components/common/CustomFormLabel";
import CustomIcon from "@/src/components/common/CustomIcon";
import { Button, Col, Form, Input, Row } from "antd";
import React from "react";
import { Controller, useFieldArray } from "react-hook-form";

export default function LocationInfoSubLocations({
  control,
  locationIndex,
}: {
  control: any;
  locationIndex: number;
}) {
  const {
    fields: subLocationFields,
    append: appendSubLocation,
    remove: removeSubLocation,
  } = useFieldArray({
    control,
    name: `locations.${locationIndex}.subLocations`,
  });

  return (
    <React.Fragment>
      <>
        {subLocationFields?.map((field, subLocationIndex: number) => (
          <Col className="mt-2" xs={15} key={field.id}>
            <CustomFormLabel
              text={`Sublocation ${String(subLocationIndex + 1).padStart(
                2,
                "0"
              )}`}
              required
            />
            <Row align={"bottom"}>
              <Col xs={19}>
                <Controller
                  name={`locations.${locationIndex}.subLocations.${subLocationIndex}.name`}
                  control={control}
                  render={({ field, formState: { errors } }) => {
                    const locationError = (errors?.locations as any)?.[
                      locationIndex
                    ];
                    const sublocationError =
                      locationError?.subLocations?.[subLocationIndex];

                    return (
                      <Form.Item
                        help={sublocationError?.name?.message}
                        validateStatus={sublocationError?.name ? "error" : ""}
                      >
                        <Input
                          className="mt-3"
                          {...field}
                          size="large"
                          placeholder="Sublocation Name"
                        />
                      </Form.Item>
                    );
                  }}
                />
              </Col>
              <Col xs={4}>
                <Button
                  onClick={() => removeSubLocation(subLocationIndex)}
                  className="px-2 py-1 mb-5 !text-primary"
                  type="text"
                >
                  Delete
                </Button>
              </Col>
            </Row>
          </Col>
        ))}
        <Col xs={12}>
          <Form.Item>
            <Button
              className="border-0 shadow-none text-primary font-medium"
              size="small"
              icon={<CustomIcon type="plus" className="fill-primary " />}
              onClick={() =>
                appendSubLocation({
                  id: null,
                  name: "",
                  projectLocationId: null,
                })
              }
            >
              <span className="text-sm font-medium text-primary">
                Add another Sublocation
              </span>
            </Button>
          </Form.Item>
        </Col>
      </>
    </React.Fragment>
  );
}
