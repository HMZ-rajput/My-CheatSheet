import {
  Button,
  Col,
  Divider,
  Flex,
  Form,
  Input,
  Select,
  Space,
  Typography,
} from "antd";
import { useLocation, useNavigate, useParams } from "react-router-dom";

import {
  createLocation,
  deleteLocationById,
  editLocationById,
  EditLocationRequest,
  GetAllLocationsResponse,
  getLocationListForSideBar,
  getLocationslist,
  LocationEndpointsEnum,
} from "@/src/apis/locationApis";
import { getSummarizedProjectsList } from "@/src/apis/projectApis";
import { getAllProjectTypes } from "@/src/apis/projectTypeApis";
import { getAllStorageTypes } from "@/src/apis/storageTypeApis";
import CreatedByUserBadge from "@/src/components/common/CreatedByUserBadge";
import CustomAlert from "@/src/components/common/CustomAlert";
import CustomFormLabel from "@/src/components/common/CustomFormLabel";
import CustomIcon from "@/src/components/common/CustomIcon";
import CustomOverlayLoader from "@/src/components/common/CustomOverlayloader";
import CustomFormRow from "@/src/components/form/CustomFormRow";
import DeleteIconButton from "@/src/components/icon-buttons/DeleteIconButton";
import PageLayout from "@/src/components/layout/PageLayout";
import { LocationValidationsSchema } from "@/src/data/validationsSchema";
import { useAppDispatch } from "@/src/hooks/useAppDispatch";
import { useAppSelector } from "@/src/hooks/useAppSelector";
import useAuthorization from "@/src/hooks/useAuthorization";
import {
  getLocationsState,
  resetState,
} from "@/src/store/slices/locationSlice";
import { getProjectsState } from "@/src/store/slices/projectsSlice";
import { getStorageTypesState } from "@/src/store/slices/storageTypeSlice";
import { getTypesState } from "@/src/store/slices/typesSlice";
import { call } from "@/src/utils/api-helpers";
import routePaths, { routePathsWithParams } from "@/src/utils/routePaths";
import { Location, ProjectType } from "@/src/utils/types";
import { EditOutlined, PlusOutlined } from "@ant-design/icons";
import SectionLayout from "@components/layout/SectionLayout";
import { yupResolver } from "@hookform/resolvers/yup";
import { FieldNamesType } from "antd/es/cascader";
import React, { useEffect, useMemo, useState } from "react";
import { Controller, Resolver, useFieldArray, useForm } from "react-hook-form";
import LocationInfoSubLocations from "./LocationInfoSublocationsRHF";
import StorageTypeModal from "./StorageTypeModal";
type LocationDetailsFormProps = {
  handleCancelForm?: () => void | undefined;
};

type FormValues = {
  projectId: string;
  projectTypeId: string | null;
  locations: Location[];
};

export default function LocationDetailsForm({
  handleCancelForm,
}: LocationDetailsFormProps) {
  const [isOpen, setIsOpen] = useState(false);
  const { isFieldsCraftAuthorized } = useAuthorization();
  const dispatch = useAppDispatch();
  const [isLoading, setIsLoading] = useState(false);
  const [editStorageType, setEditStorageType] = useState<{
    label: string;
    value: string | null;
  } | null>(null);
  const [locations, setLocations] = useState<Location[] | null>(null);
  const [activeIndex, setActiveIndex] = useState<null | number>(null);
  const { projectId } = useParams();
  const location = useLocation();

  const { successMessage, resError, reqError } =
    useAppSelector(getLocationsState);

  const [isCreated, setIsCreated] = useState<boolean>(
    locations?.length ? true : false
  );
  const [isEdited, setIsEdited] = useState<boolean>(false);
  const [isDeleting, setIsDeleting] = useState(false);
  const [actionType, setActionType] = useState("");
  const navigate = useNavigate();

  const { projectsSummarizedData } = useAppSelector(getProjectsState);

  const memoizedProjectsOptions = useMemo(() => {
    return [
      {
        value: "",
        label: "Select Project",
      },
      ...(projectsSummarizedData?.map((f) => ({
        value: f.id,
        label: f.name,
      })) || []),
    ];
  }, [projectsSummarizedData]);

  const { storageTypesData } = useAppSelector(getStorageTypesState);
  const memoizedStorageTypesOptions = useMemo(() => {
    return [
      {
        value: "",
        label: "Select Storage Type",
      },
      ...(storageTypesData?.map((f) => ({
        value: f?.id,
        label: f?.name,
      })) || []),
    ];
  }, [storageTypesData]);

  const { typesData } = useAppSelector(getTypesState);
  const memoizedProjectTypesOptions = useMemo(() => {
    return [
      {
        value: "",
        label: "N/A",
      },
      ...(typesData?.map((f: ProjectType) => ({
        value: f?.id,
        label: f?.name,
      })) || []),
    ];
  }, [typesData]);

  async function handleDeleteLocationById() {
    const payload = {
      projectId:
        locations?.[0]?.project?.id || (getValues("projectId") as string) || "",
      locationsIdArray: locations?.map((m) => m?.id) || [],
    };
    try {
      setIsDeleting(true);
      const res = await dispatch(deleteLocationById(payload)).unwrap();
      if (res.isSuccess) {
        navigate(routePathsWithParams.LOCATIONSWITHOUTNAME);
        dispatch(getLocationListForSideBar());
        dispatch(getLocationslist());
      }
    } catch (error) {
      console.error("Error deleting project:", error);
    } finally {
      setIsDeleting(false);
    }
  }

  useEffect(() => {
    dispatch(getSummarizedProjectsList());
    dispatch(getAllStorageTypes());
    dispatch(getAllProjectTypes());
  }, [dispatch]);

  const handleOpenModal = (index: number) => {
    setIsOpen(!isOpen);
    setActiveIndex(index);
  };

  const initialValues = [
    {
      name: "",
      address: "",
      nearestCrossStreets: "",
      storageTypeId: null,
      id: null,
      subLocations: [
        {
          id: null,
          name: null,
          projectLocationId: null,
        },
      ],
    },
  ];

  const {
    control,
    handleSubmit,
    setValue,
    reset,
    // watch,
    getValues,
    formState: { isSubmitting, errors },
  } = useForm({
    resolver: yupResolver(
      LocationValidationsSchema
    ) as unknown as Resolver<FormValues>,
    defaultValues: {
      // projectTypeId: locations?.[0]?.project?.projectTypeId || null,
      projectId: locations?.[0]?.project?.id || "",
      locations: locations?.length ? locations : initialValues,
    },
  });

  const {
    fields: locationFields,
    append: appendLocation,
    remove: removeLocation,
  } = useFieldArray({
    control,
    name: "locations",
  });

  const fetchLocationByProjectId = async (value: string) => {
    try {
      setIsLoading(true);
      if (!value) {
        setLocations([]);
        return;
      }
      const response = await call<GetAllLocationsResponse>({
        url: `${LocationEndpointsEnum.GET_ALL_LOCATIONS}/${value}`,
        method: "GET",
      });
      setLocations(response.locations);
      return response;
    } catch (err) {
      console.log(err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleChangeProjectId = async (value: string): Promise<void> => {
    try {
      const response = await fetchLocationByProjectId(value);
      const newLocations = response?.locations;

      //@ts-ignore
      setValue(
        "locations",
        newLocations?.length ? newLocations : initialValues
      );

      setValue(
        "projectTypeId",
        newLocations?.[0]?.project?.projectTypeId || null
      );
      dispatch(resetState());
    } catch (err) {
      console.log(err);
    }
  };

  const handleSave = async (data: FormValues) => {
    const { locations: location, ...rest } = data;

    const payload = {
      ...rest,

      locations: location?.map((m) => ({
        ...m,
        nearestCrossStreets: m.nearestCrossStreets
          ? m?.nearestCrossStreets
          : null,
        subLocations: m.subLocations?.map((s) =>
          typeof s === "string" ? s : s?.name || ""
        ),
      })),
    };

    const editPayload = {
      ...rest,
      locations: location.map((m) => ({
        ...m,
        nearestCrossStreets: m.nearestCrossStreets
          ? m?.nearestCrossStreets
          : null,
      })),
    };
    try {
      let response;

      if (locations?.length || isCreated) {
        response = await dispatch(
          editLocationById(editPayload as EditLocationRequest)
        ).unwrap();

        if (response.isSuccess) {
          setIsEdited(!isEdited);
          setLocations(response.locations);
          dispatch(getLocationListForSideBar());
        }
        return response;
      } else {
        response = await dispatch(createLocation(payload)).unwrap();

        if (response.isSuccess) {
          setIsCreated(true);
          setLocations(response.locations);
          dispatch(getLocationListForSideBar());
        }

        return response;
      }
    } catch (err) {
      setTimeout(() => {
        dispatch(resetState());
      }, 3000);
      console.error("Error:", err);
    }
  };

  useEffect(() => {
    const fetchLocation = async () => {
      if (projectId) {
        try {
          const res = await fetchLocationByProjectId(projectId);
          if (res?.locations?.length) {
            setValue("locations", res.locations);
            setValue("projectId", projectId);
            setValue(
              "projectTypeId",
              res.locations[0]?.project?.projectTypeId || null
            );
          }
        } catch (err) {
          console.log(err);
        }
      }
    };
    fetchLocation();
  }, [projectId]);

  const onSubmit = async (data: FormValues) => {
    try {
      if (actionType === "save") {
        const res = await handleSave(data);
        if (res?.isSuccess) {
          setValue("locations", res.locations);

          dispatch(getLocationListForSideBar());
        }
      } else if (actionType === "saveAndClose") {
        const res = await handleSave(data);
        if (res?.isSuccess) {
          navigate(`${routePaths.LOCATIONSWITHOUTNAME}`);
        }
      }
    } catch (error) {
      console.error("Error during form submission:", error);
    }
  };

  // console.log(watch());

  useEffect(() => {
    dispatch(resetState());
  }, []);

  useEffect(() => {
    if (location.pathname === routePaths.LOCATION_NEW) {
      reset({});
    }
  }, [location.pathname]);

  const handleEditStorageType = (
    item: {
      label: string;
      value: string | null;
    },
    locationIndex: number
  ) => {
    setActiveIndex(locationIndex);
    setIsOpen(true);
    setEditStorageType(item);
  };

  return (
    <>
      <PageLayout title={`${projectId ? "Edit" : "Add New"} Location`}>
        <SectionLayout>
          <StorageTypeModal
            setIsOpen={setIsOpen}
            isOpen={isOpen && activeIndex !== null}
            editStorageType={editStorageType}
            setEditStorageType={setEditStorageType}
            setStorageTypeId={(id) => {
              if (activeIndex !== null) {
                setValue(`locations.${activeIndex}.storageTypeId`, id);
                setActiveIndex(null);
              }
            }}
          />
          <>
            <Form
              onFinish={handleSubmit(onSubmit)}
              layout="vertical"
              disabled={isFieldsCraftAuthorized()}
            >
              <CustomFormRow>
                {/* Project */}
                <Col xs={12} className="mb-4">
                  <Controller
                    name="projectId"
                    control={control}
                    render={({ field }) => (
                      <Form.Item
                        label={
                          <CustomFormLabel text="Project" required={true} />
                        }
                        validateStatus={
                          !field.value && errors.projectId ? "error" : ""
                        }
                        help={
                          !field.value && errors.projectId
                            ? errors.projectId.message
                            : ""
                        }
                      >
                        <Select
                          {...field}
                          onChange={(value) => {
                            field.onChange(value);
                            handleChangeProjectId(value);
                          }}
                          disabled={projectId ? true : false}
                          size="large"
                          placeholder="Select Project"
                          showSearch
                          filterOption={(input, option) =>
                            (option?.label || "")
                              .toLowerCase()
                              .includes(input.toLowerCase())
                          }
                          options={memoizedProjectsOptions}
                        />
                      </Form.Item>
                    )}
                  />
                </Col>
                {/* ProjectType */}
                <Col xs={12} className="mb-4">
                  <Controller
                    name="projectTypeId"
                    control={control}
                    render={({ field }) => (
                      <Form.Item<FieldNamesType>
                        label={<CustomFormLabel text="Project Type" />}
                        validateStatus={
                          !field.value && errors.projectTypeId ? "error" : ""
                        }
                        help={
                          !field.value && errors.projectTypeId
                            ? errors.projectTypeId.message
                            : ""
                        }
                      >
                        <Select
                          disabled
                          {...field}
                          size="large"
                          placeholder="Select Project Type"
                          options={memoizedProjectTypesOptions}
                          showSearch
                        />
                      </Form.Item>
                    )}
                  />
                </Col>
              </CustomFormRow>
              {isLoading ? (
                <CustomOverlayLoader />
              ) : (
                <>
                  {locationFields.map((field, locationIndex) => (
                    <React.Fragment key={field.id}>
                      {locationIndex !== 0 ? (
                        <Divider className="mt-0" />
                      ) : (
                        <></>
                      )}
                      <CustomFormRow>
                        <>
                          <Col xs={23}>
                            <Typography.Title level={5} className="mt-2">
                              {`Location ${locationIndex + 1} Information`}
                            </Typography.Title>
                          </Col>
                          {/* <Col xs={3}>
                            <Button
                              size="large"
                              className="hover:!fill-primary"
                              disabled={true}
                              icon={
                                <CustomIcon
                                  type="inventory-list"
                                  className="fill-white"
                                />
                              }
                              onClick={() => {}}
                              block
                            >
                              Add Inventory
                            </Button>
                          </Col> */}
                          <Col xs={1} className="mt-1">
                            <DeleteIconButton
                              disabled={locationFields.length === 1}
                              handleDelete={() => {
                                removeLocation(locationIndex);
                              }}
                            />
                          </Col>
                        </>

                        {/* Storage Type */}
                        <Col xs={12} className="mt-4">
                          <Controller
                            name={`locations.${locationIndex}.storageTypeId`}
                            control={control}
                            render={({ field }) => (
                              <Form.Item
                                validateStatus={
                                  !field.value &&
                                  errors.locations?.[locationIndex]
                                    ?.storageTypeId
                                    ? "error"
                                    : ""
                                }
                                help={
                                  !field.value &&
                                  errors.locations?.[locationIndex]
                                    ?.storageTypeId
                                    ? errors.locations?.[locationIndex]
                                        ?.storageTypeId.message
                                    : ""
                                }
                                label={
                                  <CustomFormLabel
                                    text="Storage Type"
                                    required={true}
                                  />
                                }
                              >
                                <Select
                                  {...field}
                                  size="large"
                                  placeholder="Select Storage Type"
                                  // options={memoizedStorageTypesOptions}
                                  rootClassName="z-50"
                                  showSearch
                                  filterOption={(input, option) =>
                                    (option?.key || "")
                                      .toLowerCase()
                                      .includes(input.toLowerCase())
                                  }
                                  dropdownRender={(menu) => (
                                    <>
                                      {menu}
                                      <Divider className="mt-2 mb-1" />
                                      <Space className="p-1">
                                        <Button
                                          type="text"
                                          icon={<PlusOutlined />}
                                          onClick={() =>
                                            handleOpenModal(locationIndex)
                                          }
                                        >
                                          Add New Storage Type
                                        </Button>
                                      </Space>
                                    </>
                                  )}
                                >
                                  {memoizedStorageTypesOptions?.map((item) => (
                                    <Select.Option
                                      key={item?.label}
                                      value={item?.value}
                                    >
                                      <div
                                        style={{
                                          display: "flex",
                                          justifyContent: "space-between",
                                          alignItems: "center",
                                        }}
                                      >
                                        <span>{item?.label}</span>
                                        {item?.value && (
                                          <Button
                                            type="link"
                                            size="small"
                                            icon={
                                              <EditOutlined
                                                size={18}
                                                className="px-3 py-1 rounded-md text-textBase"
                                              />
                                            }
                                            onMouseDown={(e) =>
                                              e.stopPropagation()
                                            } // Prevent dropdown from toggling
                                            onClick={(e) => {
                                              e.stopPropagation();
                                              handleEditStorageType(
                                                item,
                                                locationIndex
                                              );
                                            }}
                                          />
                                        )}
                                      </div>
                                    </Select.Option>
                                  ))}
                                </Select>
                              </Form.Item>
                            )}
                          />
                        </Col>

                        {/* Location Name */}
                        <Col xs={12} className="mt-4">
                          <Controller
                            name={`locations.${locationIndex}.name`}
                            control={control}
                            render={({ field }) => (
                              <Form.Item
                                validateStatus={
                                  !field.value &&
                                  errors.locations?.[locationIndex]?.name
                                    ? "error"
                                    : ""
                                }
                                help={
                                  !field.value &&
                                  errors.locations?.[locationIndex]?.name
                                    ? errors.locations?.[locationIndex]?.name
                                        .message
                                    : ""
                                }
                                label={
                                  <CustomFormLabel
                                    text="Location Name"
                                    required={true}
                                  />
                                }
                              >
                                <Input
                                  {...field}
                                  size="large"
                                  placeholder="Location Name"
                                />
                              </Form.Item>
                            )}
                          />
                        </Col>

                        {/* Address */}
                        <Col xs={12} className="mt-2">
                          <Controller
                            name={`locations.${locationIndex}.address`}
                            control={control}
                            render={({ field }) => (
                              <Form.Item
                                validateStatus={
                                  !field.value &&
                                  errors.locations?.[locationIndex]?.address
                                    ? "error"
                                    : ""
                                }
                                help={
                                  !field.value &&
                                  errors.locations?.[locationIndex]?.address
                                    ? errors.locations?.[locationIndex]?.address
                                        .message
                                    : ""
                                }
                                label={
                                  <CustomFormLabel
                                    text="Address"
                                    required={true}
                                  />
                                }
                              >
                                <Input
                                  {...field}
                                  size="large"
                                  placeholder="Your Address"
                                />
                              </Form.Item>
                            )}
                          />
                        </Col>

                        {/* Nearest Cross Streets */}
                        <Col xs={12} className="mt-2">
                          <Controller
                            name={`locations.${locationIndex}.nearestCrossStreets`}
                            control={control}
                            render={({ field }) => (
                              <Form.Item
                                label={
                                  <CustomFormLabel text="Nearest Cross Streets" />
                                }
                              >
                                <Input
                                  {...field}
                                  value={field.value ?? ""}
                                  size="large"
                                  placeholder="Nearest Cross Streets"
                                />
                              </Form.Item>
                            )}
                          />
                        </Col>

                        <LocationInfoSubLocations
                          control={control}
                          locationIndex={locationIndex}
                        />
                      </CustomFormRow>
                    </React.Fragment>
                  ))}
                  <Col xs={12}>
                    <Flex className="gap-5" style={{ width: "220px" }}>
                      <Button
                        size="large"
                        className="hover:!fill-primary text-sm "
                        icon={<CustomIcon type="plus" />}
                        onClick={() =>
                          appendLocation({
                            name: "",
                            address: "",
                            nearestCrossStreets: null,
                            storageTypeId: null,
                            id: null,
                            subLocations: [
                              {
                                id: null,
                                name: null,
                                projectLocationId: null,
                              },
                            ],
                          })
                        }
                        block
                      >
                        <span className="text-sm font-medium">
                          Add New Location
                        </span>
                      </Button>
                    </Flex>
                  </Col>
                </>
              )}
              {(reqError || resError || successMessage) && (
                <CustomAlert
                  message={reqError || resError || successMessage || ""}
                  type={successMessage ? "success" : "error"}
                />
              )}

              {!isFieldsCraftAuthorized() && (
                <Flex justify="flex-end" className="gap-4">
                  <Button
                    disabled={isSubmitting || isDeleting}
                    type="default"
                    onClick={handleCancelForm}
                  >
                    Cancel
                  </Button>
                  {getValues("locations")?.[0]?.id && (
                    <Button
                      loading={isDeleting}
                      disabled={isSubmitting || isDeleting}
                      type="default"
                      onClick={handleDeleteLocationById}
                    >
                      {isDeleting ? "Deleting.." : "Delete"}
                    </Button>
                  )}
                  <Button
                    loading={actionType === "save" && isSubmitting}
                    disabled={isSubmitting || isDeleting}
                    type="primary"
                    htmlType="submit"
                    onClick={() => setActionType("save")}
                  >
                    {actionType === "save" && isSubmitting
                      ? "Saving.."
                      : "Save"}
                  </Button>

                  <Button
                    loading={actionType === "saveAndClose" && isSubmitting}
                    disabled={isSubmitting || isDeleting}
                    type="primary"
                    htmlType="submit"
                    onClick={() => setActionType("saveAndClose")}
                  >
                    {actionType === "saveAndClose" && isSubmitting
                      ? "Saving and closing.."
                      : "Save & Close"}
                  </Button>
                </Flex>
              )}
              <div className="mt-5"></div>
            </Form>
          </>
          {getValues("locations")?.[0]?.id && (
            <Flex justify="flex-end">
              <CreatedByUserBadge
                // userName={locations?.[0]?.createdBy}
                // date={locations?.[0]?.createdDate}

                userName={
                  getValues("locations")?.[0]?.modifiedBy == null
                    ? getValues("locations")?.[0]?.createdBy
                    : getValues("locations")?.[0]?.lastModifiedBy
                }
                date={getValues("locations")?.[0]?.lastModifiedDate}
                isModifiedBadge={
                  getValues("locations")?.[0]?.modifiedBy == null ? false : true
                }
              />
            </Flex>
          )}
        </SectionLayout>
      </PageLayout>
    </>
  );
}
