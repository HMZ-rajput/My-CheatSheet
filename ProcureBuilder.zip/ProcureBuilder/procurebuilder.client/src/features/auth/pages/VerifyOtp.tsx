import VerifyOtpForm from "@features/auth/components/VerifyOtpForm";
import AuthenticationLayout from "@components/layout/AuthenticationLayout";

export default function VerifyOtpPage() {
  return (
    <>
      <AuthenticationLayout>
        <VerifyOtpForm />
      </AuthenticationLayout>
    </>
  );
}
