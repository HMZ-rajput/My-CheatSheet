import ChangePasswordForm from "@features/auth/components/ChangePasswordForm"
import AuthenticationLayout from "@components/layout/AuthenticationLayout"

export default function ChangePasswordPage() {
  return (
    <>
      <AuthenticationLayout>
        <ChangePasswordForm />
      </AuthenticationLayout>
    </>
  )
}
