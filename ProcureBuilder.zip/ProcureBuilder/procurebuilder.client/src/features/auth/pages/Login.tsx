import LoginForm from "@features/auth/components/LoginForm"
import AuthenticationLayout from "@components/layout/AuthenticationLayout"

export default function LoginPage() {
  return (
    <>
      <AuthenticationLayout>
        <LoginForm />
      </AuthenticationLayout>
    </>
  )
}
