import ForgotPasswordForm from "@features/auth/components/ForgotPasswordForm"
import AuthenticationLayout from "@components/layout/AuthenticationLayout"

export default function ForgotPasswordPage() {
  return (
    <>
      <AuthenticationLayout>
        <ForgotPasswordForm />
      </AuthenticationLayout>
    </>
  )
}
