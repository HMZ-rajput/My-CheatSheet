import { Button, Col, Form, Image, Input, Row, Typography } from "antd";
import { useFormik } from "formik";
import { useLocation, useNavigate } from "react-router-dom";
import { resetPasswordForm } from "@apis/userApis";
import ResetPasswordPageIcon from "@assets/icons/reset-pass-icon.png";
import { useAppSelector } from "@hooks/useAppSelector";
import { getUserState } from "@store/slices/userSlice";
import { getConsistentSpacing } from "@utils/theme-helpers";
import * as Yup from "yup";
import CustomIcon from "@components/common/CustomIcon";
import { useState } from "react";
import routePaths from "@utils/routePaths";
import CustomAlert from "@/src/components/common/CustomAlert";

export default function ChangePasswordForm() {
  const { data } = useAppSelector(getUserState);
  const [loading, setLoading] = useState(false);
  const location = useLocation();
  const searchParams = new URLSearchParams(location.search);
  const email = searchParams.get("data");
  const resetPasswordToken = searchParams.get("resetPasswordToken");
  const [error, setError] = useState<string | null>(null);
  const navigate = useNavigate();
  type FieldType = {
    password?: string;
    confirmPassword?: string;
  };

  const validationSchema = Yup.object().shape({
    // password: Yup.string()
    //   .min(8, "Password should be of minimum 8 characters length")
    //   .matches(/[a-z]/, "Password must contain at least one lowercase letter")
    //   .matches(/[A-Z]/, "Password must contain at least one uppercase letter")
    //   .matches(/" "/, "Password must not contain spaces")
    //   .matches(/[0-9]/, "Password must contain at least one digit")
    //   .matches(
    //     /[^\w\s]/,
    //     "Password must contain at least one non-alphanumeric character"
    //   )
    //   .required("Password is required")
    //   .trim(),

    password: Yup.string()
      .matches(
        /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[#$^+=!*()@%&]).{8,}$/,
        "Password must contain at least 8 characters, one uppercase, one lowercase, one number, and one special case character."
      )
      .required("Password is required"),

    confirmPassword: Yup.string()
      .oneOf([Yup.ref("password"), ""], "Passwords must match")
      .required("Confirm password is required"),
  });

  const formik = useFormik({
    initialValues: {
      password: "",
      confirmPassword: "",
    },
    validationSchema: validationSchema,
    onSubmit: async (values) => {
      const { password } = values;
      try {
        setError("");
        setLoading(true);
        const res = await resetPasswordForm({
          Email: email,
          Password: password,
          resetPasswordToken: resetPasswordToken,
          ModifiedBy: data?.userName,
        });
        if (res.isSuccess) {
          handleBack();
        } else {
          setError(res.errors[0]);
        }
      } catch (err) {
        setError("Something went wrong. Please try again later.");
        console.error("ChangePasswordForm:", err);
      } finally {
        setLoading(false);
      }
    },
  });

  const handleBack = () => {
    navigate(routePaths.LOGIN);
  };

  return (
    <>
      <Row justify="center" align="middle" style={{ height: "100%" }}>
        <Col span={12}>
          <Row gutter={[0, parseInt(getConsistentSpacing(5))]}>
            <Col span={24}>
              <Row gutter={[0, parseInt(getConsistentSpacing(1))]}>
                <Col span={24}>
                  <Row justify="center">
                    <Image preview={false} src={ResetPasswordPageIcon} />
                  </Row>
                </Col>
                <Col style={{ margin: "auto" }}>
                  <Row justify="center">
                    <Typography.Title
                      level={2}
                      style={{ width: "100%", textAlign: "center", margin: 0 }}
                    >
                      Set new password
                    </Typography.Title>
                    <Typography.Paragraph
                      style={{
                        textAlign: "center",
                        fontSize: getConsistentSpacing(2.5),
                        margin: 0,
                      }}
                    >
                      Must be at least 8 characters
                    </Typography.Paragraph>
                  </Row>
                </Col>
              </Row>
            </Col>
            <Col span={24}>
              <Form
                onFinish={formik.handleSubmit}
                layout="vertical"
                // name="basic"
                initialValues={{ remember: true }}
                autoComplete="off"
              >
                <Form.Item<FieldType>
                  label={
                    <Typography.Text style={{ fontWeight: "bold" }}>
                      Password
                    </Typography.Text>
                  }
                  name="password"
                  validateStatus={
                    formik.touched.password && formik.errors.password
                      ? "error"
                      : ""
                  }
                  help={
                    formik.touched.password && formik.errors.password
                      ? formik.errors.password
                      : ""
                  }
                  style={{ padding: 0 }}
                >
                  <Input.Password
                    value={formik.values.password}
                    onChange={(event) =>
                      formik.setFieldValue(
                        "password",
                        event?.target?.value || ""
                      )
                    }
                    size="large"
                    placeholder="••••••••••"
                  />
                </Form.Item>
                <Form.Item<FieldType>
                  label={
                    <Typography.Text style={{ fontWeight: "bold" }}>
                      Confirm Password
                    </Typography.Text>
                  }
                  name="confirmPassword"
                  validateStatus={
                    formik.touched.confirmPassword &&
                    formik.errors.confirmPassword
                      ? "error"
                      : ""
                  }
                  help={
                    formik.touched.confirmPassword &&
                    formik.errors.confirmPassword
                      ? formik.errors.confirmPassword
                      : ""
                  }
                  style={{ padding: 0 }}
                >
                  <Input.Password
                    value={formik.values.confirmPassword}
                    onChange={(event) =>
                      formik.setFieldValue(
                        "confirmPassword",
                        event?.target?.value || ""
                      )
                    }
                    size="large"
                    placeholder="••••••••••"
                  />
                </Form.Item>
                <Form.Item style={{ marginTop: getConsistentSpacing(3) }}>
                  <Button
                    loading={loading}
                    block
                    type="primary"
                    htmlType="submit"
                  >
                    {loading ? "Changing password..." : "Change password"}
                  </Button>
                </Form.Item>
                {error && <CustomAlert message={error || ""} type="error" />}
              </Form>
              <div
                style={{
                  display: "flex",
                  justifyContent: "center",
                  width: "100%",
                  marginTop: getConsistentSpacing(1.5),
                }}
              >
                <Button
                  type="text"
                  icon={<CustomIcon type="arrow-back" />}
                  onClick={handleBack}
                  style={{ fontWeight: 500 }}
                >
                  Back to log in
                </Button>
              </div>
            </Col>
          </Row>
        </Col>
      </Row>
    </>
  );
}
