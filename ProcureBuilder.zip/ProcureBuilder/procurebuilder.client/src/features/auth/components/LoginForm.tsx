import CustomAlert from "@/src/components/common/CustomAlert";
import { loginUserByEmail } from "@apis/userApis";
import LoginPageIcon from "@assets/icons/login-page-icon.png";
import { useAppDispatch } from "@hooks/useAppDispatch";
import { useAppSelector } from "@hooks/useAppSelector";
import { getUserState, resetState } from "@store/slices/userSlice";
import routePaths from "@utils/routePaths";
import { getConsistentSpacing } from "@utils/theme-helpers";
import { Button, Col, Form, Image, Input, Row, Typography } from "antd";
import { useFormik } from "formik";
import { useEffect } from "react";
import { useNavigate } from "react-router-dom";

export default function LoginForm() {
  const navigate = useNavigate();
  const dispatch = useAppDispatch();
  const { isLoading, resError, reqError } = useAppSelector(getUserState);

  type FieldType = {
    emailAddress?: string;
    password?: string;
    remember?: string;
  };

  const formik = useFormik({
    initialValues: {
      emailAddress: "",
      password: "",
      remember: "",
    },
    onSubmit: (values) => {
      dispatch(
        loginUserByEmail({
          UserName: values.emailAddress,
          Password: values.password,
        })
      );
    },
  });

  useEffect(() => {
    dispatch(resetState());
  }, [formik.values]);

  return (
    <>
      <Row
        justify="center"
        align="middle"
        style={{ height: "100%", overflow: "hidden" }}
      >
        <Col span={12}>
          <Row gutter={[0, parseInt(getConsistentSpacing(5))]}>
            <Col span={24}>
              <Row gutter={[0, parseInt(getConsistentSpacing(1))]}>
                <Col span={24}>
                  <Row justify="center">
                    <Image preview={false} src={LoginPageIcon} />
                  </Row>
                </Col>
                <Col style={{ margin: "auto" }}>
                  <Row justify="center">
                    <Typography.Title
                      level={2}
                      style={{ width: "100%", textAlign: "center", margin: 0 }}
                    >
                      Login to your account
                    </Typography.Title>
                    <Typography.Paragraph
                      style={{
                        textAlign: "center",
                        fontSize: getConsistentSpacing(2.5),
                        margin: 0,
                      }}
                    >
                      Enter your details to login.
                    </Typography.Paragraph>
                  </Row>
                </Col>
              </Row>
            </Col>
            <Col span={24}>
              <Form
                onFinish={formik.handleSubmit}
                layout="vertical"
                name="basic"
                initialValues={{ remember: true }}
                // onFinish={onFinish}
                // onFinishFailed={onFinishFailed}
                requiredMark="optional"
                autoComplete="off"
              >
                <Form.Item<FieldType>
                  label={
                    <Typography.Text style={{ fontWeight: "bold" }}>
                      Email Address
                    </Typography.Text>
                  }
                  name="emailAddress"
                  labelAlign="right"
                  rules={[
                    {
                      required: true,
                      validator: (_, value) => {
                        if (!value) {
                          return Promise.reject("Email is required");
                        } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) {
                          return Promise.reject("Invalid email");
                        } else {
                          return Promise.resolve();
                        }
                      },
                    },
                  ]}
                >
                  <Input
                    value={formik.values.emailAddress}
                    onChange={(event) =>
                      formik.setFieldValue(
                        "emailAddress",
                        event?.target?.value || ""
                      )
                    }
                    size="large"
                    placeholder="johnsmith@email.com"
                  />
                </Form.Item>
                <Form.Item<FieldType>
                  label={
                    <Typography.Text style={{ fontWeight: "bold" }}>
                      Password
                    </Typography.Text>
                  }
                  name="password"
                  style={{ padding: 0 }}
                  rules={[
                    {
                      required: true,
                      message: "Password is required",
                    },
                  ]}
                >
                  <Input.Password
                    value={formik.values.password}
                    onChange={(event) =>
                      formik.setFieldValue(
                        "password",
                        event?.target?.value || ""
                      )
                    }
                    size="large"
                    placeholder="••••••••••"
                  />
                </Form.Item>
                {(resError || reqError) && (
                  <Row
                    style={{
                      marginTop: getConsistentSpacing(0.5),
                      marginBottom: getConsistentSpacing(3),
                    }}
                  >
                    <CustomAlert
                      message={resError || reqError || ""}
                      type="error"
                      hasMargin={false}
                    />
                  </Row>
                )}
                <div
                  style={{
                    marginTop: getConsistentSpacing(0.5),
                    marginBottom: getConsistentSpacing(4),
                  }}
                >
                  <Button
                    onClick={() => navigate(routePaths.FORGOTPASSWORD)}
                    type="link"
                    style={{ marginLeft: "auto", padding: 0 }}
                  >
                    Forgot password?
                  </Button>
                </div>
                <Form.Item>
                  <Button
                    loading={isLoading}
                    block
                    type="primary"
                    htmlType="submit"
                  >
                    {isLoading ? "Logging in.." : "Login"}
                  </Button>
                </Form.Item>
              </Form>
            </Col>
          </Row>
        </Col>
      </Row>
    </>
  );
}
