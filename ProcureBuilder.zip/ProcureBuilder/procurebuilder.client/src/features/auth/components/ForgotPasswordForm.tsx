import { Button, Col, Form, Image, Input, Row, Typography } from "antd";
import { useFormik } from "formik";
import ForgotPasswordIcon from "@assets/icons/forgot-pass-icon.png";
import { getConsistentSpacing } from "@utils/theme-helpers";
import { forgotPasswordByEmail } from "@apis/userApis";

import { useNavigate } from "react-router-dom";
import CustomIcon from "@components/common/CustomIcon";
import routePaths from "@utils/routePaths";
import { useState } from "react";
import CustomAlert from "@/src/components/common/CustomAlert";
export default function ForgotPasswordForm() {
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  type FieldType = {
    emailAddress?: string;
  };

  const formik = useFormik({
    initialValues: {
      emailAddress: "",
    },
    onSubmit: async (values) => {
      try {
        setError("");
        setIsLoading(true);
        const Email = values?.emailAddress;
        const res = await forgotPasswordByEmail({
          Email,
        });

        if (res.isSuccess) {
          navigate(
            `${routePaths.VERIFY_OTP}?email=${encodeURIComponent(Email)}`
          );
        } else {
          setError(res.errors[0]);
        }
      } catch (err) {
        setError("Something went wrong. Please try again later.");
        console.error("err", err);
      } finally {
        setIsLoading(false);
      }
    },
  });

  const handleBack = () => {
    navigate(routePaths.LOGIN);
  };

  return (
    <>
      <Row justify="center" align="middle" style={{ height: "100%" }}>
        <Col span={12}>
          <Row gutter={[0, parseInt(getConsistentSpacing(5))]}>
            <Col span={24}>
              <Row gutter={[0, parseInt(getConsistentSpacing(1))]}>
                <Col span={24}>
                  <Row justify="center">
                    <Image preview={false} src={ForgotPasswordIcon} />
                  </Row>
                </Col>
                <Col style={{ margin: "auto" }}>
                  <Row justify="center">
                    <Typography.Title
                      level={2}
                      style={{ width: "100%", textAlign: "center", margin: 0 }}
                    >
                      Forgot password?
                    </Typography.Title>
                    <Typography.Paragraph
                      style={{ fontSize: getConsistentSpacing(2.5), margin: 0 }}
                    >
                      Enter your email to reset your password.
                    </Typography.Paragraph>
                  </Row>
                </Col>
              </Row>
            </Col>
            <Col span={24}>
              <Form
                onFinish={formik.handleSubmit}
                layout="vertical"
                name="basic"
                initialValues={{ remember: true }}
                // onFinish={onFinish}
                // onFinishFailed={onFinishFailed}
                requiredMark="optional"
                autoComplete="off"
              >
                <Form.Item<FieldType>
                  label={
                    <Typography.Text style={{ fontWeight: "bold" }}>
                      Email Address
                    </Typography.Text>
                  }
                  name="emailAddress"
                  labelAlign="right"
                  rules={[
                    {
                      required: true,
                      message: "Email address must not be empty.",
                    },
                  ]}
                >
                  <Input
                    value={formik.values.emailAddress}
                    onChange={(event) =>
                      formik.setFieldValue(
                        "emailAddress",
                        event?.target?.value || ""
                      )
                    }
                    size="large"
                    placeholder="johnsmith@email.com"
                  />
                </Form.Item>

                <Form.Item style={{ marginTop: getConsistentSpacing(3) }}>
                  <Button
                    loading={isLoading}
                    block
                    type="primary"
                    htmlType="submit"
                  >
                    {isLoading ? "Sending..." : "Send OTP"}
                  </Button>
                </Form.Item>
              </Form>
              {error && <CustomAlert message={error || ""} type="error" />}
              <div
                style={{
                  display: "flex",
                  justifyContent: "center",
                  width: "100%",
                  marginTop: getConsistentSpacing(1.5),
                }}
              >
                <Button
                  type="text"
                  icon={<CustomIcon type="arrow-back" />}
                  onClick={handleBack}
                  style={{ fontWeight: 500 }}
                >
                  Back to log in
                </Button>
              </div>
            </Col>
          </Row>
        </Col>
      </Row>
    </>
  );
}
