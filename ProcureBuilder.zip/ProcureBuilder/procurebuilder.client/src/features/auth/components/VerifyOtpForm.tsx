import CustomAlert from "@/src/components/common/CustomAlert";
import { forgotPasswordByEmail, verifyOtpByEmail } from "@apis/userApis";
import OtpImage from "@assets/icons/otp-icon.png";
import CustomIcon from "@components/common/CustomIcon";
import routePaths from "@utils/routePaths";
import { getConsistentSpacing } from "@utils/theme-helpers";
import {
  Button,
  Col,
  Form,
  GetProp,
  Image,
  Input,
  Row,
  Typography,
} from "antd";
import { OTPProps } from "antd/es/input/OTP";
import { useEffect, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";

export default function ForgotPasswordForm() {
  const location = useLocation();
  const searchParams = new URLSearchParams(location.search);
  const email: string = searchParams.get("email") || "";
  const [otp, setOtp] = useState<number>();
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [isResending, setIsResending] = useState(false);
  const [timer, setTimer] = useState(60);
  const navigate = useNavigate();

  type FieldType = {
    otp?: number;
  };

  const onSubmit = async () => {
    try {
      setError("");
      setLoading(true);
      true;
      const res = await verifyOtpByEmail({
        Email: email,
        OTP: otp,
      });
      if (res.isSuccess) {
        navigate(
          `${routePaths.RESET_PASSWORD}?data=${encodeURIComponent(
            email
          )}&resetPasswordToken=${encodeURIComponent(res.resetPasswordToken)}`
        );
      } else {
        setError(res.errors[0]);
      }
    } catch (err) {
      setError("Something went wrong. Please try again later.");
      console.error("err", err);
    } finally {
      setLoading(false);
    }
  };

  const onChange: GetProp<typeof Input.OTP, "onChange"> = (text) => {
    setOtp(parseInt(text));
  };

  const sharedProps: OTPProps = {
    onChange,
  };

  const handleBack = () => {
    navigate(routePaths.LOGIN);
  };

  const handleResendOtp = () => {
    setIsResending(true);
    setTimer(60);
    setTimeout(async () => {
      try {
        const res = await forgotPasswordByEmail({
          Email: email,
        });
        if (!res.isSuccess) {
          setError(res.errors[0]);
        }
      } catch (err) {
        console.error("err", err);
      }
      setIsResending(false);
    }, 60000);
  };

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isResending) {
      interval = setInterval(() => {
        setTimer((prevTimer) => {
          if (prevTimer === 0) {
            setIsResending(false);
            clearInterval(interval);
            return 0;
          }
          return prevTimer - 1;
        });
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isResending]);

  return (
    <>
      <Row justify="center" align="middle" style={{ height: "100%" }}>
        <Col span={12}>
          <Row gutter={[0, parseInt(getConsistentSpacing(5))]}>
            <Col span={24}>
              <Row gutter={[0, parseInt(getConsistentSpacing(1))]}>
                <Col span={24}>
                  <Row justify="center">
                    <Image preview={false} src={OtpImage} />
                  </Row>
                </Col>
                <Col style={{ margin: "auto" }}>
                  <Row justify="center">
                    <Typography.Title
                      level={2}
                      style={{ width: "100%", textAlign: "center", margin: 0 }}
                    >
                      Enter your code
                    </Typography.Title>
                    <Typography.Paragraph
                      style={{ fontSize: getConsistentSpacing(2.5), margin: 0 }}
                    >
                      We sent a code to <b>{email}</b>
                    </Typography.Paragraph>
                  </Row>
                </Col>
              </Row>
            </Col>
            <Col span={24}>
              <Form
                onFinish={onSubmit}
                layout="vertical"
                name="basic"
                initialValues={{ remember: true }}
                requiredMark="optional"
                autoComplete="off"
              >
                <Form.Item<FieldType>
                  name="otp"
                  labelAlign="right"
                  rules={[
                    {
                      required: true,
                      message: "OTP must not be empty.",
                    },
                  ]}
                >
                  <div
                    style={{
                      display: "flex",
                      justifyContent: "center",
                      margin: getConsistentSpacing(2.5),
                    }}
                  >
                    <Input.OTP
                      formatter={(str) => str.toUpperCase()}
                      {...sharedProps}
                    />
                  </div>
                </Form.Item>
                {timer % 60 > 10 && (
                  <div
                    style={{
                      display: "flex",
                      justifyContent: "center",
                      marginBottom: getConsistentSpacing(3),
                    }}
                  >
                    <span
                      onClick={handleResendOtp}
                      style={{
                        color: "#E3963E",
                        cursor: isResending ? "not-allowed" : "pointer",
                      }}
                    >
                      <span style={{ color: "#525866" }}>Resend in </span>
                      <span style={{ color: "#DF1C41" }}>
                        {isResending
                          ? `${Math.floor(timer / 60)}:${
                              timer % 60 < 10 ? "0" : ""
                            }${timer % 60}`
                          : "Resend OTP"}
                      </span>
                    </span>
                  </div>
                )}
                <Button
                  loading={loading}
                  block
                  type="primary"
                  htmlType="submit"
                >
                  {loading ? "Continuing..." : "Continue"}
                </Button>
              </Form>
              <div
                style={{
                  display: "flex",
                  justifyContent: "center",
                  width: "100%",
                  marginTop: getConsistentSpacing(1.5),
                }}
              >
                <span style={{ marginRight: getConsistentSpacing(0.25) }}>
                  Didn’t receive the email ?
                </span>
                <span
                  style={{
                    color: "#f44803",
                    // cursor: "pointer",
                    opacity: 0.8,
                    cursor: isResending ? "not-allowed" : "pointer",
                  }}
                  onClick={!isResending ? handleResendOtp : () => {}}
                >
                  Click to resend
                </span>
              </div>
              {error && <CustomAlert message={error || ""} type="error" />}
              <div
                style={{
                  display: "flex",
                  justifyContent: "center",
                  width: "100%",
                  marginTop: getConsistentSpacing(3),
                }}
              >
                <Button
                  type="text"
                  icon={<CustomIcon type="arrow-back" />}
                  onClick={handleBack}
                  style={{ fontWeight: 500 }}
                >
                  Back to log in
                </Button>
              </div>
            </Col>
          </Row>
        </Col>
      </Row>
    </>
  );
}
