import { useState, useEffect } from "react";
import CustomIcon from "@/src/components/common/CustomIcon";
import SectionLayout from "@/src/components/layout/SectionLayout";
import BidMaterialImg from "@assets/images/bid-material/bid-material-orange.png";
import { Button, Flex } from "antd";
import BidMaterialDetailForm from "./BidMaterialDetailsForm";
import { getBidMaterialsById } from "@/src/apis/bidMaterialApis";
import { useAppDispatch } from "@/src/hooks/useAppDispatch";
import { BidMaterialRequestType } from "@/src/utils/types";
import CustomOverlayLoader from "@/src/components/common/CustomOverlayloader";
import useAuthorization from "@/src/hooks/useAuthorization";
type BidMaterialTabProps = {
  projectId: string | undefined;
};

export default function BidMaterialTab({ projectId }: BidMaterialTabProps) {
  const [displayForm, setDisplayForm] = useState<boolean | null>(null);
  const { isFieldsCraftAuthorized } = useAuthorization();
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [bidMaterials, setBidMaterials] = useState<Omit<
    BidMaterialRequestType,
    "changeOrderIds"
  > | null>(null);
  const dispatch = useAppDispatch();

  const fetchBidMaterials = async () => {
    try {
      const response = await dispatch(
        getBidMaterialsById({ projectId })
      ).unwrap();
      setBidMaterials(response);
    } catch (error) {
      console.error(error);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchBidMaterials();
  }, [displayForm]);

  const NoBidMaterialSection = (
    <>
      <SectionLayout>
        <SectionLayout
          className="p-8 rounded-xl items-center max-h-64"
          borderStyle="dashed"
        >
          <img src={BidMaterialImg} width="48" height="48" className="mb-5" />
          <h6 className="font-medium text-sm !mb-1">
            No Bid Materials Added Yet
          </h6>
          <p className="font-normal text-xs mb-5 text-neutral-7">
            Please Add Bid Materials to get started.
          </p>

          {!isFieldsCraftAuthorized() && (
            <Flex className="gap-5">
              <Button
                size="large"
                className="hover:!fill-primary"
                icon={<CustomIcon type="plus" />}
                onClick={() => {
                  setDisplayForm(true);
                }}
              >
                Add Bid Materials
              </Button>
            </Flex>
          )}
        </SectionLayout>
      </SectionLayout>
    </>
  );

  if (isLoading) {
    return <CustomOverlayLoader />;
  }

  return (
    <>
      {Boolean(bidMaterials?.materials?.length) || displayForm ? (
        <BidMaterialDetailForm
          bidMaterialDetails={bidMaterials}
          setBidMaterials={setBidMaterials}
          handleCancelForm={() => {
            setDisplayForm(false);
          }}
        />
      ) : (
        NoBidMaterialSection
      )}
    </>
  );
}
