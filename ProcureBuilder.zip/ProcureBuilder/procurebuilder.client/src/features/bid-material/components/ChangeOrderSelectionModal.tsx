import CustomModal from "@/src/components/common/CustomModal";
import ChangeOrderByProjectList from "../../change-orders/components/ChangeOrderbyProjectList";
import { useEffect, useState } from "react";
import { Key } from "antd/es/table/interface";
import SectionLayout from "@/src/components/layout/SectionLayout";
import { useAppDispatch } from "@/src/hooks/useAppDispatch";
import { getChangeOrderById } from "@/src/apis/changeOrderApis";
import { ChangeOrder } from "@/src/utils/types";

type CustomerSelectionModalProps = {
  isModalOpen: boolean;
  disabledChangeOrderIds: string[];
  setIsModalOpen: React.Dispatch<React.SetStateAction<boolean>>;
  onChangeOrderAdd: (response: ChangeOrder) => void;
};

export default function ChangeOrderSelectionModal({
  isModalOpen,
  disabledChangeOrderIds,
  setIsModalOpen,
  onChangeOrderAdd: onChangeOrderAdd,
}: CustomerSelectionModalProps) {
  const dispatch = useAppDispatch();
  const [selectedChangeOrderId, setSelectedChangeOrderId] = useState<Key>("");

  useEffect(() => {
    if (isModalOpen) {
      setSelectedChangeOrderId("");
    }
  }, [isModalOpen]);

  const handleAdd = async () => {
    if (selectedChangeOrderId) {
      const response = await dispatch(
        getChangeOrderById({ id: selectedChangeOrderId as string })
      ).unwrap();
      onChangeOrderAdd(response?.changeOrder);
    }
  };

  const handleCancel = () => {
    setIsModalOpen(false);
  };

  return (
    <CustomModal
      title="Change Orders"
      isOpen={isModalOpen}
      primaryButtonAction={handleAdd}
      cancelButtonAction={handleCancel}
      primaryButtonText="Add"
      primaryButtonLoadingText="Adding.."
      isPrimaryButtonDisabled={!selectedChangeOrderId}
    >
      <div className="mt-4">
        <SectionLayout>
          <ChangeOrderByProjectList
            hasCursorPointer
            hasRowSelection
            hasPagination={false}
            selectedRowId={selectedChangeOrderId}
            setSelectedRowId={setSelectedChangeOrderId}
            disabledChangeOrderIds={disabledChangeOrderIds}
          />
        </SectionLayout>
      </div>
    </CustomModal>
  );
}
