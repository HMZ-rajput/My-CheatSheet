import {
  createBidMaterials,
  deleteBidMaterialById,
  editBidMaterials,
} from "@/src/apis/bidMaterialApis";
import CreatedByUserBadge from "@/src/components/common/CreatedByUserBadge";
import CustomAlert from "@/src/components/common/CustomAlert";
import CustomFormLabel from "@/src/components/common/CustomFormLabel";
import CustomIcon from "@/src/components/common/CustomIcon";
import CustomFormRow from "@/src/components/form/CustomFormRow";
import { bidMaterialInitialMaterials } from "@/src/data/intialsValues";
import { BidMaterialValidationSchema } from "@/src/data/validationsSchema";
import BulkUploadButton from "@/src/external-modules/bulk-upload/BulkUploadButton";
import BulkUploaderParser from "@/src/external-modules/bulk-upload/BulkUploadParser";
import { useAppSelector } from "@/src/hooks/useAppSelector";
import {
  getBidMaterialState,
  resetState,
} from "@/src/store/slices/bidMaterialSlice";
import { MaterialReviewPeriod } from "@/src/utils/enums";
import {
  BidMaterialRequestType,
  ChangeOrder,
  LabelSupportedMaterialType,
  Material,
} from "@/src/utils/types";
import SectionLayout from "@components/layout/SectionLayout";
import AddMaterialOfBidMaterial from "@components/materials/AddMaterialsOfBidMaterial";
import { yupResolver } from "@hookform/resolvers/yup";
import { useAppDispatch } from "@hooks/useAppDispatch";
import { getConsistentSpacing } from "@utils/theme-helpers";
import {
  Button,
  Col,
  Divider,
  Flex,
  Form,
  InputNumber,
  Radio,
  Select,
  Space,
  Typography,
} from "antd";
import { Dispatch, SetStateAction, useEffect, useState } from "react";
import { Controller, Resolver, useForm } from "react-hook-form";
import { useParams } from "react-router-dom";
import ChangeOrderSelectionModal from "./ChangeOrderSelectionModal";
import { formatDecimals } from "@/src/utils/number-extensions";
import { getLowerCasedMaterialName } from "@/src/external-modules/bulk-upload/bulk-upload-utils";
import useAuthorization from "@/src/hooks/useAuthorization";
import { isFreight } from "@/src/utils/constants";
import { textSearchFormat } from "@/src/utils/helper";
import CustomInfoTooltip from "@/src/components/common/CustomInfoTooltip";
type BidMaterialFormProps = {
  bidMaterialDetails: Omit<BidMaterialRequestType, "changeOrderIds"> | null;
  handleCancelForm: () => void;
  setBidMaterials: Dispatch<
    SetStateAction<Omit<BidMaterialRequestType, "changeOrderIds"> | null>
  >;
};

export default function BidMaterialDetailForm({
  bidMaterialDetails,
  setBidMaterials,
  handleCancelForm,
}: BidMaterialFormProps) {
  const { projectId } = useParams();
  const { isFieldsCraftAuthorized } = useAuthorization();
  const dispatch = useAppDispatch();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [validationError, setValidationError] = useState("");
  const [isDeleting, setIsDeleting] = useState(false);
  const { successMessage, resError, reqError } =
    useAppSelector(getBidMaterialState);

  const [addedChangeOrderIds, setAddedChangeOrderIds] = useState<string[]>([]);
  const handleChangeOrderAdd = (response: ChangeOrder) => {
    let hasErrorWhileAddingCO = false;

    if (response?.materials) {
      const existingMaterials = getValues("materials") || [];
      const existingMaterialsMap = existingMaterials.reduce((acc, material) => {
        const name = getLowerCasedMaterialName(material);
        acc[name] = material;
        return acc;
      }, {} as Record<string, Material>);

      const updatedMaterials = response?.materials?.map(
        (changeOrderMaterial, index) => {
          const name = getLowerCasedMaterialName(changeOrderMaterial);
          const existingMaterial = existingMaterialsMap[name];

          if (existingMaterial) {
            let quantity =
              existingMaterial.quantity + changeOrderMaterial.quantity;
            let budget =
              existingMaterial.totalBudget + changeOrderMaterial.totalBudget;
            let unitRate = formatDecimals(budget / quantity);

            if (quantity < 0) {
              quantity = 0;
              unitRate = existingMaterial.unitRate;

              setError(`materials.${index}.quantity`, {
                message: "Quantity cannot be 0",
                type: "min",
              });

              hasErrorWhileAddingCO = true;
            }

            return {
              ...existingMaterial,
              quantity,
              unitRate,
            };
          }
          return changeOrderMaterial;
        }
      );

      const finalMaterials = [
        ...updatedMaterials,
        ...existingMaterials.filter(
          (material) =>
            !response.materials.some(
              (m) =>
                getLowerCasedMaterialName(m) ===
                getLowerCasedMaterialName(material)
            )
        ),
      ];

      if (!hasErrorWhileAddingCO) {
        setAddedChangeOrderIds((prev) => [...prev, response?.id || ""]);
      }
      console.log("finalMaterials", finalMaterials);
      setValue("materials", finalMaterials);
      const prevOtherCost = getValues("otherCosts") || 0;
      const changeOrderOtherCost = response?.otherCosts || 0;
      setValue("otherCosts", prevOtherCost + changeOrderOtherCost);
      handleUpdateTotals();
      setIsModalOpen(false);
    }
  };

  const {
    control,
    reset,
    handleSubmit,
    setValue,
    getValues,
    setError,
    formState: { errors, isSubmitting },
  } = useForm<BidMaterialRequestType>({
    resolver: yupResolver(
      BidMaterialValidationSchema
    ) as unknown as Resolver<BidMaterialRequestType>,
    defaultValues: {
      isMaterialReceiptInspectionFormRequired:
        bidMaterialDetails?.isMaterialReceiptInspectionFormRequired ?? true,
      assumedSubmittalReview: bidMaterialDetails?.assumedSubmittalReview || 0,
      assumedSubmittalReviewPeriod:
        bidMaterialDetails?.assumedSubmittalReviewPeriod || 0,
      materials: bidMaterialDetails?.materials?.length
        ? bidMaterialDetails.materials.map((material) => ({
            id: material.id,
            name: material.name,
            costCode: material.costCode,
            quantity: material.quantity,
            unitOfMeasure: material.unitOfMeasure,
            unitRate: material.unitRate,
            totalBudget: material.totalBudget,
          }))
        : bidMaterialInitialMaterials,
      subTotal: bidMaterialDetails?.subTotal || 0,
      taxPercentage: bidMaterialDetails?.taxPercentage || 0,
      tax: (bidMaterialDetails?.tax?.toFixed(2) as unknown as number) || 0,
      total: bidMaterialDetails?.total || 0,
      otherCosts: bidMaterialDetails?.otherCosts || 0,
    },

    shouldUnregister: false,
  });

  const onSubmit = async (values: BidMaterialRequestType) => {
    setValidationError("");
    try {
      const payload: BidMaterialRequestType = {
        ...values,
        otherCosts: values?.otherCosts || 0,
        assumedSubmittalReview: values.assumedSubmittalReview,
        projectId: projectId || "",
        materials: values.materials.map((m) => ({
          ...m,
          id: m.id || null,
          projectId: projectId || "",
        })),
        changeOrderIds: addedChangeOrderIds,
      };

      if (projectId && bidMaterialDetails) {
        const res = await dispatch(editBidMaterials(payload)).unwrap();
        if (res.isSuccess) {
          setBidMaterials(res as unknown as BidMaterialRequestType);
        }
      } else {
        const res = await dispatch(createBidMaterials(payload)).unwrap();
        if (res.isSuccess) {
          setBidMaterials(res as unknown as BidMaterialRequestType);
        }
      }
    } catch (err) {
      console.error(err);
      setValidationError("Something went wrong!");
    }
  };

  const handleDeleteMaterial = async () => {
    try {
      setIsDeleting(true);
      const res = await dispatch(
        deleteBidMaterialById({
          projectId: projectId,
          materials: bidMaterialDetails?.materials?.map(
            (m) => m?.id
          ) as string[],
        })
      ).unwrap();
      if (res.isSuccess) {
        handleCancelForm();
        setValue("isMaterialReceiptInspectionFormRequired", true);
        setValue("assumedSubmittalReview", 0);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsDeleting(false);
    }
  };

  useEffect(() => {
    dispatch(resetState());
  }, []);

  const [resetBulkUploadFile, setBulkUploadFile] = useState(0);

  const handleUpdateTotals = () => {
    const materials = getValues("materials") || [];
    materials.forEach((material, index) => {
      const total = calculateMaterialTotal(material);
      setValue(`materials.${index}.totalBudget`, formatDecimals(total));
    });

    updateSubTotal();
    const taxPercentage = getValues("taxPercentage") || 0;
    const subTotal = getValues("subTotal") || 0;
    const freightAmountTotal = materials?.reduce((acc, material) => {
      if (textSearchFormat(material.name) === isFreight) {
        return acc + Number(material.totalBudget);
      }
      return acc;
    }, 0);
    const subTotalWithoutFreight = subTotal - freightAmountTotal;

    const finalTax = (subTotalWithoutFreight * taxPercentage) / 100;
    const otherCosts = getValues("otherCosts") || 0;
    const total = subTotal + finalTax + otherCosts;
    setValue("tax", formatDecimals(finalTax));
    setValue("total", formatDecimals(total));
  };

  async function updateMaterials(file: File) {
    const bulkUploadParser = new BulkUploaderParser<
      LabelSupportedMaterialType[]
    >();
    const rows = await bulkUploadParser.readAndParseAsync(file);

    const isValid = await bulkUploadParser.validateMaterials<
      LabelSupportedMaterialType[]
    >({
      rows,
      schema: {
        material: "string",
        costCode: "alphanumericString",
        quantity: "number",
        unitOfMeasurement: "alphanumericString",
        unitRate: "number",
        totalBudget: "alphanumericString",
      },
      requiredKeys: ["material", "costCode", "unitOfMeasurement", "unitRate"],
    });

    setBulkUploadFile(Date.now());

    if (!isValid) {
      return;
    }

    let subTotal = 0;

    rows.forEach((m) => {
      m.id = null;
      m.name = m?.material;
      m.unitOfMeasure = m?.unitOfMeasurement;
      subTotal += m.quantity * m.unitRate;
      m.totalBudget = formatDecimals(calculateMaterialTotal(m)) || 0;
    });

    const newRows = rows?.map((m) => ({
      ...m,
      name: m?.material,
      unitOfMeasure: m?.unitOfMeasurement,
    }));

    reset((values) => {
      let materials = [];
      const oldMaterials =
        values?.materials?.filter((f) => getLowerCasedMaterialName(f)) || [];

      if (oldMaterials?.length) {
        materials = bulkUploadParser.mergeMaterials({
          oldMaterials,
          newMaterials: newRows,
          keysToBeUpdated: ["quantity", "unitRate", "totalBudget"],
        });
      } else {
        materials = newRows;
      }

      return { ...values, materials, subTotal };
    });
    handleUpdateTotals();
  }

  const calculateMaterialTotal = (material: Material) =>
    Number(material.quantity || 0) * Number(material.unitRate || 0);

  const updateSubTotal = () => {
    const materials = getValues("materials") || [];
    const subTotal = materials.reduce(
      (sum, material) => sum + calculateMaterialTotal(material),
      0
    );
    setValue("subTotal", formatDecimals(subTotal));
  };

  const handleCalculateTax = (value: number) => {
    const taxPercentage = Number(value || 0);
    setValue("taxPercentage", taxPercentage);
    const subTotal = getValues("subTotal") || 0;
    const tax = (subTotal * taxPercentage) / 100;
    setValue("tax", tax?.toFixed(3) as unknown as number);
    const total = subTotal + tax;
    setValue("total", total?.toFixed(3) as unknown as number);
  };

  return (
    <>
      <SectionLayout>
        <Form onFinish={handleSubmit(onSubmit)} autoComplete="off">
          <CustomFormRow>
            <Col xs={24} className="mb-4">
              <Typography.Title level={5}>
                Bid Material Details
              </Typography.Title>
            </Col>

            <Col xs={12} className="mb-12">
              <Controller
                control={control}
                name="isMaterialReceiptInspectionFormRequired"
                render={({ field }) => (
                  <Form.Item
                    layout="vertical"
                    label={
                      <CustomFormLabel
                        text="For Material Delivery, is a Material Receipt Inspection Form Required?"
                        required={true}
                      />
                    }
                    validateStatus={
                      errors.isMaterialReceiptInspectionFormRequired
                        ? "error"
                        : ""
                    }
                    help={
                      errors.isMaterialReceiptInspectionFormRequired?.message
                    }
                  >
                    <Radio.Group
                      disabled={isFieldsCraftAuthorized()}
                      className="mt-6"
                      size="large"
                      value={field.value}
                      onChange={(value) => {
                        field.onChange(value);
                      }}
                    >
                      <Radio value={true}>Yes</Radio>
                      <Radio value={false}>No</Radio>
                    </Radio.Group>
                  </Form.Item>
                )}
              />
            </Col>

            <Col xs={12}>
              <Form.Item
                layout="vertical"
                label={
                  <CustomFormLabel
                    text="Assumed Submittal Review Period"
                    hasMarginBottom
                    required={true}
                  />
                }
                validateStatus={errors.assumedSubmittalReview ? "error" : ""}
                help={errors.assumedSubmittalReview?.message}
              >
                <Controller
                  control={control}
                  name="assumedSubmittalReview"
                  render={({ field }) => (
                    <InputNumber
                      disabled={isFieldsCraftAuthorized()}
                      {...field}
                      className="w-full"
                      size="large"
                      type="number"
                      onChange={(value) => {
                        field.onChange(value);
                      }}
                      value={field.value}
                      placeholder="Enter period"
                      addonAfter={
                        <Controller
                          control={control}
                          name="assumedSubmittalReviewPeriod"
                          render={({ field }) => (
                            <Select
                              className="min-w-24"
                              {...field}
                              onChange={(value) => {
                                field.onChange(value);
                              }}
                              options={[
                                {
                                  value: MaterialReviewPeriod.DAYS,
                                  label: "Days",
                                },
                                {
                                  value: MaterialReviewPeriod.WEEKS,
                                  label: "Weeks",
                                },
                                {
                                  value: MaterialReviewPeriod.MONTH,
                                  label: "Months",
                                },
                                {
                                  value: MaterialReviewPeriod.YEARS,
                                  label: "Years",
                                },
                              ]}
                            />
                          )}
                        />
                      }
                    />
                  )}
                />
              </Form.Item>
            </Col>

            <Col xs={24} className="my-2">
              <Divider />
            </Col>
            {/* {!isFieldsCraftAuthorized() && ( */}
            <Col xs={24}>
              <Col xs={12}>
                <Form.Item
                  layout="vertical"
                  label={
                    <>
                      <CustomFormLabel text="Tax Percentage" required />
                      <CustomInfoTooltip
                        placement="top"
                        title={"Tax is not applicable on Freight"}
                      />
                    </>
                  }
                >
                  <Controller
                    name={`taxPercentage`}
                    control={control}
                    render={({ field, formState: { errors } }) => {
                      return (
                        <Form.Item
                          help={errors?.taxPercentage?.message}
                          validateStatus={errors?.taxPercentage ? "error" : ""}
                        >
                          <Space.Compact size="large" style={{ width: "100%" }}>
                            <InputNumber
                              {...field}
                              onChange={(value) => {
                                field.onChange(value);
                                handleCalculateTax(value || 0);
                                handleUpdateTotals();
                              }}
                              style={{ width: "100%" }}
                              min={0}
                              max={100}
                              disabled={isFieldsCraftAuthorized()}
                              // step={0.001}
                              size="large"
                              type="number"
                              placeholder="Add Tax % here"
                            />
                            <Button
                              disabled
                              style={{
                                cursor: "default",
                                width: "10%",
                              }}
                            >
                              %
                            </Button>
                          </Space.Compact>
                        </Form.Item>
                      );
                    }}
                  />
                </Form.Item>
              </Col>
            </Col>
            {/* )} */}
            <div className="mt-24"></div>
            <Col xs={12} className="flex items-center">
              <Typography.Title level={5} className="!m-0">
                Bid Materials
              </Typography.Title>
            </Col>

            {!isFieldsCraftAuthorized() && (
              <Col xs={12} className="flex justify-end gap-4">
                <Button
                  className="hover:!fill-primaryHover"
                  size="large"
                  icon={<CustomIcon type="plus" />}
                  onClick={() => setIsModalOpen(true)}
                >
                  Add Change Order
                </Button>
                <BulkUploadButton
                  updateMaterialsCallback={updateMaterials}
                  shouldReset={resetBulkUploadFile}
                />
              </Col>
            )}

            <Col xs={24} className="mt-6">
              <AddMaterialOfBidMaterial
                handleUpdateTotals={handleUpdateTotals}
                control={control}
              />
            </Col>
          </CustomFormRow>

          {validationError ? (
            <CustomAlert message={validationError || ""} type="error" />
          ) : (
            (reqError || resError || successMessage) && (
              <CustomAlert
                message={resError || successMessage || ""}
                type={successMessage ? "success" : "error"}
              />
            )
          )}

          {!isFieldsCraftAuthorized() && (
            <Flex
              justify="flex-end"
              className="mt-10 mb-5"
              gap={parseInt(getConsistentSpacing(2))}
            >
              {Boolean(bidMaterialDetails?.materials?.length) && (
                <Button
                  loading={isDeleting}
                  disabled={isSubmitting || isDeleting}
                  type="default"
                  onClick={handleDeleteMaterial}
                >
                  {isDeleting ? "Deleting All.." : "Delete All"}
                </Button>
              )}
              <Button
                loading={isSubmitting}
                disabled={isSubmitting || isDeleting}
                type="primary"
                htmlType="submit"
                onClick={() => onSubmit}
              >
                {isSubmitting ? "Saving.." : "Save"}
              </Button>
            </Flex>
          )}
        </Form>
        <div className="mt-10"></div>
        {bidMaterialDetails?.createdBy && bidMaterialDetails?.createdDate && (
          <Flex justify="flex-end">
            <CreatedByUserBadge
              // userName={bidMaterialDetails.createdBy as string}
              // date={bidMaterialDetails.createdDate as Date}
              userName={
                bidMaterialDetails.modifiedDate == null
                  ? bidMaterialDetails?.createdBy
                  : bidMaterialDetails?.lastModifiedBy
              }
              date={bidMaterialDetails?.lastModifiedDate}
              isModifiedBadge={
                bidMaterialDetails.modifiedDate === null ? false : true
              }
            />
          </Flex>
        )}
      </SectionLayout>
      <ChangeOrderSelectionModal
        isModalOpen={isModalOpen}
        setIsModalOpen={setIsModalOpen}
        onChangeOrderAdd={handleChangeOrderAdd}
        disabledChangeOrderIds={addedChangeOrderIds}
      />
    </>
  );
}
