import {
  editPurchaseOrderDetails,
  getAllPurchaseOrderDetails,
} from "@/src/apis/companySettingsApis";
import CreatedByUserBadge from "@/src/components/common/CreatedByUserBadge";
import CustomAlert from "@/src/components/common/CustomAlert";
import CustomFileUploadRHF from "@/src/components/common/CustomFileUploadRHF";
import { useAppSelector } from "@/src/hooks/useAppSelector";
import { getCompanyState } from "@/src/store/slices/companySettingsSlice";
import { getUserFullName } from "@/src/store/slices/userSlice";
import { ActionTypeEnum, FilesDocumentTypeEnum } from "@/src/utils/enums";
import { PurchaseOrderSettings } from "@/src/utils/types";
import CustomFormLabel from "@components/common/CustomFormLabel";
import CustomIcon from "@components/common/CustomIcon";
import SectionLayout from "@components/layout/SectionLayout";
import { yupResolver } from "@hookform/resolvers/yup";
import { useAppDispatch } from "@hooks/useAppDispatch";
import { getConsistentSpacing } from "@utils/theme-helpers";
import {
  Button,
  Col,
  Divider,
  Flex,
  Form,
  InputNumber,
  Row,
  Select,
  Typography,
  UploadFile,
} from "antd";
import { useEffect, useState } from "react";
import { Controller, Resolver, useForm } from "react-hook-form";
import { useNavigate } from "react-router-dom";
import * as Yup from "yup";
import MessageEditor from "@/src/features/re-oders/components/MessageEditorComponent";
import {
  convertToLocaleString,
  filterFileDocumentsByType,
  getHtmlFromXMLPara,
} from "@/src/utils/helper";
import JSZip from "jszip";

type PurchaseOrderDetailsFormProps = {
  purchaseOrder?: PurchaseOrderSettings | null;
  superApprovers?: { label: string; value: string }[];
  nonSuperApprovers?: { label: string; value: string }[];
};

export default function PurchaseOrderDetailsForm({
  purchaseOrder,
  superApprovers,
  nonSuperApprovers,
}: PurchaseOrderDetailsFormProps) {
  const navigate = useNavigate();
  const [showButtonLoading, setShowButtonLoading] =
    useState<ActionTypeEnum | null>(null);
  const userFullName = useAppSelector(getUserFullName);
  const dispatch = useAppDispatch();
  const [hasMadeApiCall, setHasMadeApiCall] = useState(false);
  const { successMessage, resError } = useAppSelector(getCompanyState);
  const [validationError, setValidationError] = useState("");

  type FieldType = Omit<
    PurchaseOrderSettings,
    "superApprovers" | "limitOneApprovers" | "limitTwoApprovers"
  > & {
    superApproverIds: string[];
    limitOneApproverIds: string[];
    limitTwoApproverIds: string[];
  };

  const validationSchema = Yup.object();
  //   .shape(
  //     {
  //     limitTwoFrom: Yup.string().test(
  //       "is-less-than-or-equal-to",
  //       "Starting Limit cannot be greater than Ending Limit.",
  //       function (value) {
  //         const { limitTwoTo } = this.parent;
  //         return (
  //           !value || !limitTwoTo || parseFloat(value) <= parseFloat(limitTwoTo)
  //         );
  //       }
  //     ),
  //     limitTwoTo: Yup.string().test(
  //       "is-greater-than-or-equal-to",
  //       "Limit Ending cannot be less than Limit Starting.",
  //       function (value) {
  //         const { limitTwoFrom } = this.parent;
  //         return (
  //           !value ||
  //           !limitTwoFrom ||
  //           parseFloat(value) >= parseFloat(limitTwoFrom)
  //         );
  //       }
  //     ),
  //   }
  // );

  const {
    control,
    handleSubmit,
    reset,
    setValue,
    getValues,
    formState: { errors },
  } = useForm<FieldType>({
    defaultValues: {
      limitOne: purchaseOrder?.limitOne || "",
      limitTwoFrom: purchaseOrder?.limitTwoFrom || "",
      limitTwoTo: purchaseOrder?.limitTwoTo || "",
      superApproverIds: purchaseOrder?.superApprovers?.map((m) => m.id) || [],
      limitOneApproverIds:
        purchaseOrder?.limitOneApprovers?.map((m) => m.id) || [],
      limitTwoApproverIds:
        purchaseOrder?.limitTwoApprovers?.map((m) => m.id) || [],
      termsAndConditions: purchaseOrder?.termsAndConditions || "",
      termsAndConditionsDocument: filterFileDocumentsByType(
        [],
        FilesDocumentTypeEnum.REQUESTQUOTE
      ),
    },
    resolver: yupResolver(validationSchema) as Resolver<FieldType | any>,
  });

  const onSubmit = async (values: FieldType) => {
    setHasMadeApiCall(true);
    const {
      limitOne,
      limitTwoFrom,
      limitTwoTo,
      termsAndConditions,
      superApproverIds,
      limitOneApproverIds,
      limitTwoApproverIds,
    } = values;
    try {
      if (purchaseOrder) {
        await dispatch(
          editPurchaseOrderDetails({
            limitOne,
            limitTwoFrom,
            limitTwoTo,
            termsAndConditions,
            superApproverIds,
            limitOneApproverIds,
            limitTwoApproverIds,
            createdBy: userFullName,
          })
        );
      } else {
        return;
      }
    } catch (err) {
      console.log(err);
    } finally {
      setShowButtonLoading(null);
    }
  };

  useEffect(() => {
    if (!purchaseOrder) {
      return;
    }

    reset({
      ...purchaseOrder,
      superApproverIds: purchaseOrder?.superApprovers?.map((m) => m.id) || [],
      limitOneApproverIds:
        purchaseOrder?.limitOneApprovers?.map((m) => m.id) || [],
      limitTwoApproverIds:
        purchaseOrder?.limitTwoApprovers?.map((m) => m.id) || [],
      termsAndConditions: purchaseOrder?.termsAndConditions,
    });
  }, [purchaseOrder]);

  useEffect(() => {
    if (Object.keys(errors)?.length > 0) {
      setShowButtonLoading(null);
    }
  }, [errors]);

  const handleSave = () => {
    handleSubmit(onSubmit)();
    setShowButtonLoading(ActionTypeEnum.SAVE);
  };

  // const handleFileChange = (fileList: UploadFile[]) => {
  //   const isAllTxtFiles = fileList.every(
  //     (file) => file?.type === "text/plain" || file?.name.endsWith(".txt")
  //   );

  //   if (!isAllTxtFiles) {
  //     setValidationError("Only .txt files are allowed!");
  //     return;
  //   } else {
  //     setValidationError("");
  //   }

  //   const file = fileList[0]?.originFileObj as File;
  //   if (!(file instanceof File)) {
  //     setValue("termsAndConditionsDocument", []);
  //     return;
  //   }

  //   const reader = new FileReader();
  //   reader.onload = (e) => {
  //     const result = e.target?.result;
  //     if (result && typeof result === "string") {
  //       setValue("termsAndConditions", result);
  //     } else {
  //       setValue("termsAndConditionsDocument", []);
  //       setValidationError("This File do not contain text!");
  //     }
  //   };

  //   reader.readAsText(file);
  //   setValue("termsAndConditionsDocument", fileList as any);
  // };

  const handleFileChange = (fileList: UploadFile[]) => {
    const isAllDocxTxtFiles = fileList.every(
      (file) =>
        file?.type === "text/plain" ||
        file?.name.endsWith(".txt") ||
        file?.name.endsWith(".docx") ||
        file?.name.endsWith(".doc")
    );

    if (!isAllDocxTxtFiles) {
      setValidationError("Only .doc,.docx and .txt files are allowed!");
      return;
    } else {
      setValidationError("");
    }

    const file = fileList[0]?.originFileObj as File;
    if (!(file instanceof File)) {
      setValue("termsAndConditionsDocument", []);
      return;
    }

    const reader = new FileReader();

    if (file.name.endsWith(".docx") || file.name.endsWith(".doc")) {
      reader.onload = async (e) => {
        try {
          const result = e.target?.result;
          if (result instanceof ArrayBuffer) {
            const zip = await JSZip.loadAsync(result);
            const documentXml = await zip
              .file("word/document.xml")
              ?.async("text");

            if (documentXml) {
              const parser = new DOMParser();
              const xmlDoc = parser.parseFromString(documentXml, "text/xml");
              const paragraphs = xmlDoc.getElementsByTagName("w:p");
              setValue("termsAndConditions", getHtmlFromXMLPara(paragraphs));
              setValue("termsAndConditionsDocument", []);
            } else {
              setValidationError(
                "This .docx file does not contain valid text!"
              );
              setValue("termsAndConditionsDocument", []);
            }
          }
        } catch (error) {
          console.error("Error processing .docx file:", error);
          setValidationError("Error reading .docx file!");
        }
      };
      reader.readAsArrayBuffer(file);
    } else if (file.name.endsWith(".txt")) {
      reader.onload = (e) => {
        const text = e.target?.result;
        if (typeof text === "string" && text.trim() !== "") {
          setValue("termsAndConditions", text);
          setValue("termsAndConditionsDocument", []);
        } else {
          setValidationError("This .txt file does not contain valid text!");
          setValue("termsAndConditionsDocument", []);
        }
      };
      reader.readAsText(file);
    }

    setValue("termsAndConditionsDocument", fileList as any);
  };

  const handleMessageChange = (value: string) => {
    setValue("termsAndConditions", value);
  };

  useEffect(() => {
    dispatch(getAllPurchaseOrderDetails());
  }, []);

  return (
    <>
      <SectionLayout>
        <Form layout="vertical" autoComplete="off">
          <Row gutter={parseInt(getConsistentSpacing(2))}>
            <Col xs={24} style={{ marginBottom: getConsistentSpacing(2) }}>
              <Typography.Title level={5}>
                Purchase Order Limits
              </Typography.Title>
            </Col>

            {/* Limit 01 */}
            <Col xs={24}>
              <Controller
                name="limitOne"
                control={control}
                render={({ field, fieldState }) => (
                  <Form.Item
                    label={<CustomFormLabel text="Limit 01" />}
                    labelAlign="right"
                    validateStatus={fieldState.error ? "error" : ""}
                    help={fieldState.error?.message || ""}
                  >
                    <InputNumber<string>
                      value={field.value || ""}
                      onChange={(value) =>
                        field.onChange(parseFloat(value || "").toString())
                      }
                      size="large"
                      style={{ width: "100%" }}
                      min="0"
                      stringMode
                      placeholder="$"
                      formatter={(value) => `$ ${convertToLocaleString(value)}`}
                      parser={(value) =>
                        value?.replace(/\$\s?|(,*)/g, "") || ""
                      }
                    />
                  </Form.Item>
                )}
              />
            </Col>

            {/* Limit 02 From */}
            {/* <Col xs={11}>
              <Controller
                name="limitTwoFrom"
                control={control}
                render={({ field, fieldState }) => (
                  <Form.Item
                    label={<CustomFormLabel text="Limit 02" />}
                    labelAlign="right"
                    validateStatus={fieldState.error ? "error" : ""}
                    help={fieldState.error?.message || ""}
                  >
                    <InputNumber<string>
                      value={field.value || ""}
                      onChange={(value) =>
                        field.onChange(parseFloat(value || "").toString())
                      }
                      size="large"
                      style={{ width: "100%" }}
                      min="0"
                      stringMode
                      placeholder="$ Limit02 Start"
                      formatter={(value) =>
                        `$ ${value}`.replace(/\B(?=(\d{3})+(?!\d))/g, ",")
                      }
                      parser={(value) =>
                        value?.replace(/\$\s?|(,*)/g, "") || ""
                      }
                    />
                  </Form.Item>
                )}
              />
            </Col>

            <Col xs={2} className="flex items-center justify-center mt-3">
              <span>-</span>
            </Col> */}

            {/* Limit 02 To  */}
            <Col xs={24}>
              <Controller
                name="limitTwoTo"
                control={control}
                render={({ field, fieldState }) => (
                  <Form.Item
                    label={<CustomFormLabel text="Limit 02" />}
                    labelAlign="right"
                    validateStatus={fieldState.error ? "error" : ""}
                    help={fieldState.error?.message || ""}
                  >
                    <InputNumber<string>
                      value={field.value || ""}
                      onChange={(value) =>
                        field.onChange(parseFloat(value || "").toString())
                      }
                      size="large"
                      style={{ width: "100%" }}
                      min="0"
                      stringMode
                      placeholder="$"
                      formatter={(value) => `$ ${convertToLocaleString(value)}`}
                      parser={(value) =>
                        value?.replace(/\$\s?|(,*)/g, "") || ""
                      }
                    />
                  </Form.Item>
                )}
              />
            </Col>
          </Row>

          <Divider />

          {/* Authorized Approvers */}
          <Row gutter={parseInt(getConsistentSpacing(2))}>
            <Col xs={24} style={{ marginBottom: getConsistentSpacing(2) }}>
              <Typography.Title level={5}>
                Authorized Approvers
              </Typography.Title>
            </Col>

            {/* Limit 01 Approvers */}
            <Col xs={24}>
              <Controller
                name="limitOneApproverIds"
                control={control}
                render={({ field, fieldState }) => (
                  <Form.Item
                    label={<CustomFormLabel text="Limit 01 Approvers" />}
                    labelAlign="right"
                    tooltip="Limit 01 Approvers can approve purchase orders (POs) up to the limit specified in Limit 01."
                    validateStatus={fieldState.error ? "error" : ""}
                    help={fieldState.error?.message || ""}
                  >
                    <Select
                      value={field.value || []}
                      onChange={(value) => field.onChange(value || "")}
                      size="large"
                      placeholder="Select Limit 01 Approvers"
                      options={nonSuperApprovers}
                      showSearch
                      mode="multiple"
                      filterOption={(input, option) =>
                        (option?.label || "")
                          .toLowerCase()
                          .includes(input.toLowerCase())
                      }
                    />
                  </Form.Item>
                )}
              />
            </Col>

            {/* Limit 02 Approvers */}
            <Col xs={24}>
              <Controller
                name="limitTwoApproverIds"
                control={control}
                render={({ field, fieldState }) => (
                  <Form.Item
                    label={<CustomFormLabel text="Limit 02 Approvers" />}
                    labelAlign="right"
                    tooltip="Limit 02 Approvers can approve purchase orders (POs) within the range specified in Limit 02."
                    validateStatus={fieldState.error ? "error" : ""}
                    help={fieldState.error?.message || ""}
                  >
                    <Select
                      value={field.value || []}
                      onChange={(value) => field.onChange(value || "")}
                      size="large"
                      placeholder="Select Limit 02 Approvers"
                      options={nonSuperApprovers}
                      showSearch
                      mode="multiple"
                      filterOption={(input, option) =>
                        (option?.label || "")
                          .toLowerCase()
                          .includes(input.toLowerCase())
                      }
                    />
                  </Form.Item>
                )}
              />
            </Col>

            {/* Super Approvers */}
            <Col xs={24}>
              <Controller
                name="superApproverIds"
                control={control}
                render={({ field, fieldState }) => (
                  <Form.Item
                    label={<CustomFormLabel text="Super Approvers" />}
                    labelAlign="right"
                    tooltip="Super Approvers can approve purchase orders (POs) of all costs."
                    validateStatus={fieldState.error ? "error" : ""}
                    help={fieldState.error?.message || ""}
                  >
                    <Select
                      value={field.value || []}
                      onChange={(value) => field.onChange(value || "")}
                      size="large"
                      placeholder="Select Super Approvers"
                      options={superApprovers}
                      showSearch
                      mode="multiple"
                      filterOption={(input, option) =>
                        (option?.label || "")
                          .toLowerCase()
                          .includes(input.toLowerCase())
                      }
                    />
                  </Form.Item>
                )}
              />
            </Col>
          </Row>

          <Divider />

          <Typography.Title level={5}>Terms & Conditions</Typography.Title>
          <Flex className="mt-6" justify="space-between" align="end">
            <Typography.Text className="font-medium">
              Purchase Order Terms & Conditions
            </Typography.Text>
            <Controller
              control={control}
              name="termsAndConditionsDocument"
              render={({ field }) => (
                <Form.Item<FieldType>
                  labelAlign="right"
                  style={{ marginBottom: 0 }}
                  initialValue={field.value}
                >
                  <CustomFileUploadRHF
                    hasOnlyText
                    setValue={setValue}
                    getValues={getValues}
                    fieldName={field.name}
                    buttonText="Upload Document"
                    buttonIcon={<CustomIcon type="cloud-upload" />}
                    buttonClassName="hover:!fill-primaryHover"
                    onFileChange={handleFileChange}
                    maxCount={1}
                  />
                </Form.Item>
              )}
            />
          </Flex>
          <Flex className="mt-3 border-none">
            <Controller
              control={control}
              name="termsAndConditions"
              render={({ field }) => (
                <Form.Item<FieldType>
                  labelAlign="right"
                  className="w-full"
                  initialValue={field.value}
                >
                  <MessageEditor
                    value={getValues("termsAndConditions") as string}
                    onChange={handleMessageChange}
                  />
                </Form.Item>
              )}
            />
          </Flex>

          {(validationError ||
            (hasMadeApiCall && (resError || successMessage))) && (
            <CustomAlert
              message={validationError || resError || successMessage || ""}
              type={
                successMessage ? "success" : validationError ? "error" : "error"
              }
            />
          )}

          <Flex className="justify-end gap-4 mb-6">
            <Button
              disabled={showButtonLoading != null}
              onClick={() => navigate(-1)}
            >
              Cancel
            </Button>

            <Button
              loading={showButtonLoading == ActionTypeEnum.SAVE}
              disabled={
                showButtonLoading !== ActionTypeEnum.SAVE &&
                showButtonLoading != null
              }
              type="primary"
              onClick={handleSave}
            >
              {showButtonLoading == ActionTypeEnum.SAVE ? "Saving.." : "Save"}
            </Button>
          </Flex>

          {purchaseOrder && (
            <Flex justify="flex-end">
              <CreatedByUserBadge
                userName={purchaseOrder?.modifiedBy}
                date={purchaseOrder?.modifiedDate}
                isModifiedBadge
              />
            </Flex>
          )}
        </Form>
      </SectionLayout>
    </>
  );
}
