import { Button, Col, Flex, Form, Input, Row, Select, Typography } from "antd";
import { Controller, Resolver, useForm } from "react-hook-form";
import * as Yup from "yup";

import {
  editCompanyDetails,
  getAllCompanyDetails,
} from "@/src/apis/companySettingsApis";
import CustomAlert from "@/src/components/common/CustomAlert";
import CustomAvatarUpload from "@/src/components/common/CustomAvatarUpload";
import ModifiedByUserBadgeV2 from "@/src/components/common/ModifiedByUserBadgeV2";
import { useAppSelector } from "@/src/hooks/useAppSelector";
import {
  getCompanyData,
  getCompanyState,
} from "@/src/store/slices/companySettingsSlice";
import { ActionTypeEnum } from "@/src/utils/enums";
import { CompanySettings } from "@/src/utils/types";
import CustomFormLabel from "@components/common/CustomFormLabel";
import SectionLayout from "@components/layout/SectionLayout";
import { yupResolver } from "@hookform/resolvers/yup";
import { useAppDispatch } from "@hooks/useAppDispatch";
import { phoneNumberLengthRegex, statesList } from "@utils/constants";
import { getConsistentSpacing } from "@utils/theme-helpers";
import { useEffect, useRef, useState } from "react";
import PhoneInput from "react-phone-input-2";
import "react-phone-input-2/lib/style.css";
import { useNavigate } from "react-router-dom";

type CompanyDetailsFormProps = {
  company?: CompanySettings | null;
};

export default function CompanyDetailsForm({}: // company,
CompanyDetailsFormProps) {
  const navigate = useNavigate();
  const company = useAppSelector(getCompanyData);
  const [showButtonLoading, setShowButtonLoading] = useState<
    ActionTypeEnum | boolean
  >(false);
  const { successMessage, resError } = useAppSelector(getCompanyState);
  const dispatch = useAppDispatch();
  const phoneInputRef = useRef<HTMLInputElement>(null);
  const faxInputRef = useRef<HTMLInputElement>(null);

  const [hasMadeApiCall, setHasMadeApiCall] = useState(false);
  const [formattedPhoneNumber, setFormattedPhoneNumber] = useState("");

  type FieldType = CompanySettings;

  const validationSchema = Yup.object().shape({
    name: Yup.string().required("Company Name is required."),
    // logoData: Yup.string(),
    email: Yup.string()
      .email("Invalid email format.")
      .matches(
        /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/,
        "Invalid email format. Must include a domain at the end."
      ),
    // logoData: Yup.string().test()

    zip: Yup.string()?.trim()
      .test(
        "len",
        "Invalid Zip Code. Please enter in the format: 12345 or 12345-6789",
        (val) => !val || val.length === 5 || val.length === 10
      ),
    phoneNumber: Yup.string()?.optional()?.trim()
      .matches(phoneNumberLengthRegex, {
        message: "Phone Number is not valid in the US",
        excludeEmptyString: true,
      }),
    fax: Yup.string().optional().trim().matches(phoneNumberLengthRegex, {
      message: "Fax Number is not valid in the US",
      excludeEmptyString: true,
    }),
  });

  const {
    control,
    handleSubmit,
    reset,
    formState: { errors, isSubmitting },
    register,
    getValues,
  } = useForm<FieldType>({
    defaultValues: {
      // Info
      logo: company?.logo || null,
      name: company?.name || "",
      phoneNumber: company?.phoneNumber || "",
      email: company?.email || "",

      // Address Info
      address: company?.address || "",
      city: company?.city || "",
      state: company?.state || null,
      zip: company?.zip || "",
      fax: company?.fax || "",
      shouldDeleteLogo: false,
    },
    resolver: yupResolver(validationSchema) as Resolver<FieldType | any>,
  });

  const onSubmit = async (values: FieldType) => {
    setHasMadeApiCall(true);

    const formData = new FormData();
    formData.append("name", values?.name);
    formData.append("address", values?.address);
    formData.append("city", values?.city);
    formData.append("state", values?.state || "");
    formData.append("zip", values?.zip);
    formData.append("phoneNumber", values?.phoneNumber);
    formData.append("email", values?.email);
    formData.append("fax", values?.fax);
    if (!values.logo) {
      formData.append("shouldDeleteLogo", true as any);
    }
    if (values.logo !== null && values.logo !== undefined) {
      formData.append("logo", values?.logo as any);
    }

    try {
      if (company) {
        await dispatch(editCompanyDetails({ payload: formData }));
      } else {
        return;
      }
    } catch (err) {
      console.log(err);
    } finally {
      setShowButtonLoading(false);
    }
  };

  useEffect(() => {
    if (!company) {
      return;
    }
    reset(company);
    setFormattedPhoneNumber(company.phoneNumber || "");
  }, [company]);

  useEffect(() => {
    if (Object.keys(errors)?.length > 0) {
      setShowButtonLoading(false);
    }
  }, [errors]);

  const handleSave = () => {
    handleSubmit(onSubmit)();
    setShowButtonLoading(ActionTypeEnum.SAVE);
  };

  useEffect(() => {
    dispatch(getAllCompanyDetails());
  }, []);

  useEffect(() => {
    const timeoutId = setTimeout(() => {
      if (phoneInputRef?.current && faxInputRef.current && company?.name) {
        phoneInputRef?.current.focus();
        faxInputRef?.current.focus();
        const clickEvent = new MouseEvent("click", {
          bubbles: true,
          cancelable: true,
          view: window,
        });

        phoneInputRef?.current?.dispatchEvent(clickEvent);
        phoneInputRef?.current?.dispatchEvent(clickEvent);
        faxInputRef?.current?.dispatchEvent(clickEvent);
      }
    }, 600);

    return () => clearTimeout(timeoutId);
  }, [phoneInputRef, isSubmitting, faxInputRef]);
  return (
    <>
      <SectionLayout>
        <Form
          // onFinish={handleSubmit(onSubmit)}
          layout="vertical"
          autoComplete="off"
        >
          <Row gutter={parseInt(getConsistentSpacing(2))}>
            <Col xs={24} style={{ marginBottom: getConsistentSpacing(2) }}>
              <Typography.Title level={5}>Company Information</Typography.Title>
            </Col>

            <Col xs={24} className="mb-1">
              {/* Company Name */}
              <Controller
                name="logo"
                control={control}
                render={({ field, fieldState }) => (
                  <Form.Item
                    label={<CustomFormLabel text={getValues("name")} />}
                    labelAlign="right"
                    validateStatus={fieldState.error ? "error" : ""}
                    help={fieldState.error ? fieldState.error.message : ""}
                  >
                    <CustomAvatarUpload
                      value={field.value}
                      onChange={field.onChange}
                      error={fieldState.error}
                    />
                  </Form.Item>
                )}
              />

              <Typography.Title level={5} className="mt-2"></Typography.Title>
            </Col>
            <Col xs={24}>
              {/* Company Name */}
              <Controller
                name="name"
                control={control}
                render={({ field, fieldState }) => (
                  <Form.Item<FieldType>
                    validateStatus={fieldState.error ? "error" : ""}
                    help={fieldState.error ? fieldState.error.message : ""}
                  >
                    <CustomFormLabel text="Company Name" required />
                    <Input
                      value={field.value || ""}
                      onChange={(event) => field.onChange(event.target.value)}
                      size="large"
                      placeholder="Company Name"
                      className="mt-3"
                    />
                  </Form.Item>
                )}
              />
            </Col>

            <Col xs={12}>
              {/* Street Address */}
              <Controller
                name="address"
                control={control}
                render={({ field, fieldState }) => (
                  <Form.Item<FieldType>
                    label={<CustomFormLabel text="Street Address" />}
                    labelAlign="right"
                    validateStatus={fieldState.error ? "error" : ""}
                    help={fieldState.error ? fieldState.error.message : ""}
                  >
                    <Input
                      value={field.value || ""}
                      onChange={(event) => field.onChange(event.target.value)}
                      size="large"
                      placeholder="Street Address"
                    />
                  </Form.Item>
                )}
              />
            </Col>

            <Col xs={12}>
              {/* City */}
              <Controller
                name="city"
                control={control}
                render={({ field, fieldState }) => (
                  <Form.Item<FieldType>
                    label={<CustomFormLabel text="City" />}
                    labelAlign="right"
                    validateStatus={fieldState.error ? "error" : ""}
                    help={fieldState.error ? fieldState.error.message : ""}
                  >
                    <Input
                      value={field.value || ""}
                      onChange={(event) => field.onChange(event.target.value)}
                      size="large"
                      placeholder="City"
                    />
                  </Form.Item>
                )}
              />
            </Col>

            <Col xs={12}>
              {/* State */}
              <Controller
                name="state"
                control={control}
                render={({ field, fieldState }) => (
                  <Form.Item<FieldType>
                    label={<CustomFormLabel text="State" />}
                    labelAlign="right"
                    validateStatus={fieldState.error ? "error" : ""}
                    help={fieldState.error ? fieldState.error.message : ""}
                  >
                    <Select
                      value={field.value}
                      onChange={(value) => field.onChange(value)}
                      size="large"
                      options={statesList?.map((state) => ({
                        label: state,
                        value: state,
                      }))}
                      placeholder="Select State"
                      showSearch
                    />
                  </Form.Item>
                )}
              />
            </Col>

            <Col xs={12}>
              {/* Zip Code */}
              <Controller
                name="zip"
                control={control}
                render={({ field, fieldState }) => (
                  <Form.Item<FieldType>
                    label={<CustomFormLabel text="Zip Code" />}
                    labelAlign="right"
                    validateStatus={fieldState.error ? "error" : ""}
                    help={fieldState.error ? fieldState.error.message : ""}
                  >
                    <Input
                      value={field.value || ""}
                      onChange={(event) => field.onChange(event.target.value)}
                      size="large"
                      placeholder="Zip Code"
                    />
                  </Form.Item>
                )}
              />
            </Col>

            {/* Phone */}
            <Col xs={12}>
              <Form.Item<FieldType>
                label={<CustomFormLabel text="Phone" />}
                labelAlign="right"
                validateStatus={errors.phoneNumber ? "error" : ""}
                help={errors.phoneNumber ? errors.phoneNumber.message : ""}
              >
                <Controller
                  name="phoneNumber"
                  control={control}
                  render={({ field }) => (
                    <div ref={register("phoneNumber")?.ref}>
                      <PhoneInput
                        {...field}
                        containerClass="phoneNumberInput"
                        country={"us"}
                        preferredCountries={["us"]}
                        value={formattedPhoneNumber || field.value}
                        onChange={(phoneNumber) => {
                          field.onChange(phoneNumber);
                          // setFormattedPhoneNumber(phoneNumber);
                        }}
                        inputProps={{
                          id: "phoneNumbers",
                          ref: phoneInputRef,
                        }}
                      />
                    </div>
                  )}
                />
              </Form.Item>
            </Col>

            <Col xs={12}>
              {/* Email */}
              <Controller
                name="email"
                control={control}
                render={({ field, fieldState }) => (
                  <Form.Item<FieldType>
                    label={<CustomFormLabel text="Email" />}
                    labelAlign="right"
                    validateStatus={fieldState.error ? "error" : ""}
                    help={fieldState.error ? fieldState.error.message : ""}
                  >
                    <Input
                      value={field.value || ""}
                      onChange={(event) => field.onChange(event.target.value)}
                      size="large"
                      placeholder="Email"
                    />
                  </Form.Item>
                )}
              />
            </Col>

            <Col xs={12}>
              {/* Fax */}
              {/* <Controller
                name="fax"
                control={control}
                render={({ field, fieldState }) => (
                  <Form.Item<FieldType>
                    label={<CustomFormLabel text="Fax" />}
                    labelAlign="right"
                    validateStatus={fieldState.error ? "error" : ""}
                    help={fieldState.error ? fieldState.error.message : ""}
                  >
                    <Input
                      {...field}
                      value={field.value || ""}
                      onChange={(event) => field.onChange(event.target.value)}
                      size="large"
                      placeholder="Fax Number"
                    />
                  </Form.Item>
                )}
              /> */}
              <Controller
                name="fax"
                control={control}
                render={({ field, fieldState }) => (
                  <Form.Item<FieldType>
                    label={<CustomFormLabel text="Fax" />}
                    labelAlign="right"
                    validateStatus={fieldState.error ? "error" : ""}
                    help={fieldState.error ? fieldState.error.message : ""}
                  >
                    {/* <Input
                      {...field}
                      value={field.value || ""}
                      onChange={(event) => field.onChange(event.target.value)}
                      size="large"
                      placeholder="Fax Number"
                    /> */}

                    <div ref={register("fax")?.ref}>
                      <PhoneInput
                        {...field}
                        containerClass="phoneNumberInput"
                        country={"us"}
                        preferredCountries={["us"]}
                        value={field.value}
                        onChange={(phoneNumber) => {
                          field.onChange(phoneNumber);
                        }}
                        inputProps={{
                          id: "fax",
                          ref: faxInputRef,
                        }}
                      />
                    </div>
                  </Form.Item>
                )}
              />
            </Col>
          </Row>
          {hasMadeApiCall && (resError || successMessage) && (
            <CustomAlert
              message={resError || successMessage || ""}
              type={successMessage ? "success" : "error"}
            />
          )}

          <Flex className="justify-end gap-4 mb-6">
            <Button
              disabled={showButtonLoading != false}
              onClick={() => navigate(-1)}
            >
              Cancel
            </Button>

            <Button
              loading={showButtonLoading == ActionTypeEnum.SAVE}
              disabled={
                showButtonLoading !== ActionTypeEnum.SAVE &&
                showButtonLoading != false
              }
              type="primary"
              onClick={handleSave}
            >
              {showButtonLoading == ActionTypeEnum.SAVE ? "Saving.." : "Save"}
            </Button>
          </Flex>
          {company && (
            <Flex justify="flex-end">
              <ModifiedByUserBadgeV2<CompanySettings> data={company} />
            </Flex>
          )}
        </Form>
      </SectionLayout>
    </>
  );
}
