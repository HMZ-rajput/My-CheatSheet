import { Button, Col, Flex, Form, InputNumber, Row, Typography } from "antd";

import {
  editReorderDetails,
  getAllReorderDetails,
} from "@/src/apis/companySettingsApis";
import CreatedByUserBadge from "@/src/components/common/CreatedByUserBadge";
import CustomAlert from "@/src/components/common/CustomAlert";
import { useAppSelector } from "@/src/hooks/useAppSelector";
import { getCompanyState } from "@/src/store/slices/companySettingsSlice";
import { getUserFullName } from "@/src/store/slices/userSlice";
import { ActionTypeEnum } from "@/src/utils/enums";
import { ReorderSettings } from "@/src/utils/types";
import { PercentageOutlined } from "@ant-design/icons";
import CustomFormLabel from "@components/common/CustomFormLabel";
import SectionLayout from "@components/layout/SectionLayout";
import { useAppDispatch } from "@hooks/useAppDispatch";
import { getConsistentSpacing } from "@utils/theme-helpers";
import { useEffect, useState } from "react";
import { Controller, useForm } from "react-hook-form";
import "react-phone-input-2/lib/style.css";
import { useNavigate } from "react-router-dom";

type ReorderDetailsFormProps = {
  reorder?: ReorderSettings | null;
};

export default function ReorderDetailsForm({
  reorder,
}: ReorderDetailsFormProps) {
  const navigate = useNavigate();
  const [showButtonLoading, setShowButtonLoading] =
    useState<ActionTypeEnum | null>(null);
  const userFullName = useAppSelector(getUserFullName);
  const dispatch = useAppDispatch();
  const [hasMadeApiCall, setHasMadeApiCall] = useState(false);
  const { successMessage, resError } = useAppSelector(getCompanyState);

  type FieldType = {
    reorderLimit: number;
  };

  const {
    control,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm<FieldType>({
    defaultValues: {
      reorderLimit: reorder?.reorderLimit || 0,
    },
  });

  const onSubmit = async (values: FieldType) => {
    setHasMadeApiCall(true);
    const payload = {
      createdBy: userFullName,
      ...values,
    };
    try {
      if (reorder) {
        await dispatch(editReorderDetails({ ...reorder, ...payload }));
      } else {
        return;
      }
    } catch (err) {
      console.log(err);
    } finally {
      setShowButtonLoading(null);
    }
  };

  useEffect(() => {
    if (!reorder) {
      return;
    }

    reset(reorder);
  }, [reorder]);

  useEffect(() => {
    if (Object.keys(errors)?.length > 0) {
      setShowButtonLoading(null);
    }
  }, [errors]);

  const handleSave = () => {
    handleSubmit(onSubmit)();
    setShowButtonLoading(ActionTypeEnum.SAVE);
  };

  useEffect(() => {
    dispatch(getAllReorderDetails());
  }, []);

  return (
    <>
      <SectionLayout>
        <Form layout="vertical" autoComplete="off">
          <Row gutter={parseInt(getConsistentSpacing(2))}>
            <Col xs={24} style={{ marginBottom: getConsistentSpacing(2) }}>
              <Typography.Title level={5}>Reorder Settings</Typography.Title>
            </Col>

            {/* Reorder Limit */}
            <Col xs={24}>
              <Controller
                name="reorderLimit"
                control={control}
                render={({ field, fieldState }) => (
                  <Form.Item
                    label={<CustomFormLabel text="Reorder Limit" />}
                    labelAlign="right"
                    validateStatus={fieldState.error ? "error" : ""}
                    help={fieldState.error?.message || ""}
                  >
                    <InputNumber<string>
                      addonAfter={<PercentageOutlined />}
                      value={`${field.value || 0}`}
                      onChange={(value) =>
                        field.onChange(parseFloat(value || ""))
                      }
                      size="large"
                      style={{ width: "100%", background: "" }}
                      min="0"
                      max="100"
                      placeholder="Add Reorder Limit (0-100)"
                    />
                  </Form.Item>
                )}
              />
            </Col>
          </Row>

          {hasMadeApiCall && (resError || successMessage) && (
            <CustomAlert
              message={resError || successMessage || ""}
              type={successMessage ? "success" : "error"}
            />
          )}

          <Flex className="justify-end gap-4 mb-6">
            <Button
              disabled={showButtonLoading != null}
              onClick={() => navigate(-1)}
            >
              Cancel
            </Button>

            <Button
              loading={showButtonLoading == ActionTypeEnum.SAVE}
              disabled={
                showButtonLoading !== ActionTypeEnum.SAVE &&
                showButtonLoading != null
              }
              type="primary"
              onClick={handleSave}
            >
              {showButtonLoading == ActionTypeEnum.SAVE ? "Saving.." : "Save"}
            </Button>
          </Flex>
          {reorder && (
            <Flex justify="flex-end">
              <CreatedByUserBadge
                userName={reorder?.modifiedBy}
                date={reorder?.modifiedDate}
                isModifiedBadge
              />
            </Flex>
          )}
        </Form>
      </SectionLayout>
    </>
  );
}
