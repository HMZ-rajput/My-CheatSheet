import { getAllUsersSummaryList } from "@/src/apis/userApis";
import CustomTabs from "@/src/components/common/CustomTabs";
import PageLayout from "@/src/components/layout/PageLayout";
import { useAppDispatch } from "@/src/hooks/useAppDispatch";
import { useAppSelector } from "@/src/hooks/useAppSelector";
import {
  getCompanyData,
  getPurchaseOrderData,
  getReOrderData,
} from "@/src/store/slices/companySettingsSlice";
import { UserRoleEnum } from "@/src/utils/enums";
import routePaths from "@/src/utils/routePaths";
import { Flex } from "antd";
import { useCallback, useEffect, useState } from "react";
import { useLocation } from "react-router-dom";
import CompanyDetailsForm from "../components/CompanyDetailsForm";
import PurchaseOrderDetailsForm from "../components/PurchaseOrderDetailsForm";
import ReorderDetailsForm from "../components/ReorderDetailsForm";

export default function CompanyDetailsPage() {
  // Constants, location, params, etc.
  const location = useLocation();
  const dispatch = useAppDispatch();
  const tabs = {
    companyInformation: "Company Information",
    purchaseOrderSettings: "Purchase Order Settings",
    reorderSettings: "Reorder Settings",
  };

  const [superApprovers, setSuperApprovers] = useState<
    { label: string; value: string }[]
  >([]);
  const [nonSuperApprovers, setNonSuperApprovers] = useState<
    { label: string; value: string }[]
  >([]);
  const getApproversList = useCallback(async () => {
    const response = await dispatch(
      getAllUsersSummaryList({
        roles: [
          UserRoleEnum.Engineer,
          UserRoleEnum.Superintendent,
          UserRoleEnum.Admin,
        ],
      })
    ).unwrap();
    const allApproversList = response?.users || [];

    const superApprovers = allApproversList
      .filter((f) => f.role === UserRoleEnum[UserRoleEnum.Admin])
      .map((approver) => ({
        label: approver.fullName,
        value: approver?.id || "",
      }));

    const nonSuperApprovers = allApproversList
      .filter((f) => f.role !== UserRoleEnum[UserRoleEnum.Admin])
      .map((approver) => ({
        label: approver.fullName,
        value: approver?.id || "",
      }));

    setSuperApprovers(() => superApprovers);
    setNonSuperApprovers(() => nonSuperApprovers);
  }, []);

  useEffect(() => {
    getApproversList();
  }, []);

  // Selectors, memos.
  const company = useAppSelector(getCompanyData);
  const purchaseOrder = useAppSelector(getPurchaseOrderData);
  const reorder = useAppSelector(getReOrderData);

  // States
  const [selectedTab, setSelectedTab] = useState(tabs.companyInformation);

  // Functions
  function renderRenderTabPanels() {
    switch (selectedTab) {
      default:
        return <CompanyDetailsForm company={company} />;
      case tabs.purchaseOrderSettings:
        return (
          <PurchaseOrderDetailsForm
            purchaseOrder={purchaseOrder}
            superApprovers={superApprovers}
            nonSuperApprovers={nonSuperApprovers}
          />
        );
      case tabs.reorderSettings:
        return <ReorderDetailsForm reorder={reorder} />;
    }
  }

  // Effects
  useEffect(() => {
    if (
      location.pathname === routePaths.COMPANY_SETTINGS &&
      selectedTab !== tabs.companyInformation
    ) {
      setSelectedTab(tabs.companyInformation);
    }
  }, [location]);

  // Stateless Components

  return (
    <>
      <PageLayout
        title="Company Settings"
        // titleSibling={
        //   <CustomTag status={project?.status || ProjectStatusEnum.OPEN} />
        // }
        titleBarJustifyContent="flex-start"
      >
        <Flex className="mb-7">
          <CustomTabs
            options={Object.entries(tabs)?.map(([key, value]) => ({
              value: key,
              label: value,
              //   disabled: !projectId ? value !== tabs.companyInformation : false,
            }))}
            tabLabel={selectedTab}
            onChange={(tab) => setSelectedTab(tab)}
          />
        </Flex>

        {renderRenderTabPanels()}
      </PageLayout>
    </>
  );
}
