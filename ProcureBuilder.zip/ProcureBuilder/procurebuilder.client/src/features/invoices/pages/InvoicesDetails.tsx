import { useAppSelector } from "@/src/hooks/useAppSelector";
import { getInvoicesById } from "@/src/store/slices/invoicesSlice";
import PageLayout from "@components/layout/PageLayout";
import { useParams } from "react-router-dom";
import InvoicesDetailsFormRHF from "../components/InvoicesDetailsFormRHF";
import { getAllInvoicesById } from "@/src/apis/invoicesApis";
import { useEffect, useState } from "react";
import { useAppDispatch } from "@/src/hooks/useAppDispatch";
import { Invoice } from "@/src/utils/types";

export default function LocationDetailsPage() {
  const { invoiceId } = useParams();
  const dispatch = useAppDispatch();
  const invoicesData = useAppSelector((state) =>
    getInvoicesById(state, invoiceId || "")
  );
  const [invoice, setInvoice] = useState<Invoice>();

  useEffect(() => {
    if (invoiceId) {
      const fetchInvoiceById = async () => {
        const response = await dispatch(
          getAllInvoicesById({ invoiceId })
        ).unwrap();
        setInvoice(response?.invoice);
      };
      fetchInvoiceById();
    }
  }, [invoiceId, dispatch]);
  return (
    <>
      <PageLayout
        title={`${
          invoicesData?.id || invoiceId ? "Edit" : "Create New"
        } Invoice`}
        titleBarJustifyContent="flex-start"
        // titleSibling={<InvoicesStatus badgeType={badgeType} />}
      >
        {/* <InvoicesDetailsForm invoices={invoicesData} /> */}
        <InvoicesDetailsFormRHF invoices={invoice} />
      </PageLayout>
    </>
  );
}
