import CustomIcon from "@components/common/CustomIcon";
import PageLayout from "@components/layout/PageLayout";
import { getConsistentSpacing } from "@utils/theme-helpers";
import { Button } from "antd";
import InvoicesList from "../components/InvoicesList";
import routePaths from "@/src/utils/routePaths";
import { useNavigate } from "react-router-dom";
export default function InvoicesPage() {
  const navigate = useNavigate();
  return (
    <>
      <PageLayout
        title="Invoices"
        titleSibling={
          <Button
            size="large"
            type="primary"
            icon={
              <CustomIcon
                type="plus"
                className="fill-white"
                width={parseInt(getConsistentSpacing(3))}
                height={parseInt(getConsistentSpacing(3))}
              />
            }
            onClick={() => navigate(routePaths.INVOICES_NEW)}
          >
            New Invoice
          </Button>
        }
      >
        <InvoicesList hasPagination hasDetailedColumns />
      </PageLayout>
    </>
  );
}
