import {
  Button,
  Col,
  DatePicker,
  Divider,
  Flex,
  Form,
  Input,
  InputNumber,
  Select,
  Space,
  Typography,
} from "antd";
import { useEffect, useMemo, useState } from "react";

import {
  createInvoice,
  deleteInvoiceById,
  getMaterialsByPurchaseOrderById,
  updateInvoiceById,
} from "@/src/apis/invoicesApis";
import { getSummarizedProjectsList } from "@/src/apis/projectApis";
import { getPurchaseOrdersList } from "@/src/apis/purchaseOrderApis";
import { getVendorslist } from "@/src/apis/vendorApis";
import CreatedByUserBadge from "@/src/components/common/CreatedByUserBadge";
import CustomAlert from "@/src/components/common/CustomAlert";
import CustomFileUploadRHF from "@/src/components/common/CustomFileUploadRHF";
import CustomIcon from "@/src/components/common/CustomIcon";

import CustomOverlayLoader from "@/src/components/common/CustomOverlayloader";
import CustomFormRow from "@/src/components/form/CustomFormRow";
import { useAppDispatch } from "@/src/hooks/useAppDispatch";
import { getInvoicesState, resetState } from "@/src/store/slices/invoicesSlice";
import { getProjectsState } from "@/src/store/slices/projectsSlice";
import { getUserFullName } from "@/src/store/slices/userSlice";
import { getVendorsState } from "@/src/store/slices/vendorSlice";
import {
  capitalizeFirstLetter,
  convertToLocaleString,
  textSearchFormat,
} from "@/src/utils/helper";
import {
  formatDecimals,
  formatDecimalsOnlyTwo,
} from "@/src/utils/number-extensions";
import routePaths, { routePathsWithParams } from "@/src/utils/routePaths";
import { Invoice, Material, PurchaseOrdersList } from "@/src/utils/types";
import CustomFormLabel from "@components/common/CustomFormLabel";
import SectionLayout from "@components/layout/SectionLayout";
import { yupResolver } from "@hookform/resolvers/yup";
import { useAppSelector } from "@hooks/useAppSelector";
import {
  invoicesStatusOptions,
  isFreight,
  paymentTermOptions,
} from "@utils/constants";
import dayjs from "dayjs";
import { Controller, Resolver, useForm } from "react-hook-form";
import { useLocation, useNavigate, useParams } from "react-router-dom";
import { getInvoiceInitialValues } from "./InvoiceConstant";
import InvoicesMaterials from "./InvoicesMaterials";
import { validationSchema } from "./InvoiceValidationSchema";

type InvoicesDetailsFormProps = {
  invoices?: Invoice | null;
};

export default function InvoicesDetailsFormRHF({
  invoices,
}: InvoicesDetailsFormProps) {
  const userFullName = useAppSelector(getUserFullName);
  const dispatch = useAppDispatch();
  const navigate = useNavigate();

  const location = useLocation();
  const { invoiceId } = useParams();

  const [isLoading, setIsLoading] = useState(true);
  const [fromPOLoading, setFromPOLoading] = useState(false);
  const [purchaseOrdersList, setPurchaseOrdersList] =
    useState<PurchaseOrdersList[]>();

  const { projectsSummarizedData } = useAppSelector(getProjectsState);
  const { vendorsList } = useAppSelector(getVendorsState);
  const [actionType, setActionType] = useState<"save" | "saveAndClose" | "">(
    ""
  );
  const [isDeleting, setIsDeleting] = useState(false);

  const { successMessage, resError, reqError } =
    useAppSelector(getInvoicesState);
  type FieldType = Invoice[];

  const memoizedProjectsOptions = useMemo(() => {
    return [
      {
        value: "",
        label: "Select Project",
      },
      ...(projectsSummarizedData?.map((f) => ({
        value: f?.id,
        label: capitalizeFirstLetter(f?.name || ""),
      })) || []),
    ];
  }, [projectsSummarizedData]);
  const memoizedVendorOptions = useMemo(() => {
    return [
      {
        value: "",
        label: "Select Vendor",
      },
      ...(vendorsList?.map((f) => ({
        value: f?.id,
        label: capitalizeFirstLetter(f?.name || ""),
      })) || []),
    ];
  }, [vendorsList]);
  const memoizedPurchaseOrderOptions = useMemo(() => {
    return [
      {
        value: "",
        label: "Select P.O. Number",
      },
      ...(purchaseOrdersList?.map((f) => ({
        value: f?.id,
        label: capitalizeFirstLetter(f?.purchaseOrderNumber),
      })) || []),
    ];
  }, [purchaseOrdersList]);
  const locationsListOptions = useMemo(() => {
    return [
      {
        value: "",
        label: "Select Locations",
      },
      ...(purchaseOrdersList?.flatMap((location) => ({
        value: location?.deliveryLocation?.id,
        label: capitalizeFirstLetter(location?.deliveryLocation?.name || ""),
      })) || []),
    ];
  }, [purchaseOrdersList]);

  const {
    control,
    handleSubmit,
    setValue,
    getValues,
    reset,
    formState: { isSubmitting },
  } = useForm<Invoice>({
    defaultValues: getInvoiceInitialValues((invoices as Invoice) || null),
    resolver: yupResolver(validationSchema) as unknown as Resolver<Invoice>,
    mode: "onBlur",
  });

  const handleCalculateTax = (value: number) => {
    const taxPercentage = Number(value || 0);
    setValue("taxPercentage", taxPercentage);
    const subTotal = getValues("subTotal") || 0;
    const tax = (subTotal * taxPercentage) / 100;
    setValue("tax", formatDecimals(tax));
  };

  const calculateTotal = (materials: Material[]) => {
    const previousSubTotal = getValues("subTotal") || 0;

    const newMaterialCost = materials?.reduce((acc, material) => {
      return acc + (material?.cost || 0);
    }, 0);

    const updatedSubTotal = previousSubTotal + (newMaterialCost || 0);
    setValue("subTotal", formatDecimals(updatedSubTotal));

    const tax = getValues("tax");

    const total = updatedSubTotal + tax;

    setValue("total", formatDecimals(total));
  };

  const calculateMaterialTotal = (material: Material) => {
    const quantity = Number(material.quantity) || 0;
    const unitRate = Number(material.unitRate) || 0;

    return quantity * unitRate;
  };

  const handleQuantityChange = (index: number) => {
    const newQty = getValues(`materials.${index}.quantity`) || 0;
    const balanceQty = getValues(`materials.${index}.balanceQuantity`) || 0;

    const previousQty =
      getValues(`materials.${index}.previousQuantity`) === undefined
        ? newQty
        : getValues(`materials.${index}.previousQuantity`);

    const qtyDifference = newQty - (previousQty || 0);
    const newBalanceQty = balanceQty - qtyDifference;

    setValue(`materials.${index}.balanceQuantity`, newBalanceQty);

    setValue(`materials.${index}.previousQuantity`, newQty);
  };

  const handleCostChange = (index: number) => {
    const newCost = getValues(`materials.${index}.cost`);
    const remainingBudget =
      getValues(`materials.${index}.remainingBudget`) || 0;

    const previousBudget =
      getValues(`materials.${index}.previousBudget`) === undefined
        ? newCost
        : getValues(`materials.${index}.previousBudget`);
    const qtyDifference = (newCost || 0) - (previousBudget || 0);
    const newBalanceQty = remainingBudget - qtyDifference;

    setValue(`materials.${index}.remainingBudget`, newBalanceQty);
    setValue(`materials.${index}.previousBudget`, newCost);
  };

  const handleUpdateTotals = () => {
    const materials = getValues("materials") || [];

    const calculateSubtotal = (
      acc: number,
      material: Material,
      index: number
    ) => {
      handleQuantityChange(index);

      const nextCost = calculateMaterialTotal(material);
      setValue(`materials.${index}.cost`, nextCost);
      handleCostChange(index);
      return acc + nextCost;
    };

    const previousSubTotal = materials?.reduce(calculateSubtotal, 0);
    setValue("subTotal", formatDecimals(previousSubTotal));

    const taxPercentage = getValues("taxPercentage") || 0;
    const freightAmountTotal = materials?.reduce((acc, material) => {
      if (textSearchFormat(material.name) === isFreight) {
        return acc + Number(material.cost);
      }
      return acc;
    }, 0);

    const subTotalWithoutFreight = previousSubTotal - freightAmountTotal;

    const finalTax = (subTotalWithoutFreight * taxPercentage) / 100;

    const total = previousSubTotal + finalTax;
    setValue("tax", formatDecimals(finalTax));
    setValue("total", formatDecimals(total));
  };

  useEffect(() => {
    function getInvoices() {
      if (!invoices && !location.state) {
        reset({
          ...getInvoiceInitialValues(null),
        });
        return;
      }

      if (invoices || location.state) {
        reset({
          ...getInvoiceInitialValues(invoices || null),
          materials: invoices?.materials || [],
        });
      }
    }
    getInvoices();
  }, [invoices, reset, invoiceId, location.state]);

  const fetchMaterialsByPurchaseOrderId = async (value: string) => {
    const payload = {
      purchaseOrderId: value,
    };
    try {
      setIsLoading(true);
      const response = await dispatch(
        getMaterialsByPurchaseOrderById(payload)
      ).unwrap();
      setValue(
        "materials",
        response?.materials?.map((material) => ({
          ...material,
          quantity: material?.quantity
            ? material?.quantity
            : material?.totalQuantity || 0,
        }))
      );

      setValue("taxPercentage", response?.purchaseOrderTaxPercentage || 0);
      calculateTotal(response.materials);
      handleUpdateTotals();
    } catch (err) {
      console.log("err", err);
    } finally {
      setIsLoading(false);
    }
  };

  const handlePODataSetInInvoice = async (location: any) => {
    try {
      setFromPOLoading(true);

      await fetchMaterialsByPurchaseOrderId(location.state?.id);

      setValue("purchaseOrderId", location.state?.id);
      setValue("projectId", location.state?.purchaseOrderProject?.id || "");
      setValue(
        "projectLocationId",
        location.state?.purchaseOrderDeliveryLocation?.id || ""
      );
      setValue("vendorId", location.state?.vendor?.id || "");
      setValue("tax", location.state?.tax || 0);
      setValue("taxPercentage", location.state?.taxPercentage || 0);
      setValue("subTotal", location.state?.subTotal || 0);
      setValue("total", location.state?.total || 0);

      setFromPOLoading(false);
    } catch (error) {
      console.error("Error setting P.O. data:", error);
      setFromPOLoading(false);
    } finally {
      setFromPOLoading(false);
    }
  };

  useEffect(() => {
    if (location.state) {
      handlePODataSetInInvoice(location);
    }
  }, [location.state]);

  const handleClose = () => {
    const previousPath = location?.state?.previousPath || "";
    if (previousPath) {
      navigate(previousPath);
    } else {
      navigate(routePathsWithParams.INVOICES);
    }
  };

  const handleSaveInvoice = async (
    values: ReturnType<typeof getInvoiceInitialValues>
  ) => {
    const formData = new FormData();

    const payload = {
      ...values,
      createdBy: userFullName,

      invoiceDate: values?.invoiceDate
        ? new Date(values?.invoiceDate).toISOString()
        : null,
      dueDate: values.dueDate ? new Date(values.dueDate).toISOString() : null,
    };

    for (const [key, value] of Object.entries(payload)) {
      if (typeof value === "string" || typeof value === "number") {
        formData.append(key, value as string);
      }
    }

    values?.materials?.forEach((material, index) => {
      for (const [key, value] of Object.entries(material)) {
        if (value !== null) {
          formData.append(`materials[${index}][${key}]`, value as string);
        }
      }
    });

    if (
      values.purchaseOrderDocument &&
      Array.isArray(values.purchaseOrderDocument)
    ) {
      values.purchaseOrderDocument.forEach((file: any) => {
        formData.append(`purchaseOrderDocument`, file?.originFileObj);
      });
    }

    if (
      values.vendorInvoiceDocument &&
      Array.isArray(values.vendorInvoiceDocument)
    ) {
      values.vendorInvoiceDocument.forEach((file: any) => {
        formData.append(`vendorInvoiceDocument`, file?.originFileObj);
      });
    }

    if (values.attachments && Array.isArray(values.attachments)) {
      values.attachments.forEach((file: any) => {
        formData.append(`attachments`, file?.originFileObj);
      });
    }

    if (Array.isArray(values.deleteDocumentIds)) {
      values?.deleteDocumentIds?.forEach((id, index) => {
        formData.append(`deleteDocumentsId[${index}]`, id);
      });
    }

    values?.deleteDocumentIds?.forEach((id, index) => {
      formData.append(`deleteDocumentsId[${index}]`, id);
    });

    const updatePayload = {
      invoiceId: invoices?.id || "",
      formData,
    };

    if (invoices) {
      return await dispatch(updateInvoiceById(updatePayload)).unwrap();
    } else {
      return await dispatch(createInvoice(formData)).unwrap();
    }
  };
  const onSubmit = async (values: any) => {
    try {
      if (actionType === "save") {
        const res = await handleSaveInvoice(values);
        if (res?.isSuccess) {
          navigate(`${routePaths.INVOICES_EDIT_BY_ID}/${res?.invoice?.id}`);
          reset(getInvoiceInitialValues(res?.invoice));
        }
      } else if (actionType === "saveAndClose") {
        const res = await handleSaveInvoice(values);
        if (res?.isSuccess) {
          handleClose();
        }
      }
    } catch (error) {
      console.error("Error during form submission:", error);
    }
  };

  const fetchPurchaseOrderByProjectId = async (value: string | null) => {
    const payload = {
      projectId: value || "",
    };
    try {
      setValue("purchaseOrderId", "");

      setIsLoading(true);
      const response = await dispatch(getPurchaseOrdersList(payload)).unwrap();
      setPurchaseOrdersList(response?.purchaseOrders);
      if (location.state?.id || invoices) {
        const po = response?.purchaseOrders?.find(
          (f) => f.purchaseOrderNumber === invoices?.purchaseOrderNumber
        );
        setValue("purchaseOrderId", location.state?.id || po?.id);
      }
    } catch (err) {
      console.log("err", err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (location.state) {
      fetchPurchaseOrderByProjectId(location.state?.purchaseOrderProject?.id);
    } else {
      fetchPurchaseOrderByProjectId(invoices?.project?.id || null);
    }
  }, [location.state?.purchaseOrderProject?.id, invoices]);

  const handleChangeProjectId = async (value: string): Promise<void> => {
    setValue("subTotal", 0);
    setValue("total", 0);
    setValue("materials", []);
    try {
      await fetchPurchaseOrderByProjectId(value);
      handleUpdateTotals();
    } catch (err) {
      console.log("Error fetching locations:", err);
    }
  };

  const handleChangePurchaseOrderId = async (value: string) => {
    setValue("subTotal", 0);
    setValue("total", 0);
    setValue("materials", []);
    const data = purchaseOrdersList?.find((v) => v.id == value);

    setValue("purchaseOrderId", value);
    setValue("projectLocationId", data?.deliveryLocation?.id as string);
    setValue("vendorId", data?.vendor?.id as string);

    try {
      await fetchMaterialsByPurchaseOrderId(value);
      handleUpdateTotals();
    } catch (err) {
      console.log("Error fetching locations:", err);
    }
  };

  useEffect(() => {
    dispatch(getSummarizedProjectsList());
    dispatch(getVendorslist());
  }, [dispatch]);

  useEffect(() => {
    if (invoices?.project?.id) {
      fetchPurchaseOrderByProjectId(invoices?.project?.id);
    }
  }, [invoices?.project?.id]);

  const handleDeleteInvoiceById = async () => {
    try {
      setIsDeleting(true);
      const res = await dispatch(
        deleteInvoiceById(invoices?.id as string)
      ).unwrap();
      if (res) {
        navigate(routePaths.INVOICES);
      }
    } catch (error) {
      console.log("error", error);
    } finally {
      setIsDeleting(false);
    }
  };

  useEffect(() => {
    dispatch(resetState());
  }, []);

  if (fromPOLoading) {
    return <CustomOverlayLoader />;
  }

  return (
    <>
      <SectionLayout>
        <Form
          onFinish={handleSubmit(onSubmit)}
          layout="vertical"
          autoComplete="off"
        >
          <CustomFormRow>
            <Col xs={24} className="mb-4">
              <Typography.Title level={5}>General Information</Typography.Title>
            </Col>
            <Col xs={12}>
              <Controller
                name="invoiceNumber"
                control={control}
                render={({ field, fieldState }) => (
                  <Form.Item<FieldType>
                    validateStatus={
                      !field.value && fieldState.error ? "error" : ""
                    }
                    help={
                      !field.value && fieldState.error
                        ? fieldState.error.message
                        : ""
                    }
                  >
                    <CustomFormLabel text="Invoice Number" required />
                    <Input
                      {...field}
                      disabled={invoices?.invoiceNumber ? true : false}
                      placeholder="Invoice Number"
                      value={field.value}
                      onChange={(event) => field.onChange(event.target.value)}
                      size="large"
                      className="mt-3"
                    />
                  </Form.Item>
                )}
              />
            </Col>

            <Col xs={12}>
              <Controller
                name="title"
                control={control}
                render={({ field, fieldState }) => (
                  <Form.Item<FieldType>
                    validateStatus={
                      !field.value && fieldState.error ? "error" : ""
                    }
                    help={
                      !field.value && fieldState.error
                        ? fieldState.error.message
                        : ""
                    }
                  >
                    <CustomFormLabel text="Title" required />
                    <Input
                      {...field}
                      name="title"
                      value={field.value}
                      onChange={(event) => field.onChange(event.target.value)}
                      size="large"
                      placeholder="Invoice Title"
                      className="mt-3"
                    />
                  </Form.Item>
                )}
              />
            </Col>

            <Col xs={12}>
              <Controller
                name="projectId"
                control={control}
                render={({ field, fieldState }) => (
                  <Form.Item<FieldType>
                    validateStatus={
                      !field.value && fieldState.error ? "error" : ""
                    }
                    help={
                      !field.value && fieldState.error
                        ? fieldState.error.message
                        : ""
                    }
                  >
                    <CustomFormLabel text="Project" required />
                    <Select
                      {...field}
                      disabled={
                        Boolean(invoices) ||
                        location.state?.purchaseOrderProject?.id
                      }
                      value={field.value}
                      onChange={async (value) => {
                        field.onChange(value);
                        handleChangeProjectId(value);
                      }}
                      className="mt-3"
                      size="large"
                      placeholder="Select Project Name"
                      options={memoizedProjectsOptions}
                      showSearch
                      filterOption={(input, option) =>
                        (option?.label || "")
                          .toLowerCase()
                          .includes(input.toLowerCase())
                      }
                    />
                  </Form.Item>
                )}
              />
            </Col>

            <Col xs={12}>
              <Controller
                name="projectLocationId"
                control={control}
                render={({ field, fieldState }) => (
                  <Form.Item<FieldType>
                    validateStatus={
                      !field.value && fieldState.error ? "error" : ""
                    }
                    help={
                      !field.value && fieldState.error
                        ? fieldState.error.message
                        : ""
                    }
                  >
                    <CustomFormLabel text="Location" required />
                    <Select
                      {...field}
                      value={field.value}
                      loading={isLoading}
                      disabled
                      onChange={(value) => field.onChange(value)}
                      size="large"
                      placeholder="Select Location"
                      className="mt-3"
                      options={locationsListOptions}
                      showSearch
                      filterOption={(input, option) =>
                        (option?.label || "")
                          .toLowerCase()
                          .includes(input.toLowerCase())
                      }
                    />
                  </Form.Item>
                )}
              />
            </Col>

            <Col xs={12}>
              <Controller
                name="vendorId"
                control={control}
                render={({ field, fieldState }) => (
                  <Form.Item<FieldType>
                    validateStatus={
                      !field.value && fieldState.error ? "error" : ""
                    }
                    help={
                      !field.value && fieldState.error
                        ? fieldState.error.message
                        : ""
                    }
                  >
                    <CustomFormLabel text="Vendor" required />
                    <Select
                      {...field}
                      disabled
                      value={field.value}
                      onChange={(value) => field.onChange(value)}
                      size="large"
                      placeholder="Select Vendor"
                      className="mt-3"
                      options={memoizedVendorOptions}
                      filterOption={(input, option) =>
                        (option?.label || "")
                          .toLowerCase()
                          .includes(input.toLowerCase())
                      }
                      showSearch
                    />
                  </Form.Item>
                )}
              />
            </Col>

            <Col xs={12}>
              <Controller
                name="invoiceDate"
                control={control}
                render={({ field, fieldState }) => (
                  <Form.Item<FieldType>
                    validateStatus={
                      !field.value && fieldState.error ? "error" : ""
                    }
                    help={
                      !field.value && fieldState.error
                        ? fieldState.error.message
                        : ""
                    }
                  >
                    <CustomFormLabel text="Invoice Date" required />
                    <DatePicker
                      {...field}
                      value={
                        dayjs(field.value).isValid()
                          ? dayjs(field.value)
                          : dayjs(new Date())
                      }
                      onChange={(date) => {
                        field.onChange(dayjs(date).locale("en").format());
                      }}
                      size="large"
                      style={{ width: "100%" }}
                      placeholder="MM/DD/YYYY"
                      className="mt-3"
                    />
                  </Form.Item>
                )}
              />
            </Col>

            <Col xs={12}>
              <Controller
                name="dueDate"
                control={control}
                render={({ field, fieldState }) => (
                  <Form.Item<FieldType>
                    validateStatus={
                      !field.value && fieldState.error ? "error" : ""
                    }
                    help={
                      !field.value && fieldState.error
                        ? fieldState.error.message
                        : ""
                    }
                  >
                    <CustomFormLabel text="Due Date" required />
                    <DatePicker
                      {...field}
                      value={
                        dayjs(field.value).isValid()
                          ? dayjs(field.value)
                          : dayjs(new Date())
                      }
                      onChange={(date) => {
                        field.onChange(dayjs(date).locale("en").format());
                      }}
                      className="mt-3"
                      size="large"
                      style={{ width: "100%" }}
                      placeholder="MM/DD/YYYY"
                    />
                  </Form.Item>
                )}
              />
            </Col>
          </CustomFormRow>
          <CustomFormRow>
            <Col xs={12}>
              <Controller
                name="purchaseOrderId"
                control={control}
                render={({ field, fieldState }) => (
                  <Form.Item<FieldType>
                    validateStatus={
                      !field.value && fieldState.error ? "error" : ""
                    }
                    help={
                      !field.value && fieldState.error
                        ? fieldState.error.message
                        : ""
                    }
                  >
                    <CustomFormLabel text="Purchase Order Number" required />
                    <Select
                      {...field}
                      loading={isLoading}
                      disabled={
                        isLoading ||
                        getValues("projectId")?.length === 0 ||
                        Boolean(invoices) ||
                        location.state?.id
                      }
                      value={field.value}
                      onChange={(value) => {
                        field.onChange(value);
                        handleChangePurchaseOrderId(value);
                      }}
                      className="mt-3"
                      size="large"
                      placeholder="Select P.O. Number"
                      options={memoizedPurchaseOrderOptions}
                      showSearch
                      filterOption={(input, option) =>
                        (option?.label || "")
                          .toLowerCase()
                          .includes(input.toLowerCase())
                      }
                    />
                  </Form.Item>
                )}
              />
            </Col>

            <Col xs={12}>
              <Controller
                name="vendorInvoiceDocument"
                control={control}
                render={({ field }) => (
                  <Form.Item
                    label={<CustomFormLabel text="Upload Vendor Invoice" />}
                    labelAlign="right"
                  >
                    <CustomFileUploadRHF
                      deletedFileName="deleteDocumentIds"
                      getValues={getValues}
                      setValue={setValue}
                      fieldName={field.name}
                      buttonText="Browse File"
                      maxCount={1}
                    />
                  </Form.Item>
                )}
              />
            </Col>

            <Col xs={12}>
              <Controller
                name="purchaseOrderDocument"
                control={control}
                render={({ field }) => (
                  <Form.Item
                    label={
                      <CustomFormLabel text="Upload Purchase Order Document" />
                    }
                    labelAlign="right"
                  >
                    <CustomFileUploadRHF
                      getValues={getValues}
                      setValue={setValue}
                      fieldName={field.name}
                      buttonText="Browse File"
                      deletedFileName="deleteDocumentIds"
                      maxCount={1}
                    />
                  </Form.Item>
                )}
              />
            </Col>

            <Col xs={12}>
              <Controller
                name="paymentTerm"
                control={control}
                render={({ field }) => (
                  <Form.Item<FieldType>
                    label={<CustomFormLabel text="Payment Term" />}
                    labelAlign="right"
                    initialValue={field.value}
                  >
                    <Select
                      {...field}
                      value={field.value}
                      onChange={(value) => field.onChange(value)}
                      size="large"
                      placeholder="Select Payment Term"
                      options={paymentTermOptions}
                      showSearch
                    />
                  </Form.Item>
                )}
              />
            </Col>

            <Col xs={12}>
              <Controller
                name="status"
                control={control}
                render={({ field }) => (
                  <Form.Item<FieldType>
                    label={<CustomFormLabel text="Status" />}
                    labelAlign="right"
                    initialValue={field.value}
                  >
                    <Select
                      {...field}
                      value={field.value}
                      onChange={(value) => field.onChange(value)}
                      size="large"
                      options={invoicesStatusOptions}
                    />
                  </Form.Item>
                )}
              />
            </Col>

            <Col xs={24}>
              <Controller
                name="notes"
                control={control}
                render={({ field }) => (
                  <Form.Item<FieldType>
                    label={
                      <CustomFormLabel text="Notes (for Internal Users)" />
                    }
                    labelAlign="right"
                    initialValue={field.value}
                  >
                    <Input.TextArea
                      {...field}
                      value={field.value}
                      onChange={(event) =>
                        field.onChange(event.target.value || "")
                      }
                      className="!min-h-40"
                      placeholder="Write your notes here.."
                    />
                  </Form.Item>
                )}
              />
            </Col>
          </CustomFormRow>
          <Divider />
          <Col xs={24}>
            <Col xs={12}>
              <Form.Item
                layout="vertical"
                label={<CustomFormLabel text="Tax Percentage" required />}
              >
                <Controller
                  name={`taxPercentage`}
                  control={control}
                  render={({ field, formState: { errors } }) => {
                    return (
                      <Form.Item
                        help={errors?.taxPercentage?.message}
                        validateStatus={errors?.taxPercentage ? "error" : ""}
                      >
                        <Space.Compact size="large" style={{ width: "100%" }}>
                          <InputNumber
                            {...field}
                            onChange={(value) => {
                              field.onChange(value);
                              handleCalculateTax(value || 0);
                              handleUpdateTotals();
                            }}
                            style={{ width: "90%" }}
                            min={0}
                            max={100}
                            size="large"
                            type="number"
                            placeholder="Add Tax % here"
                          />
                          <Button
                            disabled
                            style={{
                              cursor: "default",
                              width: "10%",
                            }}
                          >
                            %
                          </Button>
                        </Space.Compact>
                      </Form.Item>
                    );
                  }}
                />
              </Form.Item>
            </Col>
          </Col>
          <InvoicesMaterials
            control={control}
            getValues={getValues}
            handleUpdateTotals={handleUpdateTotals}
            disabled={Boolean(invoices)}
          />
          <Flex
            justify="center"
            align="flex-end"
            vertical
            className="mt-14 mr-1"
          >
            <Controller
              name="subTotal"
              control={control}
              render={({ field }) => (
                <Form.Item
                  colon={false}
                  layout="horizontal"
                  initialValue={field.value || 0}
                  label={
                    <span
                      style={{
                        marginRight: "30px",
                        fontSize: "1.05rem",
                        textAlign: "left",
                      }}
                    >
                      Subtotal
                    </span>
                  }
                >
                  <InputNumber
                    {...field}
                    disabled
                    size="large"
                    style={{ width: "80%" }}
                    min={0}
                    value={field.value || 0}
                    formatter={(value) => `$ ${convertToLocaleString(value)}`}
                    parser={(value) =>
                      value?.replace(/\$\s?|(,*)/g, "") as unknown as number
                    }
                  />
                </Form.Item>
              )}
            />
            <Controller
              name="tax"
              control={control}
              render={({ field }) => {
                return (
                  <Form.Item
                    colon={false}
                    layout="horizontal"
                    initialValue={field.value}
                    label={
                      <span
                        style={{
                          marginRight: "30px",
                          fontSize: "1.05rem",
                          textAlign: "left",
                        }}
                      >
                        Tax
                      </span>
                    }
                  >
                    <InputNumber
                      {...field}
                      disabled
                      size="large"
                      style={{ width: "80%" }}
                      min={0}
                      formatter={(value) => `$ ${convertToLocaleString(value)}`}
                      parser={(value) =>
                        value?.replace(/\$\s?|(,*)/g, "") as unknown as number
                      }
                    />
                  </Form.Item>
                );
              }}
            />

            <Controller
              name={`total`}
              control={control}
              render={({ field }) => (
                <Form.Item
                  colon={false}
                  layout="horizontal"
                  className="font-bold"
                  initialValue={field.value || 0}
                  label={
                    <span style={{ marginRight: "20px", fontSize: "1.05rem" }}>
                      Total
                    </span>
                  }
                >
                  <InputNumber
                    {...field}
                    disabled
                    size="large"
                    style={{ width: "80%" }}
                    min={0}
                    // value={field.value || 0}
                    value={formatDecimalsOnlyTwo(field.value) || 0}
                    formatter={(value) => `$ ${convertToLocaleString(value)}`}
                  />
                </Form.Item>
              )}
            />
          </Flex>
          <Divider />
          <Typography.Title level={5} className="mt-9">
            Attachments
          </Typography.Title>
          <SectionLayout
            className="rounded-xl flex items-center max-h-64 my-5"
            borderStyle="dashed"
          >
            <div className="flex flex-col justify-center items-center max-h-64 p-8">
              <div className="mb-4">
                <CustomIcon type="add-file" className="fill-white" />
              </div>
              <h6 className="font-medium text-sm !mb-1">
                Select a file to import
              </h6>
              <Flex className="gap-5 mt-4">
                <Controller
                  name="attachments"
                  control={control}
                  render={({ field }) => (
                    <Form.Item<FieldType> labelAlign="right">
                      <CustomFileUploadRHF
                        deletedFileName="deleteDocumentIds"
                        getValues={getValues}
                        setValue={setValue}
                        fieldName={field.name}
                        buttonText="Browse File"
                        maxCount={4}
                      />
                    </Form.Item>
                  )}
                />
              </Flex>
            </div>
          </SectionLayout>
          {(reqError || resError || successMessage) && (
            <CustomAlert
              message={reqError || resError || successMessage || ""}
              type={successMessage ? "success" : "error"}
            />
          )}
          <Flex justify="flex-end" className="gap-4">
            <Button
              disabled={isSubmitting || isDeleting}
              type="default"
              onClick={handleClose}
            >
              Cancel
            </Button>
            {getValues("id") && (
              <Button
                loading={isDeleting}
                disabled={isSubmitting || isDeleting}
                type="default"
                onClick={handleDeleteInvoiceById}
              >
                {isDeleting ? "Deleting.." : "Delete"}
              </Button>
            )}

            <Button
              loading={actionType === "save" && isSubmitting}
              disabled={isSubmitting || isDeleting}
              type="primary"
              htmlType="submit"
              onClick={() => setActionType("save")}
            >
              {actionType === "save" && isSubmitting ? "Saving.." : "Save"}
            </Button>
            <Button
              loading={actionType === "saveAndClose" && isSubmitting}
              disabled={isSubmitting || isDeleting}
              type="primary"
              htmlType="submit"
              onClick={() => setActionType("saveAndClose")}
            >
              {actionType === "saveAndClose" && isSubmitting
                ? "Saving and closing.."
                : "Save & Close"}
            </Button>
          </Flex>
          {getValues("id") && (
            <Flex justify="flex-end" className="mt-4">
              <CreatedByUserBadge
                userName={
                  invoices?.modifiedDate == null
                    ? invoices?.createdBy
                    : invoices?.lastModifiedBy
                }
                date={invoices?.lastModifiedDate}
                isModifiedBadge={invoices?.modifiedDate == null ? false : true}
              />
            </Flex>
          )}
        </Form>
      </SectionLayout>
    </>
  );
}
