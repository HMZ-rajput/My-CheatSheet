import * as Yup from "yup";

export const validationSchema = Yup.object().shape({
  invoiceNumber: Yup.string().required("Invoice Number is required."),
  title: Yup.string().required("Title is required."),
  projectId: Yup.string().required("Project is required."),
  projectLocationId: Yup.string().required("Location is required."),
  vendorId: Yup.string().required("Vendor is required."),
  invoiceDate: Yup.string().required("Invoice Date is required."),
  dueDate: Yup.string().required("Due Date is required."),
  purchaseOrderId: Yup.string().required("Purchase Order Number is required."),
});
