import CustomIcon from "@/src/components/common/CustomIcon";
import { invoiceOptions } from "@/src/utils/constants";
import { BudgetStatusEnum } from "@/src/utils/enums";
import { convertToLocaleString } from "@/src/utils/helper";
import { Material } from "@/src/utils/types";
import { Form, Input, InputNumber } from "antd";
import React, { useRef } from "react";
import {
  Control,
  Controller,
  FieldValues,
  UseFieldArrayRemove,
} from "react-hook-form";
import { VariableSizeList as List } from "react-window";
type InvoiceMaterialsListProps = {
  control?: Control<FieldValues | any>;
  getValues: any;
  invoiceMaterialFields: Material[];
  disabled: boolean;

  deleteInvoiceMaterialField: UseFieldArrayRemove;
  handleUpdateTotals: () => void;
};

const InvoiceMaterialsList = ({
  control,
  getValues,
  invoiceMaterialFields,
  disabled,
  deleteInvoiceMaterialField,
  handleUpdateTotals,
}: InvoiceMaterialsListProps) => {
  const listRef = useRef<List>(null);

  const MAX_HEIGHT = 500;
  const estimatedItemHeight = 100;
  const listHeight = Math.min(
    invoiceMaterialFields.length * estimatedItemHeight,
    MAX_HEIGHT
  );

  const getItemSize = () => {
    return 100;
  };

  const renderRow = ({
    index,
    style,
  }: {
    index: number;
    style: React.CSSProperties;
  }) => {
    invoiceMaterialFields;
    const materials = invoiceMaterialFields[index];

    return (
      <div style={style} className="materials-row " key={materials.id}>
        <div className="materials-first-row flex mb-7" key={materials.id}>
          {/* Material */}
          <div className="col pr-4 col-xs-2">
            <Controller
              name={`materials.${index}.name`}
              control={control}
              render={({ field, fieldState }) => (
                <Form.Item
                  initialValue={field.value}
                  labelAlign="right"
                  validateStatus={
                    !field.value && fieldState?.error ? "error" : ""
                  }
                >
                  <Input
                    {...field}
                    disabled={getValues("materials")?.length > 0}
                    value={field.value}
                    onChange={(event) => field.onChange(event.target.value)}
                    size="large"
                    placeholder="Material Name"
                  />
                </Form.Item>
              )}
            />
          </div>

          {/* Cost Code */}
          <div className="col pr-4 col-xs-3">
            <Controller
              name={`materials.${index}.costCode`}
              control={control}
              render={({ field, fieldState }) => (
                <Form.Item
                  labelAlign="right"
                  validateStatus={
                    !field.value && fieldState?.error ? "error" : ""
                  }
                >
                  <Input
                    {...field}
                    disabled
                    value={field.value}
                    onChange={(e) => field.onChange(e.target.value)}
                    size="large"
                    style={{ width: "100%" }}
                    placeholder="Cost Code"
                  />
                </Form.Item>
              )}
            />
          </div>

          {/* Balance Quantity */}
          <div className="col pr-4 col-xs-3">
            <Controller
              name={`materials.${index}.balanceQuantity`}
              control={control}
              render={({ field, fieldState }) => (
                <Form.Item
                  labelAlign="right"
                  validateStatus={
                    !field.value && fieldState?.error ? "error" : ""
                  }
                >
                  <InputNumber
                    {...field}
                    disabled
                    value={field.value}
                    onChange={(value) => field.onChange(value || 0)}
                    size="large"
                    min={0}
                    style={{ width: "100%" }}
                    placeholder="0"
                  />
                </Form.Item>
              )}
            />
          </div>

          {/* Remaining Budget */}
          <div className="col pr-4 col-xs-2">
            <Controller
              name={`materials.${index}.remainingBudget`}
              control={control}
              render={({ field, fieldState }) => (
                <Form.Item
                  labelAlign="right"
                  validateStatus={
                    !field.value && fieldState?.error ? "error" : ""
                  }
                >
                  <InputNumber
                    {...field}
                    disabled
                    value={field.value}
                    size="large"
                    min={0}
                    style={{ width: "100%" }}
                    placeholder="$ 0.00"
                  />
                </Form.Item>
              )}
            />
          </div>

          {/* Previously Billed */}
          <div className="col pr-4 col-xs-2">
            <Controller
              name={`materials.${index}.previouslyBilled`}
              control={control}
              render={({ field, fieldState }) => (
                <Form.Item
                  labelAlign="right"
                  validateStatus={
                    !field.value && fieldState?.error ? "error" : ""
                  }
                >
                  <InputNumber
                    {...field}
                    disabled
                    value={field.value}
                    size="large"
                    min={0}
                    style={{ width: "100%" }}
                    placeholder="0"
                  />
                </Form.Item>
              )}
            />
          </div>

          <div className="col pr-4 col-xs-2">
            <Controller
              name={`materials.${index}.quantity`}
              control={control}
              render={({ field, fieldState }) => (
                <Form.Item
                  labelAlign="right"
                  validateStatus={
                    !field.value && fieldState?.error ? "error" : ""
                  }
                >
                  <div className="flex items-center gap-2">
                    <InputNumber
                      {...field}
                      type="number"
                      value={field.value}
                      onChange={(value) => {
                        field.onChange(value);
                        handleUpdateTotals();
                      }}
                      disabled={disabled}
                      size="large"
                      min={0}
                      max={getValues("materials")?.[index]?.totalQuantity}
                      style={{ width: "100%" }}
                      placeholder="0"
                      precision={0}
                    />
                    /{getValues("materials")?.[index]?.totalQuantity}
                  </div>
                </Form.Item>
              )}
            />
          </div>

          <div className="col pr-4 col-xs-3">
            <Controller
              name={`materials.${index}.unitOfMeasure`}
              control={control}
              render={({ field, fieldState }) => (
                <Form.Item
                  labelAlign="right"
                  validateStatus={
                    !field.value && fieldState?.error ? "error" : ""
                  }
                >
                  <Input
                    {...field}
                    disabled
                    value={field.value}
                    size="large"
                    placeholder="kg"
                  />
                </Form.Item>
              )}
            />
          </div>

          {/* Unit Rate */}
          <div className="col pr-4 col-xs-2">
            <Controller
              name={`materials.${index}.unitRate`}
              control={control}
              render={({ field, fieldState }) => (
                <Form.Item
                  labelAlign="right"
                  validateStatus={
                    !field.value && fieldState?.error ? "error" : ""
                  }
                >
                  <InputNumber
                    {...field}
                    disabled={getValues("materials")?.length > 0}
                    value={field.value || 0}
                    size="large"
                    min={0}
                    style={{ width: "100%" }}
                    placeholder="$ 0.00"
                    prefix="$"
                  />
                </Form.Item>
              )}
            />
          </div>

          {/* Amount */}
          <div className="col pr-4 col-xs-2">
            <Controller
              name={`materials.${index}.cost`}
              control={control}
              render={({ field, fieldState }) => (
                <Form.Item
                  labelAlign="right"
                  validateStatus={
                    !field.value && fieldState?.error ? "error" : ""
                  }
                >
                  <InputNumber<string>
                    {...field}
                    disabled
                    size="large"
                    style={{ width: "100%" }}
                    min="0"
                    stringMode
                    readOnly
                    value={(field.value || 0)?.toString()}
                    formatter={(value) => `${convertToLocaleString(value)}`}
                    prefix="$"
                  />
                </Form.Item>
              )}
            />
          </div>

          {/* Total Budget */}
          <div className="col pr-4 col-xs-2">
            <Controller
              name={`materials.${index}.cost`}
              control={control}
              render={({ field, fieldState }) => (
                <Form.Item
                  labelAlign="right"
                  validateStatus={
                    !field.value && fieldState?.error ? "error" : ""
                  }
                >
                  {(getValues("materials")?.[index]
                    ?.remainingBudget as number) >= 0 ? (
                    <div className="p-2 rounded-lg bg-[#0CAF6014] flex items-center justify-center text-[#0CAF60]">
                      {invoiceOptions[BudgetStatusEnum.WithinBudget]}
                    </div>
                  ) : (
                    <div className="p-2 rounded-lg bg-[#DF1C4114] flex items-center justify-center text-[#DF1C41]">
                      {invoiceOptions[BudgetStatusEnum.OverBudget]}
                    </div>
                  )}
                </Form.Item>
              )}
            />
          </div>

          <div className="col pr-4 col-xs-1">
            <button
              className={`disabled:!bg-neutral-1 disabled:!border-neutral-5 disabled:!text-neutral-75 disabled:stroke-neutral-7 border transition-all duration-200 cursor-pointer p-1.5 rounded-md hover:!border-danger-5 hover:!bg-primary25 fill-white  stroke-danger-5 border-danger-5 hover:bg-danger-5-12 disabled:cursor-not-allowed mt-0.5`}
              disabled={disabled}
              onClick={() => {
                deleteInvoiceMaterialField(index);
              }}
            >
              <CustomIcon type="delete-icon" />
            </button>
          </div>
        </div>
      </div>
    );
  };

  return (
    <>
      <List
        ref={listRef}
        height={listHeight}
        itemCount={invoiceMaterialFields.length}
        itemSize={getItemSize}
        width={"100%"}
        className="list-scroll-container"
      >
        {renderRow}
      </List>
    </>
  );
};

export default InvoiceMaterialsList;
