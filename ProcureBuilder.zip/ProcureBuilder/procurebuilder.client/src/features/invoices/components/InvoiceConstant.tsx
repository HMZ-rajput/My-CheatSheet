import { FilesDocumentTypeEnum } from "@/src/utils/enums";
import { Invoice } from "@/src/utils/types";

export const invoiceMaterials = [];

export const getInvoiceInitialValues = (invoices: Invoice | null) => {
  const fileFormater = (documentTypeEnum: number) => {
    const newFileFormat = invoices?.documents
      ?.filter((v) => v.documentType === documentTypeEnum)
      ?.map((v) => ({
        uid: v?.id,
        name: v.fileName,
        documentType: v.documentType,
        url: v.url,
      }));

    return newFileFormat || [];
  };

  const initialValues = {
    id: invoices?.id || "",
    invoiceNumber: invoices?.invoiceNumber || "",
    title: invoices?.title || "",
    createdBy: invoices?.createdBy || "",
    createdDate: invoices?.createdDate || new Date(),
    deleteDocumentIds: [],
    projectId: invoices?.project?.id || "",
    projectName: invoices?.project?.name || "",
    projectLocationId: invoices?.location?.id || "",
    locationName: invoices?.locationName || "",
    vendorId: invoices?.vendor?.id || "",
    vendorName: invoices?.vendorName || "",
    invoiceDate: invoices?.invoiceDate || new Date(),
    dueDate: invoices?.dueDate || new Date(),
    purchaseOrderId: invoices?.purchaseOrder?.id || "",
    freight: invoices?.freight || 0,
    tax: invoices?.tax || 0,
    taxPercentage: invoices?.taxPercentage || 0,
    total: invoices?.total || 0,
    attachments:
      fileFormater(FilesDocumentTypeEnum?.INVOICEATTACHMENTS) || null,
    vendorInvoiceNumber: invoices?.vendorInvoiceNumber || "",
    purchaseOrderDocument:
      fileFormater(FilesDocumentTypeEnum?.PURCHASEORDER) || null,
    vendorInvoiceDocument:
      fileFormater(FilesDocumentTypeEnum?.VENDORINVOICE) || null,
    paymentTerm: invoices?.paymentTerm || 0,
    status: invoices?.status || 0,
    notes: invoices?.notes || "",
    subTotal: invoices?.subTotal || 0,
    materials: invoices?.materials || invoiceMaterials,
    lastModifiedDate: invoices?.lastModifiedDate || null,
    modifiedBy: invoices?.modifiedBy || "",
    modifiedDate: invoices?.modifiedDate || null,
    lastModifiedBy: invoices?.lastModifiedBy || "",
    PurchaseOrderNumber: 14,
  };
  return initialValues;
};
