import { getAllInvoices } from "@/src/apis/invoicesApis";
import HighlightedText from "@/src/components/common/HighlightedText";
import InvoicesStatus from "@/src/components/common/InvoicesStatus";
import CustomTable from "@/src/components/table/CustomTable";
import CustomTableFilters, {
  CustomFilterDataType,
  CustomFiltersType,
} from "@/src/components/table/CustomTableFilters";
import { useAppDispatch } from "@/src/hooks/useAppDispatch";
import { useDebouncedCallback } from "@/src/hooks/useDebouncedCallback";
import useSyncFilters from "@/src/hooks/useSyncFilters";
import { getInvoicesState } from "@/src/store/slices/invoicesSlice";
import { getProjectsState } from "@/src/store/slices/projectsSlice";
import {
  allInvoicesStatusOption,
  dateFormat,
  invoicesStatusOptionsWithAll,
  paymentTermOptions,
  statusOptions,
} from "@/src/utils/constants";
import { getInvoicesStatus } from "@/src/utils/helper";
import routePaths from "@/src/utils/routePaths";
import { getConsistentSpacing } from "@/src/utils/theme-helpers";
import { Invoice } from "@/src/utils/types";
import CustomIcon from "@components/common/CustomIcon";
import SectionLayout from "@components/layout/SectionLayout";
import { useAppSelector } from "@hooks/useAppSelector";
import { Button, TableProps, Typography } from "antd";
import dayjs from "dayjs";
import { useEffect, useMemo, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";

type InvoicesListProps = {
  invoices?: Invoice[] | null;

  hasPagination?: boolean;
  hasDetailedColumns?: boolean;
  hasSearch?: boolean;
  hasFilters?: boolean;
  hasBorders?: boolean;
};
export default function InvoicesList({
  hasPagination = true,
  hasSearch = true,
  hasFilters = true,
  hasBorders = true,
}: InvoicesListProps) {
  const dispatch = useAppDispatch();
  const {
    isLoading,
    totalCount,
    currentPage: invoicesCurrentPage,
    pageSize: invoicesPageSize,
  } = useAppSelector(getInvoicesState);
  const { projectsSummarizedData } = useAppSelector(getProjectsState);

  const navigate = useNavigate();
  const { invoicesData } = useAppSelector(getInvoicesState);
  const [buttonActive, setButtonActive] = useState({
    isDueTodayActive: false,
    isOverDueActive: false,
    isUpComingActive: false,
  });

  const [page, setPage] = useState<number>(invoicesCurrentPage);
  const [pageSize, setPageSize] = useState(invoicesPageSize);
  const isFirstCallComplete = useRef(false);
  // const [isFirstCall, setIsFirstCall] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [hasSearched, setHasSearched] = useState(false);
  const { searchParams } = useSyncFilters();
  const [previousSearchTerm, setPreviousSearchTerm] = useState(
    searchParams.get("searchTerm")
  );
  const [lastSearchTimestamp, setLastSearchTimestamp] = useState(0);

  useEffect(() => {
    setLastSearchTimestamp(Date.now());
  }, [previousSearchTerm]);

  const [buttonsFilterStatus, setButtonsFilterStatus] = useState({
    isDueToday: false,
    isOverDue: false,
    isUpComing: false,
  });

  const memoizedProjectsOptions = useMemo(() => {
    return [
      {
        value: "",
        label: "All Projects",
      },
      ...(projectsSummarizedData?.map((f) => ({
        value: f?.id,
        label: f?.name,
      })) || []),
    ];
  }, [projectsSummarizedData]);

  const [filters, setFilters] = useState<CustomFiltersType>({
    status: {
      value: allInvoicesStatusOption?.value || 0,
      options: invoicesStatusOptionsWithAll,
      className: "!min-w-[140px]",
      dataType: CustomFilterDataType.NUM,
    },
    projectId: {
      value: memoizedProjectsOptions[0]?.value || "",
      options: memoizedProjectsOptions,
      className: "!min-w-[160px]",
      dataType: CustomFilterDataType.STR,
    },
  });

  function updateDueTimeButtons(value: string) {
    switch (value) {
      case "dueToday":
        setButtonsFilterStatus((prev) => ({
          ...prev,
          isDueToday: !prev.isDueToday,
          isOverDue: false,
          isUpComing: false,
        }));
        setButtonActive((prev) => ({
          ...prev,
          isDueTodayActive: !prev.isDueTodayActive,
          isOverDueActive: false,
          isUpComingActive: false,
        }));
        break;
      case "overDue":
        setButtonsFilterStatus((prev) => ({
          ...prev,
          isDueToday: false,
          isOverDue: !prev.isOverDue,
          isUpComing: false,
        }));
        setButtonActive((prev) => ({
          ...prev,
          isDueTodayActive: false,
          isOverDueActive: !prev.isOverDueActive,
          isUpComingActive: false,
        }));
        break;
      case "upComing":
        setButtonsFilterStatus((prev) => ({
          ...prev,
          isDueToday: false,
          isOverDue: false,
          isUpComing: !prev.isUpComing,
        }));
        setButtonActive((prev) => ({
          ...prev,
          isDueTodayActive: false,
          isOverDueActive: false,
          isUpComingActive: !prev.isUpComingActive,
        }));
    }
  }

  const filterButtons = [
    {
      label: "Due Today",
      value: "dueToday",
      isActive: buttonActive.isDueTodayActive,
      onClick: updateDueTimeButtons,
    },
    {
      label: "Overdue",
      value: "overDue",
      isActive: buttonActive.isOverDueActive,
      onClick: updateDueTimeButtons,
    },
    {
      label: "Upcoming",
      value: "upComing",
      isActive: buttonActive.isUpComingActive,
      onClick: updateDueTimeButtons,
    },
  ];
  useEffect(() => {
    // Only update filters if the options actually change
    setFilters((prevFilters) => {
      const currentOptions = prevFilters.projectId.options;
      const newOptions = memoizedProjectsOptions;

      // Check if options are different (by comparing their length or individual items)
      const optionsChanged =
        currentOptions.length !== newOptions.length ||
        currentOptions.some(
          (option, index) => option.value !== newOptions[index]?.value
        );

      // If options are the same, return the previous filters to avoid unnecessary state update
      if (!optionsChanged) {
        return prevFilters;
      }

      // If options have changed, update the filters
      return {
        ...prevFilters,
        projectId: {
          ...prevFilters.projectId,
          options: newOptions,
        },
      };
    });
  }, [memoizedProjectsOptions]);

  const handleGetResults = useDebouncedCallback(getResults, 100);

  async function getResults(pageNumber?: number) {
    const status =
      filters.status?.value !== statusOptions?.value
        ? (filters?.status?.value as number)
        : undefined;

    const projectId =
      filters.projectId?.value !== memoizedProjectsOptions[0]?.value
        ? filters?.projectId?.value?.toString()
        : undefined;

    const isDueToday = buttonsFilterStatus.isDueToday
      ? buttonsFilterStatus.isDueToday.toString()
      : undefined;

    const isOverDue = buttonsFilterStatus.isOverDue
      ? buttonsFilterStatus.isOverDue.toString()
      : undefined;

    const isUpComing = buttonsFilterStatus.isUpComing
      ? buttonsFilterStatus.isUpComing.toString()
      : undefined;

    await dispatch(
      getAllInvoices({
        pageNumber: pageNumber || page,
        pageSize,
        isDueToday,
        isUpComing,
        isOverDue,
        projectId: projectId,
        search: searchTerm || undefined,
        status: status,
      })
    );
  }

  const navigateToEditPage = (invoice: Invoice) => {
    const path = `${routePaths.INVOICES_EDIT_BY_ID}/${invoice.id}`;

    if (new URLSearchParams(location.search).size > 0) {
      navigate(path, {
        state: {
          previousPath: `${location.pathname}${location.search}`,
        },
      });
    } else {
      navigate(path);
    }
  };
  const columns: TableProps<Invoice>["columns"] = [
    {
      title: "Invoice Number",
      dataIndex: "invoiceNumber",
      key: "invoiceNumber",
      sorter: (a, b) => a.invoiceNumber.localeCompare(b.invoiceNumber),
      render: (title: string) => (
        <HighlightedText text={title} searchTerm={searchTerm || ""} />
      ),
    },
    {
      title: "Title",
      dataIndex: "title",
      key: "title",
      sorter: (a, b) => a.title.localeCompare(b.title),
      render: (title: string) => (
        <HighlightedText text={title} searchTerm={searchTerm || ""} />
      ),
    },
    {
      title: "Vendor",
      dataIndex: ["vendor", "name"],
      key: "vendor",
      sorter: (a, b) => a.vendor?.name.localeCompare(b.vendor?.name),
    },
    {
      title: "Invoice Date",
      dataIndex: "invoiceDate",
      key: "invoiceDate",
      sorter: (a, b) =>
        dayjs(a.invoiceDate).unix() - dayjs(b.invoiceDate).unix(),
      render: (invoiceDate) => (
        <HighlightedText
          text={dayjs(invoiceDate).format(dateFormat)}
          searchTerm={searchTerm}
        />
      ),
    },
    {
      title: "Due Date",
      dataIndex: "dueDate",
      key: "dueDate",
      sorter: (a, b) => dayjs(a.dueDate).unix() - dayjs(b.dueDate).unix(),
      render: (dueDate) => (
        <HighlightedText
          text={dayjs(dueDate).format(dateFormat)}
          searchTerm={searchTerm}
        />
      ),
    },
    {
      title: "Payment Term",
      dataIndex: "paymentTerm",
      key: "paymentTerm",
      sorter: (a, b) => (a.paymentTerm || 0) - (b.paymentTerm || 0),
      render: (paymentTerm) => (
        <HighlightedText
          text={
            paymentTermOptions.find((f) => f.value === paymentTerm)?.label || ""
          }
          searchTerm={searchTerm}
        />
      ),
    },
    {
      title: "Total",
      dataIndex: "total",
      key: "total",
      sorter: (a, b) => a.total - b.total,
      render: (_, record) => {
        return (
          <Typography.Text
            style={{ fontSize: getConsistentSpacing(1.75), margin: 0 }}
          >
            ${record.total?.toLocaleString()}
          </Typography.Text>
        );
      },
    },

    {
      title: "Status",
      dataIndex: "status",
      key: "status",
      render: (status) => {
        const { badgeType } = getInvoicesStatus(status);
        return <InvoicesStatus badgeType={badgeType} />;
      },
    },
    {
      title: "P.O. #",
      dataIndex: "purchaseOrderNumber",
      key: "purchaseOrderNumber",
      sorter: (a, b) =>
        a?.purchaseOrderNumber?.localeCompare(b?.purchaseOrderNumber as string),
    },
    {
      title: "Project",
      dataIndex: ["project", "name"],
      key: "project",
      sorter: (a, b) =>
        a.project?.name?.localeCompare(b.project.name as string),
    },
    {
      title: "",
      key: "actions",
      render: (record) => (
        <Button
          shape="circle"
          className="hover:!fill-primary"
          icon={<CustomIcon type="edit" />}
          onClick={() => navigateToEditPage(record)}
        />
      ),
    },
  ];

  function resetPaginationAndGetFirstPageResults() {
    if (isFirstCallComplete?.current === true) {
      if (filters) {
        setPage(1);
      }

      handleGetResults(1);
    } else {
      handleGetResults();
    }
  }

  useEffect(() => {
    if (!hasSearched) return;
    const timer = setTimeout(() => {
      if (searchTerm === "" && previousSearchTerm !== "") {
        resetPaginationAndGetFirstPageResults();
        setPreviousSearchTerm(searchTerm);
      }
    }, 500);

    return () => {
      clearTimeout(timer);
    };
  }, [searchTerm, hasSearched, previousSearchTerm]);

  const handleSearch = () => {
    if (searchTerm !== previousSearchTerm) {
      setHasSearched(true);
      resetPaginationAndGetFirstPageResults();
      setPreviousSearchTerm(searchTerm);
    }
  };

  useEffect(() => {
    if (
      !isFirstCallComplete?.current ||
      invoicesCurrentPage !== page ||
      invoicesPageSize !== pageSize
    ) {
      handleGetResults();

      if (!isFirstCallComplete?.current) {
        setTimeout(() => {
          isFirstCallComplete.current = true;
        }, 1000);
      }
    }
  }, [page, pageSize]);

  useEffect(() => {
    resetPaginationAndGetFirstPageResults();
  }, [filters, buttonsFilterStatus]);

  return (
    <>
      <SectionLayout isHidden={!hasBorders}>
        <CustomTable
          data={invoicesData || []}
          columns={columns || []}
          searchTerm={searchTerm}
          setSearchTerm={setSearchTerm}
          handleSearch={handleSearch}
          isLoading={isLoading}
          totalCount={totalCount}
          page={page}
          setPage={setPage}
          pageSize={pageSize}
          setPageSize={setPageSize}
          tableFilters={filters}
          setTableFilters={setFilters}
          filterElements={
            hasFilters ? (
              <CustomTableFilters
                filters={filters}
                setFilters={setFilters}
                buttons={filterButtons}
              />
            ) : null
          }
          hasPagination={hasPagination}
          hasSearch={hasSearch}
          lastSearchTimestamp={lastSearchTimestamp}
          dueTimeButtons={filterButtons?.map((m) => ({
            ...m,
            isActive:
              m.value === "dueToday"
                ? buttonActive.isDueTodayActive
                : m.value === "overDue"
                ? buttonActive.isOverDueActive
                : buttonActive.isUpComingActive,
          }))}
          updateDueTimeButtons={updateDueTimeButtons}
        />
      </SectionLayout>
    </>
  );
}
