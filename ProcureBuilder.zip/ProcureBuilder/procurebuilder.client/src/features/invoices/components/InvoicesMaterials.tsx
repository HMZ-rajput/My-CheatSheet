import { Invoice } from "@/src/utils/types";
import { Control, useFieldArray, UseFormGetValues } from "react-hook-form";
import InvoiceMaterialsList from "./InvoiceMaterialsList";

type InvoiceFormProps = {
  control: Control<Invoice, any>;
  getValues: UseFormGetValues<Invoice>;
  handleUpdateTotals: () => void;
  disabled: boolean;
};

export default function InvoicesMaterials(props: InvoiceFormProps) {
  const { control, getValues, handleUpdateTotals, disabled } = props;

  const { fields: invoiceMaterialFields, remove: deleteInvoiceMaterialField } =
    useFieldArray({
      control: control,
      name: "materials",
    });

  return (
    <>
      <div className="materials-header-row flex w-full py-1.5 px-2 rounded-lg mb-4 bg-neutral-0">
        <div className="col col-xs-2">
          <span className="font-medium text-xs">Material</span>
        </div>
        <div className="col col-xs-3">
          <div className="font-normal">Cost Code</div>
        </div>
        <div className="col  col-xs-3">
          <div className="font-normal">Balance Quantity</div>
        </div>
        <div className="col  col-xs-2">
          <div className="font-normal">
            Remaining
            <br />
            Budget
          </div>
        </div>
        <div className="col col-xs-2">
          <div className="font-normal">Previously Billed</div>
        </div>
        <div className="col col-xs-2">
          <div className="font-normal">Quantity</div>
        </div>
        <div className="col col-xs-3">
          <div className="font-normal">Unit of Measurement</div>
        </div>
        <div className="col col-xs-2">
          <div className="font-normal">Unit Rate</div>
        </div>
        <div className="col col-xs-2">
          <div className="font-normal">Amount</div>
        </div>
        <div className="col  col-xs-2">
          <div className="font-normal">Budget Status</div>
        </div>
        <div className="col col-xs-1">
          <div className="font-normal"></div>
        </div>
      </div>

      <InvoiceMaterialsList
        invoiceMaterialFields={invoiceMaterialFields}
        control={control}
        getValues={getValues}
        handleUpdateTotals={handleUpdateTotals}
        deleteInvoiceMaterialField={deleteInvoiceMaterialField}
        disabled={disabled}
      />

      <div className="float-end mt-5">
        {invoiceMaterialFields.length} Row(s)
      </div>
    </>
  );
}
