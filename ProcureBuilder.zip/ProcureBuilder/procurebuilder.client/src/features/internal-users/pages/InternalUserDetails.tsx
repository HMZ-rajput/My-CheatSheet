import { getInternalUserById } from "@/src/apis/internalUsersApis";
import CustomTabs from "@/src/components/common/CustomTabs";
import { InternalUserStatus } from "@/src/components/common/InternalUserStatus";
import { useAppSelector } from "@/src/hooks/useAppSelector";
import { getInternalUserDataById } from "@/src/store/slices/internalUsersSlice";
import { Roles } from "@/src/utils/constants";
import { UserStatus } from "@/src/utils/enums";
import routePaths from "@/src/utils/routePaths";
import { InternalUser } from "@/src/utils/types";
import PageLayout from "@components/layout/PageLayout";
import { Flex } from "antd";
import { useEffect, useState } from "react";
import { useLocation, useParams } from "react-router-dom";
import InternalUserDetailsForm from "../components/InternalUserDetailsForm";
import ProjectAccessList from "../components/ProjectAccessList";

export default function InternalUserDetailsPage() {
  const { internalUserId } = useParams();
  const [internalUserData, setInternalUserData] = useState<InternalUser | null>(
    null
  );

  const [selectedUser, setSelectedUser] = useState<string[]>([]);

  console.log("selectedUser", selectedUser);

  const tabs = {
    overview: "Overview",
    ...(internalUserData?.role !== Roles.Admin
      ? { projectAccess: "Project Access" }
      : {}),
  };
  const location = useLocation();

  const internalUser = useAppSelector((state) =>
    getInternalUserDataById(state, internalUserId || "")
  );
  useEffect(() => {
    if (internalUserId) {
      const fetchInternalUserById = async () => {
        try {
          const response = await getInternalUserById(internalUserId || "");
          if (response?.isSuccess) {
            setInternalUserData(response?.user);
          }
        } catch (e) {
          console.error("Error fetching internal user by id", e);
        }
      };
      fetchInternalUserById();
    }
    if (location.pathname === routePaths.INTERNAL_USERS_NEW) {
      setInternalUserData(null);
    }
  }, [location.pathname]);

  // States
  const [selectedTab, setSelectedTab] = useState(tabs.overview);
  // Functions
  function renderRenderTabPanels() {
    switch (selectedTab) {
      default:
        return (
          <InternalUserDetailsForm
            internalUser={internalUserData}
            setInternalUserData={setInternalUserData}
          />
        );
      case tabs.projectAccess:
        return (
          <>
            {internalUserData?.role !== Roles.Admin ? (
              <ProjectAccessList
                internalUserId={
                  internalUserData?.id || internalUserData?.userId || ""
                }
                setSelectedUser={setSelectedUser}
                selectedUser={selectedUser}
              />
            ) : null}
          </>
        );
    }
  }

  function renderStatusOnForm() {
    if (
      UserStatus.Active === internalUser?.status ||
      UserStatus.Active === internalUserData?.status
    ) {
      return (
        <InternalUserStatus badgeIconType={"check-mark"} badgeType={"Active"} />
      );
    } else if (
      UserStatus.InvitePending === internalUser?.status ||
      UserStatus.InvitePending === internalUserData?.status
    ) {
      return (
        <InternalUserStatus
          badgeIconType={"clock-icon"}
          badgeType={"Invite Pending"}
        />
      );
    } else if (
      UserStatus.InActive === internalUser?.status ||
      UserStatus.InActive === internalUserData?.status
    ) {
      return (
        <InternalUserStatus badgeIconType={"cancel"} badgeType={"Removed"} />
      );
    } else {
      return (
        <InternalUserStatus
          badgeIconType={"clock-icon"}
          badgeType={"Invite Pending"}
        />
      );
    }
  }

  useEffect(() => {
    if (
      location.pathname === routePaths.INTERNAL_USERS_NEW &&
      selectedTab !== tabs.overview
    ) {
      setSelectedTab(tabs.overview);
    }
  }, [location]);

  return (
    <>
      <PageLayout
        title={`${
          internalUser || internalUserData ? "Edit" : "Add New"
        } Internal User`}
        titleSibling={renderStatusOnForm()}
        titleBarJustifyContent="flex-start"
      >
        <Flex className="mb-7">
          <CustomTabs
            options={Object.entries(tabs)?.map(([key, value]) => ({
              value: key,
              label: value,
              disabled: !internalUserId ? value == tabs.projectAccess : false,
            }))}
            tabLabel={selectedTab}
            onChange={(tab) => setSelectedTab(tab)}
          />
        </Flex>
        {/* {isLoadingUser ? <CustomOverlayLoader /> : renderRenderTabPanels()} */}
        {renderRenderTabPanels()}
      </PageLayout>
    </>
  );
}
