import CustomTag from "@/src/components/common/CustomTag";
import HighlightedText from "@/src/components/common/HighlightedText";
import CustomTable from "@/src/components/table/CustomTable";
import { useAppSelector } from "@/src/hooks/useAppSelector";
import { getProjectsState, resetState } from "@/src/store/slices/projectsSlice";
import { getTypesState } from "@/src/store/slices/typesSlice";
import { dateFormat } from "@/src/utils/constants";
import { ProjectStatusEnum, TagTypeEnum } from "@/src/utils/enums";
import routePaths from "@/src/utils/routePaths";
import { getConsistentSpacing } from "@/src/utils/theme-helpers";
import SectionLayout from "@components/layout/SectionLayout";
import { Button, Flex, TableProps, Typography } from "antd";
import dayjs from "dayjs";
import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";

import { getAllProjects, updateUserAccessById } from "@/src/apis/projectApis";
import { getAllProjectTypes } from "@/src/apis/projectTypeApis";
import CustomAlert from "@/src/components/common/CustomAlert";
import CustomFormButtons from "@/src/components/form/CustomFormButtons";
import CustomTableFilters, {
  CustomFiltersType,
} from "@/src/components/table/CustomTableFilters";
import HighlightedProjectTypeName from "@/src/features/projects/components/HighlightedProjectTypeName";
import { useAppDispatch } from "@/src/hooks/useAppDispatch";
import { useDebouncedCallback } from "@/src/hooks/useDebouncedCallback";
import { Project } from "@/src/utils/types";
import { EyeOutlined } from "@ant-design/icons";

type ProjectAccessListProps = {
  internalUserId: string;
  setSelectedUser: (selectedUser: string[]) => void;
  selectedUser: string[];
};
export default function ProjectAccessList({
  internalUserId,
  setSelectedUser,
  selectedUser,
}: ProjectAccessListProps) {
  const [searchTerm, setSearchTerm] = useState("");
  const [hasMadeApiCall, setHasMadeApiCall] = useState(false);

  const navigate = useNavigate();
  const dispatch = useAppDispatch();
  const {
    projectsData,
    isLoading,
    totalCount,
    currentPage: projectsCurrentPage,
    pageSize: projectsPageSize,
    successMessage,
    reqError,
    resError,
  } = useAppSelector(getProjectsState);

  const { typesData: typesData } = useAppSelector(getTypesState);
  const [page, setPage] = useState<number>(projectsCurrentPage);
  const [pageSize, setPageSize] = useState(projectsPageSize);
  const [isFirstCall, setIsFirstCall] = useState(false);
  const [accessState, setAccessState] = useState({
    isLoading: false,
    isSuccess: false,
    error: "",
  });
  const [selectedRowKeys, setSelectedRowKeys] = useState<React.Key[]>(
    (projectsData || []).filter((f) => f.isAccessible).map((m) => m.id)
  );

  const rowSelection: TableProps<Project>["rowSelection"] = {
    selectedRowKeys,
    columnTitle: "Access",
    onChange: (selectedKeys) => {
      setSelectedRowKeys(selectedKeys);
      setSelectedUser(selectedKeys as string[]);
    },
  };

  // useEffect(() => {
  //   setSelectedRowKeys([]);
  // }, []);

  useEffect(() => {
    dispatch(getAllProjectTypes());
  }, [dispatch]);

  useEffect(() => {
    const error = resError || reqError || "";

    if (!error) return;

    setAccessState((prev) => ({
      ...prev,
      error,
    }));
  }, [resError, reqError]);

  const handleUpdateUserAccess = async () => {
    dispatch(resetState());
    setAccessState((prev) => ({
      ...prev,
      isLoading: false,
      error: "",
    }));

    try {
      setAccessState((prev) => ({
        ...prev,
        isLoading: true,
      }));

      setHasMadeApiCall(true);
      const payload = {
        projectIds: selectedRowKeys as string[],
      };

      const res = await dispatch(
        updateUserAccessById({ payload, userId: internalUserId })
      ).unwrap();

      setAccessState((prev) => ({
        ...prev,
        isSuccess: res?.isSuccess || false,
      }));
    } catch (err) {
      console.error(err);

      // setAccessState((prev) => ({
      //   ...prev,
      //   error: err?.message || ""
      // }))
    } finally {
      setAccessState((prev) => ({
        ...prev,
        isLoading: false,
      }));
    }
  };

  useEffect(() => {
    dispatch(resetState());
    // formik.resetForm();
  }, [selectedRowKeys]);

  const allTypesOption = useMemo(
    () => ({
      value: "all-types",
      label: "All Types",
    }),
    []
  );

  const memoizedTypeOptions = useMemo(() => {
    const mappedTypes =
      typesData?.map((type) => ({
        value: type.id,
        label: type.name,
      })) || [];

    return [allTypesOption, ...mappedTypes];
  }, [allTypesOption, typesData]);

  const [filters, setFilters] = useState<CustomFiltersType>({
    type: { value: allTypesOption?.value || 0, options: memoizedTypeOptions },
  });

  // useEffect(() => {
  //   setFilters({
  //     type: { value: allTypesOption?.value || 0, options: memoizedTypeOptions },
  //   });
  // }, [typesData]);

  useEffect(() => {
    // Only update filters if the options actually change
    setFilters((prevFilters) => {
      const currentOptions = prevFilters.type.options;
      const newOptions = memoizedTypeOptions;

      // Check if options are different (by comparing their length or individual items)
      const optionsChanged =
        currentOptions.length !== newOptions.length ||
        currentOptions.some(
          (option, index) => option.value !== newOptions[index]?.value
        );

      // If options are the same, return the previous filters to avoid unnecessary state update
      if (!optionsChanged) {
        return prevFilters;
      }

      // If options have changed, update the filters
      return {
        ...prevFilters,
        type: {
          ...prevFilters.type,
          options: newOptions,
        },
      };
    });
  }, [memoizedTypeOptions]);

  const columns: TableProps<Project>["columns"] = [
    {
      title: "Project Name",
      dataIndex: "Name",
      key: "Name",
      sorter: (a, b) => a.name?.localeCompare(b.name),
      render: (_, record) => (
        <Typography.Title
          level={5}
          style={{ fontSize: getConsistentSpacing(1.75), margin: 0 }}
        >
          <HighlightedText text={record.name} searchTerm={searchTerm} />
        </Typography.Title>
      ),
    },
    {
      title: "Project Type",
      dataIndex: "projectTypeId",
      key: "projectTypeId",
      sorter: (a, b) => {
        const typeA =
          typesData?.find((f) => f?.id === a?.projectTypeId)?.name || "";
        const typeB =
          typesData?.find((f) => f?.id === b?.projectTypeId)?.name || "";
        return typeA.localeCompare(typeB);
      },
      render: (projectTypeId) => (
        <HighlightedProjectTypeName
          searchTerm={searchTerm}
          projectTypeId={projectTypeId}
        />
      ),
    },
    {
      title: "Status",
      dataIndex: "ProjectStatus",
      key: "ProjectStatus",
      sorter: (a, b) => a.status - b.status,
      render: (_, record) => (
        <CustomTag
          isWide
          type={
            record.status === ProjectStatusEnum.OPEN
              ? TagTypeEnum.GREEN
              : TagTypeEnum.ORANGE
          }
          status={record.status}
        />
      ),
    },
    {
      title: "Date Opened",
      dataIndex: "createdDate",
      key: "createdDate",
      sorter: (a, b) =>
        dayjs(a.createdDate).unix() - dayjs(b.createdDate).unix(),
      render: (_, record) => dayjs(record.createdDate).format(dateFormat),
    },
    {
      title: "",
      dataIndex: "",
      key: "",
      render: (_, record) => (
        <Button
          className="hover:!fill-primary"
          icon={<EyeOutlined className="text-lg" />}
          onClick={() =>
            navigate(`${routePaths.PROJECTS_DETAILS_BY_ID}/${record?.id}`)
          }
        >
          View
        </Button>
      ),
    },
  ];

  const handleGetResults = useDebouncedCallback(getResults, 100);

  async function getResults() {
    const type =
      filters.type?.value !== allTypesOption?.value
        ? filters?.type?.value?.toString()
        : undefined;

    const response = await dispatch(
      getAllProjects({
        pageNumber: page,
        pageSize,
        search: searchTerm || undefined,
        type,
        userId: internalUserId,
      })
    ).unwrap();

    const accessibleProjectIds =
      response?.projects
        ?.filter((f) => f?.isAccessible || false)
        ?.map((m) => m?.id || "") || [];
    setSelectedRowKeys((prev) => {
      const filtered = prev?.filter((f) => selectedUser?.includes(f as string));
      const sameIdsNotAllowed = filtered?.filter(
        (f) => !accessibleProjectIds?.includes(f as string)
      );
      return [...accessibleProjectIds, ...sameIdsNotAllowed];
    });
  }

  const handleSearch = () => {
    handleGetResults();
  };

  useEffect(() => {
    if (filters) {
      handleGetResults();
    }
  }, [filters]);

  useEffect(() => {
    if (
      isFirstCall ||
      projectsCurrentPage !== page ||
      projectsPageSize !== pageSize
    ) {
      handleGetResults();
      if (isFirstCall) {
        setIsFirstCall(false);
      }
    }
  }, [page, pageSize, isFirstCall]);

  return (
    <>
      <SectionLayout>
        <CustomTable
          data={projectsData || []}
          columns={columns || []}
          hasCursorPointer
          hasRowSelection
          rowSelection={rowSelection}
          searchTerm={searchTerm}
          setSearchTerm={setSearchTerm}
          handleSearch={handleSearch}
          isLoading={isLoading}
          totalCount={totalCount}
          page={page}
          setPage={setPage}
          pageSize={pageSize}
          setPageSize={setPageSize}
          filterElements={
            <CustomTableFilters filters={filters} setFilters={setFilters} />
          }
          // hasSearch={false}
          hasPagination={true}
        />
        {hasMadeApiCall && (accessState.error || successMessage) && (
          <CustomAlert
            message={accessState.error || successMessage || ""}
            type={successMessage ? "success" : "error"}
          />
        )}
        <Flex justify="flex-end" className="gap-4">
          <CustomFormButtons
            isSuccess={accessState.isSuccess}
            navigationRoute={routePaths.INTERNAL_USERS}
            // hasValidationErrors={false}
            hasHttpErrors={Boolean(accessState.error)}
            handleSubmit={() => handleUpdateUserAccess()}
          />
        </Flex>
      </SectionLayout>
    </>
  );
}
