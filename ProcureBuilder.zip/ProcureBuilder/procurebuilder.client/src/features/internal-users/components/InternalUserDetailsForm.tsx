import { useEffect, useRef, useState } from "react";
import { useLocation, useNavigate, useParams } from "react-router-dom";

import { yupResolver } from "@hookform/resolvers/yup";
import {
  Button,
  Col,
  Flex,
  Form,
  Input,
  Radio,
  Row,
  Select,
  Typography,
} from "antd";
import { Controller, Resolver, useForm } from "react-hook-form";
import PhoneInput from "react-phone-input-2";

import "react-phone-input-2/lib/style.css";

import {
  createInternalUser,
  editInternalUser,
  resendingInvite,
} from "@/src/apis/internalUsersApis";
import CreatedByUserBadge from "@/src/components/common/CreatedByUserBadge";
import CustomAlert from "@/src/components/common/CustomAlert";
import { useAppSelector } from "@/src/hooks/useAppSelector";
import {
  getInternalUsersState,
  resetState,
} from "@/src/store/slices/internalUsersSlice";
import { getUserFullName } from "@/src/store/slices/userSlice";
import { UserRoleEnum, UserStatus } from "@/src/utils/enums";
import { InternalUser } from "@/src/utils/types";

import CustomFormLabel from "@components/common/CustomFormLabel";
import SectionLayout from "@components/layout/SectionLayout";

import { useAppDispatch } from "@hooks/useAppDispatch";

import routePaths, { routePathsWithParams } from "@utils/routePaths";
import { getConsistentSpacing } from "@utils/theme-helpers";

import { getAllProjectManagers } from "@/src/apis/projectManagersApis";
import {
  deleteInternalUser,
  getAllUsersSummaryList,
} from "@/src/apis/userApis";
import useAuthorization from "@/src/hooks/useAuthorization";
import { validationSchema } from "./InternalUserValidationForm";
// import { internalUserRoleOptions } from "@/src/utils/constants";
// import { number } from "yup";

type InternalUserDetailsFormProps = {
  internalUser?: InternalUser | null;
  handleCancelForm?: () => void;
  setInternalUserData: (data: InternalUser) => void;
};
// type FormattedPhoneNumberType = {
//   phoneNumber?: string | null;
//   cellPhoneNumber?: string | null;
// };
type FormValues = Omit<
  InternalUser,
  "isEmailNotificationsEnabled" | "isTextNotificationsEnabled"
> & {
  emailNotificationsEnabled: boolean;
  textNotificationsEnabled: boolean;
};

export default function InternalUserDetailsForm({
  internalUser,
  setInternalUserData,
}: //   handleCancelForm,
InternalUserDetailsFormProps) {
  const { isSuperAdminAuthorized } = useAuthorization();
  const [inviteSending, setInviteSending] = useState(false);
  const [inviteSendMessage, setInviteSendMessage] = useState<any | boolean>(
    false
  );

  const { internalUserId } = useParams();

  const { successMessage, resError } = useAppSelector(getInternalUsersState);
  const userFullName = useAppSelector(getUserFullName);
  const { isCominedAdminAuthorized: isCombinedAdminAuthorized } =
    useAuthorization();
  const dispatch = useAppDispatch();
  const navigate = useNavigate();
  const location = useLocation();
  const phoneInputRef = useRef<HTMLInputElement>(null);
  const cellPhoneInputRef = useRef<HTMLInputElement>(null);

  const [actionType, setActionType] = useState<"save" | "saveAndClose" | "">(
    ""
  );

  const [isDeleting, setIsDeleting] = useState(false);
  const userRolesOptions = [
    { label: "Select Role", value: null },
    ...Object.entries(UserRoleEnum)
      .filter(([_, value]) => {
        if (value === UserRoleEnum.Admin) {
          return isSuperAdminAuthorized();
        }
        return typeof value === "number";
      })
      .map(([key, value]) => ({
        value: value,
        label: key,
      })),
  ];

  type FieldType = InternalUser;

  const getDefaultValues = (internalUser: InternalUser | null) => {
    const internalUserRoles =
      typeof internalUser?.role === "string"
        ? userRolesOptions.find(
            (data) =>
              data?.label?.toLowerCase()?.trim() ===
              (internalUser?.role as string)?.toLowerCase()?.trim()
          )?.value
        : internalUser?.role;

    return {
      firstName: internalUser?.firstName || "",
      lastName: internalUser?.lastName || "",
      phoneNumber: internalUser?.phoneNumber || "",
      cellNumber: internalUser?.cellNumber || "",
      email: internalUser?.email || "",
      role: internalUserRoles || 0,
      emailNotificationsEnabled:
        internalUser?.isEmailNotificationsEnabled || false,
      textNotificationsEnabled:
        internalUser?.isTextNotificationsEnabled || false,
      lastModifiedBy: internalUser?.lastModifiedBy || "",
      lastModifiedDate: internalUser?.lastModifiedDate || null,
      modifiedDate: internalUser?.modifiedDate || null,
    };
  };

  const {
    control,
    handleSubmit,
    reset,
    formState: { isSubmitting, errors },
    register,
  } = useForm<FormValues>({
    resolver: yupResolver(validationSchema) as unknown as Resolver<FormValues>,
    defaultValues: getDefaultValues(internalUser || null),
    mode: "all", // You can change the validation mode
  });

  // console.log(internalUser);

  const onSubmit = async (data: FormValues) => {
    console.log("data", data);

    const payload = {
      ...data,
      isEmailNotificationsEnabled: data.emailNotificationsEnabled, // Did this due to typescript errors
      isTextNotificationsEnabled: data.textNotificationsEnabled,
      role: Number(data.role) || 0,
      createdBy: userFullName,
    };

    try {
      if (internalUserId) {
        const response = await dispatch(
          editInternalUser({
            firstName: data.firstName,
            lastName: data.lastName,
            phoneNumber: data.phoneNumber,
            cellNumber: data.cellNumber,
            modifiedBy: internalUser?.modifiedBy || "",
            id: internalUser?.userId || internalUser?.id || "",
            role: Number(data.role) || 0,
            isEmailNotificationsEnabled: data.emailNotificationsEnabled,
            isTextNotificationsEnabled: data.textNotificationsEnabled,
          })
        ).unwrap();
        if (response.isSuccess) {
          // reset(getDefaultValues(response));
          setInternalUserData(response);
          if (actionType === "saveAndClose") {
            navigate(routePaths.INTERNAL_USERS);
          }
        }
      } else {
        const response = await dispatch(createInternalUser(payload)).unwrap();
        if (response.isSuccess) {
          // reset(getDefaultValues(response));
          setInternalUserData(response);
          if (actionType === "saveAndClose") {
            navigate(routePaths.INTERNAL_USERS);
            return;
          }
          navigate(
            `${routePaths.INTERNAL_USERS_EDIT_BY_ID}/${response?.userId}`
          );
        }
      }
    } catch (err) {
      console.log(err);
    } finally {
      dispatch(getAllProjectManagers());
      dispatch(
        getAllUsersSummaryList({
          roles: [
            UserRoleEnum.Engineer,
            UserRoleEnum.Fieldcraft,
            UserRoleEnum.Superintendent,
            UserRoleEnum.Admin,
          ],
        })
      );
    }
  };
  const resendHandler = async (userId: string) => {
    try {
      setInviteSending(true);
      const response = await resendingInvite(userId);

      if (response.isSuccess) {
        setInviteSendMessage({
          success: true,
          message: "Invitation has been sent successfully.",
        });
        setTimeout(() => {
          setInviteSendMessage({ success: true, message: "" });
        }, 5000);
      } else {
        setInviteSendMessage({
          success: false,
          message: response?.errors?.[0],
        });
        setTimeout(() => {
          setInviteSendMessage(false);
        }, 5000);
      }
    } catch (err) {
      setInviteSendMessage({
        success: false,
        message: "Something went wrong!",
      });
      setTimeout(() => {
        setInviteSendMessage(false);
      }, 5000);
    } finally {
      setInviteSending(false);
    }
  };

  const handleClose = () => {
    const previousPath = location?.state?.previousPath || "";
    if (previousPath) {
      navigate(previousPath);
    } else {
      navigate(routePathsWithParams.INTERNAL_USERS);
    }
  };

  const handleDelete = async () => {
    try {
      setIsDeleting(true);
      await dispatch(
        deleteInternalUser({ userId: internalUser?.id || "" })
      ).unwrap();
      navigate(routePaths.INTERNAL_USERS);
    } catch (err) {
      console.log(err);
    } finally {
      setIsDeleting(false);
    }
  };

  useEffect(() => {
    if (internalUser?.id) {
      const internalUserRoles =
        typeof internalUser?.role === "string"
          ? userRolesOptions?.find(
              (data) =>
                data?.label?.toLowerCase()?.trim() ===
                (internalUser?.role as string)?.toLowerCase()?.trim()
            )?.value
          : internalUser?.role;
      reset({
        firstName: internalUser.firstName || "",
        lastName: internalUser.lastName || "",
        phoneNumber: internalUser.phoneNumber || "",
        cellNumber: internalUser.cellNumber || "",
        email: internalUser.email || "",
        role: internalUserRoles,
        emailNotificationsEnabled:
          internalUser?.isEmailNotificationsEnabled || false,
        textNotificationsEnabled:
          internalUser.isTextNotificationsEnabled || false,
        lastModifiedBy: internalUser.lastModifiedBy || "",
        lastModifiedDate: internalUser.lastModifiedDate || null,
        modifiedDate: internalUser.modifiedDate || null,
      });
    }
  }, [internalUser, reset]);

  useEffect(() => {
    dispatch(resetState());
  }, []);

  useEffect(() => {
    const timeoutId = setTimeout(() => {
      if (
        internalUser &&
        phoneInputRef?.current &&
        cellPhoneInputRef?.current
      ) {
        phoneInputRef.current.focus();
        cellPhoneInputRef.current.focus();
        const clickEvent = new MouseEvent("click", {
          bubbles: true,
          cancelable: true,
          view: window,
        });
        phoneInputRef?.current.dispatchEvent(clickEvent);
        cellPhoneInputRef?.current?.dispatchEvent(clickEvent);
      }
    }, 100); // Adjust the delay as needed

    return () => clearTimeout(timeoutId);
  }, [phoneInputRef, isSubmitting, cellPhoneInputRef, internalUser]);

  useEffect(() => {
    if (location.pathname === routePaths.INTERNAL_USERS_NEW) {
      console.log("resetting");
      reset(getDefaultValues(null));
      dispatch(resetState());
    }
  }, [location.pathname]);

  return (
    <>
      <SectionLayout>
        <Form
          onFinish={handleSubmit(onSubmit)}
          layout="vertical"
          autoComplete="off"
        >
          <Row gutter={parseInt(getConsistentSpacing(2))}>
            <Col xs={24} style={{ marginBottom: getConsistentSpacing(2) }}>
              <Typography.Title level={5}>Overview</Typography.Title>
            </Col>

            {/* First Name */}
            <Col xs={12}>
              <Controller
                name="firstName"
                control={control}
                render={({ field, fieldState }) => (
                  <Form.Item<FieldType>
                    label={<CustomFormLabel text="First Name" required />}
                    labelAlign="right"
                    initialValue={field.value}
                    validateStatus={
                      !field.value && fieldState.error ? "error" : ""
                    }
                    help={
                      !field.value && fieldState.error
                        ? fieldState.error.message
                        : ""
                    }
                  >
                    <Input {...field} size="large" placeholder="First Name" />
                  </Form.Item>
                )}
              />
            </Col>

            {/* Last Name */}

            <Col xs={12}>
              <Controller
                name="lastName"
                control={control}
                render={({ field, fieldState }) => (
                  <Form.Item<FieldType>
                    label={<CustomFormLabel text="Last Name" required />}
                    labelAlign="right"
                    validateStatus={fieldState.error ? "error" : ""}
                    help={fieldState?.error?.message}
                  >
                    <Input {...field} size="large" placeholder="Last Name" />
                  </Form.Item>
                )}
              />
            </Col>

            {/* Email */}
            <Col xs={12}>
              <Controller
                name="email"
                control={control}
                render={({ field, fieldState }) => (
                  <Form.Item<FieldType>
                    label={<CustomFormLabel text="Email" required />}
                    labelAlign="right"
                    tooltip="The email you input here will receive an invitation to set up their account."
                    validateStatus={fieldState.error ? "error" : ""}
                    help={fieldState?.error?.message || ""}
                  >
                    <Input
                      {...field}
                      size="large"
                      placeholder="Email"
                      disabled={Boolean(internalUserId)}
                    />
                  </Form.Item>
                )}
              />
            </Col>

            {/* Phone */}
            <Col xs={12}>
              <Form.Item<FieldType>
                label={<CustomFormLabel text="Phone" />}
                labelAlign="right"
                validateStatus={errors.phoneNumber ? "error" : ""}
                help={errors.phoneNumber ? errors.phoneNumber.message : ""}
              >
                <Controller
                  name="phoneNumber"
                  control={control}
                  render={({ field }) => (
                    <div ref={register("phoneNumber").ref}>
                      <PhoneInput
                        country={"us"}
                        value={field.value}
                        onChange={(phoneNumber) => {
                          field.onChange(phoneNumber);
                        }}
                        autoFormat
                        inputProps={{
                          id: "phoneNumbers",
                          ref: phoneInputRef,
                        }}
                      />
                    </div>
                  )}
                />
              </Form.Item>
            </Col>

            {/* Cell Phone */}
            <Col xs={12}>
              <Form.Item<FieldType>
                label={<CustomFormLabel text="Cell Phone" />}
                labelAlign="right"
                validateStatus={errors.cellNumber ? "error" : ""}
                help={errors.cellNumber ? errors.cellNumber.message : ""}
              >
                <Controller
                  name="cellNumber"
                  control={control}
                  render={({ field }) => (
                    <div ref={register("cellNumber").ref}>
                      <PhoneInput
                        country={"us"}
                        value={field.value}
                        autoFormat
                        onChange={(cellNumber) => {
                          field.onChange(cellNumber);
                        }}
                        inputProps={{
                          id: "cellNumbers",
                          ref: cellPhoneInputRef,
                        }}
                      />
                    </div>
                  )}
                />
              </Form.Item>
            </Col>

            {/* Role */}
            <Col xs={12}>
              <Controller
                name="role"
                control={control}
                render={({ field, fieldState }) => (
                  console.log("field", field),
                  (
                    <Form.Item<FieldType>
                      label={<CustomFormLabel text="Role" required />}
                      labelAlign="right"
                      validateStatus={
                        !field.value && fieldState.error ? "error" : ""
                      }
                      help={
                        !field.value && fieldState.error
                          ? fieldState.error.message
                          : ""
                      }
                    >
                      <Select
                        disabled={!isCombinedAdminAuthorized()}
                        {...field}
                        size="large"
                        onChange={(value) => field.onChange(value)}
                        options={userRolesOptions}
                        placeholder="Select Role"
                        showSearch
                        allowClear
                      />
                    </Form.Item>
                  )
                )}
              />
            </Col>

            {/* Email Notifications */}
            <Col xs={12} className="mt-4">
              <Controller
                name="emailNotificationsEnabled"
                control={control}
                render={({ field }) => (
                  <Form.Item
                    layout="vertical"
                    label={
                      <CustomFormLabel text="Email with new notifications?" />
                    }
                  >
                    <Radio.Group
                      {...field}
                      size="large"
                      value={field.value}
                      onChange={(e) => field.onChange(e.target.value)}
                    >
                      <Radio value={true}> Yes </Radio>
                      <Radio value={false}> No </Radio>
                    </Radio.Group>
                  </Form.Item>
                )}
              />
            </Col>

            {/* Text Notifications */}
            <Col xs={12} className="mt-4">
              <Controller
                name="textNotificationsEnabled"
                control={control}
                render={({ field }) => (
                  <Form.Item
                    layout="vertical"
                    label={
                      <CustomFormLabel text="Text with new notifications?" />
                    }
                  >
                    <Radio.Group
                      {...field}
                      size="large"
                      value={field.value}
                      onChange={(e) => field.onChange(e.target.value)}
                    >
                      <Radio value={true}> Yes </Radio>
                      <Radio value={false}> No </Radio>
                    </Radio.Group>
                  </Form.Item>
                )}
              />
            </Col>
          </Row>
          {(resError || successMessage) && (
            <CustomAlert
              message={resError || successMessage || ""}
              type={successMessage ? "success" : "error"}
            />
          )}
          {inviteSendMessage?.message && (
            <CustomAlert
              message={inviteSendMessage?.message}
              type={inviteSendMessage?.success ? "success" : "error"}
            />
          )}

          <Flex justify="flex-end" className="gap-4">
            <Button
              disabled={isSubmitting}
              type="default"
              onClick={handleClose}
            >
              Cancel
            </Button>
            {internalUser?.id && (
              <Button
                loading={isDeleting}
                disabled={isSubmitting || isDeleting}
                type="default"
                onClick={handleDelete}
              >
                {isDeleting ? "Deleting.." : "Delete"}
              </Button>
            )}

            <Button
              loading={actionType === "save" && isSubmitting}
              disabled={isSubmitting}
              type="primary"
              htmlType="submit"
              onClick={() => setActionType("save")}
            >
              {actionType === "save" && isSubmitting ? "Saving.." : "Save"}
            </Button>

            <Button
              loading={actionType === "saveAndClose" && isSubmitting}
              disabled={isSubmitting}
              type="primary"
              htmlType="submit"
              onClick={() => setActionType("saveAndClose")}
            >
              {actionType === "saveAndClose" && isSubmitting
                ? "Saving and closing.."
                : "Save & Close"}
            </Button>
            {internalUser?.status == UserStatus.InvitePending &&
              internalUserId && (
                <Button
                  loading={inviteSending}
                  disabled={inviteSendMessage?.success}
                  type="primary"
                  htmlType="button"
                  onClick={() => resendHandler(internalUserId)}
                >
                  {inviteSending ? "Resending Invite.." : "Resend Invite"}
                </Button>
              )}
          </Flex>
          {internalUser?.id && (
            <Flex justify="flex-end" className="mt-4">
              <CreatedByUserBadge
                userName={internalUser?.createdBy}
                date={internalUser?.createdDate}
              />
            </Flex>
          )}
        </Form>
      </SectionLayout>
    </>
  );
}
