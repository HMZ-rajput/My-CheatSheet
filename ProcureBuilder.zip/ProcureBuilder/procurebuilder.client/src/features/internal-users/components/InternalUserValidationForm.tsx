import { phoneNumberLengthRegex } from "@/src/utils/constants";
import * as Yup from "yup";
export const validationSchema = Yup.object().shape({
  firstName: Yup.string().required("First Name is required."),
  lastName: Yup.string().required("Last Name is required."),
  email: Yup.string()
    .required("Email is required.")
    .email("Invalid email format.")
    .matches(
      /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/,
      "Invalid email format. Must include a domain at the end."
    ),
  role: Yup.string().required("Role is required."),
  phoneNumber: Yup.string().optional().trim().matches(phoneNumberLengthRegex, {
    message: "Phone Number is not valid in the US",
    excludeEmptyString: true,
  }),
  cellNumber: Yup.string().optional().trim().matches(phoneNumberLengthRegex, {
    message: "Cell Phone Number is not valid in the US",
    excludeEmptyString: true,
  }),
});
