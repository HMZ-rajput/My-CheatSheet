import { getAllInternalUsers } from "@/src/apis/internalUsersApis";
import HighlightedText from "@/src/components/common/HighlightedText";
import { InternalUserStatus } from "@/src/components/common/InternalUserStatus";
import CustomTable from "@/src/components/table/CustomTable";
import CustomTableFilters, {
  CustomFilterDataType,
  CustomFiltersType,
} from "@/src/components/table/CustomTableFilters";
import { useAppDispatch } from "@/src/hooks/useAppDispatch";
import useAuthorization from "@/src/hooks/useAuthorization";
import useSyncFilters from "@/src/hooks/useSyncFilters";
import { getInternalUsersState } from "@/src/store/slices/internalUsersSlice";
import {
  allInternalUserRoleOption,
  allInternalUserStatusOption,
  internalUserRoleOptionsWithAll,
  internalUserStatusOptionsWithAll,
} from "@/src/utils/constants";
import { UserRoleEnum } from "@/src/utils/enums";
import { getInternalUserStatus } from "@/src/utils/helper";
import routePaths from "@/src/utils/routePaths";
import { InternalUser } from "@/src/utils/types";
import CustomIcon from "@components/common/CustomIcon";
import SectionLayout from "@components/layout/SectionLayout";
import { useAppSelector } from "@hooks/useAppSelector";
import { getConsistentSpacing } from "@utils/theme-helpers";
import { Button, TableProps, Typography } from "antd";
import { useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";

type InternalUsersListProps = {
  internalUsers?: InternalUser[] | null;

  hasPagination?: boolean;
  hasDetailedColumns?: boolean;
  hasSearch?: boolean;
  hasFilters?: boolean;
  hasBorders?: boolean;
};
export default function InternalUsersList({
  hasPagination = true,
  hasSearch = true,
  hasFilters = true,
  hasBorders = true,
}: InternalUsersListProps) {
  const dispatch = useAppDispatch();
  const navigate = useNavigate();
  const { isAdminAuthorized } = useAuthorization();

  const isFirstCallComplete = useRef(false);
  // const [isFirstCall, setIsFirstCall] = useState(false);
  const {
    internalUsersData,
    isLoading,
    totalCount,
    currentPage: internalUsersCurrentPage,
    pageSize: internalUsersPageSize,
  } = useAppSelector(getInternalUsersState);

  const [page, setPage] = useState<number>(internalUsersCurrentPage);
  const [pageSize, setPageSize] = useState(internalUsersPageSize);
  const { searchParams } = useSyncFilters();
  const [searchTerm, setSearchTerm] = useState(
    searchParams.get("searchTerm") || ""
  );
  const [hasSearched, setHasSearched] = useState(false);
  const [previousSearchTerm, setPreviousSearchTerm] = useState(
    searchParams.get("searchTerm") || ""
  );
  const [lastSearchTimestamp, setLastSearchTimestamp] = useState(0);

  useEffect(() => {
    setLastSearchTimestamp(Date.now());
  }, [previousSearchTerm]);

  const getInternalUserRoleOptions = (isUser: boolean) => {
    return isUser
      ? internalUserRoleOptionsWithAll.filter(
          (option) => option.value !== UserRoleEnum.Admin
        )
      : internalUserRoleOptionsWithAll;
  };

  const [filters, setFilters] = useState<CustomFiltersType>({
    status: {
      value: allInternalUserStatusOption?.value || 0,
      options: internalUserStatusOptionsWithAll,
      className: "!min-w-[148px]",
      dataType: CustomFilterDataType.NUM,
    },
    role: {
      value: allInternalUserRoleOption?.value || 0,
      options: getInternalUserRoleOptions(isAdminAuthorized()),
      className: "!min-w-[158px]",
      dataType: CustomFilterDataType.NUM,
    },
  });

  const navigateToEditPage = (data: InternalUser) => {
    const path = `${routePaths.INTERNAL_USERS_EDIT_BY_ID}/${data?.id}`;
    const hasParams = new URLSearchParams(location.search).size > 0;

    if (hasParams) {
      navigate(path, {
        state: {
          previousPath: `${location.pathname}${location.search}`,
        },
      });
    } else {
      navigate(path);
    }
  };

  const columns: TableProps<InternalUser>["columns"] = [
    {
      title: "Name",
      dataIndex: "fullName",
      key: "fullName",
      sorter: (a, b) => a.fullName?.localeCompare(b.fullName),
      render: (fullName) => (
        <Typography.Title
          level={5}
          style={{ fontSize: getConsistentSpacing(1.75), margin: 0 }}
        >
          <HighlightedText text={fullName} searchTerm={searchTerm} />
        </Typography.Title>
      ),
    },
    {
      title: "Role",
      dataIndex: "role",
      key: "role",
      sorter: (a, b) =>
        (a.role as unknown as string)?.localeCompare(
          b.role as unknown as string
        ),
      render: (role) => <HighlightedText text={role} searchTerm={searchTerm} />,
    },
    {
      title: "Email",
      dataIndex: "email",
      key: "email",
      sorter: (a, b) => a.fullName?.localeCompare(b.fullName),
      render: (email) => (
        <HighlightedText text={email} searchTerm={searchTerm} />
      ),
    },
    {
      title: "Phone",
      dataIndex: "phoneNumber",
      key: "phoneNumber",
      sorter: (a, b) => a.phoneNumber?.localeCompare(b.phoneNumber),
      render: (phoneNumber) => (
        <HighlightedText text={phoneNumber} searchTerm={searchTerm} />
      ),
    },
    {
      title: "Status",
      dataIndex: "status",
      key: "status",
      render: (status) => {
        const { iconType, badgeType } = getInternalUserStatus(status);
        return (
          <Typography
            style={{ fontSize: getConsistentSpacing(1.75), margin: 0 }}
          >
            <InternalUserStatus
              badgeIconType={iconType}
              badgeType={badgeType}
            />
          </Typography>
        );
      },
    },
    {
      title: "",
      dataIndex: "",
      key: "actions",
      render: (_, record) => (
        <Button
          shape="circle"
          className="hover:!fill-primary"
          icon={<CustomIcon type="edit" />}
          onClick={() => navigateToEditPage(record)}
        />
      ),
    },
  ];

  function handleGetResults(pageNumber?: number) {
    const status =
      filters.status?.value !== allInternalUserStatusOption?.value
        ? (filters?.status?.value as number)
        : undefined;

    const role =
      filters.role?.value !== allInternalUserRoleOption?.value
        ? (filters?.role?.value as number)
        : undefined;

    dispatch(
      getAllInternalUsers({
        pageNumber: pageNumber || page,
        pageSize,
        search: searchTerm || undefined,
        status,
        role,
      })
    );
  }

  function resetPaginationAndGetFirstPageResults() {
    if (isFirstCallComplete?.current === true) {
      if (filters) {
        setPage(1);
      }

      handleGetResults(1);
    } else {
      handleGetResults();
    }
  }

  useEffect(() => {
    if (!hasSearched) return;
    const timer = setTimeout(() => {
      if (searchTerm === "" && previousSearchTerm !== "") {
        resetPaginationAndGetFirstPageResults();
        setPreviousSearchTerm(searchTerm);
      }
    }, 500);

    return () => {
      clearTimeout(timer);
    };
  }, [searchTerm, hasSearched, previousSearchTerm]);

  const handleSearch = () => {
    if (searchTerm !== previousSearchTerm) {
      setHasSearched(true);
      resetPaginationAndGetFirstPageResults();
      setPreviousSearchTerm(searchTerm);
    }
  };

  useEffect(() => {
    resetPaginationAndGetFirstPageResults();
  }, [filters]);

  useEffect(() => {
    if (
      !isFirstCallComplete?.current ||
      internalUsersCurrentPage !== page ||
      internalUsersPageSize !== pageSize
    ) {
      handleGetResults();
      if (!isFirstCallComplete?.current) {
        setTimeout(() => {
          isFirstCallComplete.current = true;
        }, 1000);
      }
    }
  }, [page, pageSize]);

  return (
    <>
      <SectionLayout isHidden={!hasBorders}>
        <CustomTable
          data={internalUsersData || []}
          columns={columns || []}
          searchTerm={searchTerm}
          setSearchTerm={setSearchTerm}
          handleSearch={handleSearch}
          isLoading={isLoading}
          totalCount={totalCount}
          page={page}
          setPage={setPage}
          pageSize={pageSize}
          setPageSize={setPageSize}
          filterElements={
            hasFilters ? (
              <CustomTableFilters filters={filters} setFilters={setFilters} />
            ) : null
          }
          hasPagination={hasPagination}
          hasSearch={hasSearch}
          tableFilters={filters}
          setTableFilters={setFilters}
          lastSearchTimestamp={lastSearchTimestamp}
        />
      </SectionLayout>
    </>
  );
}
