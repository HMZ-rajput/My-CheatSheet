import { Button } from "antd";
// import ProjectsList from "@features/projects/components/ProjectsList";
import CustomIcon from "@components/common/CustomIcon";
import { getConsistentSpacing } from "@utils/theme-helpers";
import PageLayout from "@components/layout/PageLayout";
import { useNavigate } from "react-router-dom";
import routePaths from "@/src/utils/routePaths";
import PurchaseOrdersList from "../components/PurchaseOrdersList";
const PurchaseOrders = () => {
  const navigate = useNavigate();

  return (
    <>
      <PageLayout
        title="Purchase Orders"
        titleSibling={
          <Button
            size="large"
            type="primary"
            icon={
              <CustomIcon
                type="plus"
                className="fill-white"
                width={parseInt(getConsistentSpacing(3))}
                height={parseInt(getConsistentSpacing(3))}
              />
            }
            onClick={() => navigate(routePaths.PURCHASE_ORDERS_NEW)}
          >
            New Purchase Order
          </Button>
        }
      >
        <PurchaseOrdersList />
      </PageLayout>
    </>
  );
};

export default PurchaseOrders;
