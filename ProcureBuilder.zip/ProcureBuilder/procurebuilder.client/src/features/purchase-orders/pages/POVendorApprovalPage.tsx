import { getAllCompanyDetails } from "@/src/apis/companySettingsApis";
import {
  createPOApproval,
  downloadPOReport,
  getPOVendorApproveByPOId,
} from "@/src/apis/purchaseOrderApis";
import CustomAlert from "@/src/components/common/CustomAlert";
import CustomFormLabel from "@/src/components/common/CustomFormLabel";
import CustomIcon from "@/src/components/common/CustomIcon";
import CustomModal from "@/src/components/common/CustomModal";
import ProcureBuilderLogo from "@/src/components/common/ProcureBuilderLogo";
// import PurchaseOrderStatus from "@/src/components/common/PurchaseOrderStatus";
import SectionLayout from "@/src/components/layout/SectionLayout";
import { useAppDispatch } from "@/src/hooks/useAppDispatch";
import { useAppSelector } from "@/src/hooks/useAppSelector";
import { getCompanyState } from "@/src/store/slices/companySettingsSlice";
import { manuallyDownloadBlob } from "@/src/utils/api-helpers";
import { dateFormat } from "@/src/utils/constants";
import {
  ActionTypeEnum,
  ApprovalStatusEnum,
  AuthorizingEntityEnum,
  PoReportTypeEnum,
  PurchaseOrderStatusEnum,
} from "@/src/utils/enums";
import { convertToLocaleString } from "@/src/utils/helper";
// import { getPurchaseOrderStatus } from "@/src/utils/helper";
import {
  ActionTypeState,
  PurchaseOrder,
  PurchaseOrderMaterials,
} from "@/src/utils/types";
import {
  Button,
  DatePicker,
  Flex,
  Form,
  Input,
  InputNumber,
  Space,
  Table,
  TableProps,
  Typography,
} from "antd";
import dayjs from "dayjs";
import { useEffect, useState } from "react";
import { Controller, useForm } from "react-hook-form";
import { useParams } from "react-router-dom";

type PurchaseOrderRecipientTabTypeProps = {
  purchaseOrder?: PurchaseOrder | null;
};

const columns: TableProps<PurchaseOrderMaterials>["columns"] = [
  {
    title: "Material",
    dataIndex: "name",
    key: "name",
    sorter: (a, b) => a.name.localeCompare(b.name),
  },
  {
    title: "Cost Code",
    dataIndex: "costCode",
    key: "costCode",
    sorter: (a, b) => a.costCode.localeCompare(b.costCode),
  },
  {
    title: "Quantity",
    dataIndex: "quantity",
    key: "quantity",

    sorter: (a, b) => a.quantity - b.quantity,
  },
  {
    title: "Unit of Measurement",
    dataIndex: "unitOfMeasure",
    key: "unitOfMeasure",
    sorter: (a, b) => a.unitOfMeasure.localeCompare(b.unitOfMeasure),
  },
  {
    title: "Unit Rate",
    dataIndex: "unitRate",
    key: "unitRate",
    sorter: (a, b) => a.unitRate - b.unitRate,
    render: (unitRate) => <>${unitRate?.toLocaleString() || 0}</>,
  },
  {
    title: "Amount",
    dataIndex: "cost",
    key: "cost",
    sorter: (a, b) => a.cost - b.cost,
    render: (amount) => <>${amount?.toLocaleString() || 0}</>,
  },
  {
    title: "Max Material Lead Time",
    dataIndex: "maxMaterialLeadTime",
    key: "maxMaterialLeadTime",
    sorter: (a, b) => a.maxMaterialLeadTime - b.maxMaterialLeadTime,
    render: (maxMaterialLeadTime) => (
      <>
        {maxMaterialLeadTime > 0
          ? maxMaterialLeadTime === 1
            ? `${maxMaterialLeadTime} Week`
            : `${maxMaterialLeadTime} Weeks`
          : ""}{" "}
      </>
    ),
  },

  {
    title: "Max Submittal Lead Time",
    dataIndex: "maxSubmittalLeadTime",
    key: "maxSubmittalLeadTime",
    sorter: (a, b) => a.maxSubmittalLeadTime - b.maxSubmittalLeadTime,
    render: (maxSubmittalLeadTime) => (
      <>
        {maxSubmittalLeadTime > 0
          ? maxSubmittalLeadTime === 1
            ? `${maxSubmittalLeadTime} Week`
            : `${maxSubmittalLeadTime} Weeks`
          : ""}
      </>
    ),
  },
];

const POVendorApprovalPage = ({
  purchaseOrder,
}: PurchaseOrderRecipientTabTypeProps) => {
  const dispatch = useAppDispatch();
  const { purchaseOrderId } = useParams();

  const { companyData } = useAppSelector(getCompanyState);
  // P.O. = Purchase Order
  const [po, setPo] = useState<PurchaseOrder | null>(null);
  const [isCompleted, setIsCompleted] = useState(false);
  const [error, setError] = useState("");
  const [successMessage, setSuccessMessage] = useState("");
  const [isRejecting, setIsRejecting] = useState(false);
  const [isConfirmApprovalModal, setIsConfirmApprovalModal] = useState(false);

  const location = window.location;
  const query = new URLSearchParams(location.search);
  const rejected = query.get("rejected");

  const [actionType, setActionType] = useState<
    Pick<ActionTypeState, "approveAll" | "cancel" | "approveWithComments">
  >({
    approveAll: ActionTypeEnum.NEUTRAL,
    cancel: ActionTypeEnum.NEUTRAL,
    approveWithComments: ActionTypeEnum.NEUTRAL,
  });

  const {
    reset,
    handleSubmit,
    control,
    getValues,
    formState: { isSubmitting },
    trigger,
    setValue,
    clearErrors,
  } = useForm({
    defaultValues: {
      vendor: purchaseOrder?.vendor?.id || "",
      vendorAddress: purchaseOrder?.vendorAddress || "",
      approvalStatus: purchaseOrder?.approvalStatus || 0,
      signature: "",
      company: "",
      title: "",
      date: dayjs(new Date()),
      subTotal: 0,
      tax: 0,
      total: 0,
      taxPercentage: 0,
      deliveryNotes: purchaseOrder?.deliveryNotes || "",
      approvalComments: "",
    },
  });
  const onSubmit = async ({
    title,
    company,
    signature,
    date,
    approvalComments,
  }: {
    vendor: string;
    vendorAddress: string;
    signature: string;
    company: string;
    approvalStatus: number;
    title: string;
    date: dayjs.Dayjs;
    subTotal: number;
    tax: number;
    total: number;
    taxPercentage: number;
    deliveryNotes: string;
    approvalComments?: string;
  }) => {
    try {
      setSuccessMessage("");
      setError("");
      const response = await createPOApproval({
        purchaseOrderId: po?.id || "",
        authorizingEntity: AuthorizingEntityEnum.Vendor,
        company,
        dateSigned: date?.toISOString(),
        signature,
        approvalComments: approvalComments?.trim()
          ? approvalComments
          : undefined,
        status:
          actionType.approveAll === ActionTypeEnum.APPROVE_ALL ||
          actionType.approveWithComments ===
            ActionTypeEnum.APPROVE_WITH_COMMENTS
            ? ApprovalStatusEnum.Approved
            : ApprovalStatusEnum.Rejected,
        title,
      });
      if (response?.isSuccess) {
        setIsCompleted(() => true);
        setSuccessMessage("Purchase Order updated successfully.");
        setValue("approvalStatus", response?.purchaseOrderApprovalDTO?.status);
      } else {
        setError(response?.errors[0] || "An error occurred while processing.");
      }
      // setValue("approvalStatus",1);
      setIsConfirmApprovalModal(false);
      setValue("approvalComments", "");
    } catch (error) {
      setError("An error occurred while processing the data.");
    } finally {
      setValue("approvalComments", "");
    }
  };
  const getShouldDisableAll = () =>
    isCompleted || po?.status !== PurchaseOrderStatusEnum.VendorApprovalPending;
  // false;

  useEffect(() => {
    dispatch(getAllCompanyDetails());
    async function getPO() {
      setError("");

      if (!purchaseOrderId) return;

      const response = await getPOVendorApproveByPOId({
        purchaseOrderId,
      });
      const purchaseOrder = response?.purchaseOrder || null;
      if (!purchaseOrder || !response?.isSuccess) {
        setError("Something went wrong while fetching purchase order details.");
        return;
      }
      if (
        purchaseOrder?.status !== PurchaseOrderStatusEnum.VendorApprovalPending
      ) {
        const signature = purchaseOrder?.signature || "";
        const company = purchaseOrder?.company || "";
        const approvalTitle = purchaseOrder?.approvalTitle || "";

        reset((prev) => ({
          ...prev,
          signature,
          company,
          title: approvalTitle,
        }));
      }
      setPo(purchaseOrder);
      setValue("approvalStatus", purchaseOrder?.approvalStatus || 0);
    }

    getPO();
  }, [purchaseOrderId]);
  useEffect(() => {
    reset((prev) => ({
      ...prev,
      total: po?.total || 0,
      subTotal: po?.subTotal || 0,
      taxPercentage: po?.taxPercentage || 0,
      tax: po?.tax || 0,
    }));
  }, [po]);

  const handleRejected = async () => {
    try {
      setIsRejecting(() => true);
      const res = await createPOApproval({
        purchaseOrderId: purchaseOrderId || null,
        authorizingEntity: AuthorizingEntityEnum.Vendor,
        company: getValues("company") || "",
        dateSigned:
          getValues("date")?.toISOString() || new Date().toISOString(),
        signature: getValues("signature") || "",
        status: ApprovalStatusEnum.Rejected,
        title: getValues("title") || "",
      });
      if (res?.isSuccess) {
        setValue("approvalStatus", ApprovalStatusEnum?.Rejected);
        setIsCompleted(() => true);
      }
    } catch (error) {
      console.error("Error handling rejected approval:", error);
    } finally {
      setIsRejecting(() => false);
    }
  };

  const handleOpenApprovalModal = async () => {
    const isValid = await trigger(["signature", "company", "title", "date"]);

    if (isValid) {
      setIsConfirmApprovalModal(true);
    }
  };

  useEffect(() => {
    if (!rejected) return;

    setActionType({ cancel: ActionTypeEnum.REJECT_ALL });

    handleRejected();

    // Dependencies to ensure effect runs correctly
  }, [rejected, purchaseOrderId, po?.id, getValues]);

  type ColorStylesType = {
    [Number: number]: string;
  };

  const colorStyles: ColorStylesType = {
    0: "bg-[#E5FFF2] text-[#307D57]", // Approved
    1: "bg-[#FFE5E5] text-[#D14343]", // Rejected
    2: "bg-[#ECECEC] text-[#53575A]",
  };

  const getStatusLabel = (status?: number) => {
    switch (status) {
      case 0:
        return "Approved";
      case 1:
        return "Rejected";
      case 2:
        return "Pending";
      default:
        return "Pending";
    }
  };

  const statusClass =
    colorStyles?.[
      getValues("approvalStatus") === undefined
        ? 2
        : getValues("approvalStatus")
    ];

  return (
    <SectionLayout className="m-6 p-6 rounded-2xl">
      <CustomModal
        width={800}
        isOpen={isConfirmApprovalModal}
        cancelButtonAction={() => {
          setIsConfirmApprovalModal(false);
          clearErrors("approvalComments");
          setValue("approvalComments", "");
        }}
        isLoading={isSubmitting}
        title={"Comments"}
        primaryButtonText="Approve"
        primaryButtonAction={async () => {
          const isValid = await trigger("approvalComments");
          if (isValid) {
            handleSubmit(onSubmit)();
          }
        }}
      >
        <div className="mb-10 mt-6">
          <Controller
            name="approvalComments"
            control={control}
            rules={{
              required: "Comments are required",
            }}
            render={({ field, fieldState: { error } }) => (
              <>
                <Form.Item
                  colon={false}
                  help={error?.message}
                  validateStatus={error ? "error" : ""}
                >
                  <Input.TextArea
                    {...field}
                    onChange={(value) => {
                      field.onChange(value);
                      trigger("approvalComments");
                    }}
                    placeholder="Write your comments here..."
                    value={field.value}
                    rows={10}
                  />
                </Form.Item>
              </>
            )}
          />
        </div>
        {/* {error?.length > 0 ||
          (successMessage && (
            <CustomAlert
              message={error || successMessage || ""}
              type={successMessage ? "success" : "error"}
            />
          ))} */}
      </CustomModal>
      <Flex className="justify-between items-center">
        {companyData?.logo?.url ? (
          <img
            src={companyData?.logo?.url}
            className=" w-[130px] h-[50px] object-contain"
          />
        ) : (
          <ProcureBuilderLogo />
        )}
        <h1 className="font-semibold text-4xl text-primaryActive">
          Purchase Order
        </h1>

        <span
          className={`inline-flex items-center rounded-md ${statusClass} px-4 py-2 text-sm font-bold`}
        >
          {getStatusLabel(getValues("approvalStatus"))}
        </span>
      </Flex>

      <Form
        onFinish={handleSubmit(onSubmit)}
        labelCol={{ span: 4 }}
        layout="vertical"
        autoComplete="off"
        className="pt-6"
      >
        <SectionLayout>
          <Flex className="flex-col mb-3">
            <div className="flex justify-between items-center">
              <div className="flex flex-col">
                {companyData?.name !== null &&
                companyData?.name !== undefined ? (
                  <p className="text-lg">
                    <span className="font-semibold">Company:</span>{" "}
                    {companyData?.name}
                  </p>
                ) : null}
                {po?.purchaseOrderNumber !== null &&
                po?.purchaseOrderNumber !== undefined ? (
                  <p className="text-lg">
                    <span className="font-semibold">PO#:</span>{" "}
                    {po?.purchaseOrderNumber}
                  </p>
                ) : null}

                {po?.purchaseOrderProject?.name ? (
                  <p className="text-lg">
                    <span className="font-semibold">Project:</span>{" "}
                    {po?.purchaseOrderProject?.name}
                  </p>
                ) : null}
              </div>

              <Button
                className={`border border-primaryActive text-primaryActive stroke-primaryActive fill-white hover:!bg-primary25 hover:!fill-primary25 hover:!border-primary hover:!text-primary hover:!stroke-primary group`}
                icon={<CustomIcon type="download-icon" />}
                size="large"
                data-loader="false"
                onClick={async (event) => {
                  const el = event.currentTarget as HTMLButtonElement;
                  event.stopPropagation();
                  if (el.dataset.loader === "true") return;

                  el.dataset.loader = "true";

                  const blob = (await downloadPOReport({
                    purchaseOrderId: purchaseOrderId || "",
                    pdfType: PoReportTypeEnum.PurchaseOrderVendor.toString(),
                  })) as Blob;
                  const name = `Vendor-Details-Report-${po?.purchaseOrderNumber}.pdf`;
                  manuallyDownloadBlob(blob, name);
                  el.dataset.loader = "false";
                }}
              >
                <span className="group-data-[loader=true]:!hidden">
                  Download PDF Report
                </span>
                <span className="!hidden group-data-[loader=true]:!block">
                  Downloading...
                </span>
              </Button>
            </div>

            <div className="mt-6 mb-2">
              <CustomFormLabel text="Tax Percentage" />
            </div>

            <Controller
              name={`taxPercentage`}
              control={control}
              render={({ field, formState: { errors } }) => {
                return (
                  <Form.Item
                    help={errors?.taxPercentage?.message}
                    validateStatus={errors?.taxPercentage ? "error" : ""}
                  >
                    <Space.Compact size="large">
                      <InputNumber
                        {...field}
                        style={{ width: "100%" }}
                        min={0}
                        max={100}
                        size="large"
                        type="number"
                        placeholder="0%"
                        disabled
                      />
                      <Button
                        disabled
                        style={{
                          cursor: "default",
                          width: "10%",
                        }}
                      >
                        %
                      </Button>
                    </Space.Compact>
                  </Form.Item>
                );
              }}
            />
          </Flex>

          <Table
            style={{ width: "100%", overflowX: "auto", maxHeight: "800px" }}
            columns={columns || []}
            pagination={false}
            dataSource={po?.purchaseOrderMaterials || []}
            className="relative vendor-approval-table"
          />

          <Flex className="ml-auto mt-8 flex-col min-w-[400px]">
            <Form.Item
              layout="horizontal"
              colon={false}
              label={<label className="font-medium text-md">Subtotal</label>}
            >
              <Controller
                name="subTotal"
                control={control}
                render={({ field }) => (
                  <InputNumber
                    value={field.value}
                    disabled
                    size="large"
                    className="w-full"
                    placeholder="Subtotal"
                    formatter={(value) => `$ ${convertToLocaleString(value)}`}
                    parser={(value) =>
                      value?.replace(/\$\s?|(,*)/g, "") as unknown as number
                    }
                  />
                )}
              />
            </Form.Item>

            <Form.Item
              layout="horizontal"
              colon={false}
              label={<label className="font-medium text-md">Tax</label>}
            >
              <Controller
                name="tax"
                control={control}
                render={({ field }) => (
                  <InputNumber
                    value={field.value}
                    disabled
                    size="large"
                    className="w-full"
                    placeholder="Tax"
                    formatter={(value) => `$ ${convertToLocaleString(value)}`}
                    parser={(value) =>
                      value?.replace(/\$\s?|(,*)/g, "") as unknown as number
                    }
                  />
                )}
              />
            </Form.Item>
            <Form.Item
              layout="horizontal"
              colon={false}
              label={<label className="font-bold text-md">Total</label>}
            >
              <Controller
                name="total"
                control={control}
                render={({ field }) => (
                  <InputNumber
                    value={field.value}
                    disabled
                    size="large"
                    className="w-full"
                    placeholder="Total"
                    formatter={(value) => `$ ${convertToLocaleString(value)}`}
                    parser={(value) =>
                      value?.replace(/\$\s?|(,*)/g, "") as unknown as number
                    }
                  />
                )}
              />
            </Form.Item>
          </Flex>
        </SectionLayout>
        <Flex gap={"large"} justify="center" className="w-full mt-8 mb-4">
          {/* Terms And Conditions */}
          {po?.termsAndConditions && (
            <SectionLayout className="grow p-6 rounded-xl max-h-[430px] overflow-auto">
              <Flex justify="center" className="gap-1" vertical>
                <div>
                  <Typography.Title level={4}>Delivery Notes:</Typography.Title>
                  <Typography>
                    <span
                      className="text-sm"
                      dangerouslySetInnerHTML={{
                        __html: `${po?.deliveryNotes?.trim() || ""}`,
                      }}
                    />
                  </Typography>
                </div>
              </Flex>
            </SectionLayout>
          )}
        </Flex>
        <Flex gap={"large"} justify="center" className="w-full mt-8 mb-4">
          {/* Terms And Conditions */}
          {po?.termsAndConditions && (
            <SectionLayout className="grow p-6 rounded-xl max-h-[430px] overflow-auto">
              <Flex justify="center" className="gap-1" vertical>
                <div>
                  <Typography.Title level={4}>
                    Terms and Conditions:
                  </Typography.Title>
                  <Typography>
                    <span
                      className="text-sm"
                      dangerouslySetInnerHTML={{
                        __html: `${po?.termsAndConditions?.trim()}`,
                      }}
                    />
                  </Typography>
                </div>
              </Flex>
            </SectionLayout>
          )}

          <SectionLayout className="basis-1/4 shrink-0 grow-0 p-6 rounded-xl">
            <Flex justify="center" className="gap-1" vertical>
              <Controller
                name="signature"
                control={control}
                rules={{
                  required: "Signature is required.",
                }}
                render={({ field, formState: { errors } }) => {
                  const { signature } = errors;
                  return (
                    <Form.Item
                      colon={false}
                      label={<label>Signature</label>}
                      help={signature?.message}
                      validateStatus={signature?.message?.length ? "error" : ""}
                    >
                      <Input
                        className="-mt-2"
                        {...field}
                        onChange={(value) => {
                          field.onChange(value);
                          trigger("signature");
                        }}
                        disabled={getShouldDisableAll()}
                        size="large"
                        placeholder="Signature..."
                      />
                    </Form.Item>
                  );
                }}
              />
              <Controller
                name="company"
                control={control}
                rules={{
                  required: "Company is required.",
                }}
                render={({ field, formState: { errors } }) => {
                  const { company } = errors;

                  return (
                    <Form.Item
                      colon={false}
                      label={<label>Company</label>}
                      help={company?.message}
                      validateStatus={company?.message?.length ? "error" : ""}
                    >
                      <Input
                        {...field}
                        className="-mt-2"
                        disabled={getShouldDisableAll()}
                        onChange={(value) => {
                          field.onChange(value);
                          trigger("company");
                        }}
                        size="large"
                        placeholder="Company..."
                      />
                    </Form.Item>
                  );
                }}
              />
              <Controller
                name="title"
                control={control}
                rules={{
                  required: "Title is required.",
                }}
                render={({ field, formState: { errors } }) => {
                  const { title } = errors;
                  return (
                    <Form.Item
                      colon={false}
                      label={<label>Title</label>}
                      help={title?.message}
                      validateStatus={title?.message?.length ? "error" : ""}
                    >
                      <Input
                        className="-mt-2"
                        disabled={getShouldDisableAll()}
                        {...field}
                        onChange={(value) => {
                          field.onChange(value);
                          trigger("title");
                        }}
                        size="large"
                        placeholder="Title..."
                      />
                    </Form.Item>
                  );
                }}
              />
              <Form.Item
                className="!mb-0"
                colon={false}
                label={<label>Date</label>}
              >
                <Controller
                  name="date"
                  control={control}
                  render={({ field }) => (
                    <DatePicker
                      className="-mt-2"
                      {...field}
                      disabled
                      value={
                        dayjs(field.value).isValid() ? dayjs(field.value) : null
                      }
                      onChange={(date) => {
                        field.onChange(dayjs(date).locale("en").format());
                      }}
                      size="large"
                      style={{ width: "100%" }}
                      placeholder="MM/DD/YYYY"
                      format={dateFormat}
                    />
                  )}
                />
              </Form.Item>
            </Flex>
            <Flex justify="center" className="gap-4 mt-8">
              <Button
                loading={
                  actionType.cancel === ActionTypeEnum.REJECT_ALL && isRejecting
                }
                disabled={getShouldDisableAll() || isSubmitting}
                className="font-medium !border-danger-5 !text-danger-5 bg-danger-510 hover:!bg-danger-5-18 hover:!border-danger-5-02 disabled:!bg-neutral-1 disabled:!border-neutral-5 disabled:!text-neutral-75"
                type="default"
                onClick={() => {
                  setActionType({
                    cancel: ActionTypeEnum.REJECT_ALL,
                  });
                  handleRejected();
                }}
              >
                {actionType.cancel === ActionTypeEnum.REJECT_ALL && isSubmitting
                  ? "Rejecting.."
                  : "Reject"}
              </Button>
              <Button
                loading={
                  actionType.approveAll === ActionTypeEnum.APPROVE_ALL &&
                  isSubmitting
                }
                disabled={getShouldDisableAll() || isSubmitting}
                // type=""
                className="font-medium !border-green-primary !text-white !bg-green-primary hover:!bg-green-primaryHover hover:!border-green-primaryHover disabled:!bg-neutral-1 disabled:!border-neutral-5 disabled:!text-neutral-75"
                htmlType="submit"
                onClick={() => {
                  setActionType({
                    approveAll: ActionTypeEnum.APPROVE_ALL,
                  });
                  setValue("approvalComments", " ");
                }}
              >
                {actionType.approveAll === ActionTypeEnum.APPROVE_ALL &&
                isSubmitting
                  ? "Approving.."
                  : "Approve "}
              </Button>
              <Button
                loading={
                  actionType.approveWithComments ===
                    ActionTypeEnum.APPROVE_WITH_COMMENTS && isSubmitting
                }
                disabled={getShouldDisableAll() || isSubmitting}
                onClick={() => {
                  setActionType({
                    approveWithComments: ActionTypeEnum.APPROVE_WITH_COMMENTS,
                  });
                  handleOpenApprovalModal();
                }}
              >
                {actionType.approveWithComments ===
                  ActionTypeEnum.APPROVE_WITH_COMMENTS && isSubmitting
                  ? "Approving.."
                  : "Approve With Comments"}
              </Button>
            </Flex>
          </SectionLayout>
        </Flex>

        {/* Custom Error or Success Msg */}
        {(error || successMessage) && (
          <CustomAlert
            message={error || successMessage || ""}
            type={successMessage ? "success" : "error"}
          />
        )}
      </Form>
    </SectionLayout>
  );
};

export default POVendorApprovalPage;
