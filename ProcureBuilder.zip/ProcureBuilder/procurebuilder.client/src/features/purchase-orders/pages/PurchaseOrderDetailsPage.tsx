import {
  downloadPOReport,
  getPurchaseOrdersById,
} from "@/src/apis/purchaseOrderApis";
import CustomIcon from "@/src/components/common/CustomIcon";
import CustomTabs from "@/src/components/common/CustomTabs";
import PurchaseOrderStatus, {
  PurchaseOrderBadgeTypes,
} from "@/src/components/common/PurchaseOrderStatus";
import PageLayout from "@/src/components/layout/PageLayout";
import { useAppDispatch } from "@/src/hooks/useAppDispatch";
import { useAppSelector } from "@/src/hooks/useAppSelector";
import useAuthorization from "@/src/hooks/useAuthorization";
import { getPurchaseOrderDataById } from "@/src/store/slices/purchaseOrderSlice";
import { manuallyDownloadBlob } from "@/src/utils/api-helpers";
import { PoReportTypeEnum } from "@/src/utils/enums";
import {
  getPurchaseOrderStatus,
  isPOMatchingStatusDF,
} from "@/src/utils/helper";
import routePaths from "@/src/utils/routePaths";
import { PurchaseOrder } from "@/src/utils/types";
import { Button, Flex } from "antd";
import { useEffect, useState } from "react";
import { useLocation, useParams } from "react-router-dom";
import PurchaseOrderApprovalTab from "../components/PurchaseOrderApprovalTab";
import PurchaseOrderDetailsFormRFH from "../components/PurchaseOrderDetailsFormRFH";
// import PurchaseOrderApprovalTab from "../components/PurchaseOrderApprovalTab";

const PurchaseOrderDetailsPage = () => {
  const { isFieldsCraftAuthorized } = useAuthorization();
  const { purchaseOrderId } = useParams();
  const [purchaseOrderData, setPurchaseOrderData] = useState<PurchaseOrder>();
  const location = useLocation();
  const dispatch = useAppDispatch();

  const purchaseOrder = useAppSelector((state) =>
    getPurchaseOrderDataById(state, purchaseOrderId || "")
  );
  const [statusValue, setStatus] = useState<number>();

  const showDownloadButton = () => {
    const hasPOId = Boolean(purchaseOrderId);
    const isAllowedForFieldCraft = isFieldsCraftAuthorized();
    const hideForPendingApprovalStatus = isPOMatchingStatusDF(
      purchaseOrderData?.status
    );

    return hasPOId && hideForPendingApprovalStatus && !isAllowedForFieldCraft;
  };

  const tabs = {
    purchaseOrderDetails: "Purchase Order Details",
    // recipient: "Recipient",
    approvalDetails: "Approval Details",
  };

  useEffect(() => {
    if (purchaseOrder) {
      setPurchaseOrderData(purchaseOrder);
      return;
    }

    if (purchaseOrderId) {
      const fetchChangeOrderById = async () => {
        const response = await dispatch(
          getPurchaseOrdersById({ purchaseOrderId })
        ).unwrap();
        setPurchaseOrderData(response?.purchaseOrder);
      };
      fetchChangeOrderById();
    }
  }, [purchaseOrderId, dispatch, statusValue]);

  useEffect(() => {
    if (
      location.pathname === routePaths.PURCHASE_ORDERS_NEW &&
      !location.state
    ) {
      setStatus(0);
    }
  }, [location.pathname]);

  // States
  const [selectedTab, setSelectedTab] = useState(tabs.purchaseOrderDetails);
  const [badgeType, setBadgeType] = useState<PurchaseOrderBadgeTypes>(
    "Pending Admin Approval"
  );

  // useEffect(() => {
  //   const fetchApproval = async () => {
  //     const res = await dispatch(
  //       getPurchaseOrderApprovalsById(purchaseOrderId || "")
  //     ).unwrap();
  //     setVendorData(res?.vendorApproval);
  //     // setValue("vendorApproval", res?.vendorApproval);
  //   };

  //   fetchApproval();
  // }, []);

  // Functions

  // const isAdminAuthorized = () => {
  //   return (
  //     purchaseOrderData?.status === PurchaseOrderStatusEnum.AdminSigned ||
  //     purchaseOrderData?.status === PurchaseOrderStatusEnum.AdminRejectedAll ||
  //     purchaseOrderData?.status === PurchaseOrderStatusEnum.VendorApproved ||
  //     purchaseOrderData?.status === PurchaseOrderStatusEnum.FullyReceived ||
  //     purchaseOrderData?.status === PurchaseOrderStatusEnum.PartiallyReceived
  //     // purchaseOrder?.status === PurchaseOrderStatusEnum.AdminApprovedAll
  //   );
  // };

  function renderRenderTabPanels() {
    switch (selectedTab) {
      default:
        return (
          <PurchaseOrderDetailsFormRFH
            setStatus={setStatus}
            reorder={location?.state?.actionType ? null : location?.state} // for two way state passes away from reorder to get reorder data and  other side dashboard for actionType of Vendor Approval
            purchaseOrderData={purchaseOrderData}
          />
        );
      // return <PurchaseOrderDetailsForm purchaseOrder={purchaseOrder} />;
      // case tabs.recipient:
      //   return (
      //     <PurchaseOrderRecipientTab
      //       purchaseOrder={purchaseOrderData}
      //       isAdminAuthorized={isAdminAuthorized}
      //       setStatus={setStatus}
      //     />
      //   );
      // case tabs.procurementDetails:
      //   return <POMaterialTable purchaseOrder={purchaseOrder} />;
      case tabs.approvalDetails:
        return (
          <PurchaseOrderApprovalTab
            statusValue={statusValue}
            setStatus={setStatus}
            purchaseOrderData={purchaseOrderData}
          />
        );
    }
  }

  // const resolvedStatus = statusValue;
  // Effects

  useEffect(() => {
    if (location.state?.actionType) {
      return;
    }
    const status = getPurchaseOrderStatus(
      statusValue || purchaseOrder?.status || 0
    );
    setBadgeType(status);
  }, [purchaseOrder, purchaseOrderId, statusValue]);
  useEffect(() => {
    if (
      location.pathname === routePaths.PURCHASE_ORDERS_NEW &&
      selectedTab !== tabs.purchaseOrderDetails
    ) {
      setSelectedTab(tabs.purchaseOrderDetails);
    }
  }, [location, selectedTab, tabs.purchaseOrderDetails, statusValue]);

  // useEffect(() => {
  //   if (location.state?.actionType === NotificationActionEnum.VendorApproval) {
  //     setSelectedTab(tabs.recipient);
  //     const status = getPurchaseOrderStatus(
  //       PurchaseOrderStatusEnum.VendorApproved
  //     );
  //     // setStatus(status || 0);
  //     setBadgeType(status);
  //   }
  // }, [location.state?.actionType]);

  return (
    <>
      <PageLayout
        title={purchaseOrderId ? "Edit Purchase Order" : "New Purchase Order"}
        titleSibling={<PurchaseOrderStatus badgeType={badgeType} />}
        titleBarJustifyContent="flex-start"
      >
        <Flex className="mb-7 justify-between items-center ">
          <CustomTabs
            options={Object.entries(tabs)?.map(([key, value]) => ({
              value: key,
              label: value,
              disabled: !purchaseOrderId
                ? value !== tabs.purchaseOrderDetails
                : false,
            }))}
            tabLabel={selectedTab}
            onChange={(tab) => setSelectedTab(tab)}
          />

          {showDownloadButton() && (
            <>
              {selectedTab === tabs.approvalDetails ? (
                <Button
                  className={`stroke-gray-1 fill-white hover:!fill-primary25 hover:!stroke-primary group`}
                  icon={<CustomIcon type="download-icon" />}
                  size="large"
                  data-loader="false"
                  onClick={async (event) => {
                    const el = event.currentTarget as HTMLButtonElement;
                    event.stopPropagation();
                    if (el.dataset.loader === "true") return;

                    el.dataset.loader = "true";

                    const blob = (await downloadPOReport({
                      purchaseOrderId: purchaseOrderId || "",
                      pdfType:
                        PoReportTypeEnum.PurchaseOrderApproval.toString(),
                    })) as Blob;
                    const name = `Approval-Details-Report-${purchaseOrderData?.purchaseOrderNumber}.pdf`;
                    manuallyDownloadBlob(blob, name);
                    el.dataset.loader = "false";
                  }}
                >
                  <span className="group-data-[loader=true]:!hidden">
                    Download Approval Details Report
                  </span>
                  <span className="!hidden group-data-[loader=true]:!block">
                    Downloading...
                  </span>
                </Button>
              ) : (
                <Flex className="gap-2">
                  <Button
                    className={` hover:!fill-primaryHover group`}
                    icon={<CustomIcon type="cp-purchase-orders" />}
                    size="large"
                    data-loader="false"
                    onClick={async (event) => {
                      const el = event.currentTarget as HTMLButtonElement;
                      event.stopPropagation();
                      if (el.dataset.loader === "true") return;

                      el.dataset.loader = "true";

                      const blob = (await downloadPOReport({
                        purchaseOrderId: purchaseOrderId || "",
                        pdfType: PoReportTypeEnum.PurchaseOrder.toString(),
                      })) as Blob;
                      const name = `Purchase-Order-Report-${purchaseOrderData?.purchaseOrderNumber}.pdf`;
                      manuallyDownloadBlob(blob, name);
                      el.dataset.loader = "false";
                    }}
                  >
                    <span className="group-data-[loader=true]:!hidden">
                      Download Purchase Order Report
                    </span>
                    <span className="!hidden group-data-[loader=true]:!block">
                      Downloading...
                    </span>
                  </Button>
                  <Button
                    className={` hover:!fill-primaryHover group`}
                    icon={<CustomIcon type="cp-vendors" />}
                    size="large"
                    data-loader="false"
                    onClick={async (event) => {
                      const el = event.currentTarget as HTMLButtonElement;
                      event.stopPropagation();
                      if (el.dataset.loader === "true") return;

                      el.dataset.loader = "true";

                      const blob = (await downloadPOReport({
                        purchaseOrderId: purchaseOrderId || "",
                        pdfType:
                          PoReportTypeEnum.PurchaseOrderVendor.toString(),
                      })) as Blob;
                      const name = `Vendor-Details-Report-${purchaseOrderData?.purchaseOrderNumber}.pdf`;
                      manuallyDownloadBlob(blob, name);
                      el.dataset.loader = "false";
                    }}
                  >
                    <span className="group-data-[loader=true]:!hidden">
                      Download Vendor Details Report
                    </span>
                    <span className="!hidden group-data-[loader=true]:!block">
                      Downloading...
                    </span>
                  </Button>
                </Flex>
              )}
            </>
          )}
        </Flex>

        {renderRenderTabPanels()}
      </PageLayout>
    </>
  );
};

export default PurchaseOrderDetailsPage;
