import CustomModal from "@/src/components/common/CustomModal";
import CustomFormRow from "@/src/components/form/CustomFormRow";
import {
  dateFormat,
  purchaseOrderSubmittalStatusOptions,
} from "@/src/utils/constants";
import { handleIncrementDate } from "@/src/utils/date-helpers";
import { MaterialReviewPeriod } from "@/src/utils/enums";
import { handleNumericInput } from "@/src/utils/helper";
import { AssumedSubmittal, PurchaseOrderMaterials } from "@/src/utils/types";
import {
  Button,
  Col,
  DatePicker,
  Form,
  InputNumber,
  Radio,
  RadioChangeEvent,
  Select,
  Space,
} from "antd";
import dayjs, { Dayjs } from "dayjs";
import { useMemo } from "react";
import {
  Controller,
  FieldValues,
  UseFieldArrayUpdate,
  useForm,
  UseFormSetValue,
} from "react-hook-form";

type FormValues = {
  maxMaterialLeadTime: number;
  maxSubmittalLeadTime: number;
  expectedDeliveryDate: any;
  expectedSubmittalDate: any;
  submittalStatus: number;
  isMaterialAlreadyApproved: boolean;
};

type PurchaseOrderApprovalTabProps = {
  MaterialsControl: any;
  setValueMaterials: UseFormSetValue<any>;
  getValuesMaterials: any;
  isOpen: boolean;
  isLoading?: boolean;
  setIsOpen: React.Dispatch<React.SetStateAction<boolean>>;
  // updateMaterial: () => void;
  updateMaterial?: UseFieldArrayUpdate<FieldValues, "purchaseOrderMaterials">;
  setIsLoading?: React.Dispatch<React.SetStateAction<boolean>>;
  assumedSubmittal?: AssumedSubmittal;
  // setProcurementDetails: React.Dispatch<React.SetStateAction<FormValues>>;
};

const ProcurementDetailsModal = ({
  isOpen,
  setIsLoading,
  setIsOpen,
  setValueMaterials,
  getValuesMaterials,
  isLoading,
  assumedSubmittal,
}: PurchaseOrderApprovalTabProps) => {
  const { control, handleSubmit, setValue, resetField, getValues, reset } =
    useForm<FormValues>({
      defaultValues: {
        maxMaterialLeadTime: 0,
        maxSubmittalLeadTime: 0,
        expectedDeliveryDate: dayjs(new Date()),
        expectedSubmittalDate: dayjs(new Date()),
        submittalStatus: 0,
        isMaterialAlreadyApproved: false,
      },
    });
  const materials = getValuesMaterials(`purchaseOrderMaterials`);

  useMemo(() => {
    if (!materials) return;
    materials?.map((v: PurchaseOrderMaterials) => {
      return setValue("expectedDeliveryDate", v?.expectedDeliveryDate);
    });
  }, [materials]);

  const onSubmit = async (values: FormValues) => {
    try {
      if (typeof setIsLoading === "function") setIsLoading(true);

      const selectedMaterials = materials.filter(
        (v: PurchaseOrderMaterials) => v.checked === true
      );

      const promises = selectedMaterials.map(
        (material: PurchaseOrderMaterials) => {
          return new Promise((resolve) => {
            const materialIndex = materials.findIndex(
              (m: PurchaseOrderMaterials) => m === material
            );

            setValueMaterials(
              `purchaseOrderMaterials.${materialIndex}.maxMaterialLeadTime`,
              values.maxMaterialLeadTime
            );
            setValueMaterials(
              `purchaseOrderMaterials.${materialIndex}.maxSubmittalLeadTime`,
              values.maxSubmittalLeadTime
            );
            setValueMaterials(
              `purchaseOrderMaterials.${materialIndex}.expectedDeliveryDate`,
              values.expectedDeliveryDate
            );
            setValueMaterials(
              `purchaseOrderMaterials.${materialIndex}.expectedSubmittalDate`,
              values.expectedSubmittalDate
            );
            setValueMaterials(
              `purchaseOrderMaterials.${materialIndex}.submittalStatus`,
              values.submittalStatus
            );
            setValueMaterials(
              `purchaseOrderMaterials.${materialIndex}.isMaterialAlreadyApproved`,
              values.isMaterialAlreadyApproved
            );

            // @ts-ignore
            resolve();

            // Reset fields for the form-level values
          });
        }
      );

      await Promise.all(promises); // Wait for all promises to resolve
      reset({
        maxMaterialLeadTime: 0,
        maxSubmittalLeadTime: 0,
        expectedDeliveryDate: dayjs(new Date()),
        expectedSubmittalDate: dayjs(new Date()),
        submittalStatus: 0,
        isMaterialAlreadyApproved: false,
      });
    } catch (err) {
      console.error(err);
    } finally {
      if (typeof setIsLoading === "function") setIsLoading(false); // Stop loading
      setIsOpen(false);
    }
  };

  const handleChangeMaterialApproved = (e: RadioChangeEvent) => {
    setValue("isMaterialAlreadyApproved", e.target.value);
    resetField("maxMaterialLeadTime");
    resetField("maxSubmittalLeadTime");
    resetField("expectedDeliveryDate", { defaultValue: dayjs(new Date()) });
    resetField("expectedSubmittalDate", { defaultValue: dayjs(new Date()) });
    resetField("submittalStatus");
  };

  const handleSubmittalLeadTimeChange = (numericValue: number) => {
    const submittalDate = dayjs(new Date()).format(dateFormat);
    const newSubmittalDate = handleIncrementDate(
      submittalDate,
      numericValue,
      "week"
    );
    setValue(`expectedSubmittalDate`, newSubmittalDate);
    const reviewPeriodUnit =
      MaterialReviewPeriod[
        assumedSubmittal?.assumedSubmittalReviewPeriod ?? 0
      ]?.toLowerCase() || "day";

    const reviewPeriodUnitFormatted = reviewPeriodUnit as
      | "day"
      | "week"
      | "month";

    const reviewPeriodInDays = handleIncrementDate(
      newSubmittalDate,
      assumedSubmittal?.assumedSubmittalReview ?? 0,
      reviewPeriodUnitFormatted
    );
    const materialLeadTime = getValues(`maxMaterialLeadTime`);

    const newDeliveryDate = handleIncrementDate(
      reviewPeriodInDays,
      materialLeadTime,
      "week"
    );

    setValue(`expectedDeliveryDate`, newDeliveryDate);
  };

  const handleExpectedSubmittalDateChange = (date: Dayjs) => {
    setValue(`expectedSubmittalDate`, date.format(dateFormat));
    const reviewPeriodUnit =
      MaterialReviewPeriod[
        assumedSubmittal?.assumedSubmittalReviewPeriod ?? 0
      ]?.toLowerCase() || "day";

    const reviewPeriodUnitFormatted = reviewPeriodUnit as
      | "day"
      | "week"
      | "month";
    const reviewPeriodInDays = handleIncrementDate(
      date,
      assumedSubmittal?.assumedSubmittalReview ?? 0,
      reviewPeriodUnitFormatted
    );

    const materialLeadTime = getValues(`maxMaterialLeadTime`);

    const newDeliveryDate = handleIncrementDate(
      reviewPeriodInDays,
      materialLeadTime,
      "week"
    );

    setValue(`expectedDeliveryDate`, newDeliveryDate);
  };

  const handleMaxMaterialLeadTimeChange = (numericValue: number) => {
    const submittalDate = dayjs(getValues(`expectedSubmittalDate`)).isValid()
      ? getValues(`expectedSubmittalDate`)
      : dayjs(new Date()).format(dateFormat);
    const reviewPeriodUnit =
      MaterialReviewPeriod[
        assumedSubmittal?.assumedSubmittalReviewPeriod ?? 0
      ]?.toLowerCase() || "day";

    const reviewPeriodUnitFormatted = reviewPeriodUnit as
      | "day"
      | "week"
      | "month";

    const reviewPeriodInDays = handleIncrementDate(
      submittalDate,
      assumedSubmittal?.assumedSubmittalReview ?? 0,
      reviewPeriodUnitFormatted
    );

    const newDeliveryDate = handleIncrementDate(
      reviewPeriodInDays,
      numericValue,
      "week"
    );
    setValue(`expectedDeliveryDate`, newDeliveryDate);
  };

  return (
    <CustomModal
      title="Procurement Details"
      isOpen={isOpen}
      isLoading={isLoading}
      cancelButtonAction={() => setIsOpen(false)}
      primaryButtonAction={handleSubmit(onSubmit)}
    >
      <Form layout="vertical" autoComplete="off">
        <CustomFormRow>
          <Col xs={12}>
            <Form.Item label="Max Submittal Lead Time">
              <Controller
                name="maxSubmittalLeadTime"
                control={control}
                render={({ field }) => (
                  <Space.Compact size="large" style={{ width: "100%" }}>
                    <InputNumber
                      {...field}
                      disabled={getValues("isMaterialAlreadyApproved")}
                      onChange={(value) => {
                        if (
                          typeof value !== "string" &&
                          typeof value !== "number"
                        )
                          return;
                        const numericValue = handleNumericInput(value);
                        field.onChange(numericValue);
                        handleSubmittalLeadTimeChange(numericValue);
                      }}
                      style={{ width: "90%" }}
                      min={0}
                      size="large"
                      placeholder="In weeks"
                    />
                    <Button
                      disabled
                      style={{
                        cursor: "default",
                        width: "10%",
                        fontSize: "0.75rem",
                      }}
                    >
                      Weeks
                    </Button>
                  </Space.Compact>
                )}
              />
            </Form.Item>
          </Col>
          {/* Expected Submittal Date */}
          <Col xs={12}>
            <Form.Item
              label="Expected Submittal Date"
              tooltip="This will override other lead time fields."
            >
              <Controller
                name="expectedSubmittalDate"
                control={control}
                render={({ field }) => (
                  <DatePicker
                    {...field}
                    disabled={getValues("isMaterialAlreadyApproved")}
                    value={
                      dayjs(field.value).isValid() ? dayjs(field.value) : null
                    }
                    onChange={(date) => {
                      if (!dayjs(date).isValid()) {
                        setValue(`expectedSubmittalDate`, null);
                        return;
                      }
                      handleExpectedSubmittalDateChange(date);
                    }}
                    size="large"
                    style={{ width: "100%" }}
                    placeholder="MM/DD/YYYY"
                    format={dateFormat}
                  />
                )}
              />
            </Form.Item>
          </Col>

          <Col xs={12}>
            <Form.Item label="Max Material Lead Time">
              <Controller
                name="maxMaterialLeadTime"
                control={control}
                render={({ field }) => (
                  <Space.Compact size="large" style={{ width: "100%" }}>
                    <InputNumber
                      disabled={getValues("isMaterialAlreadyApproved")}
                      {...field}
                      onChange={(value) => {
                        if (
                          typeof value !== "string" &&
                          typeof value !== "number"
                        )
                          return;
                        const numericValue = handleNumericInput(value);
                        field.onChange(numericValue);
                        handleMaxMaterialLeadTimeChange(numericValue);
                      }}
                      style={{ width: "90%" }}
                      min={0}
                      size="large"
                      placeholder="In weeks"
                    />
                    <Button
                      disabled
                      style={{
                        cursor: "default",
                        width: "10%",
                        fontSize: "0.75rem",
                      }}
                    >
                      Weeks
                    </Button>
                  </Space.Compact>
                )}
              />
            </Form.Item>
          </Col>

          <Col xs={12}>
            <Form.Item label="Expected Delivery Date">
              <Controller
                name="expectedDeliveryDate"
                control={control}
                render={({ field }) => (
                  <DatePicker
                    {...field}
                    disabled={getValues("isMaterialAlreadyApproved")}
                    value={
                      dayjs(field.value).isValid() ? dayjs(field.value) : null
                    }
                    onChange={(date) => {
                      if (!dayjs(date).isValid()) {
                        setValue(
                          `expectedSubmittalDate`,
                          getValues(`expectedSubmittalDate`)
                        );
                        setValue(
                          `expectedDeliveryDate`,
                          dayjs(new Date()).format(dateFormat)
                        );
                        return;
                      }
                      field.onChange(dayjs(date).locale("en").format());
                    }}
                    size="large"
                    style={{ width: "100%" }}
                    placeholder="MM/DD/YYYY"
                    format={dateFormat}
                  />
                )}
              />
            </Form.Item>
          </Col>

          {/* Submittal Status */}
          <Col xs={12}>
            <Form.Item label="Submittal Status">
              <Controller
                name="submittalStatus"
                control={control}
                render={({ field }) => (
                  <Select
                    {...field}
                    disabled={getValues("isMaterialAlreadyApproved")}
                    size="large"
                    placeholder="Select Status"
                    options={purchaseOrderSubmittalStatusOptions}
                    onChange={(value) => setValue("submittalStatus", value)}
                  />
                )}
              />
            </Form.Item>
          </Col>

          {/* Material Approved */}
          <Col xs={12}>
            <Form.Item label="Is material already approved?">
              <Controller
                name="isMaterialAlreadyApproved"
                control={control}
                render={({ field }) => (
                  <Radio.Group
                    disabled={false}
                    {...field}
                    onChange={(e) => handleChangeMaterialApproved(e)}
                  >
                    <Radio value={true}>Yes</Radio>
                    <Radio value={false}>No</Radio>
                  </Radio.Group>
                )}
              />
            </Form.Item>
          </Col>
        </CustomFormRow>
      </Form>
    </CustomModal>
  );
};

export default ProcurementDetailsModal;
