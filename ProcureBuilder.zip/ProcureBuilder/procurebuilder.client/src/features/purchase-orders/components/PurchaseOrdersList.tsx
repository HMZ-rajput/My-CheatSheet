import { getSummarizedProjectsList } from "@/src/apis/projectApis";
import { getAllPurchaseOrders } from "@/src/apis/purchaseOrderApis";
import CustomIcon from "@/src/components/common/CustomIcon";
import HighlightedText from "@/src/components/common/HighlightedText";
import PurchaseOrderStatus from "@/src/components/common/PurchaseOrderStatus";
import CustomTable, {
  defaultPageSizes,
} from "@/src/components/table/CustomTable";
import CustomTableFilters, {
  CustomFilterDataType,
  CustomFiltersType,
} from "@/src/components/table/CustomTableFilters";
import { useAppDispatch } from "@/src/hooks/useAppDispatch";
import { useAppSelector } from "@/src/hooks/useAppSelector";
import useAuthorization from "@/src/hooks/useAuthorization";
import { useDebouncedCallback } from "@/src/hooks/useDebouncedCallback";
import { getProjectsState } from "@/src/store/slices/projectsSlice";
import { getPurchaseOrdersState } from "@/src/store/slices/purchaseOrderSlice";
import {
  allPurchaseOrderStatusOptions,
  allPurchaseOrderSubmittalStatusOptions,
  dateFormat,
  purchaseOrderStatusOptionsWithAll,
} from "@/src/utils/constants";
import {
  getPurchaseOrderPaymentTerm,
  getPurchaseOrderStatus,
} from "@/src/utils/helper";
import { getFirstValidNumber } from "@/src/utils/number-extensions";
import routePaths from "@/src/utils/routePaths";
import { getConsistentSpacing } from "@/src/utils/theme-helpers";
import { PurchaseOrder } from "@/src/utils/types";
import { EyeOutlined } from "@ant-design/icons";
import SectionLayout from "@components/layout/SectionLayout";
import { Button, TableProps, Typography } from "antd";
import dayjs from "dayjs";
import { useEffect, useMemo, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useReports } from "../../reports/contexts/ReportsProvider";
import useSyncFilters from "@/src/hooks/useSyncFilters";

type PurchaseOrdersListProps = {
  exportButtonEl?: React.ReactNode | null;

  setReportStats?:
    | null
    | ((
        totalPurchaseOrders: number,
        totalCost: number,
        totalPendingAdminApproval: number,
        totalAdminApprovedPartial: number,
        totalAdminApprovedAll: number,
        totalAdminRejected: number,
        totalVendorApprovalPending: number,
        totalVendorApproved: number,
        totalVendorRejected: number,
        totalPartiallyReceived: number,
        totalFullyReceived: number,
        totalAdminSigned: number,
        totalNet60: number,
        totalNet45: number,
        totalNet30: number
      ) => void);

  paramProjectId?: string;
  showProjectsFilter?: boolean;
};
export default function PurchaseOrdersList({
  paramProjectId,
  showProjectsFilter = true,

  setReportStats = null,
  exportButtonEl = null,
}: PurchaseOrdersListProps) {
  const { filterValues } = useReports();

  const isInsideReports = useMemo(
    () => Boolean(exportButtonEl),
    [exportButtonEl]
  );
  const [searchTerm, setSearchTerm] = useState("");
  const [hasSearched, setHasSearched] = useState(false);
  const { searchParams } = useSyncFilters();
  const [previousSearchTerm, setPreviousSearchTerm] = useState(
    searchParams.get("searchTerm")
  );
  const [lastSearchTimestamp, setLastSearchTimestamp] = useState(0);

  useEffect(() => {
    setLastSearchTimestamp(Date.now());
  }, [previousSearchTerm]);

  const navigate = useNavigate();
  const dispatch = useAppDispatch();
  const { isFieldsCraftAuthorized } = useAuthorization();
  const {
    purchaseOrdersData,
    isLoading,
    totalCount,
    currentPage: purchaseOrdersCurrentPage,
    pageSize: purchaseOrdersPageSize,
  } = useAppSelector(getPurchaseOrdersState);
  const { projectsSummarizedData } = useAppSelector(getProjectsState);

  const isFirstCallComplete = useRef(false);

  const [page, setPage] = useState<number>(purchaseOrdersCurrentPage);
  const [pageSize, setPageSize] = useState(
    !isInsideReports && !defaultPageSizes.includes(purchaseOrdersPageSize)
      ? 10
      : purchaseOrdersPageSize
  );
  // const [isFirstCall, setIsFirstCall] = useState(false);

  useEffect(() => {
    dispatch(getSummarizedProjectsList());
  }, [dispatch]);

  const memoizedProjectsOptions = useMemo(() => {
    return [
      {
        value: "",
        label: "All Projects",
      },
      ...(projectsSummarizedData?.map((f) => ({
        value: f?.id,
        label: f?.name,
      })) || []),
    ];
  }, [projectsSummarizedData]);

  const [filters, setFilters] = useState<CustomFiltersType>({
    status: {
      value: allPurchaseOrderStatusOptions.value || "",
      options: purchaseOrderStatusOptionsWithAll,
      className: "!min-w-[234px]",
      dataType: CustomFilterDataType.NUM,
    },
    projectId: {
      value: memoizedProjectsOptions[0]?.value || "",
      options: memoizedProjectsOptions,
      isHidden: !showProjectsFilter,
      dataType: CustomFilterDataType.STR,
    },
  });

  useEffect(() => {
    // Only update filters if the options actually change
    setFilters((prevFilters) => {
      const currentOptions = prevFilters.projectId.options;
      const newOptions = memoizedProjectsOptions;

      // Check if options are different (by comparing their length or individual items)
      const optionsChanged =
        currentOptions.length !== newOptions.length ||
        currentOptions.some(
          (option, index) => option.value !== newOptions[index]?.value
        );

      // If options are the same, return the previous filters to avoid unnecessary state update
      if (!optionsChanged) {
        return prevFilters;
      }

      // If options have changed, update the filters
      return {
        ...prevFilters,
        projectId: {
          ...prevFilters.projectId,
          options: newOptions,
        },
      };
    });
  }, [memoizedProjectsOptions]);

  const [buttonsFilterStatus, setButtonsFilterStatus] = useState({
    isDueToday: false,
    isOverDue: false,
    isUpComing: false,
  });
  const [buttonActive, setButtonActive] = useState({
    isDueTodayActive: false,
    isOverDueActive: false,
    isUpComingActive: false,
  });

  function updateDueTimeButtons(value: string) {
    switch (value) {
      case "dueToday":
        setButtonsFilterStatus((prev) => ({
          ...prev,
          isDueToday: !prev.isDueToday,
          isOverDue: false,
          isUpComing: false,
        }));
        setButtonActive((prev) => ({
          ...prev,
          isDueTodayActive: !prev.isDueTodayActive,
          isOverDueActive: false,
          isUpComingActive: false,
        }));
        break;
      case "overDue":
        setButtonsFilterStatus((prev) => ({
          ...prev,
          isDueToday: false,
          isOverDue: !prev.isOverDue,
          isUpComing: false,
        }));
        setButtonActive((prev) => ({
          ...prev,
          isDueTodayActive: false,
          isOverDueActive: !prev.isOverDueActive,
          isUpComingActive: false,
        }));
        break;
      case "upComing":
        setButtonsFilterStatus((prev) => ({
          ...prev,
          isDueToday: false,
          isOverDue: false,
          isUpComing: !prev.isUpComing,
        }));
        setButtonActive((prev) => ({
          ...prev,
          isDueTodayActive: false,
          isOverDueActive: false,
          isUpComingActive: !prev.isUpComingActive,
        }));
    }
  }

  const filterButtons = [
    {
      label: "Due Today",
      value: "dueToday",
      isActive: buttonActive.isDueTodayActive,
      onClick: updateDueTimeButtons,
    },
    {
      label: "Overdue",
      value: "overDue",
      isActive: buttonActive.isOverDueActive,
      onClick: updateDueTimeButtons,
    },
    {
      label: "Upcoming",
      value: "upComing",
      isActive: buttonActive.isUpComingActive,
      onClick: updateDueTimeButtons,
    },
  ];

  const handleGetResults = useDebouncedCallback(getResults, 100);

  async function getResults(pageNumber?: number) {
    const purchaseOrderStatus =
      filters.status?.value !== allPurchaseOrderStatusOptions?.value
        ? (filters?.status?.value as number)
        : undefined;

    const purchaseOrderSubmittalStatus =
      filters.submittalStatus?.value !==
      allPurchaseOrderSubmittalStatusOptions?.value
        ? (filters?.submittalStatus?.value as number)
        : undefined;

    const projectId =
      filters.projectId?.value !== memoizedProjectsOptions[0]?.value
        ? filters?.projectId?.value?.toString()
        : undefined;

    const isDueToday = buttonsFilterStatus.isDueToday
      ? buttonsFilterStatus.isDueToday.toString()
      : undefined;

    const isOverDue = buttonsFilterStatus.isOverDue
      ? buttonsFilterStatus.isOverDue.toString()
      : undefined;

    const isUpComing = buttonsFilterStatus.isUpComing
      ? buttonsFilterStatus.isUpComing.toString()
      : undefined;

    const reportFilters = isInsideReports ? filterValues : {};

    const res = await dispatch(
      getAllPurchaseOrders({
        isForReport: isInsideReports,
        pageNumber: pageNumber || page,
        pageSize,
        search: searchTerm || undefined,
        isDueToday,
        isUpComing,
        isOverDue,
        purchaseOrderStatus: getFirstValidNumber(
          reportFilters?.status,
          purchaseOrderStatus
        ),
        purchaseOrderSubmittalStatus,
        projectId: reportFilters?.projectId || paramProjectId || projectId,
        vendorId: reportFilters?.vendorId || undefined,
        locationId: reportFilters?.locationId || undefined,
        paymentTerm:
          reportFilters?.paymentTerm !== undefined &&
          reportFilters?.paymentTerm !== null &&
          reportFilters?.paymentTerm !== ""
            ? reportFilters?.paymentTerm
            : undefined,
        priceFrom: reportFilters?.totalPriceStart || undefined,
        priceTo: reportFilters?.totalPriceEnd || undefined,
        dueDateFrom: reportFilters?.dueDate?.[0] || undefined,
        dueDateTo: reportFilters?.dueDate?.[1] || undefined,
      })
    ).unwrap();

    if (typeof setReportStats === "function") {
      setReportStats(
        res?.totalCount || 0,
        res?.totalCost || 0,
        res?.totalPendingAdminApproval || 0,
        res?.totalAdminApprovedPartial || 0,
        res?.totalAdminApprovedAll || 0,
        res?.totalAdminRejected || 0,
        res?.totalVendorApprovalPending || 0,
        res?.totalVendorApproved || 0,
        res?.totalVendorRejected || 0,
        res?.totalPartiallyReceived || 0,
        res?.totalFullyReceived || 0,
        res?.totalAdminSigned || 0,
        res?.totalNet60 || 0,
        res?.totalNet45 || 0,
        res?.totalNet30 || 0
      );
    }
  }

  useEffect(() => {
    resetPaginationAndGetFirstPageResults();
  }, [filters, buttonsFilterStatus, filterValues]);

  const navigateToEditPage = (po: PurchaseOrder) => {
    const path = `${routePaths.PURCHASE_ORDERS_EDIT_BY_ID}/${po?.id}`;

    if (isInsideReports || new URLSearchParams(location.search).size > 0) {
      navigate(path, {
        state: {
          previousPath: `${location.pathname}${location.search}`,
        },
      });
    } else {
      navigate(path);
    }
  };

  const columns: TableProps<PurchaseOrder>["columns"] = [
    {
      title: "P.O. Number",
      dataIndex: "purchaseOrderNumber",
      key: "purchaseOrderNumber",
      sorter: (a, b) => {
        return Number(a.purchaseOrderNumber) - Number(b.purchaseOrderNumber);
      },
      render: (_, record) => {
        return (
          <Typography.Title
            level={5}
            style={{ fontSize: getConsistentSpacing(1.75), margin: 0 }}
          >
            <HighlightedText
              text={record.purchaseOrderNumber}
              searchTerm={searchTerm}
            />
          </Typography.Title>
        );
      },
    },
    {
      title: "Title",
      dataIndex: "title",
      key: "title",
      sorter: (a, b) => a.title.localeCompare(b.title),
      render: (_, record) => {
        return (
          <Typography.Text
            style={{ fontSize: getConsistentSpacing(1.75), margin: 0 }}
          >
            <HighlightedText text={record.title} searchTerm={searchTerm} />
          </Typography.Text>
        );
      },
    },
    {
      title: "Project",
      dataIndex: "purchaseOrderProject",
      key: "purchaseOrderProject",
      sorter: (a, b) => {
        return a.purchaseOrderProject?.name.localeCompare(
          b.purchaseOrderProject?.name
        );
      },
      render: (_, record) => {
        return (
          <Typography.Text
            style={{ fontSize: getConsistentSpacing(1.75), margin: 0 }}
          >
            <HighlightedText
              text={record.purchaseOrderProject?.name}
              searchTerm={searchTerm}
            />
          </Typography.Text>
        );
      },
    },
    {
      title: "Location",
      dataIndex: "purchaseOrderProjectLocation",
      key: "purchaseOrderProjectLocation",
      sorter: (a, b) => {
        return a.purchaseOrderProjectLocation?.name.localeCompare(
          b.purchaseOrderProjectLocation?.name
        );
      },
      render: (_, record) => {
        return (
          <Typography.Text
            style={{ fontSize: getConsistentSpacing(1.75), margin: 0 }}
          >
            <HighlightedText
              text={record.purchaseOrderDeliveryLocation?.name}
              searchTerm={searchTerm}
            />
          </Typography.Text>
        );
      },
    },
    {
      title: "Due Date",
      dataIndex: "dueDate",
      key: "dueDate",
      sorter: (a, b) => dayjs(a.dueDate).unix() - dayjs(b.dueDate).unix(),
      render: (_, record) => dayjs(record.dueDate).format(dateFormat),
    },
    {
      title: "Total",
      dataIndex: "total",
      key: "total",
      sorter: (a, b) => {
        return Number(a.total) - Number(b.total);
      },
      render: (_, record) => {
        return (
          <Typography.Text
            style={{ fontSize: getConsistentSpacing(1.75), margin: 0 }}
          >
            ${record.total?.toLocaleString()}
          </Typography.Text>
        );
      },
    },
    {
      title: "Vendor",
      dataIndex: "vendor",
      key: "vendor",
      sorter: (a, b) => {
        return a.vendor?.name?.localeCompare(b.vendor?.name);
      },
      render: (_, record) => {
        return (
          <Typography.Text
            style={{ fontSize: getConsistentSpacing(1.75), margin: 0 }}
          >
            <HighlightedText
              text={record.vendor?.name}
              searchTerm={searchTerm}
            />
          </Typography.Text>
        );
      },
    },
    {
      title: "Payment Term",
      dataIndex: "paymentTerm",
      key: "paymentTerm",
      sorter: (a, b) => {
        return Number(a.paymentTerm) - Number(b.paymentTerm);
      },
      render: (_, record) => {
        const netTerm = getPurchaseOrderPaymentTerm(record.paymentTerm);

        return (
          <Typography.Text
            style={{ fontSize: getConsistentSpacing(1.75), margin: 0 }}
          >
            <HighlightedText text={netTerm || ""} />
          </Typography.Text>
        );
      },
    },
    {
      title: "Status",
      dataIndex: "status",
      key: "status",
      sorter: (a, b) => {
        return Number(a.status) - Number(b.status);
      },
      render: (_, record) => {
        const badgeType = getPurchaseOrderStatus(record.status);
        return (
          <Typography
            style={{ fontSize: getConsistentSpacing(1.75), margin: 0 }}
          >
            <PurchaseOrderStatus badgeType={badgeType} />
          </Typography>
        );
      },
    },
    {
      title: "",
      dataIndex: "",
      key: "",
      render: (_, record) =>
        !isInsideReports && (
          <Button
            shape="circle"
            className="hover:!fill-primary"
            icon={
              isFieldsCraftAuthorized() ? (
                <EyeOutlined />
              ) : (
                <CustomIcon type="edit" />
              )
            }
            onClick={() => navigateToEditPage(record)}
          />
        ),
    },
  ];

  function resetPaginationAndGetFirstPageResults() {
    if (isFirstCallComplete?.current === true) {
      if (filters) {
        setPage(1);
      }

      handleGetResults(1);
    } else {
      handleGetResults();
    }
  }

  useEffect(() => {
    if (!hasSearched) return;
    const timer = setTimeout(() => {
      if (searchTerm === "" && previousSearchTerm !== "") {
        resetPaginationAndGetFirstPageResults();
        setPreviousSearchTerm(searchTerm);
      }
    }, 500);

    return () => {
      clearTimeout(timer);
    };
  }, [searchTerm, hasSearched, previousSearchTerm]);

  const handleSearch = () => {
    if (searchTerm !== previousSearchTerm) {
      setHasSearched(true);
      resetPaginationAndGetFirstPageResults();
      setPreviousSearchTerm(searchTerm);
    }
  };

  useEffect(() => {
    if (
      !isFirstCallComplete?.current ||
      purchaseOrdersCurrentPage !== page ||
      purchaseOrdersPageSize !== pageSize
    ) {
      handleGetResults();

      if (!isFirstCallComplete?.current) {
        setTimeout(() => {
          isFirstCallComplete.current = true;
        }, 1000);
      }
    }
  }, [page, pageSize]);

  return (
    <>
      <SectionLayout isHidden={isInsideReports}>
        <CustomTable
          data={purchaseOrdersData || []}
          columns={columns || []}
          searchTerm={searchTerm}
          setSearchTerm={setSearchTerm}
          handleSearch={handleSearch}
          isLoading={isLoading}
          totalCount={totalCount}
          page={page}
          setPage={setPage}
          pageSize={pageSize}
          setPageSize={setPageSize}
          tableFilters={filters}
          reportFilterForParamsUseOnly={
            isInsideReports ? filterValues : undefined
          }
          setTableFilters={!isInsideReports ? setFilters : undefined}
          filterElements={
            !isInsideReports && (
              <CustomTableFilters
                filters={filters}
                setFilters={setFilters}
                buttons={filterButtons}
              />
            )
          }
          hasSearch={true}
          hasPagination={true}
          exportButtonEl={exportButtonEl}
          isInsideReports={isInsideReports}
          hasCursorPointer={isInsideReports}
          onRowClick={
            isInsideReports ? (co) => navigateToEditPage(co) : undefined
          }
          lastSearchTimestamp={lastSearchTimestamp}
          dueTimeButtons={filterButtons?.map((m) => ({
            ...m,
            isActive:
              m.value === "dueToday"
                ? buttonActive.isDueTodayActive
                : m.value === "overDue"
                ? buttonActive.isOverDueActive
                : buttonActive.isUpComingActive,
          }))}
          updateDueTimeButtons={updateDueTimeButtons}
        />
      </SectionLayout>
    </>
  );
}
