import CustomIcon from "@/src/components/common/CustomIcon";
// import CustomFormRow from "@/src/components/form/CustomFormRow";
// import {
//   dateFormat,
//   purchaseOrderSubmittalStatusOptions,
// } from "@/src/utils/constants";
import CustomOverlayLoader from "@/src/components/common/CustomOverlayloader";
import {
  ActionTypeState,
  AssumedSubmittal,
  PurchaseOrder,
  PurchaseOrderMaterials,
  Reorder,
} from "@/src/utils/types";
import { Button, Divider, Flex, Form, InputNumber } from "antd";
import dayjs from "dayjs";
import React, { useEffect, useState } from "react";
import {
  Control,
  Controller,
  FieldErrors,
  useFieldArray,
  UseFormSetValue,
  UseFormWatch,
} from "react-hook-form";
import POMaterialRow from "./POMaterialRow";
import ProcurementDetailsModal from "./ProcurementDetailsModal";
import {
  convertToLocaleString,
  isPOMatchingStatusDF,
} from "@/src/utils/helper";
import { formatDecimalsOnlyTwo } from "@/src/utils/number-extensions";
import { MaterialReviewPeriod } from "@/src/utils/enums";
import { handleIncrementDate } from "@/src/utils/date-helpers";

type PurchaseOrderMaterialFormProps = {
  control: Control<PurchaseOrderMaterials | any>;
  setValue: UseFormSetValue<PurchaseOrderMaterials | any>;
  watch: UseFormWatch<PurchaseOrderMaterials | any>;
  getValues: any;
  handleCalculateTotal: (index?: number) => void;
  actionType: ActionTypeState;
  errors: FieldErrors<PurchaseOrder>;

  register: any;
  toggleLoader: (shouldShow: boolean) => void;
  setPoMaxIndex: (index: number) => void;
  handleLikeAction: any;
  reorder: Reorder | null;
  assumedSubmittal: AssumedSubmittal;
};

const PurchaseOrderMaterialsRHF = React.memo(
  ({
    // trigger,
    // actionType,
    watch,
    setValue,
    getValues,
    control,
    handleCalculateTotal,
    register,
    toggleLoader,
    setPoMaxIndex,
    errors,
    handleLikeAction,
    reorder,
    assumedSubmittal,
  }: PurchaseOrderMaterialFormProps) => {
    const [isOpen, setIsOpen] = useState(false);

    const {
      fields: materialsFields,
      append: appendMaterials,
      remove: removeMaterial,
      update: updateMaterial,
    } = useFieldArray({
      control,
      name: "purchaseOrderMaterials",
    });

    useEffect(() => {
      //@ts-ignore
      updateMaterial();
    }, [reorder]);

    const [isLoading, setIsLoading] = useState(false);

    const handleRestProcurementFields = () => {
      const materials = getValues(`purchaseOrderMaterials`);

      const allChecked = materials?.every(
        (material: any) => material.checked === true
      );
      materials?.forEach((_: any, index: number) => {
        setValue(
          `purchaseOrderMaterials.${index}.isUniversalChecked`,
          allChecked
        );
      });
    };

    const handleChangeMaterialApproved = (
      value: string | number | boolean,
      materialIndex: number
    ) => {
      setValue(
        `purchaseOrderMaterials.${materialIndex}.isMaterialAlreadyApproved`,
        value
      );
    };

    const handleUniversalCheckBoxesChange = (value: boolean) => {
      const materials = getValues(`purchaseOrderMaterials`);
      materials.forEach(
        (material: PurchaseOrderMaterials, materialIndex: number) => {
          if (!material.isMaterialRejected) {
            setValue(`purchaseOrderMaterials.${materialIndex}.checked`, value);
          }
        }
      );
    };

    const handleAddMaterial = () => {
      const period =
        MaterialReviewPeriod[
          assumedSubmittal?.assumedSubmittalReviewPeriod ?? 0
        ]?.toLowerCase() || "day";
      appendMaterials({
        id: "",
        name: "",
        costCode: "",
        spares: 0,
        samples: 0,
        regular: 0,
        quantity: 0,
        unitOfMeasure: "",
        unitRate: 0,
        cost: 0,
        checked: false,
        maxMaterialLeadTime: 0,
        maxSubmittalLeadTime: 0,
        expectedDeliveryDate: handleIncrementDate(
          dayjs(new Date()),
          assumedSubmittal.assumedSubmittalReview,
          period as "day" | "week" | "month"
        ),
        expectedSubmittalDate: dayjs(new Date()),
        submittalStatus: 0,
        isMaterialAlreadyApproved: true,
      });
      handleRestProcurementFields();
    };

    return (
      <div className="mt-10 w-full">
        <ProcurementDetailsModal
          assumedSubmittal={assumedSubmittal}
          setIsLoading={setIsLoading}
          isLoading={isLoading}
          updateMaterial={updateMaterial}
          MaterialsControl={control}
          setValueMaterials={setValue}
          getValuesMaterials={getValues}
          setIsOpen={setIsOpen}
          isOpen={isOpen}
        />
        <div
          style={{
            marginBottom: "16px",
          }}
        >
          <Flex justify="flex-end">
            <button
              type="button"
              className="border-0 shadow-none bg-primary font-medium cursor-pointer text-white px-4 p-1 rounded-md"
              onClick={() => {
                setIsOpen(true);
              }}
            >
              Bulk Edit Procurement Details
            </button>
          </Flex>
        </div>
        {isLoading ? (
          <CustomOverlayLoader />
        ) : (
          <div className="">
            <POMaterialRow
              assumedSubmittal={assumedSubmittal}
              errors={errors}
              register={register}
              setValue={setValue}
              updateMaterial={updateMaterial}
              getValues={getValues}
              handleLikeAction={handleLikeAction}
              handleRestProcurementFields={handleRestProcurementFields}
              handleChangeMaterialApproved={handleChangeMaterialApproved}
              handleCalculateTotal={handleCalculateTotal}
              control={control}
              fields={materialsFields}
              watch={watch}
              handleUniversalCheckBoxesChange={handleUniversalCheckBoxesChange}
              removeMaterial={removeMaterial}
              toggleLoader={toggleLoader}
              setPoMaxIndex={setPoMaxIndex}
            />
          </div>
        )}
        <div>
          <Button
            disabled={isPOMatchingStatusDF(getValues("status"))}
            className="border-0 shadow-none text-primary font-medium cursor-pointer mt-5"
            size="small"
            icon={<CustomIcon width={16} type="add-circle" />}
            onClick={() => {
              toggleLoader(true);
              setPoMaxIndex(
                (getValues("purchaseOrderMaterials")?.length || 0) - 1
              );

              handleAddMaterial();
            }}
          >
            Add Material
          </Button>
          <div className="text-md float-end mt-5">
            {materialsFields.length} Row(s)
          </div>
        </div>
        <Divider className="mt-10 mb-5" />
        <Flex justify="end" align="flex-end" vertical>
          <Controller
            name="subTotal"
            control={control}
            render={({ field }) => (
              <Form.Item
                colon={false}
                layout="horizontal"
                initialValue={field.value || 0}
                label={
                  <span
                    style={{
                      marginRight: "30px",
                      fontSize: "1.05rem",
                      textAlign: "left",
                    }}
                  >
                    Subtotal
                  </span>
                }
              >
                <InputNumber
                  {...field}
                  disabled
                  size="large"
                  style={{ width: "80%" }}
                  min={0}
                  value={field.value || 0}
                  formatter={(value) => `$ ${convertToLocaleString(value)}`}
                  parser={(value) =>
                    value?.replace(/\$\s?|(,*)/g, "") as unknown as number
                  }
                />
              </Form.Item>
            )}
          />
          <Controller
            name="tax"
            control={control}
            render={({ field }) => {
              return (
                <Form.Item
                  colon={false}
                  layout="horizontal"
                  label={
                    <span
                      style={{
                        marginRight: "30px",
                        fontSize: "1.05rem",
                        textAlign: "left",
                      }}
                    >
                      Tax
                    </span>
                  }
                >
                  <InputNumber
                    {...field}
                    disabled
                    size="large"
                    style={{ width: "80%" }}
                    min={0}
                    formatter={(value) => `$ ${convertToLocaleString(value)}`}
                    parser={(value) =>
                      value?.replace(/\$\s?|(,*)/g, "") as unknown as number
                    }
                  />
                </Form.Item>
              );
            }}
          />
          <Controller
            name="total"
            control={control}
            render={({ field }) => (
              <Form.Item
                colon={false}
                layout="horizontal"
                className="font-bold"
                initialValue={field.value || 0}
                label={
                  <span style={{ marginRight: "20px", fontSize: "1.05rem" }}>
                    Total
                  </span>
                }
              >
                <InputNumber
                  {...field}
                  disabled
                  size="large"
                  style={{ width: "80%" }}
                  min={0}
                  value={formatDecimalsOnlyTwo(field.value) || 0}
                  formatter={(value) => `$ ${convertToLocaleString(value)}`}
                  parser={(value) =>
                    value?.replace(/\$\s?|(,*)/g, "") as unknown as number
                  }
                />
              </Form.Item>
            )}
          />
        </Flex>
      </div>
    );
  }
);

export default PurchaseOrderMaterialsRHF;
