import {
  getPurchaseOrderVendorById,
  updatePurchaseOrderVendor,
} from "@/src/apis/purchaseOrderApis";
import { getVendorslist } from "@/src/apis/vendorApis";
import CreatedByUserBadge from "@/src/components/common/CreatedByUserBadge";
import CustomAlert from "@/src/components/common/CustomAlert";
import CustomFormLabel from "@/src/components/common/CustomFormLabel";
import CustomFormRow from "@/src/components/form/CustomFormRow";
import SectionLayout from "@/src/components/layout/SectionLayout";
import { useAppDispatch } from "@/src/hooks/useAppDispatch";
import { useAppSelector } from "@/src/hooks/useAppSelector";
import {
  getPurchaseOrdersState,
  resetState,
} from "@/src/store/slices/purchaseOrderSlice";
import { getUserFullName } from "@/src/store/slices/userSlice";
import { getVendorsState } from "@/src/store/slices/vendorSlice";
import { ActionTypeEnum } from "@/src/utils/enums";
import routePaths from "@/src/utils/routePaths";
import { ActionTypeState, PurchaseOrder } from "@/src/utils/types";
import { Button, Col, Flex, Form, Input, Select, Typography } from "antd";
import { useEffect, useMemo, useState } from "react";
import { Controller, useForm } from "react-hook-form";
import { useNavigate, useParams } from "react-router-dom";

type PurchaseOrderRecipientTabTypeProps = {
  purchaseOrder?: PurchaseOrder | null;
  isAdminAuthorized: () => boolean;
  setStatus: (status: number) => void;
};

const PurchaseOrderRecipientTab = ({
  purchaseOrder,
  isAdminAuthorized,
  setStatus,
}: PurchaseOrderRecipientTabTypeProps) => {
  const dispatch = useAppDispatch();
  const { isSuccess, successMessage, resError, reqError } = useAppSelector(
    getPurchaseOrdersState
  );

  const { purchaseOrderId } = useParams();

  const navigate = useNavigate();
  const userFullName = useAppSelector(getUserFullName);
  const [actionType, setActionType] = useState<ActionTypeState>({
    delete: ActionTypeEnum.NEUTRAL,
    save: ActionTypeEnum.NEUTRAL,
    saveAndNew: ActionTypeEnum.NEUTRAL,
    saveAndRelease: ActionTypeEnum.NEUTRAL,
  });

  useEffect(() => {
    const fetchApprovals = async () => {
      setValue("vendorId", "");
      setValue("vendorAddress", "");
      dispatch(getVendorslist());
      const purchaseOrderVendor = await dispatch(
        getPurchaseOrderVendorById({ purchaseOrderId: purchaseOrderId || "" })
      ).unwrap();
      if (purchaseOrderVendor) {
        setValue("vendorId", purchaseOrderVendor?.vendor?.id || "");
        setValue(
          "vendorAddress",
          purchaseOrderVendor?.vendor.vendorAddress || ""
        );
      }
    };
    fetchApprovals();
    setStatus(purchaseOrder?.status || 0);
  }, []);

  const { vendorsList } = useAppSelector(getVendorsState);
  const memoizedVendorOptions = useMemo(() => {
    return [
      {
        value: "",
        label: "Select Vendor",
      },
      ...(vendorsList?.map((f) => ({
        value: f.id,
        label: f.name,
      })) || []),
    ];
  }, [vendorsList]);

  // Setting up React Hook Form
  const {
    control,
    handleSubmit,
    setValue,
    formState: { errors, isSubmitting },
  } = useForm({
    defaultValues: {
      vendorId: purchaseOrder?.vendor?.id || "",
      vendorAddress: purchaseOrder?.vendorAddress || "",
      toRelease: false,
    },
    mode: "onChange",
  });

  type PayloadTypeProps = {
    vendorId: string;
    vendorAddress: string;
    modifiedBy: string;
    toRelease: boolean;
  };

  const handleSaveVendor = async (payload: PayloadTypeProps) => {
    try {
      if (purchaseOrderId) {
        const id = purchaseOrderId;
        return await dispatch(
          updatePurchaseOrderVendor({ id, payload: { ...payload } })
        ).unwrap();
      }
    } catch (error) {
      console.error("Error submitting form:", error);
    }
  };
  const onSubmit = async (values: Omit<PayloadTypeProps, "modifiedBy">) => {
    console.log("values", values);
    const payload = {
      ...values,
      modifiedBy: userFullName,
    };

    try {
      if (actionType.save === ActionTypeEnum.SAVE) {
        const res = await handleSaveVendor(payload);
        setValue("vendorId", res?.purchaseOrderVendor?.vendor.id || "");
        setValue(
          "vendorAddress",
          res?.purchaseOrderVendor?.vendorAddress || ""
        );
      } else if (
        actionType.saveAndRelease === ActionTypeEnum.SAVE_AND_RELEASE
      ) {
        const res = await handleSaveVendor({ ...payload, toRelease: true });
        if (res?.isSuccess) {
          navigate(routePaths.PURCHASE_ORDERS);
        }
      }
    } catch (error) {
      console.error("Error during form submission:", error);
    }
  };

  useEffect(() => {
    dispatch(resetState());
  }, []);

  return (
    <SectionLayout>
      <Form
        layout="vertical"
        autoComplete="off"
        onFinish={handleSubmit(onSubmit)}
      >
        <CustomFormRow>
          <>
            <Col xs={24} className="mb-4">
              <Typography.Title level={5}>Vendor Information</Typography.Title>
            </Col>
          </>

          <Col xs={12}>
            <Form.Item labelAlign="right" required>
              <CustomFormLabel text="Add Vendor" required />
              <Controller
                name="vendorId"
                control={control}
                rules={{ required: "Vendor is required." }}
                render={({ field }) => (
                  <Select
                    {...field}
                    disabled={isAdminAuthorized() as boolean}
                    size="large"
                    placeholder="Select Vendor"
                    className="mt-3"
                    options={memoizedVendorOptions}
                    onChange={(value) => {
                      field.onChange(value);
                      const selectedVendor = vendorsList?.find(
                        (vendor) => vendor.id === value
                      );
                      setValue("vendorAddress", selectedVendor?.address || "");
                    }}
                    showSearch
                    filterOption={(input, option) =>
                      (option?.label ?? "")
                        .toLowerCase()
                        .includes(input.toLowerCase())
                    }
                  />
                )}
              />
              {errors.vendorId && (
                <Typography.Text type="danger">
                  {errors.vendorId.message}
                </Typography.Text>
              )}
            </Form.Item>
          </Col>

          <Col xs={12}>
            <Form.Item labelAlign="right" required>
              <CustomFormLabel text="Address" />
              <Controller
                name="vendorAddress"
                control={control}
                render={({ field }) => (
                  <Input.TextArea
                    {...field}
                    disabled={isAdminAuthorized() as boolean}
                    className="min-h-90 mt-3"
                    placeholder="Vendor Address"
                  />
                )}
              />
              {errors.vendorAddress && (
                <Typography.Text type="danger">
                  {errors.vendorAddress.message}
                </Typography.Text>
              )}
            </Form.Item>
          </Col>
        </CustomFormRow>

        {(resError || successMessage || reqError) && (
          <CustomAlert
            message={resError || reqError || successMessage || ""}
            type={isSuccess ? "success" : "error"}
          />
        )}
        <Flex justify="flex-end" className="gap-4 mt-7">
          <Button
            disabled={isSubmitting}
            type="default"
            onClick={() => navigate(routePaths.PURCHASE_ORDERS)}
          >
            Cancel
          </Button>

          <Button
            loading={actionType.save === ActionTypeEnum.SAVE && isSubmitting}
            disabled={isSubmitting || isAdminAuthorized()}
            type="primary"
            htmlType="submit"
            onClick={() =>
              setActionType({
                save: ActionTypeEnum.SAVE,
              })
            }
          >
            {actionType.save === ActionTypeEnum.SAVE && isSubmitting
              ? "Saving.."
              : "Save"}
          </Button>

          <Button
            loading={
              actionType.saveAndRelease === ActionTypeEnum.SAVE_AND_RELEASE &&
              isSubmitting
            }
            disabled={isSubmitting || isAdminAuthorized()}
            type="primary"
            htmlType="submit"
            onClick={() =>
              setActionType({
                saveAndRelease: ActionTypeEnum.SAVE_AND_RELEASE,
              })
            }
          >
            {actionType.saveAndRelease === ActionTypeEnum.SAVE_AND_RELEASE &&
            isSubmitting
              ? "Saving and Releasing.."
              : "Save & Release"}
          </Button>
        </Flex>

        {purchaseOrder?.id && (
          <Flex justify="flex-end" className="mt-5">
            <CreatedByUserBadge
              userName={purchaseOrder?.createdBy}
              // @ts-ignore
              date={purchaseOrder?.createdDate}
              isUpdatedBadge
            />
          </Flex>
        )}
      </Form>
    </SectionLayout>
  );
};

export default PurchaseOrderRecipientTab;
