import { getAllUsersSummaryList } from "@/src/apis/userApis";
import CustomFormLabel from "@/src/components/common/CustomFormLabel";
import CustomIcon from "@/src/components/common/CustomIcon";
import { useAppDispatch } from "@/src/hooks/useAppDispatch";
import { useAppSelector } from "@/src/hooks/useAppSelector";
import { getUsersListState } from "@/src/store/slices/userSlice";
import { UserRoleEnum } from "@/src/utils/enums";
import {
  getHelpMessageInPurchaseOrder,
  getValidateStatusInPurchaseOrder,
} from "@/src/utils/errorHelpers";
import { FormikLibraryHelperType } from "@/src/utils/library-helper-types";
import { Approver, PurchaseOrder } from "@/src/utils/types";
import { Button, Col, Flex, Form, Select } from "antd";
import { useEffect, useMemo } from "react";
import PhoneInput from "react-phone-input-2";

type PurchaseOrderValues = Pick<PurchaseOrder, "deliveryContacts">;

type PurchaseOrderDeliveryContactFormProps = {
  formik: FormikLibraryHelperType<PurchaseOrderValues>;
};

const PurchaseOrderSelect = ({
  formik,
}: PurchaseOrderDeliveryContactFormProps) => {
  const dispatch = useAppDispatch();
  const usersList = useAppSelector(getUsersListState);

  useEffect(() => {
    dispatch(
      getAllUsersSummaryList({
        roles: [
          UserRoleEnum.Engineer,
          UserRoleEnum.Fieldcraft,
          UserRoleEnum.Superintendent,
          UserRoleEnum.Admin,
        ],
      })
    );
  }, []);

  const memoizedAllUsersOptions = useMemo(() => {
    return [
      ...(usersList?.map((f) => ({
        value: f.id,
        label: f.firstName + " " + f.lastName,
      })) || []),
    ];
  }, [usersList]);

  const handleAddDeliveryContact = (add: () => void) => {
    const newDeliveryContact = {
      id: "",
      firstName: "",
      lastName: "",
      userName: "",
      email: "",
      phoneNumber: "",
      isActive: null,
    };

    formik.setFieldValue("deliveryContacts", [
      ...formik.values.deliveryContacts,
      newDeliveryContact,
    ]);
    add();
  };

  const handleChangeDeliveryContact = (value: string, index: number) => {
    const selectedDeliveryUser = usersList?.find(
      (user) => user.id === value
    ) as Approver;
    const deliveryContacts = [...formik.values.deliveryContacts];

    deliveryContacts[index] = selectedDeliveryUser;

    formik.setFieldValue("deliveryContacts", deliveryContacts);
  };

  const handleDeleteDeliveryContact = (index: number) => {
    formik.setFieldValue(
      "deliveryContacts",
      formik.values.deliveryContacts?.filter(
        (_, userIndex) => userIndex !== index
      )
    );
  };

  return (
    <>
      <Form.List
        initialValue={formik.values?.deliveryContacts}
        name="purchaseOrderDeliveryContact"
      >
        {(fields, { add, remove }) => (
          <>
            {fields?.map((field, index) => (
              <>
                <Col xs={12}>
                  <Form.Item
                    label={<CustomFormLabel text="Delivery Contact" />}
                    labelAlign="right"
                    required
                    initialValue={
                      formik.values.deliveryContacts[index]?.id || null
                    }
                    validateStatus={
                      getValidateStatusInPurchaseOrder({
                        formik,
                        field: "id",
                        index,
                      }) as "error"
                    }
                    help={getHelpMessageInPurchaseOrder({
                      formik,
                      field: "id",
                      index,
                    })}
                  >
                    <Select
                      value={formik.values.deliveryContacts[index]?.id || null}
                      onChange={(value) =>
                        handleChangeDeliveryContact(value, index)
                      }
                      size="large"
                      placeholder="Select User"
                      options={memoizedAllUsersOptions}
                      showSearch
                      filterOption={(input, option) =>
                        (option?.label ?? "")
                          .toLowerCase()
                          .includes(input.toLowerCase())
                      }
                    />
                  </Form.Item>
                </Col>
                <Col xs={12}>
                  <Form.Item
                    {...field}
                    label={
                      <CustomFormLabel text={`Contact Phone ${index + 1}`} />
                    }
                    labelAlign="right"
                    required
                  >
                    <Flex align="center">
                      <PhoneInput
                        placeholder="(555) 000-0000"
                        country={"us"}
                        value={
                          formik.values.deliveryContacts[index]?.phoneNumber ||
                          ""
                        }
                        inputProps={{
                          autoFocus: true,
                        }}
                      />
                      <Button
                        disabled={fields.length <= 1}
                        onClick={() => {
                          handleDeleteDeliveryContact(index);
                          remove(field.name);
                        }}
                        className="border-0 shadow-none text-primary font-medium"
                      >
                        Delete
                      </Button>
                    </Flex>
                  </Form.Item>
                </Col>
              </>
            ))}
            <Col xs={24} style={{ marginBottom: "16px" }}>
              <Flex justify="space-between">
                <Button
                  className="border-0 shadow-none text-primary font-medium"
                  size="small"
                  icon={<CustomIcon width={16} type="add-circle" />}
                  onClick={() => {
                    console.log("fields", fields);
                    handleAddDeliveryContact(add);
                  }}
                >
                  Add Delivery Contact
                </Button>
              </Flex>
            </Col>
          </>
        )}
      </Form.List>
    </>
  );
};

export default PurchaseOrderSelect;
