import CustomFormRow from "@/src/components/form/CustomFormRow";
import {
  dateFormat,
  purchaseOrderSubmittalStatusOptions,
} from "@/src/utils/constants";
import {
  Button,
  Col,
  DatePicker,
  Form,
  InputNumber,
  Radio,
  Select,
  Space,
} from "antd";
import dayjs from "dayjs";
import { useState } from "react";
import { Controller } from "react-hook-form";

type ApproveSectionProps = {
  materialIndex: number;
  control: any;
  handleChangeMaterialApproved: (e: any, materialIndex: number) => void;
};

const ApproveSection = ({
  materialIndex,
  control,
  handleChangeMaterialApproved,
}: ApproveSectionProps) => {
  const [isHideFields, setIsHideFields] = useState(false);

  return (
    <div>
      <CustomFormRow>
        <Col xs={1}></Col>
        <Col xs={4}>
          <Form.Item
            label="Is material already approved?"
            labelAlign="right"
            required
          >
            <Controller
              name={`purchaseOrderMaterials.${materialIndex}.isMaterialApproved`}
              control={control}
              render={({ field }) => (
                <Radio.Group
                  {...field}
                  onChange={(e) => {
                    handleChangeMaterialApproved(e, materialIndex);
                    setIsHideFields(!isHideFields);
                  }}
                >
                  <Radio value={true}>Yes</Radio>
                  <Radio value={false}>No</Radio>
                </Radio.Group>
              )}
            />
          </Form.Item>
        </Col>

        {isHideFields && (
          <>
            <Col xs={4}>
              <Form.Item label="Max Submittal Lead Time">
                <Controller
                  name={`purchaseOrderMaterials.${materialIndex}.maxMaterialLeadTime`}
                  control={control}
                  render={({ field }) => {
                    return (
                      <Space.Compact size="large" style={{ width: "100%" }}>
                        <InputNumber
                          {...field}
                          style={{ width: "75%" }}
                          min={0}
                          size="large"
                          type="number"
                          placeholder="In weeks"
                        />
                        <Button
                          disabled
                          style={{
                            cursor: "default",
                            width: "25%",
                            fontSize: "0.75rem",
                          }}
                        >
                          Weeks
                        </Button>
                      </Space.Compact>
                    );
                  }}
                />
              </Form.Item>
            </Col>
            <Col xs={4}>
              <Form.Item
                label="Expected Submittal Date"
                tooltip='Entering an Expected Submittal Date will override the "Max Submittal Lead Time" and "Expected Delivery Date" fields'
              >
                <Controller
                  name={`purchaseOrderMaterials.${materialIndex}.expectedSubmittalDate`}
                  control={control}
                  render={({ field }) => (
                    <DatePicker
                      value={
                        dayjs(field.value).isValid()
                          ? dayjs(field.value)
                          : dayjs(new Date())
                      }
                      onChange={(date) => {
                        field.onChange(dayjs(date).locale("en").format());
                      }}
                      size="large"
                      style={{ width: "100%" }}
                      placeholder="MM/DD/YYYY"
                      format={dateFormat}
                    />
                  )}
                />
              </Form.Item>
            </Col>

            <Col xs={4}>
              <Form.Item
                label="Expected Delivery Date"
                tooltip='Entering an Expected Delivery Date will override the "Max Submittal Lead Time"'
              >
                <Controller
                  name={`purchaseOrderMaterials.${materialIndex}.expectedDeliveryDate`}
                  control={control}
                  render={({ field }) => (
                    <DatePicker
                      value={
                        dayjs(field.value).isValid()
                          ? dayjs(field.value)
                          : dayjs(new Date())
                      }
                      onChange={(date) => field.onChange(dayjs(date).format())}
                      size="large"
                      style={{ width: "100%" }}
                      placeholder="MM/DD/YYYY"
                      format={dateFormat}
                    />
                  )}
                />
              </Form.Item>
            </Col>

            <Col xs={4}>
              <Form.Item label="Max Material Lead Time">
                <Controller
                  name={`purchaseOrderMaterials.${materialIndex}.maxSubmittalLeadTime`}
                  control={control}
                  render={({ field }) => (
                    <Space.Compact size="large" style={{ width: "100%" }}>
                      <InputNumber
                        {...field}
                        style={{ width: "75%" }}
                        min={0}
                        type="number"
                        size="large"
                        placeholder="In weeks"
                      />
                      <Button
                        disabled
                        style={{
                          cursor: "default",
                          width: "25%",
                          fontSize: "0.75rem",
                        }}
                      >
                        Weeks
                      </Button>
                    </Space.Compact>
                  )}
                />
              </Form.Item>
            </Col>

            <Col xs={3}>
              <Form.Item label="Submittal Status">
                <Controller
                  name={`purchaseOrderMaterials.${materialIndex}.submittalStatus`}
                  control={control}
                  render={({ field }) => (
                    <Select
                      size="large"
                      {...field}
                      placeholder="Select Submittal Status"
                      options={purchaseOrderSubmittalStatusOptions}
                      onChange={(value) => field.onChange(value)}
                      showSearch
                      filterOption={(input, option) =>
                        (option?.label || "")
                          .toLowerCase()
                          .includes(input.toLowerCase())
                      }
                    />
                  )}
                />
              </Form.Item>
            </Col>
          </>
        )}
      </CustomFormRow>
    </div>
  );
};

export default ApproveSection;
