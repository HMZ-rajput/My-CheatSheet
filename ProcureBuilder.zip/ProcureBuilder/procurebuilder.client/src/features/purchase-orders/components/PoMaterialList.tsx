import CustomFormRow from "@/src/components/form/CustomFormRow";
import DeleteIconButton from "@/src/components/icon-buttons/DeleteIconButton";
import { Checkbox, Col, Form, Input, InputNumber, Row, Typography } from "antd";
import React from "react";
import { Controller } from "react-hook-form";
import ApproveSection from "./ApproveSection";

const { Text } = Typography;

type POMaterialList = {
  control: any;
  getValues: any;
  materialsFields: Record<"id", string>[];
  handleUniversalCheckBoxesChange: (e: any) => void;
  handleChangeMaterialApproved: (e: any, materialIndex: number) => void;
  removeMaterial: (materialIndex: number) => void;
  handleChangeValue: () => void;
  //   watch: UseFormWatch<any>;
  //   getValues: any;
};

const PoMaterialList = React.memo(
  ({
    materialsFields,
    control,
    handleUniversalCheckBoxesChange,
    handleChangeMaterialApproved,
    removeMaterial,
    handleChangeValue,
  }: POMaterialList) => {
    console.log("Child");

    return (
      <div>
        {materialsFields?.map((_, materialIndex) => (
          <div key={materialIndex}>
            <CustomFormRow>
              <>
                <div
                  style={{ backgroundColor: "whitesmoke" }}
                  className="py-1.5 px-2 rounded-lg mb-4 w-full"
                >
                  <Row className="bg-slate-400">
                    <Col xs={1} className="mr-0.5">
                      {materialIndex === 0 && (
                        <Checkbox
                          onChange={(e) => handleUniversalCheckBoxesChange(e)}
                        />
                      )}
                    </Col>
                    <Col xs={4} className="">
                      <Text className="font-medium text-xs">Material</Text>
                    </Col>
                    <Col xs={2} className="">
                      <Text className="font-medium text-xs">Cost Code</Text>
                    </Col>
                    <Col xs={2} className="">
                      <Text className="font-medium text-xs">Regular</Text>
                    </Col>
                    <Col xs={2} className="mr-1">
                      <Text className="font-medium text-xs">Spares</Text>
                    </Col>
                    <Col xs={2} className="">
                      <Text className="font-medium text-xs">Samples</Text>
                    </Col>
                    <Col xs={2} className="">
                      <Text className="font-medium text-xs">Quantity</Text>
                    </Col>
                    <Col xs={2} className="mr-1.5">
                      <Text className="font-medium text-xs">
                        Unit of Measurement
                      </Text>
                    </Col>
                    <Col xs={2} className="mr-1.5">
                      <Text className="font-medium text-xs">Unit Rate</Text>
                    </Col>
                    <Col xs={3} className="mr-1.5">
                      <Text className="font-medium text-xs">Amount</Text>
                    </Col>
                  </Row>
                </div>
              </>

              <Col xs={1}>
                <Form.Item>
                  <Controller
                    //   disabled
                    name={`purchaseOrderMaterials.${materialIndex}.checked`}
                    control={control}
                    render={({ field }) => (
                      <Form.Item>
                        <Checkbox
                          checked={field.value}
                          {...field}
                          onChange={field.onChange}
                        />
                      </Form.Item>
                    )}
                  />
                </Form.Item>
              </Col>
              <Col xs={4}>
                <Form.Item>
                  <Controller
                    name={`purchaseOrderMaterials.${materialIndex}.name`}
                    control={control}
                    render={({ field }) => {
                      return (
                        <Form.Item
                          //   help={
                          //     errors?.purchaseOrderMaterials?.[materialIndex]
                          //       ?.name?.message
                          //   }
                          //   validateStatus={   ? "error" : ""}
                          className="!mb-0"
                        >
                          <Input
                            {...field}
                            size="large"
                            placeholder="Material"
                          />
                        </Form.Item>
                      );
                    }}
                  />
                </Form.Item>
              </Col>

              <Col xs={2}>
                <Form.Item>
                  <Controller
                    name={`purchaseOrderMaterials.${materialIndex}.costCode`}
                    control={control}
                    render={({ field }) => {
                      return (
                        <Form.Item>
                          <Input
                            min={0}
                            {...field}
                            size="large"
                            placeholder="Cost Code"
                            style={{ width: "100%" }}
                          />
                        </Form.Item>
                      );
                    }}
                  />
                </Form.Item>
              </Col>

              <Col xs={2}>
                <Form.Item>
                  <Controller
                    name={`purchaseOrderMaterials.${materialIndex}.regular`}
                    control={control}
                    render={({ field }) => (
                      <Form.Item>
                        <InputNumber
                          {...field}
                          onChange={(value) => {
                            field.onChange(value);
                            handleChangeValue();
                          }}
                          style={{ width: "100%" }}
                          size="large"
                          placeholder={"0"}
                          min={0}
                          type="number"
                        />
                      </Form.Item>
                    )}
                  />
                </Form.Item>
              </Col>
              <Col xs={2}>
                <Form.Item>
                  <Controller
                    name={`purchaseOrderMaterials.${materialIndex}.spares`}
                    control={control}
                    render={({ field }) => {
                      return (
                        <Form.Item>
                          <InputNumber
                            min={0}
                            {...field}
                            onChange={(value) => {
                              field.onChange(value);
                              handleChangeValue();
                            }}
                            size="large"
                            placeholder="0"
                            type="number"
                            style={{ width: "100%" }}
                          />
                        </Form.Item>
                      );
                    }}
                  />
                </Form.Item>
              </Col>
              <Col xs={2}>
                <Form.Item>
                  <Controller
                    name={`purchaseOrderMaterials.${materialIndex}.samples`}
                    control={control}
                    render={({ field }) => {
                      return (
                        <Form.Item>
                          <InputNumber
                            min={0}
                            {...field}
                            onChange={(value) => {
                              field.onChange(value);
                              handleChangeValue();
                            }}
                            size="large"
                            placeholder="0"
                            type="number"
                            style={{ width: "100%" }}
                          />
                        </Form.Item>
                      );
                    }}
                  />
                </Form.Item>
              </Col>

              <Col xs={2}>
                <Form.Item>
                  <Controller
                    name={`purchaseOrderMaterials.${materialIndex}.newQuantity`}
                    control={control}
                    render={({ field }) => {
                      return (
                        <Form.Item>
                          <Input
                            disabled
                            {...field}
                            size="large"
                            placeholder="Total"
                          />
                        </Form.Item>
                      );
                    }}
                  />
                </Form.Item>
              </Col>
              <Col xs={2}>
                <Form.Item>
                  <Controller
                    name={`purchaseOrderMaterials.${materialIndex}.unitOfMeasure`}
                    control={control}
                    render={({ field }) => {
                      return (
                        <Form.Item>
                          <Input {...field} size="large" placeholder="Unit" />
                        </Form.Item>
                      );
                    }}
                  />
                </Form.Item>
              </Col>

              <Col xs={2}>
                <Form.Item>
                  <Controller
                    name={`purchaseOrderMaterials.${materialIndex}.unitRate`}
                    control={control}
                    render={({ field }) => {
                      return (
                        <Form.Item>
                          <InputNumber
                            {...field}
                            onChange={(value) => {
                              field.onChange(value);
                              handleChangeValue();
                            }}
                            style={{ width: "100%" }}
                            type="number"
                            size="large"
                            placeholder="0"
                          />
                        </Form.Item>
                      );
                    }}
                  />
                </Form.Item>
              </Col>
              <Col xs={4}>
                <Form.Item>
                  <Controller
                    name={`purchaseOrderMaterials.${materialIndex}.cost`}
                    control={control}
                    render={({ field }) => {
                      return (
                        <Form.Item>
                          <Input
                            style={{ width: "100%" }}
                            {...field}
                            size="large"
                            placeholder="Amount"
                          />
                        </Form.Item>
                      );
                    }}
                  />
                </Form.Item>
              </Col>
              <Col className="mt-1" xs={1}>
                <DeleteIconButton
                  disabled={materialsFields.length === 1}
                  handleDelete={() => {
                    removeMaterial(materialIndex);
                  }}
                />
              </Col>
            </CustomFormRow>

            <ApproveSection
              // getValues={getValues}
              materialIndex={materialIndex}
              control={control}
              handleChangeMaterialApproved={handleChangeMaterialApproved}
            />
          </div>
        ))}
      </div>
    );
  }
);

export default PoMaterialList;
