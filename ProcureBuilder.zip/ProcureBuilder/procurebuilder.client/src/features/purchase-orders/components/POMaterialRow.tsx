import { downloadPdfForSingleMaterial } from "@/src/apis/purchaseOrderApis";
import CustomFormLabel from "@/src/components/common/CustomFormLabel";
import CustomIcon from "@/src/components/common/CustomIcon";
import CustomInput from "@/src/components/form/CustomInput";
import CustomRadio from "@/src/components/form/CustomRadio";
import DeleteIconButton from "@/src/components/icon-buttons/DeleteIconButton";
import { useAppSelector } from "@/src/hooks/useAppSelector";
import useAuthorization from "@/src/hooks/useAuthorization";
import { getUserState } from "@/src/store/slices/userSlice";
import { manuallyDownloadBlob } from "@/src/utils/api-helpers";
import {
  dateFormat,
  isFreight,
  purchaseOrderSubmittalStatusOptions,
  Roles,
} from "@/src/utils/constants";
import { handleIncrementDate } from "@/src/utils/date-helpers";
import { MaterialReviewPeriod } from "@/src/utils/enums";
import {
  convertToLocaleString,
  handleNumericInput,
  isPOMatchingStatusDF,
} from "@/src/utils/helper";
import {
  AssumedSubmittal,
  PurchaseOrder,
  PurchaseOrderMaterials,
} from "@/src/utils/types";
import { DatePicker, Form, InputNumber, Select } from "antd";
import dayjs, { Dayjs } from "dayjs";
import React, { useEffect, useRef, useState } from "react";
import {
  Control,
  Controller,
  FieldErrors,
  UseFieldArrayRemove,
  UseFormWatch,
} from "react-hook-form";
import { VariableSizeList as List } from "react-window";

type POMaterialRowProps = {
  control: Control<PurchaseOrder, any>;
  fields: Record<"id", string>[];
  // index: number;
  removeMaterial: UseFieldArrayRemove;
  watch: UseFormWatch<any>;
  handleCalculateTotal: () => void;
  handleUniversalCheckBoxesChange: (value: boolean) => void;
  handleRestProcurementFields: () => void;
  handleChangeMaterialApproved: (
    value: string | number | boolean,
    materialIndex: number
  ) => void;
  handleLikeAction: (index: number, action: boolean) => void;
  getValues: any;
  setValue: any;
  updateMaterial: any;
  register: any;
  errors: FieldErrors<PurchaseOrder>;
  toggleLoader: (shouldShow: boolean) => void;
  setPoMaxIndex: (index: number) => void;
  assumedSubmittal: AssumedSubmittal;
  // handleSetProcurementDetails: () => void;
};
const POMaterialRow = React.memo(
  ({
    control,
    fields,
    handleUniversalCheckBoxesChange,
    handleChangeMaterialApproved,
    removeMaterial,
    watch,
    handleCalculateTotal,
    handleRestProcurementFields,
    handleLikeAction,
    getValues,
    updateMaterial,
    register,
    toggleLoader,
    setPoMaxIndex,
    errors,
    setValue,
    assumedSubmittal,
  }: POMaterialRowProps) => {
    const ref = useRef<HTMLDivElement>(null);
    const { data } = useAppSelector(getUserState);
    const [forceRender, setForceRender] = useState(Date.now());
    const previousLength = useRef(fields.length);
    const { isFieldsCraftAuthorized } = useAuthorization();
    const isMaterialDisabled = (index: number) => {
      return (
        getValues(`purchaseOrderMaterials.${index}.isMaterialRejected`) ||
        isPOMatchingStatusDF(getValues("status"))
      );
    };

    const listRef = useRef<List>(null);

    const MAX_HEIGHT = 800;
    const estimatedItemHeight = 200;
    const listHeight = Math.min(
      fields?.length * estimatedItemHeight,
      MAX_HEIGHT
    );

    const scrollToError = (index: number) => {
      if (listRef.current) {
        listRef.current.scrollToItem(index, "center");
      }
    };

    useEffect(() => {
      if (errors?.purchaseOrderMaterials) {
        const firstErrorIndex = fields?.findIndex((_, index) => {
          const materialError = errors?.purchaseOrderMaterials?.[index];
          return (
            materialError?.name ||
            materialError?.costCode ||
            materialError?.unitOfMeasure
          );
        });

        if (firstErrorIndex !== -1 && firstErrorIndex !== undefined) {
          scrollToError(firstErrorIndex);
        }
      }
    }, [errors]);

    useEffect(() => {
      if (listRef.current) {
        if (fields?.length > previousLength.current) {
          listRef.current.scrollToItem(fields.length - 1, "end");
        }
        previousLength.current = fields.length;
      }
    }, [fields.length]);

    const getItemSize = (index: number) => {
      return index === 0 ? 195 : 240;
    };
    const checkForError = (
      index: number,
      keyName: keyof PurchaseOrderMaterials
    ): Boolean | any => {
      const materialValue = getValues(`purchaseOrderMaterials.${index}`);
      const errorMessage = "Cannot add materials with same name.";
      if (
        errors?.purchaseOrderMaterials?.[index]?.[keyName]?.message
          ?.toLowerCase()
          ?.trim() === errorMessage?.toLowerCase()?.trim()
      ) {
        return errors?.purchaseOrderMaterials?.[index]?.[keyName];
      }
      return (
        !materialValue?.[keyName] &&
        errors?.purchaseOrderMaterials?.[index]?.[keyName]
      );
    };

    const handleSubmittalLeadTimeChange = (
      numericValue: number,
      index: number
    ) => {
      const submittalDate = dayjs(new Date()).format(dateFormat);
      const newSubmittalDate = handleIncrementDate(
        submittalDate,
        numericValue,
        "week"
      );
      setValue(
        `purchaseOrderMaterials.${index}.expectedSubmittalDate`,
        newSubmittalDate
      );
      const reviewPeriodUnit =
        MaterialReviewPeriod[
          assumedSubmittal?.assumedSubmittalReviewPeriod ?? 0
        ]?.toLowerCase() || "day";

      const reviewPeriodUnitFormatted = reviewPeriodUnit as
        | "day"
        | "week"
        | "month";

      const reviewPeriodInDays = handleIncrementDate(
        newSubmittalDate,
        assumedSubmittal.assumedSubmittalReview,
        reviewPeriodUnitFormatted
      );
      const materialLeadTime = getValues(
        `purchaseOrderMaterials.${index}.maxMaterialLeadTime`
      );

      const newDeliveryDate = handleIncrementDate(
        reviewPeriodInDays,
        materialLeadTime,
        "week"
      );

      setValue(
        `purchaseOrderMaterials.${index}.expectedDeliveryDate`,
        newDeliveryDate
      );
    };

    const handleExpectedSubmittalDateChange = (date: Dayjs, index: number) => {
      setValue(
        `purchaseOrderMaterials.${index}.expectedSubmittalDate`,
        date.format(dateFormat)
      );
      const reviewPeriodUnit =
        MaterialReviewPeriod[
          assumedSubmittal?.assumedSubmittalReviewPeriod ?? 0
        ]?.toLowerCase() || "day";

      const reviewPeriodUnitFormatted = reviewPeriodUnit as
        | "day"
        | "week"
        | "month";
      const reviewPeriodInDays = handleIncrementDate(
        date,
        assumedSubmittal.assumedSubmittalReview,
        reviewPeriodUnitFormatted
      );

      const materialLeadTime = getValues(
        `purchaseOrderMaterials.${index}.maxMaterialLeadTime`
      );

      const newDeliveryDate = handleIncrementDate(
        reviewPeriodInDays,
        materialLeadTime,
        "week"
      );

      setValue(
        `purchaseOrderMaterials.${index}.expectedDeliveryDate`,
        newDeliveryDate
      );
    };

    const handleMaxMaterialLeadTimeChange = (
      numericValue: number,
      index: number
    ) => {
      const submittalDate = dayjs(
        getValues(`purchaseOrderMaterials.${index}.expectedSubmittalDate`)
      ).isValid()
        ? getValues(`purchaseOrderMaterials.${index}.expectedSubmittalDate`)
        : dayjs(new Date()).format(dateFormat);
      const reviewPeriodUnit =
        MaterialReviewPeriod[
          assumedSubmittal?.assumedSubmittalReviewPeriod ?? 0
        ]?.toLowerCase() || "day";

      const reviewPeriodUnitFormatted = reviewPeriodUnit as
        | "day"
        | "week"
        | "month";

      const reviewPeriodInDays = handleIncrementDate(
        submittalDate,
        assumedSubmittal.assumedSubmittalReview,
        reviewPeriodUnitFormatted
      );

      const newDeliveryDate = handleIncrementDate(
        reviewPeriodInDays,
        numericValue,
        "week"
      );
      setValue(
        `purchaseOrderMaterials.${index}.expectedDeliveryDate`,
        newDeliveryDate
      );
    };

    const renderRow = ({
      index,
      style,
    }: {
      index: number;
      style: React.CSSProperties;
    }) => {
      const currentMaterial = fields[index];

      const showDownloadButtonForMaterial = () => {
        const hasPOId = getValues("id");
        const isSameAsFreight =
          getValues(`purchaseOrderMaterials.${index}.name`).toLowerCase() ===
          isFreight;
        const isAllowedForFieldCraft = isFieldsCraftAuthorized();
        const hideForPendingApprovalStatus = isPOMatchingStatusDF(
          getValues("status")
        );

        return (
          hasPOId &&
          hideForPendingApprovalStatus &&
          !isSameAsFreight &&
          !isAllowedForFieldCraft
        );
      };

      const isRejected = getValues(
        `purchaseOrderMaterials.${index}.isMaterialRejected`
      );

      return (
        <div
          style={style}
          className="materials-row "
          key={currentMaterial.id}
          // data-material-loader-index={index}
        >
          <div key={currentMaterial.id} ref={ref}>
            {index !== 0 && (
              <div className="materials-header-row flex w-full py-1.5 px-2 rounded-lg mb-4 bg-neutral-0 ">
                <div className="col col-xs-1"></div>
                <div className="col col-xs-4">
                  <span className="font-medium text-xs">Material</span>
                </div>
                <div className="col col-xs-4">
                  <span className="font-medium text-xs">Cost Code</span>
                </div>
                {/* <div className="col col-xs-2">
                  <span className="font-medium text-xs">Regular</span>
                </div>
                <div className="col col-xs-2">
                  <span className="font-medium text-xs">Spares</span>
                </div>
                <div className="col col-xs-2">
                  <span className="font-medium text-xs">Samples</span>
                </div> */}
                <div className="col col-xs-4">
                  <span className="font-medium text-xs">Quantity</span>
                </div>
                <div className="col col-xs-3 mr-2">
                  <span className="font-medium text-xs text-wrap">
                    Unit of Measurement
                  </span>
                </div>

                <div className="col col-xs-3 ml-1">
                  <span className="font-medium text-xs">Unit Rate</span>
                </div>
                <div className="col col-xs-3">
                  <span className="font-medium text-xs">Amount</span>
                </div>
              </div>
            )}
            <div className="materials-first-row flex items-start mt-7">
              <div className="col pr-4 col-xs-1">
                <Controller
                  name={`purchaseOrderMaterials.${index}.checked`}
                  control={control}
                  render={({ field }) => (
                    <CustomInput
                      disabled={isRejected}
                      isLineThrough={isRejected}
                      {...field}
                      onChange={(value) => {
                        field.onChange(value);
                        handleRestProcurementFields();
                      }}
                      checked={field.value}
                      type="checkbox"
                    />
                  )}
                />
              </div>
              <div className="col pr-4 col-xs-4">
                <Controller
                  name={`purchaseOrderMaterials.${index}.name`}
                  control={control}
                  render={({ field }) => {
                    return (
                      <div
                        key={index}
                        ref={
                          register(`purchaseOrderMaterials.${index}.name`).ref
                        }
                      >
                        <input
                          className={`custom-input ${
                            isRejected && "line-through"
                          }`}
                          {...register(`purchaseOrderMaterials.${index}.name`)}
                          disabled={
                            data?.role == Roles.Admin ||
                            data?.role == Roles.SuperAdmin
                              ? false
                              : field?.value?.toLowerCase()?.trim() ===
                                  isFreight || isMaterialDisabled(index)
                          }
                          placeholder="Material"
                          value={field.value}
                          onChange={(e) => {
                            setValue(
                              `purchaseOrderMaterials.${index}.name`,
                              e.target.value
                            );
                            handleCalculateTotal();
                          }}
                        />
                        {checkForError(index, "name") && (
                          <span className="block mt-1 text-error break-words">
                            {checkForError(index, "name")?.message}
                          </span>
                        )}
                      </div>
                    );
                  }}
                />
              </div>
              <div className="col pr-4 col-xs-4">
                <Controller
                  name={`purchaseOrderMaterials.${index}.costCode`}
                  control={control}
                  render={({ field }) => {
                    return (
                      <div
                        key={index}
                        ref={
                          register(`purchaseOrderMaterials.${index}.costCode`)
                            .ref
                        }
                      >
                        <input
                          className={`custom-input ${
                            isRejected && "line-through"
                          }`}
                          {...register(
                            `purchaseOrderMaterials.${index}.costCode`
                          )}
                          disabled={
                            data?.role == Roles.Admin ||
                            data?.role == Roles.SuperAdmin
                              ? false
                              : isMaterialDisabled(index)
                          }
                          placeholder="Cost Code"
                          onChange={(e) => {
                            const { value } = e.target;
                            field.onChange(value);
                            if (
                              field.name ===
                                `purchaseOrderMaterials.1.costCode` &&
                              getValues(
                                "purchaseOrderMaterials.0.name"
                              ).toLowerCase() === isFreight
                            ) {
                              setValue(
                                `purchaseOrderMaterials.0.costCode`,
                                value
                              );
                            }
                          }}
                        />
                        {checkForError(index, "costCode") && (
                          <span className="block mt-1 text-error break-words">
                            {checkForError(index, "costCode")?.message}
                          </span>
                        )}
                      </div>
                    );
                  }}
                />
              </div>
              {/* <div className="col pr-4 col-xs-2">
                <Controller
                  name={`purchaseOrderMaterials.${index}.regular`}
                  control={control}
                  render={({ field, formState: { errors } }) => {
                    const materialError = (
                      errors?.purchaseOrderMaterials as unknown as
                        | FieldErrorsImpl<PurchaseOrderMaterials>[]
                        | undefined
                    )?.[index]?.regular;
                    return (
                      <div
                        ref={
                          register(`purchaseOrderMaterials.${index}.regular`)
                            .ref
                        }
                      >
                        <CustomInput
                          isLineThrough={isRejected}
                          disabled={isMaterialDisabled(index)}
                          error={materialError?.message}
                          {...field}
                          onChange={(value: string | number | boolean) => {
                            if (
                              typeof value !== "string" &&
                              typeof value !== "number"
                            )
                              return;
                            const numericValue = handleNumericInput(value);
                            field.onChange(numericValue);
                            handleCalculateTotal();
                          }}
                          type="number"
                          placeholder="0"
                          min={0}
                        />
                      </div>
                    );
                  }}
                />
              </div>
              <div className="col pr-4 col-xs-2">
                <Controller
                  name={`purchaseOrderMaterials.${index}.spares`}
                  control={control}
                  render={({ field, formState: { errors } }) => {
                    const materialError = (
                      errors?.purchaseOrderMaterials as unknown as
                        | FieldErrorsImpl<PurchaseOrderMaterials>[]
                        | undefined
                    )?.[index]?.spares;
                    return (
                      <div
                        ref={
                          register(`purchaseOrderMaterials.${index}.spares`).ref
                        }
                      >
                        <CustomInput
                          isLineThrough={isRejected}
                          disabled={isMaterialDisabled(index)}
                          error={materialError?.message}
                          {...field}
                          onChange={(value: string | number | boolean) => {
                            if (
                              typeof value !== "string" &&
                              typeof value !== "number"
                            )
                              return;
                            const numericValue = handleNumericInput(value);
                            field.onChange(numericValue);
                            handleCalculateTotal();
                          }}
                          placeholder="Spares"
                          min={0}
                          type="number"
                        />
                      </div>
                    );
                  }}
                />
              </div>
              <div className="col pr-4 col-xs-2">
                <Controller
                  name={`purchaseOrderMaterials.${index}.samples`}
                  control={control}
                  render={({ field, formState: { errors } }) => {
                    const materialError = (
                      errors?.purchaseOrderMaterials as unknown as
                        | FieldErrorsImpl<PurchaseOrderMaterials>[]
                        | undefined
                    )?.[index]?.spares;
                    return (
                      <div
                        ref={
                          register(`purchaseOrderMaterials.${index}.samples`)
                            .ref
                        }
                      >
                        <CustomInput
                          isLineThrough={isRejected}
                          disabled={isMaterialDisabled(index)}
                          error={materialError?.message}
                          {...field}
                          onChange={(value: string | number | boolean) => {
                            if (
                              typeof value !== "string" &&
                              typeof value !== "number"
                            )
                              return;
                            const numericValue = handleNumericInput(value);
                            field.onChange(numericValue);
                            handleCalculateTotal();
                          }}
                          placeholder="Samples"
                          min={0}
                          type="number"
                        />
                      </div>
                    );
                  }}
                />
              </div> */}
              <div className="col pr-4 col-xs-4">
                <Controller
                  name={`purchaseOrderMaterials.${index}.quantity`}
                  control={control}
                  render={({ field }) => {
                    return (
                      <div
                        ref={
                          register(`purchaseOrderMaterials.${index}.quantity`)
                            .ref
                        }
                      >
                        <CustomInput
                          {...field}
                          onChange={(value) => {
                            field.onChange(value);
                            handleCalculateTotal();
                          }}
                          isLineThrough={isRejected}
                          disabled={isMaterialDisabled(index)}
                          placeholder="Quantity"
                          min={0}
                          type="number"
                        />
                      </div>
                    );
                  }}
                />
              </div>
              <div className="col pr-4 col-xs-3">
                <Controller
                  name={`purchaseOrderMaterials.${index}.unitOfMeasure`}
                  control={control}
                  render={() => {
                    // const materialError = (
                    //   errors?.purchaseOrderMaterials as unknown as
                    //     | FieldErrorsImpl<PurchaseOrderMaterials>[]
                    //     | undefined
                    // )?.[index]?.unitOfMeasure;
                    return (
                      // <div
                      //   ref={
                      //     register(
                      //       `purchaseOrderMaterials.${index}.unitOfMeasure`
                      //     ).ref
                      //   }
                      // >
                      //   <CustomInput
                      //     isLineThrough={isRejected}
                      //     disabled={isMaterialDisabled(index)}
                      //     error={materialError?.message}
                      //     {...field}
                      //     placeholder="Kg"
                      //   />
                      // </div>
                      <div
                        key={index}
                        ref={
                          register(
                            `purchaseOrderMaterials.${index}.unitOfMeasure`
                          ).ref
                        }
                      >
                        <input
                          className={`custom-input ${
                            isRejected && "line-through"
                          }`}
                          {...register(
                            `purchaseOrderMaterials.${index}.unitOfMeasure`
                          )}
                          disabled={
                            data?.role == Roles.Admin ||
                            data?.role == Roles.SuperAdmin
                              ? false
                              : isMaterialDisabled(index)
                          }
                          placeholder="FT"
                          onChange={(e) =>
                            setValue(
                              `purchaseOrderMaterials.${index}.unitOfMeasure`,
                              e.target.value
                            )
                          }
                        />
                        {checkForError(index, "unitOfMeasure") && (
                          <span className="block mt-1 text-error break-words">
                            {checkForError(index, "unitOfMeasure")?.message}
                          </span>
                        )}
                      </div>
                    );
                  }}
                />
              </div>
              <div className="col pr-3 col-xs-3">
                <Controller
                  name={`purchaseOrderMaterials.${index}.unitRate`}
                  control={control}
                  render={({ field, fieldState: { error } }) => {
                    return (
                      <Form.Item
                        help={error?.message}
                        validateStatus={error?.message ? "error" : ""}
                      >
                        <InputNumber
                          disabled={
                            data?.role == Roles.Admin ||
                            data?.role == Roles.SuperAdmin
                              ? false
                              : isMaterialDisabled(index)
                          }
                          {...field}
                          onChange={(value) => {
                            field.onChange(String(value || 0));
                            handleCalculateTotal();
                          }}
                          style={{ width: "100%" }}
                          size="large"
                          placeholder="Unit Rate"
                          min={0}
                          prefix="$"
                          className={isRejected ? "text-through" : ""}
                        />
                      </Form.Item>
                    );
                  }}
                />
              </div>
              <div className="col pr-4 col-xs-3">
                <Controller
                  name={`purchaseOrderMaterials.${index}.cost`}
                  control={control}
                  render={({ field }) => {
                    return (
                      <CustomInput
                        isLineThrough={isRejected}
                        disabled
                        {...field}
                        value={`$ ${convertToLocaleString(field.value)}`}
                        placeholder="Amount"
                        min={0}
                      />
                    );
                  }}
                />
              </div>
              <div className="mt-1 flex items-center gap-2">
                <DeleteIconButton
                  disabled={fields.length === 1 || isMaterialDisabled(index)}
                  handleDelete={() => {
                    // Yes I have added two timeouts, they were necessary. :)
                    // - Ustad Inshal on 11:21 PM, October 19th, 2024.
                    toggleLoader(true);

                    setTimeout(() => {
                      removeMaterial(index);
                      updateMaterial();
                      handleCalculateTotal();
                      handleRestProcurementFields();
                    }, 0);

                    setTimeout(() => {
                      setPoMaxIndex(
                        (getValues("purchaseOrderMaterials")?.length || 0) - 1
                      );
                    }, 100);
                  }}
                />
                {getValues("id") && !isFieldsCraftAuthorized() && (
                  <button
                    className={`disabled:!bg-neutral-1 disabled:!border-neutral-5 disabled:!text-neutral-75 disabled:!fill-gray-2 border transition-all duration-200 cursor-pointer p-1.5 rounded-md
                ${
                  isRejected
                    ? "!border-primaryHover !bg-primary25 fill-primary"
                    : "border-primary25 "
                }
                  hover:!border-primaryHover hover:!bg-primary25 hover:fill-primary active:fill-primaryActive`}
                    disabled={isPOMatchingStatusDF(getValues("status"))}
                    type="reset"
                    onClick={() => {
                      handleLikeAction(index, !isRejected);
                      setForceRender(Date.now());
                    }}
                  >
                    <CustomIcon className="w-5" type={"dislike-icon"} />
                  </button>
                )}
                {showDownloadButtonForMaterial() && (
                  <button
                    data-loader="false"
                    className={` fill-white stroke-primaryActive border border-primaryActive transition-all duration-200 cursor-pointer p-1.5 rounded-full hover:!bg-primary25 hover:!fill-primary25 hover:stroke-primary hover:border-primary group relative w-[34px] h-[34px]`}
                    type="reset"
                    onClick={async (event) => {
                      const el = event.currentTarget as HTMLButtonElement;
                      event.stopPropagation();
                      if (el.dataset.loader === "true") return;

                      el.dataset.loader = "true";

                      const blob = (await downloadPdfForSingleMaterial({
                        purchaseOrderId: getValues("id"),
                        materialId: getValues(
                          `purchaseOrderMaterials.${index}.id`
                        ),
                      })) as Blob;
                      const name = `PO-${getValues(
                        "purchaseOrderNumber"
                      )}_${getValues(
                        `purchaseOrderMaterials.${index}.name`
                      )}.pdf`;

                      manuallyDownloadBlob(blob, name);

                      el.dataset.loader = "false";
                    }}
                  >
                    <span className="group-data-[loader=true]:!hidden">
                      <CustomIcon className="w-5" type={"download-icon"} />
                    </span>
                    <span className="!hidden group-data-[loader=true]:!block">
                      <div className="loader small"></div>
                    </span>
                  </button>
                )}
              </div>
            </div>
            {getValues(`purchaseOrderMaterials.${index}.name`).toLowerCase() ===
            isFreight ? null : (
              <div className="materials-second-row my-4 flex">
                <div className="col pr-4 col-xs-1"></div>
                <div className="col pr-4 col-xs-4">
                  <Controller
                    name={
                      `purchaseOrderMaterials.${index}.isMaterialAlreadyApproved` as any
                    }
                    control={control}
                    render={({ field }) => (
                      <CustomRadio
                        // disabled={isPOMatchingStatusDF(getValues("status"))}
                        // disabled={isMaterialDisabled()}
                        title="* Is material already approved?"
                        fieldValue={field.value}
                        fieldOnChange={(value) => {
                          field.onChange(value);
                          handleChangeMaterialApproved(value, index);
                        }}
                        options={[
                          {
                            value: true,
                            label: "Yes",
                          },
                          {
                            value: false,
                            label: "No",
                          },
                        ]}
                      />
                    )}
                  />
                </div>

                {!watch(
                  `purchaseOrderMaterials.${index}.isMaterialAlreadyApproved`
                ) ? (
                  <>
                    <div className="col pr-4 col-xs-4">
                      <Controller
                        name={`purchaseOrderMaterials.${index}.maxSubmittalLeadTime`}
                        control={control}
                        render={({ field }) => {
                          return (
                            <CustomInput
                              isLineThrough={isRejected}
                              disabled={isRejected}
                              {...field}
                              onChange={(value: string | number | boolean) => {
                                if (
                                  typeof value !== "string" &&
                                  typeof value !== "number"
                                )
                                  return;

                                const numericValue = handleNumericInput(value);
                                field.onChange(numericValue);

                                handleSubmittalLeadTimeChange(
                                  numericValue,
                                  index
                                );
                              }}
                              label="Max Submittal Lead Time"
                              min={0}
                              type="number"
                              placeholder="In weeks"
                              endAdornment={<span>Weeks</span>}
                            />
                          );
                        }}
                      />
                    </div>
                    <div className="col pr-4 col-xs-4">
                      <Form.Item
                        label="Expected Submittal Date"
                        tooltip='Entering an Expected Submittal Date will override the "Max Submittal Lead Time" and "Expected Delivery Date" fields'
                      >
                        <Controller
                          name={`purchaseOrderMaterials.${index}.expectedSubmittalDate`}
                          control={control}
                          render={({ field }) => (
                            <DatePicker
                              className={isRejected ? "line-through" : ""}
                              disabled={isRejected}
                              value={
                                dayjs(field.value).isValid()
                                  ? dayjs(field.value)
                                  : null
                              }
                              onChange={(date) => {
                                if (!dayjs(date).isValid()) {
                                  setValue(
                                    `purchaseOrderMaterials.${index}.expectedSubmittalDate`,
                                    null
                                  );
                                  return;
                                }
                                handleExpectedSubmittalDateChange(date, index);
                              }}
                              size="large"
                              style={{ width: "100%" }}
                              placeholder="MM/DD/YYYY"
                              format={dateFormat}
                            />
                          )}
                        />
                      </Form.Item>
                    </div>
                    <div className="col pr-4 col-xs-4">
                      <Form.Item
                        label="Expected Delivery Date"
                        tooltip='Entering an Expected Delivery Date will override the "Max Submittal Lead Time"'
                      >
                        <Controller
                          name={`purchaseOrderMaterials.${index}.expectedDeliveryDate`}
                          control={control}
                          render={({ field }) => (
                            <DatePicker
                              className={isRejected ? "line-through" : ""}
                              disabled={isRejected}
                              value={
                                dayjs(field.value).isValid()
                                  ? dayjs(field.value)
                                  : dayjs(new Date())
                              }
                              onChange={(date) => {
                                if (!dayjs(date).isValid()) {
                                  setValue(
                                    `purchaseOrderMaterials.${index}.expectedSubmittalDate`,
                                    getValues(
                                      `purchaseOrderMaterials.${index}.expectedSubmittalDate`
                                    )
                                  );
                                  setValue(
                                    `purchaseOrderMaterials.${index}.expectedDeliveryDate`,
                                    dayjs(new Date()).format(dateFormat)
                                  );
                                  return;
                                }
                                field.onChange(
                                  dayjs(date).locale("en").format()
                                );
                              }}
                              size="large"
                              style={{ width: "100%" }}
                              placeholder="MM/DD/YYYY"
                              format={dateFormat}
                            />
                          )}
                        />
                      </Form.Item>
                    </div>
                    <div className="col pr-4 col-xs-4">
                      <Controller
                        name={`purchaseOrderMaterials.${index}.maxMaterialLeadTime`}
                        control={control}
                        render={({ field }) => {
                          return (
                            <CustomInput
                              isLineThrough={isRejected}
                              disabled={isRejected}
                              {...field}
                              label="Max Material Lead Time"
                              onChange={(value: string | number | boolean) => {
                                if (
                                  typeof value !== "string" &&
                                  typeof value !== "number"
                                )
                                  return;

                                const numericValue = handleNumericInput(value);
                                field.onChange(numericValue);

                                handleMaxMaterialLeadTimeChange(
                                  numericValue,
                                  index
                                );
                              }}
                              min={0}
                              type="number"
                              placeholder="In weeks"
                              endAdornment={<span>Weeks</span>}
                            />
                          );
                        }}
                      />
                    </div>
                    <div className="col col-xs-3">
                      {/* <Controller
                      name={`purchaseOrderMaterials.${index}.submittalStatus`}
                      control={control}
                      render={({ field }) => (
                        <CustomSelect
                          isLineThrough={isRejected}
                          disabled={isRejected}
                          label="Submittal Status"
                          fieldValue={field.value || 0}
                          fieldOnChange={(value) => field.onChange(value)}
                          options={purchaseOrderSubmittalStatusOptions}
                        />
                      )}
                    /> */}
                      <CustomFormLabel text="Submittal Status" />
                      <Controller
                        name={`purchaseOrderMaterials.${index}.submittalStatus`}
                        control={control}
                        render={({ field }) => (
                          <Select
                            {...field}
                            style={{ width: "100%", marginTop: "10px" }}
                            className={isRejected ? "line-through" : ""}
                            onChange={(value) => {
                              field.onChange(value);
                            }}
                            disabled={isRejected}
                            size="large"
                            placeholder="Submittal Status"
                            showSearch
                            filterOption={(input, option) =>
                              (option?.label || "")
                                .toLowerCase()
                                .includes(input.toLowerCase())
                            }
                            options={purchaseOrderSubmittalStatusOptions}
                          />
                        )}
                      />
                    </div>
                  </>
                ) : null}
              </div>
            )}
          </div>
        </div>
      );
    };

    return (
      <>
        <div className="materials-header-row flex w-full py-1.5 px-2 rounded-lg mb-4 bg-neutral-0 ">
          <div className="col col-xs-1 ">
            {fields[0] && (
              <Controller
                name={`purchaseOrderMaterials.${0}.isUniversalChecked`}
                control={control}
                render={({ field }) => (
                  <CustomInput
                    // disabled={isRejected}

                    {...field}
                    onChange={(value) => {
                      field.onChange(value);
                      handleUniversalCheckBoxesChange(value as boolean);
                    }}
                    checked={field.value}
                    type="checkbox"
                  />
                )}
              />
            )}
          </div>
          <div className="col col-xs-4">
            <span className="font-medium text-xs">Material</span>
          </div>
          <div className="col col-xs-4">
            <span className="font-medium text-xs">Cost Code</span>
          </div>
          {/* <div className="col col-xs-2">
            <span className="font-medium text-xs">Regular</span>
          </div>
          <div className="col col-xs-2">
            <span className="font-medium text-xs">Spares</span>
          </div>
          <div className="col col-xs-2">
            <span className="font-medium text-xs">Samples</span>
          </div> */}
          <div className="col col-xs-4">
            <span className="font-medium text-xs">Quantity</span>
          </div>
          <div className="col col-xs-3 mr-2">
            <span className="font-medium text-xs text-wrap">
              Unit of Measurement
            </span>
          </div>

          <div className="col col-xs-3 ml-1">
            <span className="font-medium text-xs">Unit Rate</span>
          </div>
          <div className="col col-xs-3">
            <span className="font-medium text-xs">Amount</span>
          </div>
        </div>
        <List
          ref={listRef}
          height={listHeight}
          itemCount={fields.length}
          itemSize={getItemSize}
          width={"100%"}
          className="list-scroll-container"
        >
          {renderRow}
        </List>

        {/* DON'T REMOVE THIS FORCERENDER SPAN */}
        <span className="hidden">{forceRender}</span>
      </>
    );
  }
);

export default POMaterialRow;
