import {
  createPurchaseOrderApprovals,
  getPurchaseOrderApprovalsById,
} from "@/src/apis/purchaseOrderApis";
import CustomAlert from "@/src/components/common/CustomAlert";
import CustomFormLabel from "@/src/components/common/CustomFormLabel";
import SectionLayout from "@/src/components/layout/SectionLayout";
import { PO_APPROVAL_CREATE_VALIDATION_SCHEMA } from "@/src/data/validationsSchema";
import { useAppDispatch } from "@/src/hooks/useAppDispatch";
import { useAppSelector } from "@/src/hooks/useAppSelector";
import useAuthorization from "@/src/hooks/useAuthorization";
import {
  getPurchaseOrdersState,
  resetState,
} from "@/src/store/slices/purchaseOrderSlice";
import { AuthorizingEntity, dateFormat } from "@/src/utils/constants";
import { PurchaseOrderStatusEnum } from "@/src/utils/enums";
import { isPOMatchingStatusVendorApprove } from "@/src/utils/helper";
import routePaths from "@/src/utils/routePaths";
import { PurchaseOrder, PurchaseOrderApprovalDetail } from "@/src/utils/types";
import { yupResolver } from "@hookform/resolvers/yup";
import { Button, DatePicker, Flex, Form, Input, Tooltip } from "antd";
import dayjs from "dayjs";
import { useEffect } from "react";
import { Controller, Resolver, useForm } from "react-hook-form";
import { useLocation, useNavigate, useParams } from "react-router-dom";

type PurchaseOrderRecipientTabTypeProps = {
  // isAdminAuthorized: () => boolean;
  purchaseOrderData?: PurchaseOrder | null;
  statusValue?: number;
  setStatus: (status: number) => void;
};

const PurchaseOrderApprovalTab = ({
  statusValue,
  purchaseOrderData,
  setStatus,
}: PurchaseOrderRecipientTabTypeProps) => {
  const location = useLocation();
  const purchaseOrderId = useParams();
  const navigate = useNavigate();
  const { successMessage, resError, reqError } = useAppSelector(
    getPurchaseOrdersState
  );
  const { isFieldsCraftAuthorized } = useAuthorization();
  useEffect(() => {
    setStatus(purchaseOrderData?.status ? purchaseOrderData?.status : 0);
  }, []);

  const {
    handleSubmit,
    control,
    setValue,
    formState: { isSubmitting },
  } = useForm({
    defaultValues: {
      contractorApproval: {
        signature: "",
        company: "",
        title: "",
        dateSigned: new Date() || null,
        status: AuthorizingEntity.Contractor,
        purchaseOrderId: purchaseOrderId.purchaseOrderId || "",
        authorizingEntity: 0,
      },
      vendorApproval: {
        signature: "",
        company: "",
        title: "",
        dateSigned: null,
        createdBy: "",
        createdDate: "",
        status: AuthorizingEntity.Vendor,
        purchaseOrderId: "",
        authorizingEntity: 1,
        approvalComments: "",
      },
    },
    resolver: yupResolver(
      PO_APPROVAL_CREATE_VALIDATION_SCHEMA
    ) as unknown as Resolver<any>,
  });

  const dispatch = useAppDispatch();

  useEffect(() => {
    const fetchApproval = async () => {
      const res = await dispatch(
        getPurchaseOrderApprovalsById(purchaseOrderId || "")
      ).unwrap();

      setValue("vendorApproval", res?.vendorApproval);
      setValue("contractorApproval", res?.contractorApproval);
      setValue;
    };

    fetchApproval();
  }, []);

  const onSubmit = async (values: PurchaseOrderApprovalDetail) => {
    const payload = {
      signature: values.contractorApproval.signature,
      company: values.contractorApproval.company,
      title: values.contractorApproval.title,
      dateSigned: values.contractorApproval.dateSigned,
      authorizingEntity: AuthorizingEntity.Contractor,
      purchaseOrderId: purchaseOrderId.purchaseOrderId || "",
      status: AuthorizingEntity.Contractor,
    };

    try {
      const res = await dispatch(
        createPurchaseOrderApprovals(payload)
      ).unwrap();

      if (res?.isSuccess) {
        // navigate(routePaths.PURCHASE_ORDERS);
        handleClose();
      }
    } catch (err) {
      console.error("err", err);
    }
  };

  useEffect(() => {
    dispatch(resetState());
  }, []);

  const handleClose = () => {
    const previousPath = location?.state?.previousPath || "";
    if (previousPath) {
      navigate(previousPath);
    } else {
      navigate(routePaths.PURCHASE_ORDERS);
    }
  };

  return (
    <SectionLayout>
      <Form
        onFinish={handleSubmit(onSubmit)}
        labelCol={{ span: 5 }}
        layout="horizontal"
        autoComplete="off"
      >
        <div className="flex">
          <Flex justify="flex-start" vertical className="w-full m-10">
            <Form.Item
              colon={false}
              label={<CustomFormLabel text="Signature" />}
            >
              <Controller
                name="vendorApproval.signature"
                control={control}
                render={({ field }) => (
                  <Tooltip
                    title={field.value}
                    placement="bottomLeft"
                    arrow={false}
                  >
                    <Input
                      disabled={true}
                      {...field}
                      size="large"
                      placeholder="Signature here..."
                    />
                  </Tooltip>
                )}
              />
            </Form.Item>
            <Form.Item colon={false} label={<CustomFormLabel text="Company" />}>
              <Controller
                name="vendorApproval.company"
                control={control}
                render={({ field }) => (
                  <Tooltip
                    title={field.value}
                    placement="bottomLeft"
                    arrow={false}
                  >
                    <Input
                      {...field}
                      size="large"
                      placeholder="Company Name"
                      disabled
                    />
                  </Tooltip>
                )}
              />
            </Form.Item>
            <Form.Item colon={false} label="Title">
              <Controller
                name="vendorApproval.title"
                control={control}
                render={({ field }) => (
                  <Tooltip
                    title={field.value}
                    placement="bottomLeft"
                    arrow={false}
                  >
                    <Input
                      {...field}
                      size="large"
                      placeholder="Title"
                      disabled
                    />
                  </Tooltip>
                )}
              />
            </Form.Item>
            <Form.Item colon={false} label={<CustomFormLabel text="Date" />}>
              <Controller
                name="vendorApproval.dateSigned"
                control={control}
                render={({ field }) => (
                  <DatePicker
                    disabled
                    {...field}
                    value={
                      dayjs(field.value).isValid()
                        ? dayjs(field.value)
                        : dayjs(new Date())
                    }
                    onChange={(date) => {
                      field.onChange(dayjs(date).locale("en").format());
                    }}
                    size="large"
                    style={{ width: "100%" }}
                    placeholder="MM/DD/YYYY"
                    format={dateFormat}
                  />
                )}
              />
            </Form.Item>
            <Form.Item
              style={{ alignSelf: "center" }}
              labelAlign="right"
              required
            >
              <Button
                disabled
                className="bg-neutral-10 px-10 py-4 font-semibold"
              >
                Vendor
              </Button>
            </Form.Item>
            <Form.Item
              colon={false}
              label={<CustomFormLabel text="Vendor Comments" />}
            >
              <Controller
                name="vendorApproval.approvalComments"
                disabled
                control={control}
                render={({ field, fieldState: { error } }) => (
                  <>
                    <Form.Item
                      colon={false}
                      help={error?.message}
                      validateStatus={error ? "error" : ""}
                    >
                      <Input.TextArea
                        {...field}
                        onChange={(value) => {
                          field.onChange(value);
                        }}
                        // placeholder=""
                        value={field.value}
                        rows={10}
                      />
                    </Form.Item>
                  </>
                )}
              />
            </Form.Item>
          </Flex>
          <Flex justify="flex-start" vertical className="w-full m-10">
            <Controller
              name="contractorApproval.signature"
              control={control}
              render={({ field, fieldState: { error } }) => {
                return (
                  <Form.Item
                    colon={false}
                    label={<CustomFormLabel text="Signature" />}
                    help={error ? error.message : null}
                    validateStatus={error ? "error" : ""}
                  >
                    <Tooltip
                      title={field.value}
                      placement="bottomLeft"
                      arrow={false}
                    >
                      <Input
                        autoFocus
                        {...field}
                        value={field.value || ""}
                        onChange={(e) => field.onChange(e.target.value)}
                        disabled={
                          isPOMatchingStatusVendorApprove(statusValue) ||
                          isFieldsCraftAuthorized()
                        }
                        size="large"
                        placeholder="Signature here..."
                      />
                    </Tooltip>
                  </Form.Item>
                );
              }}
            />
            <Controller
              name="contractorApproval.company"
              control={control}
              render={({ field, fieldState: { error } }) => (
                <Form.Item
                  colon={false}
                  label={<CustomFormLabel text="Company" />}
                  help={error ? error.message : null}
                  validateStatus={error ? "error" : ""}
                >
                  <Tooltip
                    title={field.value}
                    placement="bottomLeft"
                    arrow={false}
                  >
                    <Input
                      autoFocus
                      {...field}
                      value={field.value || ""}
                      onChange={(e) => field.onChange(e.target.value)}
                      disabled={
                        isPOMatchingStatusVendorApprove(statusValue) ||
                        isFieldsCraftAuthorized()
                      }
                      size="large"
                      placeholder="Company Name"
                    />
                  </Tooltip>
                </Form.Item>
              )}
            />
            <Controller
              name="contractorApproval.title"
              control={control}
              render={({ field, fieldState: { error } }) => (
                <Form.Item
                  colon={false}
                  label="Title"
                  help={error ? error.message : null}
                  validateStatus={error ? "error" : ""}
                >
                  <Tooltip
                    title={field.value}
                    placement="bottomLeft"
                    arrow={false}
                  >
                    <Input
                      autoFocus
                      {...field}
                      value={field.value || ""}
                      onChange={(e) => field.onChange(e.target.value)}
                      disabled={
                        isPOMatchingStatusVendorApprove(statusValue) ||
                        isFieldsCraftAuthorized()
                      }
                      size="large"
                      placeholder="Title"
                    />
                  </Tooltip>
                </Form.Item>
              )}
            />

            <Form.Item colon={false} label={<CustomFormLabel text="Date" />}>
              <Controller
                name="contractorApproval.dateSigned"
                control={control}
                render={({ field }) => (
                  <DatePicker
                    disabled
                    {...field}
                    value={
                      dayjs(field.value).isValid()
                        ? dayjs(field.value)
                        : dayjs(new Date())
                    }
                    onChange={(date) => {
                      field.onChange(dayjs(date).locale("en").format());
                    }}
                    size="large"
                    style={{ width: "100%" }}
                    placeholder="MM/DD/YYYY"
                    format={dateFormat}
                  />
                )}
              />
            </Form.Item>
            <Form.Item
              style={{ alignSelf: "center" }}
              labelAlign="right"
              required
            >
              <Button
                className="bg-neutral-10 px-10 py-4 font-semibold"
                disabled={
                  isPOMatchingStatusVendorApprove(statusValue) ||
                  isFieldsCraftAuthorized()
                }
              >
                Contractor
              </Button>
            </Form.Item>
          </Flex>
        </div>

        {(resError || reqError || successMessage) && (
          <CustomAlert
            message={resError || resError || successMessage || ""}
            type={successMessage ? "success" : "error"}
          />
        )}

        <Flex justify="flex-end" className="gap-4 mt-7">
          <Button
            // loading={isSubmitting}
            disabled={isSubmitting}
            onClick={handleClose}
          >
            Cancel
          </Button>
          {!isFieldsCraftAuthorized() && (
            <Button
              loading={isSubmitting}
              disabled={
                isSubmitting ||
                statusValue !== PurchaseOrderStatusEnum.VendorApproved
              }
              type="primary"
              htmlType="submit"
              // onClick={() =>
              //   setActionType({
              //     save: ActionTypeEnum.SAVE,
              //   })
              // }
            >
              {isSubmitting ? "Saving.." : "Save"}
            </Button>
          )}
        </Flex>
        {/* Add CustomFormButtons and other components as needed */}
      </Form>
    </SectionLayout>
  );
};

export default PurchaseOrderApprovalTab;
