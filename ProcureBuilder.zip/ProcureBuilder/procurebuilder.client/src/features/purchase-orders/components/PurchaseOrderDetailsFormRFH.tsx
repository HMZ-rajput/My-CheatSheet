import { getLocationslist } from "@/src/apis/locationApis";
import {
  createPurchaseOrder,
  deletePurchaseOrderById,
  downloadPdfForPO,
  updatePurchaseOrderById,
} from "@/src/apis/purchaseOrderApis";
import { getAllStorageTypes } from "@/src/apis/storageTypeApis";
import { getAllUsersSummaryList } from "@/src/apis/userApis";
import { getVendorslist } from "@/src/apis/vendorApis";
import CreatedByUserBadge from "@/src/components/common/CreatedByUserBadge";
import CustomAlert from "@/src/components/common/CustomAlert";
import CustomFileUploadRHF from "@/src/components/common/CustomFileUploadRHF";
import CustomFormLabel from "@/src/components/common/CustomFormLabel";
import CustomIcon from "@/src/components/common/CustomIcon";
import CustomInfoTooltip from "@/src/components/common/CustomInfoTooltip";
import CustomOverlayLoader from "@/src/components/common/CustomOverlayloader";
import CustomFormRow from "@/src/components/form/CustomFormRow";
import SectionLayout from "@/src/components/layout/SectionLayout";
import {
  materialUpdateInitialMaterials,
  purchaseOrderInitialMaterials,
} from "@/src/data/intialsValues";
import { PurchaseOrderValidationSchema } from "@/src/data/validationsSchema";
import { getLowerCasedMaterialName } from "@/src/external-modules/bulk-upload/bulk-upload-utils";
import BulkUploadButton from "@/src/external-modules/bulk-upload/BulkUploadButton";
import BulkUploaderParser from "@/src/external-modules/bulk-upload/BulkUploadParser";
import LocationModal from "@/src/features/locations/components/LocationModal";
import { useAppDispatch } from "@/src/hooks/useAppDispatch";
import { useAppSelector } from "@/src/hooks/useAppSelector";
import useAuthorization from "@/src/hooks/useAuthorization";
import { getLocationsState } from "@/src/store/slices/locationSlice";
import { getProjectsState } from "@/src/store/slices/projectsSlice";
import {
  getPurchaseOrdersState,
  resetState,
} from "@/src/store/slices/purchaseOrderSlice";
import { getUsersListState } from "@/src/store/slices/userSlice";
import { getVendorsState } from "@/src/store/slices/vendorSlice";
import { manuallyDownloadBlob } from "@/src/utils/api-helpers";
import {
  dateFormat,
  isFreight,
  numberRegex,
  paymentTermOptions,
  purchaseOrderStatusOptionsWithAll,
  purchaseOrderSubmittalStatusOptions,
} from "@/src/utils/constants";
import {
  ActionTypeEnum,
  FilesDocumentTypeEnum,
  MaterialReviewPeriod,
  PurchaseOrderStatusEnum,
  UserRoleEnum,
} from "@/src/utils/enums";
import {
  filterFileDocumentsByType,
  isPOMatchingStatusDF,
  isPOVendorDisabled,
  textSearchFormat,
} from "@/src/utils/helper";
import { formatDecimals } from "@/src/utils/number-extensions";
import routePaths from "@/src/utils/routePaths";
import {
  ActionTypeState,
  LabelSupportedPOMaterial,
  PurchaseOrder,
  PurchaseOrderMaterials,
  Reorder,
  ReorderMaterial,
} from "@/src/utils/types";
import { PlusOutlined } from "@ant-design/icons";
import { yupResolver } from "@hookform/resolvers/yup";
import {
  Button,
  Col,
  DatePicker,
  Divider,
  Flex,
  Form,
  Input,
  InputNumber,
  Radio,
  Select,
  Space,
  Typography,
} from "antd";
import dayjs, { Dayjs, ManipulateType } from "dayjs";
import React, { useEffect, useMemo, useState } from "react";
import { Controller, Resolver, useFieldArray, useForm } from "react-hook-form";
import PhoneInput from "react-phone-input-2";
import { useLocation, useNavigate, useParams } from "react-router-dom";
import PurchaseOrderMaterialsRHF from "./PurchaseOrderMaterialsRHF";
import { QrcodeOutlined } from "@ant-design/icons";

type FieldType = {
  purchaseOrderData?: PurchaseOrder | null;
};

type PurchaseOrderDetailsFormTypeProps = {
  purchaseOrderData?: PurchaseOrder | null;
  reorder: Reorder | null;
  setStatus: (status: number) => void;
};

const PurchaseOrderDetailsFormRFH = ({
  purchaseOrderData,
  reorder,
  setStatus,
}: PurchaseOrderDetailsFormTypeProps) => {
  const location = useLocation();
  const { isCominedAdminAuthorized, isFieldsCraftAuthorized } =
    useAuthorization();
  // Stateless & Pure JavaScript Loader for Ultimate Performance
  // (I tried using state, but it was so slow that it did nothing) - Ustad Inshal on 11:03 PM, October 19th, 2024.

  type AssumedSubmittal = {
    assumedSubmittalReview: number;
    assumedSubmittalReviewPeriod: number;
  };

  const { isAdminAuthorized } = useAuthorization();
  const [assumedSubmittal, setAssumedSubmittal] = useState<AssumedSubmittal>({
    assumedSubmittalReview: 0,
    assumedSubmittalReviewPeriod: 0,
  });
  const [isLocationModalOpen, setIsLocationModalOpen] = useState<{
    open: boolean;
    title?: string | null;
    field?: string;
  }>({ open: false, title: null, field: "" });

  function getPoMaxIndex() {
    return parseInt(document.body.dataset?.purchaseOrderMaxIndex || "0");
  }
  function setPoMaxIndex(index: number) {
    document.body.setAttribute("data-purchase-order-max-index", `${index}`);
  }
  function toggleLoader(shouldShow: boolean) {
    const el = document.getElementById("custom-relative-loader") || null;
    if (el) {
      el.style.display = shouldShow ? "block" : "none";
    }
  }
  useEffect(() => {
    const interval = setInterval(() => {
      const maxIndex = getPoMaxIndex();

      const rowEl =
        document.querySelector(`[data-material-loader-index="${maxIndex}"]`) ||
        null;

      if (!rowEl) return;

      setPoMaxIndex(-1);
      toggleLoader(false);
    }, 500);

    return () => {
      clearInterval(interval);
    };
  }, []);

  const dispatch = useAppDispatch();

  const { purchaseOrderId } = useParams();

  const [isDeleting, setIsDeleting] = useState(false);
  const [isRevision, setIsRevision] = useState(false);
  const [isLoadROMaterial, setIsLoadROMaterial] = useState(false);

  const [actionType, setActionType] = useState<ActionTypeState>({
    delete: ActionTypeEnum.NEUTRAL, // Default to SAVE state (0)
    downloadPdf: ActionTypeEnum.NEUTRAL,
    createMRI: ActionTypeEnum.NEUTRAL,
    createInvoice: ActionTypeEnum.NEUTRAL,
    createRevision: ActionTypeEnum.NEUTRAL,
    rejectAll: ActionTypeEnum.NEUTRAL,
    approve: ActionTypeEnum.NEUTRAL,
    approveAll: ActionTypeEnum.NEUTRAL,
    saveAndRelease: ActionTypeEnum.NEUTRAL,
    save: ActionTypeEnum.NEUTRAL,
    saveAndNew: ActionTypeEnum.NEUTRAL,
    cancel: ActionTypeEnum.NEUTRAL,
  });

  const [purchaseOrder, setPurchaseOrder] = useState<PurchaseOrder | null>(
    purchaseOrderData as PurchaseOrder
  );

  const [isAnyMaterialRejected, setIsAnyMaterialRejected] = useState(false);
  const checkIfAnyMaterialIsRejected = (
    materials: PurchaseOrderMaterials[]
  ) => {
    const hasDislikedMaterials = materials?.some((s) => s.isMaterialRejected);
    setIsAnyMaterialRejected(hasDislikedMaterials);
  };
  useEffect(() => {
    checkIfAnyMaterialIsRejected(purchaseOrder?.purchaseOrderMaterials || []);
  }, [purchaseOrder]);

  useEffect(() => {
    if (actionType?.saveAndNew) {
      return;
    }
    setPurchaseOrder(purchaseOrderData as PurchaseOrder | null);
  }, [purchaseOrderId]);

  const { projectsSummarizedData } = useAppSelector(getProjectsState);
  const { locationsList } = useAppSelector(getLocationsState);
  const { successMessage, resError, reqError } = useAppSelector(
    getPurchaseOrdersState
  );

  const usersList = useAppSelector(getUsersListState);

  useEffect(() => {
    dispatch(
      getAllUsersSummaryList({
        roles: [
          UserRoleEnum.Engineer,
          UserRoleEnum.Fieldcraft,
          UserRoleEnum.Superintendent,
          UserRoleEnum.Admin,
        ],
      })
    );
  }, []);

  const getInitialValues = (purchaseOrder?: PurchaseOrder) => ({
    id: purchaseOrder?.id || "",
    createdBy: purchaseOrder?.createdBy || "",
    createdDate: purchaseOrder?.createdDate || "",
    purchaseOrderNumber: purchaseOrder?.purchaseOrderNumber || "",
    title: purchaseOrder?.title || "",
    deliveryLocationId: purchaseOrder?.purchaseOrderDeliveryLocation?.id || "",
    contactNumber: purchaseOrder?.contactNumber || "",
    purchaseOrderProjectId: purchaseOrder?.purchaseOrderProject?.id || "",
    revisionNumber: purchaseOrder?.revisionNumber || "",
    dueDate: dayjs(purchaseOrder?.dueDate || new Date()) || null,
    assignedUserId: purchaseOrder?.assignedUser?.id || "",
    status: purchaseOrder?.status || 0,
    notes: purchaseOrder?.notes || "",
    vendorId: purchaseOrder?.vendor?.id || "",
    vendorAddress: purchaseOrder?.vendorAddress || "",
    toRelease: false,
    isContractorResponsibleForTax:
      purchaseOrder?.isContractorResponsibleForTax ?? true,
    taxPercentage: purchaseOrder?.taxPercentage || 0,
    recentQuoteDocument: filterFileDocumentsByType(
      purchaseOrder?.purchaseOrderDocuments || [],
      FilesDocumentTypeEnum.RECENTQUOTE
    ),
    attachments: filterFileDocumentsByType(
      purchaseOrder?.purchaseOrderDocuments || [],
      FilesDocumentTypeEnum.PURCHASEORDERATTACHMENTS
    ),
    deliveryContacts: purchaseOrder?.deliveryContacts?.length
      ? purchaseOrder.deliveryContacts.map((v) => ({
          id: v.id || "",
          phoneNumber: v.phoneNumber || "",
        }))
      : [{ id: "", phoneNumber: "" }],
    deleteDocumentIds: [],
    paymentTerm: purchaseOrder?.paymentTerm || 0,
    deliveryNotes: purchaseOrder?.deliveryNotes || "",
    subTotal: formatDecimals(purchaseOrder?.subTotal || 0),
    tax: formatDecimals(purchaseOrder?.tax || 0),
    total: formatDecimals(purchaseOrder?.total || 0),
    purchaseOrderMaterials: purchaseOrder?.purchaseOrderMaterials
      ? purchaseOrder?.purchaseOrderMaterials
      : purchaseOrderId
      ? materialUpdateInitialMaterials
      : purchaseOrderInitialMaterials,
    purchaseOrderMaterials2: purchaseOrder?.purchaseOrderMaterials,
    lastModifiedBy: purchaseOrder?.lastModifiedBy || "",
    lastModifiedDate: purchaseOrder?.lastModifiedDate || null,
    modifiedDate: purchaseOrder?.modifiedDate || null,
    modifiedBy: purchaseOrder?.modifiedBy || "",
  });

  const navigate = useNavigate();

  const {
    reset,
    control,
    handleSubmit,
    getValues,
    setValue,
    watch,
    register,
    formState: { isSubmitting, errors },
  } = useForm<PurchaseOrder>({
    defaultValues: getInitialValues(purchaseOrder as PurchaseOrder),
    resolver: yupResolver(
      PurchaseOrderValidationSchema
    ) as unknown as Resolver<PurchaseOrder>,
  });

  const handleSavePurchaseOrder = async (values: PurchaseOrder) => {
    const formData = new FormData();

    const payload = {
      ...values,
      assignedUserId: values?.assignedUserId ? values.assignedUserId : null,
      projectId: values?.purchaseOrderProjectId
        ? values?.purchaseOrderProjectId
        : null,
      deliveryContactsIds: values?.deliveryContacts?.map((v) => v.id),
    };

    if (Array.isArray(payload?.deliveryContactsIds)) {
      payload?.deliveryContactsIds?.forEach((v) => {
        formData.append(`deliveryContactsIds`, v || "");
      });
    }

    for (const [key, value] of Object.entries(payload)) {
      if (
        typeof value === "string" ||
        typeof value === "number" ||
        typeof value === "boolean"
      ) {
        formData.append(key, value as string);
      }
    }

    values?.purchaseOrderMaterials?.forEach((material, index) => {
      Object.entries(material).forEach(([key, value]) => {
        if (value !== null && value !== "" && value !== undefined) {
          if (["spares", "samples", "regular"].includes(key)) return;

          formData.append(
            `purchaseOrderMaterials[${index}][${key}]`,
            String(value)
          );
        }
      });
    });
    formData.append("dueDate", values.dueDate as string);
    if (
      values.recentQuoteDocument &&
      Array.isArray(values.recentQuoteDocument)
    ) {
      values.recentQuoteDocument.forEach((file) => {
        formData.append(`recentQuoteDocument`, file?.originFileObj);
      });
    }

    if (values.attachments && Array.isArray(values.attachments)) {
      values?.attachments?.forEach((file) => {
        formData.append(`attachments`, file?.originFileObj);
      });
    }

    if (Array.isArray(values.deleteDocumentIds)) {
      const filteredDeleteDocumentIds = values?.deleteDocumentIds?.filter(
        (id: string) => !id?.startsWith("rc-upload-")
      );
      filteredDeleteDocumentIds?.forEach((id: string) => {
        formData.append("deleteDocumentIds", id);
      });
    }

    if (getValues("id")) {
      return await dispatch(
        updatePurchaseOrderById({
          id: getValues("id") as string,
          formData,
        })
      ).unwrap();
    } else {
      return await dispatch(createPurchaseOrder(formData)).unwrap();
    }
  };

  useEffect(() => {
    dispatch(resetState());
    setStatus(getValues("status"));
  }, []);

  const onSubmit = async (values: PurchaseOrder) => {
    try {
      if (actionType.save === ActionTypeEnum.SAVE) {
        const res = await handleSavePurchaseOrder(values);
        if (res?.isSuccess) {
          reset(getInitialValues(res.purchaseOrder));
          navigate(
            `${routePaths.PURCHASE_ORDERS_EDIT_BY_ID}/${res.purchaseOrder.id}`
          );
        }
      } else if (
        actionType.saveAndRelease === ActionTypeEnum.SAVE_AND_RELEASE
      ) {
        const res = await handleSavePurchaseOrder({
          ...values,
          toRelease: true,
        });
        if (res?.isSuccess) {
          handleClose();
          // navigate(routePaths.PURCHASE_ORDERS);
        }
      } else if (actionType.createInvoice === ActionTypeEnum.CREATE_INVOICE) {
        navigate(routePaths.INVOICES_NEW, { state: purchaseOrderData });
        // const res = await handleSavePurchaseOrder(values);
        // if (!res?.isSuccess) {
        // }
      } else if (actionType.createMRI === ActionTypeEnum.CREATE_MRI) {
        navigate(routePaths.MATERIAL_RECEIPT_INSPECTION_NEW, {
          state: purchaseOrderData,
        });
      } else if (actionType.createRO === ActionTypeEnum.CREATE_RO) {
        navigate(routePaths.REORDERS_NEW, {
          state: purchaseOrderData,
        });
      } else if (actionType.saveAndNew === ActionTypeEnum.SAVE_AND_NEW) {
        const res = await handleSavePurchaseOrder(values);
        if (res?.isSuccess) {
          reset(getInitialValues());
          navigate(routePaths.PURCHASE_ORDERS_NEW);
          setTimeout(() => {
            dispatch(resetState());
          }, 3000);
          setPurchaseOrder({} as PurchaseOrder);
        }
      } else if (actionType.rejectAll === ActionTypeEnum.REJECT_ALL) {
        const res = await handleSavePurchaseOrder({
          ...values,
          status: PurchaseOrderStatusEnum.AdminRejectedAll,
        });
        if (res.isSuccess) {
          reset(getInitialValues(res.purchaseOrder));
        }
      } else if (actionType.approveAll === ActionTypeEnum.APPROVE_ALL) {
        const res = await handleSavePurchaseOrder({
          ...values,
          status: PurchaseOrderStatusEnum.AdminApprovedAll,
        });
        console.log("res", res);
        if (res.isSuccess) {
          reset(getInitialValues(res.purchaseOrder));
        }
      } else if (actionType.approve === ActionTypeEnum.APPROVE) {
        const res = await handleSavePurchaseOrder({
          ...values,
          status: PurchaseOrderStatusEnum.AdminApprovedPartial,
        });
        if (res.isSuccess) {
          reset(getInitialValues(res.purchaseOrder));
        }
      }
    } catch (error) {
      console.error("Error during form submission:", error);
    }
  };

  const fetchLocationsByProjectId = async (
    value: string,
    isUpdateTaxPercentage?: boolean
  ) => {
    const payload = {
      projectId: value,
    };
    setValue("deliveryLocationId", "");
    setValue("taxPercentage", 0);
    try {
      const res = await dispatch(
        getLocationslist(payload.projectId || "")
      ).unwrap();
      setAssumedSubmittal({
        assumedSubmittalReview: res?.assumedSubmittalReview || 0,
        assumedSubmittalReviewPeriod: res?.assumedSubmittalReviewPeriod || 0,
      });

      const handleIncrementDate = (
        date: string | Dayjs | Date | null,
        reviewPeriod: number,
        period: ManipulateType
      ) => {
        return dayjs(date)
          .add(reviewPeriod, period)
          .locale("en")
          .format(dateFormat);
      };

      const period =
        MaterialReviewPeriod[
          res?.assumedSubmittalReviewPeriod ?? 0
        ]?.toLowerCase() || "day";

      const materials = getValues("purchaseOrderMaterials");
      const filtersMaterials = getValues("purchaseOrderMaterials2");

      const updatedMaterials = materials?.map((item) => {
        const matchedItem = filtersMaterials?.find(
          (fItem) => fItem?.id === item?.id
        );

        if (!matchedItem) {
          return {
            ...item,
            expectedDeliveryDate: handleIncrementDate(
              item?.expectedDeliveryDate,
              res?.assumedSubmittalReview || 0,
              period as ManipulateType
            ),
          };
        }
        return item;
      });
      setValue("purchaseOrderMaterials", updatedMaterials);

      checkIfAnyMaterialIsRejected(updatedMaterials);

      if (isUpdateTaxPercentage) {
        setValue("taxPercentage", res?.taxPercentage || 0);
      }
    } catch (err) {
      console.error("Error fetching locations by project id:", err);
    } finally {
      handleCalculateTotal();
    }
  };

  const getFilteredUserOptions = (index: number) => {
    const selectedContactIds =
      watch("deliveryContacts")?.map((contact) => contact.id) || [];
    return [
      {
        value: "",
        label: "Select User",
      },
      ...(usersList
        ?.map((user) => ({
          value: user.id,
          label: `${user.firstName} ${user.lastName}`,
        }))
        .filter(
          (user) =>
            !selectedContactIds.includes(user.value) ||
            user.value === selectedContactIds[index]
        ) || []),
    ];
  };

  const memoizedUserRoleOptions = useMemo(() => {
    return [
      {
        value: "",
        label: "Select User",
      },
      ...(usersList
        ?.filter((user) => {
          if (user.role === "Admin") {
            return user;
          } else if (user.role === "Superintendent") {
            return user;
          } else if (user.role === "Engineer") {
            return user;
          } else {
            return;
          }
        })
        .map((f) => ({
          value: f.id,
          label: f.firstName + " " + f.lastName,
        })) || []),
    ];
  }, [usersList]);

  const memoizedProjectsOptions = useMemo(() => {
    return [
      {
        value: "",
        label: "Select Project",
      },
      ...(projectsSummarizedData?.map((f) => ({
        value: f.id,
        label: f.name,
      })) || []),
    ];
  }, [projectsSummarizedData]);

  const memoizedLocationOptions = useMemo(() => {
    return [
      {
        value: "",
        label: "Select Location",
      },
      ...(locationsList?.map((f) => ({
        value: f.id,
        label: f.name,
      })) || []),
    ];
  }, [locationsList]);

  const handleChangedDeliveryContact = (
    deliveryContactId: string,
    index: number
  ) => {
    const selectedUser = usersList?.find(
      (user) => user.id === deliveryContactId
    );

    setValue(
      `deliveryContacts.${index}.phoneNumber`,
      selectedUser?.phoneNumber || ""
    );
  };

  const handleChangeValue = () => {
    const materials = getValues("purchaseOrderMaterials");

    let totalCost = 0;

    materials?.forEach((material: PurchaseOrderMaterials, index: number) => {
      // const total =
      //   Number(material.spares || 0) +
      //   Number(material.samples || 0) +
      //   Number(material.regular || 0);

      // setValue(`purchaseOrderMaterials.${index}.newQuantity`, total);
      // setValue(`purchaseOrderMaterials.${index}.quantity`, total);

      const quantity = Number(material.quantity || 0);
      const unitRate = Number(material.unitRate || 0);
      const amount = quantity * unitRate;

      setValue(`purchaseOrderMaterials.${index}.cost`, formatDecimals(amount));

      const tax =
        (Number(getValues("subTotal")) * Number(getValues("taxPercentage"))) /
        100;

      setValue("tax", formatDecimals(tax));
      if (!material.isMaterialRejected) {
        totalCost += amount;
      }
    });

    setValue("subTotal", formatDecimals(totalCost));
  };

  const handleCalculateTax = (value: number | null) => {
    setValue("taxPercentage", Number(value || 0));
    handleCalculateTotal();
    const subTotal = getValues("subTotal") || 0;

    const tax = (Number(subTotal) * Number(value)) / 100;

    setValue("tax", formatDecimals(tax));
  };

  const handleCalculateTotal = () => {
    handleChangeValue();

    const subTotal = getValues("subTotal") || 0;
    const freightAmountTotal = getValues(`purchaseOrderMaterials`)
      ?.filter((m) => !m.isMaterialRejected)
      ?.reduce((acc, material) => {
        if (textSearchFormat(material.name) === isFreight) {
          return acc + Number(material.cost);
        }
        return acc;
      }, 0);
    const subTotalWithoutFreight = subTotal - freightAmountTotal;

    const tax =
      (Number(subTotalWithoutFreight) * Number(getValues("taxPercentage"))) /
      100;

    setValue("tax", formatDecimals(tax));
    const total = subTotal + tax;

    setValue("total", formatDecimals(total));
  };

  const {
    fields: deliveryContactsFields,
    append: appendContact,
    remove: removeContact,
  } = useFieldArray({
    control,
    name: "deliveryContacts",
  });

  const [resetBulkUploadFile, setBulkUploadFile] = useState(0);

  async function updateMaterials(file: File) {
    setPoMaxIndex(-1);
    toggleLoader(true);
    const bulkUploadParser = new BulkUploaderParser<
      LabelSupportedPOMaterial[]
    >();
    const rows = await bulkUploadParser.readAndParseAsync(file);

    const isValid = await bulkUploadParser.validateMaterials<
      LabelSupportedPOMaterial[]
    >({
      rows,
      schema: {
        material: "alphanumericString", // Mapped to name
        costCode: "alphanumericString",
        regular: "number",
        spares: "number",
        samples: "number",
        quantity: "number",
        unitOfMeasurement: "alphanumericString", // Mapped to unitOfMeasure
        unitRate: "number",
        amount: "number",
        isMaterialAlreadyApproved: "string", // Type casted from Yes/No to True/False and mapped to isMaterialAlreadyApproved
        maxSubmittalLeadTime: "alphanumericString", // Type casted from string to number
        expectedSubmittalDate: "alphanumericString", // Type casted from MM/DD/YYYY to dayjs()
        expectedDeliveryDate: "alphanumericString", // Type casted from MM/DD/YYYY to dayjs()
        maxMaterialLeadTime: "alphanumericString", // Type casted from string to number
        submittalStatus: "string", // Type casted from Status Name to Status Enum Number Value
      },
      requiredKeys: ["material", "costCode", "unitOfMeasurement", "unitRate"],
    });

    setBulkUploadFile(Date.now());

    if (!isValid) {
      toggleLoader(false);
      return;
    }

    rows.forEach((e) => {
      e.name = e.material;
      e.unitOfMeasure = e.unitOfMeasurement;

      const isMaterialApprovedString =
        `${e.isMaterialAlreadyApproved}`?.toLowerCase();

      let isMaterialApprovedBoolean = false;

      if (
        isMaterialApprovedString === "yes" ||
        isMaterialApprovedString === "true"
      ) {
        isMaterialApprovedBoolean = true;
      } else if (
        isMaterialApprovedString === "no" ||
        isMaterialApprovedString === "false"
      ) {
        isMaterialApprovedBoolean = false;
      }

      e.isMaterialAlreadyApproved = isMaterialApprovedBoolean;
      e.expectedSubmittalDate = dayjs(e.expectedSubmittalDate || new Date(), {
        format: dateFormat,
      });
      e.expectedDeliveryDate = dayjs(e.expectedDeliveryDate || new Date(), {
        format: dateFormat,
      });

      e.maxSubmittalLeadTime = (
        numberRegex.test(`${e.maxSubmittalLeadTime}`)
          ? parseFloat(`${e.maxSubmittalLeadTime}`)
          : 0
      ) as number;
      e.maxMaterialLeadTime = (
        numberRegex.test(`${e.maxMaterialLeadTime}`)
          ? parseFloat(`${e.maxMaterialLeadTime}`)
          : 0
      ) as number;

      // @ts-ignore
      e.submittalStatus =
        purchaseOrderSubmittalStatusOptions?.find(
          (f) =>
            `${f.label}`?.toLowerCase() ===
            `${e.submittalStatus}`?.toLowerCase()
        )?.value || 0;

      return { ...e };
    });

    // @ts-ignore
    reset((values) => {
      let purchaseOrderMaterials = [];
      const oldMaterials =
        values?.purchaseOrderMaterials?.filter((f) =>
          getLowerCasedMaterialName(f)
        ) || [];

      if (oldMaterials?.length) {
        purchaseOrderMaterials = bulkUploadParser.mergeMaterials({
          oldMaterials,
          newMaterials: rows,
          keysToBeUpdated: ["quantity", "unitRate", "amount"],
        });
      } else {
        purchaseOrderMaterials = rows;
      }

      setPoMaxIndex((purchaseOrderMaterials?.length || 0) - 1);

      return { ...values, purchaseOrderMaterials };
    });
    setTimeout(() => {
      handleCalculateTotal();
    }, 1000);
  }

  useEffect(() => {
    if (!purchaseOrderData) return;
    fetchLocationsByProjectId(
      purchaseOrderData?.purchaseOrderProject?.id || "",
      false
    );
    reset(getInitialValues(purchaseOrderData));
    setStatus(getValues("status") || purchaseOrderData?.status || 0);
  }, [purchaseOrderData, reset]);

  const handleDeletePurchaseOrder = async () => {
    const payload = {
      purchaseOrderId: getValues("id"),
    };
    try {
      setIsDeleting(true);
      await dispatch(deletePurchaseOrderById(payload)).unwrap();
      handleClose();
      // navigate(routePaths.PURCHASE_ORDERS);
    } catch (error) {
      console.error("Error deleting purchase order:", error);
    } finally {
      setIsDeleting(false);
    }
  };

  const handleReorderData = async (reorder: Reorder) => {
    try {
      setIsLoadROMaterial(true);
      window.scrollTo(0, 0);
      await fetchLocationsByProjectId(reorder?.project?.id || "", true);
      setValue("purchaseOrderProjectId", reorder?.project?.id || "");
      setValue("deliveryLocationId", reorder?.location?.id || "");
      reorder?.materials?.forEach(
        (material: ReorderMaterial, index: number) => {
          setValue(
            `purchaseOrderMaterials.${index}.costCode`,
            material.costCode
          );
          setValue(`purchaseOrderMaterials.${index}.name`, material.name);
          setValue(
            `purchaseOrderMaterials.${index}.quantity`,
            material.quantity
          );
          setValue(`purchaseOrderMaterials.${index}.regular`, material.regular);
          setValue(`purchaseOrderMaterials.${index}.spares`, material.spares);
          setValue(`purchaseOrderMaterials.${index}.samples`, material.samples);
          setValue(`purchaseOrderMaterials.${index}.unitRate`, 0);

          setValue(
            `purchaseOrderMaterials.${index}.unitOfMeasure`,
            material.unitOfMeasure
          );
          setValue(
            `purchaseOrderMaterials.${index}.isMaterialAlreadyApproved` as any,
            true
          );
          setValue(`purchaseOrderMaterials.${index}.cost`, 0);
        }
      );
    } catch (error) {
      console.error("Error fetching reorder data:", error);
    } finally {
      setIsLoadROMaterial(false);
    }
  };

  useEffect(() => {
    if (reorder?.project?.id) {
      handleReorderData(reorder);
    }
  }, [reorder]);

  useEffect(() => {
    if (
      location.pathname === routePaths.PURCHASE_ORDERS_NEW &&
      !reorder &&
      actionType.createRevision !== ActionTypeEnum.CREATE_REVISION
    ) {
      dispatch(resetState());
      reset(getInitialValues());
      setStatus(0);
    }
  }, [location.pathname, reorder]);

  const handleLikeAction = (index: number, action: boolean) => {
    setValue(`purchaseOrderMaterials.${index}.isMaterialRejected`, action);
    checkIfAnyMaterialIsRejected(getValues("purchaseOrderMaterials"));
    handleCalculateTotal();
  };

  const handleCreateRevision = () => {
    dispatch(resetState());
    setIsRevision(!isRevision);
    setValue("purchaseOrderNumber", "");
    setValue("revisionNumber", "");
    setValue("id", "");
    setValue("status", PurchaseOrderStatusEnum.PendingAdminApproval);
    setValue("title", "");
    setValue("attachments", []);
    setValue("tax", 0);
    setValue("subTotal", 0);
    setValue("total", 0);
    setValue(
      "purchaseOrderMaterials",
      getValues("purchaseOrderMaterials")?.map((v) => {
        return {
          ...v,
          quantity: 0,
          regular: 0,
          spares: 0,
          samples: 0,
          cost: 0,
          isMaterialRejected: false,
        };
      })
    );
    navigate(routePaths.PURCHASE_ORDERS_NEW);
  };

  useEffect(() => {
    if (isLocationModalOpen?.open) {
      dispatch(getAllStorageTypes());
    } else {
      dispatch(getLocationslist(getValues("purchaseOrderProjectId") || ""));
    }
  }, [dispatch, isLocationModalOpen?.open]);

  const handleOpenLocationModal = (title: string, field: string) => {
    setIsLocationModalOpen({
      title: title,
      open: true,
      field: field,
    });
  };

  const { vendorsList } = useAppSelector(getVendorsState);
  const memoizedVendorOptions = useMemo(() => {
    return [
      {
        value: "",
        label: "Select Vendor",
      },
      ...(vendorsList?.map((f) => ({
        value: f.id,
        label: f.name,
      })) || []),
    ];
  }, [vendorsList]);

  useEffect(() => {
    dispatch(getVendorslist());
  }, []);

  // Download PDF
  const showDownloadButton = () => {
    const hasPOId = getValues("id");
    const isAllowedForFieldCraft = isFieldsCraftAuthorized();
    const hideForPendingApprovalStatus = isPOMatchingStatusDF(
      getValues("status")
    );

    return hasPOId && hideForPendingApprovalStatus && !isAllowedForFieldCraft;
  };

  const handleClose = () => {
    const previousPath = location?.state?.previousPath || "";
    if (previousPath) {
      navigate(previousPath);
    } else {
      navigate(routePaths.PURCHASE_ORDERS);
    }
  };

  return (
    <>
      <LocationModal
        setLocationValue={setValue}
        projectId={getValues("purchaseOrderProjectId")}
        isLocationModalOpen={isLocationModalOpen}
        setIsLocationModalOpen={setIsLocationModalOpen}
      />
      {isLoadROMaterial ? (
        <CustomOverlayLoader />
      ) : (
        <SectionLayout>
          <Form
            onFinish={handleSubmit(onSubmit)}
            layout="vertical"
            autoComplete="off"
          >
            <CustomFormRow>
              <Col xs={24} className="mb-4">
                <Typography.Title level={5}>
                  General Information
                </Typography.Title>
              </Col>
              <Col xs={12}>
                <Controller
                  name="purchaseOrderNumber"
                  control={control}
                  render={({ field, fieldState: { error } }) => (
                    <Form.Item<FieldType>
                      label={
                        <CustomFormLabel
                          text="Purchase Order Number"
                          required
                        />
                      }
                      validateStatus={error ? "error" : ""}
                      help={error ? error.message : ""}
                    >
                      <Input
                        disabled={
                          Boolean(getValues("id") && !isRevision) &&
                          isPOMatchingStatusDF(getValues("status"))
                        }
                        {...field}
                        size="large"
                        placeholder="Purchase Order Number"
                      />
                    </Form.Item>
                  )}
                />
              </Col>
              <Col xs={12}>
                <Controller
                  name="title"
                  control={control}
                  render={({ field, fieldState: { error } }) => (
                    <Form.Item<FieldType>
                      label={<CustomFormLabel text="Title" required />}
                      validateStatus={error ? "error" : ""}
                      help={error ? error.message : ""}
                    >
                      <Input
                        {...field}
                        size="large"
                        placeholder="P.O. Title"
                        disabled={isPOMatchingStatusDF(getValues("status"))}
                      />
                    </Form.Item>
                  )}
                />
              </Col>
              <Col xs={12}>
                <Controller
                  name="purchaseOrderProjectId"
                  control={control}
                  render={({ field, formState: { errors } }) => (
                    <Form.Item
                      help={errors?.purchaseOrderProjectId?.message}
                      validateStatus={
                        errors?.purchaseOrderProjectId ? "error" : ""
                      }
                    >
                      <CustomFormLabel text="Project" required />
                      <Select
                        size="large"
                        className="mt-3"
                        {...field}
                        placeholder="Select Project"
                        options={memoizedProjectsOptions}
                        disabled={isPOMatchingStatusDF(getValues("status"))}
                        onChange={(value) => {
                          const materials = getValues("purchaseOrderMaterials");
                          setValue(
                            "purchaseOrderMaterials",
                            materials?.map((v) => {
                              return {
                                ...v,
                                expectedDeliveryDate: dayjs(new Date())
                                  .locale("en")
                                  .format(dateFormat),
                              };
                            })
                          );
                          field.onChange(value);

                          fetchLocationsByProjectId(value || "", true);
                        }}
                        showSearch
                        filterOption={(input, option) =>
                          (option?.label || "")
                            .toLowerCase()
                            .includes(input.toLowerCase())
                        }
                      />
                    </Form.Item>
                  )}
                />
              </Col>

              <Col xs={12}>
                <Controller
                  name="revisionNumber"
                  control={control}
                  render={({ field, fieldState: { error } }) => (
                    <Form.Item<FieldType>
                      label={<CustomFormLabel text="Revision Number" />}
                      validateStatus={error ? "error" : ""}
                      help={error ? error.message : ""}
                    >
                      <Input
                        {...field}
                        disabled={isPOMatchingStatusDF(getValues("status"))}
                        size="large"
                        placeholder="Enter Revision Number"
                      />
                    </Form.Item>
                  )}
                />
              </Col>
              <Col xs={12}>
                <Controller
                  name="dueDate"
                  control={control}
                  render={({ field }) => (
                    <Form.Item<FieldType>
                      label={<CustomFormLabel text="Due Date" />}
                      labelAlign="right"
                    >
                      <DatePicker
                        value={
                          dayjs(field.value).isValid()
                            ? dayjs(field.value)
                            : dayjs(new Date())
                        }
                        onChange={(date) => {
                          field.onChange(dayjs(date).locale("en").format());
                        }}
                        disabled={isPOMatchingStatusDF(getValues("status"))}
                        size="large"
                        style={{ width: "100%" }}
                        placeholder="MM/DD/YYYY"
                        format={dateFormat}
                      />
                    </Form.Item>
                  )}
                />
              </Col>
              <Col xs={12}>
                <Controller
                  name="assignedUserId"
                  control={control}
                  render={({ field, formState: { errors } }) => (
                    <Form.Item
                      help={errors?.assignedUserId?.message}
                      validateStatus={errors?.assignedUserId ? "error" : ""}
                    >
                      <CustomFormLabel text="Assign to" required />
                      <Select
                        size="large"
                        className="mt-3"
                        {...field}
                        placeholder="Select User"
                        options={memoizedUserRoleOptions}
                        showSearch
                        disabled={isPOMatchingStatusDF(getValues("status"))}
                        filterOption={(input, option) =>
                          (option?.label || "")
                            .toLowerCase()
                            .includes(input.toLowerCase())
                        }
                      />
                    </Form.Item>
                  )}
                />
              </Col>
              <Col xs={12}>
                <Controller
                  name="status"
                  control={control}
                  render={({ field }) => (
                    <Form.Item>
                      <CustomFormLabel text="Status" />
                      <Select
                        disabled
                        size="large"
                        className="mt-3"
                        {...field}
                        placeholder="Select Status"
                        options={purchaseOrderStatusOptionsWithAll}
                        showSearch
                        filterOption={(input, option) =>
                          (option?.label || "")
                            .toLowerCase()
                            .includes(input.toLowerCase())
                        }
                      />
                    </Form.Item>
                  )}
                />
              </Col>
              <Col xs={12}>
                <Controller
                  name="vendorId"
                  control={control}
                  render={({ field, formState: { errors } }) => (
                    <Form.Item
                      help={errors?.vendorId?.message}
                      validateStatus={errors?.vendorId ? "error" : ""}
                    >
                      <CustomFormLabel text="Vendor" required />
                      <Select
                        size="large"
                        className="mt-3"
                        {...field}
                        placeholder="Select Vendor"
                        options={memoizedVendorOptions}
                        disabled={isPOVendorDisabled(getValues("status"))}
                        showSearch
                        onChange={(value) => {
                          field.onChange(value);
                          const selectedVendor = vendorsList?.find(
                            (vendor) => vendor.id === value
                          );
                          setValue(
                            "vendorAddress",
                            selectedVendor?.address || ""
                          );
                        }}
                        filterOption={(input, option) =>
                          (option?.label || "")
                            .toLowerCase()
                            .includes(input.toLowerCase())
                        }
                      />
                    </Form.Item>
                  )}
                />
              </Col>
              <Col xs={12}>
                <Controller
                  name="notes"
                  control={control}
                  render={({ field }) => (
                    <Form.Item<FieldType>
                      label={
                        <CustomFormLabel text="Notes (For Internal Users)" />
                      }
                    >
                      <Input.TextArea
                        {...field}
                        disabled={isPOMatchingStatusDF(getValues("status"))}
                        size="large"
                        placeholder="Write your notes here..."
                        rows={5}
                      />
                    </Form.Item>
                  )}
                />
              </Col>
              <Col xs={12}>
                <Controller
                  name="vendorAddress"
                  control={control}
                  render={({ field }) => (
                    <Form.Item<FieldType>
                      label={<CustomFormLabel text="Vendor Address" required />}
                      help={errors?.vendorAddress?.message}
                      validateStatus={errors?.vendorAddress ? "error" : ""}
                    >
                      <Input.TextArea
                        {...field}
                        disabled={isPOVendorDisabled(getValues("status"))}
                        size="large"
                        placeholder="Vendor Address"
                        rows={5}
                      />
                    </Form.Item>
                  )}
                />
              </Col>

              <Divider />
              <Col xs={24} className="mb-4">
                <Typography.Title level={5}>Material Details</Typography.Title>
              </Col>
              <Col xs={12}>
                <Controller
                  name="isContractorResponsibleForTax"
                  control={control}
                  render={({ field }) => (
                    <Form.Item<FieldType>
                      label={
                        <CustomFormLabel
                          text="Is contractor responsible for sales tax?"
                          required
                        />
                      }
                    >
                      <Radio.Group
                        disabled={isPOMatchingStatusDF(getValues("status"))}
                        value={field.value}
                        onChange={field.onChange}
                      >
                        <Radio value={true}>Yes</Radio>
                        <Radio value={false}>No</Radio>
                      </Radio.Group>
                    </Form.Item>
                  )}
                />
              </Col>
              <Col xs={12}>
                <Form.Item
                  label={
                    <>
                      <CustomFormLabel text="Tax Percentage" required />
                      <CustomInfoTooltip
                        placement="top"
                        title={"Tax is not applicable on Freight"}
                      />
                    </>
                  }
                >
                  <Controller
                    name={`taxPercentage`}
                    control={control}
                    render={({ field, formState: { errors } }) => {
                      return (
                        <Form.Item
                          help={errors?.taxPercentage?.message}
                          validateStatus={errors?.taxPercentage ? "error" : ""}
                        >
                          <Space.Compact size="large" style={{ width: "100%" }}>
                            <InputNumber
                              {...field}
                              disabled={isPOMatchingStatusDF(
                                getValues("status")
                              )}
                              onChange={(value) => {
                                field.onChange(value);
                                handleCalculateTax(value);
                                handleCalculateTotal();
                              }}
                              style={{ width: "90%" }}
                              min={0}
                              max={100}
                              // step={0.001}
                              size="large"
                              type="number"
                              placeholder="Add Tax % here"
                            />
                            <Button
                              disabled
                              style={{
                                cursor: "default",
                                width: "10%",
                              }}
                            >
                              %
                            </Button>
                          </Space.Compact>
                        </Form.Item>
                      );
                    }}
                  />
                </Form.Item>
              </Col>
              <Col xs={24} className="flex justify-end gap-4 mt-5">
                {showDownloadButton() && (
                  <Button
                    className={`border border-primaryActive text-primaryActive stroke-primaryActive fill-white hover:!bg-primary25 hover:!fill-primary25 hover:!border-primary hover:!text-primary hover:!stroke-primary group`}
                    icon={<QrcodeOutlined />}
                    size="large"
                    data-loader="false"
                    onClick={async (event) => {
                      const el = event.currentTarget as HTMLButtonElement;
                      event.stopPropagation();
                      if (el.dataset.loader === "true") return;

                      el.dataset.loader = "true";

                      const blob = (await downloadPdfForPO({
                        purchaseOrderId: getValues("id"),
                      })) as Blob;
                      const name = `PO-${getValues("purchaseOrderNumber")}.pdf`;

                      manuallyDownloadBlob(blob, name);

                      el.dataset.loader = "false";
                    }}
                  >
                    <span className="group-data-[loader=true]:!hidden">
                      Download QR Code PDF
                    </span>
                    <span className="!hidden group-data-[loader=true]:!block">
                      Loading...
                    </span>
                  </Button>
                )}

                <BulkUploadButton
                  disabled={isPOMatchingStatusDF(getValues("status"))}
                  updateMaterialsCallback={updateMaterials}
                  shouldReset={resetBulkUploadFile}
                />
              </Col>

              <PurchaseOrderMaterialsRHF
                assumedSubmittal={assumedSubmittal}
                reorder={reorder ?? null}
                handleLikeAction={handleLikeAction}
                register={register}
                actionType={actionType}
                handleCalculateTotal={handleCalculateTotal}
                control={control}
                getValues={getValues}
                setValue={setValue}
                watch={watch}
                errors={errors}
                toggleLoader={toggleLoader}
                setPoMaxIndex={setPoMaxIndex}
              />

              <Divider />
              <Col xs={24} className="mb-4">
                <Typography.Title level={5}>
                  Additional Information
                </Typography.Title>
              </Col>
              <Col xs={12}>
                <Controller
                  control={control}
                  name="recentQuoteDocument"
                  render={({ field }) => (
                    <Form.Item<FieldType>
                      labelAlign="right"
                      initialValue={field.value}
                      label={<CustomFormLabel text="Recent Quote" />}
                    >
                      <CustomFileUploadRHF
                        disabled={isPOMatchingStatusDF(getValues("status"))}
                        setValue={setValue}
                        getValues={getValues}
                        fieldName={field.name}
                        deletedFileName="deleteAttachmentIds"
                        buttonText="Browse Files"
                        maxCount={10}
                      />
                    </Form.Item>
                  )}
                />
              </Col>
              <Col xs={12}>
                <Controller
                  name="deliveryLocationId"
                  control={control}
                  render={({ field, formState: { errors } }) => (
                    <Form.Item
                      help={errors?.deliveryLocationId?.message}
                      validateStatus={errors?.deliveryLocationId ? "error" : ""}
                    >
                      <CustomFormLabel text="Delivery Address" required />
                      <Select
                        // disabled={true}
                        disabled={isPOMatchingStatusDF(getValues("status"))}
                        size="large"
                        className="mt-3"
                        {...field}
                        placeholder="Select Location"
                        options={memoizedLocationOptions}
                        showSearch
                        filterOption={(input, option) =>
                          (option?.label || "")
                            .toLowerCase()
                            .includes(input.toLowerCase())
                        }
                        dropdownRender={(menu) => (
                          <>
                            {menu}
                            <Divider className="mt-2 mb-1" />
                            <Space className="p-1">
                              <Button
                                type="text"
                                icon={<PlusOutlined />}
                                onClick={() =>
                                  handleOpenLocationModal(
                                    "Add New Delivery Address",
                                    "deliveryLocationId"
                                  )
                                }
                              >
                                Add New Delivery Address
                              </Button>
                            </Space>
                          </>
                        )}
                      />
                    </Form.Item>
                  )}
                />
              </Col>
              {deliveryContactsFields?.map((contact, id) => (
                <React.Fragment key={contact.id}>
                  <Col xs={12}>
                    <Controller
                      name={`deliveryContacts.${id}.id`}
                      control={control}
                      render={({ field, formState: { errors } }) => (
                        <Form.Item
                          help={errors?.deliveryContacts?.[id]?.id?.message}
                          validateStatus={
                            errors?.deliveryContacts?.[id]?.id ? "error" : ""
                          }
                        >
                          <CustomFormLabel text="Delivery Contact" required />
                          <Select
                            size="large"
                            className="mt-3"
                            {...field}
                            onChange={(value) => {
                              field.onChange(value);
                              handleChangedDeliveryContact(value, id);
                            }}
                            disabled={isPOMatchingStatusDF(getValues("status"))}
                            placeholder="Select Delivery Contact"
                            options={getFilteredUserOptions(id)}
                            showSearch
                            filterOption={(input, option) =>
                              (option?.label || "")
                                .toLowerCase()
                                .includes(input.toLowerCase())
                            }
                          />
                        </Form.Item>
                      )}
                    />
                  </Col>
                  <Col xs={10}>
                    <Controller
                      name={`deliveryContacts.${id}.phoneNumber`}
                      control={control}
                      render={({ field, formState: { errors } }) => (
                        <Form.Item
                          help={
                            errors?.deliveryContacts?.[id]?.phoneNumber?.message
                          }
                          validateStatus={
                            errors?.deliveryContacts?.[id]?.phoneNumber
                              ? "error"
                              : ""
                          }
                        >
                          <CustomFormLabel text="Contact Phone" required />
                          <div className="mt-3"></div>
                          <PhoneInput
                            disabled
                            placeholder="(555) 000-0000"
                            country={"us"}
                            value={field.value}
                            onChange={field.onChange}
                            inputProps={{
                              autoFocus: true,
                            }}
                          />
                        </Form.Item>
                      )}
                    />
                  </Col>
                  <Col xs={2} className="flex items-center">
                    <Button
                      className="border-0 shadow-none text-primary font-medium mt-4"
                      onClick={() => removeContact(id)}
                      disabled={deliveryContactsFields.length === 1}
                    >
                      Delete
                    </Button>
                  </Col>
                </React.Fragment>
              ))}

              <Col xs={12}></Col>
              <Col xs={12}>
                {" "}
                <Button
                  className="border-0 shadow-none text-primary font-medium"
                  size="small"
                  icon={<CustomIcon width={16} type="add-circle" />}
                  onClick={() => appendContact({ id: "", phoneNumber: "" })}
                >
                  Add another Delivery Contact
                </Button>
              </Col>

              <Col xs={12} className="mt-5">
                <Controller
                  name="paymentTerm"
                  control={control}
                  render={({ field, formState: { errors } }) => (
                    <Form.Item
                      help={errors?.paymentTerm?.message}
                      validateStatus={errors?.paymentTerm ? "error" : ""}
                    >
                      <CustomFormLabel text="Payment Term" required />
                      <Select
                        size="large"
                        className="mt-3"
                        {...field}
                        disabled={isPOMatchingStatusDF(getValues("status"))}
                        placeholder="Payment Term"
                        options={paymentTermOptions}
                        showSearch
                        filterOption={(input, option) =>
                          (option?.label || "")
                            .toLowerCase()
                            .includes(input.toLowerCase())
                        }
                      />
                    </Form.Item>
                  )}
                />
              </Col>
              <Col xs={12} className="mt-5">
                <Controller
                  name="deliveryNotes"
                  control={control}
                  render={({ field }) => (
                    <Form.Item<FieldType>
                      label={<CustomFormLabel text="Delivery Notes" />}
                    >
                      <Input.TextArea
                        {...field}
                        disabled={isPOMatchingStatusDF(getValues("status"))}
                        size="large"
                        placeholder="Write your notes here..."
                        rows={5}
                      />
                    </Form.Item>
                  )}
                />
              </Col>
            </CustomFormRow>
            <Divider />
            <Typography.Title level={5}>Attachments</Typography.Title>
            <SectionLayout
              className="rounded-xl flex items-center min-h-64 max-h-full my-5"
              borderStyle="dashed"
            >
              <div className="flex flex-col justify-center items-center p-8">
                <div className="mb-4">
                  <CustomIcon type="add-file" className="fill-white" />
                </div>

                <h6 className="font-medium text-sm !mb-2">
                  Select a file to import
                </h6>

                <Flex justify="center" gap={5} className="mt-2">
                  <Controller
                    control={control}
                    name="attachments"
                    render={({ field }) => (
                      <Form.Item<FieldType>
                        labelAlign="right"
                        initialValue={field.value}
                      >
                        <CustomFileUploadRHF
                          disabled={isPOMatchingStatusDF(getValues("status"))}
                          setValue={setValue}
                          getValues={getValues}
                          fieldName={field.name}
                          deletedFileName="deleteAttachmentIds"
                          buttonText="Browse Files"
                          maxCount={10}
                        />
                      </Form.Item>
                    )}
                  />
                </Flex>
              </div>
            </SectionLayout>
            {(resError || reqError || successMessage) && (
              <CustomAlert
                message={reqError || resError || successMessage || ""}
                type={successMessage ? "success" : "error"}
              />
            )}
            <Flex justify="flex-end" className="gap-4">
              {getValues("id") && (
                <Button
                  loading={
                    (actionType.delete === ActionTypeEnum.DELETE &&
                      isSubmitting) ||
                    isDeleting
                  }
                  disabled={
                    isSubmitting ||
                    isDeleting ||
                    isPOMatchingStatusDF(getValues("status"))
                  }
                  type="default"
                  onClick={() => {
                    handleDeletePurchaseOrder(),
                      setActionType({
                        delete: ActionTypeEnum.DELETE,
                      });
                  }}
                >
                  {actionType.delete === ActionTypeEnum.DELETE && isSubmitting
                    ? "Deleting.."
                    : "Delete"}
                </Button>
              )}
              {getValues("id") && (
                <Button
                  loading={
                    actionType.createMRI === ActionTypeEnum.CREATE_MRI &&
                    isSubmitting
                  }
                  disabled={
                    isSubmitting ||
                    isDeleting ||
                    getValues("status") ==
                      PurchaseOrderStatusEnum.VendorRejected ||
                    getValues("status") ==
                      PurchaseOrderStatusEnum.VendorApproved ||
                    getValues("status") ==
                      PurchaseOrderStatusEnum.AdminRejectedAll ||
                    getValues("status") ==
                      PurchaseOrderStatusEnum.AdminApprovedAll ||
                    getValues("status") ==
                      PurchaseOrderStatusEnum.AdminApprovedPartial ||
                    getValues("status") ==
                      PurchaseOrderStatusEnum.PendingAdminApproval ||
                    getValues("status") ==
                      PurchaseOrderStatusEnum.FullyReceived ||
                    getValues("status") ==
                      PurchaseOrderStatusEnum.VendorApprovalPending
                  }
                  type="default"
                  htmlType="submit"
                  onClick={() =>
                    setActionType({
                      createMRI: ActionTypeEnum.CREATE_MRI,
                    })
                  }
                >
                  {actionType.createMRI === ActionTypeEnum.CREATE_MRI &&
                  isSubmitting
                    ? "Creating.."
                    : "Create MRI"}
                </Button>
              )}
              {getValues("id") && isCominedAdminAuthorized() && (
                <Button
                  loading={
                    actionType.createInvoice ===
                      ActionTypeEnum.CREATE_INVOICE && isSubmitting
                  }
                  disabled={
                    isSubmitting ||
                    isDeleting ||
                    getValues("status") ==
                      PurchaseOrderStatusEnum.VendorRejected ||
                    getValues("status") ==
                      PurchaseOrderStatusEnum.VendorApproved ||
                    getValues("status") ==
                      PurchaseOrderStatusEnum.AdminRejectedAll ||
                    getValues("status") ==
                      PurchaseOrderStatusEnum.AdminApprovedAll ||
                    getValues("status") ==
                      PurchaseOrderStatusEnum.AdminApprovedPartial ||
                    getValues("status") ==
                      PurchaseOrderStatusEnum.PendingAdminApproval ||
                    getValues("status") ==
                      PurchaseOrderStatusEnum.VendorApprovalPending
                  }
                  type="default"
                  htmlType="submit"
                  onClick={() =>
                    setActionType({
                      createInvoice: ActionTypeEnum.CREATE_INVOICE,
                    })
                  }
                >
                  {actionType.createInvoice === ActionTypeEnum.CREATE_INVOICE &&
                  isSubmitting
                    ? "Creating.."
                    : "Create Invoice"}
                </Button>
              )}

              {getValues("id") && (
                <Button
                  disabled={
                    isSubmitting ||
                    isDeleting ||
                    getValues("status") ==
                      PurchaseOrderStatusEnum.VendorRejected ||
                    getValues("status") ==
                      PurchaseOrderStatusEnum.VendorApproved ||
                    getValues("status") ==
                      PurchaseOrderStatusEnum.AdminRejectedAll ||
                    getValues("status") ==
                      PurchaseOrderStatusEnum.AdminApprovedAll ||
                    getValues("status") ==
                      PurchaseOrderStatusEnum.AdminApprovedPartial ||
                    getValues("status") ==
                      PurchaseOrderStatusEnum.PendingAdminApproval ||
                    getValues("status") ==
                      PurchaseOrderStatusEnum.VendorApprovalPending
                  }
                  type="default"
                  htmlType="submit"
                  onClick={() =>
                    setActionType({
                      createRO: ActionTypeEnum.CREATE_RO,
                    })
                  }
                >
                  {actionType.createRO === ActionTypeEnum.CREATE_RO &&
                  isSubmitting
                    ? "Creating.."
                    : "Create Reorder"}
                </Button>
              )}

              {/* CREATE_REVISION */}
              {getValues("id") && (
                <Button
                  loading={
                    actionType.createRevision ===
                      ActionTypeEnum.CREATE_REVISION && isSubmitting
                  }
                  disabled={
                    isSubmitting || isDeleting
                    // (getValues("status") !==
                    //   PurchaseOrderStatusEnum.AdminRejectedAll &&
                    //   getValues("status") !==
                    //     PurchaseOrderStatusEnum.VendorRejected)
                  }
                  type="default"
                  htmlType="submit"
                  onClick={() => {
                    setActionType({
                      createRevision: ActionTypeEnum.CREATE_REVISION,
                    });
                    handleCreateRevision();
                  }}
                >
                  {actionType.createRevision ===
                    ActionTypeEnum.CREATE_REVISION && isSubmitting
                    ? "Creating.."
                    : "Create Revision"}
                </Button>
              )}
              {/* Reject All */}
              {getValues("id") && !isFieldsCraftAuthorized() && (
                <Button
                  loading={
                    actionType.rejectAll === ActionTypeEnum.REJECT_ALL &&
                    isSubmitting
                  }
                  disabled={
                    isSubmitting ||
                    isDeleting ||
                    isPOMatchingStatusDF(getValues("status"))
                  }
                  className="font-medium !border-danger-5 !text-danger-5 bg-danger-510 hover:!bg-danger-5-18 hover:!border-danger-5-02 disabled:!bg-neutral-1 disabled:!border-neutral-5 disabled:!text-neutral-75"
                  type="default"
                  htmlType="submit"
                  onClick={() => {
                    setActionType({
                      rejectAll: ActionTypeEnum.REJECT_ALL,
                    });
                  }}
                >
                  {actionType.rejectAll === ActionTypeEnum.REJECT_ALL &&
                  isSubmitting
                    ? "Rejecting.."
                    : "Reject All"}
                </Button>
              )}

              {getValues("id") && !isFieldsCraftAuthorized() && (
                <Button
                  loading={
                    actionType.approve === ActionTypeEnum.APPROVE &&
                    isSubmitting
                  }
                  disabled={
                    !isAnyMaterialRejected ||
                    isSubmitting ||
                    isDeleting ||
                    isPOMatchingStatusDF(getValues("status"))
                  }
                  type="default"
                  htmlType="submit"
                  onClick={() => {
                    setActionType({
                      approve: ActionTypeEnum.APPROVE,
                    });
                  }}
                >
                  {actionType.approve === ActionTypeEnum.APPROVE && isSubmitting
                    ? "Approving.."
                    : "Approve"}
                </Button>
              )}
              {getValues("id") && !isFieldsCraftAuthorized() && (
                <Button
                  loading={
                    actionType.approveAll === ActionTypeEnum.APPROVE_ALL &&
                    isSubmitting
                  }
                  disabled={
                    isAnyMaterialRejected ||
                    isSubmitting ||
                    isDeleting ||
                    isPOMatchingStatusDF(getValues("status"))
                    // ||
                    // isPOMatchingStatusDF(getValues("status"))
                  }
                  type="default"
                  className="font-medium !border-green-primary !text-white !bg-green-primary hover:!bg-green-primaryHover hover:!border-green-primaryHover disabled:!bg-neutral-1 disabled:!border-neutral-5 disabled:!text-neutral-75"
                  htmlType="submit"
                  onClick={() => {
                    setActionType({
                      approveAll: ActionTypeEnum.APPROVE_ALL,
                    });
                  }}
                >
                  {actionType.approveAll === ActionTypeEnum.APPROVE_ALL &&
                  isSubmitting
                    ? "Approving.."
                    : "Approve All"}
                </Button>
              )}
            </Flex>
            <Flex justify="flex-end" className="gap-4 mt-5">
              <Button
                disabled={isSubmitting || isDeleting}
                type="default"
                onClick={handleClose}
              >
                Cancel
              </Button>

              <Button
                loading={
                  actionType.save === ActionTypeEnum.SAVE && isSubmitting
                }
                disabled={
                  isSubmitting || isDeleting
                  // isPOMatchingStatusDF(getValues("status"))
                }
                type="primary"
                htmlType="submit"
                onClick={() =>
                  setActionType({
                    save: ActionTypeEnum.SAVE,
                  })
                }
              >
                {actionType.save === ActionTypeEnum.SAVE && isSubmitting
                  ? "Saving.."
                  : "Save"}
              </Button>
              <Button
                loading={
                  actionType.saveAndNew === ActionTypeEnum.SAVE_AND_NEW &&
                  isSubmitting
                }
                disabled={
                  isSubmitting ||
                  isDeleting ||
                  isPOMatchingStatusDF(getValues("status"))
                }
                type="primary"
                htmlType="submit"
                onClick={() => {
                  setActionType({
                    saveAndNew: ActionTypeEnum.SAVE_AND_NEW,
                  });
                }}
              >
                {actionType.saveAndNew === ActionTypeEnum.SAVE_AND_NEW &&
                isSubmitting
                  ? "Saving and Newing.."
                  : "Save & New"}
              </Button>
              <Button
                loading={
                  actionType.saveAndRelease ===
                    ActionTypeEnum.SAVE_AND_RELEASE && isSubmitting
                }
                disabled={
                  isSubmitting ||
                  isDeleting ||
                  getValues("status") ==
                    PurchaseOrderStatusEnum.PendingAdminApproval ||
                  getValues("status") ==
                    PurchaseOrderStatusEnum.AdminRejectedAll ||
                  getValues("status") ==
                    PurchaseOrderStatusEnum.PartiallyReceived ||
                  getValues("status") ==
                    PurchaseOrderStatusEnum.FullyReceived ||
                  getValues("status") == PurchaseOrderStatusEnum.AdminSigned ||
                  isAdminAuthorized()
                }
                type="primary"
                htmlType="submit"
                onClick={() => {
                  setActionType({
                    saveAndRelease: ActionTypeEnum.SAVE_AND_RELEASE,
                  });
                }}
              >
                {actionType.saveAndRelease ===
                  ActionTypeEnum.SAVE_AND_RELEASE && isSubmitting
                  ? "Saving and Releasing.."
                  : "Save & Release"}
              </Button>
            </Flex>
            {getValues("id") && (
              <Flex justify="flex-end" className="mt-5">
                <CreatedByUserBadge
                  // userName={getValues("createdBy")}
                  // // @ts-ignore
                  // date={getValues("createdDate")}
                  userName={
                    getValues("modifiedDate") == null
                      ? getValues("createdBy")
                      : getValues("lastModifiedBy")
                  }
                  date={getValues("lastModifiedDate")}
                  isModifiedBadge={
                    getValues("modifiedDate") == null ? false : true
                  }
                />
              </Flex>
            )}
          </Form>
        </SectionLayout>
      )}
    </>
  );
};

export default PurchaseOrderDetailsFormRFH;
