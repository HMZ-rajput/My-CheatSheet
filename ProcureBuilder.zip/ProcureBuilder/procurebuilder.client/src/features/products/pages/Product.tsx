import routePaths from "@/src/utils/routePaths";
import CustomIcon from "@components/common/CustomIcon";
import PageLayout from "@components/layout/PageLayout";
import { getConsistentSpacing } from "@utils/theme-helpers";
import { Button } from "antd";
import { useNavigate } from "react-router-dom";
import ProductList from "../components/ProductList";
import useAuthorization from "@/src/hooks/useAuthorization";

export default function Product() {
  const navigate = useNavigate();
  const { isFieldsCraftAuthorized } = useAuthorization();
  return (
    <>
      <PageLayout
        title="Products"
        titleSibling={
          !isFieldsCraftAuthorized() && (
            <Button
              size="large"
              type="primary"
              icon={
                <CustomIcon
                  type="plus"
                  className="fill-white"
                  width={parseInt(getConsistentSpacing(3))}
                  height={parseInt(getConsistentSpacing(3))}
                />
              }
              onClick={() => navigate(routePaths.PRODUCTS_CREATE)}
            >
              Add New
            </Button>
          )
        }
      >
        <ProductList />
      </PageLayout>
    </>
  );
}
