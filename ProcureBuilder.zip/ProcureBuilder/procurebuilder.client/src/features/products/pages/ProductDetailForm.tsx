import { Card } from "antd";
import PageLayout from "../../../components/layout/PageLayout";
// import ProductInventoryForm from "../components/ProductInventoryForm";
import ProductInventorySection from "../components/ProductInventorySection";

const ProductDetailForm = () => {
  return (
    <div>
      {/* <h1>ProductDetailForm</h1> */}
      <PageLayout title="Add Products">
        <Card>
          <ProductInventorySection />
        </Card>
      </PageLayout>
    </div>
  );
};

export default ProductDetailForm;
