import routePaths from "@/src/utils/routePaths";
import CustomIcon from "@components/common/CustomIcon";
import PageLayout from "@components/layout/PageLayout";
import { getConsistentSpacing } from "@utils/theme-helpers";
import { Button } from "antd";
import { useNavigate, useParams } from "react-router-dom";
import ProductListByName from "../components/ProductListByName";
import useAuthorization from "@/src/hooks/useAuthorization";
export default function ProductView() {
  const navigate = useNavigate();
  const { name } = useParams();
  const { isFieldsCraftAuthorized } = useAuthorization();

  // const handleEdit = (Id?: Readonly<Params<string>>) => {
  //   navigate(routePaths.PRODUCTS_EDIT_BY_ID + "/" + Id);
  // };

  return (
    <>
      <PageLayout
        titlePrefixIcon="product-name"
        title={name}
        isActive={true}
        titleSibling={
          !isFieldsCraftAuthorized() && (
            <Button
              size="large"
              type="primary"
              icon={
                <CustomIcon
                  type="plus"
                  className="fill-white"
                  width={parseInt(getConsistentSpacing(3))}
                  height={parseInt(getConsistentSpacing(3))}
                />
              }
              onClick={() => navigate(routePaths.PRODUCTS_CREATE)}
            >
              Add New
            </Button>
          )
        }
      >
        <ProductListByName />
        {/* <ProductList /> */}
        {/* <InventoryList handleEdit={handleEdit} /> */}
      </PageLayout>
    </>
  );
}
