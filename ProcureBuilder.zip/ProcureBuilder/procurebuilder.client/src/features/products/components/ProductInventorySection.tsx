// import { getInventoryListByProjectId } from "@/src/apis/inventoryApis";
// import { useAppDispatch } from "@/src/hooks/useAppDispatch";
import { useAppSelector } from "@/src/hooks/useAppSelector";
import { getInventoriesState } from "@/src/store/slices/inventorySlice";
import { Inventory } from "@/src/utils/types";
import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
// import InventoryDetailForm from "../../inventory/components/InventoryDetailForm";
import InventoryList from "../../inventory/components/InventoryList";
import ProductInventoryForm from "./ProductInventoryForm";
import routePaths from "@/src/utils/routePaths";
import { useAppDispatch } from "@/src/hooks/useAppDispatch";
import { getAllInventoryListByProjectId } from "@/src/apis/inventoryApis";

export default function ProductInventorySection() {
  const [displayForm, setDisplayForm] = useState(false);
  const { inventories, createdBy, createdDate, modifiedBy, modifiedDate } =
    useAppSelector(getInventoriesState);
  const [_, setHasData] = useState(false);
  const { name, projectId } = useParams();
  const navigate = useNavigate();
  const dispatch = useAppDispatch();

  // const handleEdit = () => {
  //   setDisplayForm(true);
  // };

  const getInventoryByProjectId = async () => {
    await dispatch(
      getAllInventoryListByProjectId({ projectId: projectId || "" })
    );
  };

  const handleEdit = async (getDataAgain = false) => {
    if (getDataAgain) {
      await getInventoryByProjectId();
    }

    setDisplayForm(true);
  };

  const handleBackToTable = () => {
    if (projectId) {
      setDisplayForm(false);
    } else {
      navigate(routePaths.PRODUCTS);
    }
  };

  // const dispatch = useAppDispatch();

  // useEffect(() => {
  //   if (projectId) {
  //     dispatch(getInventoryListByProjectId({ projectId: projectId }));
  //   }
  // }, [displayForm]);

  const data =
    inventories?.flatMap(
      (inventory: Inventory) => inventory?.materials || []
    ) || [];

  useEffect(() => {
    if (data?.length > 0) {
      setHasData(true);
    }
  }, [data?.length]);

  const productInventoryData = {
    inventories,
    createdBy: createdBy || "",
    createdDate: createdDate || null,
    // projectId: projectId || null,
    modifiedBy: modifiedBy || "",
    modifiedDate,
  };

  return (
    <>
      {projectId && !displayForm ? (
        <InventoryList handleEdit={handleEdit} data={data} name={name} />
      ) : (
        <ProductInventoryForm
          // setHasData={setHasData}
          handleBackToTable={handleBackToTable}
          inventories={productInventoryData}
        />
      )}
    </>
  );
}
