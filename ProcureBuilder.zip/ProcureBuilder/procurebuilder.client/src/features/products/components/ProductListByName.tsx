import CustomIcon from "@/src/components/common/CustomIcon";
import CustomTable from "@/src/components/table/CustomTable";
import { useAppSelector } from "@/src/hooks/useAppSelector";
import {
  allInventoryLocationsOption,
  allProjectsOptions,
} from "@/src/utils/constants";
import SectionLayout from "@components/layout/SectionLayout";
import { Button, Col, TableProps } from "antd";
import { useEffect, useMemo, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";

import { getAllProductByName } from "@/src/apis/productApis";
import CustomFormRow from "@/src/components/form/CustomFormRow";
import CustomTableFilters, {
  CustomFiltersType,
} from "@/src/components/table/CustomTableFilters";
import { useAppDispatch } from "@/src/hooks/useAppDispatch";
// import { getLocationsState } from "@/src/store/slices/locationSlice";
import { getProductState } from "@/src/store/slices/productsSlice";
import { getProjectsState } from "@/src/store/slices/projectsSlice";
import routePaths from "@/src/utils/routePaths";
import { ProductMaterial } from "@/src/utils/types";
import { EyeOutlined } from "@ant-design/icons";

export default function ProductListByName() {
  const [searchTerm, setSearchTerm] = useState("");
  const { name } = useParams();
  const navigate = useNavigate();
  const dispatch = useAppDispatch();
  const {
    productsByName,
    isLoading,
    totalCount,
    currentPage: projectsCurrentPage,
    pageSize: projectsPageSize,
  } = useAppSelector(getProductState);

  // const { locationsList } = useAppSelector(getLocationsState);
  const { projectsSummarizedData } = useAppSelector(getProjectsState);

  const [page, setPage] = useState<number>(projectsCurrentPage);
  const [pageSize, setPageSize] = useState(projectsPageSize);
  const [isFirstCall, setIsFirstCall] = useState(false);

  // const locationsListOptions = useMemo(() => {
  //   return [
  //     allInventoryLocationsOption,
  //     ...(locationsList?.map((f) => ({
  //       value: f.id,
  //       label: f.name,
  //     })) || []),
  //   ];
  // }, [locationsList]);

  const memoizedProjectsOptions = useMemo(() => {
    return [
      {
        value: "",
        label: "All Project",
      },
      ...(projectsSummarizedData?.map((f) => ({
        value: f.id,
        label: f.name,
      })) || []),
    ];
  }, [projectsSummarizedData]);

  const [filters, setFilters] = useState<CustomFiltersType>({
    project: {
      value: allProjectsOptions.value || "",
      options: memoizedProjectsOptions,
    },
    // location: {
    //   value: allInventoryLocationsOption?.value,
    //   options: locationsListOptions,
    // },
  });

  useEffect(() => {
    setFilters({
      project: {
        value: allProjectsOptions?.value,
        options: memoizedProjectsOptions,
      },
      // location: {
      //   value: allInventoryLocationsOption?.value,
      //   options: locationsListOptions,
      // },
    });
  }, []);

  // useEffect(() => {
  //   if (projectId) {
  //     dispatch(getLocationslist(projectId));
  //   }
  // }, [projectId, dispatch]);

  const columns: TableProps<ProductMaterial>["columns"] = [
    {
      title: "Projects",
      dataIndex: "projectName",
      key: "projectName",
      sorter: (a, b) => a.projectName?.localeCompare(b.projectName),
    },
    {
      title: "Locations",
      dataIndex: "projectLocationName",
      key: "projectLocationName",
      sorter: (a, b) =>
        a.projectLocationName?.localeCompare(b.projectLocationName),
    },
    {
      title: "Sublocations",
      dataIndex: "subLocationName",
      key: "subLocationName",
      sorter: (a, b) => a.subLocationName?.localeCompare(b.subLocationName),
    },
    {
      title: "Quantity",
      dataIndex: "quantity",
      key: "quantity",
      sorter: (a, b) => a.quantity - b.quantity,
    },
    {
      title: "Unit of Measurement",
      dataIndex: "unitOfMeasure",
      key: "unitOfMeasure",
      sorter: (a, b) => a.unitOfMeasure?.localeCompare(b.unitOfMeasure),
    },
    {
      title: "Refillable",
      dataIndex: "isRefillable",
      key: "isRefillable",
      render: (_, { isRefillable }) => (
        <CustomFormRow>
          <Col>
            <CustomIcon
              type={
                isRefillable ? "check-mark-outline" : "cancel-close-outline"
              }
            />
          </Col>
        </CustomFormRow>
      ),
    },

    {
      title: "",
      dataIndex: "",
      key: "",
      render: (_, record) => (
        <Button
          shape="circle"
          className="hover:!fill-primary"
          icon={<EyeOutlined />}
          onClick={() =>
            navigate(
              `${routePaths.PRODUCTS_DETAILS}/${name}/${record?.projectId}`
            )
          }
        />
      ),
    },
  ];

  // useEffect(() => {
  //   if (projectId) {
  //     dispatch(getLocationslist(projectId));
  //   }
  // }, [projectId, dispatch]);

  function handleGetResults() {
    const project =
      filters?.project?.value !== allProjectsOptions.value
        ? (filters?.project?.value as string)
        : undefined;

    const location =
      filters.location?.value !== allInventoryLocationsOption?.value
        ? filters?.location?.value?.toString()
        : undefined;

    dispatch(
      getAllProductByName({
        pageNumber: page,
        pageSize,
        search: searchTerm || undefined,
        productName: name,
        projectId: project,
        projectLocationId: location,
      })
    );
  }

  const handleSearch = () => {
    handleGetResults();
  };

  useEffect(() => {
    handleGetResults();
  }, [filters]);

  useEffect(() => {
    if (
      isFirstCall ||
      projectsCurrentPage !== page ||
      projectsPageSize !== pageSize
    ) {
      handleGetResults();
      if (isFirstCall) {
        setIsFirstCall(false);
      }
    }
  }, [page, pageSize, isFirstCall]);

  return (
    <>
      <SectionLayout>
        <CustomTable
          data={productsByName || []}
          columns={columns || []}
          searchTerm={searchTerm}
          setSearchTerm={setSearchTerm}
          handleSearch={handleSearch}
          isLoading={isLoading}
          totalCount={totalCount}
          page={page}
          setPage={setPage}
          pageSize={pageSize}
          setPageSize={setPageSize}
          filterElements={
            <CustomTableFilters filters={filters} setFilters={setFilters} />
          }
          hasSearch={true}
          hasPagination={true}
        />
      </SectionLayout>
    </>
  );
}
