// import { Inventory, InventoryMaterial, LocationsList } from "@/src/utils/types";
// import { FieldInputProps, FormikProps } from "formik";
import ProductInventorySection from "./ProductInventorySection";

// type InputNumberFieldProps = {
//   field: FieldInputProps<number>;
//   form: FormikProps<InventoryMaterial>;
// };

// export type LocationResponse = {
//   locations: LocationsList[];
// };

// type Props = {
//   inventories?: Inventory[];
//   handleBackToTable?: () => void;
// };

const ProductForm = () => {
  return <ProductInventorySection />;
};

export default ProductForm;
