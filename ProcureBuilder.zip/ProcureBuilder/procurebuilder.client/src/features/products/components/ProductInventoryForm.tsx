import {
  createInventory,
  deleteInventoryById,
  editInventoryById,
  getAllInventoryListByProjectId,
  getAllInventoryListByProjectIdOnlyInventoryMaterial,
} from "@/src/apis/inventoryApis";
import { getLocationslist } from "@/src/apis/locationApis";
import { getAllStorageTypes } from "@/src/apis/storageTypeApis";
import CreatedByUserBadge from "@/src/components/common/CreatedByUserBadge";
import CustomAlert from "@/src/components/common/CustomAlert";
import CustomFormLabel from "@/src/components/common/CustomFormLabel";
import CustomIcon from "@/src/components/common/CustomIcon";
import CustomOverlayLoader from "@/src/components/common/CustomOverlayloader";
import CustomFormRow from "@/src/components/form/CustomFormRow";
import DeleteIconButton from "@/src/components/icon-buttons/DeleteIconButton";
import { initialInventoryMaterials } from "@/src/data/intialsValues";
import { InventoryValidationSchema } from "@/src/data/validationsSchema";
import { getLowerCasedMaterialName } from "@/src/external-modules/bulk-upload/bulk-upload-utils";
import BulkUploadButton from "@/src/external-modules/bulk-upload/BulkUploadButton";
import BulkUploaderParser from "@/src/external-modules/bulk-upload/BulkUploadParser";
import LocationModal from "@/src/features/locations/components/LocationModal";
import { useAppDispatch } from "@/src/hooks/useAppDispatch";
import { useAppSelector } from "@/src/hooks/useAppSelector";
import useAuthorization from "@/src/hooks/useAuthorization";
import {
  getInventoriesState,
  resetState,
} from "@/src/store/slices/inventorySlice";
import { getLocationsState } from "@/src/store/slices/locationSlice";
import { getProjectsState } from "@/src/store/slices/projectsSlice";
import { allProjectsOptions } from "@/src/utils/constants";
import routePaths from "@/src/utils/routePaths";
import {
  Inventory,
  InventoryMaterial,
  LabelSupportedInventoryMaterial,
} from "@/src/utils/types";
import { PlusOutlined } from "@ant-design/icons";
import { yupResolver } from "@hookform/resolvers/yup";
import {
  Button,
  Col,
  Divider,
  Flex,
  Form,
  Select,
  Space,
  Typography,
} from "antd";
import { useEffect, useMemo, useState } from "react";
import { Controller, Resolver, useFieldArray, useForm } from "react-hook-form";
import { useLocation, useNavigate, useParams } from "react-router-dom";
import ProductInventoryMaterials from "./ProductInventoryMaterials";

// Define types
type FormValues = {
  projectId: string | null;
  createdBy?: string;
  createdDate?: Date | null;
  modifiedBy?: string;
  modifiedDate?: Date | null;
  lastModifiedDate?: Date | null;
  inventories: Inventory[];
};

type ProductInventoryData = {
  projectId?: string | null;
  createdBy?: string;
  createdDate?: Date | null;
  modifiedBy?: string;
  modifiedDate?: Date | null;
  lastModifiedDate?: Date | null;
  inventories: Inventory[] | null;
};

type Props = {
  inventories: ProductInventoryData | null;
  handleBackToTable?: () => void;
};

const ProductInventoryForm = ({ inventories, handleBackToTable }: Props) => {
  const [_, setSelectedLocation] = useState<string | null>(null);
  const [selectedProjectId, setSelectedProjectId] = useState<string | null>(
    null
  );
  const [isLocationModalOpen, setIsLocationModalOpen] = useState<{
    open: boolean;
    title?: string | null;
    field?: string;
  }>({ open: false, title: null, field: "" });
  const { isFieldsCraftAuthorized } = useAuthorization();

  const [actionType, setActionType] = useState("");
  const [isDeleting, setIsDeleting] = useState(false);
  const [isMaterialsFetch, setIsMaterialFetch] = useState(false);
  const { projectsSummarizedData } = useAppSelector(getProjectsState);
  const {
    // createdBy,
    // createdDate,
    // modifiedBy,
    // modifiedDate,
    // lastModifiedBy,
    // lastModifiedDate,
    successMessage,
    resError,
    reqError,
  } = useAppSelector(getInventoriesState);

  const navigation = useNavigate();
  const { projectId } = useParams();
  const dispatch = useAppDispatch();
  const locationPath = useLocation();
  const { locationsList } = useAppSelector(getLocationsState);

  useEffect(() => {
    if (projectId) {
      dispatch(getLocationslist(projectId));
    }
  }, [projectId, dispatch]);

  const locationsListOptions = useMemo(() => {
    return [
      {
        value: "",
        label: "Select Location",
      },
      ...(locationsList?.map((f) => ({
        value: f.id,
        label: f.name,
      })) || []),
    ];
  }, [locationsList]);

  const handleDeleteInventoryById = async () => {
    try {
      setIsDeleting(true);
      await dispatch(
        deleteInventoryById(projectId || selectedProjectId || null)
      ).unwrap();
      dispatch(resetState());
      navigation(routePaths.PRODUCTS);
    } catch (error) {
      console.error("Error deleting project:", error);
    } finally {
      setIsDeleting(false);
    }
  };

  const getDefaultValues = (data: ProductInventoryData | null) => {
    if (!data) {
      return {
        projectId: null,
        createdBy: "",
        createdDate: null,
        modifiedBy: "",
        modifiedDate: null,
        lastModifiedDate: null,
        inventories: initialInventoryMaterials,
      };
    } else {
      return {
        projectId: data.projectId || projectId,
        createdBy: data.createdBy,
        createdDate: data.createdDate,
        modifiedBy: data.modifiedBy,
        modifiedDate: data.modifiedDate,
        lastModifiedDate: data.lastModifiedDate,
        inventories: data?.inventories?.map((inventory: Inventory) => ({
          locationId: inventory.locationId,
          materials: inventory?.materials?.map(
            (material: InventoryMaterial) => ({
              materialId: material.materialId,
              name: material.name,
              costCode: material.costCode,
              quantity: material.quantity,
              isRefillable: material.isRefillable,
              subLocationId: material.subLocationId,
              unitOfMeasure: material.unitOfMeasure,
            })
          ),
        })),
      };
    }
  };

  const {
    control,
    handleSubmit,
    setValue,
    getValues,
    watch,
    reset,
    register,
    formState: { isSubmitting, errors },
  } = useForm<FormValues>({
    resolver: yupResolver(
      InventoryValidationSchema
    ) as unknown as Resolver<FormValues>,
    defaultValues: getDefaultValues(inventories),
    shouldUnregister: false,
  });

  const {
    fields: inventoryFields,
    append: appendInventory,
    remove: removeInventory,
    update: updateInventory,
  } = useFieldArray({
    control,
    name: "inventories",
  });

  const getSubLocationsListOptions = (inventoryIndex: number) => {
    const selectedLocationId = getValues(
      `inventories.${inventoryIndex}.locationId`
    );

    const selectedLocation = locationsList?.find(
      (location) => location.id === selectedLocationId
    );

    return [
      {
        value: "",
        label: "Select Sublocation",
      },
      ...(selectedLocation?.subLocations?.map((subLocation) => ({
        value: subLocation?.id,
        label: subLocation?.name,
      })) || []),
    ];
  };

  const memoizedProjectsOptions = useMemo(() => {
    return [
      allProjectsOptions,
      ...(projectsSummarizedData?.map((f) => ({
        value: f.id,
        label: f.name,
      })) || []),
    ];
  }, [projectsSummarizedData]);

  const selectedLocationIds =
    watch("inventories")?.map((inventory) => inventory?.locationId) || [];
  const getFilteredLocationOptions = (inventoryIndex: number) => {
    const currentLocationId = selectedLocationIds[inventoryIndex];

    return locationsListOptions
      ?.map((option) => ({
        ...option,
        disabled:
          option.value === "" ||
          (option.value !== currentLocationId &&
            selectedLocationIds.includes(option.value)),
      }))
      .filter(
        (option) =>
          option.value === currentLocationId ||
          !selectedLocationIds.includes(option.value)
      );
  };

  const handleLocationChange = async (
    inventoryIndex?: number,
    value?: string
  ) => {
    setSelectedLocation(value as string);
    try {
      setIsMaterialFetch(true);
      const res = await dispatch(
        getAllInventoryListByProjectIdOnlyInventoryMaterial({
          projectId: selectedProjectId || projectId,
          LocationId: value,
        })
      ).unwrap();

      setValue(
        `inventories[${inventoryIndex}].materials` as any,
        res?.inventories?.[0]?.materials ||
          initialInventoryMaterials?.[0]?.materials
      );
    } catch (err) {
      console.log("error", err);
    } finally {
      setIsMaterialFetch(false);
      dispatch(resetState());
    }
  };

  const handleProjectChange = async (value: string) => {
    setSelectedProjectId(value);
    try {
      reset();
      setIsMaterialFetch(true);
      const res = await dispatch(
        getAllInventoryListByProjectId({ projectId: value })
      ).unwrap();
      dispatch(getLocationslist(value));
      setValue("createdBy", res?.createdBy || "");
      setValue("createdDate", res?.createdDate || null);
      setValue("modifiedBy", res?.modifiedBy || "");
      setValue("modifiedDate", res?.modifiedDate || null);
      setValue("lastModifiedDate", res?.lastModifiedDate || null);
      setValue(
        `inventories`,
        res?.inventories.length ? res?.inventories : initialInventoryMaterials
      );
      setValue("projectId", value);
    } catch (err) {
      console.log("error", err);
    } finally {
      setIsMaterialFetch(false);
      dispatch(resetState());
    }
  };

  const handleSave = async (data: FormValues) => {
    if (
      (inventories?.inventories || []).length ||
      projectId ||
      getValues("projectId")
    ) {
      return await dispatch(editInventoryById(data)).unwrap();
    } else {
      return await dispatch(createInventory(data)).unwrap();
    }
  };

  const onSubmit = async (data: FormValues) => {
    try {
      if (actionType === "save") {
        const res = await handleSave(data);
        if (res?.isSuccess) {
          reset(
            getDefaultValues({
              createdBy: res?.createdBy || "",
              createdDate: res?.createdDate || null,
              modifiedBy: res?.modifiedBy || "",
              modifiedDate: res?.modifiedDate || null,
              inventories: res?.inventories || null,
              lastModifiedDate: res?.lastModifiedDate || null,
            })
          );
        }
      } else if (actionType === "saveAndClose") {
        const res = await handleSave(data);
        if (res?.isSuccess) {
          navigation(routePaths.PRODUCTS);
        }
      }
    } catch (error) {
      console.error("Error during form submission:", error);
    }
  };

  useEffect(() => {
    dispatch(resetState());
  }, []);

  // Bulk upload handling
  const [resetBulkUploadFile, setBulkUploadFile] = useState(0);

  async function updateMaterials(file: File, inventoryIndex: number) {
    const bulkUploadParser = new BulkUploaderParser<
      LabelSupportedInventoryMaterial[]
    >();
    const rows = await bulkUploadParser.readAndParseAsync(file, [
      "sublocation",
    ]);

    const isValid = await bulkUploadParser.validateMaterials<
      LabelSupportedInventoryMaterial[]
    >({
      rows,
      schema: {
        material: "alphanumericString",
        costCode: "alphanumericString",
        unitOfMeasurement: "alphanumericString",
        quantity: "number",
        refillable: "string",
        sublocation: "alphanumericString",
      },
      stringToBooleanKeys: ["refillable"],
      requiredKeys: ["material", "costCode", "unitOfMeasurement"],
    });

    setBulkUploadFile(Date.now());

    if (!isValid) {
      return;
    }

    rows.forEach((m) => {
      const sublocationId = getSubLocationsListOptions(inventoryIndex).find(
        (f) => f.label === `${m.sublocation}`
      )?.value;

      if (sublocationId) {
        m.subLocationId = sublocationId;
      }

      const isRefillableString = `${m.refillable}`?.toLowerCase();

      let isRefillableBoolean = false;
      if (isRefillableString === "yes" || isRefillableString === "true") {
        isRefillableBoolean = true;
      } else if (
        isRefillableString === "no" ||
        isRefillableString === "false"
      ) {
        isRefillableBoolean = false;
      }

      m.unitOfMeasure = m?.unitOfMeasurement;
      m.name = m.material;
      m.isRefillable = isRefillableBoolean;
    });

    reset((values) => {
      const valuesCopy = { ...values };
      const inventory =
        (valuesCopy.inventories || [])?.[inventoryIndex] || null;

      if (inventory) {
        let materials = [];
        const oldMaterials =
          inventory?.materials?.filter((f) => getLowerCasedMaterialName(f)) ||
          [];

        if (oldMaterials?.length) {
          materials = bulkUploadParser.mergeMaterials({
            oldMaterials,
            newMaterials: rows,
            keysToBeUpdated: ["quantity"],
          });
          inventory.materials = materials;
        } else {
          inventory.materials = rows;
        }
      }

      return valuesCopy;
    });
  }

  useEffect(() => {
    if (isLocationModalOpen?.open) {
      dispatch(getAllStorageTypes());
    } else {
      dispatch(getLocationslist(getValues("projectId") || ""));
    }
  }, [dispatch, isLocationModalOpen?.open]);

  const handleOpenLocationModal = (title: string, field: string) => {
    setIsLocationModalOpen({
      title: title,
      open: true,
      field: field,
    });
  };
  useEffect(() => {
    if (locationPath.pathname === routePaths.PRODUCTS_CREATE) {
      reset(getDefaultValues(null));
    }
  }, [locationPath.pathname]);

  return isMaterialsFetch ? (
    <CustomOverlayLoader />
  ) : (
    <>
      <LocationModal
        setLocationValue={setValue}
        projectId={getValues("projectId")}
        isLocationModalOpen={isLocationModalOpen}
        setIsLocationModalOpen={setIsLocationModalOpen}
      />
      <Form
        onFinish={handleSubmit(onSubmit)}
        layout="vertical"
        disabled={isFieldsCraftAuthorized()}
      >
        <CustomFormRow>
          <Col xs={12}>
            <Controller
              name="projectId"
              control={control}
              render={({ field, formState: { errors } }) => (
                <Form.Item
                  help={!field.value && errors?.projectId?.message}
                  validateStatus={
                    !field.value && errors?.projectId ? "error" : ""
                  }
                >
                  <CustomFormLabel text="Project" required />
                  <Select
                    className="mt-3"
                    {...field}
                    placeholder="Project"
                    options={memoizedProjectsOptions}
                    disabled={Boolean(projectId)}
                    onChange={(value) => {
                      field.onChange(value);
                      handleProjectChange(value);
                    }}
                    showSearch
                    filterOption={(input, option) =>
                      (option?.label || "")
                        .toLowerCase()
                        .includes(input.toLowerCase())
                    }
                  />
                </Form.Item>
              )}
            />
          </Col>
        </CustomFormRow>
        {inventoryFields?.map((inventory, inventoryIndex) => (
          <div key={inventory.id} style={{ marginBottom: 20, marginTop: 20 }}>
            <CustomFormRow>
              <Col xs={12} className="flex items-center">
                <Typography.Title
                  level={5}
                  className="!font-medium flex gap-3 items-center"
                >
                  <CustomIcon type="inventory-list" className="fill-white" />{" "}
                  {`Location ${inventoryIndex + 1} Inventory`}
                </Typography.Title>
              </Col>
              {!isFieldsCraftAuthorized() && (
                <Col xs={12} className="flex justify-end gap-4 items-center">
                  <BulkUploadButton
                    disabled={
                      !getValues(`inventories.${inventoryIndex}.locationId`)
                    }
                    updateMaterialsCallback={(file) =>
                      updateMaterials(file, inventoryIndex)
                    }
                    shouldReset={resetBulkUploadFile}
                  />

                  <DeleteIconButton
                    disabled={inventoryFields.length === 1}
                    handleDelete={() => {
                      removeInventory(inventoryIndex);
                    }}
                  />
                </Col>
              )}
            </CustomFormRow>
            <Controller
              name={`inventories.${inventoryIndex}.locationId`}
              control={control}
              render={({ field, formState: { errors } }) => (
                <Form.Item
                  help={
                    errors?.inventories?.[inventoryIndex]?.locationId
                      ?.message as string
                  }
                  validateStatus={
                    errors?.inventories?.[inventoryIndex]?.locationId
                      ? "error"
                      : ""
                  }
                >
                  <CustomFormLabel text="Location" required />
                  <Select
                    disabled={
                      selectedProjectId
                        ? false
                        : true || isFieldsCraftAuthorized()
                    }
                    className="mt-3"
                    {...field}
                    placeholder="Select Location"
                    options={getFilteredLocationOptions(inventoryIndex)}
                    onChange={(value) => {
                      field.onChange(value);
                      handleLocationChange(inventoryIndex, value);
                    }}
                    showSearch
                    filterOption={(input, option) =>
                      (option?.label || "")
                        .toLowerCase()
                        .includes(input.toLowerCase())
                    }
                    dropdownRender={(menu) => (
                      <>
                        {menu}
                        <Divider className="mt-2 mb-1" />
                        <Space className="p-1">
                          <Button
                            type="text"
                            icon={<PlusOutlined />}
                            onClick={() =>
                              handleOpenLocationModal(
                                "Add New Location",
                                `inventories.${inventoryIndex}.locationId`
                              )
                            }
                          >
                            Add New Location
                          </Button>
                        </Space>
                      </>
                    )}
                  />
                </Form.Item>
              )}
            />
            <ProductInventoryMaterials
              register={register}
              errors={errors}
              getValues={getValues}
              updateInventory={updateInventory}
              control={control}
              inventoryIndex={inventoryIndex}
              getSubLocationsListOptions={getSubLocationsListOptions}
              watch={watch}
              setValue={setValue}
            />
          </div>
        ))}

        {!isFieldsCraftAuthorized() && (
          <Button
            size="large"
            icon={<CustomIcon type="plus" />}
            onClick={() =>
              appendInventory({
                locationId: "",
                materials: [
                  {
                    name: "",
                    costCode: "",
                    quantity: 0,
                    isRefillable: false,
                    subLocationId: null,
                    unitOfMeasure: "",
                  },
                ],
              })
            }
          >
            Add Products to New Location
          </Button>
        )}
        {(reqError || resError || successMessage) && (
          <CustomAlert
            message={reqError || resError || successMessage || ""}
            type={successMessage ? "success" : "error"}
          />
        )}
        <div className="mt-10"></div>
        {isFieldsCraftAuthorized() ? (
          <Flex justify="flex-end" className="gap-4">
            <Button
              disabled={isSubmitting || isDeleting}
              type="default"
              onClick={handleBackToTable}
            >
              Back
            </Button>
          </Flex>
        ) : (
          <Flex justify="flex-end" className="gap-4">
            <Button
              disabled={isSubmitting || isDeleting}
              type="default"
              onClick={handleBackToTable}
            >
              Cancel
            </Button>
            {(Boolean(projectId) ||
              getValues("inventories")?.some(
                (inventory) => inventory.materials[0].materialId
              )) && (
              <Button
                loading={isDeleting}
                disabled={isSubmitting || isDeleting}
                type="default"
                onClick={handleDeleteInventoryById}
              >
                {isDeleting ? "Deleting.." : "Delete"}
              </Button>
            )}
            <Button
              loading={actionType === "save" && isSubmitting}
              disabled={isSubmitting || isDeleting}
              type="primary"
              htmlType="submit"
              onClick={() => setActionType("save")}
            >
              {actionType === "save" && isSubmitting ? "Saving.." : "Save"}
            </Button>

            <Button
              loading={actionType === "saveAndClose" && isSubmitting}
              disabled={isSubmitting || isDeleting}
              type="primary"
              htmlType="submit"
              onClick={() => setActionType("saveAndClose")}
            >
              {actionType === "saveAndClose" && isSubmitting
                ? "Saving and closing.."
                : "Save & Close"}
            </Button>
          </Flex>
        )}
        <div className="mt-5"></div>
        {getValues("inventories")?.some(
          (inventory) => inventory.materials[0].materialId
        ) && (
          <Flex justify="flex-end">
            <CreatedByUserBadge
              // userName={getValues("createdBy") as string}
              // date={getValues("createdDate") as Date}

              userName={
                getValues("modifiedBy")
                  ? getValues("modifiedBy")
                  : getValues("createdBy")
              }
              date={getValues("lastModifiedDate")}
              isModifiedBadge={getValues("modifiedBy") ? true : false}
            />
          </Flex>
        )}
      </Form>
    </>
  );
};

export default ProductInventoryForm;
