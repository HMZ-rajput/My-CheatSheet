import CustomIcon from "@/src/components/common/CustomIcon";
import useAuthorization from "@/src/hooks/useAuthorization";
import { Button } from "antd";
import React, { useCallback } from "react";
import { useFieldArray, UseFormSetValue, UseFormWatch } from "react-hook-form";
import InventoryMaterialList from "../../inventory/components/InventoryMaterialList";

const ProductInventoryMaterials = React.memo(
  ({
    control,
    inventoryIndex,
    getSubLocationsListOptions,
    setValue,
    getValues,
    updateInventory,
    register,
    errors,
  }: {
    updateInventory: any;
    control: any;
    inventoryIndex: number;
    setValue: UseFormSetValue<any>;
    watch: UseFormWatch<any>;
    getValues: any;
    register: any;
    errors: any;

    getSubLocationsListOptions: (
      inventoryIndex: number
    ) => { value: string; label: string }[];
  }) => {
    const { isFieldsCraftAuthorized } = useAuthorization();

    const {
      fields: materialFields,
      append: appendMaterial,
      remove: removeMaterial,
    } = useFieldArray({
      control,
      name: `inventories[${inventoryIndex}].materials`,
    });

    const removeMaterialAndErrors = (materialIndex: number) => {
      removeMaterial(materialIndex);
      updateInventory();
    };

    const handleAppend = useCallback(() => {
      appendMaterial({
        name: "",
        costCode: "",
        quantity: 0,
        isRefillable: false,
        subLocationId: null,
        unitOfMeasure: "",
      });
    }, [appendMaterial]);

    return (
      <div>
        <div className="materials-header-row flex w-full py-1.5 px-2 rounded-lg mb-4 bg-neutral-0">
          <div className="col col-xs-4">
            <span className="font-medium">Material</span>
          </div>
          <div className="col pr-4 col-xs-4">
            <div className="font-normal">Cost Code</div>
          </div>
          <div className="col pr-4 col-xs-3">
            <div className="font-normal">Quantity</div>
          </div>
          <div className="col pr-4 col-xs-4">
            <div className="font-normal">Unit of Measurement</div>
          </div>
          <div className="col pr-4 col-xs-2">
            <div className="font-normal">Refillable</div>
          </div>
          <div className="col pr-4 col-xs-6">
            <div className="font-normal">Sublocation</div>
          </div>
        </div>

        <InventoryMaterialList
          errors={errors}
          updateInventory={updateInventory}
          getValues={getValues}
          setValue={setValue}
          register={register}
          materialFields={materialFields}
          control={control}
          inventoryIndex={inventoryIndex}
          getSubLocationsListOptions={getSubLocationsListOptions}
          removeMaterialAndErrors={removeMaterialAndErrors}
        />

        {!isFieldsCraftAuthorized() && (
          <Button
            className="border-0 shadow-none text-primary font-medium mt-5"
            size="small"
            icon={<CustomIcon width={16} type="add-circle" />}
            onClick={handleAppend}
          >
            Add Material
          </Button>
        )}
        <div className="text-md float-end">{materialFields.length} Row(s)</div>
      </div>
    );
  }
);

export default ProductInventoryMaterials;
