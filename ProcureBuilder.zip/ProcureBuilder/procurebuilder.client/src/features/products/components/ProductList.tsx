import CustomTable, {
  defaultPageSizes,
} from "@/src/components/table/CustomTable";
import { useAppSelector } from "@/src/hooks/useAppSelector";
import {
  productSortingFilterOptions,
  productSortingOptions,
} from "@/src/utils/constants";
import SectionLayout from "@components/layout/SectionLayout";
import { Button, TableProps } from "antd";
import { useEffect, useMemo, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";

import { getAllProducts } from "@/src/apis/productApis";
import CustomTableFilters, {
  CustomFilterDataType,
  CustomFiltersType,
} from "@/src/components/table/CustomTableFilters";
import { useAppDispatch } from "@/src/hooks/useAppDispatch";
import { getProductState } from "@/src/store/slices/productsSlice";
import { getFirstValidNumber } from "@/src/utils/number-extensions";
import routePaths from "@/src/utils/routePaths";
import { Product } from "@/src/utils/types";
import { EyeOutlined } from "@ant-design/icons";
import { useReports } from "../../reports/contexts/ReportsProvider";
import useSyncFilters from "@/src/hooks/useSyncFilters";

type ProductListProps = {
  exportButtonEl?: React.ReactNode | null;
  setReportStats?: null | React.Dispatch<
    React.SetStateAction<{
      totalMaterials: number;
    }>
  >;
};

export default function ProductList({
  exportButtonEl = null,

  setReportStats = null,
}: ProductListProps) {
  const { filterValues } = useReports();

  const isInsideReports = useMemo(
    () => Boolean(exportButtonEl),
    [exportButtonEl]
  );
  const [searchTerm, setSearchTerm] = useState("");
  const [hasSearched, setHasSearched] = useState(false);
  const { searchParams } = useSyncFilters();
  const [previousSearchTerm, setPreviousSearchTerm] = useState(
    searchParams.get("searchTerm")
  );
  const [lastSearchTimestamp, setLastSearchTimestamp] = useState(0);

  useEffect(() => {
    setLastSearchTimestamp(Date.now());
  }, [previousSearchTerm]);

  const navigate = useNavigate();
  const dispatch = useAppDispatch();
  const {
    productsData,
    isLoading,
    totalCount,
    currentPage: projectsCurrentPage,
    pageSize: projectsPageSize,
  } = useAppSelector(getProductState);

  const [page, setPage] = useState<number>(projectsCurrentPage);
  const [pageSize, setPageSize] = useState(
    !isInsideReports && !defaultPageSizes.includes(projectsPageSize)
      ? 10
      : projectsPageSize
  );
  const isFirstCallComplete = useRef(false);
  // const [isFirstCall, setIsFirstCall] = useState(false);

  const [filters, setFilters] = useState<CustomFiltersType>({
    sortBy: {
      value: productSortingOptions?.value || "",
      options: productSortingFilterOptions,
      suffixIcon: "sort-desc",
      className: "!min-w-[218px]",
      dataType: CustomFilterDataType.NUM,
    },
  });

  const conditionalColumns: TableProps<Product>["columns"] = !isInsideReports
    ? [
        {
          title: "Projects",
          dataIndex: "projects",
          key: "projects",
          sorter: (a, b) => a.projects - b.projects,
        },
        {
          title: "Locations",
          dataIndex: "locations",
          key: "locations",
          sorter: (a, b) => a.locations - b.locations,
        },
      ]
    : [];
  const navigateToEditPage = (changeOrder: Product) => {
    const coPath = `${routePaths.PRODUCTS_DETAILS}/${changeOrder?.productName}`;

    if (isInsideReports) {
      navigate(coPath, {
        state: {
          previousPath: `${location.pathname}${location.search}`,
        },
      });
    } else {
      navigate(coPath);
    }
  };

  const columns: TableProps<Product>["columns"] = [
    {
      title: "Product",
      dataIndex: "productName",
      key: "productName",
      sorter: (a, b) => a.productName?.localeCompare(b.productName),
    },
    {
      title: "Cost Code",
      dataIndex: "costCode",
      key: "costCode",
      sorter: (a, b) => a.costCode?.localeCompare(b.costCode),
    },
    ...conditionalColumns,
    {
      title: "Quantity",
      dataIndex: "quantity",
      key: "quantity",
      sorter: (a, b) => a.quantity - b.quantity,
    },
    {
      title: "Unit of Measurement",
      dataIndex: "unitOfMeasure",
      key: "unitOfMeasure",
      sorter: (a, b) => a.unitOfMeasure?.localeCompare(b.unitOfMeasure),
    },
    {
      title: "",
      dataIndex: "",
      key: "",
      render: (_, record) =>
        !isInsideReports && (
          <Button
            shape="circle"
            className="hover:!fill-primary"
            icon={<EyeOutlined />}
            onClick={
              () => navigateToEditPage(record)
              // navigate(`${routePaths.PRODUCTS_DETAILS}/${record?.productName}`)
            }
          />
        ),
    },
  ];

  async function handleGetResults(pageNumber?: number) {
    const sortingFilter =
      filters.sortBy?.value !== productSortingOptions?.value
        ? (filters?.sortBy?.value as number)
        : undefined;

    const reportFilters = isInsideReports ? filterValues : {};

    const res = await dispatch(
      getAllProducts({
        isForReport: isInsideReports,
        pageNumber: pageNumber || page,
        pageSize,
        search: searchTerm || undefined,
        sortingFilter,
        projectId: reportFilters?.projectId || undefined,
        locationId: reportFilters?.locationId || undefined,
        materialType: getFirstValidNumber(
          reportFilters?.materialType,
          undefined
        ),
      })
    ).unwrap();

    if (typeof setReportStats === "function") {
      setReportStats({
        totalMaterials: res?.totalCount || 0,
      });
    }
  }

  function resetPaginationAndGetFirstPageResults() {
    if (isFirstCallComplete?.current === true) {
      if (filters) {
        setPage(1);
      }

      handleGetResults(1);
    } else {
      handleGetResults();
    }
  }

  useEffect(() => {
    if (!hasSearched) return;
    const timer = setTimeout(() => {
      if (searchTerm === "" && previousSearchTerm !== "") {
        resetPaginationAndGetFirstPageResults();
        setPreviousSearchTerm(searchTerm);
      }
    }, 500);

    return () => {
      clearTimeout(timer);
    };
  }, [searchTerm, hasSearched, previousSearchTerm]);

  const handleSearch = () => {
    if (searchTerm !== previousSearchTerm) {
      setHasSearched(true);
      resetPaginationAndGetFirstPageResults();
      setPreviousSearchTerm(searchTerm);
    }
  };

  useEffect(() => {
    resetPaginationAndGetFirstPageResults();
  }, [filters, filterValues]);

  useEffect(() => {
    if (
      !isFirstCallComplete?.current ||
      projectsCurrentPage !== page ||
      projectsPageSize !== pageSize
    ) {
      handleGetResults();
      if (!isFirstCallComplete?.current) {
        setTimeout(() => {
          isFirstCallComplete.current = true;
        }, 1000);
      }
    }
  }, [page, pageSize]);

  return (
    <>
      <SectionLayout isHidden={isInsideReports}>
        <CustomTable
          data={productsData || []}
          columns={columns || []}
          searchTerm={searchTerm}
          setSearchTerm={setSearchTerm}
          handleSearch={handleSearch}
          isLoading={isLoading}
          totalCount={totalCount}
          page={page}
          setPage={setPage}
          pageSize={pageSize}
          setPageSize={setPageSize}
          tableFilters={filters}
          reportFilterForParamsUseOnly={
            isInsideReports ? filterValues : undefined
          }
          setTableFilters={!isInsideReports ? setFilters : undefined}
          filterElements={
            !isInsideReports && (
              <CustomTableFilters filters={filters} setFilters={setFilters} />
            )
          }
          hasSearch={true}
          hasPagination={true}
          exportButtonEl={exportButtonEl}
          isInsideReports={isInsideReports}
          hasCursorPointer={isInsideReports}
          onRowClick={
            isInsideReports ? (co) => navigateToEditPage(co) : undefined
          }
          lastSearchTimestamp={lastSearchTimestamp}
        />
      </SectionLayout>
    </>
  );
}
