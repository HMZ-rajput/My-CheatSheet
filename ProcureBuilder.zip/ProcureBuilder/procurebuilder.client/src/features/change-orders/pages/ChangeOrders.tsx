import { useNavigate, useParams } from "react-router-dom";
import routePaths from "@/src/utils/routePaths";
import { Button } from "antd";
import SectionLayout from "@/src/components/layout/SectionLayout";
import CustomIcon from "@/src/components/common/CustomIcon";
import { getConsistentSpacing } from "@/src/utils/theme-helpers";
import PageLayout from "@/src/components/layout/PageLayout";
import ChangeOrderList from "../components/ChangeOrderList";
import ChangeOrderByProjectList from "../components/ChangeOrderbyProjectList";
import useAuthorization from "@/src/hooks/useAuthorization";

export default function ChangeOrderPage() {
  const navigate = useNavigate();
  const { projectId } = useParams();
  const { isFieldsCraftAuthorized } = useAuthorization();
  return (
    <>
      <PageLayout
        title={`Change Orders`}
        titleSibling={
          !isFieldsCraftAuthorized() && (
            <Button
              size="large"
              type="primary"
              icon={
                <CustomIcon
                  className="fill-white"
                  type="plus"
                  width={parseInt(getConsistentSpacing(3))}
                  height={parseInt(getConsistentSpacing(3))}
                />
              }
              onClick={() => navigate(routePaths.CHANGE_ORDERS_NEW)}
            >
              New Change Order
            </Button>
          )
        }
      >
        <SectionLayout>
          {projectId ? <ChangeOrderByProjectList /> : <ChangeOrderList />}
        </SectionLayout>
      </PageLayout>
    </>
  );
}
