import PageLayout from "@components/layout/PageLayout";
import { useLocation, useNavigate, useParams } from "react-router-dom";
import ChangeOrderDetailForm from "../components/ChangeOrderDetailsForm";
import routePaths from "@/src/utils/routePaths";
import { useEffect } from "react";
import { useAppDispatch } from "@/src/hooks/useAppDispatch";
import { getChangeOrderById } from "@/src/apis/changeOrderApis";
import { useAppSelector } from "@/src/hooks/useAppSelector";
import { getChangeOrderByIdState } from "@/src/store/slices/changeOrderSlice";
import useAuthorization from "@/src/hooks/useAuthorization";

export default function ChangeOrderDetailsPage() {
  const { changeOrderId } = useParams<{ changeOrderId?: string }>();
  const { isFieldsCraftAuthorized } = useAuthorization();
  const location = useLocation();
  const navigate = useNavigate();
  const dispatch = useAppDispatch();

  const catchChangeOrder = useAppSelector((state) =>
    getChangeOrderByIdState(state, changeOrderId || "")
  );

  useEffect(() => {
    if (catchChangeOrder) {
      return;
    }

    if (changeOrderId) {
      const fetchChangeOrderById = async () => {
        await dispatch(getChangeOrderById({ id: changeOrderId })).unwrap();
      };
      fetchChangeOrderById();
    }
  }, [changeOrderId, dispatch]);

  const handleCancelForm = () => {
    const previousPath = location?.state?.previousPath || "";
    if (previousPath) {
      navigate(previousPath);
    } else {
      navigate(routePaths.CHANGE_ORDERS);
    }
  };

  return (
    <PageLayout
      title={
        isFieldsCraftAuthorized()
          ? "Change Order Details"
          : `${catchChangeOrder ? "Edit" : "Create"} Change Order`
      }
    >
      <ChangeOrderDetailForm
        changeOrder={catchChangeOrder}
        handleCancelForm={handleCancelForm}
      />
    </PageLayout>
  );
}
