import { Button, Flex } from "antd";
import { useEffect, useState } from "react";
import { ChangeOrder } from "@/src/utils/types";
import { useAppDispatch } from "@/src/hooks/useAppDispatch";
import { useAppSelector } from "@/src/hooks/useAppSelector";
import CustomIcon from "@/src/components/common/CustomIcon";
import PageLayout from "@/src/components/layout/PageLayout";
import { getConsistentSpacing } from "@/src/utils/theme-helpers";
import ChangeOrderByProjectList from "./ChangeOrderbyProjectList";
import SectionLayout from "@/src/components/layout/SectionLayout";
import ChangeOrderInfoFormSection from "./ChangeOrderInfoFormSection";
import ChangeOrderImg from "@assets/images/change-order/changeOrder-orange.png";
import { getChangeOrderByIdState } from "@/src/store/slices/changeOrderSlice";
import {
  getChangeOrdersByProject,
  GetChangeOrdersByProjectArgs,
} from "@/src/apis/changeOrderApis";
import CustomOverlayLoader from "@/src/components/common/CustomOverlayloader";
import useAuthorization from "@/src/hooks/useAuthorization";

type ChangeOrderTabProps = {
  projectId: string | undefined;
};

export default function ChangeOrderTab({ projectId }: ChangeOrderTabProps) {
  const { isFieldsCraftAuthorized } = useAuthorization();
  const [displayForm, setDisplayForm] = useState(false);
  const [changeOrders, setChangeOrders] = useState<ChangeOrder[] | null>();
  const [changeOrderId, setChangeOrderId] = useState<string | null>();
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const dispatch = useAppDispatch();

  const fetchChangeOrders = async () => {
    try {
      const payload: GetChangeOrdersByProjectArgs = {
        projectId,
      } as GetChangeOrdersByProjectArgs;
      const response = await dispatch(
        getChangeOrdersByProject(payload)
      ).unwrap();
      setChangeOrders(response.changeOrders);
    } catch (error) {
      console.log("error", error);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchChangeOrders();
  }, [displayForm]);

  const changeOrderData = useAppSelector((state) =>
    getChangeOrderByIdState(state, changeOrderId || "")
  );

  const handleChangeFormState = (changeOrderId: string | null) => {
    setChangeOrderId(changeOrderId);
    setDisplayForm(true);
  };

  const NoChangeOrderSection = (
    <>
      <SectionLayout>
        <SectionLayout
          className="p-8 rounded-xl items-center max-h-64"
          borderStyle="dashed"
        >
          <img src={ChangeOrderImg} width="48" height="48" className="mb-5" />

          <h6 className="font-medium text-sm !mb-1">
            No Change Orders Added Yet
          </h6>

          <p className="font-normal text-center text-xs mb-5 text-neutral-7">
            You currently have no change orders for this project. Please create
            a <br /> change order to update project quantities and totals.
          </p>

          {!isFieldsCraftAuthorized() && (
            <Flex className="gap-5">
              <Button
                size="large"
                className="hover:!fill-primary"
                icon={<CustomIcon type="plus" />}
                onClick={() => {
                  setDisplayForm(true);
                  setChangeOrderId(null);
                }}
              >
                New Change Order
              </Button>
            </Flex>
          )}
        </SectionLayout>
      </SectionLayout>
    </>
  );

  const ChangeOrderListView = (
    <>
      <PageLayout
        title={`Change Orders`}
        titleSibling={
          !isFieldsCraftAuthorized() && (
            <>
              <Button
                size="large"
                type="primary"
                icon={
                  <CustomIcon
                    className="fill-white"
                    type="plus"
                    width={parseInt(getConsistentSpacing(3))}
                    height={parseInt(getConsistentSpacing(3))}
                  />
                }
                onClick={() => setDisplayForm(true)}
              >
                New Change Order
              </Button>
            </>
          )
        }
      >
        <SectionLayout>
          <ChangeOrderByProjectList
            fromTab={true}
            handleChangeFormState={handleChangeFormState}
          />
        </SectionLayout>
      </PageLayout>
    </>
  );

  if (isLoading) {
    return <CustomOverlayLoader />;
  }

  return (
    <>
      {changeOrders?.length && !displayForm ? (
        ChangeOrderListView
      ) : displayForm ? (
        <ChangeOrderInfoFormSection
          handleCancelForm={() => {
            setDisplayForm(false);
            setChangeOrderId(null);
          }}
          changeOrder={changeOrderId ? changeOrderData : null}
        />
      ) : (
        NoChangeOrderSection
      )}
    </>
  );
}
