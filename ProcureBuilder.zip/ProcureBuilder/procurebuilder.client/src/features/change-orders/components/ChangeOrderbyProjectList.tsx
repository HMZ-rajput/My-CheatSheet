import {
  getApprovedChangeOrdersByProject,
  getChangeOrdersByProject,
} from "@/src/apis/changeOrderApis";
import OrderStatus from "@/src/components/common/OrderStatus";
import { useAppDispatch } from "@/src/hooks/useAppDispatch";
import useAuthorization from "@/src/hooks/useAuthorization";
import { dateFormat } from "@/src/utils/constants";
import { getOrderStatus } from "@/src/utils/helper";
import CustomIcon from "@components/common/CustomIcon";
import { useAppSelector } from "@hooks/useAppSelector";
import { getChangeOrderState } from "@store/slices/changeOrderSlice";
import { getConsistentSpacing } from "@utils/theme-helpers";
import { ChangeOrder } from "@utils/types";
import { Button, Table, TableProps, Typography } from "antd";
import { Key, TableRowSelection } from "antd/es/table/interface";
import dayjs from "dayjs";
import { useEffect, useMemo, useState } from "react";
import { useParams } from "react-router-dom";
import { EyeOutlined } from "@ant-design/icons";
const { Text } = Typography;

type ChangeOrderByProjectListProps = {
  selectedRowId?: Key;
  hasPagination?: boolean;
  hasRowSelection?: boolean;
  fromTab?: boolean;
  hasCursorPointer?: boolean;
  setSelectedRowId?: React.Dispatch<React.SetStateAction<Key>>;
  disabledChangeOrderIds?: string[];
  handleChangeFormState?: (changeOrderId: string | null) => void;
};

export default function ChangeOrderByProjectList({
  selectedRowId,
  fromTab,
  hasRowSelection,
  disabledChangeOrderIds = [],
  setSelectedRowId,
  handleChangeFormState,
  ...props
}: ChangeOrderByProjectListProps) {
  const {
    changeOrderData,
    totalCount,
    currentPage: changeOrderListCurrentPage,
    pageSize: changeOrderListPageSize,
  } = useAppSelector(getChangeOrderState);
  const { isFieldsCraftAuthorized } = useAuthorization();
  const dispatch = useAppDispatch();
  const { projectId } = useParams();
  const [page, setPage] = useState<number>(changeOrderListCurrentPage || 1);
  const [pageSize, setPageSize] = useState<number>(
    changeOrderListPageSize || 10
  );

  const filteredData = useMemo(() => {
    const changeOrderDataArray = (changeOrderData || []).slice();
    return changeOrderDataArray;
  }, [changeOrderData]);

  function handleSetSelectedRowId(id: Key) {
    if (setSelectedRowId && !disabledChangeOrderIds.includes(id as string)) {
      setSelectedRowId(id);
    }
  }

  const rowSelection: TableRowSelection<ChangeOrder> = {
    type: "radio",
    selectedRowKeys: [selectedRowId || ""],
    onChange: (selectedRowKeys: Key[]) => {
      handleSetSelectedRowId(selectedRowKeys[0]);
      return selectedRowKeys;
    },
    getCheckboxProps: (record) => ({
      disabled: disabledChangeOrderIds.includes(record.id || ""),
    }),
  };

  const columns: TableProps<ChangeOrder>["columns"] = [
    {
      title: "Change Order Number",
      dataIndex: "changeOrderNumber",
      key: "changeOrderNumber",
      sorter: (a, b) => a.changeOrderNumber?.localeCompare(b.changeOrderNumber),
      render: (_, changeOrder) => (
        <Text
          style={{
            fontSize: getConsistentSpacing(1.75),
            fontWeight: 500,
            margin: 0,
          }}
        >
          {changeOrder?.changeOrderNumber}
        </Text>
      ),
    },
    {
      title: "Title",
      dataIndex: "title",
      key: "title",
      sorter: (a, b) => a.title?.localeCompare(b.title),
      render: (_, changeOrder) => (
        <Text style={{ fontSize: getConsistentSpacing(1.75), margin: 0 }}>
          {changeOrder?.title}
        </Text>
      ),
    },
    {
      title: "Approval Deadline",
      dataIndex: "approveDeadline",
      key: "approveDeadline",
      sorter: (a, b) =>
        dayjs(a.approvalDeadline).unix() - dayjs(b.approvalDeadline).unix(),
      render: (_, changeOrder) => (
        <Text style={{ fontSize: getConsistentSpacing(1.75), margin: 0 }}>
          {dayjs(changeOrder?.approvalDeadline).format(dateFormat)}
        </Text>
      ),
    },
    {
      title: "Status",
      dataIndex: "status",
      key: "status",
      sorter: (a, b) => (a.status || 0) - (b.status || 0),
      render: (_, changeOrder) => {
        const { iconType, badgeType } = getOrderStatus(changeOrder?.status);
        return (
          <Text style={{ fontSize: getConsistentSpacing(1.75), margin: 0 }}>
            <OrderStatus badgeIconType={iconType} badgeType={badgeType} />
          </Text>
        );
      },
    },
    {
      title: "Subtotal",
      dataIndex: "subtotal",
      key: "subtotal",
      sorter: (a, b) => (a.subTotal || 0) - (b.subTotal || 0),
      render: (_, changeOrder) => (
        <Text style={{ fontSize: getConsistentSpacing(1.75), margin: 0 }}>
          {`$${changeOrder?.subTotal?.toLocaleString()}`}
        </Text>
      ),
    },
    {
      title: "Date Created",
      dataIndex: "dateCreated",
      key: "dateCreated",
      sorter: (a, b) =>
        dayjs(a.createdDate).unix() - dayjs(b.createdDate).unix(),
      render: (_, changeOrder) => (
        <Text style={{ fontSize: getConsistentSpacing(1.75), margin: 0 }}>
          {dayjs(changeOrder?.createdDate).format(dateFormat)}
        </Text>
      ),
    },

    {
      title: "",
      dataIndex: "edit",
      key: "edit",
      render: (_, changeOrder) => (
        <>
          {!hasRowSelection && (
            <Button
              shape="circle"
              className="hover:!fill-primary"
              icon={
                isFieldsCraftAuthorized() ? (
                  <EyeOutlined />
                ) : (
                  <CustomIcon type="edit" />
                )
              }
              onClick={() => {
                if (handleChangeFormState) {
                  handleChangeFormState(changeOrder?.id);
                }
              }}
            />
          )}
        </>
      ),
    },
  ];

  useEffect(() => {
    if (fromTab) {
      return;
    }
    const fetchChangeOrders = () => {
      if (projectId) {
        if (hasRowSelection && page && pageSize) {
          dispatch(getApprovedChangeOrdersByProject({ projectId }));
        } else if (page && pageSize) {
          dispatch(getChangeOrdersByProject({ projectId }));
        }
      }
    };

    fetchChangeOrders();
  }, [page, pageSize, projectId, hasRowSelection, dispatch]);

  return (
    <>
      <Table
        rowClassName={(record) =>
          disabledChangeOrderIds.includes(record.id || "")
            ? "opacity-50 cursor-not-allowed"
            : ""
        }
        // loading={{ spinning: isLoading, indicator: <Loader /> }}
        rowSelection={hasRowSelection ? rowSelection : undefined}
        onRow={
          props.hasCursorPointer
            ? (record) => ({
                onClick: () => handleSetSelectedRowId(record.id),
                style: { cursor: "pointer" },
              })
            : undefined
        }
        style={{ width: "100%" }}
        columns={columns}
        dataSource={filteredData || []}
        rowKey="id"
        pagination={
          props.hasPagination
            ? {
                position: ["bottomRight"],
                current: page,
                pageSize: pageSize,
                pageSizeOptions: ["10", "25", "50"],
                showSizeChanger: true,
                total: totalCount,
                showTotal: (total) => "Total: " + total,
                onChange: (page, pageSize) => {
                  setPageSize(pageSize);
                  setPage(page);
                },
              }
            : false
        }
      />
    </>
  );
}
