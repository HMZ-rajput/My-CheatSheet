import {
  createChangeOrder,
  deleteChangeOrderById,
  editChangeOrderById,
} from "@/src/apis/changeOrderApis";
import { getSummarizedProjectsList } from "@/src/apis/projectApis";
import { getAllProjectTypes } from "@/src/apis/projectTypeApis";
import CreatedByUserBadge from "@/src/components/common/CreatedByUserBadge";
import CustomAlert from "@/src/components/common/CustomAlert";
import CustomFileUploadRHF from "@/src/components/common/CustomFileUploadRHF";
import CustomFormLabel from "@/src/components/common/CustomFormLabel";
import CustomIcon from "@/src/components/common/CustomIcon";
import OrderStatus from "@/src/components/common/OrderStatus";
// import CustomFormButtons from "@/src/components/form/CustomFormButtons";
import CustomFormRow from "@/src/components/form/CustomFormRow";
import AddMaterialOfChangeOrder from "@/src/components/materials/AddMaterialsOfChangeOrder";
import { changeOrderInitialMaterials } from "@/src/data/intialsValues";
import { ChangeOrderDetailsValidationSchema } from "@/src/data/validationsSchema";
import { getLowerCasedMaterialName } from "@/src/external-modules/bulk-upload/bulk-upload-utils";
import BulkUploadButton from "@/src/external-modules/bulk-upload/BulkUploadButton";
import BulkUploaderParser from "@/src/external-modules/bulk-upload/BulkUploadParser";
import useAuthorization from "@/src/hooks/useAuthorization";
import {
  getChangeOrderState,
  resetState,
} from "@/src/store/slices/changeOrderSlice";
import { getProjectsState } from "@/src/store/slices/projectsSlice";
import { getTypesState } from "@/src/store/slices/typesSlice";
import { ActionTypeEnum, ChangeOrderStatusEnum } from "@/src/utils/enums";
import { getOrderStatus } from "@/src/utils/helper";
import { formatDecimals } from "@/src/utils/number-extensions";
import routePaths from "@/src/utils/routePaths";
import {
  ActionTypeState,
  Attachment,
  ChangeOrder,
  LabelSupportedMaterialType,
  Material,
} from "@/src/utils/types";
import SectionLayout from "@components/layout/SectionLayout";
import { yupResolver } from "@hookform/resolvers/yup";
import { useAppDispatch } from "@hooks/useAppDispatch";
import { useAppSelector } from "@hooks/useAppSelector";
import { getProjectManagersState } from "@store/slices/projectManagersSlice";
import { dateFormat } from "@utils/constants";
import { getConsistentSpacing } from "@utils/theme-helpers";
import {
  Button,
  Col,
  DatePicker,
  Divider,
  Flex,
  Form,
  Input,
  Select,
  Typography,
} from "antd";
import dayjs from "dayjs";
import { useEffect, useMemo, useState } from "react";
import { Controller, Resolver, useForm } from "react-hook-form";
import { useNavigate } from "react-router-dom";

type ChangeOrderFormProps = {
  changeOrder?: ChangeOrder | null;
  handleCancelForm: () => void;
};

export default function ChangeOrderDetailForm({
  changeOrder,
  handleCancelForm,
}: ChangeOrderFormProps) {
  type FieldType = ChangeOrder;

  const dispatch = useAppDispatch();
  const navigate = useNavigate();
  const { isFieldsCraftAuthorized } = useAuthorization();
  const [isDeleting, setIsDeleting] = useState(false);
  const [shouldDisable, setShouldDisable] = useState(false);
  const [validationError, setValidationError] = useState("");
  const [selectedProjectId, setSelectedProjectId] = useState<
    string | undefined
  >(changeOrder?.projectId ?? undefined);
  const { successMessage, resError, reqError } =
    useAppSelector(getChangeOrderState);

  const [actionType, setActionType] = useState<ActionTypeState>({
    delete: ActionTypeEnum.NEUTRAL,
    rejectAll: ActionTypeEnum.NEUTRAL,
    approve: ActionTypeEnum.NEUTRAL,
    save: ActionTypeEnum.NEUTRAL,
    cancel: ActionTypeEnum.NEUTRAL,
  });

  const { managersData: projectManagersData } = useAppSelector(
    getProjectManagersState
  );
  const memoizedProjectManagersOptions = useMemo(() => {
    return (
      projectManagersData?.map((pm) => ({
        value: pm?.id,
        label: pm?.fullName,
      })) || []
    );
  }, [projectManagersData]);

  const { typesData: typesData } = useAppSelector(getTypesState);
  const memoizedProjectTypesOptions = useMemo(() => {
    return [
      {
        value: "",
        label: "Select Project Type",
      },
      ...(typesData?.map((pt) => ({
        value: pt?.id,
        label: pt?.name,
      })) || []),
    ];
  }, [typesData]);

  useEffect(() => {
    dispatch(getSummarizedProjectsList());
    dispatch(getAllProjectTypes());
  }, [dispatch]);

  const { projectsSummarizedData } = useAppSelector(getProjectsState);
  const memoizedProjectsOptions = useMemo(() => {
    return [
      {
        value: "",
        label: "Select Project",
      },
      ...(projectsSummarizedData?.map((f) => ({
        value: f?.id,
        label: f?.name,
      })) || []),
    ];
  }, [projectsSummarizedData]);

  const formattedFiles = changeOrder?.attachments?.map((v) => ({
    ...v,
    uid: v?.id,
    name: v.fileName,
  }));

  const getDefaultValues = (changeOrder: ChangeOrder | null) => {
    return {
      id: changeOrder?.id || "",
      title: changeOrder?.title || "",
      attachments: formattedFiles || [],
      deleteAttachmentIds: [],
      changeOrderNumber: changeOrder?.changeOrderNumber || "",
      approvalDeadline: changeOrder?.approvalDeadline
        ? dayjs(changeOrder?.approvalDeadline)
        : "",
      projectId: changeOrder?.projectId || null,
      projectTypeId: changeOrder?.projectTypeId || "",
      userId: changeOrder?.userId || null,
      notes: changeOrder?.notes || "",
      materials:
        changeOrder?.materials?.map((material) => ({
          id: material.id,
          name: material.name,
          costCode: material.costCode,
          quantity: material.quantity,
          unitOfMeasure: material.unitOfMeasure,
          unitRate: material.unitRate,
          totalBudget: material.totalBudget,
        })) || changeOrderInitialMaterials,
      createdBy: changeOrder?.createdBy || "",
      lastModifiedBy: changeOrder?.lastModifiedBy || "",
      lastModifiedDate: changeOrder?.lastModifiedDate || null,
      modifiedDate: changeOrder?.modifiedDate || null,
      subTotal: changeOrder?.subTotal || 0,
      status: changeOrder?.status || 0,
      otherCosts: changeOrder?.otherCosts || 0,
    };
  };

  const {
    reset,
    control,
    handleSubmit,
    setValue,
    getValues,
    register,
    formState: { errors, isSubmitting },
  } = useForm<FieldType>({
    resolver: yupResolver(
      ChangeOrderDetailsValidationSchema
    ) as unknown as Resolver<FieldType>,
    defaultValues: getDefaultValues(changeOrder ? changeOrder : null),
    shouldUnregister: false,
  });

  const handleSave = async (values: FieldType) => {
    setValidationError("");
    const formData = new FormData();
    formData.append("title", values.title);
    formData.append("otherCosts", String(values.otherCosts || 0));
    formData.append("changeOrderNumber", values.changeOrderNumber);
    formData.append("approvalDeadline", values.approvalDeadline as string);
    formData.append("projectId", values.projectId as string);
    formData.append("projectTypeId", values.projectTypeId as string);
    values.userId && formData.append("userId", values.userId as string);
    formData.append("notes", values.notes);
    formData.append("subTotal", String(values.subTotal));
    formData.append("status", String(values.status || 0));

    values?.materials?.forEach((material, index) => {
      Object.entries(material).forEach(([key, value]) => {
        formData.append(`materials[${index}][${key}]`, String(value));
      });
    });

    if (Array.isArray(values.attachments)) {
      values?.attachments?.forEach((file: Attachment) => {
        console.log("file.originFileObj", file.originFileObj);
        if (file?.originFileObj) {
          formData.append("attachments", file.originFileObj);
        }
      });
    }

    if (Array.isArray(values.deleteAttachmentIds)) {
      const filteredDeleteDocumentIds = values?.deleteAttachmentIds?.filter(
        (id: string) => !id?.startsWith("rc-upload-")
      );
      filteredDeleteDocumentIds?.forEach((id) => {
        formData.append("deleteAttachmentIds", id);
      });
    }

    try {
      if (getValues("id")) {
        return await dispatch(
          editChangeOrderById({
            payload: formData,
            changeOrderId: changeOrder?.id,
            projectId: selectedProjectId,
          })
        ).unwrap();
      } else if (selectedProjectId) {
        return await dispatch(
          createChangeOrder({
            payload: formData,
            projectId: selectedProjectId,
          })
        ).unwrap();
      }
    } catch (error) {
      console.error("Error submitting form:", error);
    }
  };

  const onSubmit = async (values: FieldType, actionType: ActionTypeEnum) => {
    try {
      if (actionType === ActionTypeEnum.SAVE) {
        const response = await handleSave(values);
        if (response?.isSuccess && response?.changeOrder) {
          setTimeout(() => {
            navigate(
              `${routePaths.CHANGE_ORDER_EDIT_BY_ID}/${response.changeOrder.project?.id}/${response.changeOrder.id}`
            );
            reset(getDefaultValues(response?.changeOrder));
          }, 1000);
        }
      } else if (actionType === ActionTypeEnum.APPROVE) {
        const response = await handleSave({
          ...values,
          status: ChangeOrderStatusEnum.Approved,
        });

        if (response?.isSuccess && response?.changeOrder) {
          reset(getDefaultValues(response?.changeOrder));
          navigate(
            `${routePaths.CHANGE_ORDER_EDIT_BY_ID}/${response.changeOrder.project?.id}/${response.changeOrder.id}`
          );

          setShouldDisable(true);
        }
      } else if (actionType === ActionTypeEnum.REJECT_ALL) {
        const response = await handleSave({
          ...values,
          status: ChangeOrderStatusEnum.Rejected,
        });

        if (response?.isSuccess && response?.changeOrder) {
          reset(getDefaultValues(response?.changeOrder));
          navigate(
            `${routePaths.CHANGE_ORDER_EDIT_BY_ID}/${response.changeOrder.project?.id}/${response.changeOrder.id}`
          );

          setShouldDisable(true);
        }
      }
    } catch (error) {
      console.error(error);
    }
  };

  const { iconType, badgeType } = getOrderStatus(getValues("status") ?? 0);

  type DeleteChangeOrderFunctionArgs = {
    projectId: string | undefined;
    changeOrderId: string | undefined;
  };

  async function handleDeleteChangeOrderById({
    projectId,
    changeOrderId,
  }: DeleteChangeOrderFunctionArgs) {
    if (changeOrderId) {
      try {
        setIsDeleting(true);
        const res = await dispatch(
          deleteChangeOrderById({
            changeOrderId: changeOrderId,
            projectId: projectId,
            errors: [],
            isSuccess: true,
          })
        ).unwrap();
        if (res.isSuccess) {
          handleCancelForm();
        }
      } catch (error) {
        console.error("Error Deleting Change Order:", error);
      } finally {
        setIsDeleting(false);
      }
    }
  }

  useEffect(() => {
    if (selectedProjectId) {
      const selectedProject = projectsSummarizedData?.find(
        (project) => project?.id === selectedProjectId
      );

      if (selectedProject?.projectTypeId) {
        // @ts-ignore
        setValue("projectTypeId", selectedProject?.projectTypeId || "");
      } else {
        setValue("projectTypeId", null);
      }
    } else {
      setValue("projectTypeId", null);
    }
  }, [selectedProjectId, projectsSummarizedData, dispatch, setValue]);

  useEffect(() => {
    if (!changeOrder) return;

    if (changeOrder?.projectId) {
      setSelectedProjectId(changeOrder?.projectId);
      setShouldDisable(changeOrder?.status !== ChangeOrderStatusEnum.Pending);
    }

    const changeOrderValues = getDefaultValues(changeOrder);
    reset(changeOrderValues);
  }, [changeOrder, reset]);

  useEffect(() => {
    dispatch(resetState());
  }, []);

  // Bulk upload handling
  const [resetBulkUploadFile, setBulkUploadFile] = useState(0);

  async function updateMaterials(file: File) {
    const bulkUploadParser = new BulkUploaderParser<
      LabelSupportedMaterialType[]
    >();
    const rows = await bulkUploadParser.readAndParseAsync(file);

    const isValid = await bulkUploadParser.validateMaterials<
      LabelSupportedMaterialType[]
    >({
      rows,
      schema: {
        material: "alphanumericString",
        costCode: "alphanumericString",
        quantity: "number",
        unitOfMeasurement: "alphanumericString",
        unitRate: "number",
        totalBudget: "alphanumericString",
      },
      requiredKeys: ["material", "costCode", "unitOfMeasurement", "unitRate"],
    });

    setBulkUploadFile(Date.now());

    if (!isValid) {
      return;
    }

    let subTotal = 0;

    rows.forEach((m) => {
      subTotal += m.quantity * m.unitRate;
      m.name = m.material;
      m.unitOfMeasure = m.unitOfMeasurement;
      m.totalBudget = formatDecimals(calculateMaterialTotal(m)) || 0;
    });

    reset((values) => {
      let materials = [];
      const oldMaterials =
        values?.materials?.filter((f) => getLowerCasedMaterialName(f)) || [];

      if (oldMaterials?.length) {
        materials = bulkUploadParser.mergeMaterials({
          oldMaterials,
          newMaterials: rows,
          keysToBeUpdated: ["quantity", "unitRate", "totalBudget"],
        });
      } else {
        materials = rows;
      }

      return { ...values, materials, subTotal };
    });
  }

  const calculateMaterialTotal = (material: Material) => {
    // Created the below variables for better debugging - Ustad Inshal, 02:46 PM, October 17th, 2024.
    const qty = Number(material.quantity || 0);
    const rate = Number(material.unitRate || 0);
    const total = qty * rate;

    return total;
  };

  const updateSubTotal = () => {
    const materials = getValues("materials") || [];
    const subTotal = materials.reduce(
      (sum, material) => sum + calculateMaterialTotal(material),
      0
    );

    const otherCosts = getValues("otherCosts") || 0;

    // @ts-ignore -> USTAD INSHAL on October 15, 2024
    setValue("subTotal", formatDecimals(subTotal + otherCosts));
  };

  const handleUpdateTotals = () => {
    const materials = getValues("materials") || [];
    materials.forEach((material, index) => {
      const total = calculateMaterialTotal(material);
      setValue(`materials.${index}.totalBudget`, formatDecimals(total));
    });

    updateSubTotal();
    const subTotal = getValues("subTotal") || 0;
    const tax = getValues("tax") || 0;
    setValue("total", formatDecimals(subTotal + tax));
  };

  // const handleCalculateTax = (value: number) => {
  //   const taxPercentage = Number(value || 0);
  //   setValue("taxPercentage", taxPercentage);
  //   const subTotal = getValues("subTotal") || 0;
  //   const tax = (subTotal * taxPercentage) / 100;
  //   setValue("tax", formatDecimals(tax));

  //   const total = subTotal + tax;
  //   setValue("total", formatDecimals(total));
  // };

  // There is a pending case:
  // If Approve button is clicked, before the call is made, the Status of the Form is set to Approved.
  // Somehow if the call fails, and it should revert back to pending, it will not.
  // This case is not handled by me (Abdul Hafeez)
  // Approved by Ustad Inshal on Friday, October 11, 2024.

  return (
    <>
      <SectionLayout>
        <Form
          disabled={
            isFieldsCraftAuthorized() ||
            (shouldDisable &&
              (getValues("status") === ChangeOrderStatusEnum.Approved ||
                getValues("status") ===
                  ChangeOrderStatusEnum.AddedToBidMaterial ||
                getValues("status") === ChangeOrderStatusEnum.Rejected))
          }
          onFinish={handleSubmit((data) => onSubmit(data, ActionTypeEnum.SAVE))}
          layout="vertical"
          autoComplete="off"
        >
          <CustomFormRow>
            <Col xs={24} className="mb-1">
              <Flex justify="space-between" align="center">
                <Typography.Title level={5}>
                  Change Order Information
                </Typography.Title>
                <OrderStatus badgeIconType={iconType} badgeType={badgeType} />
              </Flex>
            </Col>

            {/* Title */}
            <Col xs={12}>
              <Controller
                control={control}
                name="title"
                render={({ field }) => (
                  <Form.Item<FieldType>
                    label={<CustomFormLabel text="Title" required={true} />}
                    labelAlign="right"
                    initialValue={field.value}
                    validateStatus={errors.title ? "error" : ""}
                    help={errors.title?.message}
                  >
                    <Input
                      ref={register(`title`).ref}
                      value={field.value}
                      onChange={(event) => field.onChange(event?.target?.value)}
                      size="large"
                      placeholder="Change Order Title"
                    />
                  </Form.Item>
                )}
              />
            </Col>

            {/* Change Order Number */}
            <Col xs={12}>
              <Controller
                control={control}
                name="changeOrderNumber"
                render={({ field }) => (
                  <Form.Item<FieldType>
                    label={
                      <CustomFormLabel
                        text="Change Order Number"
                        required={true}
                      />
                    }
                    labelAlign="right"
                    initialValue={field.value}
                    validateStatus={errors.changeOrderNumber ? "error" : ""}
                    help={errors.changeOrderNumber?.message}
                  >
                    <Input
                      ref={register(`changeOrderNumber`).ref}
                      value={field.value}
                      onChange={(event) => field.onChange(event?.target?.value)}
                      disabled={Boolean(changeOrder?.id)}
                      size="large"
                      placeholder="Change Order Number"
                    />
                  </Form.Item>
                )}
              />
            </Col>

            {/* Project* */}
            <Col xs={12}>
              <Controller
                control={control}
                name="projectId"
                render={({ field }) => (
                  <Form.Item<FieldType>
                    label={<CustomFormLabel text="Project" required={true} />}
                    labelAlign="right"
                    initialValue={field.value}
                    validateStatus={errors.projectId ? "error" : ""}
                    help={errors.projectId?.message}
                  >
                    <Select
                      ref={register(`projectId`).ref}
                      value={field.value}
                      onChange={(value) => {
                        field.onChange(value);
                        setSelectedProjectId(value);
                      }}
                      showSearch
                      size="large"
                      placeholder={"Select Project"}
                      style={{ width: "100%" }}
                      options={memoizedProjectsOptions}
                      disabled={Boolean(changeOrder?.id)}
                      filterOption={(input, option) =>
                        (option?.label || "")
                          .toLowerCase()
                          .includes(input.toLowerCase())
                      }
                    />
                  </Form.Item>
                )}
              />
            </Col>

            {/* Project Type */}
            <Col xs={12}>
              <Controller
                control={control}
                name="projectTypeId"
                render={({ field }) => (
                  <Form.Item<FieldType>
                    label={<CustomFormLabel text="Project Type" />}
                    labelAlign="right"
                    initialValue={field.value}
                  >
                    <Select
                      value={field.value}
                      onChange={(value) => {
                        field.onChange(value);
                      }}
                      size="large"
                      disabled
                      placeholder="Select Project Type"
                      options={memoizedProjectTypesOptions}
                      filterOption={(input, option) =>
                        (option?.label || "")
                          .toLowerCase()
                          .includes(input.toLowerCase())
                      }
                    />
                  </Form.Item>
                )}
              />
            </Col>

            {/* Approval Deadline */}
            <Col xs={12}>
              <Controller
                control={control}
                name="approvalDeadline"
                render={({ field }) => (
                  <Form.Item<FieldType>
                    label={<CustomFormLabel text="Approval Deadline" />}
                    labelAlign="right"
                    initialValue={field.value}
                  >
                    <DatePicker
                      value={
                        dayjs(field.value).isValid() ? dayjs(field.value) : null
                      }
                      onChange={(date) => {
                        field.onChange(dayjs(date).locale("en").format());
                      }}
                      size="large"
                      style={{ width: "100%" }}
                      placeholder="MM/DD/YYYY"
                      format={dateFormat}
                    />
                  </Form.Item>
                )}
              />
            </Col>

            {/* Assign to */}
            <Col xs={12}>
              <Controller
                control={control}
                name="userId"
                render={({ field }) => (
                  <Form.Item<FieldType>
                    label={<CustomFormLabel text="Assign to" />}
                    labelAlign="right"
                    initialValue={field.value}
                  >
                    <Select
                      value={field.value}
                      onChange={(value) => {
                        field.onChange(value);
                      }}
                      size="large"
                      placeholder="Select Project Manager"
                      options={memoizedProjectManagersOptions}
                      showSearch
                      filterOption={(input, option) =>
                        (option?.label || "")
                          .toLowerCase()
                          .includes(input.toLowerCase())
                      }
                    />
                  </Form.Item>
                )}
              />
            </Col>

            {/* Notes */}
            <Col xs={12}>
              <Controller
                control={control}
                name="notes"
                render={({ field }) => (
                  <Form.Item<FieldType>
                    label={
                      <CustomFormLabel text="Notes (For Internal Users)" />
                    }
                    labelAlign="right"
                    initialValue={field.value}
                  >
                    <Input.TextArea
                      value={field.value}
                      onChange={(event) => field.onChange(event?.target?.value)}
                      style={{ minHeight: getConsistentSpacing(20) }}
                      size="large"
                      placeholder="Write your notes here..."
                    />
                  </Form.Item>
                )}
              />
            </Col>
          </CustomFormRow>

          <Divider />
          {/* <Col xs={24}>
            <Col xs={12}>
              <Form.Item
                layout="vertical"
                label={<CustomFormLabel text="Tax Percentage" required />}
              >
                <Controller
                  name={`taxPercentage`}
                  control={control}
                  render={({ field, formState: { errors } }) => {
                    return (
                      <Form.Item
                        help={errors?.taxPercentage?.message}
                        validateStatus={errors?.taxPercentage ? "error" : ""}
                      >
                        <Space.Compact size="large" style={{ width: "100%" }}>
                          <InputNumber
                            {...field}
                            onChange={(value) => {
                              field.onChange(value);
                              handleCalculateTax(value || 0);
                            }}
                            style={{ width: "90%" }}
                            min={0}
                            max={100}
                            size="large"
                            type="number"
                            placeholder="Add Tax % here"
                          />
                          <Button
                            disabled
                            style={{
                              cursor: "default",
                              width: "10%",
                            }}
                          >
                            %
                          </Button>
                        </Space.Compact>
                      </Form.Item>
                    );
                  }}
                />
              </Form.Item>
            </Col>
          </Col> */}
          <Flex justify="space-between" align="center" gap={5}>
            <Typography.Title level={5}>Materials</Typography.Title>

            {!isFieldsCraftAuthorized() && (
              <BulkUploadButton
                disabled={
                  shouldDisable &&
                  (getValues("status") === ChangeOrderStatusEnum.Approved ||
                    getValues("status") ===
                      ChangeOrderStatusEnum.AddedToBidMaterial ||
                    getValues("status") === ChangeOrderStatusEnum.Rejected)
                }
                updateMaterialsCallback={updateMaterials}
                shouldReset={resetBulkUploadFile}
              />
            )}
          </Flex>

          <div className="my-6">
            <AddMaterialOfChangeOrder
              shouldDisable={shouldDisable}
              handleUpdateTotals={handleUpdateTotals}
              getValues={getValues}
              control={control}
            />
          </div>

          {validationError && (
            <CustomAlert message={validationError || ""} type="error" />
          )}

          <Divider />

          <Typography.Title level={5}>Attachments</Typography.Title>

          <SectionLayout
            className="rounded-xl flex items-center min-h-64 max-h-full my-5"
            borderStyle="dashed"
          >
            <div className="flex flex-col justify-center items-center p-8">
              <div className="mb-4">
                <CustomIcon type="add-file" className="fill-white" />
              </div>

              <h6 className="font-medium text-sm !mb-2">
                Select a file to import
              </h6>

              <Flex justify="center" gap={5} className="mt-2">
                <Controller
                  control={control}
                  name="attachments"
                  render={({ field }) => (
                    <Form.Item<FieldType>
                      labelAlign="right"
                      initialValue={field.value}
                    >
                      <CustomFileUploadRHF
                        setValue={setValue}
                        getValues={getValues}
                        fieldName={field.name}
                        deletedFileName="deleteAttachmentIds"
                        buttonText="Browse Files"
                        maxCount={10}
                      />
                    </Form.Item>
                  )}
                />
              </Flex>
            </div>
          </SectionLayout>

          {!validationError && (reqError || resError || successMessage) && (
            <CustomAlert
              message={reqError || resError || successMessage || ""}
              type={successMessage ? "success" : "error"}
            />
          )}

          {isFieldsCraftAuthorized() ? (
            <Flex
              justify="flex-end"
              className="mt-8 mb-5"
              gap={parseInt(getConsistentSpacing(2))}
            >
              <Button
                disabled={isSubmitting || isDeleting}
                type="default"
                onClick={handleCancelForm}
              >
                Back
              </Button>
            </Flex>
          ) : (
            <Flex
              justify="flex-end"
              className="mt-8 mb-5"
              gap={parseInt(getConsistentSpacing(2))}
            >
              {/* Cancel*/}
              <Button
                disabled={isSubmitting || isDeleting}
                type="default"
                onClick={handleCancelForm}
              >
                Cancel
              </Button>

              {Boolean(changeOrder) && (
                <>
                  {/* Delete */}
                  <Button
                    loading={
                      (actionType.delete === ActionTypeEnum.DELETE &&
                        isSubmitting) ||
                      isDeleting
                    }
                    disabled={
                      (shouldDisable &&
                        (getValues("status") ===
                          ChangeOrderStatusEnum.Approved ||
                          getValues("status") ===
                            ChangeOrderStatusEnum.AddedToBidMaterial ||
                          getValues("status") ===
                            ChangeOrderStatusEnum.Rejected)) ||
                      isSubmitting ||
                      isDeleting
                    }
                    type="default"
                    onClick={() => {
                      handleDeleteChangeOrderById({
                        projectId: selectedProjectId,
                        changeOrderId: getValues().id,
                      });
                      setActionType((prev) => ({
                        ...prev,
                        delete: ActionTypeEnum.DELETE,
                      }));
                    }}
                  >
                    {actionType.delete === ActionTypeEnum.DELETE && isSubmitting
                      ? "Deleting..."
                      : "Delete"}
                  </Button>

                  {/* Reject */}
                  <Button
                    loading={
                      actionType.rejectAll === ActionTypeEnum.REJECT_ALL &&
                      isSubmitting
                    }
                    disabled={
                      (shouldDisable &&
                        (getValues("status") ===
                          ChangeOrderStatusEnum.Approved ||
                          getValues("status") ===
                            ChangeOrderStatusEnum.AddedToBidMaterial ||
                          getValues("status") ===
                            ChangeOrderStatusEnum.Rejected)) ||
                      isSubmitting ||
                      isDeleting
                    }
                    className="font-medium !border-danger-5 !text-danger-5 bg-danger-510 hover:!bg-danger-5-18 hover:!border-danger-5-02  disabled:!bg-neutral-1 disabled:!border-neutral-5 disabled:!text-neutral-75"
                    type="default"
                    htmlType="button"
                    onClick={() => {
                      // setValue("status", ChangeOrderStatusEnum.Rejected);
                      setActionType((prev) => ({
                        ...prev,
                        rejectAll: ActionTypeEnum.REJECT_ALL,
                      }));

                      handleSubmit((data) =>
                        onSubmit(data, ActionTypeEnum.REJECT_ALL)
                      )();
                    }}
                  >
                    {actionType.rejectAll === ActionTypeEnum.REJECT_ALL &&
                    isSubmitting
                      ? "Rejecting.."
                      : "Reject"}
                  </Button>

                  {/* Approve */}
                  <Button
                    loading={
                      actionType.approve === ActionTypeEnum.APPROVE &&
                      isSubmitting
                    }
                    disabled={
                      (shouldDisable &&
                        (getValues("status") ===
                          ChangeOrderStatusEnum.Approved ||
                          getValues("status") ===
                            ChangeOrderStatusEnum.AddedToBidMaterial ||
                          getValues("status") ===
                            ChangeOrderStatusEnum.Rejected)) ||
                      isSubmitting ||
                      isDeleting
                    }
                    type="default"
                    className="font-medium !border-green-primary !text-[#FFFFFF] !bg-green-primary hover:!bg-green-primaryHover hover:!border-green-primaryHover disabled:!bg-neutral-1 disabled:!border-neutral-5 disabled:!text-neutral-75"
                    htmlType="button"
                    onClick={() => {
                      // setValue("status", ChangeOrderStatusEnum.Approved);
                      setActionType((prev) => ({
                        ...prev,
                        approve: ActionTypeEnum.APPROVE,
                      }));

                      handleSubmit((data) =>
                        onSubmit(data, ActionTypeEnum.APPROVE)
                      )();
                    }}
                  >
                    {actionType.approve === ActionTypeEnum.APPROVE &&
                    isSubmitting
                      ? "Approving.."
                      : "Approve"}
                  </Button>
                </>
              )}

              {/* Save */}
              <Button
                loading={
                  actionType.save === ActionTypeEnum.SAVE && isSubmitting
                }
                disabled={
                  (shouldDisable &&
                    (getValues("status") === ChangeOrderStatusEnum.Approved ||
                      getValues("status") ===
                        ChangeOrderStatusEnum.AddedToBidMaterial ||
                      getValues("status") ===
                        ChangeOrderStatusEnum.Rejected)) ||
                  isSubmitting ||
                  isDeleting
                }
                type="primary"
                htmlType="submit"
                onClick={() =>
                  setActionType((prev) => ({
                    ...prev,
                    save: ActionTypeEnum.SAVE,
                  }))
                }
              >
                {actionType.save === ActionTypeEnum.SAVE && isSubmitting
                  ? "Saving.."
                  : "Save"}
              </Button>
            </Flex>
          )}

          {changeOrder?.id && (
            <Flex justify="flex-end">
              <CreatedByUserBadge
                // userName={changeOrder?.createdBy as string}
                // date={changeOrder?.createdDate as Date}

                userName={
                  getValues("modifiedDate") == null
                    ? getValues("createdBy")
                    : getValues("lastModifiedBy")
                }
                date={getValues("lastModifiedDate")}
                isModifiedBadge={
                  getValues("modifiedDate") == null ? false : true
                }
              />
            </Flex>
          )}
        </Form>
      </SectionLayout>
    </>
  );
}
