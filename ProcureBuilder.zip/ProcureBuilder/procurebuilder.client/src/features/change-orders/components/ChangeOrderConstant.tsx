import { changeOrderInitialMaterials } from "@/src/data/intialsValues";
import { FilesDocumentTypeEnum } from "@/src/utils/enums";
import { ChangeOrder } from "@/src/utils/types";
import dayjs from "dayjs";

export const invoiceMaterials = [];

export const getChangeOrderIntialValues = (changeOrderData: ChangeOrder) => {
  const fileFormater = (documentTypeEnum: number) => {
    const newFileFormat = changeOrderData?.attachments
      ?.filter((v) => v.documentType === documentTypeEnum)
      ?.map((v) => ({
        uid: v?.id,
        name: v.fileName,
        documentType: v.documentType,
        url: v.url,
      }));

    return newFileFormat || [];
  };

  const initialValues = {
    id: changeOrderData?.id || "",
    title: changeOrderData?.title || "",
    otherCosts: changeOrderData?.otherCosts || 0,
    attachments:
      fileFormater(FilesDocumentTypeEnum.CHANGEORDERATTACHMENTS) || null,
    deleteAttachmentIds: [],
    changeOrderNumber: changeOrderData?.changeOrderNumber || "",
    approvalDeadline: dayjs(changeOrderData?.approvalDeadline || new Date()),
    projectId: changeOrderData?.projectId || null,
    userId: changeOrderData?.userId || null,
    notes: changeOrderData?.notes || "",
    materials:
      changeOrderData?.materials?.map((material) => ({
        id: material.id,
        name: material.name,
        costCode: material.costCode,
        quantity: material.quantity,
        unitOfMeasure: material.unitOfMeasure,
        unitRate: material.unitRate,
        totalBudget: material.totalBudget,
      })) || changeOrderInitialMaterials,
    createdBy: changeOrderData?.createdBy || "",
    lastModifiedDate: changeOrderData?.lastModifiedDate || null,
    modifiedDate: changeOrderData?.modifiedDate || null,
    lastModifiedBy: changeOrderData?.lastModifiedBy || "",
    subTotal: changeOrderData?.subTotal || 0,
    status: changeOrderData?.status || 0,
    // attachments:
    // fileFormater(FilesDocumentTypeEnum?.INVOICEATTACHMENTS) || null,
    // vendorInvoiceNumber: invoices?.vendorInvoiceNumber || "",
    // purchaseOrderDocument:
    //   fileFormater(FilesDocumentTypeEnum?.PURCHASEORDER) || null,
    // vendorInvoiceDocument:
    //   fileFormater(FilesDocumentTypeEnum?.VENDORINVOICE) || null,
    // paymentTerm: invoices?.paymentTerm || 0,
    // status: invoices?.status || 0,
    // notes: invoices?.notes || "",
    // subTotal: invoices?.subTotal || 0,
    // materials: invoices?.materials || invoiceMaterials,
    // PurchaseOrderNumber: 14,
  };
  return initialValues;
};
