import {
  createChangeOrder,
  deleteChangeOrderById,
  editChangeOrderById,
} from "@/src/apis/changeOrderApis";
import CreatedByUserBadge from "@/src/components/common/CreatedByUserBadge";
import CustomAlert from "@/src/components/common/CustomAlert";
import CustomFileUploadRHF from "@/src/components/common/CustomFileUploadRHF";
import CustomFormLabel from "@/src/components/common/CustomFormLabel";
import CustomIcon from "@/src/components/common/CustomIcon";
import OrderStatus from "@/src/components/common/OrderStatus";
// import CustomFormButtons from "@/src/components/form/CustomFormButtons";
import CustomFormRow from "@/src/components/form/CustomFormRow";
import AddMaterialOfChangeOrder from "@/src/components/materials/AddMaterialsOfChangeOrder";
// import { changeOrderInitialMaterials } from "@/src/data/intialsValues";
import { ChangeOrderInfoValidationSchema } from "@/src/data/validationsSchema";
import BulkUploadButton from "@/src/external-modules/bulk-upload/BulkUploadButton";
import BulkUploaderParser from "@/src/external-modules/bulk-upload/BulkUploadParser";
import {
  getChangeOrderByIdState,
  getChangeOrderState,
  resetState,
} from "@/src/store/slices/changeOrderSlice";
import { getOrderStatus } from "@/src/utils/helper";
import {
  ActionTypeState,
  Attachment,
  ChangeOrder,
  LabelSupportedMaterialType,
  Material,
} from "@/src/utils/types";
import SectionLayout from "@components/layout/SectionLayout";
import { yupResolver } from "@hookform/resolvers/yup";
import { useAppDispatch } from "@hooks/useAppDispatch";
import { useAppSelector } from "@hooks/useAppSelector";
import { getProjectManagersState } from "@store/slices/projectManagersSlice";
import { dateFormat } from "@utils/constants";
import { getConsistentSpacing } from "@utils/theme-helpers";
import {
  Button,
  Col,
  DatePicker,
  Divider,
  Flex,
  Form,
  Input,
  Select,
  Typography,
} from "antd";
// import dayjs from "dayjs";
import { ActionTypeEnum, ChangeOrderStatusEnum } from "@/src/utils/enums";
import { formatDecimals } from "@/src/utils/number-extensions";
import { useEffect, useMemo, useState } from "react";
import { Controller, Resolver, useForm } from "react-hook-form";
import { useParams } from "react-router-dom";
import { getChangeOrderIntialValues } from "./ChangeOrderConstant";
import { getLowerCasedMaterialName } from "@/src/external-modules/bulk-upload/bulk-upload-utils";
import useAuthorization from "@/src/hooks/useAuthorization";
import dayjs from "dayjs";

type ChangeOrderInfoFormSectionProps = {
  changeOrder?: ChangeOrder | null;
  handleCancelForm: () => void;
};

export default function ChangeOrderInfoFormSection({
  changeOrder,
  handleCancelForm,
}: ChangeOrderInfoFormSectionProps) {
  type FieldType = ChangeOrder;

  const { projectId } = useParams();
  const { isFieldsCraftAuthorized } = useAuthorization();
  const dispatch = useAppDispatch();
  const [shouldDisable, setShouldDisable] = useState(false);
  const [validationError, setValidationError] = useState("");
  const [isDeleting, setIsDeleting] = useState(false);
  const [changeOrderId, setChangeOrderId] = useState<string | null>(null);
  const [catchedChangeOrder, setCatchedChangeOrder] =
    useState<ChangeOrder | null>();
  const { successMessage, resError, reqError } =
    useAppSelector(getChangeOrderState);

  const [actionType, setActionType] = useState<ActionTypeState>({
    delete: ActionTypeEnum.NEUTRAL,
    rejectAll: ActionTypeEnum.NEUTRAL,
    approve: ActionTypeEnum.NEUTRAL,
    save: ActionTypeEnum.NEUTRAL,
    cancel: ActionTypeEnum.NEUTRAL,
  });

  const catchChangeOrder = useAppSelector((state) =>
    getChangeOrderByIdState(state, changeOrderId || "")
  );

  useEffect(() => {
    if (catchChangeOrder) {
      setCatchedChangeOrder(catchChangeOrder);
      return;
    }
  }, [changeOrderId, dispatch]);

  const changeOrderData = changeOrder || catchedChangeOrder;

  useEffect(() => {
    if (changeOrderData) {
      setShouldDisable(
        changeOrderData?.status !== ChangeOrderStatusEnum.Pending
      );
    }
  }, [changeOrderData]);

  const { managersData: projectManagersData } = useAppSelector(
    getProjectManagersState
  );
  const memoizedProjectManagersOptions = useMemo(() => {
    return (
      projectManagersData?.map((pm) => ({
        value: pm?.id,
        label: pm?.fullName,
      })) || []
    );
  }, [projectManagersData]);

  const {
    reset,
    control,
    handleSubmit,
    setValue,
    getValues,
    register,
    formState: { errors, isSubmitting },
  } = useForm<FieldType>({
    resolver: yupResolver(
      ChangeOrderInfoValidationSchema
    ) as unknown as Resolver<FieldType>,
    defaultValues: getChangeOrderIntialValues(changeOrderData as ChangeOrder),
    shouldUnregister: false,
  });

  const handleSave = async (values: FieldType) => {
    setValidationError("");

    const formData = new FormData();
    formData.append("id", changeOrderData?.id || ("" as string));
    formData.append("title", values.title);
    formData.append("otherCosts", String(values.otherCosts || 0));
    formData.append("changeOrderNumber", values.changeOrderNumber);
    formData.append("approvalDeadline", values.approvalDeadline as string);
    formData.append("projectId", projectId as string);
    values.userId && formData.append("userId", values.userId as string);
    formData.append("notes", values.notes);
    // formData.append("taxPercentage", String(values.taxPercentage || 0));
    formData.append("subTotal", String(values.subTotal));
    // formData.append("tax", String(values.tax || 0));
    // formData.append("total", String(values.total));
    formData.append("status", String(values.status));

    values?.materials?.forEach((material, index) => {
      Object.entries(material).forEach(([key, value]) => {
        formData.append(`materials[${index}][${key}]`, String(value));
      });
    });

    if (Array.isArray(values.attachments)) {
      values?.attachments?.forEach((file: Attachment) => {
        if (file?.originFileObj) {
          formData.append("attachments", file.originFileObj);
        }
      });
    }

    if (Array.isArray(values.deleteAttachmentIds)) {
      const filteredDeleteDocumentIds = values?.deleteAttachmentIds?.filter(
        (id: string) => !id?.startsWith("rc-upload-")
      );
      filteredDeleteDocumentIds?.forEach((id) => {
        formData.append("deleteAttachmentIds", id);
      });
    }

    try {
      if (getValues("id")) {
        return await dispatch(
          editChangeOrderById({
            payload: formData,
            changeOrderId: changeOrderData?.id,
            projectId,
          })
        ).unwrap();
      } else if (projectId) {
        return await dispatch(
          createChangeOrder({
            payload: formData,
            projectId,
          })
        ).unwrap();
      }
    } catch (error) {
      console.error("Error submitting form:", error);
    }
  };

  const onSubmit = async (values: FieldType, actionType: ActionTypeEnum) => {
    try {
      if (actionType === ActionTypeEnum.SAVE) {
        const response = await handleSave(values);

        if (response?.isSuccess && response?.changeOrder) {
          reset(getChangeOrderIntialValues(response?.changeOrder));
          setChangeOrderId(response.changeOrder.id);
        }
      } else if (actionType === ActionTypeEnum.APPROVE) {
        const response = await handleSave({
          ...values,
          status: ChangeOrderStatusEnum.Approved,
        });

        if (response?.isSuccess && response?.changeOrder) {
          reset(getChangeOrderIntialValues(response?.changeOrder));
          setChangeOrderId(response.changeOrder.id);

          setShouldDisable(true);
        }
      } else if (actionType === ActionTypeEnum.REJECT_ALL) {
        const response = await handleSave({
          ...values,
          status: ChangeOrderStatusEnum.Rejected,
        });

        if (response?.isSuccess && response?.changeOrder) {
          reset(getChangeOrderIntialValues(response?.changeOrder));
          setChangeOrderId(response.changeOrder.id);

          setShouldDisable(true);
        }
      }
    } catch (error) {
      console.error(error);
    }
  };

  const { iconType, badgeType } = getOrderStatus(getValues("status") || 0);

  type DeleteChangeOrderFunctionArgs = {
    projectId: string | undefined;
    changeOrderId: string | undefined;
  };

  async function handleDeleteChangeOrderById({
    projectId,
    changeOrderId,
  }: DeleteChangeOrderFunctionArgs) {
    if (changeOrderId) {
      try {
        setIsDeleting(true);
        const res = await dispatch(
          deleteChangeOrderById({
            changeOrderId: changeOrderId,
            projectId: projectId,
            errors: [],
            isSuccess: true,
          })
        ).unwrap();
        if (res.isSuccess) {
          handleCancelForm();
        }
      } catch (error) {
        console.error("Error Deleting Change Order:", error);
      } finally {
        setIsDeleting(false);
        dispatch(resetState());
      }
    }
  }

  useEffect(() => {
    dispatch(resetState());
  }, []);

  // Bulk upload handling
  const [resetBulkUploadFile, setBulkUploadFile] = useState(0);

  async function updateMaterials(file: File) {
    const bulkUploadParser = new BulkUploaderParser<
      LabelSupportedMaterialType[]
    >();
    const rows = await bulkUploadParser.readAndParseAsync(file);

    const isValid = await bulkUploadParser.validateMaterials<
      LabelSupportedMaterialType[]
    >({
      rows,
      schema: {
        material: "alphanumericString",
        costCode: "alphanumericString",
        quantity: "number",
        unitOfMeasurement: "alphanumericString",
        unitRate: "number",
        totalBudget: "alphanumericString",
      },
      requiredKeys: ["material", "costCode", "unitOfMeasurement", "unitRate"],
    });

    setBulkUploadFile(Date.now());

    if (!isValid) {
      return;
    }

    let subTotal = 0;

    rows.forEach((m: LabelSupportedMaterialType) => {
      subTotal += m.quantity * m.unitRate;
      m.name = m.material;
      m.unitOfMeasure = m.unitOfMeasurement;
      m.totalBudget = formatDecimals(calculateMaterialTotal(m)) || 0;
    });

    reset((values) => {
      let materials = [];
      const oldMaterials =
        values?.materials?.filter((f) => getLowerCasedMaterialName(f)) || [];

      if (oldMaterials?.length) {
        materials = bulkUploadParser.mergeMaterials({
          oldMaterials,
          newMaterials: rows,
          keysToBeUpdated: ["quantity", "unitRate", "totalBudget"],
        });
      } else {
        materials = rows;
      }

      return { ...values, materials, subTotal };
    });
  }

  const calculateMaterialTotal = (material: Material) =>
    Number(material.quantity || 0) * Number(material.unitRate || 0);

  const updateSubTotal = () => {
    const materials = getValues("materials") || [];
    const subTotal = materials.reduce(
      (sum, material) => sum + calculateMaterialTotal(material),
      0
    );

    const otherCosts = getValues("otherCosts") || 0;

    // @ts-ignore (ustad inshal)
    setValue("subTotal", formatDecimals(subTotal + otherCosts));
  };

  const handleUpdateTotals = () => {
    const materials = getValues("materials") || [];
    materials.forEach((material, index) => {
      const total = calculateMaterialTotal(material);
      setValue(`materials.${index}.totalBudget`, formatDecimals(total));
    });

    updateSubTotal();
    const subTotal = getValues("subTotal") || 0;
    const tax = getValues("tax") || 0;
    setValue("total", formatDecimals(subTotal + tax));
  };

  // const handleCalculateTax = (value: number) => {
  //   const taxPercentage = Number(value || 0);
  //   setValue("taxPercentage", taxPercentage);
  //   const subTotal = getValues("subTotal") || 0;
  //   const tax = (subTotal * taxPercentage) / 100;
  //   setValue("tax", formatDecimals(tax));

  //   const total = subTotal + tax;
  //   setValue("total", formatDecimals(total));
  // };

  return (
    <>
      <SectionLayout>
        <Form
          disabled={
            isFieldsCraftAuthorized() ||
            (shouldDisable &&
              (getValues("status") === ChangeOrderStatusEnum.Approved ||
                getValues("status") ===
                  ChangeOrderStatusEnum.AddedToBidMaterial ||
                getValues("status") === ChangeOrderStatusEnum.Rejected))
          }
          onFinish={handleSubmit((data) => onSubmit(data, ActionTypeEnum.SAVE))}
          layout="vertical"
          autoComplete="off"
        >
          <CustomFormRow>
            <Col xs={24} className="mb-1">
              <Flex justify="space-between" align="center">
                <Typography.Title level={5}>
                  Change Order Information
                </Typography.Title>
                <OrderStatus badgeIconType={iconType} badgeType={badgeType} />
              </Flex>
            </Col>

            {/* Title */}
            <Col xs={12}>
              <Controller
                control={control}
                name="title"
                render={({ field }) => (
                  <Form.Item<FieldType>
                    label={<CustomFormLabel text="Title" required={true} />}
                    labelAlign="right"
                    initialValue={field.value}
                    validateStatus={errors.title ? "error" : ""}
                    help={errors.title?.message}
                  >
                    <Input
                      ref={register(`title`).ref}
                      value={field.value}
                      onChange={(event) => field.onChange(event?.target?.value)}
                      size="large"
                      placeholder="Change Order Title"
                    />
                  </Form.Item>
                )}
              />
            </Col>

            {/* Change Order Number */}
            <Col xs={12}>
              <Controller
                control={control}
                name="changeOrderNumber"
                render={({ field }) => (
                  <Form.Item<FieldType>
                    label={
                      <CustomFormLabel
                        text="Change Order Number"
                        required={true}
                      />
                    }
                    labelAlign="right"
                    initialValue={field.value}
                    validateStatus={errors.changeOrderNumber ? "error" : ""}
                    help={errors.changeOrderNumber?.message}
                  >
                    <Input
                      ref={register(`changeOrderNumber`).ref}
                      value={field.value}
                      onChange={(event) => field.onChange(event?.target?.value)}
                      disabled={
                        (shouldDisable &&
                          (getValues("status") ===
                            ChangeOrderStatusEnum.Approved ||
                            getValues("status") ===
                              ChangeOrderStatusEnum.AddedToBidMaterial ||
                            getValues("status") ===
                              ChangeOrderStatusEnum.Rejected)) ||
                        Boolean(changeOrder?.id)
                      }
                      size="large"
                      placeholder="Change Order Number"
                    />
                  </Form.Item>
                )}
              />
            </Col>

            {/* Approval Deadline */}
            <Col xs={12}>
              <Controller
                control={control}
                name="approvalDeadline"
                render={({ field }) => (
                  <Form.Item<FieldType>
                    label={<CustomFormLabel text="Approval Deadline" />}
                    labelAlign="right"
                    initialValue={field.value}
                  >
                    <DatePicker
                      value={
                        dayjs(field.value).isValid() ? dayjs(field.value) : null
                      }
                      onChange={(date) => {
                        field.onChange(dayjs(date).locale("en").format());
                      }}
                      size="large"
                      style={{ width: "100%" }}
                      placeholder="MM/DD/YYYY"
                      format={dateFormat}
                    />
                  </Form.Item>
                )}
              />
            </Col>

            {/* Assign to */}
            <Col xs={12}>
              <Controller
                control={control}
                name="userId"
                render={({ field }) => (
                  <Form.Item<FieldType>
                    label={<CustomFormLabel text="Assign to" />}
                    labelAlign="right"
                    initialValue={field.value}
                  >
                    <Select
                      value={field.value}
                      onChange={(value) => {
                        field.onChange(value);
                      }}
                      size="large"
                      placeholder="Select Project Manager"
                      options={memoizedProjectManagersOptions}
                      showSearch
                      filterOption={(input, option) =>
                        (option?.label || "")
                          .toLowerCase()
                          .includes(input.toLowerCase())
                      }
                    />
                  </Form.Item>
                )}
              />
            </Col>

            {/* Notes */}
            <Col xs={12}>
              <Controller
                control={control}
                name="notes"
                render={({ field }) => (
                  <Form.Item<FieldType>
                    label={
                      <CustomFormLabel text="Notes (For Internal Users)" />
                    }
                    labelAlign="right"
                    initialValue={field.value}
                  >
                    <Input.TextArea
                      value={field.value}
                      onChange={(event) => field.onChange(event?.target?.value)}
                      style={{ minHeight: getConsistentSpacing(20) }}
                      size="large"
                      placeholder="Write your notes here..."
                    />
                  </Form.Item>
                )}
              />
            </Col>
          </CustomFormRow>

          <Divider />
          {/* <Col xs={24}>
            <Col xs={12}>
              <Form.Item
                layout="vertical"
                label={<CustomFormLabel text="Tax Percentage" required />}
              >
                <Controller
                  name={`taxPercentage`}
                  control={control}
                  render={({ field, formState: { errors } }) => {
                    return (
                      <Form.Item
                        help={errors?.taxPercentage?.message}
                        validateStatus={errors?.taxPercentage ? "error" : ""}
                      >
                        <Space.Compact size="large" style={{ width: "100%" }}>
                          <InputNumber
                            {...field}
                            onChange={(value) => {
                              field.onChange(value);
                              handleCalculateTax(value || 0);
                            }}
                            style={{ width: "90%" }}
                            min={0}
                            max={100}
                            size="large"
                            type="number"
                            placeholder="Add Tax % here"
                          />
                          <Button
                            disabled
                            style={{
                              cursor: "default",
                              width: "10%",
                            }}
                          >
                            %
                          </Button>
                        </Space.Compact>
                      </Form.Item>
                    );
                  }}
                />
              </Form.Item>
            </Col>
          </Col> */}
          <Flex justify="space-between" align="center" gap={5}>
            <Typography.Title level={5}>Materials</Typography.Title>

            {!isFieldsCraftAuthorized() && (
              <BulkUploadButton
                disabled={
                  shouldDisable &&
                  (getValues("status") === ChangeOrderStatusEnum.Approved ||
                    getValues("status") ===
                      ChangeOrderStatusEnum.AddedToBidMaterial ||
                    getValues("status") === ChangeOrderStatusEnum.Rejected)
                }
                updateMaterialsCallback={updateMaterials}
                shouldReset={resetBulkUploadFile}
              />
            )}
          </Flex>

          <div className="my-6">
            <AddMaterialOfChangeOrder
              shouldDisable={shouldDisable}
              handleUpdateTotals={handleUpdateTotals}
              getValues={getValues}
              control={control}
            />
          </div>

          {validationError && (
            <CustomAlert message={validationError || ""} type="error" />
          )}

          <Divider />

          <Typography.Title level={5}>Attachments</Typography.Title>

          <SectionLayout
            className="rounded-xl flex justify-center items-center max-h-full min-h-52 my-5"
            borderStyle="dashed"
          >
            <div className="flex flex-col justify-center items-center max-h-full min-h-52 p-8">
              <div className="mb-4">
                <CustomIcon type="add-file" className="fill-white" />
              </div>

              <h6 className="font-medium text-sm !mb-2">
                Select a file to import
              </h6>

              <Flex justify="center" gap={5} className="mt-2">
                <Controller
                  control={control}
                  name="attachments"
                  render={({ field }) => (
                    <Form.Item<FieldType>
                      labelAlign="right"
                      initialValue={field.value}
                    >
                      <CustomFileUploadRHF
                        setValue={setValue}
                        getValues={getValues}
                        fieldName={field.name}
                        deletedFileName="deleteAttachmentIds"
                        buttonText="Browse Files"
                        maxCount={10}
                      />
                    </Form.Item>
                  )}
                />
              </Flex>
            </div>
          </SectionLayout>

          {!validationError && (reqError || resError || successMessage) && (
            <CustomAlert
              message={reqError || resError || successMessage || ""}
              type={successMessage ? "success" : "error"}
            />
          )}

          {isFieldsCraftAuthorized() ? (
            <Flex
              justify="flex-end"
              className="mt-8 mb-5"
              gap={parseInt(getConsistentSpacing(2))}
            >
              <Button
                disabled={isSubmitting || isDeleting}
                type="default"
                onClick={handleCancelForm}
              >
                Back
              </Button>
            </Flex>
          ) : (
            <Flex
              justify="flex-end"
              className="mt-8 mb-5"
              gap={parseInt(getConsistentSpacing(2))}
            >
              {/* Cancel*/}
              <Button
                disabled={isSubmitting || isDeleting}
                type="default"
                onClick={handleCancelForm}
              >
                Cancel
              </Button>

              {Boolean(changeOrder || changeOrderId) && (
                <>
                  {/* Delete */}
                  <Button
                    loading={
                      (actionType.delete === ActionTypeEnum.DELETE &&
                        isSubmitting) ||
                      isDeleting
                    }
                    disabled={
                      (shouldDisable &&
                        (getValues("status") ===
                          ChangeOrderStatusEnum.Approved ||
                          getValues("status") ===
                            ChangeOrderStatusEnum.AddedToBidMaterial ||
                          getValues("status") ===
                            ChangeOrderStatusEnum.Rejected)) ||
                      isSubmitting ||
                      isDeleting
                    }
                    type="default"
                    onClick={() => {
                      handleDeleteChangeOrderById({
                        projectId: projectId,
                        changeOrderId: getValues().id,
                      });

                      setActionType((prev) => ({
                        ...prev,
                        delete: ActionTypeEnum.DELETE,
                      }));
                    }}
                  >
                    {actionType.delete === ActionTypeEnum.DELETE && isSubmitting
                      ? "Deleting..."
                      : "Delete"}
                  </Button>

                  {/* Reject */}
                  <Button
                    loading={
                      actionType.rejectAll === ActionTypeEnum.REJECT_ALL &&
                      isSubmitting
                    }
                    disabled={
                      (shouldDisable &&
                        (getValues("status") ===
                          ChangeOrderStatusEnum.Approved ||
                          getValues("status") ===
                            ChangeOrderStatusEnum.AddedToBidMaterial ||
                          getValues("status") ===
                            ChangeOrderStatusEnum.Rejected)) ||
                      isSubmitting ||
                      isDeleting
                    }
                    className="font-medium !border-danger-5 !text-danger-5 bg-danger-510 hover:!bg-danger-5-18 hover:!border-danger-5-02  disabled:!bg-neutral-1 disabled:!border-neutral-5 disabled:!text-neutral-75"
                    type="default"
                    htmlType="button"
                    onClick={() => {
                      // setValue("status", ChangeOrderStatusEnum.Rejected);
                      setActionType((prev) => ({
                        ...prev,
                        rejectAll: ActionTypeEnum.REJECT_ALL,
                      }));

                      handleSubmit((data) =>
                        onSubmit(data, ActionTypeEnum.REJECT_ALL)
                      )();
                    }}
                  >
                    {actionType.rejectAll === ActionTypeEnum.REJECT_ALL &&
                    isSubmitting
                      ? "Rejecting.."
                      : "Reject"}
                  </Button>

                  {/* Approve */}
                  <Button
                    loading={
                      actionType.approve === ActionTypeEnum.APPROVE &&
                      isSubmitting
                    }
                    disabled={
                      (shouldDisable &&
                        (getValues("status") ===
                          ChangeOrderStatusEnum.Approved ||
                          getValues("status") ===
                            ChangeOrderStatusEnum.AddedToBidMaterial ||
                          getValues("status") ===
                            ChangeOrderStatusEnum.Rejected)) ||
                      isSubmitting ||
                      isDeleting
                    }
                    type="default"
                    className="font-medium !border-green-primary !text-[#FFFFFF] !bg-green-primary hover:!bg-green-primaryHover hover:!border-green-primaryHover disabled:!bg-neutral-1 disabled:!border-neutral-5 disabled:!text-neutral-75"
                    htmlType="button"
                    onClick={() => {
                      // setValue("status", ChangeOrderStatusEnum.Approved);
                      setActionType((prev) => ({
                        ...prev,
                        approve: ActionTypeEnum.APPROVE,
                      }));

                      handleSubmit((data) =>
                        onSubmit(data, ActionTypeEnum.APPROVE)
                      )();
                    }}
                  >
                    {actionType.approve === ActionTypeEnum.APPROVE &&
                    isSubmitting
                      ? "Approving.."
                      : "Approve"}
                  </Button>
                </>
              )}

              {/* Save */}
              <Button
                loading={
                  actionType.save === ActionTypeEnum.SAVE && isSubmitting
                }
                disabled={
                  (shouldDisable &&
                    (getValues("status") === ChangeOrderStatusEnum.Approved ||
                      getValues("status") ===
                        ChangeOrderStatusEnum.AddedToBidMaterial ||
                      getValues("status") ===
                        ChangeOrderStatusEnum.Rejected)) ||
                  isSubmitting ||
                  isDeleting
                }
                type="primary"
                htmlType="submit"
                onClick={() =>
                  setActionType((prev) => ({
                    ...prev,
                    save: ActionTypeEnum.SAVE,
                  }))
                }
              >
                {actionType.save === ActionTypeEnum.SAVE && isSubmitting
                  ? "Saving.."
                  : "Save"}
              </Button>
            </Flex>
          )}

          {changeOrderData?.id && (
            <Flex justify="flex-end">
              <CreatedByUserBadge
                // userName={changeOrderData?.createdBy as string}
                // date={changeOrderData?.createdDate as Date}

                userName={
                  getValues("modifiedDate") == null
                    ? getValues("createdBy")
                    : getValues("lastModifiedBy")
                }
                date={getValues("lastModifiedDate")}
                isModifiedBadge={
                  getValues("modifiedDate") == null ? false : true
                }
              />
            </Flex>
          )}
        </Form>
      </SectionLayout>
    </>
  );
}
