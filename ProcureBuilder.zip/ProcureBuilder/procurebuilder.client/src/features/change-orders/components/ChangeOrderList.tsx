import {
  GetAllChangeOrderRequest,
  getAllChangeOrders,
} from "@/src/apis/changeOrderApis";
import { getSummarizedProjectsList } from "@/src/apis/projectApis";
import HighlightedText from "@/src/components/common/HighlightedText";
import OrderStatus from "@/src/components/common/OrderStatus";
import CustomTable, {
  defaultPageSizes,
} from "@/src/components/table/CustomTable";
import CustomTableFilters, {
  CustomFilterDataType,
  CustomFiltersType,
} from "@/src/components/table/CustomTableFilters";
import { useAppDispatch } from "@/src/hooks/useAppDispatch";
import useAuthorization from "@/src/hooks/useAuthorization";
import { useDebouncedCallback } from "@/src/hooks/useDebouncedCallback";
import { getProjectsState } from "@/src/store/slices/projectsSlice";
import {
  allChangeOrderStatusOption,
  changeOrderStatusOptionsWithAll,
  dateFormat,
} from "@/src/utils/constants";
import { getOrderStatus } from "@/src/utils/helper";
import { getFirstValidNumber } from "@/src/utils/number-extensions";
import routePaths from "@/src/utils/routePaths";
import { EyeOutlined } from "@ant-design/icons";
import CustomIcon from "@components/common/CustomIcon";
import { useAppSelector } from "@hooks/useAppSelector";
import { getChangeOrderState } from "@store/slices/changeOrderSlice";
import { getConsistentSpacing } from "@utils/theme-helpers";
import { ChangeOrder } from "@utils/types";
import { Button, TableProps, Typography } from "antd";
import dayjs from "dayjs";
import { useEffect, useMemo, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useReports } from "../../reports/contexts/ReportsProvider";
import useSyncFilters from "@/src/hooks/useSyncFilters";
const { Text } = Typography;

type ChangeOrderListProps = {
  exportButtonEl?: React.ReactNode | null;

  setReportStats?:
    | null
    | ((
        totalChangeOrders: number,
        totalSubtotal: number,
        totalApprovedChangeOrders: number,
        totalRejectedChangeOrders: number,
        totalPendingChangeOrders: number,
        totalAddedToBidMaterialChangeOrder: number
      ) => void);
};

export default function ChangeOrderList({
  exportButtonEl = null,
  setReportStats = null,
}: ChangeOrderListProps) {
  const { filterValues } = useReports();

  const isInsideReports = useMemo(
    () => Boolean(exportButtonEl),
    [exportButtonEl]
  );
  const navigate = useNavigate();
  const dispatch = useAppDispatch();
  const { isFieldsCraftAuthorized } = useAuthorization();

  const {
    changeOrderData,
    isLoading,
    totalCount,
    currentPage: changeOrderListCurrentPage,
    pageSize: changeOrderListPageSize,
  } = useAppSelector(getChangeOrderState);
  const { projectsSummarizedData } = useAppSelector(getProjectsState);
  const [searchTerm, setSearchTerm] = useState("");
  const [hasSearched, setHasSearched] = useState(false);
  const { searchParams } = useSyncFilters();
  const [previousSearchTerm, setPreviousSearchTerm] = useState(
    searchParams.get("searchTerm")
  );
  const [lastSearchTimestamp, setLastSearchTimestamp] = useState(0);

  useEffect(() => {
    setLastSearchTimestamp(Date.now());
  }, [previousSearchTerm]);

  const [page, setPage] = useState<number>(changeOrderListCurrentPage);
  const [pageSize, setPageSize] = useState(
    !isInsideReports && !defaultPageSizes.includes(changeOrderListPageSize)
      ? 10
      : changeOrderListPageSize
  );
  const isFirstCallComplete = useRef(false);
  // const [isFirstCall, setIsFirstCall] = useState(false);

  useEffect(() => {
    dispatch(getSummarizedProjectsList());
  }, [dispatch]);

  const memoizedProjectsOptions = useMemo(() => {
    return [
      {
        value: "",
        label: "All Projects",
      },
      ...(projectsSummarizedData?.map((f) => ({
        value: f?.id,
        label: f?.name,
      })) || []),
    ];
  }, [projectsSummarizedData]);
  const [filters, setFilters] = useState<CustomFiltersType>({
    status: {
      value: allChangeOrderStatusOption?.value || 0,
      options: changeOrderStatusOptionsWithAll,
      className: "!min-w-[205px]",
      dataType: CustomFilterDataType.NUM,
    },
    projectId: {
      value: memoizedProjectsOptions[0]?.value || "",
      options: memoizedProjectsOptions,
      dataType: CustomFilterDataType.STR,
    },
  });
  useEffect(() => {
    // Only update filters if the options actually change
    setFilters((prevFilters) => {
      const currentOptions = prevFilters.projectId.options;
      const newOptions = memoizedProjectsOptions;

      // Check if options are different (by comparing their length or individual items)
      const optionsChanged =
        currentOptions.length !== newOptions.length ||
        currentOptions.some(
          (option, index) => option.value !== newOptions[index]?.value
        );

      // If options are the same, return the previous filters to avoid unnecessary state update
      if (!optionsChanged) {
        return prevFilters;
      }

      // If options have changed, update the filters
      return {
        ...prevFilters,
        projectId: {
          ...prevFilters.projectId,
          options: newOptions,
        },
      };
    });
  }, [memoizedProjectsOptions]);
  // useEffect(() => {
  //   setFilters((prevFilters) => ({
  //     ...prevFilters,
  //     projectId: {
  //       ...prevFilters.projectId,
  //       options: memoizedProjectsOptions,
  //     },
  //   }));
  // }, [memoizedProjectsOptions]);

  const [buttonsFilterStatus, setButtonsFilterStatus] = useState({
    isDueToday: false,
    isOverDue: false,
    isUpComing: false,
  });

  const [buttonActive, setButtonActive] = useState({
    isDueTodayActive: false,
    isOverDueActive: false,
    isUpComingActive: false,
  });

  function updateDueTimeButtons(value: string) {
    switch (value) {
      case "dueToday":
        setButtonsFilterStatus((prev) => ({
          ...prev,
          isDueToday: !prev.isDueToday,
          isOverDue: false,
          isUpComing: false,
        }));
        setButtonActive((prev) => ({
          ...prev,
          isDueTodayActive: !prev.isDueTodayActive,
          isOverDueActive: false,
          isUpComingActive: false,
        }));
        break;
      case "overDue":
        setButtonsFilterStatus((prev) => ({
          ...prev,
          isDueToday: false,
          isOverDue: !prev.isOverDue,
          isUpComing: false,
        }));
        setButtonActive((prev) => ({
          ...prev,
          isDueTodayActive: false,
          isOverDueActive: !prev.isOverDueActive,
          isUpComingActive: false,
        }));
        break;
      case "upComing":
        setButtonsFilterStatus((prev) => ({
          ...prev,
          isDueToday: false,
          isOverDue: false,
          isUpComing: !prev.isUpComing,
        }));
        setButtonActive((prev) => ({
          ...prev,
          isDueTodayActive: false,
          isOverDueActive: false,
          isUpComingActive: !prev.isUpComingActive,
        }));
    }
  }
  const navigateToEditPage = (changeOrder: ChangeOrder) => {
    const path = `${routePaths.CHANGE_ORDER_EDIT_BY_ID}/${changeOrder?.projectId}/${changeOrder?.id}`;

    if (isInsideReports || new URLSearchParams(location.search).size > 0) {
      navigate(path, {
        state: {
          previousPath: `${location.pathname}${location.search}`,
        },
      });
    } else {
      navigate(path);
    }
  };

  const filterButtons = [
    {
      label: "Due Today",
      value: "dueToday",
      isActive: buttonActive.isDueTodayActive,
      onClick: updateDueTimeButtons,
    },
    {
      label: "Over Due",
      value: "overDue",
      isActive: buttonActive.isOverDueActive,
      onClick: updateDueTimeButtons,
    },
    {
      label: "Upcoming",
      value: "upComing",
      isActive: buttonActive.isUpComingActive,
      onClick: updateDueTimeButtons,
    },
  ];

  const columns: TableProps<ChangeOrder>["columns"] = [
    {
      title: "Change Order Number",
      dataIndex: "changeOrderNumber",
      key: "changeOrderNumber",
      sorter: (a, b) => a.changeOrderNumber?.localeCompare(b.changeOrderNumber),
      render: (_, changeOrder) => (
        <HighlightedText
          text={changeOrder?.changeOrderNumber}
          searchTerm={searchTerm}
        />
      ),
    },
    {
      title: "Title",
      dataIndex: "title",
      key: "title",
      sorter: (a, b) => a.title?.localeCompare(b.title),
      render: (_, changeOrder) => (
        <HighlightedText text={changeOrder?.title} searchTerm={searchTerm} />
      ),
    },
    {
      title: "Project",
      dataIndex: "projects",
      key: "projects",
      sorter: (a, b) =>
        dayjs(a.project?.name).unix() - dayjs(b.project?.name).unix(),
      render: (_, changeOrder) => (
        <HighlightedText
          text={changeOrder?.project?.name}
          searchTerm={searchTerm}
        />
      ),
    },
    {
      title: "Approval Deadline",
      dataIndex: "approveDeadline",
      key: "approveDeadline",
      sorter: (a, b) =>
        dayjs(a.approvalDeadline).unix() - dayjs(b.approvalDeadline).unix(),
      render: (_, record) =>
        record?.approvalDeadline
          ? dayjs(record?.approvalDeadline).format(dateFormat)
          : "",
    },
    {
      title: "Status",
      dataIndex: "status",
      key: "status",
      sorter: (a, b) => (a.status || 0) - (b.status || 0),
      render: (_, changeOrder) => {
        const { iconType, badgeType } = getOrderStatus(changeOrder?.status);
        return (
          <Text style={{ fontSize: getConsistentSpacing(1.75), margin: 0 }}>
            <OrderStatus badgeIconType={iconType} badgeType={badgeType} />
          </Text>
        );
      },
    },
    {
      title: "Subtotal",
      dataIndex: "subtotal",
      key: "subtotal",
      sorter: (a, b) => (a.subTotal || 0) - (b.subTotal || 0),
      render: (_, changeOrder) => (
        <Text style={{ fontSize: getConsistentSpacing(1.75), margin: 0 }}>
          {`$${changeOrder?.subTotal?.toLocaleString()}`}
        </Text>
      ),
    },

    {
      title: "",
      dataIndex: "edit",
      key: "edit",
      render: (_, changeOrder) =>
        !isInsideReports && (
          <Button
            shape="circle"
            className="hover:!fill-primary"
            icon={
              isFieldsCraftAuthorized() ? (
                <EyeOutlined />
              ) : (
                <CustomIcon type="edit" />
              )
            }
            onClick={() => navigateToEditPage(changeOrder)}
          />
        ),
    },
  ];

  const handleGetResults = useDebouncedCallback(getResults, 100);

  async function getResults(pageNumber?: number) {
    const status =
      filters.status?.value !== allChangeOrderStatusOption?.value
        ? (filters?.status?.value as number)
        : undefined;

    const projectId =
      filters.projectId?.value !== memoizedProjectsOptions[0]?.value
        ? filters?.projectId?.value?.toString()
        : undefined;

    const isDueToday = buttonsFilterStatus.isDueToday
      ? buttonsFilterStatus.isDueToday.toString()
      : undefined;

    const isOverDue = buttonsFilterStatus.isOverDue
      ? buttonsFilterStatus.isOverDue.toString()
      : undefined;

    const isUpComing = buttonsFilterStatus.isUpComing
      ? buttonsFilterStatus.isUpComing.toString()
      : undefined;

    const reportFilters = isInsideReports ? filterValues : {};

    const payload: GetAllChangeOrderRequest = {
      isForReport: isInsideReports,
      pageNumber: pageNumber || page,
      pageSize,
      status: getFirstValidNumber(reportFilters?.status, status),
      isDueToday,
      isUpComing,
      isOverDue,
      projectId: reportFilters?.projectId || projectId,
      search: searchTerm || undefined,
      ...{
        subtotalFrom: reportFilters?.subtotalStart || undefined,
        subtotalTo: reportFilters?.subtotalEnd || undefined,
        approvalDeadlineFrom: reportFilters?.approvalDeadline?.[0] || undefined,
        approvalDeadlineTo: reportFilters?.approvalDeadline?.[1] || undefined,
      },
    };

    const res = await dispatch(getAllChangeOrders(payload)).unwrap();

    if (typeof setReportStats === "function") {
      setReportStats(
        res?.totalCount || 0,
        res?.combinedSubtotal || 0,
        res?.totalApproved || 0,
        res?.totalRejected || 0,
        res?.totalPending || 0,
        res?.totalAddedToBidMaterial || 0
      );
    }
  }
  function resetPaginationAndGetFirstPageResults() {
    if (isFirstCallComplete?.current === true) {
      if (filters) {
        setPage(1);
      }

      handleGetResults(1);
    } else {
      handleGetResults();
    }
  }

  useEffect(() => {
    resetPaginationAndGetFirstPageResults();
  }, [filters, buttonsFilterStatus, filterValues]);

  useEffect(() => {
    if (!hasSearched) return;
    const timer = setTimeout(() => {
      if (searchTerm === "" && previousSearchTerm !== "") {
        resetPaginationAndGetFirstPageResults();
        setPreviousSearchTerm(searchTerm);
      }
    }, 500);

    return () => {
      clearTimeout(timer);
    };
  }, [searchTerm, hasSearched, previousSearchTerm]);

  const handleSearch = () => {
    if (searchTerm !== previousSearchTerm) {
      setHasSearched(true);
      resetPaginationAndGetFirstPageResults();
      setPreviousSearchTerm(searchTerm);
    }
  };

  useEffect(() => {
    if (
      !isFirstCallComplete?.current ||
      changeOrderListCurrentPage !== page ||
      changeOrderListPageSize !== pageSize
    ) {
      handleGetResults();

      if (!isFirstCallComplete?.current) {
        setTimeout(() => {
          isFirstCallComplete.current = true;
        }, 1000);
      }
    }
  }, [page, pageSize]);

  return (
    <>
      <CustomTable
        data={changeOrderData || []}
        columns={columns || []}
        searchTerm={searchTerm}
        setSearchTerm={setSearchTerm}
        handleSearch={handleSearch}
        isLoading={isLoading}
        totalCount={totalCount}
        page={page}
        setPage={setPage}
        pageSize={pageSize}
        setPageSize={setPageSize}
        filterElements={
          !isInsideReports && (
            <CustomTableFilters
              filters={filters}
              setFilters={setFilters}
              buttons={filterButtons}
            />
          )
        }
        hasPagination={true}
        hasSearch={true}
        exportButtonEl={exportButtonEl}
        isInsideReports={isInsideReports}
        onRowClick={
          isInsideReports ? (co) => navigateToEditPage(co) : undefined
        }
        tableFilters={filters}
        reportFilterForParamsUseOnly={
          isInsideReports ? filterValues : undefined
        }
        setTableFilters={!isInsideReports ? setFilters : undefined}
        hasCursorPointer={isInsideReports}
        lastSearchTimestamp={lastSearchTimestamp}
        dueTimeButtons={filterButtons?.map((m) => ({
          ...m,
          isActive:
            m.value === "dueToday"
              ? buttonActive.isDueTodayActive
              : m.value === "overDue"
              ? buttonActive.isOverDueActive
              : buttonActive.isUpComingActive,
        }))}
        updateDueTimeButtons={updateDueTimeButtons}
      />
    </>
  );
}
