import { Inventory } from "@/src/utils/types";

export function mapInventoryMaterials(inventories: Inventory[]): Inventory[] {
  return inventories?.map((i) => ({
    ...i,
    materials: i?.materials?.map((m) => ({
      name: m.name,
      costCode: m.costCode,
      quantity: m.quantity,
      isRefillable: m.isRefillable,
      subLocationId: m.subLocationId,
      unitOfMeasure: m.unitOfMeasure,
      isNewMaterialFromBulkUpload: m.isNewMaterialFromBulkUpload,
      materialId: m.materialId,
      id: m.id,
    })),
  }));
}
