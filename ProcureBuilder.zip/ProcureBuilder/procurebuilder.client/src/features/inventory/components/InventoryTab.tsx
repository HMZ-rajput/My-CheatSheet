import { getAllInventoryListByProjectId } from "@/src/apis/inventoryApis";
import CustomIcon from "@/src/components/common/CustomIcon";
import CustomOverlayLoader from "@/src/components/common/CustomOverlayloader";
import SectionLayout from "@/src/components/layout/SectionLayout";
import { useAppDispatch } from "@/src/hooks/useAppDispatch";
import { useAppSelector } from "@/src/hooks/useAppSelector";
import useAuthorization from "@/src/hooks/useAuthorization";
import { getInventoriesState } from "@/src/store/slices/inventorySlice";
import { Inventory } from "@/src/utils/types";
import InventoryImg from "@assets/images/inventory/inventory-orange.png";
import { Button, Flex } from "antd";
import { useState } from "react";
import { useParams } from "react-router-dom";
import InventoryDetailForm from "./InventoryDetailForm";
import InventoryList from "./InventoryList";

// type InventoryTabProps = {}
export default function InventoryTab() {
  const { isFieldsCraftAuthorized } = useAuthorization();
  const { projectId } = useParams();
  const [displayForm, setDisplayForm] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const { inventories } = useAppSelector(getInventoriesState);

  const getInventoryByProjectId = async () => {
    try {
      setIsLoading(true);
      await dispatch(
        getAllInventoryListByProjectId({ projectId: projectId || "" })
      );
    } catch (error) {
      console.log("err", error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleEdit = async (getDataAgain = false) => {
    if (getDataAgain) {
      await getInventoryByProjectId();
    }

    setDisplayForm(true);
  };

  const handleBackToTable = () => {
    setDisplayForm(false);
  };

  const dispatch = useAppDispatch();

  const data =
    inventories?.flatMap(
      (inventory: Inventory) => inventory?.materials || []
    ) || [];

  const NoInventorySection = (
    <>
      <SectionLayout>
        <SectionLayout
          className="p-8 rounded-xl items-center max-h-64"
          borderStyle="dashed"
        >
          <img src={InventoryImg} width="48" height="48" className="mb-5" />

          <h6 className="font-medium text-sm !mb-1">No Inventory Added Yet</h6>

          <p className="font-normal text-center text-xs mb-5 text-neutral-7">
            Please Add Products to get started.
          </p>

          {!isFieldsCraftAuthorized() && (
            <Flex className="gap-5">
              <Button
                size="large"
                className="hover:!fill-primary"
                icon={<CustomIcon type="plus" />}
                onClick={() => {
                  setDisplayForm(true);
                }}
              >
                Add Products
              </Button>
            </Flex>
          )}
        </SectionLayout>
      </SectionLayout>
    </>
  );

  if (isLoading) {
    return <CustomOverlayLoader />;
  }
  return (
    <>
      {!displayForm ? (
        <InventoryList
          Loading={isLoading}
          handleEdit={handleEdit}
          data={data}
        />
      ) : displayForm ? (
        <InventoryDetailForm
          handleBackToTable={handleBackToTable}
          inventories={inventories || []}
        />
      ) : (
        NoInventorySection
      )}
    </>
  );
}
