// New
import { Select } from "antd";
import React, { useCallback, useEffect, useRef } from "react";
import { Controller } from "react-hook-form";
import { VariableSizeList as List } from "react-window";

import CustomInput from "@/src/components/form/CustomInput";
import DeleteIconButton from "@/src/components/icon-buttons/DeleteIconButton";
// import { Inventory } from "@/src/utils/types";
import useAuthorization from "@/src/hooks/useAuthorization";

type InventoryMaterialListProps = {
  materialFields: any;
  control: any;
  inventoryIndex: number;
  getSubLocationsListOptions: any;
  // handleCalculateQuantity: any;
  removeMaterialAndErrors: any;
  register: any;
  updateInventory: any;
  errors: any;
  setValue: any;
  getValues: any;
  // trigger: any;
};

const InventoryMaterialList = React.memo(
  ({
    materialFields,
    control,
    inventoryIndex,
    getSubLocationsListOptions,
    // handleCalculateQuantity,
    removeMaterialAndErrors,
    register,
    updateInventory,
    errors,
    setValue,
    getValues,
  }: InventoryMaterialListProps) => {
    const { isFieldsCraftAuthorized } = useAuthorization();

    const ref = useRef<HTMLDivElement>(null);
    const previousLength = useRef(materialFields.length);
    const listRef = useRef<List>(null);

    const MAX_HEIGHT = 400;
    const estimatedItemHeight = 70;
    const listHeight = Math.min(
      materialFields?.length * estimatedItemHeight,
      MAX_HEIGHT
    );

    const scrollToError = (index: number) => {
      if (listRef.current) {
        listRef.current.scrollToItem(index, "center");
      }
    };

    useEffect(() => {
      const firstErrorIndex = materialFields?.findIndex(
        (_: any, index: number) => {
          const materialError =
            errors?.inventories?.[inventoryIndex]?.materials?.[index];
          return (
            materialError?.name ||
            materialError?.costCode ||
            materialError?.unitOfMeasure
          );
        }
      );

      if (firstErrorIndex !== -1) {
        scrollToError(firstErrorIndex);
      }
    }, [errors]);

    useEffect(() => {
      if (listRef?.current) {
        if (materialFields?.length > previousLength?.current) {
          listRef?.current?.scrollToItem(materialFields.length - 1, "end");
        }
        previousLength.current = materialFields?.length;
      }
    }, [materialFields?.length]);

    const handleRemove = useCallback(
      (index: number) => {
        removeMaterialAndErrors(index);
        updateInventory();
      },
      [removeMaterialAndErrors, updateInventory]
    );

    const getItemSize = () => {
      return 50;
    };

    const checkForError = (
      inventoryIndex: number,
      materialIndex: number,
      keyName: string
    ) => {
      const materialValue = getValues(
        `inventories.[${inventoryIndex}].materials.[${materialIndex}]`
      );
      const errorMessage =
        "Cannot add the same material under the same sublocation.";
      if (
        errors?.inventories?.[inventoryIndex]?.materials?.[materialIndex]?.[
          keyName
        ]?.message === errorMessage
      ) {
        return errors?.inventories?.[inventoryIndex]?.materials?.[
          materialIndex
        ]?.[keyName];
      }
      return (
        !materialValue?.[keyName] &&
        errors?.inventories?.[inventoryIndex]?.materials?.[materialIndex]?.[
          keyName
        ]
      );
    };

    const renderRow = ({
      index,
      style,
    }: {
      index: number;
      style: React.CSSProperties;
    }) => {
      const materials = materialFields[index];
      const materialIndex = index;

      return (
        <div className="" style={style} key={materials?.id} ref={ref}>
          <div className="materials-first-row flex mb-3" key={materials?.id}>
            {/* Material Name Input */}
            <div className="col pr-4 col-xs-4">
              <Controller
                name={`inventories.[${inventoryIndex}].materials.[${materialIndex}].name`}
                control={control}
                render={() => {
                  return (
                    <div
                      key={materialIndex + `${inventoryIndex}`}
                      ref={
                        register(
                          `inventories.[${inventoryIndex}].materials.[${materialIndex}].name`
                        ).ref
                      }
                    >
                      <input
                        className={`custom-input`}
                        {...register(
                          `inventories.[${inventoryIndex}].materials.[${materialIndex}].name`
                        )}
                        disabled={isFieldsCraftAuthorized()}
                        placeholder="Material"
                        onChange={(e) =>
                          setValue(
                            `inventories.[${inventoryIndex}].materials.[${materialIndex}].name`,
                            e.target.value
                          )
                        }
                      />
                      {checkForError(inventoryIndex, materialIndex, "name") && (
                        <span className="block mt-1 text-error break-words">
                          {
                            checkForError(inventoryIndex, materialIndex, "name")
                              ?.message
                          }
                        </span>
                      )}
                    </div>
                  );
                }}
              />
            </div>
            <div className="col pr-4 col-xs-4">
              {/* Cost Code */}
              <Controller
                name={`inventories.[${inventoryIndex}].materials.[${materialIndex}].costCode`}
                control={control}
                render={() => {
                  // const inventoryError = (
                  //   errors?.inventories as unknown as
                  //     | FieldErrorsImpl<Inventory>[]
                  //     | undefined
                  // )?.[inventoryIndex];
                  // const materialError =
                  //   inventoryError?.materials?.[materialIndex];
                  return (
                    <div key={materialIndex + `${inventoryIndex}`}>
                      {/* <CustomInput
                            disabled={isFieldsCraftAuthorized()}
                            error={materialError?.costCode?.message}
                            {...field}
                            onChange={(value) => field.onChange(`${value}`)}
                            placeholder="Cost Code"
                          /> */}
                      <input
                        className={`custom-input`}
                        {...register(
                          `inventories.[${inventoryIndex}].materials.[${materialIndex}].costCode`
                        )}
                        disabled={isFieldsCraftAuthorized()}
                        placeholder="Cost Code"
                        onChange={(e) =>
                          setValue(
                            `inventories.[${inventoryIndex}].materials.[${materialIndex}].costCode`,
                            e.target.value
                          )
                        }
                      />
                      {checkForError(
                        inventoryIndex,
                        materialIndex,
                        "costCode"
                      ) && (
                        <span className="block mt-1 text-error break-words">
                          {
                            checkForError(
                              inventoryIndex,
                              materialIndex,
                              "costCode"
                            )?.message
                          }
                        </span>
                      )}
                    </div>
                  );
                }}
              />
            </div>

            {/* Quantity Input */}
            {/* <div className="col pr-4 col-xs-4">
              <Controller
                name={`inventories[${inventoryIndex}].materials[${materialIndex}].quantity`}
                control={control}
                render={({ field }) => (
                  <CustomInput
                    disabled
                    {...field}
                    onChange={(value) => {
                      // handleCalculateQuantity();
                      field.onChange(`${value}`);
                    }}
                    placeholder="Quantity"
                    min={0}
                    type="number"
                  />
                )}
              />
            </div> */}

            {/* Spares Input */}
            {/* <div className="col pr-4 col-xs-2">
              <Controller
                name={`inventories[${inventoryIndex}].materials[${materialIndex}].spares`}
                control={control}
                render={({ field }) => (
                  <CustomInput
                    disabled={isFieldsCraftAuthorized()}
                    {...field}
                    onChange={(value: string | number | boolean) => {
                      if (
                        typeof value !== "string" &&
                        typeof value !== "number"
                      )
                        return;
                      const numericValue = handleNumericInput(value);
                      field.onChange(numericValue);
                      handleCalculateQuantity();
                    }}
                    min={0}
                    type="number"
                  />
                )}
              />
            </div> */}

            {/* Sample Input */}
            {/* <div className="col pr-4 col-xs-2">
              <Controller
                name={`inventories[${inventoryIndex}].materials[${materialIndex}].sample`}
                control={control}
                render={({ field }) => (
                  <CustomInput
                    disabled={isFieldsCraftAuthorized()}
                    {...field}
                    onChange={(value: string | number | boolean) => {
                      if (
                        typeof value !== "string" &&
                        typeof value !== "number"
                      )
                        return;
                      const numericValue = handleNumericInput(value);
                      field.onChange(numericValue);
                      handleCalculateQuantity();
                    }}
                    min={0}
                    type="number"
                  />
                )}
              />
            </div> */}

            {/* Regular Input */}
            {/* <div className="col pr-4 col-xs-2">
              <Controller
                name={`inventories[${inventoryIndex}].materials[${materialIndex}].regular`}
                control={control}
                render={({ field }) => (
                  <CustomInput
                    disabled={isFieldsCraftAuthorized()}
                    {...field}
                    onChange={(value: string | number | boolean) => {
                      if (
                        typeof value !== "string" &&
                        typeof value !== "number"
                      )
                        return;
                      const numericValue = handleNumericInput(value);
                      field.onChange(numericValue);
                      handleCalculateQuantity();
                    }}
                    min={0}
                    type="number"
                  />
                )}
              />
            </div> */}

            {/* New Quantity Input */}
            <div className="col pr-4 col-xs-3">
              <Controller
                name={`inventories[${inventoryIndex}].materials[${materialIndex}].quantity`}
                control={control}
                render={({ field }) => (
                  <CustomInput
                    {...field}
                    disabled={isFieldsCraftAuthorized()}
                    onChange={(value) => field.onChange(value)}
                    placeholder="Quantity"
                    min={0}
                    type="number"
                  />
                )}
              />
            </div>

            {/* Unit of Measurement Input */}
            <div className="col pr-4 col-xs-4">
              <Controller
                name={`inventories.[${inventoryIndex}].materials.[${materialIndex}].unitOfMeasure`}
                control={control}
                render={() => {
                  // const inventoryError = (
                  //   errors?.inventories as unknown as
                  //     | FieldErrorsImpl<Inventory>[]
                  //     | undefined
                  // )?.[inventoryIndex];
                  // const materialError =
                  //   inventoryError?.materials?.[materialIndex];
                  return (
                    // <CustomInput
                    //   disabled={isFieldsCraftAuthorized()}
                    //   error={materialError?.unitOfMeasure?.message}
                    //   {...field}
                    //   onChange={(value) => field.onChange(`${value}`)}
                    //   placeholder="Unit of Measurement"
                    // />
                    <div key={materialIndex + `${inventoryIndex}`}>
                      <input
                        className={`custom-input`}
                        {...register(
                          `inventories.[${inventoryIndex}].materials.[${materialIndex}].unitOfMeasure`
                        )}
                        disabled={isFieldsCraftAuthorized()}
                        placeholder="FT"
                        onChange={(e) =>
                          setValue(
                            `inventories.[${inventoryIndex}].materials.[${materialIndex}].unitOfMeasure`,
                            e?.target?.value
                          )
                        }
                      />
                      {checkForError(
                        inventoryIndex,
                        materialIndex,
                        "unitOfMeasure"
                      ) && (
                        <span className="block mt-1 text-error break-words">
                          {
                            checkForError(
                              inventoryIndex,
                              materialIndex,
                              "unitOfMeasure"
                            )?.message
                          }
                        </span>
                      )}
                    </div>
                  );
                }}
              />
            </div>

            {/* IsRefillable Dropdown */}
            <div className="col pr-4 col-xs-2">
              <Controller
                name={`inventories[${inventoryIndex}].materials[${materialIndex}].isRefillable`}
                control={control}
                render={({ field }) => (
                  <Select
                    {...field}
                    size="large"
                    placeholder="No"
                    style={{ width: "100%" }}
                    onChange={(value) => field.onChange(value || null)}
                    options={[
                      { label: "Yes", value: true },
                      { label: "No", value: false },
                    ]}
                  />
                )}
              />
            </div>

            <div className="col pr-4 col-xs-6">
              <Controller
                name={`inventories[${inventoryIndex}].materials[${materialIndex}].subLocationId`}
                control={control}
                render={({ field }) => (
                  <Select
                    {...field}
                    size="large"
                    placeholder="Sublocation"
                    style={{ width: "100%" }}
                    onChange={(value) => field.onChange(value || null)}
                    options={getSubLocationsListOptions(inventoryIndex)}
                  />
                )}
              />
            </div>

            {/* Delete Button */}
            {!isFieldsCraftAuthorized() && (
              <div className="w-full xs:w-1/12">
                <DeleteIconButton
                  disabled={materialFields.length === 1}
                  handleDelete={() => handleRemove(materialIndex)}
                />
              </div>
            )}
          </div>
          {/* <hr className="" style={{ color: "#E2E4E9" }} key={materials?.id} /> */}
        </div>
      );
    };

    return (
      <>
        <List
          ref={listRef}
          height={listHeight}
          itemCount={materialFields?.length}
          itemSize={getItemSize}
          width={"100%"}
          className="list-scroll-container"
        >
          {renderRow}
        </List>
      </>
    );
  }
);

export default InventoryMaterialList;
