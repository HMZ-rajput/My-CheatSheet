import {
  createInventory,
  deleteInventoryById,
  editInventoryById,
  InventoryEndpoints,
} from "@/src/apis/inventoryApis";
import { getLocationslist } from "@/src/apis/locationApis";
import { getAllStorageTypes } from "@/src/apis/storageTypeApis";
import CreatedByUserBadge from "@/src/components/common/CreatedByUserBadge";
import CustomAlert from "@/src/components/common/CustomAlert";
import CustomFormLabel from "@/src/components/common/CustomFormLabel";
import CustomIcon from "@/src/components/common/CustomIcon";
import CustomOverlayLoader from "@/src/components/common/CustomOverlayloader";
import DeleteIconButton from "@/src/components/icon-buttons/DeleteIconButton";
import { initialInventoryMaterials } from "@/src/data/intialsValues";
import { InventoryValidationSchema } from "@/src/data/validationsSchema";
import { getLowerCasedMaterialName } from "@/src/external-modules/bulk-upload/bulk-upload-utils";
import BulkUploadButton from "@/src/external-modules/bulk-upload/BulkUploadButton";
import BulkUploaderParser from "@/src/external-modules/bulk-upload/BulkUploadParser";
import LocationModal from "@/src/features/locations/components/LocationModal";
import { useAppDispatch } from "@/src/hooks/useAppDispatch";
import { useAppSelector } from "@/src/hooks/useAppSelector";
import useAuthorization from "@/src/hooks/useAuthorization";
import {
  getInventoriesState,
  resetState,
} from "@/src/store/slices/inventorySlice";
import { getLocationsState } from "@/src/store/slices/locationSlice";
import { call } from "@/src/utils/api-helpers";
import {
  InventoriesList,
  Inventory,
  LabelSupportedInventoryMaterial,
} from "@/src/utils/types";
import { PlusOutlined } from "@ant-design/icons";
import { yupResolver } from "@hookform/resolvers/yup";
import { Button, Divider, Flex, Form, Select, Space } from "antd";
import { useEffect, useMemo, useState } from "react";
import { Controller, Resolver, useFieldArray, useForm } from "react-hook-form";
import { useParams } from "react-router-dom";
import InventoryMaterials from "./InventoryMaterials";
import { mapInventoryMaterials } from "../inventory-helpers";

type FormValues = {
  projectId: string;
  inventories: Inventory[];
};

type Props = {
  inventories: Inventory[];
  handleBackToTable: () => void;
};

const InventoryDetailForm = ({ handleBackToTable, inventories }: Props) => {
  const { isFieldsCraftAuthorized } = useAuthorization();
  const [_, setSelectedLocation] = useState<string | null>(null);
  const [actionType, setActionType] = useState("");
  const [isDeleting, setIsDeleting] = useState(false);
  const [isMaterialsFetch, setIsMaterialFetch] = useState(false);

  const {
    inventories: inventoryData,
    successMessage,
    resError,
    reqError,
    createdBy,
    modifiedBy,
    lastModifiedBy,
    lastModifiedDate,
  } = useAppSelector(getInventoriesState);

  const [isLocationModalOpen, setIsLocationModalOpen] = useState<{
    open: boolean;
    title?: string | null;
    field?: string;
  }>({ open: false, title: null, field: "" });

  const { projectId } = useParams();
  const dispatch = useAppDispatch();
  const { locationsList } = useAppSelector(getLocationsState);

  useEffect(() => {
    if (projectId) {
      dispatch(getLocationslist(projectId));
    }
  }, [projectId, dispatch]);

  const locationsListOptions = useMemo(() => {
    return [
      {
        value: "",
        label: "Select Location",
      },
      ...(locationsList?.map((f) => ({
        value: f.id,
        label: f.name,
      })) || []),
    ];
  }, [locationsList]);

  const handleDeleteInventoryById = async () => {
    try {
      setIsDeleting(true);
      await dispatch(deleteInventoryById(projectId || "")).unwrap();
      dispatch(resetState());
      handleBackToTable();
    } catch (error) {
      console.error("Error deleting project:", error);
    } finally {
      setIsDeleting(false);
    }
  };

  const {
    reset,
    control,
    handleSubmit,
    setValue,
    getValues,
    watch,
    register,

    formState: { isSubmitting, errors },
  } = useForm<FormValues>({
    resolver: yupResolver(
      InventoryValidationSchema
    ) as unknown as Resolver<FormValues>,
    defaultValues: {
      projectId: projectId,
      inventories: inventories?.length
        ? inventories
        : initialInventoryMaterials,
    },
    mode: "all",
  });

  const {
    fields: inventoryFields,
    append: appendInventory,
    remove: removeInventory,
    update: updateInventory,
  } = useFieldArray({
    control,
    name: "inventories",
  });
  const getSubLocationsListOptions = (inventoryIndex: number) => {
    const selectedLocationId = getValues(
      `inventories.${inventoryIndex}.locationId`
    );

    const selectedLocation = locationsList?.find(
      (location) => location.id === selectedLocationId
    );

    return [
      {
        value: "",
        label: "Select Sublocation",
      },
      ...(selectedLocation?.subLocations?.map((subLocation) => ({
        value: subLocation.id,
        label: subLocation.name,
      })) || []),
    ];
  };

  const fetchPRMaterials = async (projectId: string, locationId: string) => {
    const res: InventoriesList = await call({
      url: `${InventoryEndpoints.GET_ALL_INVENTORY}/${projectId}?LocationId=${locationId}`,
      method: "GET",
    });
    return res;
  };

  const handleLocationChange = async (
    inventoryIndex?: number,
    value?: string
  ) => {
    setSelectedLocation(value as string);

    try {
      setIsMaterialFetch(true);
      const res = await fetchPRMaterials(projectId || "", value || "");

      setValue(
        `inventories[${inventoryIndex}].materials` as any,
        res?.inventories?.[0]?.materials ||
          initialInventoryMaterials?.[0]?.materials
      );
    } catch (err) {
      console.error("error", err);
    } finally {
      setIsMaterialFetch(false);
      dispatch(resetState());
    }
  };

  const selectedLocationIds =
    getValues("inventories")?.map((inventory) => inventory?.locationId) || [];

  const getFilteredLocationOptions = (inventoryIndex: number) => {
    const currentLocationId = selectedLocationIds[inventoryIndex];

    return locationsListOptions
      ?.map((option) => ({
        ...option,
        disabled:
          option.value === "" ||
          (option.value !== currentLocationId &&
            selectedLocationIds.includes(option.value)),
      }))
      .filter(
        (option) =>
          option.value === currentLocationId ||
          !selectedLocationIds.includes(option.value)
      );
  };

  const handleSave = async (data: FormValues) => {
    const req = {
      projectId: data.projectId,
      inventories: mapInventoryMaterials(data.inventories),
    };

    if (req?.inventories?.length === 0) {
      return await dispatch(createInventory(req)).unwrap();
    } else {
      return await dispatch(editInventoryById(req)).unwrap();
    }
  };

  const onSubmit = async (data: FormValues) => {
    try {
      if (actionType === "save") {
        const res = await handleSave(data);
        if (res.isSuccess) {
          console.log("res.isSuccess ran");
          reset({
            projectId,
            inventories: res?.inventories || null,
          });
        }
      } else if (actionType === "saveAndClose") {
        const res = await handleSave(data);
        if (res?.isSuccess) {
          handleBackToTable();
        }
      }
    } catch (error) {
      console.error("Error during form submission:", error);
    }
  };

  useEffect(() => {
    dispatch(resetState());
  }, []);
  useEffect(() => {
    if (Array.isArray(inventoryData) && inventoryData?.length > 0) {
      reset({ inventories: inventoryData, projectId });
    }
  }, []);

  useEffect(() => {
    if (isLocationModalOpen?.open) {
      dispatch(getAllStorageTypes());
    } else {
      dispatch(getLocationslist(getValues("projectId") || ""));
    }
  }, [dispatch, isLocationModalOpen?.open]);

  const handleOpenLocationModal = (title: string, field: string) => {
    setIsLocationModalOpen({
      title: title,
      open: true,
      field: field,
    });
  };

  const [resetBulkUploadFile, setBulkUploadFile] = useState(0);

  async function updateMaterials(file: File, inventoryIndex: number) {
    const bulkUploadParser = new BulkUploaderParser<
      LabelSupportedInventoryMaterial[]
    >();
    const rows = await bulkUploadParser.readAndParseAsync(file, [
      "sublocation",
    ]);

    const sublocations = getSubLocationsListOptions(inventoryIndex);

    const isValid = await bulkUploadParser.validateMaterials<
      LabelSupportedInventoryMaterial[]
    >({
      rows,
      schema: {
        material: "alphanumericString",
        costCode: "alphanumericString",
        unitOfMeasurement: "alphanumericString",
        quantity: "number",
        refillable: "string",
        sublocation: "alphanumericString",
      },
      sublocations: sublocations?.map((f) => ({
        id: (f.value || "")?.toLowerCase(),
        name: (f.label || "")?.toLowerCase(),
      })),
      stringToBooleanKeys: ["refillable"],
      requiredKeys: ["material", "costCode", "unitOfMeasurement"],
    });

    setBulkUploadFile(Date.now());

    if (!isValid) {
      return;
    }

    rows.forEach((m) => {
      const sublocationId = sublocations.find(
        (f) =>
          (f.label?.toLowerCase() || "") ===
          `${m.sublocation?.toLowerCase() || ""}`
      )?.value;

      const isRefillableString = `${m.refillable}`?.toLowerCase();

      let isRefillableBoolean = false;
      if (isRefillableString === "yes" || isRefillableString === "true") {
        isRefillableBoolean = true;
      } else if (
        isRefillableString === "no" ||
        isRefillableString === "false"
      ) {
        isRefillableBoolean = false;
      }

      if (sublocationId) {
        m.subLocationId = sublocationId;
      }

      m.unitOfMeasure = m?.unitOfMeasurement;
      m.name = m.material;
      m.isRefillable = isRefillableBoolean;
    });

    reset((values) => {
      const valuesCopy = { ...values };
      const inventory =
        (valuesCopy.inventories || [])?.[inventoryIndex] || null;

      if (inventory) {
        let materials = [];
        const oldMaterials =
          inventory?.materials?.filter((f) => getLowerCasedMaterialName(f)) ||
          [];

        if (oldMaterials?.length) {
          materials = bulkUploadParser.mergeMaterials({
            oldMaterials,
            newMaterials: rows,
            keysToBeUpdated: ["quantity"],
          });
          inventory.materials = materials;
        } else {
          inventory.materials = rows;
        }
      }

      return valuesCopy;
    });
  }
  return (
    <>
      <LocationModal
        setLocationValue={setValue}
        projectId={getValues("projectId")}
        isLocationModalOpen={isLocationModalOpen}
        setIsLocationModalOpen={setIsLocationModalOpen}
      />
      <Form
        onFinish={handleSubmit(onSubmit)}
        disabled={isFieldsCraftAuthorized()}
        layout="vertical"
      >
        {inventoryFields?.map((inventory, inventoryIndex) => (
          <div key={inventory.id} style={{ marginBottom: 20 }}>
            <div className="materials-first-row flex items-center">
              <div className="col pr-4  col-xs-21">
                <div className="!font-medium flex gap-3 items-center text-lg">
                  <CustomIcon type="inventory-list" className="fill-white" />{" "}
                  {`Location ${inventoryIndex + 1} Inventory`}
                </div>
              </div>
              <div className="flex items-center gap-4">
                {!isFieldsCraftAuthorized() && (
                  <>
                    <BulkUploadButton
                      disabled={
                        !getValues(`inventories.${inventoryIndex}.locationId`)
                      }
                      updateMaterialsCallback={(file) =>
                        updateMaterials(file, inventoryIndex)
                      }
                      shouldReset={resetBulkUploadFile}
                    />
                    <DeleteIconButton
                      disabled={inventoryFields.length === 1}
                      handleDelete={() => {
                        removeInventory(inventoryIndex);
                      }}
                    />
                  </>
                )}
              </div>
            </div>
            <div className="mt-3"></div>
            <Controller
              name={`inventories.${inventoryIndex}.locationId`}
              control={control}
              render={({ field, formState: { errors } }) => (
                <Form.Item
                  help={
                    errors?.inventories?.[inventoryIndex]?.locationId
                      ?.message as string
                  }
                  validateStatus={
                    errors?.inventories?.[inventoryIndex]?.locationId
                      ? "error"
                      : ""
                  }
                >
                  <CustomFormLabel text="Location" required />
                  <Select
                    disabled={isFieldsCraftAuthorized()}
                    className="mt-3"
                    {...field}
                    placeholder="Select Location"
                    options={getFilteredLocationOptions(inventoryIndex)}
                    onChange={(value) => {
                      field.onChange(value);

                      handleLocationChange(inventoryIndex, value);
                    }}
                    showSearch
                    filterOption={(input, option) =>
                      (option?.label || "")
                        .toLowerCase()
                        .includes(input.toLowerCase())
                    }
                    dropdownRender={(menu) => (
                      <>
                        {menu}
                        <Divider className="mt-2 mb-1" />
                        <Space className="p-1">
                          <Button
                            type="text"
                            icon={<PlusOutlined />}
                            onClick={() =>
                              handleOpenLocationModal(
                                "Add New Location",
                                `inventories.${inventoryIndex}.locationId`
                              )
                            }
                          >
                            Add New Location
                          </Button>
                        </Space>
                      </>
                    )}
                  />
                </Form.Item>
              )}
            />
            {isMaterialsFetch ? (
              <>
                <CustomOverlayLoader />
              </>
            ) : (
              <InventoryMaterials
                errors={errors}
                register={register}
                getValues={getValues}
                updateInventory={updateInventory}
                control={control}
                inventoryIndex={inventoryIndex}
                getSubLocationsListOptions={getSubLocationsListOptions}
                watch={watch}
                inventories={inventories}
                setValue={setValue}
              />
            )}
          </div>
        ))}

        {!isFieldsCraftAuthorized() && (
          <Button
            size="large"
            icon={<CustomIcon type="plus" />}
            onClick={() =>
              appendInventory({
                locationId: "",
                materials: [
                  {
                    name: "",
                    costCode: "",
                    quantity: 0,
                    isRefillable: false,
                    subLocationId: null,
                    unitOfMeasure: "",
                  },
                ],
              })
            }
          >
            Add Products to New Location
          </Button>
        )}
        {(reqError || resError || successMessage) && (
          <CustomAlert
            message={reqError || resError || successMessage || ""}
            type={successMessage ? "success" : "error"}
          />
        )}
        <div className="mt-10"></div>
        {isFieldsCraftAuthorized() ? (
          <>
            <Flex justify="flex-end">
              <Button
                disabled={isSubmitting || isDeleting}
                type="default"
                onClick={handleBackToTable}
              >
                Back
              </Button>
            </Flex>
          </>
        ) : (
          <Flex justify="flex-end" className="gap-4">
            <Button
              disabled={isSubmitting || isDeleting}
              type="default"
              onClick={handleBackToTable}
            >
              Cancel
            </Button>
            {getValues("inventories").some((inventory) =>
              inventory.materials[0].materialId ? true : false
            ) && (
              <Button
                loading={isDeleting}
                disabled={isSubmitting || isDeleting}
                type="default"
                onClick={handleDeleteInventoryById}
              >
                {isDeleting ? "Deleting.." : "Delete"}
              </Button>
            )}
            <Button
              loading={actionType === "save" && isSubmitting}
              disabled={isSubmitting || isDeleting}
              type="primary"
              htmlType="submit"
              onClick={() => setActionType("save")}
            >
              {actionType === "save" && isSubmitting ? "Saving.." : "Save"}
            </Button>

            <Button
              loading={actionType === "saveAndClose" && isSubmitting}
              disabled={isSubmitting || isDeleting}
              type="primary"
              htmlType="submit"
              onClick={() => setActionType("saveAndClose")}
            >
              {actionType === "saveAndClose" && isSubmitting
                ? "Saving and closing.."
                : "Save & Close"}
            </Button>
          </Flex>
        )}
        <div className="mt-5"></div>
        {getValues("inventories").length > 0 &&
          getValues("inventories").some(
            (inventory) => inventory.materials[0].materialId
          ) && (
            <Flex justify="flex-end">
              <CreatedByUserBadge
                //@ts-ignore
                userName={modifiedBy == null ? createdBy : lastModifiedBy}
                date={lastModifiedDate}
                isModifiedBadge={modifiedBy == null ? false : true}
              />
            </Flex>
          )}
      </Form>
    </>
  );
};

export default InventoryDetailForm;
