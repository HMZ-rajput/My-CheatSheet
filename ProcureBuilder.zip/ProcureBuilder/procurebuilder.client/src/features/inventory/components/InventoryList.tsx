import CustomTable from "@/src/components/table/CustomTable";
import SectionLayout from "@components/layout/SectionLayout";
import { TableProps } from "antd";
import { useEffect, useMemo, useState } from "react";

import { getInventoryListByProjectId } from "@/src/apis/inventoryApis";
import CustomButton from "@/src/components/common/CustomButton";
import CustomIcon from "@/src/components/common/CustomIcon";
import CustomTableFilters, {
  CustomFiltersType,
} from "@/src/components/table/CustomTableFilters";
import { useAppDispatch } from "@/src/hooks/useAppDispatch";
import { useAppSelector } from "@/src/hooks/useAppSelector";
import useAuthorization from "@/src/hooks/useAuthorization";
import { useDebouncedCallback } from "@/src/hooks/useDebouncedCallback";
import { getInventoriesState } from "@/src/store/slices/inventorySlice";
import { call } from "@/src/utils/api-helpers";
import {
  allInventoryLocationsOption,
  allInventorySublocationsOption,
} from "@/src/utils/constants";
import { InventoryMaterial, LocationsList } from "@/src/utils/types";
import { EyeOutlined } from "@ant-design/icons";
import { useParams } from "react-router-dom";
type Props = {
  name?: string;
  data?: InventoryMaterial[];
  handleEdit: (getDataAgain?: boolean) => void;
  Loading?: boolean;
};

export default function InventoryList({
  data,
  handleEdit,
  name,
  Loading,
}: Props) {
  const { isFieldsCraftAuthorized } = useAuthorization();
  const [searchTerm, setSearchTerm] = useState(name || "");
  const [hasSearched, setHasSearched] = useState(false);
  const [previousSearchTerm, setPreviousSearchTerm] = useState("");
  const [isEditBtnLoading, setIsEditBtnLoading] = useState(false);
  const [isFirstCall, setIsFirstCall] = useState(false);

  const {
    isLoading,
    totalCount,
    currentPage: inventoryCurrentPage,
    pageSize: inventoryPageSize,
  } = useAppSelector(getInventoriesState);
  const [page, setPage] = useState<number>(inventoryCurrentPage);
  const [pageSize, setPageSize] = useState(inventoryPageSize);

  const urlParams = new URLSearchParams(window.location.search);
  const locationIdFromQueryParams = urlParams.get("locationId");

  const TopSectionLayout = () => {
    return (
      <div>
        <div className="flex w-full justify-between items-center mb-8">
          <h1 className="text-lg">Inventory</h1>
          <div className="flex gap-3">
            <CustomButton
              disabled={isLoading}
              loading={isEditBtnLoading}
              className="hover:!fill-primary"
              onClick={() => {
                setIsEditBtnLoading(true);
                handleEdit(true);
              }}
              variant="outlined"
              icon={
                isFieldsCraftAuthorized() ? (
                  <EyeOutlined />
                ) : (
                  <CustomIcon type="edit" />
                )
              }
            >
              {isFieldsCraftAuthorized() ? "View" : "Edit"}
            </CustomButton>
          </div>
        </div>
      </div>
    );
  };

  const { projectId } = useParams();

  const [filters, setFilters] = useState<CustomFiltersType>({});
  const [locationsList, setLocationsList] = useState<LocationsList[]>([]);
  const dispatch = useAppDispatch();
  useEffect(() => {
    const fetchLocationslist = async () => {
      try {
        const response = await call<
          {
            locations: LocationsList[];
          } & Response
        >({
          url: `locations/list?projectId=${projectId}`,
          method: "GET",
        });

        setLocationsList(response?.locations);
      } catch (err) {
        console.log("error", err);
      } finally {
        // setSubmitting(false);
      }
    };
    fetchLocationslist();
  }, [locationIdFromQueryParams]);

  const locationsListOptions = useMemo(() => {
    return [
      allInventoryLocationsOption,
      ...(locationsList?.map((f) => ({
        value: f.id,
        label: f.name,
      })) || []),
    ];
  }, [locationsList]);
  const subLocationListOptions = useMemo(() => {
    const selectedLocationId = filters?.Location?.value;
    return [
      allInventorySublocationsOption,
      ...(locationsList
        ?.filter((f) => {
          if (selectedLocationId !== allInventoryLocationsOption.value) {
            return f.id === selectedLocationId;
          } else {
            return true;
          }
        })
        ?.flatMap((location) => location.subLocations)
        ?.map((f) => ({
          value: f?.id,
          label: f?.name,
        })) || []),
    ];
  }, [locationsList, filters?.Location?.value]);

  useEffect(() => {
    // @ts-ignore
    setFilters((prevFilters) => {
      const newLocationValue = allInventoryLocationsOption?.value;
      const newSubLocationValue = allInventorySublocationsOption?.value;

      const currentLocation = prevFilters?.Location || {
        value: null,
        options: [],
      };
      const currentSubLocations = prevFilters?.subLocations || {
        value: null,
        options: [],
      };
      if (
        currentLocation.value === newLocationValue &&
        currentSubLocations.value === newSubLocationValue &&
        JSON.stringify(currentLocation.options) ===
          JSON.stringify(locationsListOptions) &&
        JSON.stringify(currentSubLocations.options) ===
          JSON.stringify(subLocationListOptions)
      ) {
        return prevFilters;
      }

      return {
        Location: {
          value: currentLocation.value || newLocationValue,
          options: locationsListOptions,
        },
        subLocations: {
          value: currentSubLocations.value || newSubLocationValue,
          options: subLocationListOptions,
        },
      };
    });
  }, [locationsListOptions, subLocationListOptions]);

  const columns: TableProps<InventoryMaterial>["columns"] = [
    {
      title: "Material",
      dataIndex: "name",
      key: "name",
      sorter: (a, b) => a.name?.localeCompare(b.name),
    },
    {
      title: "Cost Code",
      dataIndex: "costCode",
      key: "costCode",
      sorter: (a, b) => a.name?.localeCompare(b.name),
    },
    {
      title: "Sublocation",
      dataIndex: "subLocationName",
      key: "subLocationName",
      sorter: (a, b) => a.name?.localeCompare(b.name),
    },
    {
      title: "Quantity",
      dataIndex: "quantity",
      key: "quantity",
      sorter: (a, b) => {
        return Number(a.quantity) - Number(b.quantity);
      },
    },
    {
      title: "Unit of Measurement",
      dataIndex: "unitOfMeasure",
      key: "unitOfMeasure",
      sorter: (a, b) => a.name?.localeCompare(b.name),
    },
  ];

  async function getResults(pageNumber: number) {
    const LocationId =
      filters?.Location?.value === allInventoryLocationsOption.value
        ? null
        : filters.Location?.value;

    const SubLocationId =
      filters?.subLocations?.value === allInventorySublocationsOption?.value
        ? null
        : filters.subLocations?.value;

    await dispatch(
      getInventoryListByProjectId({
        projectId: projectId || "",
        LocationId,
        search: searchTerm || undefined,
        pageNumber: pageNumber || page,
        pageSize,
        SubLocationId,
      })
    ).unwrap();

    if (searchTerm === "") {
      setHasSearched(false);
    }
  }

  const handleGetResults = useDebouncedCallback(getResults, 100);

  useEffect(() => {
    handleGetResults();
  }, [filters?.Location?.value, filters?.subLocations?.value]);

  const handleSearch = () => {
    if (searchTerm !== previousSearchTerm) {
      setHasSearched(true);
      handleGetResults();
      setPreviousSearchTerm(searchTerm);
    }
  };

  // Debounce the searchTerm change
  useEffect(() => {
    if (!name) {
      if (!hasSearched) return;
    }
    const timer = setTimeout(() => {
      if (
        (searchTerm === "" && previousSearchTerm !== "") ||
        searchTerm === ""
      ) {
        handleGetResults();
        setPreviousSearchTerm(searchTerm);
      }
    }, 500);

    return () => {
      clearTimeout(timer);
    };
  }, [searchTerm, hasSearched, previousSearchTerm]);

  useEffect(() => {
    if (
      isFirstCall ||
      inventoryCurrentPage !== page ||
      inventoryPageSize !== pageSize
    ) {
      handleGetResults();

      if (isFirstCall) {
        setIsFirstCall(false);
      }
    }
  }, [page, pageSize, isFirstCall]);

  useEffect(() => {
    if (locationIdFromQueryParams) {
      // setDisplayForm(false);
      setFilters((prevFilters) => ({
        ...prevFilters,
        Location: {
          value: locationIdFromQueryParams,
          options: locationsListOptions,
        },
      }));
    } else {
      setFilters((prevFilters) => ({
        ...prevFilters,
        Location: {
          value: allInventoryLocationsOption.value,
          options: locationsListOptions,
        },
      }));
    }
  }, [locationIdFromQueryParams]);

  return (
    <>
      <SectionLayout>
        <CustomTable
          searchPlaceholder={"Search by Material Name or Cost Code"}
          handleSearch={handleSearch}
          customTopLayout={<TopSectionLayout />}
          data={data || []}
          columns={columns || []}
          searchTerm={searchTerm}
          setSearchTerm={setSearchTerm}
          totalCount={totalCount}
          page={page}
          setPage={setPage}
          pageSize={pageSize}
          setPageSize={setPageSize}
          isLoading={Loading ? Loading : isLoading}
          filterElements={
            <CustomTableFilters filters={filters} setFilters={setFilters} />
          }
          filterElementContainFullWidth={true}
          hasSearch={false}
          hasSearchInNextLine={true}
          hasPagination={true}
        />
      </SectionLayout>
    </>
  );
}
