import React from "react";
import { useNavigate } from "react-router-dom";
import { Button, Typography } from "antd";
import routePaths from "@/src/utils/routePaths";

const NotFoundPage: React.FC = () => {
  const navigate = useNavigate();

  const handleGoBack = () => {
    navigate(routePaths.LOGIN);
  };

  return (
    <section className="flex flex-col items-center justify-center h-[calc(100vh-80px)] text-center">
      <Typography.Title
        level={1}
        className="!text-7xl !font-bold !text-primaryActive !mb-0"
      >
        404
      </Typography.Title>
      <Typography.Title level={4} className="!my-0">
        Page Not Found
      </Typography.Title>
      <Typography.Text className="!text-lg !my-3 block">
        The page you're looking for doesn't exist.
      </Typography.Text>

      <Button
        type="primary"
        size="large"
        onClick={handleGoBack}
        className="mt-3"
      >
        Go Back to Home
      </Button>
    </section>
  );
};

export default NotFoundPage;
