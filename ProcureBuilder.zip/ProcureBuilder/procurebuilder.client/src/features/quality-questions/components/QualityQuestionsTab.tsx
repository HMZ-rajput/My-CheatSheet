import { getAllQuestions } from "@/src/apis/questionApis";
import CustomIcon from "@/src/components/common/CustomIcon";
import CustomOverlayLoader from "@/src/components/common/CustomOverlayloader";
import SectionLayout from "@/src/components/layout/SectionLayout";
import { useAppDispatch } from "@/src/hooks/useAppDispatch";
import { useAppSelector } from "@/src/hooks/useAppSelector";
import { getQuestionsState } from "@/src/store/slices/questionsSlice";
import { QualityQuestion } from "@/src/utils/types";
import QualityQuestionsImg from "@assets/images/quality-questions/help-orange.png";
import { Button, Flex } from "antd";
import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import QualityQuestionsDetailsForm from "./QualityQuestionsDetailsForm";
import useAuthorization from "@/src/hooks/useAuthorization";

// type LocationTabProps = {}
export default function QualityQuestionsTab() {
  const dispatch = useAppDispatch();
  const { isFieldsCraftAuthorized } = useAuthorization();
  const { projectId } = useParams();
  const { questionsData } = useAppSelector(getQuestionsState);
  const [isLoading, setIsLoading] = useState(true);
  const [responseQuestions, setResponseQuestions] = useState<
    QualityQuestion[] | null
  >([]);

  const qualityQuestions =
    questionsData?.qualityQuestions?.map((question) => ({
      id: question.id,
      question: question.question,
    })) || [];

  const [displayForm, setDisplayForm] = useState(false);

  const getAllQuestionsByProjectId = async () => {
    try {
      const res = await dispatch(
        getAllQuestions({
          projectId: projectId || "",
        })
      ).unwrap();

      if (Boolean(res?.qualityQuestions?.length)) {
        setDisplayForm(true);
      }
    } catch (err) {
      console.log("error", err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    getAllQuestionsByProjectId();
  }, []);

  const NoQualityQuestionsSection = (
    <>
      <SectionLayout>
        <SectionLayout
          className="p-8 rounded-xl items-center max-h-64"
          borderStyle="dashed"
        >
          <img
            src={QualityQuestionsImg}
            width="48"
            height="48"
            className="mb-5"
          />

          <h6 className="font-medium text-sm !mb-1">
            Set Up Quality Questions
          </h6>

          <p className="font-normal text-xs mb-5 text-neutral-7 text-center">
            Quality questions have not been added yet. Please add <br />
            quality questions to get started.
          </p>

          {!isFieldsCraftAuthorized() && (
            <Flex className="gap-5">
              <Button
                size="large"
                className="hover:!fill-primary"
                icon={<CustomIcon type="plus" />}
                onClick={() => {
                  setDisplayForm(true);
                }}
              >
                Add Quality Questions
              </Button>
            </Flex>
          )}
        </SectionLayout>
      </SectionLayout>
    </>
  );

  if (isLoading) {
    return <CustomOverlayLoader />;
  }

  return (
    <>
      {displayForm ? (
        <QualityQuestionsDetailsForm
          displayForm={displayForm}
          questions={questionsData}
          qualityQuestions={qualityQuestions}
          responseQuestions={responseQuestions}
          setResponseQuestions={setResponseQuestions}
          handleCancelForm={() => setDisplayForm(false)}
        />
      ) : (
        NoQualityQuestionsSection
      )}
    </>
  );
}
