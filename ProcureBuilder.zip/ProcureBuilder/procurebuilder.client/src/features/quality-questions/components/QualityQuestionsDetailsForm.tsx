// import CreatedByUserBadge from "@/src/components/common/CreatedByUserBadge";
import CustomIcon from "@/src/components/common/CustomIcon";
import { useAppSelector } from "@/src/hooks/useAppSelector";
import { getUserFullName } from "@/src/store/slices/userSlice";
import SectionLayout from "@components/layout/SectionLayout";
import { useAppDispatch } from "@hooks/useAppDispatch";
import { getConsistentSpacing } from "@utils/theme-helpers";
import { Button, Col, Flex, Form, Input, Row, Tooltip, Typography } from "antd";
// import { useFormik } from "formik";
import {
  createQuestion,
  deleteQuestions,
  editQuestions,
} from "@/src/apis/questionApis";
import CreatedByUserBadge from "@/src/components/common/CreatedByUserBadge";
import DeleteIconButton from "@/src/components/icon-buttons/DeleteIconButton";
import {
  getQuestionsState,
  resetState,
} from "@/src/store/slices/questionsSlice";
import { OnlyQuestion, QualityQuestion } from "@/src/utils/types";
import { useParams } from "react-router-dom";
import * as Yup from "yup";
// import {
//   getHelpMessageInQualityQuestions,
//   getValidateStatusInQualityQuestions,
// } from "@/src/utils/errorHelpers";
import CustomAlert from "@/src/components/common/CustomAlert";
import useAuthorization from "@/src/hooks/useAuthorization";
import { yupResolver } from "@hookform/resolvers/yup";
import { useEffect, useState } from "react";
import { Controller, Resolver, useFieldArray, useForm } from "react-hook-form";

type QualityQuestionDetailsFormProps = {
  questions?: OnlyQuestion | null;
  displayForm?: boolean;
  qualityQuestions: {
    id: string | null;
    question: string;
  }[];
  handleCancelForm: () => void;
  responseQuestions: QualityQuestion[] | null;
  setResponseQuestions: React.Dispatch<
    React.SetStateAction<QualityQuestion[] | null>
  >;
};

type FieldValues = {
  qualityQuestions: QualityQuestion[];
};

export default function QualityQuestionsDetailsForm({
  // qualityQuestions,
  questions,
  handleCancelForm,
  responseQuestions,
  setResponseQuestions,
}: QualityQuestionDetailsFormProps) {
  const { resError, reqError, successMessage } =
    useAppSelector(getQuestionsState);
  const { isFieldsCraftAuthorized } = useAuthorization();

  const [actionType, setActionType] = useState("");
  const [isDeleting, setIsDeleting] = useState(false);
  const userFullName = useAppSelector(getUserFullName);

  const dispatch = useAppDispatch();
  // const navigate = useNavigate();
  const { projectId } = useParams();

  // console.log(questions?.qualityQuestions, "quality questions from get API");

  const validationSchema = Yup.object().shape({
    qualityQuestions: Yup.array()
      .of(
        Yup.object({
          question: Yup.string().required("Question is required."),
        })
      )
      .min(1, "At least one question is required.")
      .required("At least one question is required."),
  });

  const {
    handleSubmit,
    control,
    formState: { errors, isSubmitting },
  } = useForm<FieldValues>({
    resolver: yupResolver(validationSchema) as unknown as Resolver<FieldValues>,
    defaultValues: {
      qualityQuestions: ((
        questions?.qualityQuestions ||
        responseQuestions ||
        []
      )?.length > 0 &&
        (questions?.qualityQuestions
          ? questions?.qualityQuestions
          : responseQuestions)) || [{ question: "" }],
    },
  });

  const { fields, append, remove } = useFieldArray({
    control,
    name: "qualityQuestions",
  });

  const handleSave = async (data: OnlyQuestion) => {
    if ((questions?.qualityQuestions || responseQuestions || []).length > 0) {
      const editedData = data?.qualityQuestions?.map((question) => {
        return {
          id: question?.qualityQuestionId ? question.qualityQuestionId : null,
          question: question.question,
        };
      });
      return await dispatch(
        editQuestions({
          projectId,
          qualityQuestions: editedData ? editedData : null,
        })
      ).unwrap();
    } else {
      const postData = data?.qualityQuestions?.map(
        (question: QualityQuestion) => {
          return question.question;
        }
      );

      const res = await dispatch(
        createQuestion({
          projectId,
          qualityQuestions: postData ? postData : [],
          createdBy: userFullName,
        })
      ).unwrap();
      if (res.isSuccess) {
        setResponseQuestions(res.qualityQuestions);
      }
      return res;
    }
  };

  // console.log(responseQuestions, "response questions");
  // console.log(
  //   (questions?.qualityQuestions || responseQuestions || [])?.length > 0,
  //   "quality question & response question length"
  // );

  const onSubmit = async (data: OnlyQuestion) => {
    // console.log(data, "datatata");
    try {
      if (actionType === "save") {
        await handleSave(data);
      } else if (actionType === "saveAndClose") {
        const res = await handleSave(data);
        if (res?.isSuccess) {
          handleCancelForm();
        }
      }
    } catch (error) {
      console.error("Error during form submission:", error);
    }
  };

  useEffect(() => {
    dispatch(resetState());
  }, []);

  async function handleDeleteQuestions() {
    setIsDeleting(true);
    const response = await dispatch(deleteQuestions(projectId || "")).unwrap();
    if (response.isSuccess) {
      //   navigate(routePathsWithParams.PROJECTS);
      setIsDeleting(false);
      setResponseQuestions([]);
      handleCancelForm();
    }
  }

  return (
    <>
      <SectionLayout>
        <Form
          onFinish={handleSubmit(onSubmit)}
          layout="vertical"
          autoComplete="off"
        >
          <Row gutter={parseInt(getConsistentSpacing(2))}>
            <Col xs={24} style={{ marginBottom: getConsistentSpacing(2) }}>
              <Typography.Title level={5} className="flex items-center">
                Quality Questions
                <Tooltip title="The questions you add here will be displayed on the Material Receipt Inspection Form (MRIF).">
                  <>
                    <CustomIcon type="info-icon" />
                  </>
                </Tooltip>
              </Typography.Title>
            </Col>
          </Row>
          {fields.map((field, questionIndex) => (
            <Form.Item
              key={field.id}
              validateStatus={
                errors.qualityQuestions?.[questionIndex] ? "error" : ""
              }
              help={
                errors.qualityQuestions?.[questionIndex]
                  ? errors.qualityQuestions[questionIndex].question?.message
                  : ""
              }
            >
              <Row className="justify-items-center items-center" gutter={24}>
                <Col xs={23} className="mt-3">
                  <Controller
                    name={`qualityQuestions.${questionIndex}.question`}
                    control={control}
                    render={({ field }) => (
                      <Input.TextArea
                        disabled={isFieldsCraftAuthorized()}
                        {...field}
                        className="min-h-96 rounded-xl px-5 py-3"
                        placeholder="Write your question here..."
                      />
                    )}
                  />
                </Col>
                {!isFieldsCraftAuthorized() && (
                  <Col xs={1} className="">
                    <DeleteIconButton
                      disabled={fields.length <= 1}
                      handleDelete={() => {
                        remove(questionIndex);
                      }}
                    />
                  </Col>
                )}
              </Row>
            </Form.Item>
          ))}

          {!isFieldsCraftAuthorized() && (
            <Button
              onClick={() =>
                append({
                  id: null,
                  question: "",
                })
              }
              className="border-none shadow-none text-primary font-medium"
              size="small"
              icon={
                <CustomIcon
                  type="plus"
                  className="bg-primary rounded-full fill-white"
                />
              }
            >
              Add
            </Button>
          )}

          {(resError || reqError || successMessage) && (
            <CustomAlert
              message={resError || reqError || successMessage || ""}
              type={successMessage ? "success" : "error"}
            />
          )}

          {!isFieldsCraftAuthorized() && (
            <Flex justify="flex-end" className="gap-4">
              {/* <Button
              disabled={isSubmitting || isDeleting}
              type="default"
              onClick={handleCancelForm}
            >
              Cancel
            </Button> */}
              {(questions?.qualityQuestions || responseQuestions || [])
                ?.length > 0 && (
                <Button
                  loading={isDeleting}
                  disabled={isSubmitting || isDeleting}
                  type="default"
                  onClick={handleDeleteQuestions}
                >
                  {isDeleting ? "Deleting.." : "Delete"}
                </Button>
              )}
              <Button
                loading={actionType === "save" && isSubmitting}
                disabled={isSubmitting || isDeleting}
                type="primary"
                htmlType="submit"
                onClick={() => setActionType("save")}
              >
                {actionType === "save" && isSubmitting ? "Saving.." : "Save"}
              </Button>

              {/* <Button
              loading={actionType === "saveAndClose" && isSubmitting}
              disabled={isSubmitting || isDeleting}
              type="primary"
              htmlType="submit"
              onClick={() => setActionType("saveAndClose")}
            >
              {actionType === "saveAndClose" && isSubmitting
                ? "Saving and closing.."
                : "Save & Close"}
            </Button> */}
            </Flex>
          )}
          <div className="mt-5"></div>
          {(questions?.qualityQuestions || responseQuestions || []).length! >
            0 && (
            <Flex justify="flex-end">
              <CreatedByUserBadge
                userName={
                  (questions?.qualityQuestions || responseQuestions || [])[0]
                    .modifiedDate == null
                    ? (questions?.qualityQuestions ||
                        responseQuestions ||
                        [])[0].createdBy
                    : (questions?.qualityQuestions ||
                        responseQuestions ||
                        [])[0].lastModifiedBy
                }
                date={
                  (questions?.qualityQuestions || responseQuestions || [])[0]
                    .lastModifiedDate
                }
                isModifiedBadge={
                  (questions?.qualityQuestions || responseQuestions || [])[0]
                    .modifiedDate == null
                    ? false
                    : true
                }
              />
            </Flex>
          )}
        </Form>
      </SectionLayout>
    </>
  );
}
