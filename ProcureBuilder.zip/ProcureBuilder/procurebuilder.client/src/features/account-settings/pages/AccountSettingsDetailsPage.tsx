import CustomTabs from "@/src/components/common/CustomTabs";
import PageLayout from "@/src/components/layout/PageLayout";
import { Flex } from "antd";
import { useEffect, useState } from "react";
// import { getCompanyDataById } from "@/src/store/slices/companySettingsSlice";
// import PurchaseOrderDetailsForm from "../components/PurchaseOrderDetailsForm";
// import ReorderDetailsForm from "../components/ReorderDetailsForm";
// import AccountDetailsForm from "../components/AccountSettingsDetailsForm";
import AccountDetailsForm from "../components/AccountSettingsDetailsFormRHF";
// import PasswordDetailsForm from "../components/PasswordSettingsDetailsForm";
import PasswordDetailsForm from "../components/PasswordSettingsDetailsFormRHF";
import routePaths from "@/src/utils/routePaths";
import { useLocation } from "react-router-dom";

export default function CompanyDetailsPage() {
  // Constants, location, params, etc.
  const location = useLocation();
  const tabs = {
    accountSettings: "Personal Details",
    passwordSettings: "Password Settings",
  };

  // Selectors, memos.
  // const company = useAppSelector((state) =>
  //   getCompanyDataById(state, companyId || "")
  // );

  // States
  const [selectedTab, setSelectedTab] = useState(tabs.accountSettings);

  // Functions
  function renderRenderTabPanels() {
    switch (selectedTab) {
      default:
        return <AccountDetailsForm />;
      case tabs.passwordSettings:
        return <PasswordDetailsForm />;
    }
  }

  // Effects
  useEffect(() => {
    if (
      location.pathname === routePaths.ACCOUNT_SETTINGS &&
      selectedTab !== tabs.accountSettings
    ) {
      setSelectedTab(tabs.accountSettings);
    }
  }, [location]);

  // Stateless Components

  return (
    <>
      <PageLayout
        title="Account Settings"
        // titleSibling={
        //   <CustomTag status={project?.status || ProjectStatusEnum.OPEN} />
        // }
        titleBarJustifyContent="flex-start"
      >
        <Flex className="mb-7">
          <CustomTabs
            options={Object.entries(tabs)?.map(([key, value]) => ({
              value: key,
              label: value,
              //   disabled: !projectId ? value !== tabs.companyInformation : false,
            }))}
            tabLabel={selectedTab}
            onChange={(tab) => setSelectedTab(tab)}
          />
        </Flex>

        {renderRenderTabPanels()}
      </PageLayout>
    </>
  );
}
