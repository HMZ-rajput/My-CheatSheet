import { Col, Flex, Form, Input, Row, Typography } from "antd";
import { useFormik } from "formik";
import * as Yup from "yup";

import { updatePersonalInfo } from "@/src/apis/userApis";
import CustomFormButtons from "@/src/components/form/CustomFormButtons";
import { useAppSelector } from "@/src/hooks/useAppSelector";
import {
  getUserFullName,
  getUserState,
  resetStateisSuccess,
} from "@/src/store/slices/userSlice";
import { AccountSettings } from "@/src/utils/types";
import CustomFormLabel from "@components/common/CustomFormLabel";
import SectionLayout from "@components/layout/SectionLayout";
import { useAppDispatch } from "@hooks/useAppDispatch";
import { routePathsWithParams } from "@utils/routePaths";
import { getConsistentSpacing } from "@utils/theme-helpers";
import PhoneInput from "react-phone-input-2";
import "react-phone-input-2/lib/style.css";
import CustomAlert from "@/src/components/common/CustomAlert";
import { useState } from "react";

type AccountDetailsFormProps = {
  account?: AccountSettings;
  handleCancelForm?: () => void;
};

export default function AccountDetailsForm({
  account,
  handleCancelForm,
}: AccountDetailsFormProps) {
  const userFullName = useAppSelector(getUserFullName);
  const { data, successMessage, resError, reqError, isSuccess } =
    useAppSelector(getUserState);
  const dispatch = useAppDispatch();
  const [hasMadeApiCall, setHasMadeApiCall] = useState(false);

  const userId = data?.userId || "";

  type FieldType = AccountSettings;

  const validationSchema = Yup.object().shape({
    firstName: Yup.string().required("First Name is required."),
    lastName: Yup.string().required("Last Name is required."),
    phoneNumber: Yup.string().required("Phone Number is required."),
  });

  const formik = useFormik({
    initialValues: {
      // Info
      firstName: data?.firstName || "",
      lastName: data?.lastName || "",
      phoneNumber: data?.phoneNumber || "",
      cellNumber: data?.cellNumber || "",
      email: data?.userName || "",
    },
    validationSchema,
    onSubmit: async (values) => {
      setHasMadeApiCall(true);
      const payload = {
        modifiedBy: userFullName,
        ...values,
      };
      try {
        formik.setSubmitting(true);
        await dispatch(updatePersonalInfo({ payload, userId })).unwrap();
      } catch (err) {
        console.log("Error updating personal info: ", err);
      } finally {
        formik.setSubmitting(false);
      }
    },
  });

  return (
    <>
      <SectionLayout>
        {/* Image Upload */}
        {/* <Flex className="items-center">
                <Avatar rootClassName="w-12 h-12" className="cursor-pointer">
                <UserOutlined className="text-2xl mt-1" />
              </Avatar>
              <Flex vertical className="ml-5">
                <Typography.Title level={5}>Upload Image</Typography.Title>
                <span className="-mt-2">Min 400x400px, PNG or JPEG</span>
                </Flex>
                <Flex className="gap-3 ml-16">
                <Button type="primary" className="px-3 py-2 font-medium">Change Image</Button>
                <Button className="font-medium">Delete Image</Button>
                </Flex>
                </Flex> */}

        <Form
          onFinish={formik.handleSubmit}
          layout="vertical"
          autoComplete="off"
        >
          <Row gutter={parseInt(getConsistentSpacing(2))}>
            <Col xs={24} style={{ marginBottom: getConsistentSpacing(2) }}>
              <Typography.Title level={5}>Personal Details</Typography.Title>
            </Col>

            {/* First Name */}
            <Col xs={12}>
              <Form.Item<FieldType>
                label={<CustomFormLabel text="First Name" />}
                name="firstName"
                labelAlign="right"
                initialValue={formik.values.firstName}
                required
                validateStatus={formik.errors.firstName ? "error" : ""}
                help={formik.errors.firstName ? formik.errors.firstName : ""}
              >
                <Input
                  value={formik.values.firstName}
                  onChange={(event) =>
                    formik.setFieldValue(
                      "firstName",
                      event?.target?.value || ""
                    )
                  }
                  size="large"
                  placeholder="First Name"
                />
              </Form.Item>
            </Col>

            {/* Last Name */}
            <Col xs={12}>
              <Form.Item<FieldType>
                label={<CustomFormLabel text="Last Name" />}
                name="lastName"
                labelAlign="right"
                initialValue={formik.values.lastName}
                required
                validateStatus={formik.errors.lastName ? "error" : ""}
                help={formik.errors.lastName ? formik.errors.lastName : ""}
              >
                <Input
                  value={formik.values.lastName}
                  onChange={(event) =>
                    formik.setFieldValue("lastName", event?.target?.value || "")
                  }
                  size="large"
                  placeholder="Last Name"
                />
              </Form.Item>
            </Col>

            {/* Email */}
            <Col xs={12}>
              <Form.Item<FieldType>
                label={<CustomFormLabel text="Email" />}
                name="email"
                labelAlign="right"
                initialValue={formik.values.email}
              >
                <Input
                  disabled
                  value={formik.values.email}
                  onChange={(event) =>
                    formik.setFieldValue("email", event?.target?.value || "")
                  }
                  size="large"
                  placeholder="Email"
                />
              </Form.Item>
            </Col>

            {/* Phone */}
            <Col xs={12}>
              <Form.Item<FieldType>
                label={<CustomFormLabel text="Phone" />}
                name="phoneNumber"
                labelAlign="right"
                initialValue={formik.values.phoneNumber}
                required
                validateStatus={formik.errors.phoneNumber ? "error" : ""}
                help={
                  formik.errors.phoneNumber ? formik.errors.phoneNumber : ""
                }
              >
                <PhoneInput
                  placeholder="(555) 000-0000"
                  country={"us"}
                  value={formik.values.phoneNumber}
                  onChange={(value) =>
                    formik.setFieldValue("phoneNumber", value)
                  }
                  inputProps={{
                    autoFocus: true,
                  }}
                />
              </Form.Item>
            </Col>

            {/* Cell Phone */}
            <Col xs={12}>
              <Form.Item<FieldType>
                label={<CustomFormLabel text="Cell Phone" />}
                name="cellNumber"
                labelAlign="right"
                initialValue={formik.values.cellNumber}
              >
                <PhoneInput
                  placeholder="(555) 000-0000"
                  country={"us"}
                  value={formik.values.cellNumber}
                  onChange={(value) =>
                    formik.setFieldValue("cellNumber", value)
                  }
                />
              </Form.Item>
            </Col>
          </Row>

          {hasMadeApiCall && (resError || successMessage) && (
            <CustomAlert
              message={resError || successMessage || ""}
              type={successMessage ? "success" : "error"}
            />
          )}
          <Flex justify="flex-end" gap={parseInt(getConsistentSpacing(2))}>
            <CustomFormButtons
              resetStateisSuccess={resetStateisSuccess}
              saveButtonName="Save Settings"
              isSuccess={isSuccess}
              isEditMode={Boolean(account)}
              hasValidationErrors={
                Object.values(formik.errors)?.length > 0 &&
                Object.values(formik.touched)?.length > 0
              }
              navigationRoute={routePathsWithParams.HOME}
              handleSubmit={formik.handleSubmit}
              handleCancel={handleCancelForm}
              hasHttpErrors={Boolean(resError || reqError)}
            />
          </Flex>
        </Form>
      </SectionLayout>
    </>
  );
}
