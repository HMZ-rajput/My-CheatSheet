import { Button, Col, Flex, Form, Input, Row, Typography } from "antd";
import * as Yup from "yup";

import { updatePersonalInfo } from "@/src/apis/userApis";
import { useAppSelector } from "@/src/hooks/useAppSelector";
import {
  getUserFullName,
  getUserState,
  resetState,
} from "@/src/store/slices/userSlice";
import { AccountSettings } from "@/src/utils/types";
import CustomFormLabel from "@components/common/CustomFormLabel";
import SectionLayout from "@components/layout/SectionLayout";
import { useAppDispatch } from "@hooks/useAppDispatch";
import { getConsistentSpacing } from "@utils/theme-helpers";
import PhoneInput from "react-phone-input-2";
import "react-phone-input-2/lib/style.css";
import CustomAlert from "@/src/components/common/CustomAlert";
import { useEffect, useState } from "react";
import { Controller, Resolver, useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import { useNavigate } from "react-router-dom";
import { phoneNumberLengthRegex } from "@/src/utils/constants";

type FormValues = AccountSettings;
type FormattedPhoneNumberType = {
  phoneNumber?: string | null;
  cellPhoneNumber?: string | null;
};
export default function AccountDetailsForm() {
  const userFullName = useAppSelector(getUserFullName);
  const [actionType, setActionType] = useState("");
  const { data, successMessage, resError, reqError } =
    useAppSelector(getUserState);
  const dispatch = useAppDispatch();
  const navigate = useNavigate();

  const userId = data?.userId || "";

  type FieldType = AccountSettings;

  const validationSchema = Yup.object().shape({
    firstName: Yup.string().required("First Name is required."),
    lastName: Yup.string().required("Last Name is required."),
    phoneNumber: Yup.string()?.optional()?.trim()
      .matches(phoneNumberLengthRegex, {
        message: "Phone Number is not valid in the US",
        excludeEmptyString: true,
      }),
    cellNumber: Yup.string()?.optional()?.trim().matches(phoneNumberLengthRegex, {
      message: "Cell Phone Number is not valid in the US",
      excludeEmptyString: true,
    }),
  });

  const {
    control,
    handleSubmit,
    // watch,
    formState: { isSubmitting, errors },
    register,
  } = useForm({
    resolver: yupResolver(validationSchema) as unknown as Resolver<FormValues>,
    defaultValues: {
      firstName: data?.firstName || "",
      lastName: data?.lastName || "",
      phoneNumber: data?.phoneNumber || "",
      cellNumber: data?.cellNumber || "",
      email: data?.userName || "",
    },
  });

  const [formattedPhoneNumber, setFormattedPhoneNumber] =
    useState<FormattedPhoneNumberType>({
      phoneNumber: "",
      cellPhoneNumber: "",
    });

  const handleSave = async (data: FormValues) => {
    const payload = {
      modifiedBy: userFullName,
      ...data,
    };
    try {
      return await dispatch(updatePersonalInfo({ payload, userId })).unwrap();
    } catch (err) {
      console.log(err);
    }
    // finally {
    //   setSubmitting(false);
    // }
  };

  const onSubmit = async (data: FormValues) => {
    try {
      if (actionType === "save") {
        await handleSave(data);
      } else if (actionType === "saveAndClose") {
        const res = await handleSave(data);
        if (res?.isSuccess) {
          dispatch(resetState());
          navigate("/");
        }
      }
    } catch (error) {
      console.error("Error during form submission:", error);
    }

    // finally {
    //   setSubmitting(false);
    // }
  };

  //     initialValues: {
  //       // Info
  //       firstName: data?.firstName || "",
  //       lastName: data?.lastName || "",
  //       phoneNumber: data?.phoneNumber || "",
  //       cellNumber: data?.cellNumber || "",
  //       email: data?.userName || "",
  //     },
  //     validationSchema,
  //     onSubmit: async (values) => {
  //       setHasMadeApiCall(true);
  //       const payload = {
  //         modifiedBy: userFullName,
  //         ...values,
  //       };
  //       try {
  //         setSubmitting(true);
  //         await dispatch(updatePersonalInfo({ payload, userId })).unwrap();
  //       } catch (err) {
  //       } finally {
  //         setSubmitting(false);
  //       }
  //     },
  //   });

  useEffect(() => {
    dispatch(resetState());
  }, []);

  useEffect(() => {
    if (data?.cellNumber) {
      setFormattedPhoneNumber({
        cellPhoneNumber: data?.cellNumber,
        phoneNumber: data?.phoneNumber,
      }); // set the formatted number
    }
  }, [data?.phoneNumber]);

  return (
    <>
      <SectionLayout>
        {/* Image Upload */}
        {/* <Flex className="items-center">
                <Avatar rootClassName="w-12 h-12" className="cursor-pointer">
                <UserOutlined className="text-2xl mt-1" />
              </Avatar>
              <Flex vertical className="ml-5">
                <Typography.Title level={5}>Upload Image</Typography.Title>
                <span className="-mt-2">Min 400x400px, PNG or JPEG</span>
                </Flex>
                <Flex className="gap-3 ml-16">
                <Button type="primary" className="px-3 py-2 font-medium">Change Image</Button>
                <Button className="font-medium">Delete Image</Button>
                </Flex>
                </Flex> */}

        <Form
          onFinish={handleSubmit(onSubmit)}
          layout="vertical"
          autoComplete="off"
        >
          <Row gutter={parseInt(getConsistentSpacing(2))}>
            <Col xs={24} style={{ marginBottom: getConsistentSpacing(2) }}>
              <Typography.Title level={5}>Personal Details</Typography.Title>
            </Col>

            {/* First Name */}
            <Col xs={12}>
              <Form.Item<FieldType>
                validateStatus={errors.firstName ? "error" : ""}
                help={errors.firstName ? errors.firstName.message : ""}
              >
                <CustomFormLabel text="First Name" required />
                <Controller
                  name="firstName"
                  control={control}
                  render={({ field }) => (
                    <Input
                      {...field}
                      size="large"
                      placeholder="First Name"
                      className="mt-3"
                    />
                  )}
                />
              </Form.Item>
            </Col>

            {/* Last Name */}
            <Col xs={12}>
              <Form.Item<FieldType>
                validateStatus={errors.lastName ? "error" : ""}
                help={errors.lastName ? errors.lastName.message : ""}
              >
                <CustomFormLabel text="Last Name" required />
                <Controller
                  name="lastName"
                  control={control}
                  render={({ field }) => (
                    <Input
                      {...field}
                      size="large"
                      placeholder="Last Name"
                      className="mt-3"
                    />
                  )}
                />
              </Form.Item>
            </Col>

            {/* Email */}
            <Col xs={12}>
              <Form.Item<FieldType>
                label={<CustomFormLabel text="Email" />}
                name="email"
                labelAlign="right"
              >
                <Controller
                  name="email"
                  control={control}
                  disabled
                  render={({ field }) => (
                    <Input {...field} size="large" placeholder="Email" />
                  )}
                />
              </Form.Item>
            </Col>

            {/* Phone */}
            <Col xs={12}>
              <Form.Item<FieldType>
                label={<CustomFormLabel text="Phone" />}
                labelAlign="right"
                validateStatus={errors.phoneNumber ? "error" : ""}
                help={errors.phoneNumber ? errors.phoneNumber.message : ""}
              >
                <Controller
                  name="phoneNumber"
                  control={control}
                  render={({ field }) => (
                    <div ref={register("phoneNumber").ref}>
                      <PhoneInput
                        country={"us"}
                        value={formattedPhoneNumber.phoneNumber || field.value}
                        autoFormat
                        onChange={(phoneNumber) => {
                          field.onChange(phoneNumber);
                          setFormattedPhoneNumber((prev) => ({
                            ...prev,
                            phoneNumber: phoneNumber,
                          }));
                        }}
                      />
                    </div>
                  )}
                />
              </Form.Item>
            </Col>

            {/* Cell Phone */}
            <Col xs={12}>
              <Form.Item<FieldType>
                label={<CustomFormLabel text="Cell Phone" />}
                labelAlign="right"
                validateStatus={errors.cellNumber ? "error" : ""}
                help={errors.cellNumber ? errors.cellNumber.message : ""}
              >
                <Controller
                  name="cellNumber"
                  control={control}
                  render={({ field }) => (
                    <div ref={register("cellNumber").ref}>
                      <PhoneInput
                        {...field}
                        country={"us"}
                        value={
                          formattedPhoneNumber.cellPhoneNumber ||
                          field.value ||
                          ""
                        }
                        onChange={(cellNumber) => {
                          field.onChange(cellNumber);
                          setFormattedPhoneNumber((prev) => ({
                            ...prev,
                            cellPhoneNumber: cellNumber,
                          }));
                        }}
                      />
                    </div>
                  )}
                />
              </Form.Item>
            </Col>
          </Row>

          {(resError || reqError || successMessage) && (
            <CustomAlert
              message={resError || successMessage || reqError || ""}
              type={successMessage ? "success" : "error"}
            />
          )}

          <Flex justify="flex-end" className="gap-4">
            <Button
              disabled={isSubmitting}
              type="default"
              onClick={() => {
                navigate(-1);
              }}
            >
              Cancel
            </Button>
            {/* {customer?.id && (
              <Button
                loading={isDeleting}
                disabled={isSubmitting || isDeleting}
                type="default"
                onClick={handleDeleteCustomerById}
              >
                {isDeleting ? "Deleting.." : "Delete"}
              </Button>
            )} */}
            <Button
              loading={actionType === "save" && isSubmitting}
              disabled={isSubmitting}
              type="primary"
              htmlType="submit"
              onClick={() => setActionType("save")}
            >
              {actionType === "save" && isSubmitting
                ? "Saving Settings..."
                : "Save Settings"}
            </Button>

            <Button
              loading={actionType === "saveAndClose" && isSubmitting}
              disabled={isSubmitting}
              type="primary"
              htmlType="submit"
              onClick={() => setActionType("saveAndClose")}
            >
              {actionType === "saveAndClose" && isSubmitting
                ? "Saving and closing.."
                : "Save & Close"}
            </Button>
          </Flex>
          <div className="mt-5"></div>
        </Form>
      </SectionLayout>
    </>
  );
}
