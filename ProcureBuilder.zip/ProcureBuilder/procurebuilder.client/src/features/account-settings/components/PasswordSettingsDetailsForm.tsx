import { Col, Flex, Form, Input, Row, Typography } from "antd";
import { useFormik } from "formik";
import * as Yup from "yup";

import { changePassword } from "@/src/apis/userApis";
import CustomAlert from "@/src/components/common/CustomAlert";
import CustomFormButtons from "@/src/components/form/CustomFormButtons";
import { useAppSelector } from "@/src/hooks/useAppSelector";
import {
  getUserFullName,
  getUserState,
  resetState,
  resetStateisSuccess,
} from "@/src/store/slices/userSlice";
import { PasswordSettings } from "@/src/utils/types";
import CustomFormLabel from "@components/common/CustomFormLabel";
import SectionLayout from "@components/layout/SectionLayout";
import { useAppDispatch } from "@hooks/useAppDispatch";
import { routePathsWithParams } from "@utils/routePaths";
import { getConsistentSpacing } from "@utils/theme-helpers";
import { useEffect, useState } from "react";
import "react-phone-input-2/lib/style.css";

type PasswordDetailsFormProps = {
  password?: PasswordSettings;

  handleCancelForm?: () => void;
};

export default function PasswordDetailsForm({
  password,
  handleCancelForm,
}: PasswordDetailsFormProps) {
  const userFullName = useAppSelector(getUserFullName);
  const { data, successMessage, resError, reqError, isSuccess } =
    useAppSelector(getUserState);
  const dispatch = useAppDispatch();
  const [hasMadeApiCall, setHasMadeApiCall] = useState(false);

  const email = data?.userName || "";

  type FieldType = {
    oldPassword: string;
    newPassword: string;
    retypePassword: string;
  };

  const validationSchema = Yup.object().shape({
    oldPassword: Yup.string().required("Old Password is required."),
    newPassword: Yup.string()
      .min(8, "Password should be of minimum 8 characters length")
      .matches(/[a-zA-Z]/, "Password must contain at least one letter")
      .matches(/[0-9]/, "Password must contain at least one digit")
      .matches(
        /[^\w\s]/,
        "Password must contain at least one non-alphanumeric character"
      )
      .required("New Password is required"),
    retypePassword: Yup.string()
      .oneOf([Yup.ref("newPassword"), ""], "Passwords must match")
      .required("Retyping password is required"),
  });

  const formik = useFormik({
    initialValues: {
      // Info
      oldPassword: "",
      newPassword: "",
      retypePassword: "",
    },
    validationSchema,
    onSubmit: async (values) => {
      setHasMadeApiCall(true);
      const payload = {
        modifiedBy: userFullName,
        email,
        ...values,
      };
      try {
        formik.setSubmitting(true);
        const res = await dispatch(changePassword({ payload })).unwrap();
        if (res.isSuccess) {
          setTimeout(() => {
            formik.resetForm();
            dispatch(resetState());
          }, 3000);
        }
      } catch (err) {
        console.log(err);
      } finally {
        formik.setSubmitting(false);
      }
    },
  });

  useEffect(() => {
    dispatch(resetState());
  }, [formik.values]);

  return (
    <>
      <SectionLayout>
        <Form
          onFinish={formik.handleSubmit}
          layout="vertical"
          autoComplete="off"
        >
          <Row gutter={parseInt(getConsistentSpacing(2))}>
            <Col xs={24} style={{ marginBottom: getConsistentSpacing(2) }}>
              <Typography.Title level={5}>Change Password</Typography.Title>
            </Col>

            {/* Old Password */}
            <Col xs={12}>
              <Form.Item<FieldType>
                validateStatus={formik.errors.oldPassword ? "error" : ""}
                help={
                  formik.errors.oldPassword ? formik.errors.oldPassword : ""
                }
              >
                <CustomFormLabel text="Old Password" required />
                <Input.Password
                  value={formik.values.oldPassword}
                  onChange={(event) =>
                    formik.setFieldValue(
                      "oldPassword",
                      event?.target?.value || ""
                    )
                  }
                  className="mt-3"
                  size="large"
                  placeholder="Old Password"
                />
              </Form.Item>
            </Col>
          </Row>
          <Row gutter={parseInt(getConsistentSpacing(2))}>
            {/* New Password */}
            <Col xs={12}>
              <Form.Item<FieldType>
                validateStatus={formik.errors.newPassword ? "error" : ""}
                help={
                  formik.errors.newPassword ? formik.errors.newPassword : ""
                }
              >
                <CustomFormLabel text="New Password" required />
                <Input.Password
                  value={formik.values.newPassword}
                  onChange={(event) =>
                    formik.setFieldValue(
                      "newPassword",
                      event?.target?.value || ""
                    )
                  }
                  size="large"
                  placeholder="New Password"
                  className="mt-3"
                />
              </Form.Item>
            </Col>

            {/* Retype Password */}
            <Col xs={12}>
              <Form.Item<FieldType>
                validateStatus={formik.errors.retypePassword ? "error" : ""}
                help={
                  formik.errors.retypePassword
                    ? formik.errors.retypePassword
                    : ""
                }
              >
                <CustomFormLabel text="Retype Password" required />
                <Input.Password
                  value={formik.values.retypePassword}
                  onChange={(event) =>
                    formik.setFieldValue(
                      "retypePassword",
                      event?.target?.value || ""
                    )
                  }
                  size="large"
                  placeholder="Re-type Password"
                  className="mt-3"
                />
              </Form.Item>
            </Col>
          </Row>
          {hasMadeApiCall && (resError || successMessage) && (
            <CustomAlert
              message={resError || successMessage || ""}
              type={successMessage ? "success" : "error"}
            />
          )}
          <Flex justify="flex-end" gap={parseInt(getConsistentSpacing(2))}>
            <CustomFormButtons
              resetStateisSuccess={resetStateisSuccess}
              isSuccess={isSuccess}
              isEditMode={Boolean(password)}
              hasValidationErrors={
                Object.values(formik.errors)?.length > 0 &&
                Object.values(formik.touched)?.length > 0
              }
              navigationRoute={routePathsWithParams.HOME}
              handleCancel={handleCancelForm}
              handleSubmit={formik.handleSubmit}
              hasHttpErrors={Boolean(resError || reqError)}
            />
          </Flex>
        </Form>
      </SectionLayout>
    </>
  );
}
