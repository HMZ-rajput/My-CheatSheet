import { Button, Col, Flex, Form, Input, Row, Typography } from "antd";
import * as Yup from "yup";
import { changePassword } from "@/src/apis/userApis";
import CustomAlert from "@/src/components/common/CustomAlert";
import { useAppSelector } from "@/src/hooks/useAppSelector";
import {
  getUserFullName,
  getUserState,
  resetState,
} from "@/src/store/slices/userSlice";
import { PasswordSettings } from "@/src/utils/types";
import CustomFormLabel from "@components/common/CustomFormLabel";
import SectionLayout from "@components/layout/SectionLayout";
import { useAppDispatch } from "@hooks/useAppDispatch";
import { getConsistentSpacing } from "@utils/theme-helpers";
import { useEffect, useState } from "react";
import "react-phone-input-2/lib/style.css";
import { Controller, Resolver, useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import { useNavigate } from "react-router-dom";

// type PasswordDetailsFormProps = {
//   password?: PasswordSettings;

//   handleCancelForm?: () => void;
// };

type FormValues = PasswordSettings;

export default function PasswordDetailsForm() {
  const userFullName = useAppSelector(getUserFullName);
  const { data, successMessage, resError, reqError } =
    useAppSelector(getUserState);
  const [actionType, setActionType] = useState("");
  const dispatch = useAppDispatch();
  const navigate = useNavigate();

  const email = data?.userName || "";

  type FieldType = {
    oldPassword: string;
    newPassword: string;
    retypePassword: string;
  };

  const validationSchema = Yup.object().shape({
    oldPassword: Yup.string().required("Old Password is required."),
    newPassword: Yup.string()
      .min(8, "Password should be of minimum 8 characters length")
      .matches(/[a-zA-Z]/, "Password must contain at least one letter")
      .matches(/[0-9]/, "Password must contain at least one digit")
      .matches(
        /[^\w\s]/,
        "Password must contain at least one non-alphanumeric character"
      )
      .required("New Password is required"),
    retypePassword: Yup.string()
      .oneOf([Yup.ref("newPassword"), ""], "Passwords must match")
      .required("Retyping password is required"),
  });

  const {
    control,
    handleSubmit,
    // watch,
    reset,
    formState: { isSubmitting, errors },
  } = useForm({
    resolver: yupResolver(validationSchema) as unknown as Resolver<FormValues>,
    defaultValues: {
      oldPassword: "",
      newPassword: "",
      retypePassword: "",
    },
  });

  const handleSave = async (data: FormValues) => {
    const payload = {
      modifiedBy: userFullName,
      email,
      ...data,
    };
    try {
      const res = await dispatch(changePassword({ payload })).unwrap();
      if (res.isSuccess) {
        setTimeout(() => {
          reset();
          dispatch(resetState());
        }, 3000);
      }
      return res;
    } catch (err) {
      console.log(err);
    }
    // finally {
    //   formik.setSubmitting(false);
    // }
  };

  const onSubmit = async (data: FormValues) => {
    try {
      if (actionType === "save") {
        await handleSave(data);
      } else if (actionType === "saveAndClose") {
        const res = await handleSave(data);
        if (res?.isSuccess) {
          navigate(-1);
        }
      }
    } catch (error) {
      console.error("Error during form submission:", error);
    }

    // finally {
    //   setSubmitting(false);
    // }
  };

  useEffect(() => {
    dispatch(resetState());
  }, []);

  return (
    <>
      <SectionLayout>
        <Form
          onFinish={handleSubmit(onSubmit)}
          layout="vertical"
          autoComplete="off"
        >
          <Row gutter={parseInt(getConsistentSpacing(2))}>
            <Col xs={24} style={{ marginBottom: getConsistentSpacing(2) }}>
              <Typography.Title level={5}>Change Password</Typography.Title>
            </Col>

            {/* Old Password */}
            <Col xs={12}>
              <Form.Item<FieldType>
                validateStatus={errors.oldPassword ? "error" : ""}
                help={errors.oldPassword ? errors.oldPassword.message : ""}
              >
                <CustomFormLabel text="Old Password" required />
                <Controller
                  name="oldPassword"
                  control={control}
                  render={({ field }) => (
                    <Input.Password
                      {...field}
                      size="large"
                      placeholder="Old Password"
                      className="mt-3"
                    />
                  )}
                />
              </Form.Item>
            </Col>
          </Row>
          <Row gutter={parseInt(getConsistentSpacing(2))}>
            {/* New Password */}
            <Col xs={12}>
              <Form.Item<FieldType>
                validateStatus={errors.newPassword ? "error" : ""}
                help={errors.newPassword ? errors.newPassword.message : ""}
              >
                <CustomFormLabel text="New Password" required />
                <Controller
                  name="newPassword"
                  control={control}
                  render={({ field }) => (
                    <Input.Password
                      {...field}
                      size="large"
                      placeholder="New Password"
                      className="mt-3"
                    />
                  )}
                />
              </Form.Item>
            </Col>

            {/* Retype Password */}
            <Col xs={12}>
              <Form.Item<FieldType>
                validateStatus={errors.retypePassword ? "error" : ""}
                help={
                  errors.retypePassword ? errors.retypePassword.message : ""
                }
              >
                <CustomFormLabel text="Retype Password" required />
                <Controller
                  name="retypePassword"
                  control={control}
                  render={({ field }) => (
                    <Input.Password
                      {...field}
                      size="large"
                      placeholder="Re-type Password"
                      className="mt-3"
                    />
                  )}
                />
              </Form.Item>
            </Col>
          </Row>
          {(resError || successMessage || reqError) && (
            <CustomAlert
              message={resError || successMessage || reqError || ""}
              type={successMessage ? "success" : "error"}
            />
          )}
          <Flex justify="flex-end" className="gap-4">
            <Button
              disabled={isSubmitting}
              type="default"
              onClick={() => {
                navigate(-1);
              }}
            >
              Cancel
            </Button>
            <Button
              loading={actionType === "save" && isSubmitting}
              disabled={isSubmitting}
              type="primary"
              htmlType="submit"
              onClick={() => setActionType("save")}
            >
              {actionType === "save" && isSubmitting
                ? "Saving Settings..."
                : "Save Settings"}
            </Button>

            <Button
              loading={actionType === "saveAndClose" && isSubmitting}
              disabled={isSubmitting}
              type="primary"
              htmlType="submit"
              onClick={() => setActionType("saveAndClose")}
            >
              {actionType === "saveAndClose" && isSubmitting
                ? "Saving and closing.."
                : "Save & Close"}
            </Button>
          </Flex>
          <div className="mt-5"></div>
        </Form>
      </SectionLayout>
    </>
  );
}
