import { getLocationslist } from "@/src/apis/locationApis";
import { getSummarizedProjectsList } from "@/src/apis/projectApis";
import CustomIcon from "@/src/components/common/CustomIcon";
import PageLayout from "@/src/components/layout/PageLayout";
import { useAppDispatch } from "@/src/hooks/useAppDispatch";
import { useAppSelector } from "@/src/hooks/useAppSelector";
import { getLocationsState } from "@/src/store/slices/locationSlice";
import { getProjectsState } from "@/src/store/slices/projectsSlice";
import { getReorderState } from "@/src/store/slices/reordersSlice";
import { reorderStatusOptions } from "@/src/utils/constants";
import routePaths from "@/src/utils/routePaths";
import { Reorder } from "@/src/utils/types";
import { exportToExcel } from "@/src/utils/xlsx-utils";
import { Button } from "antd";
import dayjs from "dayjs";
import { useEffect, useMemo, useState } from "react";
import Chart from "react-apexcharts";
import ReordersList from "../../re-oders/components/ReordersList";
import ReportArtificialSpace from "../components/ReportArtificialSpace";
import ReportFilters from "../components/ReportFilters";
import ReportStatisticsCard from "../components/ReportStatisticsCard";
import { FilterType, ReportChartState } from "../types";
import { FilterInputTypes } from "../utils";

type ReorderReportFields = {
  "Reorder Number": string;
  Title: string | undefined;
  Project: string;
  Location: string | null | undefined;
  "Request Date": string | undefined;
  "Due Date": string | undefined;
  "Quote Received Date": string | undefined;
  Status: string;
};

const ReordersReportPage = () => {
  const dispatch = useAppDispatch();
  const { projectsSummarizedData } = useAppSelector(getProjectsState);
  const { locationsList } = useAppSelector(getLocationsState);
  const { reorderData, isLoading } = useAppSelector(getReorderState);
  const [stats, setStats] = useState({
    totalReorders: 0,
    totalPendingReQuote: 0,
    totalQuoteReceived: 0,
    totalPOCreated: 0,
  });
  const statusChartState: ReportChartState = {
    options: {
      chart: {
        type: "donut",
      },
      legend: {
        position: "top",
      },
      colors: ["#f17b2c", "#9B8DE2", "#9EE0B9"],
      labels: reorderStatusOptions.map((m) => m.label),
    },
    series: [
      stats.totalPendingReQuote,
      stats.totalQuoteReceived,
      stats.totalPOCreated,
    ],
  };
  const filters: Record<string, FilterType> = useMemo(
    () => ({
      projectId: {
        label: "Project",
        type: FilterInputTypes.SELECT,
        options:
          projectsSummarizedData?.map((m) => ({
            value: m?.id || "",
            label: m?.name || "",
          })) || [],
        placeholder: "Select Project",
        size: 3,
        clearable: true,
      },
      locationId: {
        label: "Location",
        type: FilterInputTypes.SELECT,
        options:
          locationsList?.map((m) => ({
            value: m?.id || "",
            label: m?.name || "",
            projectId: m?.projectId || "",
          })) || [],
        placeholder: "Select Location",
        filterByKey: "projectId",
        size: 3,
        clearable: true,
      },
      status: {
        label: "Status",
        type: FilterInputTypes.SELECT,
        options: reorderStatusOptions,
        placeholder: "Select Status",
        size: 3,
        clearable: true,
      },
      quoteRequest: {
        label: "Request Date",
        type: FilterInputTypes.DATE_RANGE,
        placeholder: "MM / DD / YYYY",
        suffix: <CustomIcon type="calendar-green-icon" />,
        size: 3,
      },
      dueDate: {
        label: "Due Date",
        type: FilterInputTypes.DATE_RANGE,
        placeholder: "MM / DD / YYYY",
        suffix: <CustomIcon type="calendar-green-icon" />,
        size: 3,
      },
      quoteReceived: {
        label: "Quote Received Date",
        type: FilterInputTypes.DATE_RANGE,
        placeholder: "MM / DD / YYYY",
        suffix: <CustomIcon type="calendar-green-icon" />,
        size: 3,
      },
    }),
    [projectsSummarizedData, locationsList]
  );
  const generateExcel = () => {
    if (reorderData !== null && reorderData?.length > 0) {
      const data: ReorderReportFields[] = reorderData?.map((m: Reorder) => ({
        "Reorder Number": m?.reorderNumber || "",
        Title: m?.title || "",
        Project: m?.project?.name || "",
        Location: m?.location?.name || "",
        "Request Date": dayjs(m?.createdDate)?.format("MM/DD/YYYY")?.toString(),
        "Due Date": dayjs(m?.dueDate)?.format("MM/DD/YYYY")?.toString(),
        "Quote Received Date": m?.quoteReceivedDate
          ? dayjs(m?.quoteReceivedDate)?.format("MM/DD/YYYY")?.toString()
          : "N/A",
        Status:
          reorderStatusOptions?.find((f) => f?.value === m?.status)?.label ||
          "",
      }));

      exportToExcel<ReorderReportFields[]>(data, "Reorders", "reorders-report");
    }
  };

  useEffect(() => {
    dispatch(getSummarizedProjectsList());
    dispatch(getLocationslist());
  }, []);

  return (
    <PageLayout
      backlink={{ title: "Reports", route: routePaths.REPORTS }}
      title="Reorders Report"
    >
      <ReportFilters filters={filters} />

      <ReportArtificialSpace />

      <div className="flex gap-3">
        <div className="flex flex-col basis-2/6 gap-3">
          <ReportStatisticsCard
            title="Total Reorders"
            stat={stats.totalReorders}
            className="grow-0"
          />
          <div className="grow-[2]"></div>
        </div>

        <ReportStatisticsCard title="Status">
          <div className="flex flex-col">
            <Chart
              series={statusChartState.series}
              options={statusChartState.options}
              type="donut"
              height="300"
            />
          </div>
        </ReportStatisticsCard>
      </div>

      <ReportArtificialSpace />

      <ReordersList
        setReportStats={(
          totalReorders,
          totalPendingReQuote,
          totalQuoteReceived,
          totalPOCreated
        ) => {
          setStats({
            totalReorders: totalReorders || 0,
            totalPendingReQuote: totalPendingReQuote || 0,
            totalQuoteReceived: totalQuoteReceived || 0,
            totalPOCreated: totalPOCreated || 0,
          });
        }}
        exportButtonEl={
          <Button
            disabled={isLoading || !Boolean(reorderData?.length)}
            onClick={generateExcel}
          >
            Export
          </Button>
        }
      />
    </PageLayout>
  );
};

export default ReordersReportPage;
