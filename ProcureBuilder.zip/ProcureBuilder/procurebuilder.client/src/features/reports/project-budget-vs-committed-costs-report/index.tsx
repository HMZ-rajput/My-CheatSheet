import PageLayout from "@/src/components/layout/PageLayout";
import { useAppSelector } from "@/src/hooks/useAppSelector";
import { getProjectsState } from "@/src/store/slices/projectsSlice";
import routePaths from "@/src/utils/routePaths";
import { MaterialCostAnalysisRowType } from "@/src/utils/types";
import { exportToExcel } from "@/src/utils/xlsx-utils";
import { Button } from "antd";
import { useMemo, useState } from "react";
import Chart from "react-apexcharts";
import ProjectBudgetAnalysisTable from "../../dashboard/components/ProjectBudgetAnalysisTable";
import ReportArtificialSpace from "../components/ReportArtificialSpace";
import ReportFilters from "../components/ReportFilters";
import ReportStatisticsCard from "../components/ReportStatisticsCard";
import { useReports } from "../contexts/ReportsProvider";
import { FilterType, ReportChartState } from "../types";
import { FilterInputTypes } from "../utils";

const getChartValues = (
  value1: number,
  valueDiff: number,
  value3: number,
  labels: string[],
  isDollarValue: boolean = true
) => {
  const isNegativeDiff = valueDiff < 0;
  const lowerValue = value1 < value3 ? value1 : value3;
  const chartState: ReportChartState = {
    options: {
      colors: ["#FF7E5C", isNegativeDiff ? "#e0294a" : "#2CC48D", "#7E7DDE"],
      legend: {
        markers: {
          shape: "circle",
        },
      },
      plotOptions: {
        bar: {
          horizontal: false,
          borderRadius: 8,
          borderRadiusApplication: "around",
        },
      },
      dataLabels: {
        enabled: false,
      },
      stroke: {
        show: true,
        width: 2,
        colors: ["transparent"],
      },
      xaxis: {
        categories: [""],
      },
      yaxis: {
        labels: {
          formatter: (val) => {
            const isNegativeValue = val < 0;
            const absoluteValueString = Math.abs(val)?.toLocaleString();
            const convertedValueString = isDollarValue
              ? `${isNegativeValue ? "-" : ""}$${absoluteValueString}`
              : absoluteValueString;

            return convertedValueString;
          },
        },
      },
      fill: {
        opacity: 1,
      },
      tooltip: {
        followCursor: true,
        custom: function ({ series, seriesIndex, dataPointIndex }) {
          const valuesAtPoint = series.map((s: number[]) => s[dataPointIndex]);
          const lowerValueIndex = valuesAtPoint.indexOf(
            Math.min(...valuesAtPoint)
          );
          const isDifference = seriesIndex === 1;
          const value = isDifference
            ? series[seriesIndex][dataPointIndex] -
              series[lowerValueIndex][dataPointIndex]
            : series[seriesIndex][dataPointIndex];
          const valuePrefix = isDollarValue
            ? `${isDifference && isNegativeDiff ? "-" : ""}$`
            : "";

          return (
            '<div class="arrow_box px-2 py-1">' +
            `<span>${valuePrefix}` +
            Number(Number(value).toFixed(2))?.toLocaleString() +
            "</span>" +
            "</div>"
          );
        },
      },
    },
    series: [
      {
        name: labels[0],
        data: [
          {
            x: "",
            y: [0, Math.abs(value1)],
          },
        ],
      },
      {
        name: labels[1],
        data: [
          {
            x: "",
            y: [
              Math.abs(lowerValue),
              Math.abs(valueDiff) + Math.abs(lowerValue),
            ],
          },
        ],
      },
      {
        name: labels[2],
        data: [
          {
            x: "",
            y: [0, Math.abs(value3)],
          },
        ],
      },
    ],
  };

  return chartState;
};

interface ProjectBudgetVsCommittedCostsReportFields {
  "Cost Code": string | number;
  "Unit of Measurement": string | number;
  "Budget Quantity": string | number;
  "Budget Unit Rate": string | number;
  "Budget Cost": string | number;
  "Committed Quantity": string | number;
  "Committed Unit Rate": string | number;
  "Committed Cost": string | number;
  "Quantity Difference": string | number;
  "Cost Difference": string | number;
}

const ProjectBudgetVsCommittedCostsReportPage = () => {
  const { filterValues } = useReports();
  const [stats, setStats] = useState({
    totalBudgetCost: 0,
    totalBudgetQuantity: 0,
    totalBudgetUnitRate: 0,
    totalCommittedCost: 0,
    totalCommittedQuantity: 0,
    totalCommittedUnitRate: 0,
    totalCostDifference: 0,
    totalQuantityDifference: 0,
    totalUnitRateDifference: 0,
  });
  const [state, setState] = useState<{
    data: MaterialCostAnalysisRowType[];
    isLoading: boolean;
  }>({
    data: [],
    isLoading: true,
  });
  const { projectsSummarizedData } = useAppSelector(getProjectsState);
  const projectsOptions = useMemo(
    () =>
      projectsSummarizedData?.map((m) => ({
        value: m?.id || "",
        label: m?.name || "",
      })) || [],
    [projectsSummarizedData]
  );
  const costDifferenceChart: ReportChartState = getChartValues(
    stats.totalBudgetCost,
    stats.totalCostDifference,
    stats.totalCommittedCost,
    ["Budget Cost", "Cost Difference", "Committed Cost"]
  );
  const unitRateDifferenceChart: ReportChartState = getChartValues(
    stats.totalBudgetUnitRate,
    stats.totalUnitRateDifference,
    stats.totalCommittedUnitRate,
    ["Budget Unit Rate", "Unit Rate Difference", "Committed Unit Rate"]
  );
  const quantityDifferenceChart: ReportChartState = getChartValues(
    stats.totalBudgetQuantity,
    stats.totalQuantityDifference,
    stats.totalCommittedQuantity,
    ["Budget Quantity", "Quantity Difference", "Committed Quantity"],
    false
  );

  const filters: Record<string, FilterType> = useMemo(
    () => ({
      projectId: {
        label: "Project",
        type: FilterInputTypes.SELECT,
        options: projectsOptions,
        placeholder: "Select Project",
        size: 3,
        clearable: false,
        defaultValue: projectsOptions?.[0]?.value,
      },
      budgetQuantity: {
        label: "Budget Quantity Range",
        type: FilterInputTypes.NUMBER_RANGE,
        placeholder: "0.00",
        size: 3,
      },
      budgetCost: {
        label: "Budget Cost Range",
        type: FilterInputTypes.NUMBER_RANGE,
        placeholder: "$ 0.00",
        prefix: "$",
        size: 3,
        isPriceRange: true,
      },
      committedQuantity: {
        label: "Committed Quantity Range",
        type: FilterInputTypes.NUMBER_RANGE,
        placeholder: "0.00",
        size: 3,
      },
      committedCost: {
        label: "Committed Cost Range",
        type: FilterInputTypes.NUMBER_RANGE,
        placeholder: "$ 0.00",
        prefix: "$",
        size: 3,
        isPriceRange: true,
      },
      quantityDifference: {
        label: "Quantity Difference Range",
        type: FilterInputTypes.NUMBER_RANGE,
        placeholder: "0.00",
        size: 3,
        allowNegativeNumbers: true,
      },
      costDifference: {
        label: "Cost Difference Range",
        type: FilterInputTypes.NUMBER_RANGE,
        placeholder: "$ 0.00",
        prefix: "$",
        size: 3,
        isPriceRange: true,
        allowNegativeNumbers: true,
      },
    }),
    [projectsSummarizedData]
  );
  const generateExcel = () => {
    if (state.data !== null && state.data?.length > 0) {
      const data: ProjectBudgetVsCommittedCostsReportFields[] = state.data?.map(
        (m: MaterialCostAnalysisRowType) => ({
          "Cost Code": m?.costCode || 0,
          "Unit of Measurement": m?.unitOfMeasure || 0,
          "Budget Quantity": m?.budgetQuantity || 0,
          "Budget Unit Rate": `$${m?.budgetUnitRate || 0}`,
          "Budget Cost": `$${m?.budgetCost || 0}`,
          "Committed Quantity": m?.committedQuantity || 0,
          "Committed Unit Rate": `$${m?.committedUnitRate || 0}`,
          "Committed Cost": `$${m?.committedCost || 0}`,
          "Quantity Difference": m?.quantityDifference || 0,
          "Cost Difference": `$${m?.costDifference || 0}`,
        })
      );

      exportToExcel<ProjectBudgetVsCommittedCostsReportFields[]>(
        data,
        "Project Budget vs. Committed Costs Report",
        "project-budget-vs-committed-costs-report"
      );
    }
  };

  return (
    <PageLayout
      backlink={{ title: "Reports", route: routePaths.REPORTS }}
      title="Project Budget vs. Committed Costs Report"
    >
      <ReportFilters filters={filters} />

      <ReportArtificialSpace />

      <div className="flex gap-3">
        <ReportStatisticsCard title="Cost Difference">
          <div className="flex flex-col">
            <Chart
              series={costDifferenceChart.series}
              options={costDifferenceChart.options}
              type="rangeBar"
              height="300"
            />
          </div>
        </ReportStatisticsCard>
        <ReportStatisticsCard title="Unit Rate Difference">
          <div className="flex flex-col">
            <Chart
              series={unitRateDifferenceChart.series}
              options={unitRateDifferenceChart.options}
              type="rangeBar"
              height="300"
            />
          </div>
        </ReportStatisticsCard>
        <ReportStatisticsCard title="Quantity Difference">
          <div className="flex flex-col">
            <Chart
              series={quantityDifferenceChart.series}
              options={quantityDifferenceChart.options}
              type="rangeBar"
              height="300"
            />
          </div>
        </ReportStatisticsCard>
      </div>

      <ReportArtificialSpace />

      <ProjectBudgetAnalysisTable
        selectedProjectId={
          filterValues?.projectId || projectsOptions?.[0]?.value
        }
        isInsideReports={true}
        syncState={setState}
        setReportStats={setStats}
        exportButtonEl={
          <Button
            disabled={state.isLoading || !Boolean(state.data?.length)}
            onClick={generateExcel}
          >
            Export
          </Button>
        }
      />
    </PageLayout>
  );
};

export default ProjectBudgetVsCommittedCostsReportPage;
