import { getLocationslist } from "@/src/apis/locationApis";
import { getSummarizedProjectsList } from "@/src/apis/projectApis";
import { getVendorslist } from "@/src/apis/vendorApis";
import CustomIcon from "@/src/components/common/CustomIcon";
import PageLayout from "@/src/components/layout/PageLayout";
import { useAppDispatch } from "@/src/hooks/useAppDispatch";
import { useAppSelector } from "@/src/hooks/useAppSelector";
import { getLocationsState } from "@/src/store/slices/locationSlice";
import { getProjectsState } from "@/src/store/slices/projectsSlice";
import { getPurchaseOrdersState } from "@/src/store/slices/purchaseOrderSlice";
import { getVendorsState } from "@/src/store/slices/vendorSlice";
import {
  paymentTermOptions,
  purchaseOrderStatusOptions,
} from "@/src/utils/constants";
import routePaths from "@/src/utils/routePaths";
import { PurchaseOrder } from "@/src/utils/types";
import { exportToExcel } from "@/src/utils/xlsx-utils";
import { Button } from "antd";
import dayjs from "dayjs";
import { useEffect, useMemo, useState } from "react";
import Chart from "react-apexcharts";
import PurchaseOrdersList from "../../purchase-orders/components/PurchaseOrdersList";
import ReportArtificialSpace from "../components/ReportArtificialSpace";
import ReportFilters from "../components/ReportFilters";
import ReportStatisticsCard from "../components/ReportStatisticsCard";
import { FilterType, ReportChartState } from "../types";
import { FilterInputTypes } from "../utils";

type PurchaseOrderReportFields = {
  "P.O. Number": string;
  Title: string | undefined;
  Project: string;
  Location: string | null | undefined;
  "Due Date": string | undefined;
  Total: string | undefined;
  Vendor: string | undefined;
  "Payment Term": string | undefined;
  Status: string;
};

const PurchaseOrdersReportPage = () => {
  const dispatch = useAppDispatch();
  const { projectsSummarizedData } = useAppSelector(getProjectsState);
  const { locationsList } = useAppSelector(getLocationsState);
  const { purchaseOrdersData, isLoading } = useAppSelector(
    getPurchaseOrdersState
  );
  const { vendorsList } = useAppSelector(getVendorsState);
  const [stats, setStats] = useState({
    totalPurchaseOrders: 0,
    totalCost: 0,
    totalPendingAdminApproval: 0,
    totalAdminApprovedPartial: 0,
    totalAdminApprovedAll: 0,
    totalAdminRejected: 0,
    totalVendorApprovalPending: 0,
    totalVendorApproved: 0,
    totalVendorRejected: 0,
    totalPartiallyReceived: 0,
    totalFullyReceived: 0,
    totalAdminSigned: 0,
    totalNet60: 0,
    totalNet45: 0,
    totalNet30: 0,
  });
  const statusChartState: ReportChartState = {
    options: {
      chart: {
        type: "donut",
      },
      legend: {
        position: "top",
      },
      colors: [
        "#53575A",
        "#FF8C00",
        "#38C793",
        "#06AF9E",
        "#DF1C41",
        "#5B4C9E",
        "#307D57",
        "#FF4C4C",
        "#1976D2",
        "#2E8B57",
        "#307D57",
        "#FF4C4C",
      ],
      labels: purchaseOrderStatusOptions.map((m) => m.label),
    },
    series: [
      stats.totalPendingAdminApproval,
      stats.totalAdminApprovedPartial,
      stats.totalAdminApprovedAll,
      stats.totalAdminSigned,
      stats.totalAdminRejected,
      stats.totalVendorApprovalPending,
      stats.totalVendorApproved,
      stats.totalVendorRejected,
      stats.totalPartiallyReceived,
      stats.totalFullyReceived,
    ],
  };
  const paymentTermChartState: ReportChartState = {
    options: {
      chart: {
        type: "donut",
      },
      legend: {
        position: "top",
      },
      colors: ["#8AC4F0", "#9EE0B9", "#9B8DE2"],
      labels: paymentTermOptions.map((m) => m.label),
    },
    series: [stats.totalNet30, stats.totalNet45, stats.totalNet60],
  };
  const filters: Record<string, FilterType> = useMemo(
    () => ({
      projectId: {
        label: "Project",
        type: FilterInputTypes.SELECT,
        options:
          projectsSummarizedData?.map((m) => ({
            value: m?.id || "",
            label: m?.name || "",
          })) || [],
        placeholder: "Select Project",
        size: 3,
        clearable: true,
      },
      vendorId: {
        label: "Vendor",
        type: FilterInputTypes.SELECT,
        options:
          vendorsList?.map((m) => ({
            value: m?.id || "",
            label: m?.name || "",
          })) || [],
        placeholder: "Select Vendor",
        size: 3,
        clearable: true,
      },
      locationId: {
        label: "Location",
        type: FilterInputTypes.SELECT,
        options:
          locationsList?.map((m) => ({
            value: m?.id || "",
            label: m?.name || "",
            projectId: m?.projectId || "",
          })) || [],
        placeholder: "Select Location",
        filterByKey: "projectId",
        size: 3,
        clearable: true,
      },
      status: {
        label: "Status",
        type: FilterInputTypes.SELECT,
        options: purchaseOrderStatusOptions,
        placeholder: "Select Status",
        size: 3,
        clearable: true,
      },
      dueDate: {
        label: "Due Date",
        type: FilterInputTypes.DATE_RANGE,
        placeholder: "MM / DD / YYYY",
        suffix: <CustomIcon type="calendar-green-icon" />,
        size: 3,
      },
      totalPrice: {
        label: "Total Price",
        type: FilterInputTypes.NUMBER_RANGE,
        placeholder: "$ 0.00",
        prefix: "$",
        size: 3,
        isPriceRange: true,
      },
      paymentTerm: {
        label: "Payment Term",
        type: FilterInputTypes.SELECT,
        options: paymentTermOptions,
        placeholder: "Select Payment Term",
        size: 3,
        clearable: true,
      },
    }),
    [projectsSummarizedData, vendorsList, locationsList]
  );
  const generateExcel = () => {
    if (purchaseOrdersData !== null && purchaseOrdersData?.length > 0) {
      const data: PurchaseOrderReportFields[] = purchaseOrdersData?.map(
        (m: PurchaseOrder) => ({
          "P.O. Number": m?.purchaseOrderNumber || "",
          Title: m?.title || "",
          Project: m?.purchaseOrderProject?.name || "",
          Location: m?.purchaseOrderDeliveryLocation?.name || "",
          "Due Date": dayjs(m?.dueDate).format("MM/DD/YYYY").toString(),
          Total: m?.total?.toLocaleString(),
          Vendor: m?.vendor?.name || "",
          "Payment Term":
            paymentTermOptions?.find((f) => f?.value === m?.paymentTerm)
              ?.label || "",
          Status:
            purchaseOrderStatusOptions?.find((f) => f?.value === m?.status)
              ?.label || "",
        })
      );

      exportToExcel<PurchaseOrderReportFields[]>(
        data,
        "Purchase Orders",
        "purchase-orders-report"
      );
    }
  };

  useEffect(() => {
    dispatch(getSummarizedProjectsList());
    dispatch(getVendorslist());
    dispatch(getLocationslist());
  }, []);

  return (
    <PageLayout
      backlink={{ title: "Reports", route: routePaths.REPORTS }}
      title="Purchase Orders Report"
    >
      <ReportFilters filters={filters} />

      <ReportArtificialSpace />

      <div className="flex gap-3">
        <div className="flex flex-col basis-2/6 gap-3">
          <ReportStatisticsCard
            className="grow-0"
            title="Total Purchase Orders"
            stat={stats.totalPurchaseOrders}
          />

          <ReportStatisticsCard
            className="grow-0"
            title="Total Cost"
            stat={`$${stats.totalCost?.toLocaleString()}`}
          />
        </div>

        <ReportStatisticsCard title="Status">
          <div className="flex flex-col">
            <Chart
              series={statusChartState.series}
              options={statusChartState.options}
              type="donut"
              height="300"
            />
          </div>
        </ReportStatisticsCard>

        <ReportStatisticsCard title="Payment Terms" hasMarginTopAuto={false}>
          <div className="flex flex-col">
            <Chart
              series={paymentTermChartState.series}
              options={paymentTermChartState.options}
              type="donut"
              width="100%"
              height="300"
            />
          </div>
        </ReportStatisticsCard>
      </div>

      <ReportArtificialSpace />

      <PurchaseOrdersList
        setReportStats={(
          totalPurchaseOrders,
          totalCost,
          totalPendingAdminApproval,
          totalAdminApprovedPartial,
          totalAdminApprovedAll,
          totalAdminRejected,
          totalVendorApprovalPending,
          totalVendorApproved,
          totalVendorRejected,
          totalPartiallyReceived,
          totalFullyReceived,
          totalAdminSigned,
          totalNet60,
          totalNet45,
          totalNet30
        ) => {
          setStats({
            totalPurchaseOrders: totalPurchaseOrders || 0,
            totalCost: totalCost || 0,
            totalPendingAdminApproval: totalPendingAdminApproval || 0,
            totalAdminApprovedPartial: totalAdminApprovedPartial || 0,
            totalAdminApprovedAll: totalAdminApprovedAll || 0,
            totalAdminRejected: totalAdminRejected || 0,
            totalVendorApprovalPending: totalVendorApprovalPending || 0,
            totalVendorApproved: totalVendorApproved || 0,
            totalVendorRejected: totalVendorRejected || 0,
            totalPartiallyReceived: totalPartiallyReceived || 0,
            totalFullyReceived: totalFullyReceived || 0,
            totalAdminSigned: totalAdminSigned || 0,
            totalNet60: totalNet60 || 0,
            totalNet45: totalNet45 || 0,
            totalNet30: totalNet30 || 0,
          });
        }}
        exportButtonEl={
          <Button
            disabled={isLoading || !Boolean(purchaseOrdersData?.length)}
            onClick={generateExcel}
          >
            Export
          </Button>
        }
      />
    </PageLayout>
  );
};

export default PurchaseOrdersReportPage;
