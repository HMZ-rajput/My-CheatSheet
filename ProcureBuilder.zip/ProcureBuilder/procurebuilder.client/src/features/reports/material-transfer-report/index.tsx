import { getLocationslist } from "@/src/apis/locationApis";
import { getSummarizedProjectsList } from "@/src/apis/projectApis";
import CustomIcon from "@/src/components/common/CustomIcon";
import PageLayout from "@/src/components/layout/PageLayout";
import { useAppDispatch } from "@/src/hooks/useAppDispatch";
import { useAppSelector } from "@/src/hooks/useAppSelector";
import { getLocationsState } from "@/src/store/slices/locationSlice";
import { getMaterialTransferState } from "@/src/store/slices/materialTransferSlice";
import { getProjectsState } from "@/src/store/slices/projectsSlice";
import { materialTransferStatusOptions } from "@/src/utils/constants";
import routePaths from "@/src/utils/routePaths";
import { MaterialTransfer } from "@/src/utils/types";
import { exportToExcel } from "@/src/utils/xlsx-utils";
import { Button } from "antd";
import dayjs from "dayjs";
import { useEffect, useMemo, useState } from "react";
import Chart from "react-apexcharts";
import MaterialTransferList from "../../material-transfer/components/MaterialTransferList";
import ReportArtificialSpace from "../components/ReportArtificialSpace";
import ReportFilters from "../components/ReportFilters";
import ReportStatisticsCard from "../components/ReportStatisticsCard";
import { FilterType, ReportChartState } from "../types";
import { FilterInputTypes } from "../utils";

type MaterialTransferReportFields = {
  Title: string;
  Project: string;
  "Original Location": string;
  "Delivering To": string;
  "Destination Sublocation": string | undefined;
  "Transfer Date": string;
  Status: string;
};

const MaterialTransferReportPage = () => {
  const dispatch = useAppDispatch();
  const { projectsSummarizedData } = useAppSelector(getProjectsState);
  const { locationsList } = useAppSelector(getLocationsState);
  const { materialTransferData, isLoading } = useAppSelector(
    getMaterialTransferState
  );
  const [stats, setStats] = useState({
    totalTransfers: 0,
    totalCancelled: 0,
    totalInProgress: 0,
    totalPending: 0,
    totalTransferred: 0,
  });
  const statusOptions = materialTransferStatusOptions;
  const statusChartState: ReportChartState = {
    options: {
      chart: {
        type: "donut",
      },
      legend: {
        position: "top",
      },
      colors: ["#A9ABAC", "#5b4c9e", "#2e8b57", "#df1c41"],
      labels: statusOptions.map((m) => m.label),
    },
    series: [
      stats.totalPending,
      stats.totalInProgress,
      stats.totalTransferred,
      stats.totalCancelled,
    ],
  };
  const filters: Record<string, FilterType> = useMemo(
    () => ({
      projectId: {
        label: "Project",
        type: FilterInputTypes.SELECT,
        options:
          projectsSummarizedData?.map((m) => ({
            value: m?.id || "",
            label: m?.name || "",
          })) || [],
        placeholder: "Select Project",
        size: 3,
        clearable: true,
      },
      status: {
        label: "Status",
        type: FilterInputTypes.SELECT,
        options: statusOptions,
        placeholder: "Select Status",
        size: 3,
        clearable: true,
      },
      originalLocationId: {
        label: "Original Location",
        type: FilterInputTypes.SELECT,
        options:
          locationsList?.map((m) => ({
            value: m?.id || "",
            label: m?.name || "",
            projectId: m?.projectId || "",
          })) || [],
        placeholder: "Select Location",
        filterByKey: "projectId",
        size: 3,
        clearable: true,
      },
      transferDate: {
        label: "Transfer Date",
        type: FilterInputTypes.DATE_RANGE,
        placeholder: "MM / DD / YYYY",
        suffix: <CustomIcon type="calendar-green-icon" />,
        size: 3,
      },
      destinationLocationId: {
        label: "Delivering To",
        type: FilterInputTypes.SELECT,
        options:
          locationsList?.map((m) => ({
            value: m?.id || "",
            label: m?.name || "",
            projectId: m?.projectId || "",
          })) || [],
        placeholder: "Select Location",
        filterByKey: "projectId",
        size: 3,
        clearable: true,
      },
    }),
    [projectsSummarizedData, locationsList]
  );
  const generateExcel = () => {
    if (materialTransferData !== null && materialTransferData?.length > 0) {
      const data: MaterialTransferReportFields[] = materialTransferData?.map(
        (m: MaterialTransfer) => ({
          Title: m?.title || "",
          Project: m?.originalProject?.name || "",
          "Original Location": m?.originalLocation?.name || "",
          "Delivering To": m?.destinationLocation?.name || "",
          "Destination Sublocation": m?.destinationSubLocation?.name || "",
          "Transfer Date": dayjs(m?.transferDate)
            ?.format("MM/DD/YYYY")
            ?.toString(),
          Status:
            statusOptions?.find((f) => f?.value === m?.status)?.label || "",
        })
      );

      exportToExcel<MaterialTransferReportFields[]>(
        data,
        "Material Transfers",
        "material-transfers-report"
      );
    }
  };

  useEffect(() => {
    dispatch(getSummarizedProjectsList());
    dispatch(getLocationslist());
  }, []);

  return (
    <PageLayout
      backlink={{ title: "Reports", route: routePaths.REPORTS }}
      title="Material Transfer Report"
    >
      <ReportFilters filters={filters} />

      <ReportArtificialSpace />

      <div className="flex gap-3">
        <div className="flex flex-col basis-2/6 gap-3">
          <ReportStatisticsCard
            title="Total Transfers"
            stat={stats.totalTransfers}
            className="grow-0"
          />
          <div className="grow-[2]"></div>
        </div>

        <ReportStatisticsCard title="Status">
          <div className="flex flex-col">
            <Chart
              series={statusChartState.series}
              options={statusChartState.options}
              type="donut"
              height="300"
            />
          </div>
        </ReportStatisticsCard>
      </div>

      <ReportArtificialSpace />

      <MaterialTransferList
        setReportStats={setStats}
        exportButtonEl={
          <Button
            disabled={isLoading || !Boolean(materialTransferData?.length)}
            onClick={generateExcel}
          >
            Export
          </Button>
        }
      />
    </PageLayout>
  );
};

export default MaterialTransferReportPage;
