import { getLocationslist } from "@/src/apis/locationApis";
import { downloadPdf } from "@/src/apis/materialReceiptInceptionApis";
import { getSummarizedProjectsList } from "@/src/apis/projectApis";
import { getPurchaseOrdersList } from "@/src/apis/purchaseOrderApis";
import CustomIcon from "@/src/components/common/CustomIcon";
import PageLayout from "@/src/components/layout/PageLayout";
import { useAppDispatch } from "@/src/hooks/useAppDispatch";
import { useAppSelector } from "@/src/hooks/useAppSelector";
import { getLocationsState } from "@/src/store/slices/locationSlice";
import { getMaterialReceiptInspectionState } from "@/src/store/slices/materialReceiptInceptionSlice";
import { getProjectsState } from "@/src/store/slices/projectsSlice";
import { getPurchaseOrdersState } from "@/src/store/slices/purchaseOrderSlice";
import { manuallyDownloadBlob } from "@/src/utils/api-helpers";
import { MaterialReceiptInspectionsStatusOptions } from "@/src/utils/constants";
import routePaths from "@/src/utils/routePaths";
import { MaterialReceiptInspection } from "@/src/utils/types";
import { exportToExcel } from "@/src/utils/xlsx-utils";
import { Dropdown, MenuProps } from "antd";
import dayjs from "dayjs";
import { useEffect, useMemo, useState } from "react";
import Chart from "react-apexcharts";
import MaterialReceiptInseptionsList from "../../material-receipt-inceptions/component/MaterialReceiptInceptionsList";
import ReportArtificialSpace from "../components/ReportArtificialSpace";
import ReportFilters from "../components/ReportFilters";
import ReportStatisticsCard from "../components/ReportStatisticsCard";
import { FilterType, ReportChartState } from "../types";
import { FilterInputTypes } from "../utils";

type MaterialReceiptInspectionReportFields = {
  Title: string;
  Project: string;
  "Original Location": string;
  "P.O. Number": string;
  "Expected Date": string;
  "Received Date": string;
  Status: string;
};

const MaterialReceiptInspectionReportPage = () => {
  const dispatch = useAppDispatch();
  const { projectsSummarizedData } = useAppSelector(getProjectsState);
  const { locationsList } = useAppSelector(getLocationsState);
  const { purchaseOrdersList } = useAppSelector(getPurchaseOrdersState);
  const { MaterialReceiptInspectionData, isLoading } = useAppSelector(
    getMaterialReceiptInspectionState
  );
  const [stats, setStats] = useState({
    totalInspections: 0,
    totalRejected: 0,
    totalApproved: 0,
    totalApprovedWithExceptions: 0,
    totalPending: 0,
    totalTransferred: 0,
  });
  const statusOptions = MaterialReceiptInspectionsStatusOptions;
  const statusChartState: ReportChartState = {
    options: {
      chart: {
        type: "donut",
      },
      legend: {
        position: "top",
      },
      colors: ["#A9ABAC", "#1976d2", "#2e8b57", "#df1c41"],
      labels: statusOptions.map((m) => m.label),
    },
    series: [
      stats.totalPending,
      stats.totalApproved,
      stats.totalApprovedWithExceptions,
      stats.totalRejected,
    ],
  };
  const filters: Record<string, FilterType> = useMemo(
    () => ({
      projectId: {
        label: "Project",
        type: FilterInputTypes.SELECT,
        options:
          projectsSummarizedData?.map((m) => ({
            value: m?.id || "",
            label: m?.name || "",
          })) || [],
        placeholder: "Select Project",
        size: 3,
        clearable: true,
      },
      purchaseOrderId: {
        label: "P.O. Number",
        type: FilterInputTypes.SELECT,
        options:
          purchaseOrdersList?.map((m) => ({
            value: m?.id,
            label: m?.purchaseOrderNumber,
            projectId: m?.projectId || "",
          })) || [],
        filterByKey: "projectId",
        shouldDisableIfFilterBy: false,
        placeholder: "Select P.O. Number",
        size: 3,
        clearable: true,
      },
      status: {
        label: "Status",
        type: FilterInputTypes.SELECT,
        options: statusOptions,
        placeholder: "Select Status",
        size: 3,
        clearable: true,
      },
      locationId: {
        label: "Location",
        type: FilterInputTypes.SELECT,
        options:
          locationsList?.map((m) => ({
            value: m?.id || "",
            label: m?.name || "",
            projectId: m?.projectId || "",
          })) || [],
        placeholder: "Select Location",
        filterByKey: "projectId",
        size: 3,
        clearable: true,
      },
      requestedDate: {
        label: "Received Date",
        type: FilterInputTypes.DATE_RANGE,
        placeholder: "MM / DD / YYYY",
        suffix: <CustomIcon type="calendar-green-icon" />,
        size: 3,
      },
    }),
    [projectsSummarizedData, locationsList, purchaseOrdersList]
  );
  const generateExcel = (data: MaterialReceiptInspection[] | null) => {
    if (
      MaterialReceiptInspectionData !== null &&
      MaterialReceiptInspectionData?.length > 0
    ) {
      const parsedData: MaterialReceiptInspectionReportFields[] =
        data?.map((m: MaterialReceiptInspection) => ({
          Title: m?.title || "",
          Project: m?.project?.name || "",
          "Original Location": m?.location?.name || "",
          "P.O. Number": m?.purchaseOrder?.purchaseOrderNumber || "",
          "Expected Date": dayjs(m?.expectedDate)
            ?.format("MM/DD/YYYY")
            ?.toString(),
          "Received Date": !m?.requestedDate
            ? ""
            : dayjs(m?.requestedDate)?.format("MM/DD/YYYY")?.toString(),
          Status:
            statusOptions?.find((f) => f?.value === m?.status)?.label || "",
        })) || [];

      exportToExcel<MaterialReceiptInspectionReportFields[]>(
        parsedData,
        "Material Receipt Inspection",
        "material-receipt-inspection-report"
      );
    }
  };

  enum ExportTypeEnum {
    XLSX,
    PDF,
  }

  const items = [
    {
      key: ExportTypeEnum.XLSX,
      label: "Excel (XLSX)",
    },
    {
      key: ExportTypeEnum.PDF,
      label: "Document (PDF)",
    },
  ];

  const onMenuClick: MenuProps["onClick"] = async (e) => {
    if (
      MaterialReceiptInspectionData !== null &&
      MaterialReceiptInspectionData?.length > 0
    ) {
      if (e.key === `${ExportTypeEnum.XLSX}`) {
        generateExcel(MaterialReceiptInspectionData);
      } else {
        try {
          const blob = await dispatch(
            downloadPdf(MaterialReceiptInspectionData?.map((m) => m?.id || ""))
          ).unwrap();
          const name = `material-receipt-inspection-report-${Date.now()}.pdf`;

          manuallyDownloadBlob(blob, name);
        } catch (e) {
          console.error(e);
        }
      }
    }
  };

  useEffect(() => {
    dispatch(getPurchaseOrdersList({ projectId: "" }));
    dispatch(getSummarizedProjectsList());
    dispatch(getLocationslist());
  }, []);

  return (
    <PageLayout
      backlink={{ title: "Reports", route: routePaths.REPORTS }}
      title="Material Receipt Inspection Report"
    >
      <ReportFilters filters={filters} />

      <ReportArtificialSpace />

      <div className="flex gap-3">
        <div className="flex flex-col basis-2/6 gap-3">
          <ReportStatisticsCard
            title="Total Material Receipt Inspections"
            stat={stats.totalInspections}
            className="grow-0"
          />
          <div className="grow-[2]"></div>
        </div>

        <ReportStatisticsCard title="Status">
          <div className="flex flex-col">
            <Chart
              series={statusChartState.series}
              options={statusChartState.options}
              type="donut"
              height="300"
            />
          </div>
        </ReportStatisticsCard>
      </div>

      <ReportArtificialSpace />

      <MaterialReceiptInseptionsList
        setReportStats={setStats}
        exportButtonEl={
          <>
            <Dropdown.Button
              disabled={isLoading}
              menu={{ items, onClick: onMenuClick }}
              onClick={() => generateExcel(MaterialReceiptInspectionData)}
            >
              Export
            </Dropdown.Button>
          </>
        }
      />
    </PageLayout>
  );
};

export default MaterialReceiptInspectionReportPage;
