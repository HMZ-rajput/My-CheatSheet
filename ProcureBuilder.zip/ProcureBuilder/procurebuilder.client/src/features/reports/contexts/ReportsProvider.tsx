import { createContext, useContext, useEffect, useState } from "react";
import { FieldValues } from "react-hook-form";
import useSyncReportFilters from "../hooks/useSyncReportFilters";

const initialState = {
  filterValues: null,
  updateFilterValues: () => {},
};

type ReportsContext = {
  filterValues: FieldValues | null;
  updateFilterValues: (values: FieldValues | null) => void;
};

const ReportsCtx = createContext<ReportsContext>(initialState);
export const useReports = () => useContext(ReportsCtx);

interface ReportsProvider {
  children: React.ReactNode;
}

const ReportsProvider = ({ children }: ReportsProvider) => {
  const { syncFiltersWithParams } = useSyncReportFilters();
  const [filterValues, setFilterValues] = useState<FieldValues | null>(null);

  const updateFilterValues = (values: FieldValues | null) => {
    setFilterValues(values);
  };

  const isReportsPage = () => {
    return /^\/reports\/[^/]+/.test(window.location.pathname);
  };

  useEffect(() => {
    if (isReportsPage()) {
      syncFiltersWithParams(filterValues);
    }
  }, [filterValues]);

  return (
    <ReportsCtx.Provider
      value={{
        filterValues,
        updateFilterValues,
      }}
    >
      {children}
    </ReportsCtx.Provider>
  );
};

export default ReportsProvider;
