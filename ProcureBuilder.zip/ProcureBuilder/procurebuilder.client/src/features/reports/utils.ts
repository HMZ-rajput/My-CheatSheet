import routePaths from "@/src/utils/routePaths";
import { SectionCards } from "./types";

const projectManagementCards: SectionCards = {
  Projects: {
    desc: "Track project timelines, budgets, milestones, and team progress to ensure alignment with goals.",
    route: routePaths.PROJECTS_REPORT,
  },
  "Bid Materials": {
    desc: "Track and manage materials for current bids, inventory, and any changes to orders.",
    route: routePaths.BID_MATERIALS_REPORT,
  },
  "Change Orders": {
    desc: "Display change order updates with status, amounts, and deadlines for each project.",
    route: routePaths.CHANGE_ORDERS_REPORT,
  },
  "Project Budget vs. Committed Costs Report": {
    desc: "Track project budgets, committed costs, and progress to ensure alignment with financial goals.",
    route: routePaths.PROJECT_BUDGET_VS_COMMITTED_COSTS_REPORT,
  },
};
const procurementsFinancialsCards: SectionCards = {
  "Purchase Orders": {
    desc: "Overview of POs, due dates, and vendor details for streamlined procurement tracking.",
    route: routePaths.PURCHASE_ORDERS_REPORT,
  },
  Reorders: {
    desc: "Show reorders by request and due dates, vendor status, and project associations.",
    route: routePaths.REORDERS_REPORT,
  },
  Invoices: {
    desc: "Review and manage invoices associated with project orders and vendor payments.",
    route: routePaths.INVOICES_REPORT,
  },
};
const materialManagementCards: SectionCards = {
  Inventory: {
    desc: "View current inventory quantities, item types, and availability for project needs.",
    route: routePaths.INVENTORY_REPORT,
  },
  "Material Transfer": {
    desc: "Track material movements between storage locations, showing transfer dates & destinations.",
    route: routePaths.MATERIAL_TRANSFER_REPORT,
  },
  "Material Going to Site": {
    desc: "Track materials sent to project sites with transfer statuses, sub-locations, and delivery timelines.",
    route: routePaths.MATERIAL_GOING_TO_SITE_REPORT,
  },
  "Material Receipt Inspection": {
    desc: "Track inspection statuses of incoming materials upon receipt for quality assurance.",
    route: routePaths.MATERIAL_INSPECTION_REPORT,
  },
};
export const reportSections = {
  "Project Management": projectManagementCards,
  "Procurements Financials": procurementsFinancialsCards,
  "Material Management": materialManagementCards,
};

export enum FilterInputTypes {
  INPUT = "INPUT",
  SELECT = "select",
  NUMBER_INPUT_SELECT_COMBO = "number_input_select_combo",
  NUMBER_RANGE = "number_range",
  DATE_RANGE = "date_range",
}
