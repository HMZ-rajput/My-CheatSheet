import PageLayout from "@/src/components/layout/PageLayout";
import ReportList from "./components/ReportList";

const ReportPage = () => {
  return (
    <PageLayout title="Reports">
      <ReportList />
    </PageLayout>
  );
};

export default ReportPage;
