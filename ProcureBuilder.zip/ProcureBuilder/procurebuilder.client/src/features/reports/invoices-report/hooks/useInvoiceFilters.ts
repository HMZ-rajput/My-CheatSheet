import { InvoiceReportFilters } from "@/src/utils/types";
import { useEffect, useState } from "react";
import { useReports } from "../../contexts/ReportsProvider";

export default function useInvoiceFilters() {
  const { filterValues } = useReports();
  const [formattedFilterValues, setFormattedFilterValues] =
    useState<InvoiceReportFilters | null>(null);

  useEffect(() => {
    if (
      JSON.stringify(filterValues || {}) === "{}" ||
      JSON.stringify(filterValues || {}) !==
        JSON.stringify(formattedFilterValues || {})
    ) {
      setFormattedFilterValues(filterValues || {});
    }
  }, [filterValues]);

  return formattedFilterValues;
}
