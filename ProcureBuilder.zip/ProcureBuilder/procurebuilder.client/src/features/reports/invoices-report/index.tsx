import { getSummarizedProjectsList } from "@/src/apis/projectApis";
import { getPurchaseOrdersList } from "@/src/apis/purchaseOrderApis";
import { getVendorslist } from "@/src/apis/vendorApis";
import CustomIcon from "@/src/components/common/CustomIcon";
import PageLayout from "@/src/components/layout/PageLayout";
import SectionLayout from "@/src/components/layout/SectionLayout";
import { useAppDispatch } from "@/src/hooks/useAppDispatch";
import { useAppSelector } from "@/src/hooks/useAppSelector";
import { getProjectsState } from "@/src/store/slices/projectsSlice";
import { getPurchaseOrdersState } from "@/src/store/slices/purchaseOrderSlice";
import { getVendorsState } from "@/src/store/slices/vendorSlice";
import { call } from "@/src/utils/api-helpers";
import { invoicesStatusOptions } from "@/src/utils/constants";
import routePaths from "@/src/utils/routePaths";
import { Typography } from "antd";
import { useEffect, useMemo, useState } from "react";
import ReportArtificialSpace from "../components/ReportArtificialSpace";
import ReportFilters from "../components/ReportFilters";
import { FilterType } from "../types";
import { FilterInputTypes } from "../utils";
import InvoicePODetailsReportList from "./InvoicePODetailsReportList";
import InvoicePOReportList from "./InvoicePOReportList";
import InvoiceProjectCostCodeReportList from "./InvoiceProjectCostCodeReportList";
import InvoiceProjectsReportList from "./InvoiceProjectsReportList";

type SummarizedInvoice = {
  id: string;
  invoiceNumber: string;
};

const InvoicesReportPage = () => {
  const dispatch = useAppDispatch();
  const { purchaseOrdersList } = useAppSelector(getPurchaseOrdersState);
  const { projectsSummarizedData } = useAppSelector(getProjectsState);
  const { vendorsList } = useAppSelector(getVendorsState);

  const purchaseOrderDefaultState = {
    id: "",
    number: "",
  };
  const [purchaseOrder, setPurchaseOrder] = useState(purchaseOrderDefaultState);
  const [summarizedInvoices, setSummarizedInvoices] = useState<
    SummarizedInvoice[] | null
  >(null);

  const filters: Record<string, FilterType> = useMemo(
    () => ({
      projectId: {
        label: "Project",
        type: FilterInputTypes.SELECT,
        options:
          projectsSummarizedData?.map((m) => ({
            value: m?.id || "",
            label: m?.name || "",
          })) || [],
        placeholder: "Select Project",
        size: 2,
        clearable: true,
      },
      vendorId: {
        label: "Vendor",
        type: FilterInputTypes.SELECT,
        options:
          vendorsList?.map((m) => ({
            value: m?.id || "",
            label: m?.name || "",
          })) || [],
        placeholder: "Select Vendor",
        size: 2,
        clearable: true,
      },
      status: {
        label: "Status",
        type: FilterInputTypes.SELECT,
        options: invoicesStatusOptions,
        placeholder: "Select Status",
        size: 2,
        clearable: true,
      },
      invoiceDate: {
        label: "Invoice Date",
        type: FilterInputTypes.DATE_RANGE,
        placeholder: "MM / DD / YYYY",
        suffix: <CustomIcon type="calendar-green-icon" />,
        size: 2,
      },
      dueDate: {
        label: "Due Date",
        type: FilterInputTypes.DATE_RANGE,
        placeholder: "MM / DD / YYYY",
        suffix: <CustomIcon type="calendar-green-icon" />,
        size: 2,
      },
      invoiceAmount: {
        label: "Amount Range",
        type: FilterInputTypes.NUMBER_RANGE,
        placeholder: "$ 0.00",
        prefix: "$",
        size: 2,
        isPriceRange: true,
      },
      invoiceNumber: {
        label: "Invoice Number",
        type: FilterInputTypes.SELECT,
        options:
          summarizedInvoices?.map((m) => ({
            value: m?.invoiceNumber || "",
            label: m?.invoiceNumber || "",
          })) || [],
        placeholder: "Select Invoice Number",
        size: 2,
        clearable: true,
      },
      costCode: {
        label: "Cost Code",
        type: FilterInputTypes.INPUT,
        placeholder: "Cost Code",
        size: 2,
      },
      purchaseOrderId: {
        label: "Purchase Order",
        type: FilterInputTypes.SELECT,
        options:
          purchaseOrdersList?.map((m) => ({
            value: m?.id || "",
            label: `${m?.title} - ${m?.purchaseOrderNumber}`?.trim() || "",
            projectId: m?.projectId || "",
          })) || [],
        placeholder: "Select Purchase Order",
        size: 3,
        clearable: true,
        filterByKey: "projectId",
        shouldDisableIfFilterBy: false,
      },
    }),
    [projectsSummarizedData, vendorsList, purchaseOrdersList]
  );

  const getSummarizedInvoices = async () => {
    try {
      const res = (await call({
        method: "GET",
        url: "invoice/list",
      })) as {
        data: SummarizedInvoice[];
        errors: string[];
      };

      if (res?.errors?.length > 0) {
        console.error(res?.errors);
        return;
      }

      setSummarizedInvoices(res?.data || []);
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    dispatch(getSummarizedProjectsList());
    dispatch(getVendorslist());
    dispatch(getPurchaseOrdersList({ projectId: "" }));

    getSummarizedInvoices();
  }, []);

  return (
    <PageLayout
      backlink={{ title: "Reports", route: routePaths.REPORTS }}
      title="Invoices Report"
    >
      <ReportFilters filters={filters} />

      <ReportArtificialSpace />

      <SectionLayout>
        <div className="flex gap-8 items-start">
          <div className="max-w-[calc(45%-16px)]">
            <Typography.Title level={4} className="!mt-0 !mb-2">
              Project Summary
            </Typography.Title>

            <InvoiceProjectsReportList />
          </div>

          <div className="max-w-[calc(55%-16px)]">
            <Typography.Title level={4} className="!mt-0 !mb-2">
              Cost Code Summary
            </Typography.Title>

            <InvoiceProjectCostCodeReportList />
          </div>
        </div>
      </SectionLayout>

      <ReportArtificialSpace />

      <SectionLayout className="pt-6 px-6 pb-0  rounded-2xl">
        <div className="flex items-center gap-2 mb-6">
          <Typography.Title
            level={4}
            onClick={() => setPurchaseOrder(purchaseOrderDefaultState)}
            className={`!my-0 ${
              purchaseOrder.number
                ? `!text-primary hover:!text-primaryHover cursor-pointer underline`
                : ""
            }`}
          >
            Purchase Order Summary
          </Typography.Title>

          {purchaseOrder.number ? (
            <>
              <Typography.Title level={4} className="!my-0">
                &gt;
              </Typography.Title>
              <Typography.Title level={4} className="!my-0">
                {purchaseOrder.number}
              </Typography.Title>
            </>
          ) : null}
        </div>
        {purchaseOrder?.id ? (
          <InvoicePODetailsReportList purchaseOrderId={purchaseOrder?.id} />
        ) : (
          <InvoicePOReportList setPurchaseOrder={setPurchaseOrder} />
        )}
      </SectionLayout>
    </PageLayout>
  );
};

export default InvoicesReportPage;
