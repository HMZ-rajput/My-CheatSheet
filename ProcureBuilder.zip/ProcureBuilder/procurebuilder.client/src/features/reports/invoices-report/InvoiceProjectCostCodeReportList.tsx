import { getInvoiceProjectCostCodeReportList } from "@/src/apis/invoicesApis";
import CustomTable from "@/src/components/table/CustomTable";
import { convertToLocaleString } from "@/src/utils/helper";
import { InvoiceProjectCostCodeReportRow } from "@/src/utils/types";
import { TableProps } from "antd";
import { useCallback, useEffect, useState } from "react";
import useInvoiceFilters from "./hooks/useInvoiceFilters";

const columns: TableProps<InvoiceProjectCostCodeReportRow>["columns"] = [
  { dataIndex: "projectName", title: "Project", key: "projectName" },
  { dataIndex: "costCode", title: "Cost Code", key: "costCode" },
  {
    dataIndex: "sumOfMoneyCommittedToCostCode",
    title: "Committed Total",
    key: "sumOfMoneyCommittedToCostCode",
    render(value) {
      return `$${convertToLocaleString(value)}`;
    },
  },
  {
    dataIndex: "sumOfInvoiceReceivedToCostCode",
    title: "Invoices Total",
    key: "sumOfInvoiceReceivedToCostCode",
    render(value) {
      return `$${convertToLocaleString(value)}`;
    },
  },
  {
    dataIndex: "remainingToBePaidToCostCode",
    title: "Remaining",
    key: "remainingToBePaidToCostCode",
    render(value) {
      return `$${convertToLocaleString(value)}`;
    },
  },
  {
    dataIndex: "invoicedToDatePerc",
    title: "% Invoiced",
    key: "invoicedToDatePerc",
    render(value) {
      return `${convertToLocaleString(value)}%`;
    },
  },
];

const InvoiceProjectCostCodeReportList = () => {
  const filters = useInvoiceFilters();

  const [data, setData] = useState<InvoiceProjectCostCodeReportRow[] | null>(
    null
  );
  const [totalCount, setTotalCount] = useState<number>(0);
  const [page, setPage] = useState<number>(1);
  const [pageSize, setPageSize] = useState<number>(5);

  const api = useCallback(async () => {
    try {
      setData(() => null);
      setTotalCount(0);

      const res = await getInvoiceProjectCostCodeReportList({
        pageNumber: page,
        pageSize: pageSize,
        ...filters,
      });

      if (res?.errors?.length === 0) {
        setTotalCount(res?.totalCount || 0);
        setData(() => res?.data || []);
      } else {
        setData(() => []);
        setTotalCount(0);
      }
    } catch (e) {
      setData(() => []);
      setTotalCount(0);
      console.error("ERROR: ", e);
    }
  }, [page, pageSize, filters]);

  useEffect(() => {
    api();
  }, [api]);

  return (
    <CustomTable
      data={data || []}
      columns={columns}
      isLoading={data === null}
      totalCount={totalCount}
      page={page}
      setPage={setPage}
      pageSize={pageSize}
      setPageSize={setPageSize}
      hasPagination
      hasSearch={false}
      isInsideReports
      hasTopBar={false}
      isSmallTable
    />
  );
};

export default InvoiceProjectCostCodeReportList;
