import { getInvoicePODetailsReportList } from "@/src/apis/invoicesApis";
import CustomTable from "@/src/components/table/CustomTable";
import { convertToLocaleString } from "@/src/utils/helper";
import { InvoicePOInvoiceReportRow } from "@/src/utils/types";
import { TableProps } from "antd";
import { useCallback, useEffect, useState } from "react";
import useInvoiceFilters from "./hooks/useInvoiceFilters";

const columns: TableProps<InvoicePOInvoiceReportRow>["columns"] = [
  {
    dataIndex: "material",
    title: "Material",
    key: "material",
  },
  {
    dataIndex: "costCode",
    title: "Cost Code",
    key: "costCode",
  },
  // {
  //   dataIndex: "description",
  //   title: "Description",
  //   key: "description",
  // },
  {
    dataIndex: "purchaseOrderQuantity",
    title: "PO Quantity",
    key: "purchaseOrderQuantity",
  },
  {
    dataIndex: "purchaseOrderCostPerLineItem",
    title: "PO Cost",
    key: "purchaseOrderCostPerLineItem",
    render(value) {
      return `$${convertToLocaleString(value)}`;
    },
  },
  {
    dataIndex: "quantityBilledToDate",
    title: "Quantity Billed",
    key: "quantityBilledToDate",
    render(value) {
      return `${convertToLocaleString(value)}`;
    },
  },
  {
    dataIndex: "costBilledToDate",
    title: "Cost Billed",
    key: "costBilledToDate",
    render(value) {
      return `$${convertToLocaleString(value)}`;
    },
  },
  {
    dataIndex: "remainderQuantity",
    title: "Remainder Quantity",
    key: "remainderQuantity",
  },
  {
    dataIndex: "remainderOfCostToBeBilled",
    title: "Remainder Cost",
    key: "remainderOfCostToBeBilled",
    render(value) {
      return `$${convertToLocaleString(value)}`;
    },
  },
  {
    dataIndex: "invoiceNumbers",
    title: "Invoice Numbers",
    key: "invoiceNumbers",
  },
];

type InvoicePODetailsReportListProps = {
  purchaseOrderId: string;
};

const InvoicePODetailsReportList = ({
  purchaseOrderId,
}: InvoicePODetailsReportListProps) => {
  const filters = useInvoiceFilters();

  const [data, setData] = useState<InvoicePOInvoiceReportRow[] | null>(null);
  const [totalCount, setTotalCount] = useState<number>(0);
  const [page, setPage] = useState<number>(1);
  const [pageSize, setPageSize] = useState<number>(10);

  const api = useCallback(async () => {
    if (filters === null || !purchaseOrderId) return;

    try {
      setData(() => null);
      setTotalCount(0);

      const res = await getInvoicePODetailsReportList({
        ...filters,
        pageNumber: page,
        pageSize: pageSize,
        purchaseOrderId: purchaseOrderId,
      });

      if (res?.errors?.length === 0) {
        setTotalCount(res?.totalCount || 0);
        setData(() => res?.data || []);
      } else {
        setData(() => []);
        setTotalCount(0);
      }
    } catch (e) {
      setData(() => []);
      setTotalCount(0);
      console.error("ERROR: ", e);
    }
  }, [page, pageSize, filters, purchaseOrderId]);

  useEffect(() => {
    api();
  }, [api]);

  return (
    <CustomTable
      data={data || []}
      columns={columns}
      isLoading={data === null}
      totalCount={totalCount}
      page={page}
      setPage={setPage}
      pageSize={pageSize}
      setPageSize={setPageSize}
      hasPagination
      hasSearch={false}
      isInsideReports
      hasTopBar={false}
      isNormalTable
    />
  );
};

export default InvoicePODetailsReportList;
