import { getInvoicePOReportList } from "@/src/apis/invoicesApis";
import CustomTable from "@/src/components/table/CustomTable";
import { convertToLocaleString } from "@/src/utils/helper";
import { InvoicePOReportRow } from "@/src/utils/types";
import { TableProps } from "antd";
import { useCallback, useEffect, useState } from "react";
import useInvoiceFilters from "./hooks/useInvoiceFilters";

const columns: TableProps<InvoicePOReportRow>["columns"] = [
  {
    dataIndex: "purchaseOrderNumber",
    title: "PO#",
    key: "purchaseOrderNumber",
  },
  {
    dataIndex: "costCodes",
    title: "Cost Code",
    key: "costCodes",
  },
  {
    dataIndex: "vendor",
    title: "Vendor",
    key: "vendor",
  },
  {
    dataIndex: "sumOfPurchaseOrders",
    title: "PO Subtotal",
    key: "sumOfPurchaseOrders",
    render(value) {
      return `$${convertToLocaleString(value)}`;
    },
  },
  {
    dataIndex: "sumOfInvoicesReceived",
    title: "Billed",
    key: "sumOfInvoicesReceived",
    render(value) {
      return `$${convertToLocaleString(value)}`;
    },
  },
  {
    dataIndex: "remainingToBePaid",
    title: "Remaining",
    key: "remainingToBePaid",
    render(value) {
      return `$${convertToLocaleString(value)}`;
    },
  },
  {
    dataIndex: "isAboveBudget",
    title: "Budget",
    key: "isAboveBudget",
    render(value) {
      return value ? "Above" : "Below";
    },
  },
  { dataIndex: "projectName", title: "Project", key: "projectName" },
];

type InvoicePOReportListProps = {
  setPurchaseOrder: React.Dispatch<
    React.SetStateAction<{
      id: string;
      number: string;
    }>
  >;
};

const InvoicePOReportList = ({
  setPurchaseOrder,
}: InvoicePOReportListProps) => {
  const filters = useInvoiceFilters();

  const [data, setData] = useState<InvoicePOReportRow[] | null>(null);
  const [totalCount, setTotalCount] = useState<number>(0);
  const [page, setPage] = useState<number>(1);
  const [pageSize, setPageSize] = useState<number>(10);

  const api = useCallback(async () => {
    if (filters === null) return;

    try {
      setData(() => null);
      setTotalCount(0);

      const res = await getInvoicePOReportList({
        pageNumber: page,
        pageSize: pageSize,
        ...filters,
      });

      if (res?.errors?.length === 0) {
        setTotalCount(res?.totalCount || 0);
        setData(() => res?.data || []);
      } else {
        setData(() => []);
        setTotalCount(0);
      }
    } catch (e) {
      setData(() => []);
      setTotalCount(0);
      console.error("ERROR: ", e);
    }
  }, [page, pageSize, filters]);

  useEffect(() => {
    api();
  }, [api]);

  return (
    <CustomTable
      data={data || []}
      columns={columns}
      isLoading={data === null}
      totalCount={totalCount}
      page={page}
      setPage={setPage}
      pageSize={pageSize}
      setPageSize={setPageSize}
      hasPagination
      hasSearch={false}
      isInsideReports
      hasTopBar={false}
      isNormalTable
      onRowClick={(record) =>
        setPurchaseOrder(() => ({
          id: record.purchaseOrderId,
          number: record.purchaseOrderNumber,
        }))
      }
      hasCursorPointer
    />
  );
};

export default InvoicePOReportList;
