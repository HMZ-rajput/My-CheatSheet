import { getBidMaterialsForReport } from "@/src/apis/bidMaterialApis";
import CustomTable from "@/src/components/table/CustomTable";
import { getFirstValidNumber } from "@/src/utils/number-extensions";
import routePaths from "@/src/utils/routePaths";
import { getLocaleNumberStringWithSigns } from "@/src/utils/string-extensions";
import { BidReportMaterial } from "@/src/utils/types";
import { exportToExcel } from "@/src/utils/xlsx-utils";
import { Button, TableProps } from "antd";
import { useCallback, useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import ReportArtificialSpace from "../components/ReportArtificialSpace";
import { useReports } from "../contexts/ReportsProvider";

type BidMaterialReportFields = {
  Project: string;
  "MRIF Required": string;
  "Submittal Review Period": string;
  Materials: string;
  Total: string;
};

interface BidMaterialsReportListProps {
  setStats: React.Dispatch<
    React.SetStateAction<{
      totalMaterials: number;
      totalBudget: number;
      totalMRIFRequiredForMaterialsCount: number;
      totalMRIFNotRequiredForMaterialsCount: number;
    }>
  >;
}
const BidMaterialsReportList = ({ setStats }: BidMaterialsReportListProps) => {
  const { filterValues } = useReports();
  const [totalCount, setTotalCount] = useState<number>(0);
  const [page, setPage] = useState<number>(1);
  const [pageSize, setPageSize] = useState<number>(10);
  const [materials, setMaterials] = useState<BidReportMaterial[] | null>(null);
  const navigate = useNavigate();
  const generateExcel = () => {
    if (materials !== null && materials?.length > 0) {
      const data: BidMaterialReportFields[] = materials?.map(
        (m: BidReportMaterial) => ({
          Project: m?.projectName || "",
          "MRIF Required": m?.isMRIFRequired ? "Yes" : "No",
          "Submittal Review Period": m?.submittalReviewPeriod || "",
          Materials: (m?.materials || 0)?.toLocaleString(),
          Total: (m?.total || 0)?.toLocaleString(),
        })
      );

      exportToExcel<BidMaterialReportFields[]>(
        data,
        "Bid Materials",
        "bid-materials-report"
      );
    }
  };

  const api = useCallback(async () => {
    try {
      setMaterials(() => null);
      setTotalCount(0);

      const res = await getBidMaterialsForReport({
        pageNumber: page,
        pageSize: pageSize,

        projectId: filterValues?.projectId || undefined,
        projectTypeId: filterValues?.projectTypeId || undefined,
        isMRIRequired:
          filterValues?.isMRIFRequired === undefined ||
          filterValues?.isMRIFRequired === null
            ? undefined
            : filterValues?.isMRIFRequired || false,
        totalPriceFrom: getFirstValidNumber(
          filterValues?.totalPriceStart,
          undefined
        ),
        totalPriceTo: getFirstValidNumber(
          filterValues?.totalPriceEnd,
          undefined
        ),
        assumedSubmittalReview: getFirstValidNumber(
          filterValues?.assumedSubmittalReview,
          undefined
        ),
        assumedSubmittalReviewPeriod:
          filterValues?.assumedSubmittalReviewPeriod || "",
      });

      if (res?.errors?.length === 0) {
        setTotalCount(res?.totalCount || 0);
        setMaterials(() => res?.bidMaterials || []);
      } else {
        setMaterials(() => []);
        setTotalCount(0);
      }

      if (typeof setStats === "function") {
        setStats({
          totalMaterials: res?.totalMaterials || 0,
          totalBudget: parseFloat((res?.totalBudget || 0)?.toFixed(2)),
          totalMRIFNotRequiredForMaterialsCount: res?.totalMRIFNotRequired || 0,
          totalMRIFRequiredForMaterialsCount: res?.totalMRIFRequired || 0,
        });
      }
    } catch (e) {
      setMaterials(() => []);
      setTotalCount(0);
      console.error("ERROR: ", e);
    }
  }, [filterValues, page, pageSize]);

  useEffect(() => {
    api();
  }, [api]);

  const navigateToEditPage = (report: BidReportMaterial) => {
    const coPath = `${routePaths.PROJECTS_EDIT_BY_ID}/${report?.projectId}`;
    navigate(coPath, {
      state: {
        previousPath: `${location.pathname}${location.search}`,
        bidMaterial: true,
      },
    });
  };

  const columns: TableProps<BidReportMaterial>["columns"] = [
    { dataIndex: "projectName", title: "Project", key: "projectName" },
    {
      dataIndex: "isMRIFRequired",
      title: "MRIF Required",
      key: "isMRIFRequired",
      render: (value: boolean) => (value ? "Yes" : "No"),
    },
    {
      dataIndex: "submittalReviewPeriod",
      title: "Submittal Review Period",
      key: "submittalReviewPeriod",
    },
    {
      dataIndex: "materials",
      title: "Materials",
      key: "materials",
      render: (value: number) => getLocaleNumberStringWithSigns(value),
    },
    {
      dataIndex: "total",
      title: "Total",
      key: "total",
      render: (value: number) => getLocaleNumberStringWithSigns(value, "$"),
    },
  ];
  return (
    <>
      <CustomTable
        columns={columns}
        data={materials || []}
        isLoading={materials === null}
        totalCount={totalCount}
        page={page}
        setPage={setPage}
        pageSize={pageSize}
        setPageSize={setPageSize}
        hasPagination
        hasSearch={false}
        isInsideReports
        filterElementContainFullWidth
        reportFilterForParamsUseOnly={filterValues}
        hasCursorPointer
        onRowClick={(co) => navigateToEditPage(co)}
        exportButtonEl={
          <div className="ml-auto">
            <Button
              disabled={!Boolean(materials?.length)}
              onClick={generateExcel}
            >
              Export
            </Button>

            <ReportArtificialSpace />
          </div>
        }
      />
    </>
  );
};

export default BidMaterialsReportList;
