import { getAllProjectTypes } from "@/src/apis/projectTypeApis";
import PageLayout from "@/src/components/layout/PageLayout";
import { useAppDispatch } from "@/src/hooks/useAppDispatch";
import { useAppSelector } from "@/src/hooks/useAppSelector";
import { getProjectsState } from "@/src/store/slices/projectsSlice";
import { getTypesState } from "@/src/store/slices/typesSlice";
import routePaths from "@/src/utils/routePaths";
import { useEffect, useMemo, useState } from "react";
import Chart from "react-apexcharts";
import ReportArtificialSpace from "../components/ReportArtificialSpace";
import ReportFilters from "../components/ReportFilters";
import ReportStatisticsCard from "../components/ReportStatisticsCard";
import { FilterType, ReportChartState } from "../types";
import { FilterInputTypes } from "../utils";
import BidMaterialsReportList from "./BidMaterialsReportList";

const BidMaterialsReportPage = () => {
  const dispatch = useAppDispatch();
  const [stats, setStats] = useState({
    totalMaterials: 0,
    totalBudget: 0,
    totalMRIFRequiredForMaterialsCount: 0,
    totalMRIFNotRequiredForMaterialsCount: 0,
  });
  const chartState: ReportChartState = {
    options: {
      chart: {
        type: "donut",
      },
      legend: {
        position: "top",
      },
      colors: ["#70C1B3", "#EA6F85"],
      labels: ["Yes", "No"],
    },
    series: [
      stats.totalMRIFRequiredForMaterialsCount,
      stats.totalMRIFNotRequiredForMaterialsCount,
    ],
  };
  const { projectsSummarizedData } = useAppSelector(getProjectsState);
  const { typesData: projectTypesData } = useAppSelector(getTypesState);

  const filters: Record<string, FilterType> = useMemo(
    () => ({
      projectId: {
        label: "Project",
        type: FilterInputTypes.SELECT,
        options: projectsSummarizedData?.map((m) => ({
          value: m?.id || "",
          label: m?.name || "",
          projectTypeId: m?.projectTypeId || "",
        })),
        filterByKey: "projectTypeId",
        shouldDisableIfFilterBy: false,
        placeholder: "Select Project",
        size: 4,
        clearable: true,
      },
      projectTypeId: {
        label: "Project Type",
        type: FilterInputTypes.SELECT,
        options: projectTypesData?.map((m) => ({
          value: m?.id || "",
          label: m?.name || "",
        })),
        placeholder: "Select Project Type",
        size: 4,
        clearable: true,
      },
      contractPrice: {
        label: "Price",
        type: FilterInputTypes.NUMBER_RANGE,
        placeholder: "$ 0.00",
        prefix: "$",
        size: 4,
        isPriceRange: true,
      },
      isMRIFRequired: {
        label: "MRIF Required",
        type: FilterInputTypes.SELECT,
        options: [
          {
            value: true,
            label: "Yes",
          },
          {
            value: false,
            label: "No",
          },
        ],
        placeholder: "Select MRIF Required",
        size: 4,
        clearable: true,
      },
      assumedSubmittalReview: {
        label: "Assumed Submittal Review Period ",
        type: FilterInputTypes.NUMBER_INPUT_SELECT_COMBO,
        placeholder: "Enter Assumed Submittal Period",
        options: [
          {
            value: "days",
            label: "Day(s)",
          },
          {
            value: "weeks",
            label: "Week(s)",
          },
          {
            value: "months",
            label: "Month(s)",
          },
          {
            value: "years",
            label: "Year(s)",
          },
        ],
        size: 4,
      },
    }),
    [projectsSummarizedData, projectTypesData]
  );

  useEffect(() => {
    dispatch(getAllProjectTypes());
  }, [dispatch]);

  return (
    <PageLayout
      backlink={{ title: "Reports", route: routePaths.REPORTS }}
      title="Bid Materials Report"
    >
      <ReportFilters filters={filters} />

      <ReportArtificialSpace />

      <div className="flex gap-3">
        <div className="flex flex-col basis-1/2 gap-3">
          <div className="flex gap-3">
            <ReportStatisticsCard
              className="basis-1/2"
              title="Total Bid Materials"
              stat={`${stats.totalMaterials?.toLocaleString()}`}
            />

            <ReportStatisticsCard
              className="basis-1/2"
              title="Total Budget"
              stat={`$${stats.totalBudget?.toLocaleString()}`}
            />
          </div>
        </div>

        <ReportStatisticsCard title="MRIF Required">
          <div className="flex flex-col">
            <Chart
              series={chartState.series}
              options={chartState.options}
              type="donut"
              height="200"
            />
          </div>
        </ReportStatisticsCard>
      </div>

      <ReportArtificialSpace />

      <BidMaterialsReportList setStats={setStats} />
    </PageLayout>
  );
};

export default BidMaterialsReportPage;
