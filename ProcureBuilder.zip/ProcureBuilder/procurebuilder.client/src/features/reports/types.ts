import React from "react";
import { FilterInputTypes } from "./utils";
import { ApexOptions } from "apexcharts";

export type ReportChartState = {
  options: ApexOptions;
  series: ApexNonAxisChartSeries | ApexAxisChartSeries;
  chart?: ApexChart;
  plotOptions?: ApexPlotOptions;
  dataLabels?: ApexDataLabels;
  stroke?: ApexStroke;
  xaxis?: ApexXAxis;
  yaxis?: ApexYAxis;
  fill?: ApexFill;
  tooltip?: ApexTooltip;
};

export type SectionCard = {
  desc: string;
  route: string;
};

export type SectionCards = Record<string, SectionCard>;
export type FilterTypeValue = string | boolean | number;
export interface FilterTypeOption {
  value: FilterTypeValue;
  label: string;
  [key: string]: string | boolean | number;
}

export interface FilterType {
  label: string;
  type: FilterInputTypes;
  placeholder: string;
  size: number;
  prefix?: string | React.ReactNode;
  suffix?: string | React.ReactNode;
  isPriceRange?: boolean;
  defaultValue?: FilterTypeValue;

  filterByKey?: string;
  shouldDisableIfFilterBy?: boolean;
  allowNegativeNumbers?: boolean;

  options?: FilterTypeOption[];
  clearable?: boolean;
}
