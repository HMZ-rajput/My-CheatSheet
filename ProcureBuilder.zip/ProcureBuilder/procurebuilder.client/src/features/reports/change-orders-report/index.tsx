import CustomIcon from "@/src/components/common/CustomIcon";
import PageLayout from "@/src/components/layout/PageLayout";
import { useAppSelector } from "@/src/hooks/useAppSelector";
import { getChangeOrderState } from "@/src/store/slices/changeOrderSlice";
import { getProjectsState } from "@/src/store/slices/projectsSlice";
import { changeOrderStatusOptions } from "@/src/utils/constants";
import routePaths from "@/src/utils/routePaths";
import { ChangeOrder } from "@/src/utils/types";
import { exportToExcel } from "@/src/utils/xlsx-utils";
import { Button } from "antd";
import dayjs from "dayjs";
import { useMemo, useState } from "react";
import Chart from "react-apexcharts";
import ChangeOrderList from "../../change-orders/components/ChangeOrderList";
import ReportArtificialSpace from "../components/ReportArtificialSpace";
import ReportFilters from "../components/ReportFilters";
import ReportStatisticsCard from "../components/ReportStatisticsCard";
import { FilterType, ReportChartState } from "../types";
import { FilterInputTypes } from "../utils";

type ChangeOrderReportFields = {
  "Change Order Number": string;
  Title: string | undefined;
  Project: string;
  "Approval Deadline": string | null | undefined;
  Status: string;
  Subtotal: number | undefined;
};

const ChangeOrdersReportPage = () => {
  const { projectsSummarizedData } = useAppSelector(getProjectsState);
  const { changeOrderData, isLoading } = useAppSelector(getChangeOrderState);
  const [stats, setStats] = useState({
    totalChangeOrders: 0,
    totalSubtotal: 0,
    totalApprovedChangeOrders: 0,
    totalRejectedChangeOrders: 0,
    totalPendingChangeOrders: 0,
    totalAddedToBidMaterialChangeOrders: 0,
  });
  const chartState: ReportChartState = {
    options: {
      chart: {
        type: "donut",
      },
      legend: {
        position: "top",
      },
      colors: ["#E89964", "#70C1B3", "#EA6F85", "#1976d2"],
      labels: changeOrderStatusOptions.map((m) => m.label),
    },
    series: [
      stats.totalPendingChangeOrders,
      stats.totalApprovedChangeOrders,
      stats.totalRejectedChangeOrders,
      stats.totalAddedToBidMaterialChangeOrders,
    ],
  };

  const filters: Record<string, FilterType> = useMemo(
    () => ({
      projectId: {
        label: "Project",
        type: FilterInputTypes.SELECT,
        options:
          projectsSummarizedData?.map((m) => ({
            value: m?.id || "",
            label: m?.name || "",
          })) || [],
        placeholder: "Select Project",
        size: 3,
        clearable: true,
      },
      status: {
        label: "Status",
        type: FilterInputTypes.SELECT,
        options: changeOrderStatusOptions,
        placeholder: "Select Status",
        size: 3,
        clearable: true,
      },
      approvalDeadline: {
        label: "Approval Deadline Range",
        type: FilterInputTypes.DATE_RANGE,
        placeholder: "MM / DD / YYYY",
        suffix: <CustomIcon type="calendar-green-icon" />,
        size: 3,
      },
      subtotal: {
        label: "Subtotal Range",
        type: FilterInputTypes.NUMBER_RANGE,
        placeholder: "$ 0.00",
        prefix: "$",
        size: 3,
        isPriceRange: true,
      },
    }),
    [projectsSummarizedData]
  );

  const generateExcel = () => {
    if (changeOrderData !== null && changeOrderData?.length > 0) {
      const data: ChangeOrderReportFields[] = changeOrderData?.map(
        (m: ChangeOrder) => ({
          Title: m?.title || "",
          Project: m?.project?.name || "",
          "Change Order Number": m?.changeOrderNumber || "",
          Status:
            changeOrderStatusOptions?.find((f) => f.value === m?.status)
              ?.label || "",
          "Approval Deadline": dayjs(m?.approvalDeadline)
            .format("MM/DD/YYYY")
            .toString(),
          Subtotal: m?.subTotal || 0,
        })
      );

      exportToExcel<ChangeOrderReportFields[]>(
        data,
        "Change Orders",
        "change-orders-report"
      );
    }
  };

  return (
    <PageLayout
      backlink={{ title: "Reports", route: routePaths.REPORTS }}
      title="Change Orders Report"
    >
      <ReportFilters filters={filters} />

      <ReportArtificialSpace />

      <div className="flex gap-3">
        <div className="flex flex-col basis-2/6 gap-3">
          <ReportStatisticsCard
            className="grow-0"
            title="Total Change Orders"
            stat={stats.totalChangeOrders}
          />

          <ReportStatisticsCard
            className="grow-0"
            title="Combined Subtotal"
            stat={`$${stats.totalSubtotal?.toLocaleString()}`}
          />
        </div>

        <ReportStatisticsCard title="Committed Materials">
          <div className="flex flex-col">
            <Chart
              series={chartState.series}
              options={chartState.options}
              type="donut"
              height="300"
            />
          </div>
        </ReportStatisticsCard>
      </div>

      <ReportArtificialSpace />

      <ChangeOrderList
        setReportStats={(
          totalChangeOrders,
          totalSubtotal,
          totalApprovedChangeOrders,
          totalRejectedChangeOrders,
          totalPendingChangeOrders,
          totalAddedToBidMaterialChangeOrders
        ) => {
          setStats({
            totalChangeOrders: totalChangeOrders || 0,
            totalSubtotal: totalSubtotal || 0,
            totalApprovedChangeOrders: totalApprovedChangeOrders || 0,
            totalRejectedChangeOrders: totalRejectedChangeOrders || 0,
            totalPendingChangeOrders: totalPendingChangeOrders || 0,
            totalAddedToBidMaterialChangeOrders:
              totalAddedToBidMaterialChangeOrders || 0,
          });
        }}
        exportButtonEl={
          <Button
            disabled={isLoading || !Boolean(changeOrderData?.length)}
            onClick={generateExcel}
          >
            Export
          </Button>
        }
      />
    </PageLayout>
  );
};

export default ChangeOrdersReportPage;
