import useSyncFilters from "@/src/hooks/useSyncFilters";
import dayjs from "dayjs";
import { FieldValues } from "react-hook-form";
import { FilterType } from "../types";
import { FilterInputTypes } from "../utils";

const useSyncReportFilters = () => {
  const { searchParams, updateSearchParams } = useSyncFilters();

  const syncFiltersWithParams = (filterValues: FieldValues | null) => {
    const entries = Object.entries(filterValues || {});
    const params = new URLSearchParams(window.location.search);

    if (entries?.length > 0) {
      entries.forEach(([key, value]) => {
        if (params.get(key) && !value && value !== 0) {
          params.delete(key);
          return;
        }
        if (!params.get(key) && !value && value !== 0) return;
        params.set(key, String(value));
      });
    } else {
      const paramsArray = [...(params || [])];
      paramsArray
        ?.filter(([key]) => !["pageSize", "page", "searchTerm"].includes(key))
        ?.forEach(([key]) => {
          params.delete(key);
        });
    }

    updateSearchParams(params);
  };
  const syncParamsWithFilters = (
    filters: Record<string, FilterType>
  ): FieldValues => {
    const parsedFilters: FieldValues = {};

    searchParams.forEach((value, key) => {
      try {
        const allowedBaseKeys = ["projectedStart"];
        const baseKey = allowedBaseKeys?.includes(key)
          ? key
          : key.replace(/(Start|End)$/, "");
        const filterInputType = filters[baseKey]?.type;

        switch (filterInputType) {
          case FilterInputTypes.DATE_RANGE: {
            const parts = value.split(",");
            if (parts.length === 4) {
              parsedFilters[key] = [
                dayjs(`${parts[0]}, ${parts[1]}`),
                dayjs(`${parts[2]}, ${parts[3]}`),
              ];
            }
            break;
          }

          case FilterInputTypes.NUMBER_INPUT_SELECT_COMBO:
          case FilterInputTypes.NUMBER_RANGE: {
            parsedFilters[key] = Number(value);
            break;
          }

          case FilterInputTypes.SELECT: {
            const numberVal = Number(value);
            const booleanVal =
              value === "true" ? true : value === "false" ? false : undefined;
            parsedFilters[key] = booleanVal
              ? booleanVal
              : isNaN(numberVal)
              ? value
              : numberVal;
            break;
          }

          default:
            parsedFilters[key] = value;
        }
      } catch (error) {
        console.error(`Failed to parse query param '${key}':`, error);
      }
    });

    return parsedFilters;
  };

  return { syncFiltersWithParams, syncParamsWithFilters };
};

export default useSyncReportFilters;
