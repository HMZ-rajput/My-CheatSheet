import { Typography } from "antd";
import { useNavigate } from "react-router-dom";
import { SectionCard } from "../types";

type ReportCardProps = {
  name: string;
} & SectionCard;

const ReportCard = ({ name, desc, route }: ReportCardProps) => {
  const navigate = useNavigate();

  return (
    <div
      className="shrink-0 grow-0 basis-[calc(25%-1.125rem)] rounded-xl shadow-[0_0_10px_rgba(0,0,0,0.1)] cursor-pointer transition-all duration-300 hover:shadow-primaryActive"
      onClick={() => {
        navigate(route);
      }}
    >
      <div className="px-4 py-3 border-b border-b-neutral-5">
        <Typography.Title
          level={4}
          style={{ fontSize: 16, fontWeight: 500, margin: 0 }}
        >
          {name}
        </Typography.Title>
      </div>

      <div className="flex flex-col py-3 px-4 gap-6 items-end">
        <p className="text-gray-2 text-xs">{desc}</p>

        <p
          className="text-primary cursor-pointer hover:text-primaryHover text-xs font-medium"
          onClick={() => navigate(route)}
        >
          View Report &gt;&gt;
        </p>
      </div>
    </div>
  );
};

export default ReportCard;
