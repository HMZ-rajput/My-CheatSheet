import React from "react";

type ReportStatisticsCardProps = {
  title: string;
  className?: string;
  stat?: number | string;
  children?: React.ReactNode;
  hasMarginTopAuto?: boolean;
};

const ReportStatisticsCard = ({
  title,
  className,
  stat,
  children,
  hasMarginTopAuto = true,
}: ReportStatisticsCardProps) => {
  return (
    <div
      className={`grow border border-neutral-5 p-3 rounded-xl flex flex-col gap-3 ${
        className || ""
      }`}
    >
      <h6 className="font-semibold text-neutral-85">{title}</h6>

      <div className={hasMarginTopAuto ? "mt-auto" : ""}>
        {children ? (
          children
        ) : stat !== null && stat !== undefined ? (
          <p className="font-semibold text-xl">{stat}</p>
        ) : null}
      </div>
    </div>
  );
};

export default ReportStatisticsCard;
