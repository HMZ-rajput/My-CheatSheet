const ReportArtificialSpace = () => {
  return <div className="py-2"></div>;
};

export default ReportArtificialSpace;
