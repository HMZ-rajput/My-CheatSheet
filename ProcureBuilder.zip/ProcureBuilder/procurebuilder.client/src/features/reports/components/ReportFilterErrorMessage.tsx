type ReportFilterErrorMessageProps = {
  message: string | undefined;
};

const ReportFilterErrorMessage = ({
  message,
}: ReportFilterErrorMessageProps) => {
  return Boolean(message) ? (
    <span className="text-xs text-error mt-0.5 font-medium">{message}</span>
  ) : null;
};

export default ReportFilterErrorMessage;
