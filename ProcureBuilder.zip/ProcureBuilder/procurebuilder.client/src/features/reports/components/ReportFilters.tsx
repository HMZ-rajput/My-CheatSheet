import { Button } from "antd";
import { useEffect, useMemo, useRef } from "react";
import { FieldValues, useForm } from "react-hook-form";
import { useReports } from "../contexts/ReportsProvider";
import useSyncReportFilters from "../hooks/useSyncReportFilters";
import { FilterType } from "../types";
import ReportFiltersColumn from "./ReportFiltersColumn";

type ReportFiltersProps = {
  filters: Record<string, FilterType>;
};

let prevValuesJsonString = "";

const ReportFilters = ({ filters }: ReportFiltersProps) => {
  const { syncParamsWithFilters } = useSyncReportFilters();
  const { updateFilterValues } = useReports();
  const searchBtnElRef = useRef<HTMLButtonElement | null>(null);
  const filterEntries = Object.entries(filters)?.filter(
    ([_, data]) => data?.label && data?.type
  );
  const defaultValues = useMemo(() => {
    const values = Object.fromEntries(
      (filterEntries || [])
        .filter(([_, data]) => data?.defaultValue)
        .map(([key, data]) => [key, data.defaultValue])
    );
    return Object.keys(values).length > 0 ? values : undefined;
  }, [filterEntries]);
  const { reset, handleSubmit, control, getValues, setValue } = useForm();

  const updateParentValues = (newValues: FieldValues) => {
    const newValuesJsonString = JSON.stringify(newValues);

    if (newValuesJsonString !== prevValuesJsonString) {
      prevValuesJsonString = newValuesJsonString;
      updateFilterValues?.(newValues);
    }
  };

  const hasValues = () => {
    try {
      const values = Object.entries(getValues())
        .filter(([key]) => key !== "assumedSubmittalReviewPeriod")
        .filter(
          ([_, value]) => value !== "" && value !== null && value !== undefined
        );
      const filteredValues = values?.filter(
        ([key]) => defaultValues && defaultValues[key]
      );

      return values?.length > filteredValues?.length;
    } catch (e) {
      console.error(e);
    }
  };

  useEffect(() => {
    const conditionControllingKeys = [
      ...new Set(
        Object.values(filters)
          .map((filter) => filter?.filterByKey)
          .filter((f) => f)
      ),
    ];
    const values = syncParamsWithFilters(filters);

    const conditionControllingKeyValues: {
      [key: string]: any;
    } = {};
    const conditionDependantKeyValues: {
      [key: string]: any;
    } = {};

    Object.entries({ ...values }).forEach(([key, value]) => {
      if (conditionControllingKeys.includes(key)) {
        conditionControllingKeyValues[key] = value;
      } else {
        conditionDependantKeyValues[key] = value;
      }
    });

    updateParentValues(values);

    if (Object.keys(conditionControllingKeyValues).length > 0) {
      Object.entries(conditionControllingKeyValues).forEach(([key, value]) =>
        setValue(key, value)
      );
    }

    if (
      Object.keys(conditionControllingKeyValues).length > 0 &&
      Object.keys(conditionDependantKeyValues).length > 0
    ) {
      setTimeout(() => {
        Object.entries(conditionDependantKeyValues).forEach(([key, value]) =>
          setValue(key, value)
        );
      }, 1000);
    } else if (Object.keys(conditionDependantKeyValues).length > 0) {
      Object.entries(conditionDependantKeyValues).forEach(([key, value]) =>
        setValue(key, value)
      );
    }

    return () => {
      // updateFilterValues(null);
      prevValuesJsonString = "";
    };
  }, []);

  return (
    <div className="flex-col p-4 rounded-2xl border border-neutral-5 gap-6">
      <h6 className="font-semibold text-base">Filters</h6>

      <form
        onSubmit={handleSubmit(updateParentValues)}
        className="flex mt-3 flex-wrap gap-4"
      >
        {filterEntries?.map(([key, data]) => (
          <ReportFiltersColumn
            key={key}
            data={{ ...data, key }}
            control={control}
            getValues={getValues}
            setValue={setValue}
            defaultValue={data?.defaultValue || undefined}
          />
        ))}

        <div className="ml-auto mt-auto grow flex justify-end gap-2">
          {Boolean(hasValues()) && (
            <Button
              htmlType="button"
              onClick={() => {
                const values = getValues();
                const updatedValues = Object.fromEntries(
                  Object.entries(values).filter(
                    ([key]) => defaultValues && Boolean(defaultValues[key])
                  )
                );

                if (Object.keys(updatedValues)?.length > 0) {
                  reset(updatedValues);
                } else {
                  reset({});
                }

                if (searchBtnElRef.current) {
                  searchBtnElRef.current.click();
                }
              }}
            >
              Clear All
            </Button>
          )}
          <Button htmlType="submit" type="primary" ref={searchBtnElRef}>
            Search
          </Button>
        </div>
      </form>
    </div>
  );
};

export default ReportFilters;
