import { Select } from "antd";
import { useEffect, useMemo, useRef } from "react";
import {
  Control,
  Controller,
  FieldValues,
  Path,
  PathValue,
  UseFormGetValues,
  UseFormSetValue,
  useWatch,
} from "react-hook-form";
import { useReports } from "../contexts/ReportsProvider";
import { FilterType, FilterTypeValue } from "../types";

type ReportFiltersSelectProps<TFieldValues extends FieldValues> = {
  data: FilterType & {
    /** the field this Select writes to */
    key: Path<TFieldValues>;
    /** optional dependency field to filter by */
    filterByKey?: Path<TFieldValues>;
  };
  control: Control<TFieldValues>;
  setValue: UseFormSetValue<TFieldValues>;
  defaultValue: FilterTypeValue | undefined;
  getValues: UseFormGetValues<FieldValues>;
};

export default function ReportFiltersSelect<TFieldValues extends FieldValues>({
  data,
  control,
  setValue,
  getValues,
  defaultValue,
}: ReportFiltersSelectProps<TFieldValues>) {
  const { updateFilterValues } = useReports();
  const isFirstRender = useRef(true);
  const {
    key,
    filterByKey,
    options,
    placeholder,
    clearable,
    shouldDisableIfFilterBy,
  } = data;

  // Always call useWatch with a valid Path<TFieldValues>;
  // if filterByKey is undefined we pass an empty string cast and then ignore the result.
  const filterBy = useWatch<TFieldValues, Path<TFieldValues>>({
    control,
    name: (filterByKey ?? "") as Path<TFieldValues>,
    defaultValue: undefined as any,
  }) as PathValue<TFieldValues, Path<TFieldValues>> | undefined;

  // Compute the filtered dropdown options
  const filteredOptions = useMemo(() => {
    if (filterByKey && filterBy !== undefined && options) {
      return options.filter((opt) => opt[filterByKey] === filterBy);
    }
    return options ?? [];
  }, [options, filterByKey, filterBy]);

  // Disable whenever we’re meant to depend on filterBy but it’s empty
  const isDisabled =
    shouldDisableIfFilterBy !== false && Boolean(filterByKey && !filterBy);

  // When disabled, clear out any stale value
  useEffect(() => {
    if (isDisabled) {
      setValue(key, undefined as any);
    }
  }, [isDisabled, key, setValue]);

  // ALSO clear on every change of filterBy
  useEffect(() => {
    if (filterByKey) {
      setValue(key, undefined as any);
    }
  }, [filterBy, filterByKey, key, setValue]);

  return (
    <Controller<TFieldValues>
      name={key}
      control={control}
      render={({ field }) => {
        if (defaultValue && !field.value) {
          field.onChange(defaultValue);
          updateFilterValues({ ...(getValues() || {}), [key]: defaultValue });
          isFirstRender.current = false;
        }

        return (
          <Select
            {...field}
            placeholder={placeholder}
            options={filteredOptions}
            allowClear={clearable}
            showSearch
            optionFilterProp="label"
            disabled={isDisabled}
          />
        );
      }}
    />
  );
}
