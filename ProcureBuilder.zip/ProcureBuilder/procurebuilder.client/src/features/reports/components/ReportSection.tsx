import { Flex, Typography } from "antd";
import { SectionCards } from "../types";
import ReportCard from "./ReportListCard";

type ReportSectionProps = {
  name: string;
  cardsList: SectionCards;
};

const ReportSection = ({ name, cardsList }: ReportSectionProps) => {
  return (
    <Flex className="flex-col p-6 rounded-2xl border border-neutral-5 gap-6">
      <Typography.Title level={4} style={{ fontSize: 18, margin: 0 }}>
        {name}
      </Typography.Title>

      <Flex className="flex-wrap gap-6">
        {Object.entries(cardsList)?.map(([name, data]) => (
          <ReportCard name={name} {...data} />
        ))}
      </Flex>
    </Flex>
  );
};

export default ReportSection;
