import CustomFormLabel from "@/src/components/common/CustomFormLabel";
import { useMemo } from "react";
import {
  Control,
  FieldValues,
  UseFormGetValues,
  UseFormSetValue,
} from "react-hook-form";
import { FilterType, FilterTypeValue } from "../types";
import { FilterInputTypes } from "../utils";
import ReportFiltersDateRange from "./ReportFiltersDateRange";
import ReportFiltersInputSelectCombo from "./ReportFiltersInputSelectCombo";
import ReportFiltersNumberRange from "./ReportFiltersNumberRange";
import ReportFiltersSelect from "./ReportFiltersSelect";
import ReportFiltersInput from "./ReportFiltersInput";

type ReportFiltersColumnProps = {
  data: FilterType & { key: string };
  control: Control<FieldValues, any>;
  getValues: UseFormGetValues<FieldValues>;
  setValue: UseFormSetValue<FieldValues>;
  defaultValue: FilterTypeValue | undefined;
};

const ReportFiltersColumn = ({
  data,
  control,
  defaultValue,
  getValues,
  setValue,
}: ReportFiltersColumnProps) => {
  const flexBasis = useMemo(() => {
    const isValidSize =
      data.size &&
      typeof data.size === "number" &&
      data.size <= 12 &&
      data.size >= 1;

    if (!isValidSize) {
      return "calc(25% - 16px)";
    } else {
      return `calc(${(data.size / 12) * 100}% - 16px)`;
    }
  }, [data.size]);

  return (
    <div
      className="flex flex-col shrink-0"
      style={{
        flexBasis,
      }}
    >
      <span className="mb-0.5">
        <CustomFormLabel text={data.label} fontWeight="medium" />
      </span>

      {data.type === FilterInputTypes.INPUT ? (
        <ReportFiltersInput data={data} control={control} />
      ) : data.type === FilterInputTypes.SELECT ? (
        <ReportFiltersSelect
          data={data}
          control={control}
          key={data.key}
          setValue={setValue}
          getValues={getValues}
          defaultValue={defaultValue}
        />
      ) : data.type === FilterInputTypes.NUMBER_INPUT_SELECT_COMBO ? (
        <ReportFiltersInputSelectCombo
          data={data}
          control={control}
          getValues={getValues}
          setValue={setValue}
          key={data.key}
        />
      ) : data.type === FilterInputTypes.NUMBER_RANGE ? (
        <ReportFiltersNumberRange
          data={data}
          control={control}
          getValues={getValues}
          key={data.key}
        />
      ) : data.type === FilterInputTypes.DATE_RANGE ? (
        <ReportFiltersDateRange data={data} control={control} key={data.key} />
      ) : null}
    </div>
  );
};

export default ReportFiltersColumn;
