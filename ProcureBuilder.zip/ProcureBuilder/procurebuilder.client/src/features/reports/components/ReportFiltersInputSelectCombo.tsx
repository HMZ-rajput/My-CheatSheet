import { InputNumber, Select } from "antd";
import {
  Control,
  Controller,
  FieldValues,
  UseFormGetValues,
  UseFormSetValue,
} from "react-hook-form";
import { FilterType } from "../types";

type ReportFiltersInputSelectComboProps = {
  data: FilterType & { key: string };
  control: Control<FieldValues, any>;
  getValues: UseFormGetValues<FieldValues>;
  setValue: UseFormSetValue<FieldValues>;
};

const ReportFiltersInputSelectCombo = ({
  data,
  control,
  getValues,
  setValue,
}: ReportFiltersInputSelectComboProps) => {
  if (!data.key) {
    return;
  }

  const periodKey = `${data.key}Period`;
  if (!getValues(periodKey)) {
    setValue(periodKey, data?.options?.[0]?.value);
  }

  return (
    <Controller
      name={data.key}
      control={control}
      render={({ field }) => {
        return (
          // Currently it's number only, add anything after today -- KhanInshalQx, 11:00 PM, April 16th, 2025.
          <InputNumber
            {...field}
            className="w-full"
            onChange={field.onChange}
            value={field.value}
            placeholder={data.placeholder}
            min={1}
            addonAfter={
              <Controller
                control={control}
                name={periodKey}
                render={({ field }) => (
                  <Select
                    {...field}
                    className="min-w-24"
                    options={data.options}
                  />
                )}
              />
            }
          />
        );
      }}
    />
  );
};

export default ReportFiltersInputSelectCombo;
