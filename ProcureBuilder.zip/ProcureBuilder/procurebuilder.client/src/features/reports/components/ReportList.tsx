import { Flex } from "antd";
import { reportSections } from "../utils";
import ReportSection from "./ReportSection";

const ReportList = () => {
  return (
    <Flex className="flex-col gap-4">
      {Object.entries(reportSections)?.map(([name, cardsList]) => (
        <ReportSection name={name} cardsList={cardsList} />
      ))}
    </Flex>
  );
};

export default ReportList;
