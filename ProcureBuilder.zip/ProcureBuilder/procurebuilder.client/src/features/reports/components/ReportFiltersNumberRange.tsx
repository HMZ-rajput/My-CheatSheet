import { convertToLocaleString } from "@/src/utils/helper";
import { formatDecimalsOnlyTwo } from "@/src/utils/number-extensions";
import { InputNumber } from "antd";
import {
  Control,
  Controller,
  FieldValues,
  UseFormGetValues,
} from "react-hook-form";
import { FilterType } from "../types";
import ReportFilterErrorMessage from "./ReportFilterErrorMessage";

const parseValue = (value: string | undefined) =>
  value?.replace(/\$\s?|(,*)/g, "");
const formatValue = (value: string, isPriceRange: boolean) => {
  return value
    ? isPriceRange
      ? `$ ${convertToLocaleString(value)}`
      : value
    : "";
};

type ReportFiltersNumberRangeProps = {
  data: FilterType & { key: string };
  control: Control<FieldValues, any>;
  getValues: UseFormGetValues<FieldValues>;
};

const ReportFiltersNumberRange = ({
  data,
  control,
  getValues,
}: ReportFiltersNumberRangeProps) => {
  if (!data.key) {
    return;
  }

  const rangeStartKey = `${data.key}Start`;
  const rangeEndKey = `${data.key}End`;

  return (
    <>
      <div className="flex items-start gap-1.5">
        <Controller
          name={rangeStartKey}
          control={control}
          rules={{
            validate: (value) => {
              const endValue = getValues(rangeEndKey);
              if (!value || !endValue) return true;

              return (
                Number(value) < Number(endValue) ||
                "Must be less than end value"
              );
            },
          }}
          render={({ field, formState: { errors } }) => {
            const errorMessage = errors?.[rangeStartKey]?.message;
            return (
              <div className="flex flex-col grow">
                <InputNumber
                  {...field}
                  className="w-full"
                  placeholder={data.placeholder}
                  min={data.allowNegativeNumbers ? -Infinity : 0}
                  value={formatDecimalsOnlyTwo(field.value) || ""}
                  formatter={(value) =>
                    formatValue(value || "", data?.isPriceRange || false)
                  }
                  parser={parseValue}
                />
                {Boolean(errorMessage) ? (
                  <ReportFilterErrorMessage
                    message={errorMessage?.toString()}
                  />
                ) : null}
              </div>
            );
          }}
        />

        <span className="mt-1">—</span>

        <Controller
          name={rangeEndKey}
          control={control}
          rules={{
            validate: (value) => {
              const startValue = getValues(rangeStartKey);
              if (!value || !startValue) return true;

              return (
                Number(startValue) < Number(value) ||
                "Must be greater than the start value"
              );
            },
          }}
          render={({ field, formState: { errors } }) => {
            const errorMessage = errors?.[rangeEndKey]?.message;
            return (
              <div className="flex flex-col grow">
                <InputNumber
                  {...field}
                  className="w-full"
                  placeholder={data.placeholder}
                  min={data.allowNegativeNumbers ? -Infinity : 0}
                  value={formatDecimalsOnlyTwo(field.value) || ""}
                  formatter={(value) =>
                    formatValue(value || "", data?.isPriceRange || false)
                  }
                  parser={parseValue}
                />
                {Boolean(errorMessage) ? (
                  <ReportFilterErrorMessage
                    message={errorMessage?.toString()}
                  />
                ) : null}
              </div>
            );
          }}
        />
      </div>
    </>
  );
};

export default ReportFiltersNumberRange;
