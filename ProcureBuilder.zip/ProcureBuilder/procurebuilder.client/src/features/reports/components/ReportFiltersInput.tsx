import { Input } from "antd";
import { Control, Controller, FieldValues, Path } from "react-hook-form";
import { FilterType } from "../types";

type ReportFiltersInputProps<TFieldValues extends FieldValues> = {
  data: FilterType & {
    key: Path<TFieldValues>;
  };
  control: Control<TFieldValues>;
};

export default function ReportFiltersInput<TFieldValues extends FieldValues>({
  data,
  control,
}: ReportFiltersInputProps<TFieldValues>) {
  return (
    <Controller<TFieldValues>
      name={data.key}
      control={control}
      render={({ field }) => (
        <Input {...field} placeholder={data.placeholder} />
      )}
    />
  );
}
