import { DatePicker } from "antd";
import { Control, Controller, FieldValues } from "react-hook-form";
import { FilterType } from "../types";
import { dateFormat } from "@/src/utils/constants";

type ReportFiltersDateRangeProps = {
  data: FilterType & { key: string };
  control: Control<FieldValues, any>;
};

const ReportFiltersDateRange = ({
  data,
  control,
}: ReportFiltersDateRangeProps) => {
  if (!data.key) {
    return;
  }

  return (
    <>
      <div className="flex items-center gap-1.5">
        <Controller
          name={data.key}
          control={control}
          render={({ field }) => {
            return (
              <DatePicker.RangePicker
                format={dateFormat}
                allowEmpty={[true, true]}
                className="grow"
                value={field.value}
                onChange={field.onChange}
              />
            );
          }}
        />
      </div>
    </>
  );
};

export default ReportFiltersDateRange;
