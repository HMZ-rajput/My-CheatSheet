import { getLocationslist } from "@/src/apis/locationApis";
import { getSummarizedProjectsList } from "@/src/apis/projectApis";
import PageLayout from "@/src/components/layout/PageLayout";
import { useAppDispatch } from "@/src/hooks/useAppDispatch";
import { useAppSelector } from "@/src/hooks/useAppSelector";
import { getLocationsState } from "@/src/store/slices/locationSlice";
import { getProductState } from "@/src/store/slices/productsSlice";
import { getProjectsState } from "@/src/store/slices/projectsSlice";
import routePaths from "@/src/utils/routePaths";
import { Product } from "@/src/utils/types";
import { exportToExcel } from "@/src/utils/xlsx-utils";
import { Button } from "antd";
import { useEffect, useMemo, useState } from "react";
import ProductList from "../../products/components/ProductList";
import ReportArtificialSpace from "../components/ReportArtificialSpace";
import ReportFilters from "../components/ReportFilters";
import ReportStatisticsCard from "../components/ReportStatisticsCard";
import { FilterType } from "../types";
import { FilterInputTypes } from "../utils";

type InventoryReportFields = {
  Product: string;
  "Cost Code": string;
  Quantity: number;
  "Unit of Measurement": string;
};

const InventoryReportPage = () => {
  const dispatch = useAppDispatch();
  const { projectsSummarizedData } = useAppSelector(getProjectsState);
  const { productsData, isLoading } = useAppSelector(getProductState);
  const { locationsData } = useAppSelector(getLocationsState);
  const [stats, setStats] = useState({
    totalMaterials: 0,
  });
  const filters: Record<string, FilterType> = useMemo(
    () => ({
      projectId: {
        label: "Project",
        type: FilterInputTypes.SELECT,
        options:
          projectsSummarizedData?.map((m) => ({
            value: m?.id || "",
            label: m?.name || "",
          })) || [],
        placeholder: "Select Project",
        size: 4,
        clearable: true,
      },
      locationId: {
        label: "Location",
        type: FilterInputTypes.SELECT,
        options:
          locationsData?.map((m) => ({
            value: m?.id || "",
            label: m?.name || "",
            projectId: m?.projectId || "",
          })) || [],
        filterByKey: "projectId",
        placeholder: "Select Location",
        size: 4,
        clearable: true,
      },
    }),
    [projectsSummarizedData]
  );
  const generateExcel = () => {
    if (productsData !== null && productsData?.length > 0) {
      const data: InventoryReportFields[] = productsData?.map((m: Product) => ({
        Product: m?.productName || "",
        "Cost Code": m?.costCode || "",
        Quantity: m?.quantity || 0,
        "Unit of Measurement": m?.unitOfMeasure || "",
      }));

      exportToExcel<InventoryReportFields[]>(
        data,
        "Inventory",
        "inventory-report"
      );
    }
  };

  useEffect(() => {
    dispatch(getSummarizedProjectsList());
    dispatch(getLocationslist());
  }, []);

  return (
    <PageLayout
      backlink={{ title: "Reports", route: routePaths.REPORTS }}
      title="Inventory Report"
    >
      <ReportFilters filters={filters} />

      <ReportArtificialSpace />

      <div className="flex gap-3">
        <div className="flex flex-col basis-2/6 gap-3">
          <ReportStatisticsCard
            className="grow-0"
            title="Total Materials"
            stat={stats.totalMaterials}
          />
        </div>
      </div>

      <ReportArtificialSpace />

      <ProductList
        setReportStats={setStats}
        exportButtonEl={
          <Button
            disabled={isLoading || !Boolean(productsData?.length)}
            onClick={generateExcel}
          >
            Export
          </Button>
        }
      />
    </PageLayout>
  );
};

export default InventoryReportPage;
