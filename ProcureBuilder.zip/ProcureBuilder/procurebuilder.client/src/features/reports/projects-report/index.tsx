import CustomIcon from "@/src/components/common/CustomIcon";
import PageLayout from "@/src/components/layout/PageLayout";
import { useAppSelector } from "@/src/hooks/useAppSelector";
import { getProjectManagersState } from "@/src/store/slices/projectManagersSlice";
import { getProjectsState } from "@/src/store/slices/projectsSlice";
import { getTypesState } from "@/src/store/slices/typesSlice";
import { getStatusLabelByEnumValue } from "@/src/utils/general-helpers";
import { convertToLocaleString } from "@/src/utils/helper";
import routePaths from "@/src/utils/routePaths";
import { getFullName } from "@/src/utils/string-extensions";
import { Project } from "@/src/utils/types";
import { exportToExcel } from "@/src/utils/xlsx-utils";
import { Button, Progress } from "antd";
import dayjs from "dayjs";
import { useMemo, useState } from "react";
import ProjectsList from "../../projects/components/ProjectsList";
import ReportArtificialSpace from "../components/ReportArtificialSpace";
import ReportFilters from "../components/ReportFilters";
import ReportStatisticsCard from "../components/ReportStatisticsCard";
import { FilterType } from "../types";
import { FilterInputTypes } from "../utils";

type ProjectReportFields = {
  "Project Name": string;
  Type: string | undefined;
  Customer: string;
  "Projected Start": string | null | undefined;
  "Projected Completion": string | null | undefined;
  Status: string;
  "Contract Price": string | undefined;
};

const ProjectReportPage = () => {
  const [stats, setStats] = useState({
    totalProjectsCount: 0,
    totalContractsPrice: 0,
    totalOpenProjects: 0,
    totalClosedProjects: 0,
  });
  const { projectsData, isLoading } = useAppSelector(getProjectsState);
  const { typesData: projectTypesData } = useAppSelector(getTypesState);
  const { managersData: projectManagersData } = useAppSelector(
    getProjectManagersState
  );

  const generateExcel = () => {
    if (projectsData !== null && projectsData?.length > 0) {
      const data: ProjectReportFields[] = projectsData?.map((m: Project) => ({
        "Project Name": m?.name,
        Type:
          projectTypesData?.find((f) => f?.id === m?.projectTypeId)?.name || "",
        Customer: getFullName(m?.customer) || "N/A",
        "Projected Start": dayjs(m?.projectedStartDate)
          .format("MM/DD/YYYY")
          .toString(),
        "Projected Completion": dayjs(m?.projectedCompletionDate)
          .format("MM/DD/YYYY")
          .toString(),
        Status: getStatusLabelByEnumValue(m?.status),
        "Contract Price": `$${convertToLocaleString(m?.contractPrice || 0)}`,
      }));

      exportToExcel<ProjectReportFields[]>(data, "Projects", "projects-report");
    }
  };

  const filters: Record<string, FilterType> = useMemo(
    () => ({
      projectTypeId: {
        label: "Project Type",
        type: FilterInputTypes.SELECT,
        placeholder: "Select Project Type",
        options: projectTypesData?.map((m) => ({
          label: m?.name || "",
          value: m?.id || "",
        })),
        size: 4,
        clearable: true,
      },
      projectManagerId: {
        label: "Project Manager",
        type: FilterInputTypes.SELECT,
        placeholder: "Select Project Manager",
        options: projectManagersData?.map((m) => ({
          label: m?.fullName || "",
          value: m?.id || "",
        })),
        size: 4,
        clearable: true,
      },
      contractPrice: {
        label: "Contract Price",
        type: FilterInputTypes.NUMBER_RANGE,
        placeholder: "$ 0.00",
        prefix: "$",
        size: 4,
        isPriceRange: true,
      },
      projectedStart: {
        label: "Projected Start",
        type: FilterInputTypes.DATE_RANGE,
        placeholder: "MM / DD / YYYY",
        suffix: <CustomIcon type="calendar-green-icon" />,
        size: 4,
      },
      projectedCompletion: {
        label: "Projected Completion",
        type: FilterInputTypes.DATE_RANGE,
        placeholder: "MM / DD / YYYY",
        suffix: <CustomIcon type="calendar-green-icon" />,
        size: 4,
      },
    }),
    [projectTypesData, projectManagersData]
  );

  const projectCompletionRate = useMemo(() => {
    const rate =
      ((stats.totalClosedProjects || 0) / (stats.totalProjectsCount || 0)) *
      100;
    return isNaN(rate) ? 0 : rate;
  }, [stats.totalClosedProjects, stats.totalProjectsCount]);

  return (
    <PageLayout
      backlink={{
        title: "Reports",
        route: routePaths.REPORTS,
      }}
      title="Projects Report"
    >
      <ReportFilters filters={filters} />

      <ReportArtificialSpace />

      <div className="flex gap-3">
        <ReportStatisticsCard
          title="Total Projects"
          stat={stats.totalProjectsCount?.toLocaleString()}
        />
        <ReportStatisticsCard
          title="Total Contracts' Price"
          stat={`$${stats.totalContractsPrice?.toLocaleString()}`}
        />
        <ReportStatisticsCard
          title="Project Completion Rate"
          className="grow-[3]"
        >
          <div className="flex flex-col">
            <p className="font-semibold text-xl">
              {projectCompletionRate?.toFixed(2)}%
            </p>
            <Progress percent={projectCompletionRate} showInfo={false} />
          </div>
        </ReportStatisticsCard>
      </div>

      <ReportArtificialSpace />

      <ProjectsList
        setReportStats={(
          totalProjectsCount,
          totalContractsPrice,
          totalOpenProjects,
          totalClosedProjects
        ) => {
          setStats({
            totalProjectsCount: totalProjectsCount || 0,
            totalContractsPrice: totalContractsPrice || 0,
            totalOpenProjects: totalOpenProjects || 0,
            totalClosedProjects: totalClosedProjects || 0,
          });
        }}
        exportButtonEl={
          <Button
            disabled={isLoading || !Boolean(projectsData?.length)}
            onClick={generateExcel}
          >
            Export
          </Button>
        }
      />
    </PageLayout>
  );
};

export default ProjectReportPage;
