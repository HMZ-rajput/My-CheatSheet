import CustomIcon from "@/src/components/common/CustomIcon";
import DeleteIconButton from "@/src/components/icon-buttons/DeleteIconButton";
import { useAppDispatch } from "@/src/hooks/useAppDispatch";
import { resetState } from "@/src/store/slices/materialGoingToSiteSlice";
import { MaterialTransferStatusEnum } from "@/src/utils/enums";
import routePaths from "@/src/utils/routePaths";
import { MaterialGoingToSite, MaterialTransfer } from "@/src/utils/types";
import { Button, Col, Flex, Form, Input, InputNumber, Row, Select } from "antd";
import { useEffect } from "react";
import {
  Control,
  Controller,
  useFieldArray,
  UseFormGetValues,
  UseFormSetValue,
  UseFormWatch,
} from "react-hook-form";
import MaterialGoingToSiteHeader from "./MaterialGoingToSiteHeader";

type Material = {
  id: string | null;
  name: string;
  unitOfMeasure: string;
  quantity: number;
  samples: number;
  spares: number;
  regular: number;
};

type SubLocation = {
  subLocationId?: string;
  subLocationName?: string;
  materials?: Material[];
};

type LocationData = SubLocation[];

type AddMaterialFormProps = {
  control: Control<MaterialTransfer>;
  setValue: UseFormSetValue<MaterialTransfer>;
  data: LocationData;
  getValues: UseFormGetValues<MaterialTransfer>;
  initialData?: (MaterialGoingToSite & { modifiedBy?: string }) | null;
  watch: UseFormWatch<MaterialTransfer>;
};

export default function AddMaterialGointToSiteFormRHF2(
  props: AddMaterialFormProps
) {
  const { control, data, setValue, getValues, initialData, watch } = props;
  const dispatch = useAppDispatch();

  const selectedMaterialsFromRhf = watch("materials");

  const subLocationsDataOptions = data?.map((location) => ({
    label:
      location?.subLocationName === null
        ? "Unspecified"
        : location?.subLocationName,
    value: location?.subLocationId,
    disabled: location?.materials?.every((material) => {
      return selectedMaterialsFromRhf?.some(
        (selectedMaterial) =>
          selectedMaterial?.name === material?.name &&
          selectedMaterial?.subLocationId === location?.subLocationId
      );
    }),
  }));

  useEffect(() => {
    if (location.pathname === routePaths.MATERIAL_GOING_TO_SITES_NEW) {
      dispatch(resetState());
    }
  }, [location.pathname]);

  const {
    fields: materialFields,
    remove,
    append,
  } = useFieldArray({
    name: "materials",
    control: control,
  });

  const handleAddMaterial = () => {
    append({
      id: "",
      name: "",
      quantity: 0,
      samples: 0,
      spares: 0,
      unitOfMeasure: "",
      subLocationName: "",
      regular: 0,
      subLocationId: "",
    });
  };

  const handleDelete = (index: number) => {
    remove(index);
  };

  const handleChangeSubLocation = (index: number, value: string) => {
    setValue(`materials.${index}.subLocationId`, value);
    setValue(`materials.${index}.name`, "");
    setValue(`materials.${index}.samples`, 0);
    setValue(`materials.${index}.spares`, 0);
    setValue(`materials.${index}.regular`, 0);
    setValue(`materials.${index}.quantity`, 0);
    setValue(`materials.${index}.unitOfMeasure`, "");
  };

  const handleChangeMaterial = (index: number, value: string) => {
    setValue(`materials.${index}.name`, value);
    const material = data
      ?.find(
        (location) =>
          location?.subLocationId ===
          selectedMaterialsFromRhf?.[index]?.subLocationId
      )
      ?.materials?.find((material) => material.name === value);

    setValue(`materials.${index}.samples`, material?.samples || 0);
    setValue(`materials.${index}.spares`, material?.spares || 0);
    setValue(`materials.${index}.regular`, material?.regular || 0);
    setValue(`materials.${index}.quantity`, material?.quantity || 0);
    setValue(
      `materials[${index}].unitOfMeasure` as string | any,
      material?.unitOfMeasure || ""
    );
  };

  const maxValues = (index: number) => {
    const materials = data?.find(
      (location) =>
        location?.subLocationId ===
        selectedMaterialsFromRhf?.[index]?.subLocationId
    )?.materials;
    const material = materials?.find(
      (mgts) => mgts?.name === getValues(`materials.${index}.name`)
    );

    return material;
  };
  // const handleCalculateTotal = (index: number) => {
  //   let total = 0;
  //   const sample = getValues(`materials.${index}.samples`);
  //   const spares = getValues(`materials.${index}.spares`);
  //   const regular = getValues(`materials.${index}.regular`);
  //   total = sample + spares + regular;
  //   const quantity = maxValues(index)?.quantity;
  //   if (total <= quantity!) {
  //     setValue(`materials.${index}.quantity`, total);
  //   }
  // };

  return (
    <>
      <div className="py-1.5">
        <div className="py-1.5 px-2 rounded-lg mb-4 bg-neutral-1">
          <MaterialGoingToSiteHeader />
        </div>

        {materialFields?.map((field, index) => {
          const materialOptions =
            data
              ?.find((locations) => {
                if (
                  locations?.subLocationId ===
                  selectedMaterialsFromRhf?.[index]?.subLocationId
                ) {
                  return locations.materials;
                }
              })
              ?.materials?.map((material) => ({
                label: material.name,
                value: material.name,
                disabled: selectedMaterialsFromRhf?.some((selectedMaterial) => {
                  return selectedMaterial?.name === material.name;
                }),
              })) || [];

          return (
            <Row key={field?.id} gutter={[16, 16]}>
              <Col xs={6}>
                <Controller
                  name={`materials.${index}.subLocationId`}
                  control={control}
                  render={({ field, fieldState: { error } }) => (
                    <Form.Item
                      labelAlign="right"
                      validateStatus={error ? "error" : ""}
                      help={error ? error.message : ""}
                    >
                      <Select
                        {...field}
                        disabled={
                          initialData?.status ===
                          MaterialTransferStatusEnum.TRANSFERRED
                        }
                        size="large"
                        placeholder={"Sublocations"}
                        style={{ width: "100%" }}
                        showSearch
                        value={field.value}
                        onChange={(value) => {
                          handleChangeSubLocation(index, value);
                        }}
                        options={[
                          {
                            label: "Select Sublocation",
                            value: "",
                          },
                          ...subLocationsDataOptions,
                        ]}
                        optionRender={(option) => {
                          return option.label;
                        }}
                        filterOption={(input, option) =>
                          (option?.value || "")
                            .toLowerCase()
                            .includes(input.toLowerCase())
                        }
                      />
                    </Form.Item>
                  )}
                />
              </Col>
              {/* Material */}

              <Col xs={6}>
                <Controller
                  name={`materials.${index}.name`}
                  control={control}
                  render={({ field, fieldState: { error } }) => (
                    <Form.Item
                      labelAlign="right"
                      validateStatus={!field.value && error ? "error" : ""}
                      help={!field.value && error ? error.message : ""}
                    >
                      <Select
                        {...field}
                        size="large"
                        placeholder={"Select Materials"}
                        style={{ width: "100%" }}
                        showSearch
                        disabled={
                          initialData?.status ===
                          MaterialTransferStatusEnum.TRANSFERRED
                        }
                        value={field.value}
                        onChange={(value) => {
                          handleChangeMaterial(index, value);
                        }}
                        options={[
                          {
                            label: "Select Materials",
                            value: "",
                          },
                          ...materialOptions,
                        ]}
                        filterOption={(input, option) =>
                          (option?.label || "")
                            ?.toLowerCase()
                            ?.includes(input.toLowerCase())
                        }
                      />
                    </Form.Item>
                  )}
                />
              </Col>
              {/* Samples */}
              {/* <Col xs={3} className="flex">
                <Controller
                  name={`materials.${index}.samples`}
                  control={control}
                  render={({ field, fieldState: { error } }) => (
                    <Form.Item
                      labelAlign="right"
                      validateStatus={error ? "error" : ""}
                      help={error ? error.message : ""}
                    >
                      <InputNumber
                        {...field}
                        size="large"
                        type="number"
                        precision={0}
                        disabled={
                          initialData?.status ===
                          MaterialTransferStatusEnum.TRANSFERRED
                        }
                        min={0}
                        max={maxValues(index)?.samples ?? 0}
                        style={{ width: "100%" }}
                        placeholder="sample"
                        value={field.value ?? 0}
                        onChange={(value) => {
                          field.onChange(value ?? 0);
                          handleCalculateTotal(index);
                        }}
                      />
                    </Form.Item>
                  )}
                />
                <div className="mt-2 ml-2">
                  /{maxValues(index)?.samples ?? 0}
                </div>
              </Col> */}
              {/* Spare */}
              {/* <Col xs={3} className="flex">
                <Controller
                  name={`materials.${index}.spares`}
                  control={control}
                  render={({ field, fieldState: { error } }) => (
                    <Form.Item
                      labelAlign="right"
                      validateStatus={error ? "error" : ""}
                      help={error ? error.message : ""}
                    >
                      <InputNumber
                        {...field}
                        precision={0}
                        size="large"
                        min={0}
                        max={maxValues(index)?.spares ?? 0}
                        style={{ width: "100%" }}
                        placeholder="spares"
                        value={field.value ?? 0}
                        disabled={
                          initialData?.status ===
                          MaterialTransferStatusEnum.TRANSFERRED
                        }
                        onChange={(value) => {
                          field.onChange(value ?? 0);
                          handleCalculateTotal(index);
                        }}
                      />
                    </Form.Item>
                  )}
                />
                <div className="mt-2 ml-2">
                  /{maxValues(index)?.spares ?? 0}
                </div>
              </Col> */}
              {/* Regular */}
              {/* <Col xs={3} className="flex">
                <Controller
                  name={`materials.${index}.regular`}
                  control={control}
                  render={({ field, fieldState: { error } }) => (
                    <Form.Item
                      labelAlign="right"
                      validateStatus={error ? "error" : ""}
                      help={error ? error.message : ""}
                    >
                      <InputNumber
                        {...field}
                        precision={0}
                        size="large"
                        min={0}
                        disabled={
                          initialData?.status ===
                          MaterialTransferStatusEnum.TRANSFERRED
                        }
                        max={maxValues(index)?.regular ?? 0}
                        style={{ width: "100%" }}
                        placeholder="spares"
                        value={field.value ?? 0}
                        onChange={(value) => {
                          field.onChange(value ?? 0);
                          handleCalculateTotal(index);
                        }}
                      />
                    </Form.Item>
                  )}
                />
                <div className="mt-2 ml-2">
                  /{maxValues(index)?.regular ?? 0}
                </div>
              </Col> */}
              {/* Quantity */}
              <Col xs={6} className="flex">
                <Controller
                  name={`materials.${index}.quantity`}
                  control={control}
                  render={({ field, fieldState: { error } }) => (
                    <Form.Item
                      className="flex-grow"
                      labelAlign="right"
                      validateStatus={error ? "error" : ""}
                      help={error ? error.message : ""}
                    >
                      <InputNumber
                        {...field}
                        onChange={(value) => {
                          const quantity = maxValues(index)?.quantity || 0;
                          const val = value || 0;

                          if (val <= quantity) {
                            field.onChange(value);
                          }
                        }}
                        precision={0}
                        size="large"
                        min={0}
                        disabled={
                          initialData?.status ===
                          MaterialTransferStatusEnum.TRANSFERRED
                        }
                        max={maxValues(index)?.quantity}
                        style={{ width: "100%" }}
                        placeholder="Quantity"
                        value={field.value ?? 0}
                      />
                    </Form.Item>
                  )}
                />
                <div className="mt-2 ml-2">
                  /{maxValues(index)?.quantity ?? 0}
                </div>
              </Col>
              {/* Unit of Measurement */}
              <Col xs={5}>
                <Controller
                  name={`materials[${index}].unitOfMeasure` as string | any}
                  control={control}
                  render={({ field, fieldState: { error } }) => (
                    <Form.Item
                      labelAlign="right"
                      validateStatus={!field.value && error ? "error" : ""}
                      help={!field.value && error ? error.message : ""}
                    >
                      <Input
                        {...field}
                        onChange={(e) => {
                          setValue(
                            `materials[${index}].unitOfMeasure` as string | any,
                            e.target.value
                          );
                        }}
                        size="large"
                        disabled={
                          initialData?.status ===
                          MaterialTransferStatusEnum.TRANSFERRED
                        }
                        placeholder="FT"
                        value={field.value || ""}
                      />
                    </Form.Item>
                  )}
                />
              </Col>
              <Col className="mt-1" xs={1}>
                <DeleteIconButton
                  handleDelete={() => handleDelete(index)}
                  disabled={
                    materialFields?.length === 1 ||
                    initialData?.status ===
                      MaterialTransferStatusEnum.TRANSFERRED
                  }
                />
              </Col>
            </Row>
          );
        })}

        {initialData?.status !== MaterialTransferStatusEnum.TRANSFERRED && (
          <Flex justify="space-between">
            <Button
              className="border-0 shadow-none text-primary font-medium"
              size="small"
              icon={<CustomIcon width={16} type="add-circle" />}
              onClick={handleAddMaterial}
            >
              Add Material
            </Button>
          </Flex>
        )}
      </div>
    </>
  );
}
