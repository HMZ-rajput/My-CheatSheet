import { getLocationslist } from "@/src/apis/locationApis";
import {
  createMaterialGoingToSite,
  deleteMaterialGoingToSiteById,
  editMaterialGoingToSiteById,
} from "@/src/apis/materialGoingToSiteApis";
import { getAllMaterialTransferlist } from "@/src/apis/materialTransferApis";
import { getSummarizedProjectsList } from "@/src/apis/projectApis";
import { getAllStorageTypes } from "@/src/apis/storageTypeApis";
import CreatedByUserBadge from "@/src/components/common/CreatedByUserBadge";
import CustomAlert from "@/src/components/common/CustomAlert";
import CustomOverlayLoader from "@/src/components/common/CustomOverlayloader";
import CustomFormRow from "@/src/components/form/CustomFormRow";
import LocationModal from "@/src/features/locations/components/LocationModal";
import { useAppDispatch } from "@/src/hooks/useAppDispatch";
import { getLocationsState } from "@/src/store/slices/locationSlice";
import {
  getMaterialGoingToSiteState,
  resetState,
} from "@/src/store/slices/materialGoingToSiteSlice";
import { getProjectsState } from "@/src/store/slices/projectsSlice";
import { getUserFullName } from "@/src/store/slices/userSlice";
import { ActionTypeEnum, MaterialTransferStatusEnum } from "@/src/utils/enums";
import routePaths from "@/src/utils/routePaths";
import {
  ActionTypeState,
  MaterialGoingToSite,
  MaterialTransfer,
} from "@/src/utils/types";
import { PlusOutlined } from "@ant-design/icons";
import CustomFormLabel from "@components/common/CustomFormLabel";
import SectionLayout from "@components/layout/SectionLayout";
import { yupResolver } from "@hookform/resolvers/yup";
import { useAppSelector } from "@hooks/useAppSelector";
import { dateFormat, materialTransferStatusOptions } from "@utils/constants";
import {
  Button,
  Col,
  DatePicker,
  Divider,
  Flex,
  Form,
  Input,
  Select,
  Space,
  Typography,
} from "antd";
import dayjs from "dayjs";
import { useEffect, useMemo, useState } from "react";
import { Controller, Resolver, useForm } from "react-hook-form";
import { useLocation, useNavigate } from "react-router-dom";
import { updateMaterials } from "../../../utils/update-materials";
import AddMaterialGointToSiteFormRHF2 from "./AddMaterialGoingToSitesDetailsForm2";
import { validationSchema } from "./MaterialGTSValidationSchema";

type Material = {
  id: string;
  name: string;
  unitOfMeasure: string;
  quantity: number;
  samples: number;
  spares: number;
  regular: number;
};

type SubLocation = {
  subLocationId: string;
  subLocationName: string;
  materials: Material[];
};

type LocationData = SubLocation[];

type MaterialDetailsFormProps = {
  materialGoingToSite?:
    | (MaterialGoingToSite & { modifiedBy?: string; createdDate?: Date | null })
    | null;
  projectLocationId?: string;
  handleCancelForm?: () => void;
};

const intialsMaterialsValues = Array.from({ length: 5 }, () => ({
  id: "",
  name: "",
  subLocationId: "",
  subLocationName: "",
  quantity: 0,
  unitOfMeasure: "",
  samples: 0,
  spares: 0,
  regular: 0,
}));

export default function MaterialGoingToSitesDetailsForm({
  materialGoingToSite,
}: MaterialDetailsFormProps) {
  const userFullName = useAppSelector(getUserFullName);
  const location = useLocation();
  const [isLocationModalOpen, setIsLocationModalOpen] = useState<{
    open: boolean;
    title?: string | null;
    field?: string;
  }>({ open: false, title: null, field: "" });

  const { reqError, resError, successMessage } = useAppSelector(
    getMaterialGoingToSiteState
  );
  const dispatch = useAppDispatch();
  const navigate = useNavigate();

  const [actionType, setActionType] = useState<ActionTypeState>({
    delete: ActionTypeEnum.NEUTRAL,
    downloadPdf: ActionTypeEnum.NEUTRAL,
    save: ActionTypeEnum.NEUTRAL,
    saveAndNew: ActionTypeEnum.NEUTRAL,
    saveAndClose: ActionTypeEnum.NEUTRAL,
    cancel: ActionTypeEnum.NEUTRAL,
  });

  const [isProjectSelected, setIsProjectSelected] = useState<boolean>(false);

  const [tableData, setTableData] = useState<LocationData | []>([]);

  type FieldType = MaterialTransfer[];

  useEffect(() => {
    dispatch(getSummarizedProjectsList());
  }, [dispatch]);
  useEffect(() => {
    setTableData([]);
  }, [location.pathname]);

  const { projectsSummarizedData } = useAppSelector(getProjectsState);

  const memoizedProjectsOptions = useMemo(() => {
    return [
      {
        value: "",
        label: "Select Project",
      },
      ...(projectsSummarizedData?.map((f) => ({
        value: f.id,
        label: f.name,
      })) || []),
    ];
  }, [projectsSummarizedData]);

  const { locationsList } = useAppSelector(getLocationsState);

  const memoizedLocationOptions = useMemo(() => {
    return [
      {
        value: "",
        label: "Select Site",
      },
      ...(locationsList?.map((f) => ({
        value: f.id,
        label: f.name,
      })) || []),
    ];
  }, [locationsList, materialGoingToSite]);

  const getInitialValues = () => {
    return {
      title: materialGoingToSite?.title || "",
      transferDate: dayjs(materialGoingToSite?.transferDate || new Date()),
      status: materialGoingToSite?.status || 0,
      originalLocationId: materialGoingToSite?.originalLocation?.id || "",
      destinationLocationId: materialGoingToSite?.destinationLocation?.id || "",
      projectId: materialGoingToSite?.originalProject?.id || "",
      materials:
        (materialGoingToSite &&
          materialGoingToSite?.materials?.map((material) => {
            return {
              id: material?.id,
              name: material?.name,
              subLocationId: material?.subLocationId,
              subLocationName: material.subLocationName,
              quantity: material.quantity,
              unitOfMeasure: material.unitOfMeasure,
              spares: material.spares,
              samples: material.samples,
              regular: material.regular,
            };
          })) ||
        [],
    };
  };

  const {
    control,
    handleSubmit,
    watch,
    setValue,
    getValues,
    reset,
    formState: { isSubmitting },
  } = useForm<MaterialTransfer>({
    resolver: yupResolver(
      validationSchema
    ) as unknown as Resolver<MaterialGoingToSite>,
    defaultValues: getInitialValues(),
  });

  const onSubmit = async (values: MaterialGoingToSite) => {
    if (actionType.save === ActionTypeEnum.SAVE) {
      const res = await handleSave(values);
      if (res?.isSuccess) {
        navigate(
          `${routePaths.MATERIAL_GOING_TO_SITES_EDIT_BY_ID}/${res?.materialToSite?.id}`
        );
      }
    } else if (actionType.saveAndClose === ActionTypeEnum.SAVE_AND_CLOSE) {
      const res = await handleSave(values);
      if (res?.isSuccess) {
        handleCancel();
      }
    } else if (actionType.saveAndNew === ActionTypeEnum.SAVE_AND_NEW) {
      const res = await handleSave(values);
      if (res?.isSuccess) {
        reset({
          materials: intialsMaterialsValues,
          title: "",
          projectId: "",
          originalLocationId: "",
          destinationLocationId: "",
        });
      }
    }
  };

  const handleSave = async (values: MaterialGoingToSite) => {
    const payload = {
      createdBy: userFullName,
      ...values,
      transferDate: dayjs(values?.transferDate || new Date()).toDate(),
    };
    try {
      if (materialGoingToSite?.id) {
        const data = {
          ...payload,
          materials: payload.materials?.map((mte) => ({
            ...mte,
            id:
              mte.id ||
              (tableData?.length > 0 &&
                tableData
                  .find((tbD) => tbD?.subLocationId === mte?.subLocationId)
                  ?.materials?.find((m) => m?.name === mte.name)?.id) ||
              "",
          })),
        };
        return await dispatch(
          editMaterialGoingToSiteById({
            materialGoingToSiteId: materialGoingToSite?.id,
            ...data,
          })
        ).unwrap();
      } else {
        const data = {
          ...payload,
          materials: payload.materials?.map((mte) => ({
            ...mte,
            id:
              (tableData.length > 0 &&
                tableData
                  .find((tbD) => tbD?.subLocationId === mte?.subLocationId)
                  ?.materials?.find((m) => m?.name === mte.name)?.id) ||
              "",
          })),
        };
        return await dispatch(createMaterialGoingToSite({ ...data })).unwrap();
      }
    } catch (err) {
      console.log(err);
    }
  };

  const handleCancel = async () => {
    const previousPath = location?.state?.previousPath || "";
    if (previousPath) {
      navigate(previousPath);
    } else {
      navigate(routePaths.MATERIAL_GOING_TO_SITES);
    }
  };
  const fetchLocationOptions = async (projectId: string) => {
    setIsProjectSelected(true);
    try {
      await dispatch(getLocationslist(projectId)).unwrap();
    } catch (error) {
      console.error(error, "Error fetching locations list.");
    } finally {
      setIsProjectSelected(false);
    }
  };

  const handleProjectChange = (projectId: string) => {
    setValue("projectId", projectId);
    setValue("originalLocationId", null);
    setValue("destinationLocationId", null);
    setTableData([]);

    fetchLocationOptions(projectId);
    setValue("materials", intialsMaterialsValues);
  };

  const handleLocationChange = async (value: string) => {
    const data = await dispatch(
      getAllMaterialTransferlist({
        projectLocationId: value,
        purchaseOrderIds:
          materialGoingToSite?.purchaseOrders?.map((f) => f.id) || [],
      })
    ).unwrap();
    if (data.isSuccess) {
      setTableData(data?.inventory as []);
    } else {
      setTableData([]);
    }
  };

  const handleOnDelete = async () => {
    setActionType({ delete: ActionTypeEnum.DELETE });
    if (materialGoingToSite?.id) {
      const res = await dispatch(
        deleteMaterialGoingToSiteById(materialGoingToSite?.id)
      ).unwrap();
      setActionType({ delete: ActionTypeEnum.NEUTRAL });
      if (res?.isSuccess) {
        handleCancel();
      }
    }
  };

  useEffect(() => {
    if (materialGoingToSite?.id) {
      setIsProjectSelected(true);

      dispatch(
        getLocationslist(materialGoingToSite?.originalProject?.id || "")
      );

      dispatch(
        getAllMaterialTransferlist({
          projectLocationId: materialGoingToSite?.originalLocation?.id || "",
          purchaseOrderIds:
            materialGoingToSite?.purchaseOrders?.map((f) => f.id) || [],
        })
      )
        .unwrap()
        .then((data) => {
          if (data?.isSuccess) {
            const updateTableData = updateMaterials(
              data.inventory,
              materialGoingToSite?.materials
            );
            setTableData(() => [...updateTableData]);
          }
          setIsProjectSelected(false);
        });
    }
  }, [materialGoingToSite]);

  useEffect(() => {
    if (materialGoingToSite) {
      reset(getInitialValues());
    } else if (location.pathname === routePaths.MATERIAL_GOING_TO_SITES_NEW) {
      reset({
        title: "",
        transferDate: dayjs(new Date()),
        status: 0,
        originalLocationId: "",
        destinationLocationId: "",
        projectId: "",
        materials: intialsMaterialsValues,
      });
    }
  }, [materialGoingToSite, location.pathname]);

  useEffect(() => {
    if (isLocationModalOpen?.open) {
      dispatch(getAllStorageTypes());
    } else {
      dispatch(getLocationslist(getValues("projectId") || ""));
    }
  }, [dispatch, isLocationModalOpen?.open]);
  const handleOpenLocationModal = (title: string, field: string) => {
    setIsLocationModalOpen({
      title: title,
      open: true,
      field: field,
    });
  };

  useEffect(() => {
    dispatch(resetState());
  }, []);

  return (
    <>
      <LocationModal
        setLocationValue={setValue}
        projectId={getValues("projectId")}
        isLocationModalOpen={isLocationModalOpen}
        setIsLocationModalOpen={setIsLocationModalOpen}
      />
      {isProjectSelected ? (
        <CustomOverlayLoader />
      ) : (
        <SectionLayout>
          <Form
            onFinish={handleSubmit(onSubmit)}
            layout="vertical"
            autoComplete="off"
          >
            <CustomFormRow>
              <Col xs={24} className="mb-4">
                <Typography.Title level={5}>
                  {materialGoingToSite ? "Edit" : "New"} Material Going To Site
                </Typography.Title>
              </Col>

              <Col xs={12}>
                <Controller
                  control={control}
                  name="title"
                  render={({ field, fieldState: { error } }) => (
                    <Form.Item<FieldType>
                      label={<CustomFormLabel text="Title" required />}
                      labelAlign="right"
                      validateStatus={!field.value && error ? "error" : ""}
                      help={!field.value && error ? error.message : ""}
                    >
                      <Input
                        {...field}
                        size="large"
                        placeholder="Title"
                        disabled={
                          materialGoingToSite?.status ===
                            MaterialTransferStatusEnum.TRANSFERRED ||
                          materialGoingToSite?.status ===
                            MaterialTransferStatusEnum.CANCELLED
                        }
                      />
                    </Form.Item>
                  )}
                />
              </Col>

              <Col xs={12}>
                <Controller
                  name="projectId"
                  control={control}
                  render={({ field, fieldState: { error } }) => (
                    <Form.Item
                      label={<CustomFormLabel text="Project" required />}
                      labelAlign="right"
                      validateStatus={!field.value && error ? "error" : ""}
                      help={!field.value && error ? error.message : ""}
                    >
                      <Select
                        {...field}
                        value={field.value}
                        onChange={(value) => {
                          reset((data) => ({
                            ...data,
                            materials: intialsMaterialsValues,
                          }));

                          handleProjectChange(value); // if you need to trigger this function
                        }}
                        size="large"
                        placeholder="Select Project Name"
                        options={memoizedProjectsOptions}
                        showSearch
                        allowClear
                        disabled={
                          materialGoingToSite?.status ===
                            MaterialTransferStatusEnum.TRANSFERRED ||
                          materialGoingToSite?.status ===
                            MaterialTransferStatusEnum.CANCELLED
                        }
                        filterOption={(input, option) =>
                          (option?.label ?? "")
                            .toLowerCase()
                            .includes(input.toLowerCase())
                        }
                      />
                    </Form.Item>
                  )}
                />
              </Col>

              <Col xs={12}>
                <Controller
                  name="transferDate"
                  control={control}
                  render={({ field, fieldState: { error } }) => (
                    <Form.Item
                      label={<CustomFormLabel text="Transfer Date" required />}
                      labelAlign="right"
                      validateStatus={!field.value && error ? "error" : ""}
                      help={!field.value && error ? error.message : ""}
                    >
                      <DatePicker
                        {...field}
                        disabled={
                          materialGoingToSite?.status ===
                            MaterialTransferStatusEnum.TRANSFERRED ||
                          materialGoingToSite?.status ===
                            MaterialTransferStatusEnum.CANCELLED
                        }
                        value={
                          dayjs(field.value).isValid()
                            ? dayjs(field.value)
                            : null
                        }
                        onChange={(date) => {
                          field.onChange(dayjs(date).locale("en").format());
                        }}
                        size="large"
                        style={{ width: "100%" }}
                        placeholder="MM/DD/YYYY"
                        format={dateFormat}
                      />
                    </Form.Item>
                  )}
                />
              </Col>

              <Col xs={12}>
                <Controller
                  name="originalLocationId"
                  control={control}
                  render={({ field, fieldState: { error } }) => (
                    <Form.Item
                      label={
                        <CustomFormLabel text="Original Location" required />
                      }
                      labelAlign="right"
                      validateStatus={!field.value && error ? "error" : ""}
                      help={!field.value && error ? error.message : ""}
                    >
                      <Select
                        {...field}
                        value={field.value}
                        onChange={(value) => {
                          reset((data) => ({
                            ...data,
                            materials: intialsMaterialsValues,
                          }));
                          field.onChange(value);
                          // this set value is due to field.onChange not updating the value
                          setValue("originalLocationId", value);
                          setValue("destinationLocationId", null);
                          handleLocationChange(value);
                        }}
                        size="large"
                        placeholder="Select Location"
                        options={memoizedLocationOptions}
                        showSearch
                        allowClear
                        disabled={
                          !watch("projectId") ||
                          materialGoingToSite?.status ===
                            MaterialTransferStatusEnum.TRANSFERRED ||
                          materialGoingToSite?.status ===
                            MaterialTransferStatusEnum.CANCELLED
                        }
                        filterOption={(input, option) =>
                          (option?.label ?? "")
                            .toLowerCase()
                            .includes(input.toLowerCase())
                        }
                        dropdownRender={(menu) => (
                          <>
                            {menu}
                            <Divider className="mt-2 mb-1" />
                            <Space className="p-1">
                              <Button
                                type="text"
                                icon={<PlusOutlined />}
                                onClick={() =>
                                  handleOpenLocationModal(
                                    " Add New Original Location ",
                                    "originalLocationId"
                                  )
                                }
                              >
                                Add New Original Location
                              </Button>
                            </Space>
                          </>
                        )}
                      />
                    </Form.Item>
                  )}
                />
              </Col>

              <Col xs={12}>
                <Controller
                  name="destinationLocationId"
                  control={control}
                  render={({ field, fieldState: { error } }) => (
                    <Form.Item
                      label={<CustomFormLabel text="Delivering To" required />}
                      labelAlign="right"
                      validateStatus={!field.value && error ? "error" : ""}
                      help={!field.value && error ? error.message : ""}
                    >
                      <Select
                        {...field}
                        value={field.value}
                        onChange={(value) => {
                          field.onChange(value);
                          setValue("destinationSubLocationId", "");
                        }}
                        size="large"
                        placeholder="Select Site"
                        options={memoizedLocationOptions.filter(
                          (f) =>
                            f.value === "" ||
                            f.value !== watch("originalLocationId")
                        )}
                        showSearch
                        disabled={
                          !watch("originalLocationId") ||
                          materialGoingToSite?.status ===
                            MaterialTransferStatusEnum.TRANSFERRED ||
                          materialGoingToSite?.status ===
                            MaterialTransferStatusEnum.CANCELLED
                        }
                        allowClear
                        filterOption={(input, option) =>
                          (option?.label ?? "")
                            .toLowerCase()
                            .includes(input.toLowerCase())
                        }
                        dropdownRender={(menu) => (
                          <>
                            {menu}
                            <Divider className="mt-2 mb-1" />
                            <Space className="p-1">
                              <Button
                                type="text"
                                icon={<PlusOutlined />}
                                onClick={() =>
                                  handleOpenLocationModal(
                                    " Add New Delivery Location ",
                                    "destinationLocationId"
                                  )
                                }
                              >
                                Add New Delivery Location
                              </Button>
                            </Space>
                          </>
                        )}
                      />
                    </Form.Item>
                  )}
                />
              </Col>

              <Col xs={12}>
                <Controller
                  name="status"
                  control={control}
                  render={({ field }) => (
                    <Form.Item
                      label={<CustomFormLabel text="Status" />}
                      labelAlign="right"
                    >
                      <Select
                        {...field}
                        value={field.value}
                        onChange={(value) => field.onChange(value)}
                        size="large"
                        options={materialTransferStatusOptions}
                        showSearch
                        disabled={
                          materialGoingToSite?.status ===
                            MaterialTransferStatusEnum.TRANSFERRED ||
                          materialGoingToSite?.status ===
                            MaterialTransferStatusEnum.CANCELLED
                        }
                        allowClear
                        filterOption={(input, option) =>
                          (option?.label ?? "")
                            .toLowerCase()
                            .includes(input.toLowerCase())
                        }
                      />
                    </Form.Item>
                  )}
                />
              </Col>
            </CustomFormRow>
            <Divider />
            <Typography.Title level={5}>Materials</Typography.Title>

            <div className="!mb-6">
              <AddMaterialGointToSiteFormRHF2
                control={control}
                setValue={setValue}
                data={tableData}
                getValues={getValues}
                key={tableData?.length}
                initialData={materialGoingToSite}
                watch={watch}
              />
            </div>

            {(reqError || resError || successMessage) && (
              <CustomAlert
                message={reqError || resError || successMessage || ""}
                type={successMessage ? "success" : "error"}
              />
            )}

            <Flex justify="flex-end" className="gap-4">
              <Button
                htmlType="button"
                onClick={() => handleCancel()}
                disabled={
                  actionType.delete === ActionTypeEnum.DELETE || isSubmitting
                }
              >
                Cancel
              </Button>
              {materialGoingToSite &&
                Object.keys(materialGoingToSite)?.length > 0 && (
                  <Button
                    htmlType="button"
                    disabled={
                      isSubmitting ||
                      materialGoingToSite?.status ===
                        MaterialTransferStatusEnum.TRANSFERRED ||
                      materialGoingToSite?.status ===
                        MaterialTransferStatusEnum.CANCELLED
                    }
                    onClick={() => handleOnDelete()}
                    loading={actionType.delete === ActionTypeEnum.DELETE}
                  >
                    {actionType.delete === ActionTypeEnum.DELETE
                      ? "Deleting..."
                      : "Delete"}
                  </Button>
                )}

              <Button
                htmlType="submit"
                type="primary"
                onClick={() => setActionType({ save: ActionTypeEnum.SAVE })}
                disabled={
                  isSubmitting ||
                  materialGoingToSite?.status ===
                    MaterialTransferStatusEnum.TRANSFERRED ||
                  materialGoingToSite?.status ===
                    MaterialTransferStatusEnum.CANCELLED ||
                  actionType.delete === ActionTypeEnum.DELETE
                }
                loading={
                  actionType.save === ActionTypeEnum.SAVE && isSubmitting
                }
              >
                {isSubmitting && actionType.save === ActionTypeEnum.SAVE
                  ? "Saving..."
                  : "Save"}
              </Button>
              <Button
                htmlType="submit"
                disabled={
                  isSubmitting ||
                  materialGoingToSite?.status ===
                    MaterialTransferStatusEnum.TRANSFERRED ||
                  materialGoingToSite?.status ===
                    MaterialTransferStatusEnum.CANCELLED ||
                  actionType.delete === ActionTypeEnum.DELETE
                }
                type="primary"
                onClick={() =>
                  setActionType({ saveAndClose: ActionTypeEnum.SAVE_AND_CLOSE })
                }
                loading={
                  isSubmitting &&
                  actionType.saveAndClose === ActionTypeEnum.SAVE_AND_CLOSE
                }
              >
                {isSubmitting &&
                actionType.saveAndClose === ActionTypeEnum.SAVE_AND_CLOSE
                  ? "Save & Closing..."
                  : "Save & Close"}
              </Button>
            </Flex>

            {materialGoingToSite?.id && (
              <Flex justify="flex-end" className="mt-4">
                <CreatedByUserBadge
                  userName={
                    materialGoingToSite?.modifiedBy == null
                      ? materialGoingToSite?.createdBy
                      : materialGoingToSite?.lastModifiedBy
                  }
                  date={materialGoingToSite?.lastModifiedDate}
                  isUpdatedBadge={
                    materialGoingToSite.modifiedBy == null ? false : true
                  }
                />
              </Flex>
            )}
          </Form>
        </SectionLayout>
      )}
    </>
  );
}
