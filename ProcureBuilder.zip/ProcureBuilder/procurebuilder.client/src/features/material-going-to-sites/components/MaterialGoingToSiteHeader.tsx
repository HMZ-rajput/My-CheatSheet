import { Col, Row, Typography } from "antd";
import { memo } from "react";

const MaterialGoingToSiteHeader = memo(() => {
  const { Text } = Typography;
  return (
    <Row className="bg-slate-400" gutter={[48, 16]}>
      <Col xs={6}>
        <Text className="font-normal text-neutral-85">Sublocation</Text>
      </Col>
      <Col xs={6}>
        <Text className="font-normal text-neutral-85">Material</Text>
      </Col>
      {/* <Col xs={3}>
        <Text className="font-normal text-neutral-85">Samples</Text>
      </Col>
      <Col xs={3}>
        <Text className="font-normal text-neutral-85">Spares</Text>
      </Col>
      <Col xs={3}>
        <Text className="font-normal text-neutral-85">Regular</Text>
      </Col> */}
      <Col xs={6}>
        <Text className="font-normal text-neutral-85">Quantity</Text>
      </Col>
      <Col xs={5}>
        <Text className="font-normal text-neutral-85">Unit of Measurement</Text>
      </Col>
      <Col xs={1}></Col>
    </Row>
  );
});
export default MaterialGoingToSiteHeader;
