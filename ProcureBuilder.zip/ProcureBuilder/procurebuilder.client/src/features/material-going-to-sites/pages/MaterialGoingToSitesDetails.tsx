import MaterialTransferStatus from "@/src/components/common/MaterialTransferStatus";
import { useAppSelector } from "@/src/hooks/useAppSelector";
import { getMaterialTransferStatus } from "@/src/utils/helper";
import PageLayout from "@components/layout/PageLayout";
import { useLocation, useParams } from "react-router-dom";
import MaterialGoingToSitesDetailsForm from "../components/MaterialGoingToSitesDetailsForm";
import { getMaterialGoingToSiteById } from "@/src/store/slices/materialGoingToSiteSlice";
import { useEffect, useState } from "react";
import { MaterialGoingToSite } from "@/src/utils/types";
import { getMaterialGoingToSiteByIdAsync } from "@/src/apis/materialGoingToSiteApis";
import routePaths from "@/src/utils/routePaths";

export default function MaterialGoingToSitesDetailsPage() {
  const { materialGoingToSitesId } = useParams();
  const location = useLocation();

  const [materialGoingToSiteData, setMaterialGoingToSiteData] = useState<
    | (MaterialGoingToSite & { modifiedBy?: string; createdDate?: Date | null })
    | null
  >(null);

  const materialGoingToSite = useAppSelector((state) =>
    getMaterialGoingToSiteById(state, materialGoingToSitesId || "")
  );
  const { badgeType } = getMaterialTransferStatus(
    materialGoingToSite?.status || materialGoingToSiteData?.status || 0
  );

  useEffect(() => {
    if (!materialGoingToSite && materialGoingToSitesId) {
      const fetchGetMaterialTransferById = async () => {
        const response = await getMaterialGoingToSiteByIdAsync(
          materialGoingToSitesId || ""
        );

        if (response?.isSuccess) {
          setMaterialGoingToSiteData(response?.materialToSite);
        }
      };
      fetchGetMaterialTransferById();
    }
    if (location.pathname === routePaths.MATERIAL_GOING_TO_SITES_NEW) {
      setMaterialGoingToSiteData(null);
    }
  }, [materialGoingToSite, materialGoingToSitesId, location]);

  return (
    <>
      <PageLayout
        title={`${
          materialGoingToSite || materialGoingToSiteData ? "Edit" : "Create New"
        } Material Going to Site`}
        titleBarJustifyContent="flex-start"
        titleSibling={<MaterialTransferStatus badgeType={badgeType} />}
      >
        <MaterialGoingToSitesDetailsForm
          materialGoingToSite={materialGoingToSite || materialGoingToSiteData}
        />
      </PageLayout>
    </>
  );
}
