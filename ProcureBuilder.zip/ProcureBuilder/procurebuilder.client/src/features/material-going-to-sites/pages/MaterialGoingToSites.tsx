import CustomIcon from "@components/common/CustomIcon";
import PageLayout from "@components/layout/PageLayout";
import { getConsistentSpacing } from "@utils/theme-helpers";
import { Button } from "antd";
import MaterialGoingToSitesList from "../components/MaterialGoingToSitesList";
import routePaths from "@/src/utils/routePaths";
import { useNavigate } from "react-router-dom";

export default function MaterialGoingToSites() {
  const navigate = useNavigate();

  return (
    <>
      <PageLayout
        title="Material Going to Sites"
        titleSibling={
          <Button
            size="large"
            type="primary"
            icon={
              <CustomIcon
                type="plus"
                className="fill-white"
                width={parseInt(getConsistentSpacing(3))}
                height={parseInt(getConsistentSpacing(3))}
              />
            }
            onClick={() => navigate(routePaths.MATERIAL_GOING_TO_SITES_NEW)}
          >
            New Material Going To Site
          </Button>
        }
      >
        <MaterialGoingToSitesList hasPagination />
      </PageLayout>
    </>
  );
}
