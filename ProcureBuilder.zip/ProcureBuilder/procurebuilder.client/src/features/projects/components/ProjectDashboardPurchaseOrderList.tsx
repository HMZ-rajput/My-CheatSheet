import CustomIcon from "@/src/components/common/CustomIcon";
import useToken from "@hooks/useToken";
import { Divider, Flex } from "antd";
import PurchaseOrdersList from "../../purchase-orders/components/PurchaseOrdersList";
import { useParams } from "react-router-dom";

export default function ProjectDashboardPurchaseOrderListSection() {
  const { projectId } = useParams();
  const token = useToken();

  return (
    <Flex
      vertical
      style={{
        border: `1px solid ${token.colorBorder}`,
      }}
      className="w-full rounded-2xl p-6"
    >
      <Flex className="" align="center">
        <CustomIcon
          type="cart-gray-icon"
          className="mr-2"
          width={24}
          height={24}
        />
        <h3 className="font-medium !text-base m-0">Purchase Order Summary</h3>
      </Flex>
      <Divider className="!my-4" />

      <PurchaseOrdersList
        paramProjectId={projectId || ""}
        showProjectsFilter={false}
      />
    </Flex>
  );
}
