import CustomIcon from "@/src/components/common/CustomIcon";
import CustomTag from "@/src/components/common/CustomTag";
import HighlightedText from "@/src/components/common/HighlightedText";
import CustomTable, {
  defaultPageSizes,
} from "@/src/components/table/CustomTable";
import { useAppSelector } from "@/src/hooks/useAppSelector";
import { getProjectManagersState } from "@/src/store/slices/projectManagersSlice";
import { getProjectsState } from "@/src/store/slices/projectsSlice";
import { getTypesState } from "@/src/store/slices/typesSlice";
import { dateFormat, projectStatusOptionsWithAll } from "@/src/utils/constants";
import { ProjectStatusEnum, TagTypeEnum } from "@/src/utils/enums";
import { getFullNameInitials } from "@/src/utils/general-helpers";
import routePaths from "@/src/utils/routePaths";
import { getConsistentSpacing } from "@/src/utils/theme-helpers";
import SectionLayout from "@components/layout/SectionLayout";
import { Avatar, Button, TableProps, Typography } from "antd";
import dayjs from "dayjs";
import React, { useEffect, useMemo, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";

import { getAllProjects } from "@/src/apis/projectApis";
import { getAllProjectTypes } from "@/src/apis/projectTypeApis";
import CustomTableFilters, {
  CustomFilterDataType,
  CustomFiltersType,
} from "@/src/components/table/CustomTableFilters";
import { useAppDispatch } from "@/src/hooks/useAppDispatch";
import { useDebouncedCallback } from "@/src/hooks/useDebouncedCallback";
import { allProjectStatusOption } from "@/src/utils/constants";
import { Project } from "@/src/utils/types";
import HighlightedProjectTypeName from "./HighlightedProjectTypeName";

import useAuthorization from "@/src/hooks/useAuthorization";
import { useRandomColor } from "@/src/hooks/useRandomColor";
import { EyeOutlined } from "@ant-design/icons";
import { useReports } from "../../reports/contexts/ReportsProvider";
import useSyncFilters from "@/src/hooks/useSyncFilters";

type ProjectsListProps = {
  exportButtonEl?: React.ReactNode | null;

  setReportStats?:
    | null
    | ((
        totalProjectsCount?: number,
        totalContractsPrice?: number,
        totalOpenProjects?: number,
        totalClosedProjects?: number
      ) => void);
};

export default function ProjectsList({
  exportButtonEl = null,
  setReportStats = null,
}: ProjectsListProps) {
  const { filterValues } = useReports();

  const isInsideReports = useMemo(
    () => Boolean(exportButtonEl),
    [exportButtonEl]
  );
  const [searchTerm, setSearchTerm] = useState("");
  const [hasSearched, setHasSearched] = useState(false);
  const { searchParams } = useSyncFilters();
  const [previousSearchTerm, setPreviousSearchTerm] = useState(
    searchParams.get("searchTerm")
  );
  const [lastSearchTimestamp, setLastSearchTimestamp] = useState(0);

  const navigate = useNavigate();
  const randomColor = useRandomColor();
  const dispatch = useAppDispatch();
  const { isFieldsCraftAuthorized } = useAuthorization();
  const {
    projectsData,
    isLoading,
    totalCount,
    currentPage: projectsCurrentPage,
    pageSize: projectsPageSize,
  } = useAppSelector(getProjectsState);

  const { typesData: typesData } = useAppSelector(getTypesState);
  const { managersData: projectManagersData } = useAppSelector(
    getProjectManagersState
  );

  const [page, setPage] = useState<number>(projectsCurrentPage);
  const [pageSize, setPageSize] = useState(
    !isInsideReports && !defaultPageSizes.includes(projectsPageSize)
      ? 10
      : projectsPageSize
  );
  const isFirstCallComplete = useRef(false);
  // const [isFirstCall, setIsFirstCall] = useState(false);

  const memoizedTypeOptions = useMemo(() => {
    return [
      {
        value: "",
        label: "All Types",
      },
      ...(typesData?.map((f) => ({
        value: f?.id,
        label: f?.name,
      })) || []),
    ];
  }, [typesData]);

  const [filters, setFilters] = useState<CustomFiltersType>({
    status: {
      value: allProjectStatusOption?.value || 0,
      options: projectStatusOptionsWithAll,
      className: "min-w-28",
      dataType: CustomFilterDataType.NUM,
    },
    type: {
      value: memoizedTypeOptions[0]?.value || "",
      options: memoizedTypeOptions,
      className: "min-w-32",
      dataType: CustomFilterDataType.STR,
    },
  });

  useEffect(() => {
    dispatch(getAllProjectTypes());
  }, []);

  useEffect(() => {
    // Only update filters if the options actually change
    setFilters((prevFilters) => {
      const currentOptions = prevFilters.type.options;
      const newOptions = memoizedTypeOptions;

      // Check if options are different (by comparing their length or individual items)
      const optionsChanged =
        currentOptions.length !== newOptions.length ||
        currentOptions.some(
          (option, index) => option.value !== newOptions[index]?.value
        );

      // If options are the same, return the previous filters to avoid unnecessary state update
      if (!optionsChanged) {
        return prevFilters;
      }

      // If options have changed, update the filters
      return {
        ...prevFilters,
        type: {
          ...prevFilters.type,
          options: newOptions,
        },
      };
    });
  }, [memoizedTypeOptions]);

  // useEffect(() => {
  //   setFilters((prevFilters) => ({
  //     ...prevFilters,
  //     type: { ...prevFilters.type, options: typeOptions },
  //   }));
  // }, [typeOptions]);

  const navigateToEditPage = (data: Project) => {
    const path = `${routePaths.PROJECTS_EDIT_BY_ID}/${data?.id}`;

    if (isInsideReports || new URLSearchParams(location.search).size > 0) {
      navigate(path, {
        state: {
          previousPath: `${location.pathname}${location.search}`,
        },
      });
    } else {
      navigate(path);
    }
  };

  const columns: TableProps<Project>["columns"] = [
    {
      title: "Project Name",
      dataIndex: "Name",
      key: "Name",
      sorter: (a, b) => a.name?.localeCompare(b.name),
      render: (_, record) => (
        <Typography.Title
          level={5}
          style={{ fontSize: getConsistentSpacing(1.75), margin: 0 }}
        >
          <HighlightedText text={record.name} searchTerm={searchTerm} />
        </Typography.Title>
      ),
    },
    {
      title: "Type",
      dataIndex: "projectTypeId",
      key: "projectTypeId",
      sorter: (a, b) => {
        const typeA =
          typesData?.find((f) => f?.id === a?.projectTypeId)?.name || "";
        const typeB =
          typesData?.find((f) => f?.id === b?.projectTypeId)?.name || "";
        return typeA.localeCompare(typeB);
      },
      render: (projectTypeId) => (
        <HighlightedProjectTypeName
          searchTerm={searchTerm}
          projectTypeId={projectTypeId}
        />
      ),
    },
    {
      title: "Customer",
      dataIndex: "Customer",
      key: "Customer",
      sorter: (a, b) => {
        return `${a.customer?.firstName} ${a?.customer?.lastName}`.localeCompare(
          `${b.customer?.firstName} ${b?.customer?.lastName}`
        );
      },
      render: (_, record) => {
        const customerName =
          record?.customer?.firstName || record?.customer?.lastName
            ? `${record?.customer?.firstName || ""} ${
                record?.customer?.lastName || ""
              }`
            : "N/A";
        return <HighlightedText text={customerName} searchTerm={searchTerm} />;
      },
    },
    {
      title: "Projected Start",
      dataIndex: "ProjectedStart",
      key: "ProjectedStart",
      sorter: (a, b) =>
        dayjs(a.projectedStartDate).unix() - dayjs(b.projectedStartDate).unix(),
      render: (_, record) =>
        dayjs(record.projectedStartDate).format(dateFormat),
    },
    {
      title: "Projected Completion",
      dataIndex: "ProjectedCompletion",
      key: "ProjectedCompletion",
      sorter: (a, b) =>
        dayjs(a.projectedCompletionDate).unix() -
        dayjs(b.projectedCompletionDate).unix(),
      render: (_, record) =>
        dayjs(record.projectedCompletionDate).format(dateFormat),
    },
    {
      title: "Status",
      dataIndex: "ProjectStatus",
      key: "ProjectStatus",
      sorter: (a, b) => a.status - b.status,
      render: (_, record) => (
        <CustomTag
          isWide
          type={
            record.status === ProjectStatusEnum.OPEN
              ? TagTypeEnum.GREEN
              : TagTypeEnum.ORANGE
          }
          status={record.status}
        />
      ),
    },
    {
      title: "Contract Price",
      dataIndex: "ContractPrice",
      key: "ContractPrice",
      sorter: (a, b) => (a.contractPrice || 0) - (b.contractPrice || 0),
      render: (_, record) => (
        <HighlightedText
          text={`$${record.contractPrice?.toLocaleString()}`}
          searchTerm={searchTerm}
        />
      ),
    },
    {
      title: "Project Managers",
      dataIndex: "ProjectManagers",
      key: "ProjectManagers",
      sorter: (a, b) => {
        const managerA = projectManagersData?.find(
          (f) => f?.id === (a.projectManagersIds || [])[0]
        );
        const managerB = projectManagersData?.find(
          (f) => f?.id === (b.projectManagersIds || [])[0]
        );
        const nameA = managerA?.fullName || "";
        const nameB = managerB?.fullName || "";
        return nameA.localeCompare(nameB);
      },
      render: (_, record) => (
        <Avatar.Group>
          {record.projectManagersIds
            ?.filter((f) => f)
            ?.map((m) => (
              <Avatar key={m} style={{ backgroundColor: randomColor }}>
                {getFullNameInitials(
                  projectManagersData?.find((f) => f.id === m)?.fullName || ""
                )}
              </Avatar>
            ))}
        </Avatar.Group>
      ),
    },
    {
      title: "",
      dataIndex: "",
      key: "",
      render: (_, record) =>
        !isInsideReports && (
          <Button
            shape="circle"
            className="hover:!fill-primary"
            icon={
              isFieldsCraftAuthorized() ? (
                <EyeOutlined />
              ) : (
                <CustomIcon type="edit" />
              )
            }
            onClick={() => navigateToEditPage(record)}
          />
        ),
    },
  ];

  const handleGetResults = useDebouncedCallback(getResults, 100);

  async function getResults(pageNumber?: number) {
    const status =
      filters.status?.value !== allProjectStatusOption?.value
        ? (filters?.status?.value as number)
        : undefined;

    const type =
      filters.type?.value !== memoizedTypeOptions[0]?.value
        ? filters?.type?.value?.toString()
        : undefined;

    const reportFilters = isInsideReports ? filterValues : {};

    const res = await dispatch(
      getAllProjects({
        isForReport: isInsideReports,
        pageNumber: pageNumber || page,
        pageSize,
        search: searchTerm || undefined,
        status,
        type: reportFilters?.projectTypeId || type,
        ...{
          projectManagerId: reportFilters?.projectManagerId || undefined,
          contractPriceFrom: reportFilters?.contractPriceStart || undefined,
          contractPriceTo: reportFilters?.contractPriceEnd || undefined,
          projectedStartDateFrom:
            reportFilters?.projectedStart?.[0] || undefined,
          projectedStartDateTo: reportFilters?.projectedStart?.[1] || undefined,
          projectedCompletionDateFrom:
            reportFilters?.projectedCompletion?.[0] || undefined,
          projectedCompletionDateTo:
            reportFilters?.projectedCompletion?.[1] || undefined,
        },
      })
    ).unwrap();

    if (typeof setReportStats === "function") {
      setReportStats(
        res?.totalCount,
        res?.totalContractsPrice,
        res?.totalOpenProjects,
        res?.totalClosedProjects
      );
    }
  }

  function resetPaginationAndGetFirstPageResults() {
    if (isFirstCallComplete?.current === true) {
      if (filters) {
        setPage(1);
      }

      handleGetResults(1);
    } else {
      handleGetResults();
    }
  }

  useEffect(() => {
    if (!hasSearched) return;
    const timer = setTimeout(() => {
      if (searchTerm === "" && previousSearchTerm !== "") {
        resetPaginationAndGetFirstPageResults();
        setPreviousSearchTerm(searchTerm);
      }
    }, 500);

    return () => {
      clearTimeout(timer);
    };
  }, [searchTerm, hasSearched, previousSearchTerm]);

  const handleSearch = () => {
    if (searchTerm !== previousSearchTerm) {
      setHasSearched(true);
      resetPaginationAndGetFirstPageResults();
      setPreviousSearchTerm(searchTerm);
    }
  };

  useEffect(() => {
    setLastSearchTimestamp(Date.now());
  }, [previousSearchTerm]);

  useEffect(() => {
    resetPaginationAndGetFirstPageResults();
  }, [filters, filterValues]);

  useEffect(() => {
    if (
      !isFirstCallComplete?.current ||
      projectsCurrentPage !== page ||
      projectsPageSize !== pageSize
    ) {
      handleGetResults();

      if (!isFirstCallComplete?.current) {
        setTimeout(() => {
          isFirstCallComplete.current = true;
        }, 1000);
      }
    }
  }, [page, pageSize]);

  return (
    <>
      <SectionLayout isHidden={isInsideReports}>
        <CustomTable
          isInsideReports={isInsideReports}
          data={projectsData || []}
          columns={columns || []}
          searchTerm={searchTerm}
          setSearchTerm={setSearchTerm}
          handleSearch={handleSearch}
          isLoading={isLoading}
          totalCount={totalCount}
          page={page}
          hasCursorPointer={isInsideReports}
          setPage={setPage}
          pageSize={pageSize}
          setPageSize={setPageSize}
          tableFilters={filters}
          reportFilterForParamsUseOnly={
            isInsideReports ? filterValues : undefined
          }
          setTableFilters={!isInsideReports ? setFilters : undefined}
          filterElements={
            isInsideReports ? null : (
              <CustomTableFilters filters={filters} setFilters={setFilters} />
            )
          }
          onRowClick={
            isInsideReports ? (co) => navigateToEditPage(co) : undefined
          }
          hasPagination={true}
          exportButtonEl={exportButtonEl}
          lastSearchTimestamp={lastSearchTimestamp}
        />
      </SectionLayout>
    </>
  );
}
