import { createProjectType, UpdateProjectType } from "@/src/apis/projectApis";
import { useAppDispatch } from "@/src/hooks/useAppDispatch";
import { useAppSelector } from "@/src/hooks/useAppSelector";
import { getTypesState } from "@/src/store/slices/typesSlice";
import { getUserFullName } from "@/src/store/slices/userSlice";
import { Dispatch, SetStateAction, useEffect } from "react";
import CustomModal from "@/src/components/common/CustomModal";
import CustomFormLabel from "@/src/components/common/CustomFormLabel";
import { useFormik } from "formik";
import * as Yup from "yup";
import CustomAlert from "@/src/components/common/CustomAlert";
import { Input } from "antd";
import { resetState } from "@/src/store/slices/typesSlice";

type ProjectTypeModalProps = {
  isOpen: boolean;
  setIsOpen: Dispatch<SetStateAction<boolean>>;
  setProjectType: Dispatch<SetStateAction<string>>;
  editProjectType: { label: string; value: string | null } | null;
  setEditProjectType: Dispatch<
    SetStateAction<{ label: string; value: string | null } | null>
  >;
};

const ProjectTypeModal = ({
  setProjectType,
  ...props
}: ProjectTypeModalProps) => {
  const userFullName = useAppSelector(getUserFullName);
  const { isLoading, isSuccess, reqError, resError } =
    useAppSelector(getTypesState);

  const dispatch = useAppDispatch();

  const { setIsOpen, isOpen, editProjectType, setEditProjectType } = props;

  const formik = useFormik({
    initialValues: {
      name: "",
      id: "",
    },
    validationSchema: Yup.object({
      name: Yup.string().required("Please enter the Project Type Name!"),
      id: Yup.string(),
    }),
    onSubmit: async (values) => {
      try {
        if (editProjectType?.value) {
          const res = await dispatch(
            UpdateProjectType({
              name: values.name,
              id: values.id,
              modifiedBy: userFullName,
            })
          ).unwrap();

          if (res.isSuccess) {
            setProjectType(res?.projectType?.id || "");
          }
        } else {
          const res = await dispatch(
            createProjectType({
              name: values.name,
              modifiedBy: userFullName,
            })
          ).unwrap();

          if (res.isSuccess) {
            setProjectType(res?.projectType?.id || "");
          }
        }
      } catch (err) {
        console.log(err);
      }
    },
  });

  useEffect(() => {
    if (isSuccess) {
      setIsOpen(false);
      formik.resetForm();
    }
  }, [isSuccess, setIsOpen, formik]);

  useEffect(() => {
    dispatch(resetState());
    formik.resetForm();
    if (!isOpen) {
      setEditProjectType(null);
    }
  }, [isOpen]);

  useEffect(() => {
    if (reqError || resError) dispatch(resetState());
  }, [formik.values]);

  useEffect(() => {
    if (editProjectType?.value) {
      formik.setFieldValue("name", editProjectType.label);
      formik.setFieldValue("id", editProjectType.value);
    }
  }, [editProjectType]);

  return (
    <CustomModal
      width={550}
      isLoading={isLoading}
      title={
        editProjectType?.value ? "Update Project Type" : "Add New Project Type"
      }
      primaryButtonText={editProjectType?.value ? "Update" : "Add"}
      primaryButtonLoadingText={
        editProjectType?.value ? "Updating..." : "Adding..."
      }
      isOpen={isOpen}
      primaryButtonAction={formik.handleSubmit}
      cancelButtonAction={() => setIsOpen(false)}
    >
      <form onSubmit={formik.handleSubmit}>
        <div>
          <label>
            <CustomFormLabel text="Project Type Name" />
          </label>
          <Input
            name="name"
            value={formik?.values?.name}
            onChange={formik.handleChange}
            onBlur={formik.handleBlur}
          />
          {formik.touched.name && formik.errors.name ? (
            <div className="text-error">{formik.errors.name}</div>
          ) : null}
        </div>

        {reqError ||
          (resError && (
            <CustomAlert message={reqError || resError || ""} type={"error"} />
          ))}
      </form>
    </CustomModal>
  );
};

export default ProjectTypeModal;
