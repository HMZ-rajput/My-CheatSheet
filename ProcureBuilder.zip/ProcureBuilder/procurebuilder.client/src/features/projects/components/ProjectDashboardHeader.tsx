import CustomTag from "@/src/components/common/CustomTag";
import useAuthorization from "@/src/hooks/useAuthorization";
import { ProjectStatusEnum, TagTypeEnum } from "@/src/utils/enums";
import routePaths from "@/src/utils/routePaths";
import { ProjectDashboardDetailsType } from "@/src/utils/types";
import { EditOutlined, EyeOutlined } from "@ant-design/icons";
import useToken from "@hooks/useToken";
import { Button, Flex, Typography } from "antd";
import { useNavigate } from "react-router-dom";

type ProjectHeaderProps = {
  projectDetails: ProjectDashboardDetailsType | null;
};
export default function ProjectDashboardHeader({
  projectDetails,
}: ProjectHeaderProps) {
  const token = useToken();
  const navigate = useNavigate();
  const { isFieldsCraftAuthorized } = useAuthorization();

  return (
    <Flex
      style={{
        border: `1px solid ${token.colorBorder}`,
      }}
      className="w-full rounded-2xl px-6 py-4 items-center"
    >
      <Typography.Title
        className="font-medium !text-xl pr-6"
        level={3}
        style={{ margin: 0 }}
      >
        {projectDetails?.name}
      </Typography.Title>

      <CustomTag
        type={
          projectDetails?.status === ProjectStatusEnum.OPEN
            ? TagTypeEnum.GREEN
            : TagTypeEnum.ORANGE
        }
        status={
          projectDetails?.status != undefined
            ? projectDetails?.status
            : ProjectStatusEnum.OPEN
        }
      />
      <Button
        className="flex ml-auto gap-1 px-3 py-2 rounded-lg"
        icon={
          isFieldsCraftAuthorized() ? (
            <EyeOutlined />
          ) : (
            <EditOutlined className="w-5 h-5" />
          )
        }
        onClick={() =>
          navigate(`${routePaths.PROJECTS_EDIT_BY_ID}/${projectDetails?.id}`)
        }
      >
        {isFieldsCraftAuthorized() ? "View" : "Edit"}
      </Button>
    </Flex>
  );
}
