import HighlightedText from "@/src/components/common/HighlightedText";
import { useAppSelector } from "@/src/hooks/useAppSelector";
import { getTypeNameById } from "@/src/store/slices/typesSlice";

type HighlightedProjectTypeName = {
    projectTypeId: string;
    searchTerm: string;
}
export default function HighlightedProjectTypeName(props: HighlightedProjectTypeName) {
    const typeName = useAppSelector(state => getTypeNameById(state, props.projectTypeId))

    return typeName ? <HighlightedText searchTerm={props.searchTerm} text={typeName || ""} /> : "N/A"
}