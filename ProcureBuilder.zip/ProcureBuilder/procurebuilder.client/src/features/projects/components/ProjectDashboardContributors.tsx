import CustomIcon from "@/src/components/common/CustomIcon";
import { useRandomColor } from "@/src/hooks/useRandomColor";
import { getFullNameInitials } from "@/src/utils/general-helpers";
import {
  ProjectDashboardManagersType,
  ProjectDashboardOwnerType,
} from "@/src/utils/types";
import useToken from "@hooks/useToken";
import { Avatar, Flex } from "antd";

type ProjectDashboardContributorsprops = {
  projectOwner: ProjectDashboardOwnerType | null;
  projectManagers: ProjectDashboardManagersType[] | [];
};

export default function ProjectDashboardContributors({
  projectOwner,
  projectManagers,
}: ProjectDashboardContributorsprops) {
  const token = useToken();
  const randomColor = useRandomColor();
  return (
    <Flex vertical className="gap-4">
      {/* Owner Section */}
      {projectOwner && (
        <Flex
          vertical
          style={{
            border: `1px solid ${token.colorBorder}`,
          }}
          className="w-full rounded-2xl px-4 py-4"
        >
          <Flex className="gap-6" align="center">
            <CustomIcon
              type="owner-icon"
              className="mr-3"
              width={40}
              height={50}
            />

            <Flex vertical>
              <h3 className="font-medium !text-base m-0">Owner</h3>
              <Flex align="center" className="gap-2">
                <Avatar style={{ backgroundColor: randomColor }}>
                  {projectOwner
                    ? getFullNameInitials(projectOwner.name)
                    : "N/A"}
                </Avatar>
                <span className="font-normal !text-sm m-0">
                  {projectOwner
                    ? projectOwner.name
                    : "Owner data is not available"}
                </span>
              </Flex>
            </Flex>
          </Flex>
        </Flex>
      )}

      <Flex
        vertical
        style={{
          border: `1px solid ${token.colorBorder}`,
        }}
        className="w-full rounded-2xl px-4 py-4  "
      >
        <Flex className="gap-2 overflow-x-auto" align="start">
          <CustomIcon
            type="project-manager-icon"
            className="mr-3"
            width={60}
            height={60}
          />
          <Flex vertical>
            <h3 className="font-medium !text-base m-0">
              Project Manager{projectManagers.length > 1 ? "s" : ""}
            </h3>
            {projectManagers?.length > 0 ? (
              <div className="flex flex-col gap-1">
                {projectManagers.map((manager) => (
                  <div
                    key={manager.id}
                    className="flex shrink-0 items-center gap-2"
                  >
                    <Avatar style={{ backgroundColor: randomColor }}>
                      {getFullNameInitials(manager.name)}
                    </Avatar>
                    <span className="font-normal !text-sm m-0">
                      {manager.name}
                    </span>
                  </div>
                ))}
              </div>
            ) : (
              <span className="font-normal !text-sm m-0">
                Project manager data is not available
              </span>
            )}
          </Flex>
        </Flex>
      </Flex>
    </Flex>
  );
}
