import CustomIcon from "@/src/components/common/CustomIcon";
import { dateFormat } from "@/src/utils/constants";
import { ProjectDashboardDetailsType } from "@/src/utils/types";
import useToken from "@hooks/useToken";
import { Divider, Flex } from "antd";
import dayjs from "dayjs";

type ProjectDashboardDetailsProps = {
  projectDashboardDetails: ProjectDashboardDetailsType | null;
};

export default function ProjectDashboardDetails({
  projectDashboardDetails,
}: ProjectDashboardDetailsProps) {
  const token = useToken();

  const formatDate = (dateString: string | null) => {
    if (!dateString) return "N/A";
    return dayjs(dateString).format(dateFormat);
  };

  return (
    <Flex
      vertical
      style={{
        border: `1px solid ${token.colorBorder}`,
      }}
      className="w-full rounded-2xl px-4 py-4 flex flex-grow"
    >
      <Flex className="" align="center">
        <CustomIcon
          type="project-details-icon"
          className="mr-3 fill-[#CFCCFF]"
          width={32}
          height={32}
        />
        <h3 className="font-medium !text-base m-0">Project Details</h3>
      </Flex>

      <Divider className="!my-4" />

      <Flex className="gap-4 justify-between">
        <Flex vertical className="gap-3 px-2 items-center">
          <span className="font-semibold !text-sm m-0 !text-neutral-85">
            Projected Start Date
          </span>
          <span className="font-normal !text-sm m-0 !text-gray-5 mr-auto flex flex-row gap-2">
            <CustomIcon type="calendar-green-icon" />{" "}
            {formatDate(projectDashboardDetails?.startDate || "")}
          </span>
        </Flex>

        <Flex vertical className="gap-3 px-2 items-center">
          <span className="font-semibold !text-sm m-0 !text-neutral-85">
            Projected Completion Date
          </span>
          <span className="font-normal !text-sm m-0 !text-gray-5 mr-auto flex flex-row gap-2">
            <CustomIcon type="calendar-green-icon" />{" "}
            {formatDate(projectDashboardDetails?.completionDate || "")}
          </span>
        </Flex>

        <Flex vertical className="gap-3 px-2 items-center">
          <span className="font-semibold !text-sm m-0 !text-neutral-85">
            Actual Start Date
          </span>
          <span className="font-normal !text-sm m-0 !text-gray-5 mr-auto flex flex-row gap-2">
            <CustomIcon type="calendar-green-icon" />{" "}
            {formatDate(projectDashboardDetails?.actualStartDate || "")}
          </span>
        </Flex>

        <Flex vertical className="gap-3 px-2 items-center">
          <span className="font-semibold !text-sm m-0 !text-neutral-85">
            Actual Completion Date
          </span>
          <span className="font-normal !text-sm m-0 !text-gray-5 mr-auto flex flex-row gap-2">
            <CustomIcon type="calendar-green-icon" />{" "}
            {formatDate(projectDashboardDetails?.actualCompletionDate || "")}
          </span>
        </Flex>

        <Flex vertical className="gap-3 px-2 items-center">
          <span className="font-semibold !text-sm m-0 !text-neutral-85">
            Contract Price
          </span>
          <span className="font-normal !text-sm m-0 !text-gray-5 mr-auto flex flex-row gap-2">
            <CustomIcon type="dollar-icon" />{" "}
            {projectDashboardDetails?.contractPrice
              ? `$${projectDashboardDetails.contractPrice.toLocaleString()}`
              : "N/A"}
          </span>
        </Flex>
      </Flex>
    </Flex>
  );
}
