import CustomIcon from "@/src/components/common/CustomIcon";
import { useAppSelector } from "@/src/hooks/useAppSelector";
import { getDashboardState } from "@/src/store/slices/dashboardSlice";
import useToken from "@hooks/useToken";
import { Divider, Flex } from "antd";
import { useState } from "react";
import ReactApexChart from "react-apexcharts";

export default function ProjectMaterialComparisonSection() {
  const token = useToken();
  const { dashboardDataByProjectId } = useAppSelector(getDashboardState);
  const [chartState] = useState({
    series: [
      dashboardDataByProjectId?.materials?.materialsReceivedPerc || 0,
      dashboardDataByProjectId?.materials?.materialsExpectedPerc || 0,
    ],
    options: {
      chart: {
        type: "donut" as "donut",
        offsetY: 10,
      },
      plotOptions: {
        pie: {
          startAngle: -90,
          endAngle: 90,
          donut: {
            size: "80%",
            labels: {
              show: true,
              name: {
                show: false,
              },
              value: {
                show: true,
                fontSize: "24px",
                fontWeight: "bold",
                color: "#0A0D14",
                formatter: function () {
                  const highPercentage = Math.max(...chartState.series);
                  return `${highPercentage}%`;
                },
              },
              total: {
                show: true,
                label: "",
                formatter: function () {
                  const highPercentage = Math.max(...chartState.series);
                  return `${highPercentage}%`;
                },
              },
            },
          },
        },
      },
      colors: ["#4DA167", "#FC8DB7"],
      grid: {
        padding: {
          bottom: -140,
        },
      },
      dataLabels: {
        enabled: false,
      },
      responsive: [
        {
          breakpoint: 480,
          options: {
            chart: {
              width: 332,
              height: 120,
            },
            legend: {
              show: false,
            },
          },
        },
      ],
      legend: {
        show: false,
      },
      labels: ["Materials Received", "Materials Expected"],
    },
  });

  const materialsReceivedPercentage = chartState.series[0];
  const materialsExpectedPercentage = chartState.series[1];

  return (
    <Flex
      vertical
      style={{
        border: `1px solid ${token.colorBorder}`,
      }}
      className="w-full rounded-2xl px-4 py-4"
    >
      <Flex className="w-full gap-2" align="center">
        <CustomIcon type="pie-chart-icon" width={24} height={24} />
        <h3 className="font-medium !text-base">Materials</h3>
      </Flex>

      <Divider className="" />

      <div id="chart" className="w-full align-middle items-center">
        <ReactApexChart
          options={chartState.options}
          series={chartState.series}
          type="donut"
        />
      </div>

      <Divider className="" />

      <Flex className="" vertical>
        <Flex className="flex justify-between mb-2">
          <span className="font-medium text-sm">Materials Received</span>
          <span className="font-medium text-sm">
            {dashboardDataByProjectId?.materials?.materialsReceivedPerc || 0}%
          </span>
        </Flex>
        <Flex className="relative w-full h-2 bg-gray-4 rounded-lg mb-4">
          <div
            className="absolute top-0 left-0 h-full rounded-lg"
            style={{
              width: `${materialsReceivedPercentage}%`,
              backgroundColor: "#4DA167",
            }}
          ></div>
          <div
            className="absolute top-0 left-0 h-full rounded-lg bg-gray-300"
            style={{
              width: `${100 - materialsReceivedPercentage}%`,
            }}
          ></div>
        </Flex>

        <Flex className="flex justify-between mb-2">
          <span className="font-medium text-sm">Materials Expected</span>
          <span className="font-medium text-sm">
            {dashboardDataByProjectId?.materials?.materialsExpectedPerc || 0}%
          </span>
        </Flex>
        <Flex className="relative w-full h-2 bg-gray-4 rounded-lg">
          <div
            className="absolute top-0 left-0 h-full rounded-lg"
            style={{
              width: `${materialsExpectedPercentage}%`,
              backgroundColor: "#FC8DB7",
            }}
          ></div>
          <div
            className="absolute top-0 left-0 h-full rounded-lg bg-gray-300"
            style={{
              width: `${100 - materialsExpectedPercentage}%`,
            }}
          ></div>
        </Flex>
      </Flex>
    </Flex>
  );
}
