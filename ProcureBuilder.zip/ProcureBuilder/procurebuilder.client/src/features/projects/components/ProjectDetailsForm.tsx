import { getLocationListForSideBar } from "@/src/apis/locationApis";
import { getAllProjectManagers } from "@/src/apis/projectManagersApis";
import { getAllProjectTypes } from "@/src/apis/projectTypeApis";
import CreatedByUserBadge from "@/src/components/common/CreatedByUserBadge";
import CustomAlert from "@/src/components/common/CustomAlert";
import CustomIcon from "@/src/components/common/CustomIcon";
import CustomFormRow from "@/src/components/form/CustomFormRow";
import useAuthorization from "@/src/hooks/useAuthorization";
import {
  createProjectDraft,
  getProjectsState,
  resetState,
} from "@/src/store/slices/projectsSlice";
import { getUserFullName } from "@/src/store/slices/userSlice";
import { ProjectStatusEnum } from "@/src/utils/enums";
import { setProjectName } from "@/src/utils/general-helpers";
import { convertToLocaleString } from "@/src/utils/helper";
import { Project } from "@/src/utils/types";
import { PlusOutlined } from "@ant-design/icons";
import {
  createProject,
  deleteProjectById,
  editProjectById,
  getProjectById,
  getSummarizedProjectsList,
} from "@apis/projectApis";
import CustomFormLabel from "@components/common/CustomFormLabel";
import SectionLayout from "@components/layout/SectionLayout";
import { yupResolver } from "@hookform/resolvers/yup";
import { useAppDispatch } from "@hooks/useAppDispatch";
import { useAppSelector } from "@hooks/useAppSelector";
import { getProjectManagersState } from "@store/slices/projectManagersSlice";
import { getTypesState } from "@store/slices/typesSlice";
import { dateFormat, projectStatusOptions } from "@utils/constants";
import routePaths, { routePathsWithParams } from "@utils/routePaths";
import {
  Button,
  Col,
  DatePicker,
  Divider,
  Flex,
  Form,
  Input,
  InputNumber,
  Select,
  Space,
  Typography,
} from "antd";
import dayjs, { Dayjs } from "dayjs";
import { useEffect, useMemo, useState } from "react";
import { Controller, Resolver, useForm } from "react-hook-form";
import { useLocation, useNavigate, useParams } from "react-router-dom";
import * as Yup from "yup";
import ProjectTypeModal from "./ProjectTypeModal";

type ProjectDetailsFormProps = {
  project?: Project | null;
};
type FieldType = {
  projectName: string | null;
  projectCode: string | null;
  projectType?: string | null;

  projectedStart?: Dayjs | null;
  projectedCompletion?: Dayjs | null;
  actualStart?: Dayjs | null;
  actualCompletion?: Dayjs | null;

  projectNotes?: string;

  projectStatus: ProjectStatusEnum;
  contractPrice?: number;
  projectManagers?: string[];
};

export default function ProjectDetailsForm({
  project,
}: ProjectDetailsFormProps) {
  const location = useLocation();
  const { successMessage, resError } = useAppSelector(getProjectsState);
  const { isFieldsCraftAuthorized } = useAuthorization();
  const [actionType, setActionType] = useState<"save" | "saveAndClose" | "">(
    ""
  );

  const [isOpen, setIsOpen] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  const [hasMadeApiCall, setHasMadeApiCall] = useState(false);
  const [projectType, setProjectType] = useState("");
  const [editProjectType, setEditProjectType] = useState<{
    label: string;
    value: string | null;
  } | null>(null);

  const params = useParams();
  const userFullName = useAppSelector(getUserFullName);

  const dispatch = useAppDispatch();
  const navigate = useNavigate();

  const { typesData: typesData } = useAppSelector(getTypesState);

  const memoizedTypesOptions = useMemo(() => {
    return [
      {
        value: "",
        label: "Select Project Type",
      },
      ...(typesData?.map((pm) => ({
        value: pm?.id,
        label: pm?.name,
      })) || []),
    ];
  }, [typesData]);

  const { managersData: projectManagersData } = useAppSelector(
    getProjectManagersState
  );
  const memoizedProjectManagersOptions = useMemo(() => {
    return (
      projectManagersData?.map((pm) => ({
        value: pm.id,
        label: pm.fullName,
      })) || []
    );
  }, [projectManagersData]);

  const validationSchema = Yup.object().shape({
    projectName: Yup.string().required("Project Name is required."),
    projectCode: Yup.string().required("Project Code is required."),
    projectManagers: Yup.array()
      .of(Yup.string().required())
      .min(1, "At least one project manager must be selected.")
      .required("At least one project manager must be selected."),

    projectedStart: Yup.string().required("Project Start Date is required"),
    projectedCompletion: Yup.string()
      .required("Project Completion Date is required")
      .test(
        "is-after-start",
        "Completion date must be after start date",
        function (value) {
          const { projectedStart } = this.parent;
          return projectedStart && value
            ? new Date(value) >= new Date(projectedStart)
            : true;
        }
      ),
  });

  const {
    control,
    handleSubmit,
    setValue,
    reset,
    formState: { isSubmitting },
  } = useForm<FieldType>({
    defaultValues: {
      projectName: project?.name || "",
      projectCode: project?.code || "",

      projectType: project?.projectTypeId || null,

      projectedStart: project?.projectedStartDate
        ? dayjs(project?.projectedStartDate)
        : "",
      projectedCompletion: project?.projectedCompletionDate
        ? dayjs(project?.projectedCompletionDate)
        : "",
      actualStart: project?.actualStartDate
        ? dayjs(project?.actualStartDate)
        : "",
      actualCompletion: project?.actualCompletionDate
        ? dayjs(project?.actualCompletionDate)
        : "",
      projectNotes: project?.notes || "",
      projectStatus: project?.status || ProjectStatusEnum.OPEN,
      contractPrice: project?.contractPrice || 0.0,
      projectManagers: project?.projectManagersIds || [],
    },
    resolver: yupResolver(validationSchema) as unknown as Resolver<FieldType>,
  });

  const onSubmit = async (values: FieldType) => {
    setHasMadeApiCall(true);
    const payload = {
      name: values.projectName || "",
      code: values.projectCode || "",
      notes: values.projectNotes || "",
      status: values.projectStatus,
      createdBy: userFullName,
      contractPrice: values.contractPrice,
      projectTypeId: values.projectType ? values.projectType : null,
      projectManagersIds: values.projectManagers,
      projectedStartDate: values?.projectedStart
        ? dayjs(values?.projectedStart)
        : null,
      projectedCompletionDate: values?.projectedCompletion
        ? dayjs(values?.projectedCompletion)
        : null,
      actualStartDate: values?.actualStart ? dayjs(values?.actualStart) : null,
      actualCompletionDate: values.actualCompletion
        ? dayjs(values?.actualCompletion)
        : null,
    };

    // console.log("values", values);
    try {
      if (project?.id) {
        //@ts-ignore
        await dispatch(editProjectById({ ...project, ...payload }));

        if (actionType === "saveAndClose") {
          handleClose();
        }
      } else {
        //@ts-ignore
        const response = await dispatch(createProject(payload)).unwrap();
        if (response.isSuccess) {
          if (actionType === "saveAndClose") {
            handleClose();
            return;
          }
          navigate(
            `${routePaths.PROJECTS_EDIT_BY_ID}/${response?.project?.id}`
          );
        }
      }
    } catch (error) {
      console.log(error);
    } finally {
      dispatch(getSummarizedProjectsList());
    }
  };

  const handleClose = () => {
    const previousPath = location?.state?.previousPath || "";
    if (previousPath) {
      navigate(previousPath);
    } else {
      navigate(routePathsWithParams.PROJECTS);
    }
  };

  const handleDeleteProjectById = async () => {
    try {
      setIsDeleting(true);
      if (project?.id) {
        await dispatch(deleteProjectById(project?.id)).unwrap();
        // navigate(routePathsWithParams.PROJECTS);
        handleClose();
        dispatch(getSummarizedProjectsList());
        dispatch(getLocationListForSideBar());
      }
    } catch (error) {
      console.error("Error deleting project:", error);
    } finally {
      setIsDeleting(false);
    }
  };

  const handleOpenModal = () => {
    setIsOpen(!isOpen);
  };

  const handleGetProjectById = async () => {
    const response = await getProjectById({ projectId: params.projectId });
    if (response?.isSuccess) {
      console.log(response.project.actualCompletionDate);
      const project = response.project;
      reset({
        projectName: project?.name || "",
        projectCode: project?.code,
        projectType: project?.projectTypeId,

        projectedStart: project?.projectedStartDate
          ? dayjs(project?.projectedStartDate)
          : "",
        projectedCompletion: project?.projectedCompletionDate
          ? dayjs(project?.projectedCompletionDate)
          : "",
        actualStart: project?.actualStartDate
          ? dayjs(project?.actualStartDate)
          : "",
        actualCompletion: project.actualCompletionDate
          ? dayjs(project?.actualCompletionDate)
          : "",
        projectNotes: project?.notes || "",
        projectStatus: project?.status || ProjectStatusEnum.OPEN,
        contractPrice: project?.contractPrice || 0.0,
        projectManagers: project?.projectManagersIds || [],
      });
    }
  };

  useEffect(() => {
    dispatch(getAllProjectTypes());
    dispatch(getAllProjectManagers());
  }, [dispatch]);

  useEffect(() => {
    if (!project) {
      dispatch(
        createProjectDraft({
          id: "",
          isDraft: true,
          name: "",
          projectTypeId: null,
        })
      );
    }
  }, [dispatch, project]);

  const handleEditProjectType = (item: {
    label: string;
    value: string | null;
  }) => {
    setIsOpen(true);
    setEditProjectType(item);
  };

  useEffect(() => {
    setValue("projectType", projectType);
  }, [projectType]);

  useEffect(() => {
    if (project) {
      reset({
        projectName: project?.name || "",
        projectCode: project?.code,
        projectType: project?.projectTypeId,

        projectedStart: project?.projectedStartDate
          ? dayjs(project?.projectedStartDate)
          : "",
        projectedCompletion: project?.projectedCompletionDate
          ? dayjs(project?.projectedCompletionDate)
          : "",
        actualStart: project?.actualStartDate
          ? dayjs(project?.actualStartDate)
          : "",
        actualCompletion: project.actualCompletionDate
          ? dayjs(project?.actualCompletionDate)
          : "",
        projectNotes: project?.notes || "",
        projectStatus: project?.status || ProjectStatusEnum.OPEN,
        contractPrice: project?.contractPrice || 0.0,
        projectManagers: project?.projectManagersIds || [],
      });
    } else {
      reset({
        projectName: "",
        projectCode: "",
        projectType: "",

        projectedStart: "",
        projectedCompletion: "",
        actualStart: "",
        actualCompletion: "",
        projectNotes: "",
        projectStatus: ProjectStatusEnum.OPEN,
        contractPrice: 0.0,
        projectManagers: [],
      });
      dispatch(resetState());
    }
  }, [project, reset]);

  useEffect(() => {
    if (!project && params.projectId) {
      handleGetProjectById();
    }
    return () => {
      setProjectName("");
    };
  }, [params.projectId]);

  useEffect(() => {
    dispatch(resetState());
  }, []);
  return (
    <>
      <ProjectTypeModal
        setIsOpen={setIsOpen}
        isOpen={isOpen}
        setProjectType={setProjectType}
        editProjectType={editProjectType}
        setEditProjectType={setEditProjectType}
      />

      <SectionLayout>
        <Form
          onFinish={handleSubmit(onSubmit)}
          layout="vertical"
          autoComplete="off"
        >
          <CustomFormRow>
            <Col xs={24} className="mb-4">
              <Typography.Title level={5}>Project Information</Typography.Title>
            </Col>
            <Col xs={12}>
              <Controller
                name="projectName"
                control={control}
                render={({ field, fieldState }) => (
                  <Form.Item<FieldType>
                    help={fieldState.error ? fieldState.error.message : ""}
                    validateStatus={fieldState.error ? "error" : ""}
                  >
                    <CustomFormLabel text="Project Name" required />
                    <Input
                      disabled={isFieldsCraftAuthorized()}
                      {...field}
                      onChange={(event) => {
                        field.onChange(event?.target?.value || "");
                        setProjectName(event?.target?.value || "");
                      }}
                      value={field.value || ""}
                      size="large"
                      placeholder="Project Name"
                      className="mt-3"
                    />
                  </Form.Item>
                )}
              />
            </Col>
            <Col xs={12}>
              <Controller
                name="projectCode"
                control={control}
                render={({ field, fieldState }) => {
                  return (
                    <Form.Item<FieldType>
                      validateStatus={fieldState.error ? "error" : ""}
                      help={fieldState.error ? fieldState.error.message : ""}
                    >
                      <CustomFormLabel text="Project Code" required />
                      <Input
                        {...field}
                        disabled={
                          (Boolean(project) && !project?.isDraft) ||
                          isFieldsCraftAuthorized()
                        }
                        onChange={(event) =>
                          field.onChange(event?.target?.value)
                        }
                        size="large"
                        placeholder="Project Code"
                        value={field.value || ""}
                        className="mt-3"
                      />
                    </Form.Item>
                  );
                }}
              />
            </Col>
            <Col xs={12}>
              <Controller
                name="projectType"
                control={control}
                render={({ field }) => (
                  <Form.Item
                    label={<CustomFormLabel text="Project Type" />}
                    labelAlign="right"
                  >
                    <Select
                      disabled={isFieldsCraftAuthorized()}
                      value={field.value || projectType}
                      // options={memoizedTypesOptions}
                      onChange={(value) => {
                        field.onChange(value || projectType);
                      }}
                      size="large"
                      placeholder="Select Project Type"
                      popupClassName="z-50"
                      dropdownRender={(menu) => (
                        <>
                          {menu}
                          <Divider className="mt-2 mb-1" />
                          <Space className="p-1">
                            <Button
                              type="text"
                              icon={<PlusOutlined />}
                              onClick={handleOpenModal}
                            >
                              Add New Project Type
                            </Button>
                          </Space>
                        </>
                      )}
                      showSearch
                      filterOption={(input, option) =>
                        (option?.key ?? "")
                          ?.toLowerCase()
                          ?.includes(input.toLowerCase())
                      }
                    >
                      {memoizedTypesOptions?.map((item) => (
                        <Select.Option
                          key={item?.label}
                          value={item?.value}
                          label={item?.label}
                        >
                          <div
                            style={{
                              display: "flex",
                              justifyContent: "space-between",
                              alignItems: "center",
                            }}
                          >
                            <span>{item?.label}</span>
                            {item?.value && !isFieldsCraftAuthorized() && (
                              <Button
                                type="link"
                                size="small"
                                icon={<CustomIcon type="edit" />}
                                onMouseDown={(e) => e.stopPropagation()}
                                onClick={() => handleEditProjectType(item)}
                              />
                            )}
                          </div>
                        </Select.Option>
                      ))}
                    </Select>
                  </Form.Item>
                )}
              />
            </Col>
          </CustomFormRow>

          <CustomFormRow>
            <Col xs={24} className="my-4">
              <Typography.Title level={5}>Schedule</Typography.Title>
            </Col>
            <Col xs={12}>
              <Controller
                name="projectedStart"
                control={control}
                render={({ field, fieldState }) => (
                  <Form.Item
                    validateStatus={fieldState.error ? "error" : ""}
                    help={fieldState.error ? fieldState.error.message : ""}
                  >
                    <CustomFormLabel text="Projected Start" required />
                    <DatePicker
                      {...field}
                      disabled={isFieldsCraftAuthorized()}
                      value={
                        dayjs(field.value).isValid() ? dayjs(field.value) : null
                      }
                      onChange={(date) => {
                        field.onChange(dayjs(date).locale("en").format());
                      }}
                      className="mt-3"
                      size="large"
                      style={{ width: "100%" }}
                      placeholder="MM/DD/YYYY"
                      format="MM/DD/YYYY"
                    />
                  </Form.Item>
                )}
              />
            </Col>
            <Col xs={12}>
              <Controller
                name="projectedCompletion"
                control={control}
                render={({ field, fieldState }) => (
                  <Form.Item<FieldType>
                    label={
                      <CustomFormLabel text="Projected Completion" required />
                    }
                    labelAlign="right"
                    validateStatus={fieldState.error ? "error" : ""}
                    help={fieldState.error ? fieldState.error.message : ""}
                  >
                    <DatePicker
                      {...field}
                      disabled={isFieldsCraftAuthorized()}
                      value={
                        dayjs(field.value).isValid() ? dayjs(field.value) : null
                      }
                      onChange={(date) => {
                        field.onChange(dayjs(date).locale("en").format());
                      }}
                      size="large"
                      style={{ width: "100%" }}
                      placeholder="MM/DD/YYYY"
                      format={dateFormat}
                    />
                  </Form.Item>
                )}
              />
            </Col>
            <Col xs={12}>
              <Controller
                name="actualStart"
                control={control}
                render={({ field }) => (
                  <Form.Item<FieldType>
                    label={<CustomFormLabel text="Actual Start" />}
                    // name="actualStart"
                    labelAlign="right"
                  >
                    <DatePicker
                      disabled={isFieldsCraftAuthorized()}
                      value={
                        dayjs(field.value).isValid() ? dayjs(field.value) : null
                      }
                      onChange={(date) => {
                        field.onChange(dayjs(date).locale("en").format());
                      }}
                      size="large"
                      style={{ width: "100%" }}
                      placeholder="MM/DD/YYYY"
                      format={dateFormat}
                    />
                  </Form.Item>
                )}
              />
            </Col>
            <Col xs={12}>
              <Controller
                name="actualCompletion"
                control={control}
                render={({ field }) => (
                  <Form.Item<FieldType>
                    label={<CustomFormLabel text="Actual Completion" />}
                    // name="actualCompletion"
                    labelAlign="right"
                  >
                    <DatePicker
                      disabled={isFieldsCraftAuthorized()}
                      value={
                        dayjs(field.value).isValid() ? dayjs(field.value) : null
                      }
                      onChange={(date) => {
                        field.onChange(dayjs(date).locale("en").format());
                      }}
                      size="large"
                      style={{ width: "100%" }}
                      placeholder="MM/DD/YYYY"
                      format={dateFormat}
                    />
                  </Form.Item>
                )}
              />
            </Col>
          </CustomFormRow>

          <CustomFormRow>
            <Col xs={24} className="my-4">
              <Typography.Title level={5}>Project Notes</Typography.Title>
            </Col>
            <Col xs={24}>
              <Controller
                name="projectNotes"
                control={control}
                render={({ field }) => (
                  <Form.Item<FieldType>
                    label={
                      <CustomFormLabel text="Notes (for Internal Users)" />
                    }
                    // name="projectNotes"
                    labelAlign="right"
                    tooltip="These notes will only be visible to your team."
                  >
                    <Input.TextArea
                      disabled={isFieldsCraftAuthorized()}
                      {...field}
                      value={field.value || ""}
                      onChange={(event) =>
                        field.onChange(event?.target?.value || "")
                      }
                      className="min-h-40"
                      placeholder="Write your notes here.."
                    />
                  </Form.Item>
                )}
              />
            </Col>
          </CustomFormRow>

          <CustomFormRow>
            <Col xs={24} className="my-4">
              <Typography.Title level={5}>
                Project Management Details
              </Typography.Title>
            </Col>
            <Col xs={12}>
              <Controller
                name="projectStatus"
                control={control}
                render={({ field }) => (
                  <Form.Item<FieldType>>
                    <CustomFormLabel text="Change Project Status" />
                    <Select
                      disabled={isFieldsCraftAuthorized()}
                      value={field.value}
                      onChange={(value) => field.onChange(value)}
                      size="large"
                      className="mt-3"
                      options={projectStatusOptions}
                    />
                  </Form.Item>
                )}
              />
            </Col>
            <Col xs={12}>
              <Controller
                name="contractPrice"
                control={control}
                render={({ field }) => (
                  <Form.Item<FieldType>>
                    <CustomFormLabel text="Contract Price" />
                    <InputNumber
                      disabled={isFieldsCraftAuthorized()}
                      value={field.value}
                      onChange={(value) => field.onChange(value || 0)}
                      className="mt-3"
                      size="large"
                      style={{ width: "100%" }}
                      min={0}
                      // type="number"
                      formatter={(value) => `$ ${convertToLocaleString(value)}`}
                      parser={(value) =>
                        value?.replace(/\$\s?|(,*)/g, "") as unknown as number
                      }
                    />
                  </Form.Item>
                )}
              />
            </Col>
            <Col xs={12}>
              <Controller
                name="projectManagers"
                control={control}
                render={({ field, fieldState }) => (
                  <Form.Item<FieldType>
                    validateStatus={fieldState.error ? "error" : ""}
                    help={fieldState.error ? fieldState.error.message : ""}
                  >
                    <CustomFormLabel text="Project Managers" required />
                    <Select
                      disabled={isFieldsCraftAuthorized()}
                      showSearch
                      value={field.value}
                      onChange={(value) => field.onChange(value)}
                      mode="multiple"
                      placeholder="Select Project Managers"
                      size="large"
                      className="mt-3"
                      allowClear
                      options={memoizedProjectManagersOptions}
                      filterOption={(input, option) =>
                        ((option?.label as string) ?? "")
                          .toLowerCase()
                          .includes(input.toLowerCase())
                      }
                    />
                  </Form.Item>
                )}
              />
            </Col>
          </CustomFormRow>

          {hasMadeApiCall && (resError || successMessage) && (
            <CustomAlert
              message={resError || successMessage || ""}
              type={successMessage ? "success" : "error"}
            />
          )}
          {isFieldsCraftAuthorized() && (
            <Flex justify="flex-end" className="gap-4">
              <Button
                disabled={isSubmitting || isDeleting}
                type="default"
                onClick={handleClose}
              >
                Back
              </Button>
            </Flex>
          )}
          {!isFieldsCraftAuthorized() && (
            <Flex justify="flex-end" className="gap-4">
              <Button
                disabled={isSubmitting || isDeleting}
                type="default"
                onClick={handleClose}
              >
                Cancel
              </Button>
              {project && Object.keys(project).length > 0 && (
                <Button
                  loading={isDeleting}
                  disabled={isSubmitting || isDeleting}
                  type="default"
                  onClick={handleDeleteProjectById}
                >
                  {isDeleting ? "Deleting.." : "Delete"}
                </Button>
              )}
              <Button
                loading={actionType === "save" && isSubmitting}
                disabled={isSubmitting || isDeleting}
                type="primary"
                htmlType="submit"
                onClick={() => setActionType("save")}
              >
                {actionType === "save" && isSubmitting ? "Saving.." : "Save"}
              </Button>

              <Button
                loading={actionType === "saveAndClose" && isSubmitting}
                disabled={isSubmitting || isDeleting}
                type="primary"
                htmlType="submit"
                onClick={() => setActionType("saveAndClose")}
              >
                {actionType === "saveAndClose" && isSubmitting
                  ? "Saving and closing.."
                  : "Save & Close"}
              </Button>
            </Flex>
          )}

          {project?.id && (
            <Flex justify="flex-end" className="mt-4">
              <CreatedByUserBadge
                // userName={project?.createdBy}
                // date={project?.createdDate}
                userName={
                  project.modifiedDate == null
                    ? project.createdBy
                    : project.lastModifiedBy
                }
                date={project.lastModifiedDate}
                isModifiedBadge={project.modifiedDate == null ? false : true}
              />
            </Flex>
          )}
        </Form>
      </SectionLayout>
    </>
  );
}
