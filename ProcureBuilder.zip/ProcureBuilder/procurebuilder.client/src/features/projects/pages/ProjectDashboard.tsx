import { getDashboardByProjectId } from "@/src/apis/dashboardApis";
import CustomOverlayLoader from "@/src/components/common/CustomOverlayloader";
import ActionItemsSection from "@/src/features/dashboard/components/ActionItemsSection";
import CalendarSection from "@/src/features/dashboard/components/CalendarSection";
import ProjectBudgetAnalysisSection from "@/src/features/dashboard/components/ProjectBudgetAnalysisSection";
import TimelineSection from "@/src/features/dashboard/components/TimelineSection";
import DeliverablesSection from "@/src/features/dashboard/components/UpcomingDeliverablesSection";
import WaitingForSection from "@/src/features/dashboard/components/WaitingForSection";
import ProjectDashboardDetails from "@/src/features/projects/components/ProjectDashboardDetails";
import ProjectDashboardHeader from "@/src/features/projects/components/ProjectDashboardHeader";
import { useAppDispatch } from "@/src/hooks/useAppDispatch";
import { useAppSelector } from "@/src/hooks/useAppSelector";
import { getDashboardState } from "@/src/store/slices/dashboardSlice";
import { dateFormat, getEntityIconType } from "@/src/utils/constants";
import {
  DashboardNotification,
  DashboardNotificationWithCustomProps,
  SideNotificationsType,
  SideNotificationsTypeWithCustomProps,
} from "@/src/utils/types";
import { Flex, message } from "antd";
import dayjs from "dayjs";
import { useCallback, useEffect, useMemo, useState } from "react";
import { useParams } from "react-router-dom";
import ProjectDashboardContributors from "../components/ProjectDashboardContributors";
import ProjectDashboardPurchaseOrderListSection from "../components/ProjectDashboardPurchaseOrderList";
import ProjectMaterialComparisonSection from "../components/ProjectMaterialComparison";

export default function ProjectDashboard() {
  const dispatch = useAppDispatch();
  const { projectId } = useParams();

  const {
    isLoading,
    dashboardDataByProjectId,
    dashBoardSideNotifyData,
    text,
    reqError,
    resError,
  } = useAppSelector(getDashboardState);

  const today = new Date();
  const [selectedWeekDate, setSelectedWeekDate] = useState<Date | null | any>(
    today
  );
  const [sideNotifications, setSideNotifications] =
    useState<SideNotificationsType[]>();

  useEffect(() => {
    const filters = {
      date: selectedWeekDate?.toISOString(),
      projectId: projectId || null,
    };

    const filterNotification = dashBoardSideNotifyData?.find(
      (item) =>
        dayjs(item.date).format(dateFormat) ===
        dayjs(filters.date).format(dateFormat)
    );

    setSideNotifications(filterNotification?.notifications);
  }, [selectedWeekDate, dashBoardSideNotifyData]);

  useEffect(() => {
    const filters = {
      date: selectedWeekDate?.toISOString(),
      projectId: projectId || null,
    };
    dispatch(getDashboardByProjectId(filters));
    setSelectedWeekDate(null);
    setSideNotifications([]);
  }, [projectId]);

  const {
    actionItemNotifications = [],
    upcomingDeliverableNotifications = [],
    waitingForNotifications = [],
    projectManagers = [],
    projectOwner = null,
    projectDetails = null,
  } = dashboardDataByProjectId || {};

  const mapNotificationWithCustomProps = useCallback(
    (
      item: DashboardNotification | SideNotificationsType
    ):
      | DashboardNotificationWithCustomProps
      | SideNotificationsTypeWithCustomProps => ({
      ...item,
      entityIconType: getEntityIconType[item.entityType],
    }),
    []
  );

  const memoizedActionItems = useMemo(
    () =>
      (actionItemNotifications || []).map(
        mapNotificationWithCustomProps
      ) as unknown as DashboardNotificationWithCustomProps[],
    [actionItemNotifications, mapNotificationWithCustomProps]
  );
  const memoizedDeliverables = useMemo(
    () =>
      (upcomingDeliverableNotifications || []).map(
        mapNotificationWithCustomProps
      ) as unknown as DashboardNotificationWithCustomProps[],
    [upcomingDeliverableNotifications, mapNotificationWithCustomProps]
  );
  const memoizedWaitingForItems = useMemo(
    () =>
      (waitingForNotifications || [])?.map(
        mapNotificationWithCustomProps
      ) as unknown as DashboardNotificationWithCustomProps[],
    [waitingForNotifications, mapNotificationWithCustomProps]
  );

  useEffect(() => {
    if (text || resError || reqError) {
      message.open({
        type: text ? "success" : "error",
        content: text || resError || reqError,
      });
    }
  }, [text, reqError, resError]);

  return (
    <>
      <Flex className="flex-row flex-wrap p-4 gap-4 relative">
        {isLoading ? (
          <CustomOverlayLoader />
        ) : (
          <>
            <ProjectDashboardHeader projectDetails={projectDetails} />

            <Flex className="flex-col gap-4" flex={1}>
              <ProjectDashboardDetails
                projectDashboardDetails={
                  dashboardDataByProjectId?.projectDetails || null
                }
              />
              <ActionItemsSection actionItems={memoizedActionItems} />
              <DeliverablesSection deliverables={memoizedDeliverables} />
              <WaitingForSection
                waitingForNotifications={memoizedWaitingForItems}
              />
            </Flex>

            <Flex className="flex-col gap-4 basis-[30%] max-w-[30%]">
              <ProjectDashboardContributors
                projectManagers={projectManagers || []}
                projectOwner={projectOwner}
              />
              <CalendarSection
                today={today}
                selectedWeekDate={selectedWeekDate}
                setSelectedWeekDate={setSelectedWeekDate}
              />
              <TimelineSection sideNotifications={sideNotifications || []} />
              <ProjectMaterialComparisonSection />
            </Flex>

            <ProjectDashboardPurchaseOrderListSection />
            <ProjectBudgetAnalysisSection />
          </>
        )}
      </Flex>
    </>
  );
}
