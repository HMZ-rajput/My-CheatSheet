import CustomTabs from "@/src/components/common/CustomTabs";
import CustomTag from "@/src/components/common/CustomTag";
import PageLayout from "@/src/components/layout/PageLayout";
import CustomerTab from "@/src/features/customers/components/CustomerTab";
import { useAppSelector } from "@/src/hooks/useAppSelector";
import { getProjectDataById } from "@/src/store/slices/projectsSlice";
import { ProjectStatusEnum } from "@/src/utils/enums";
import routePaths from "@/src/utils/routePaths";
import { Flex } from "antd";
import { useEffect, useState } from "react";
import { useLocation, useParams } from "react-router-dom";
import BidMaterialTab from "../../bid-material/components/BidMaterialTab";
import ChangeOrderTab from "../../change-orders/components/ChangeOrderTab";
import InventoryTab from "../../inventory/components/InventoryTab";
import LocationTab from "../../locations/components/LocationTab";
import QualityQuestionsTab from "../../quality-questions/components/QualityQuestionsTab";
import ProjectDetailsForm from "../components/ProjectDetailsForm";

export default function ProjectDetailsPage() {
  // Constants, location, params, etc.
  const tabs = {
    projectDetails: "Project Details",
    customer: "Customer",
    locations: "Locations",
    bidMaterial: "Bid Material",
    changeOrders: "Change Orders",
    inventory: "Inventory",
    qualityQuestions: "Quality Questions",
  };
  const location = useLocation();
  const { projectId } = useParams();

  const urlParams = new URLSearchParams(window.location.search);
  const queryParams = urlParams.get("locationId");

  const project = useAppSelector((state) =>
    getProjectDataById(state, projectId || "")
  );

  const [selectedTab, setSelectedTab] = useState(tabs.projectDetails);

  useEffect(() => {
    if (location?.state?.bidMaterial) {
      setSelectedTab(tabs.bidMaterial);
      return;
    }
    if (queryParams) {
      setSelectedTab(queryParams ? tabs.inventory : tabs.projectDetails);
    }
  }, [queryParams, location?.state]);

  // Functions
  function renderRenderTabPanels() {
    switch (selectedTab) {
      default:
        return <ProjectDetailsForm project={project} />;
      case tabs.customer:
        return <CustomerTab project={project} />;
      case tabs.locations:
        return (
          <LocationTab
            project={project}
            setSelectedTab={setSelectedTab}
            tabToRender={tabs.inventory}
          />
        );
      case tabs.bidMaterial:
        return <BidMaterialTab projectId={projectId} />;
      case tabs.changeOrders:
        return <ChangeOrderTab projectId={projectId} />;
      case tabs.inventory:
        return <InventoryTab />;
      case tabs.qualityQuestions:
        return <QualityQuestionsTab />;
    }
  }

  // Effects
  useEffect(() => {
    if (
      location.pathname === routePaths.PROJECTS_NEW &&
      selectedTab !== tabs.projectDetails
    ) {
      setSelectedTab(tabs.projectDetails);
    }
  }, [location]);

  // Stateless Components

  return (
    <>
      <PageLayout
        title="Project"
        titleSibling={
          <CustomTag status={project?.status || ProjectStatusEnum.OPEN} />
        }
        titleBarJustifyContent="flex-start"
      >
        <Flex className="mb-7">
          <CustomTabs
            options={Object.entries(tabs)?.map(([key, value]) => ({
              value: key,
              label: value,
              disabled: !projectId ? value !== tabs.projectDetails : false,
            }))}
            tabLabel={selectedTab}
            onChange={(tab) => {
              const urlParams = new URLSearchParams(window.location.search);
              urlParams.delete("locationId");
              window.history.replaceState(
                {},
                "",
                `${window.location.pathname}?${urlParams.toString()}`
              );

              setSelectedTab(tab);
            }}
          />
        </Flex>

        {renderRenderTabPanels()}
      </PageLayout>
    </>
  );
}
