import { Button } from "antd";
import ProjectsList from "@features/projects/components/ProjectsList";
import CustomIcon from "@components/common/CustomIcon";
import { getConsistentSpacing } from "@utils/theme-helpers";
import PageLayout from "@components/layout/PageLayout";
import { useNavigate } from "react-router-dom";
import routePaths from "@/src/utils/routePaths";
import useAuthorization from "@/src/hooks/useAuthorization";
export default function ProjectsPage() {
  const navigate = useNavigate();
  const { isFieldsCraftAuthorized } = useAuthorization();
  return (
    <>
      <PageLayout
        title="Projects"
        titleSibling={
          !isFieldsCraftAuthorized() && (
            <Button
              size="large"
              type="primary"
              icon={
                <CustomIcon
                  type="plus"
                  className="fill-white"
                  width={parseInt(getConsistentSpacing(3))}
                  height={parseInt(getConsistentSpacing(3))}
                />
              }
              onClick={() => navigate(routePaths.PROJECTS_NEW)}
            >
              New Project
            </Button>
          )
        }
      >
        <ProjectsList />
      </PageLayout>
    </>
  );
}
