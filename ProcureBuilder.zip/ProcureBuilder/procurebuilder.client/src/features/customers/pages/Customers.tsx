import routePaths from "@/src/utils/routePaths";
import CustomIcon from "@components/common/CustomIcon";
import PageLayout from "@components/layout/PageLayout";
import { getConsistentSpacing } from "@utils/theme-helpers";
import { Button } from "antd";
import { useNavigate } from "react-router-dom";
import CustomersList from "@/src/features/customers/components/CustomersList";
export default function CustomersPage() {
  const navigate = useNavigate();

  return (
    <>
      <PageLayout
        title="Customer Contacts"
        titleSibling={
          <Button
            size="large"
            type="primary"
            icon={
              <CustomIcon
                type="plus"
                className="fill-white"
                width={parseInt(getConsistentSpacing(3))}
                height={parseInt(getConsistentSpacing(3))}
              />
            }
            onClick={() => navigate(routePaths.CUSTOMERS_NEW)}
          >
            New Customer
          </Button>
        }
      >
        <CustomersList
          hasPagination
          hasDetailedColumns
        />
      </PageLayout>
    </>
  );
}