import PageLayout from "@components/layout/PageLayout";
import { useParams } from "react-router-dom";
// import CustomerDetailsForm from "../components/CustomerDetailsForm";
import CustomerDetailsForm from "../components/CustomerDetailsFormRHF";
import { useAppDispatch } from "@/src/hooks/useAppDispatch";
import { useEffect, useState } from "react";
import { Customer } from "@/src/utils/types";
import { getCustomerById } from "@/src/apis/customerApis";
import { getCustomerDataById } from "@/src/store/slices/customersSlice";
import { useAppSelector } from "@/src/hooks/useAppSelector";

export default function CustomersPage() {
  const { customerId } = useParams();
  console.log(customerId, "PARAMS id");
  const [customer, setCustomer] = useState<Customer | null>(null);
  const dispatch = useAppDispatch();
  // Selectors, memos.
  const cachedCustomer = useAppSelector((state) =>
    getCustomerDataById(state, customerId || "")
  );
  useEffect(() => {
    if (cachedCustomer) {
      setCustomer(cachedCustomer);
      return;
    }

    const fetchCustomerById = async () => {
      if (customerId) {
        const response = await dispatch(getCustomerById(customerId)).unwrap();
        setCustomer(response.customer);
      } else {
        setCustomer(null);
      }
    };
    fetchCustomerById();
  }, [customerId, cachedCustomer]);

  return (
    <>
      <PageLayout title={`${customer ? "Edit" : "Add New"} Customer`}>
        <CustomerDetailsForm customer={customer} />
      </PageLayout>
    </>
  );
}
