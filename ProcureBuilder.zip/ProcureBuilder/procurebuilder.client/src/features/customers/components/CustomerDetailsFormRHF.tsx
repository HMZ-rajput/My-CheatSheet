import { Button, Col, Flex, Form, Input, Row, Select, Typography } from "antd";
import {
  //  useLocation,
  useNavigate,
} from "react-router-dom";
import * as Yup from "yup";

import { addCustomerToProject } from "@/src/apis/projectApis";
import CreatedByUserBadge from "@/src/components/common/CreatedByUserBadge";
import CustomAlert from "@/src/components/common/CustomAlert";
import { useAppSelector } from "@/src/hooks/useAppSelector";
import {
  getCustomersState,
  resetState,
} from "@/src/store/slices/customersSlice";
import { updateProject } from "@/src/store/slices/projectsSlice";
import { getUserFullName } from "@/src/store/slices/userSlice";
import { Customer } from "@/src/utils/types";
import {
  createCustomer,
  deleteCustomerById,
  editCustomerById,
  removeCustomerById,
} from "@apis/customerApis";
import CustomFormLabel from "@components/common/CustomFormLabel";
import SectionLayout from "@components/layout/SectionLayout";
import { yupResolver } from "@hookform/resolvers/yup";
import { useAppDispatch } from "@hooks/useAppDispatch";
import { phoneNumberLengthRegex, statesList } from "@utils/constants";
import routePaths from "@utils/routePaths";
import { getConsistentSpacing } from "@utils/theme-helpers";
import { useEffect, useRef, useState } from "react";
import { Controller, Resolver, useForm } from "react-hook-form";
import PhoneInput from "react-phone-input-2";
import "react-phone-input-2/lib/style.css";
type CustomerDetailsFormProps = {
  customer?: Customer | null;
  projectId?: string;
  displayForm?: boolean;
  handleCancelForm?: () => void;
};

type FormValues = Omit<Customer, "projects">;

export default function CustomerDetailsForm({
  customer,
  projectId,
  handleCancelForm,
  displayForm,
}: CustomerDetailsFormProps) {
  const { successMessage, resError, reqError } =
    useAppSelector(getCustomersState);

  console.log("displayForm", displayForm);
  const userFullName = useAppSelector(getUserFullName);
  const dispatch = useAppDispatch();
  const navigate = useNavigate();
  //   const [hasMadeApiCall, setHasMadeApiCall] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  const [actionType, setActionType] = useState("");
  const phoneInputRef = useRef<HTMLInputElement>(null);
  const cellPhoneInputRef = useRef<HTMLInputElement>(null);

  type FieldType = {
    // Info
    firstName: string;
    lastName: string;
    companyName: string;
    phoneNumber: string;
    cellPhoneNumber: string;
    primaryEmail: string;

    // Address Info
    streetAddress: string;
    city: string;
    state: string;
    zipCode: string;
  };

  const validationSchema = Yup.object().shape({
    firstName: Yup.string().required("First Name is required.")?.trim(),
    lastName: Yup.string().required("Last Name is required.")?.trim(),
    companyName: Yup.string()
      .required("Company / Entity Name is required.")
      .trim(),
    phoneNumber: Yup.string()
      .trim()
      .required("Phone Number is required.")
      .matches(phoneNumberLengthRegex, "Phone number is not valid in the US"),
    primaryEmail: Yup.string()
      .trim()
      .required("Email is required.")
      .email("Invalid email format.")
      .matches(
        /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/,
        "Invalid email format. Must include a domain at the end."
      ),
    zipCode: Yup.string()
      .trim()
      .test(
        "len",
        "Invalid Zip Code. Please enter in the format: 12345 or 12345-6789",
        (val) => !val || val.length === 5 || val.length === 10
      ),
    cellPhoneNumber: Yup.string()
      .optional()
      .trim()
      .matches(phoneNumberLengthRegex, {
        message: "Cell Phone Number is not valid in the US",
        excludeEmptyString: true,
      }),
  });

  const getDefaultValues = (customer: Customer | null) => {
    return {
      // id: customer?.id || "",
      firstName: customer?.firstName || "",
      lastName: customer?.lastName || "",
      companyName: customer?.companyName || "",
      phoneNumber: customer?.phoneNumber || "",
      cellPhoneNumber: customer?.cellPhoneNumber || "",
      primaryEmail: customer?.primaryEmail || "",

      // Address Info
      streetAddress: customer?.streetAddress || "",
      city: customer?.city || "",
      state: customer?.state || null,
      zipCode: customer?.zipCode || "",
      createdBy: customer?.createdBy || "",
      lastModifiedBy: customer?.lastModifiedBy || "",
      lastModifiedDate: customer?.lastModifiedDate || null,
      modifiedDate: customer?.modifiedDate || null,
    };
  };
  const {
    control,
    handleSubmit,
    reset,
    getValues,
    formState: { isSubmitting, errors },
    register,
  } = useForm({
    resolver: yupResolver(validationSchema) as unknown as Resolver<FormValues>,
    defaultValues: getDefaultValues(customer ? customer : null),
  });

  const handleSave = async (data: FormValues) => {
    try {
      if (customer?.id) {
        const payload = {
          ...data,
          modifiedBy: userFullName,
        };
        const res = await dispatch(
          editCustomerById({ ...customer, ...payload })
        ).unwrap();
        if (res.isSuccess) {
          reset(getDefaultValues(res.customer));
        }
        return res;
      } else {
        const payload = {
          ...data,
          createdBy: userFullName,
        };
        const createCustomerResponse = await dispatch(
          createCustomer({ ...payload })
        ).unwrap();

        if (createCustomerResponse?.isSuccess) {
          if (projectId) {
            const addCustomerToProjectRes = await dispatch(
              addCustomerToProject({
                projectId: projectId || "",
                customerId: createCustomerResponse?.customer?.id || "",
              })
            ).unwrap();
            return addCustomerToProjectRes;
          }
          navigate(
            `${routePaths.CUSTOMERS_EDIT_BY_ID}/${createCustomerResponse.customer.id}`
          );
          return createCustomerResponse;
        }
      }
    } catch (err) {
      console.log(err);
    }
  };

  const onSubmit = async (data: FormValues) => {
    console.log(data);
    try {
      if (actionType === "save") {
        await handleSave(data);
      } else if (actionType === "saveAndClose") {
        const res = await handleSave(data);
        if (res?.isSuccess) {
          handleCancelForm
            ? handleCancelForm()
            : navigate(`${routePaths.CUSTOMERS}`);
        }
      }
    } catch (error) {
      console.error("Error during form submission:", error);
    }

    // finally {
    // }
  };

  async function handleDeleteCustomerById() {
    // if (customer?.id) {
    //   setIsDeleting(true);
    //   const res = await dispatch(deleteCustomerById(customer?.id)).unwrap();
    //   if (res.isSuccess) {
    //     setIsDeleting(false);
    //     handleCancelForm
    //       ? handleCancelForm()
    //       : navigate(`${routePaths.CUSTOMERS}`);
    //   }
    // }
    try {
      setIsDeleting(true);
      let res = null;
      if (projectId && customer?.id) {
        res = await dispatch(
          removeCustomerById({ customerId: customer?.id, projectId })
        ).unwrap();
        if (res.isSuccess) {
          dispatch(updateProject({ projectId })); // update the project slice after removing the customer
          handleCancelForm?.();
        }
      } else {
        if (customer?.id) {
          res = await dispatch(deleteCustomerById(customer?.id)).unwrap();
          if (res.isSuccess) {
            navigate(`${routePaths.CUSTOMERS}`);
          }
        }
      }
    } catch (err) {
    } finally {
      setIsDeleting(false);
    }
  }

  useEffect(() => {
    if (!customer) {
      reset(getDefaultValues(customer || null));
      return;
    }

    const customerValues = getDefaultValues(customer);
    reset(customerValues);
  }, [customer, reset]);

  useEffect(() => {
    dispatch(resetState());
  }, []);

  useEffect(() => {
    const timeoutId = setTimeout(() => {
      if (
        customer?.id &&
        phoneInputRef?.current &&
        cellPhoneInputRef?.current
      ) {
        phoneInputRef.current.focus();
        cellPhoneInputRef.current.focus();
        const clickEvent = new MouseEvent("click", {
          bubbles: true,
          cancelable: true,
          view: window,
        });
        phoneInputRef?.current.dispatchEvent(clickEvent);
        cellPhoneInputRef?.current?.dispatchEvent(clickEvent);
      }
    }, 50); // Adjust the delay as needed

    return () => clearTimeout(timeoutId);
  }, [phoneInputRef, isSubmitting, cellPhoneInputRef, customer]);
  return (
    <>
      <SectionLayout>
        <Form
          onFinish={handleSubmit(onSubmit)}
          layout="vertical"
          autoComplete="off"
        >
          <Row gutter={parseInt(getConsistentSpacing(2))}>
            <Col xs={24} style={{ marginBottom: getConsistentSpacing(2) }}>
              <Typography.Title level={5}>Contact Information</Typography.Title>
            </Col>

            {/* First Name */}
            <Col xs={12}>
              <Form.Item<FieldType>
                validateStatus={errors.firstName ? "error" : ""}
                help={errors.firstName ? errors.firstName.message : ""}
              >
                <CustomFormLabel text="First Name" required />
                <Controller
                  name="firstName"
                  control={control}
                  render={({ field }) => (
                    <Input
                      {...field}
                      size="large"
                      placeholder="First Name"
                      className="mt-3"
                    />
                  )}
                />
              </Form.Item>
            </Col>

            {/* Last Name */}
            <Col xs={12}>
              <Form.Item<FieldType>
                validateStatus={errors.lastName ? "error" : ""}
                help={errors.lastName ? errors.lastName.message : ""}
              >
                <CustomFormLabel text="Last Name" required />
                <Controller
                  name="lastName"
                  control={control}
                  render={({ field }) => (
                    <Input
                      {...field}
                      size="large"
                      placeholder="Last Name"
                      className="mt-3"
                    />
                  )}
                />
              </Form.Item>
            </Col>

            {/* Company / Entity */}
            <Col xs={12}>
              <Form.Item<FieldType>
                validateStatus={errors.companyName ? "error" : ""}
                help={errors.companyName ? errors.companyName.message : ""}
              >
                <CustomFormLabel text="Company / Entity" required />
                <Controller
                  name="companyName"
                  control={control}
                  render={({ field }) => (
                    <Input
                      {...field}
                      size="large"
                      placeholder="Company Name"
                      className="mt-3"
                    />
                  )}
                />
              </Form.Item>
            </Col>

            {/* Phone */}
            <Col xs={12}>
              <Form.Item<FieldType>
                validateStatus={errors.phoneNumber ? "error" : ""}
                help={errors.phoneNumber ? errors.phoneNumber.message : ""}
              >
                <CustomFormLabel text="Phone" required />
                <Controller
                  name="phoneNumber"
                  control={control}
                  render={({ field }) => (
                    <div ref={register("phoneNumber").ref} className="mt-3">
                      <PhoneInput
                        country={"us"}
                        value={field.value}
                        onChange={(phoneNumber) => field.onChange(phoneNumber)}
                        inputProps={{
                          id: "phoneNumbers",
                          ref: phoneInputRef,
                        }}
                      />
                    </div>
                  )}
                />
              </Form.Item>
            </Col>

            {/* Cell Phone */}
            <Col xs={12}>
              <Form.Item<FieldType>
                label={<CustomFormLabel text="Cell Phone" />}
                labelAlign="right"
                validateStatus={errors.cellPhoneNumber ? "error" : ""}
                help={
                  errors.cellPhoneNumber ? errors.cellPhoneNumber.message : ""
                }
              >
                <Controller
                  name="cellPhoneNumber"
                  control={control}
                  render={({ field }) => (
                    <div ref={register("cellPhoneNumber").ref}>
                      <PhoneInput
                        country={"us"}
                        value={field.value}
                        onChange={(cellPhoneNumber) =>
                          field.onChange(cellPhoneNumber)
                        }
                        inputProps={{
                          id: "cellNumbers",
                          ref: cellPhoneInputRef,
                        }}
                      />
                    </div>
                  )}
                />
              </Form.Item>
            </Col>

            {/* Primary Email */}
            <Col xs={12}>
              <Form.Item<FieldType>
                validateStatus={errors.primaryEmail ? "error" : ""}
                help={errors.primaryEmail ? errors.primaryEmail.message : ""}
              >
                <CustomFormLabel text="Primary Email" required />
                <Controller
                  name="primaryEmail"
                  control={control}
                  render={({ field }) => (
                    <Input
                      {...field}
                      size="large"
                      placeholder="Primary Email"
                      className="mt-3"
                    />
                  )}
                />
              </Form.Item>
            </Col>
          </Row>

          <Row gutter={parseInt(getConsistentSpacing(2))}>
            <Col xs={24} style={{ marginBlock: getConsistentSpacing(2) }}>
              <Typography.Title level={5}>Address Information</Typography.Title>
            </Col>

            {/* Street Address */}
            <Col xs={12}>
              <Form.Item<FieldType>
                label={<CustomFormLabel text="Street Address" />}
                labelAlign="right"
              >
                <Controller
                  name="streetAddress"
                  control={control}
                  render={({ field }) => (
                    <Input
                      {...field}
                      size="large"
                      placeholder="Street Address"
                    />
                  )}
                />
              </Form.Item>
            </Col>

            {/* City */}
            <Col xs={12}>
              <Form.Item<FieldType>
                label={<CustomFormLabel text="City" />}
                labelAlign="right"
              >
                <Controller
                  name="city"
                  control={control}
                  render={({ field }) => (
                    <Input {...field} size="large" placeholder="City" />
                  )}
                />
              </Form.Item>
            </Col>

            {/* State */}
            <Col xs={12}>
              <Form.Item<FieldType>
                label={<CustomFormLabel text="State" />}
                labelAlign="right"
              >
                <Controller
                  name="state"
                  control={control}
                  render={({ field }) => (
                    <Select
                      {...field}
                      size="large"
                      options={statesList?.map((state) => ({
                        label: state,
                        value: state,
                      }))}
                      placeholder="Select State"
                      showSearch
                      filterOption={(input, option) =>
                        (option?.label || "")
                          .toLowerCase()
                          .includes(input.toLowerCase())
                      }
                    />
                  )}
                />
              </Form.Item>
            </Col>

            {/* Zip Code */}
            <Col xs={12}>
              <Form.Item<FieldType>
                label={<CustomFormLabel text="Zip Code" />}
                labelAlign="right"
                validateStatus={errors.zipCode ? "error" : ""}
                help={errors.zipCode ? errors.zipCode.message : ""}
              >
                <Controller
                  name="zipCode"
                  control={control}
                  render={({ field }) => (
                    <Input
                      // value={formik.values?.zipCode.trim()}
                      {...field}
                      size="large"
                      placeholder="Zip Code"
                    />
                  )}
                />
              </Form.Item>
            </Col>
          </Row>
          {(resError || reqError || successMessage) && (
            <CustomAlert
              message={resError || reqError || successMessage || ""}
              type={successMessage ? "success" : "error"}
            />
          )}

          <Flex justify="flex-end" className="gap-4">
            <Button
              disabled={isSubmitting || isDeleting}
              type="default"
              onClick={() => {
                handleCancelForm
                  ? handleCancelForm()
                  : navigate(`${routePaths.CUSTOMERS}`);
              }}
            >
              Cancel
            </Button>
            {customer?.id && (
              <Button
                loading={isDeleting}
                disabled={isSubmitting || isDeleting}
                type="default"
                onClick={handleDeleteCustomerById}
              >
                {projectId
                  ? isDeleting
                    ? "Removing.."
                    : "Remove"
                  : isDeleting
                  ? "Deleting.."
                  : "Delete"}
              </Button>
            )}
            <Button
              loading={actionType === "save" && isSubmitting}
              disabled={isSubmitting || isDeleting}
              type="primary"
              htmlType="submit"
              onClick={() => setActionType("save")}
            >
              {actionType === "save" && isSubmitting ? "Saving.." : "Save"}
            </Button>

            <Button
              loading={actionType === "saveAndClose" && isSubmitting}
              disabled={isSubmitting || isDeleting}
              type="primary"
              htmlType="submit"
              onClick={() => setActionType("saveAndClose")}
            >
              {actionType === "saveAndClose" && isSubmitting
                ? "Saving and closing.."
                : "Save & Close"}
            </Button>
          </Flex>
          <div className="mt-5"></div>

          {customer?.id && (
            <Flex justify="flex-end">
              <CreatedByUserBadge
                // userName={customer?.createdBy}
                // date={customer?.createdDate}
                userName={
                  getValues("modifiedDate") == null
                    ? getValues("createdBy")
                    : getValues("lastModifiedBy")
                }
                date={getValues("lastModifiedDate")}
                isModifiedBadge={
                  getValues("modifiedDate") == null ? false : true
                }
              />
            </Flex>
          )}
        </Form>
      </SectionLayout>
    </>
  );
}
