import CustomModal from "@/src/components/common/CustomModal";
import CustomersList from "./CustomersList";
import { useEffect, useState } from "react";
import { Key } from "antd/es/table/interface";
import { useAppDispatch } from "@/src/hooks/useAppDispatch";
import { addCustomerToProject } from "@/src/apis/projectApis";
import { useParams } from "react-router-dom";

type CustomerSelectionModalProps = {
    isModalOpen: boolean;
    setIsModalOpen: React.Dispatch<React.SetStateAction<boolean>>
    onCustomerSaved: () => void;
}

export default function CustomerSelectionModal({ isModalOpen, setIsModalOpen, onCustomerSaved }: CustomerSelectionModalProps) {
    const dispatch = useAppDispatch()
    const [isLoading, setIsLoading] = useState(false)
    const { projectId } = useParams()
    const [selectedCustomerId, setSelectedCustomerId] = useState<Key>("")
    // const [forceRenderTimestamp, setForceRenderTimestamp] = useState(0)

    useEffect(() => {
        if (isModalOpen) {
            setSelectedCustomerId("");
        }
    }, [isModalOpen]);

    const handleSave = async () => {
        if (selectedCustomerId) {
            setIsLoading(true)
            const response = await dispatch(addCustomerToProject({ projectId: projectId || "", customerId: selectedCustomerId.toString() })).unwrap()
            if (response?.isSuccess) {
                onCustomerSaved()
                setIsLoading(false)
                setIsModalOpen(false);
            }
        }
    };

    const handleCancel = () => {
        setIsModalOpen(false);
    };

    return (
        <CustomModal
            title="Customer Contacts"
            isOpen={isModalOpen}
            primaryButtonAction={handleSave}
            cancelButtonAction={handleCancel}
            primaryButtonText="Save"
            primaryButtonLoadingText="Saving.."
            isPrimaryButtonDisabled={!selectedCustomerId}
            isLoading={isLoading}
        >
            <CustomersList
                hasCursorPointer
                hasRowSelection
                hasPagination
                selectedRowId={selectedCustomerId}
                setSelectedRowId={setSelectedCustomerId}
            // forceRenderTimestamp={forceRenderTimestamp}
            />
        </CustomModal>
    )
}

