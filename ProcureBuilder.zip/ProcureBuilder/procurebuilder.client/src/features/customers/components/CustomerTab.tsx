import { getCustomerById } from "@/src/apis/customerApis";
import CustomIcon from "@/src/components/common/CustomIcon";
import SectionLayout from "@/src/components/layout/SectionLayout";
import { Customer, Project } from "@/src/utils/types";
import NoCustomersImg from "@assets/images/customers/customers-orange.png";
import { Button, Flex } from "antd";
import { useEffect, useState } from "react";
// import CustomerDetailsForm from "./CustomerDetailsForm";
import CustomOverlayLoader from "@/src/components/common/CustomOverlayloader";
import { useAppDispatch } from "@/src/hooks/useAppDispatch";
import CustomerDetailsForm from "./CustomerDetailsFormRHF";
import CustomerSelectionModal from "./CustomerSelectionModal";
import CustomersList from "./CustomersList";
import useAuthorization from "@/src/hooks/useAuthorization";

type CustomerTabProps = {
  project?: Project | null;
};

export default function CustomerTab({ project }: CustomerTabProps) {
  const { isFieldsCraftAuthorized } = useAuthorization();
  const [displayForm, setDisplayForm] = useState(false);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [customerDetails, setCustomerDetails] = useState<Customer[]>([]);
  const [customer, setCustomer] = useState<Customer>();
  const [_, setForceRerender] = useState(0);

  const [customerId, setCustomerId] = useState("");
  const dispatch = useAppDispatch();
  const [isLoading, setIsLoading] = useState<boolean>(true);

  // console.log("forceRerender", forceRerender);

  // const dummyId = "a00b583e-4938-4e4f-856c-fddb375d1f05";

  // console.log("customerDetails", customerDetails);

  const handleGetCustomer = async () => {
    try {
      const response = await dispatch(
        getCustomerById(project?.customer?.id || customerId)
      ).unwrap();
      setCustomerDetails(response?.customer ? [response.customer] : []);
      setCustomer(response?.customer);
    } catch (err) {
      console.log("Failed to fetch customer:", err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    handleGetCustomer();
  }, [project, displayForm]);

  const handleChangeFormState = (id: string) => {
    setCustomerId(id);
    setDisplayForm(true);
  };

  const NoCustomersSection = (
    <>
      <SectionLayout
        className="p-8 rounded-xl items-center max-h-64"
        borderStyle="dashed"
      >
        <img src={NoCustomersImg} width="48" height="48" className="mb-5" />

        <h6 className="font-medium text-sm !mb-1">
          Connect your customers to their projects
        </h6>

        <p className="font-normal text-xs mb-5 text-neutral-7">
          Please create a New Customer or Choose Existing to get started.
        </p>

        {!isFieldsCraftAuthorized() && (
          <Flex className="gap-5">
            <Button
              size="large"
              className="hover:!fill-primary"
              icon={<CustomIcon type="plus" />}
              onClick={() => {
                setDisplayForm(true);
              }}
            >
              New Customer
            </Button>
            <Button size="large" onClick={() => setIsModalOpen(true)}>
              Choose Existing Customers
            </Button>
          </Flex>
        )}
      </SectionLayout>

      <CustomerSelectionModal
        isModalOpen={isModalOpen}
        setIsModalOpen={setIsModalOpen}
        onCustomerSaved={() => setForceRerender((prev) => prev + 1)}
      />
    </>
  );

  if (isLoading) {
    return <CustomOverlayLoader />;
  }

  return (
    <SectionLayout>
      {project?.customer && customerDetails?.length > 0 && !displayForm ? (
        <CustomersList
          customersData={customerDetails}
          hasSearch={false}
          hasBorders={false}
          handleChangeFormState={handleChangeFormState}
        />
      ) : displayForm ? (
        <CustomerDetailsForm
          displayForm={displayForm}
          projectId={project?.id || ""}
          customer={customer}
          handleCancelForm={() => setDisplayForm(false)}
        />
      ) : (
        NoCustomersSection
      )}
    </SectionLayout>
  );
}
