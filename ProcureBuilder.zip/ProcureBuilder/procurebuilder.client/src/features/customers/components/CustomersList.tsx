import { getAllCustomers } from "@/src/apis/customerApis";
import HighlightedText from "@/src/components/common/HighlightedText";
import { useAppDispatch } from "@/src/hooks/useAppDispatch";
import useAuthorization from "@/src/hooks/useAuthorization";
import routePaths from "@/src/utils/routePaths";
import { UserOutlined } from "@ant-design/icons";
import CustomButton from "@components/common/CustomButton";
import CustomIcon from "@components/common/CustomIcon";
import SectionLayout from "@components/layout/SectionLayout";
import { useAppSelector } from "@hooks/useAppSelector";
import { getCustomersState } from "@store/slices/customersSlice";
import { getConsistentSpacing } from "@utils/theme-helpers";
import { Customer, Project } from "@utils/types";
import {
  Avatar,
  Button,
  Divider,
  Flex,
  Input,
  Table,
  TableProps,
  Tag,
  Typography,
} from "antd";
import { Key, TableRowSelection } from "antd/es/table/interface";
import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";

type CustomersListProps = {
  hasRowSelection?: boolean;
  forceRenderTimestamp?: number;
  customersData?: Customer[] | null;
  selectedRowId?: Key;
  hasPagination?: boolean;
  hasCursorPointer?: boolean;
  hasDetailedColumns?: boolean;
  hasSearch?: boolean;
  hasBorders?: boolean;
  handleChangeFormState?: (id: string) => void;
  setSelectedRowId?: React.Dispatch<React.SetStateAction<Key>>;
};

export default function CustomersList({
  selectedRowId,
  setSelectedRowId,
  handleChangeFormState,
  hasSearch = true,
  hasBorders = true,

  ...props
}: CustomersListProps) {
  const navigate = useNavigate();
  const dispatch = useAppDispatch();

  const {
    customersData,
    totalCount,
    currentPage: customersCurrentPage,
    pageSize: customersPageSize,
  } = useAppSelector(getCustomersState);

  const { isFieldsCraftAuthorized } = useAuthorization();
  const [page, setPage] = useState<number>(customersCurrentPage);
  const [pageSize, setPageSize] = useState(customersPageSize);
  const [searchTerm, setSearchTerm] = useState("");
  const [hasSearched, setHasSearched] = useState(false);
  const [previousSearchTerm, setPreviousSearchTerm] = useState("");
  const [isFirstCall, setIsFirstCall] = useState(true);

  const filteredData = useMemo(() => {
    const data = customersData || [];
    return data;
  }, [customersData]);

  const columns: TableProps<Customer>["columns"] = [
    {
      title: "Customer",
      dataIndex: "Customer",
      key: "Customer",
      sorter: (a, b) => {
        const customerA = customersData?.find((f) => f?.id === a?.id);
        console.log("customerA", customerA);
        const customerB = customersData?.find((f) => f?.id === b?.id);
        const nameA = `${customerA?.firstName || ""} ${
          customerA?.lastName || ""
        }`;
        const nameB = `${customerB?.firstName || ""} ${
          customerB?.lastName || ""
        }`;
        return nameA.localeCompare(nameB);
      },
      render: (_, record) => {
        const customer = customersData?.find((f) => f?.id === record?.id);
        return (
          <Flex className="items-center gap-3">
            <Avatar size={32} icon={<UserOutlined />} />
            <Typography.Title
              level={5}
              style={{ fontSize: getConsistentSpacing(1.75), margin: 0 }}
            >
              <HighlightedText
                text={`${customer?.firstName || ""} ${
                  customer?.lastName || ""
                }`}
                searchTerm={searchTerm}
              />
            </Typography.Title>
          </Flex>
        );
      },
    },
    {
      title: "Company / Entity",
      dataIndex: "companyName",
      key: "companyName",
      sorter: (a, b) => a.companyName?.localeCompare(b.companyName),
      render: (companyName) => (
        <HighlightedText text={companyName} searchTerm={searchTerm} />
      ),
    },
    {
      title: "Primary Email",
      dataIndex: "primaryEmail",
      key: "primaryEmail",
      sorter: (a, b) => a.primaryEmail?.localeCompare(b.primaryEmail),
      render: (primaryEmail) => (
        <HighlightedText text={primaryEmail} searchTerm={searchTerm} />
      ),
    },
    {
      title: "Phone",
      dataIndex: "phoneNumber",
      key: "phoneNumber",
      sorter: (a, b) => a.phoneNumber?.localeCompare(b.phoneNumber),
      render: (phone) => (
        <HighlightedText text={phone} searchTerm={searchTerm} />
      ),
    },
    {
      title: "City",
      dataIndex: "city",
      key: "city",
      sorter: (a, b) => a.city?.localeCompare(b.city),
      render: (city) => <HighlightedText text={city} searchTerm={searchTerm} />,
    },
    props.hasDetailedColumns
      ? {
          title: "State",
          dataIndex: "state",
          key: "state",
          sorter: (a, b) => (a.state || "").localeCompare(b.state || ""),
          render: (state) => (
            <HighlightedText text={state} searchTerm={searchTerm} />
          ),
        }
      : {
          title: "Zip Code",
          dataIndex: "zipCode",
          key: "zipCode",
          sorter: (a, b) => a.zipCode?.localeCompare(b.zipCode),
          render: (zipCode) => (
            <HighlightedText text={zipCode} searchTerm={searchTerm} />
          ),
        },
    {
      title: "Projects",
      dataIndex: "projects",
      key: "projects",
      render: (projects: Project[]) => (
        <Flex vertical align="start" className="gap-1">
          {projects?.map((project) => (
            <Tag>
              <HighlightedText text={project?.name} searchTerm={searchTerm} />
            </Tag>
          )) || []}
        </Flex>
      ),
    },
    ...(!isFieldsCraftAuthorized()
      ? [
          {
            title: "",
            dataIndex: "",
            key: "",
            render: (_: any, record: Customer) => (
              <Button
                shape="circle"
                className="hover:!fill-primary"
                icon={<CustomIcon type="edit" />}
                onClick={() =>
                  handleChangeFormState
                    ? handleChangeFormState(record?.id || "")
                    : navigate(
                        `${routePaths.CUSTOMERS_EDIT_BY_ID}/${record?.id}`
                      )
                }
              />
            ),
          },
        ]
      : []),
  ];

  function handleSetSelectedRowId(id: Key) {
    if (setSelectedRowId) {
      setSelectedRowId(id);
    }
  }

  const rowSelection: TableRowSelection<Customer> = {
    type: "radio",
    selectedRowKeys: [selectedRowId || ""],
    onChange: (selectedRowKeys: Key[]) => {
      handleSetSelectedRowId(selectedRowKeys[0]);
      // console.log("selected", selectedRowKeys)
      return selectedRowKeys;
    },
  };

  function resetPaginationAndGetFirstPageResults() {
    setPage(1);
    handleGetResults(1);
  }

  function handleGetResults(pageNumber?: number) {
    if (!hasSearch) {
      return;
    }
    dispatch(
      getAllCustomers({
        pageNumber: pageNumber || page,
        pageSize,
        search: searchTerm || undefined,
      })
    );
  }

  const handleSearch = () => {
    if (searchTerm !== previousSearchTerm) {
      setHasSearched(true);
      resetPaginationAndGetFirstPageResults();
      setPreviousSearchTerm(searchTerm);
    }
  };

  // Debounce the searchTerm change
  useEffect(() => {
    if (!hasSearched) return;
    const timer = setTimeout(() => {
      if (searchTerm === "" && previousSearchTerm !== "") {
        resetPaginationAndGetFirstPageResults();
        setPreviousSearchTerm(searchTerm);
      }
    }, 500);

    return () => {
      clearTimeout(timer);
    };
  }, [searchTerm, hasSearched, previousSearchTerm]);

  useEffect(() => {
    if (
      isFirstCall ||
      customersCurrentPage !== page ||
      customersPageSize !== pageSize
    ) {
      handleGetResults();
      setIsFirstCall(false);
    }
  }, [page, pageSize, isFirstCall]);

  return (
    <>
      <SectionLayout isHidden={!hasBorders}>
        {hasSearch ? (
          <>
            <Flex className="gap-3">
              <Input
                value={searchTerm}
                onChange={(event) => setSearchTerm(event?.target?.value)}
                prefix={<CustomIcon type="search" />}
                placeholder="Search.."
                style={{ maxWidth: getConsistentSpacing(30) }}
              />
              <CustomButton size="large" onClick={handleSearch}>
                Search
              </CustomButton>
            </Flex>

            <Divider />
          </>
        ) : null}

        <Table
          loading={false}
          rowSelection={props.hasRowSelection ? rowSelection : undefined}
          onRow={
            props.hasCursorPointer
              ? (record) => ({
                  onClick: () => handleSetSelectedRowId(record.id || ""),
                  style: { cursor: "pointer" },
                })
              : undefined
          }
          style={{ width: "100%" }}
          columns={columns}
          dataSource={
            props?.customersData ? props?.customersData : filteredData
          }
          rowKey="id"
          pagination={
            props.hasPagination
              ? {
                  position: ["bottomRight"],
                  current: page,
                  pageSize: pageSize,
                  pageSizeOptions: ["10", "25", "50"],
                  showSizeChanger: true,
                  total: totalCount,
                  showTotal: (total) => "Total: " + total,
                  onChange: (page, pageSize) => {
                    setPageSize(pageSize);
                    setPage(page);
                  },
                }
              : false
          }
        />
      </SectionLayout>
    </>
  );
}
