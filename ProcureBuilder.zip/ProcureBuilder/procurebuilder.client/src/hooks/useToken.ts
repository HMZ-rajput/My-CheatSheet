import { theme } from "antd"

const useToken = () => theme.useToken()?.token

export default useToken

