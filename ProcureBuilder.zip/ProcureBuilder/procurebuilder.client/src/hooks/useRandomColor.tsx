import { useMemo } from "react";
import theme from "@theme/index";
export const useRandomColor = () => {
  const token = theme.token;

  const randomColor = useMemo(() => {
    const colors = [
      token?.green8 || "",
      token?.pink3 || "",
      token?.purple8 || "",
      token?.yellow5 || "",
      token?.cyan3 || "",
    ];

    return colors[Math.floor(Math.random() * colors.length)];
  }, [
    token?.green8,
    token?.pink3,
    token?.purple8,
    token?.yellow5,
    token?.cyan3,
  ]);

  return randomColor;
};
