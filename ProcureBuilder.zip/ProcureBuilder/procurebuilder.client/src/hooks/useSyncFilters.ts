import { useState } from "react";

const useSyncFilters = () => {
  const [searchParams, setSearchParams] = useState(
    () => new URLSearchParams(window.location.search)
  );

  const updateSearchParams = (params: URLSearchParams) => {
    const paramsString = params?.toString()?.trim();

    let newUrl = `${window.location.pathname}`;
    if (paramsString) {
      newUrl += `?${paramsString}`;
    }
    window.history.replaceState({}, "", newUrl);
    setSearchParams(new URLSearchParams(params));
  };

  return { searchParams, updateSearchParams };
};

export default useSyncFilters;
