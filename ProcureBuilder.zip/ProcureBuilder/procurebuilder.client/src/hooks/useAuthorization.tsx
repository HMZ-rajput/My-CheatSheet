import { getUserState } from "../store/slices/userSlice";
import { Roles } from "../utils/constants";
import { useAppSelector } from "./useAppSelector";

const useAuthorization = () => {
  const { data: userData } = useAppSelector(getUserState);
  const isAdminAuthorized = (): boolean => {
    return userData?.userRole === Roles.Admin;
  };

  const isSuperAdminAuthorized = (): boolean => {
    return userData?.userRole === Roles.SuperAdmin;
  };
  const isCominedAdminAuthorized = (): boolean => {
    return isAdminAuthorized() || isSuperAdminAuthorized();
  };

  const isEngineerAuthorized = (): boolean => {
    return userData?.userRole === Roles.Engineer;
  };
  const isSuperIntendientAuthorized = (): boolean => {
    return userData?.userRole === Roles.Superintendent;
  };
  const isCominedEngAndSuperIntAuthorized = (): boolean => {
    return isEngineerAuthorized() || isSuperIntendientAuthorized();
  };

  const isFieldsCraftAuthorized = (): boolean => {
    return userData?.userRole === Roles.Fieldcraft;
  };

  return {
    isAdminAuthorized,
    isSuperAdminAuthorized,
    isEngineerAuthorized,
    isFieldsCraftAuthorized,
    isSuperIntendientAuthorized,
    isCominedAdminAuthorized,
    isCominedEngAndSuperIntAuthorized,
  };
};

export default useAuthorization;
