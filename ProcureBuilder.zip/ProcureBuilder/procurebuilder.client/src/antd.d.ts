// antd.d.ts
import "antd/es/theme/interface"

declare module "antd/es/theme/interface" {
  export interface AliasToken {
    colorNeutral1?: string
    colorNeutral2?: string
    colorNeutral3?: string
    colorNeutral4?: string
    colorNeutral5?: string
    colorNeutral6?: string
    colorNeutral7?: string
    colorNeutral8?: string
    colorNeutral9?: string
  }
}
