import {
  createMaterialTransfer,
  deleteMaterialTransferById,
  editMaterialTransferById,
  getAllMaterialTransfer,
  getAllMaterialTransferlist,
} from "@/src/apis/materialTransferApis";
import { createSlice } from "@reduxjs/toolkit";
import { RootState } from "@store/index";
import {
  MaterialTransfer,
  MaterialTransferAddMaterial,
  PaginationProperties,
  ReduxStateType,
} from "@utils/types";
import dayjs from "dayjs";

type MaterialTransferState = {
  materialTransferData: MaterialTransfer[] | null;
  materialTransferList: MaterialTransferAddMaterial[] | null;
};

const initialState: MaterialTransferState &
  PaginationProperties &
  ReduxStateType = {
  materialTransferData: null,
  materialTransferList: null,
  isSuccess: false,
  successMessage: "",
  isLoading: false,
  reqError: "",
  resError: "",
  currentPage: 1,
  hasNext: false,
  hasPrevious: false,
  pageSize: 10,
  totalCount: 10,
  totalPages: 1,
};

export const materialTransferSlice = createSlice({
  name: "materialTransfer",
  initialState,
  reducers: {
    resetState: (state) => {
      state.isSuccess = false;
      state.isLoading = false;
      state.reqError = null;
      state.resError = null;
      state.successMessage = "";
    },
    resetStateisSuccess: (state) => {
      state.isSuccess = false;
    },
    resetMaterialTransferData: (state) => {
      state.materialTransferData = null;
    },
  },
  extraReducers: (builder) =>
    builder
      // .addCase(getAllMaterialTransferlist.pending, (state) => {
      //   state.resError = "";
      //   state.isSuccess = false;
      //   state.successMessage = "";
      //   state.isLoading = true;
      // })
      // .addCase(getAllMaterialTransferlist.rejected, (state) => {
      //   state.resError = "";
      //   state.isSuccess = false;
      //   state.successMessage = "";
      //   state.isLoading = false;
      // })
      .addCase(getAllMaterialTransferlist.fulfilled, (state, action) => {
        // state.isSuccess = true;
        // state.successMessage = "";
        state.materialTransferList = action.payload?.materials;
        // state.isLoading = false;
      })
      .addCase(getAllMaterialTransfer.pending, (state) => {
        state.isSuccess = false;
        state.isLoading = true;
      })
      .addCase(getAllMaterialTransfer.rejected, (state) => {
        state.isSuccess = false;
        state.isLoading = false;
      })
      .addCase(getAllMaterialTransfer.fulfilled, (state, action) => {
        state.isSuccess = false;
        state.materialTransferData = action.payload?.materialTransfers;
        state.currentPage = action?.payload?.currentPage;
        state.pageSize = action?.payload?.pageSize;
        state.totalCount = action?.payload?.totalCount;
        state.totalPages = action?.payload?.totalPages;
        state.isLoading = false;
      })
      .addCase(createMaterialTransfer.pending, (state) => {
        state.resError = "";
        state.reqError = "";
        state.isSuccess = false;
        state.successMessage = "";
        state.isLoading = true;
      })
      .addCase(createMaterialTransfer.rejected, (state) => {
        state.reqError = "Failed to create material transfer.";
        state.isSuccess = false;
        state.successMessage = "";
        state.isLoading = false;
      })
      .addCase(createMaterialTransfer.fulfilled, (state, action) => {
        state.isSuccess = action?.payload?.isSuccess;
        if (!action?.payload?.isSuccess) {
          state.resError = action?.payload?.errors[0] || "";
          return;
        }
        if (action?.payload?.isSuccess) {
          state.successMessage =
            "Material Transfer has been created successfully.";
          state.materialTransferData = [
            ...(state.materialTransferData || []),
            {
              ...action.payload?.materialTransfer,
              transferDate: dayjs(
                action.payload?.materialTransfer?.transferDate
              ).toDate(),
            },
          ];
        }
        state.reqError = "";
        state.isLoading = false;
      })
      .addCase(editMaterialTransferById.pending, (state) => {
        state.resError = "";
        state.reqError = "";
        state.isSuccess = false;
        state.successMessage = "";
        state.isLoading = true;
      })
      .addCase(editMaterialTransferById.rejected, (state) => {
        state.reqError = "Failed to update material transfer.";
        state.isSuccess = false;
        state.successMessage = "";
        state.isLoading = false;
      })
      .addCase(editMaterialTransferById.fulfilled, (state, action) => {
        state.isSuccess = action?.payload?.isSuccess;
        state.materialTransferData = (state?.materialTransferData || [])?.map(
          (material) =>
            material?.id === action.payload?.materialTransfer?.id
              ? action?.payload?.materialTransfer
              : material
        );
        if (!action?.payload?.isSuccess) {
          state.resError = action?.payload?.errors[0] || "";
        }
        if (action?.payload?.isSuccess) {
          state.successMessage =
            "Material Transfer has been updated successfully.";
        }
      })
      .addCase(deleteMaterialTransferById.pending, (state) => {
        state.resError = "";
        state.reqError = "";
        state.isSuccess = false;
        state.successMessage = "";
        state.isLoading = true;
      })
      .addCase(deleteMaterialTransferById.rejected, (state) => {
        state.reqError = "Failed to delete Material Transfer.";
        state.isSuccess = false;
        state.successMessage = "";
        state.isLoading = false;
      })
      .addCase(deleteMaterialTransferById.fulfilled, (state, action) => {
        state.isSuccess = action.payload.isSuccess;
        state.isLoading = false;
        state.materialTransferData =
          state.materialTransferData?.filter(
            (materialTransfer) =>
              materialTransfer?.id !== action.payload?.materialTransfer?.id
          ) || [];
        if (!action?.payload?.isSuccess) {
          state.resError = action?.payload?.errors[0] || "";
        }
        if (action?.payload?.isSuccess) {
          state.successMessage =
            "Material Transfer has been deleted successfully.";
        }
      }),
});

export const { resetState, resetStateisSuccess, resetMaterialTransferData } =
  materialTransferSlice.actions;
export const getMaterialTransferState = (state: RootState) =>
  state.materialTransfer;

export const getMaterialTransferData = (state: RootState) =>
  state.materialTransfer?.materialTransferData;

export const getMaterialTransferById = (
  state: RootState,
  materialTransferId: string
) =>
  state.materialTransfer?.materialTransferData?.find(
    (f) => f.id === materialTransferId
  ) || null;

export default materialTransferSlice.reducer;
