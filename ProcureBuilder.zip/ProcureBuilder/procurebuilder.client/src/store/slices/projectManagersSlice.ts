import { getAllProjectManagers } from "@/src/apis/projectManagersApis";
import { createSlice } from "@reduxjs/toolkit";
import { RootState } from "@store/index";
import { ProjectManager, ReduxStateType } from "@utils/types";

type ProjectManagersState = {
  managersData: ProjectManager[] | null;
};

const initialState: ProjectManagersState & ReduxStateType = {
  managersData: null,
  isSuccess: false,
  isLoading: false,
  reqError: "",
  resError: "",
};

export const projectManagersSlice = createSlice({
  name: "projectManagers",
  initialState,
  reducers: {},
  extraReducers: (builder) =>
    builder
      .addCase(getAllProjectManagers.pending, (state) => {
        state.isLoading = true;
      })
      .addCase(getAllProjectManagers.rejected, (state) => {
        state.isLoading = false;
      })
      .addCase(getAllProjectManagers.fulfilled, (state, action) => {
        state.managersData = action?.payload?.managers || [];
        state.isLoading = false;
      }),
});

export const getProjectManagersState = (state: RootState) =>
  state.projectManagers;
export const getProjectManagerNameById = (state: RootState, typeId: string) =>
  state.projectManagers?.managersData?.find((f) => f.id === typeId);

export default projectManagersSlice.reducer;
