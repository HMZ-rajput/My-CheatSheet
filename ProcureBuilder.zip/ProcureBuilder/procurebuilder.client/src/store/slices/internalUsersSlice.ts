import {
  createInternalUser,
  editInternalUser,
  getAllInternalUsers,
} from "@/src/apis/internalUsersApis";
import { deleteInternalUser } from "@/src/apis/userApis";
import { UserRoleEnum } from "@/src/utils/enums";
import { createSlice } from "@reduxjs/toolkit";
import { RootState } from "@store/index";
import {
  InternalUser,
  PaginationProperties,
  ReduxStateType,
} from "@utils/types";

type InternalUsersState = {
  internalUsersData: InternalUser[] | null;
};

const initialState: InternalUsersState & PaginationProperties & ReduxStateType =
  {
    internalUsersData: null,
    isSuccess: false,
    isLoading: false,
    reqError: "",
    resError: "",
    currentPage: 1,
    hasNext: false,
    hasPrevious: false,
    pageSize: 10,
    totalCount: 10,
    totalPages: 1,
  };

export const internalUsersSlice = createSlice({
  name: "internalUsers",
  initialState,
  reducers: {
    resetState: (state) => {
      state.isSuccess = false;
      state.isLoading = false;
      state.reqError = null;
      state.resError = null;
      state.successMessage = "";
    },
    resetStateisSuccess: (state) => {
      state.isSuccess = false;
    },
  },
  extraReducers: (builder) =>
    builder
      .addCase(getAllInternalUsers.pending, (state) => {
        state.isSuccess = false;
        state.isLoading = true;
      })
      .addCase(getAllInternalUsers.rejected, (state) => {
        state.resError = "Something went wrong!";
        state.isSuccess = false;
        state.isLoading = false;
      })
      .addCase(getAllInternalUsers.fulfilled, (state, action) => {
        state.internalUsersData = action.payload?.users;
        state.internalUsersData = action.payload?.users;
        state.currentPage = action?.payload?.currentPage;
        state.pageSize = action?.payload?.pageSize;
        state.totalCount = action?.payload?.totalCount;
        state.totalPages = action?.payload?.totalPages;
        state.isLoading = false;
      })
      .addCase(createInternalUser.pending, (state) => {
        state.resError = "";
        state.isSuccess = false;
        state.successMessage = "";
        state.isLoading = true;
      })
      .addCase(createInternalUser.rejected, (state) => {
        state.resError = "Something went wrong!";
        state.isSuccess = false;
        state.successMessage = "";
        state.isLoading = false;
      })
      .addCase(createInternalUser.fulfilled, (state, action) => {
        state.resError = "";
        state.isSuccess = true;

        const user: InternalUser = {
          ...action?.payload,
          id: action?.payload?.userId || "",
          email: action?.payload?.userName || "",
          role: null,
        };

        if (action?.payload?.userRole !== undefined) {
          const matchingKey = Object.keys(UserRoleEnum).find(
            (key) =>
              key.toLowerCase() ===
                (action?.payload?.userRole || "")?.toLowerCase() || ""
          );

          if (matchingKey) {
            user.role = (UserRoleEnum as any)[
              matchingKey as keyof typeof UserRoleEnum
            ];
          } else {
            user.role = null;
          }
        } else {
          user.role = null;
        }

        state.internalUsersData?.push(user);
        state.isLoading = false;
        if (!action?.payload?.isSuccess) {
          state.resError = action?.payload?.errors[0] || "";
          return;
        }
        if (action?.payload?.isSuccess) {
          state.successMessage = "Internal User has been created successfully.";
        }
      })
      .addCase(editInternalUser.pending, (state) => {
        state.resError = "";
        state.isSuccess = false;
        state.successMessage = "";
        state.isLoading = true;
      })
      .addCase(editInternalUser.rejected, (state) => {
        state.resError = "Something went wrong!";
        state.isSuccess = false;
        state.successMessage = "";
        state.isLoading = false;
      })
      .addCase(editInternalUser.fulfilled, (state, action) => {
        state.isSuccess = action?.payload?.isSuccess;
        state.isLoading = false;
        state.internalUsersData = (state.internalUsersData || []).map(
          (internalUser) =>
            internalUser?.id === action?.payload?.id
              ? action?.payload
              : internalUser
        );
        if (!action?.payload?.isSuccess) {
          state.resError = action?.payload?.errors[0] || "";
          return;
        }
        if (action?.payload?.isSuccess) {
          state.successMessage = "Internal User has been updated successfully.";
          return;
        }
      })
      .addCase(deleteInternalUser.pending, (state) => {
        state.resError = "";
        state.isSuccess = false;
        state.successMessage = "";
        state.isLoading = true;
      })
      .addCase(deleteInternalUser.rejected, (state) => {
        state.resError = "Something went wrong!";
        state.isSuccess = false;
        state.successMessage = "";
        state.isLoading = false;
      })
      .addCase(deleteInternalUser.fulfilled, (state, action) => {
        state.resError = "";
        state.isSuccess = action.payload.isSuccess;
        if (!action.payload.isSuccess) {
          state.resError = action?.payload?.errors?.[0];
        } else {
          state.successMessage = "User Deleted Successfully.";
        }
        state.isLoading = false;
      }),
});
export const { resetState, resetStateisSuccess } = internalUsersSlice.actions;
export const getInternalUsersState = (state: RootState) => state.internalUsers;
export const getInternalUserDataById = (
  state: RootState,
  internalUserId: string
) =>
  state.internalUsers?.internalUsersData?.find(
    (f) => f.id === internalUserId
  ) || null;

export default internalUsersSlice.reducer;
