import { createSlice } from "@reduxjs/toolkit";
import { RootState } from "@store/index";
import { Customer, PaginationProperties, ReduxStateType } from "@utils/types";
import {
  createCustomer,
  deleteCustomerById,
  editCustomerById,
  getAllCustomers,
  getCustomerById,
  removeCustomerById,
} from "@/src/apis/customerApis";

type CustomersState = {
  customersData: Customer[] | null;
  customer: Customer | null;
};

const initialState: CustomersState & PaginationProperties & ReduxStateType = {
  customersData: null,
  customer: null,
  isSuccess: false,
  isLoading: false,
  reqError: "",
  resError: "",
  currentPage: 1,
  hasNext: false,
  hasPrevious: false,
  pageSize: 10,
  totalCount: 10,
  totalPages: 1,
};

export const customersSlice = createSlice({
  name: "customers",
  initialState,
  reducers: {
    resetState: (state) => {
      state.isSuccess = false;
      state.isLoading = false;
      state.reqError = null;
      state.resError = null;
      state.successMessage = "";
    },
    resetStateisSuccess: (state) => {
      state.isSuccess = false;
    },
  },
  extraReducers: (builder) =>
    builder
      .addCase(getAllCustomers.pending, (state) => {
        state.isSuccess = false;
        state.isLoading = true;
      })
      .addCase(getAllCustomers.rejected, (state) => {
        state.isSuccess = false;
        state.isLoading = false;
      })
      .addCase(getAllCustomers.fulfilled, (state, action) => {
        state.customersData = action.payload?.customers;
        state.currentPage = action?.payload?.currentPage;
        state.pageSize = action?.payload?.pageSize;
        state.totalCount = action?.payload?.totalCount;
        state.totalPages = action?.payload?.totalPages;
        state.isLoading = false;
      })
      .addCase(getCustomerById.pending, (state) => {
        state.isSuccess = false;
        state.isLoading = true;
      })
      .addCase(getCustomerById.rejected, (state) => {
        state.isSuccess = false;
        state.isLoading = false;
      })
      .addCase(getCustomerById.fulfilled, (state, action) => {
        state.customer = action?.payload?.customer;
        // state.customersData =
        //   state.customersData?.map((customer) => ({
        //     ...customer,
        //     ...action.payload?.customer,
        //   })) || [];
        state.isLoading = false;
        state.isSuccess = true;
      })
      .addCase(createCustomer.pending, (state) => {
        state.isSuccess = false;
        state.successMessage = "";
        state.resError = "";
        state.reqError = "";
        state.isLoading = true;
      })
      .addCase(createCustomer.rejected, (state) => {
        state.reqError = "Something went wrong!";
        state.resError = "";
        state.isSuccess = false;
        state.successMessage = "";
        state.isLoading = false;
      })
      .addCase(createCustomer.fulfilled, (state, action) => {
        state.reqError = "";
        state.isSuccess = action?.payload?.isSuccess;
        if (!action?.payload?.isSuccess || action?.payload?.errors.length > 0) {
          state.resError = action?.payload?.errors[0] || "";
        }
        if (action?.payload?.isSuccess) {
          state.successMessage =
            "Customer contact has been created successfully.";
        }
        state.customersData?.push(action?.payload?.customer);
        state.isLoading = false;
      })
      .addCase(editCustomerById.pending, (state) => {
        state.isSuccess = false;
        state.successMessage = "";
        state.isLoading = true;
      })
      .addCase(editCustomerById.rejected, (state) => {
        state.reqError = "Something went wrong!";
        state.isSuccess = false;
        state.successMessage = "";
        state.isLoading = false;
      })
      .addCase(editCustomerById.fulfilled, (state, action) => {
        state.isSuccess = action.payload.isSuccess;
        state.customersData = (state.customersData || [])?.map((customer) =>
          customer?.id === action?.payload?.customer?.id
            ? action?.payload?.customer
            : customer
        );
        if (!action?.payload?.isSuccess) {
          state.resError = action?.payload?.errors[0] || "";
        }
        if (action?.payload?.isSuccess) {
          state.successMessage =
            "Customer contact has been updated successfully.";
        }
      })
      .addCase(deleteCustomerById.pending, (state) => {
        state.resError = "";
        state.isSuccess = false;
        state.successMessage = "";
        state.isLoading = true;
      })
      .addCase(deleteCustomerById.rejected, (state) => {
        state.reqError = "Something went wrong!";
        state.isSuccess = false;
        state.successMessage = "";
        state.isLoading = false;
      })
      .addCase(deleteCustomerById.fulfilled, (state, action) => {
        state.isLoading = false;
        if (!action?.payload?.isSuccess) {
          state.resError = action?.payload?.errors[0];
        }
        if (action?.payload?.isSuccess) {
          state.isSuccess = true;
          state.successMessage =
            "Customer contact has been deleted successfully.";
        }
      })
      .addCase(removeCustomerById.pending, (state) => {
        state.resError = "";
        state.isSuccess = false;
        state.successMessage = "";
        state.isLoading = true;
      })
      .addCase(removeCustomerById.rejected, (state) => {
        state.reqError = "Something went wrong!";
        state.isSuccess = false;
        state.successMessage = "";
        state.isLoading = false;
      })
      .addCase(removeCustomerById.fulfilled, (state, action) => {
        state.isLoading = false;
        if (!action?.payload?.isSuccess) {
          state.resError = action?.payload?.errors[0];
        }
        if (action?.payload?.isSuccess) {
          state.isSuccess = true;
          state.successMessage =
            "Customer contact has been removed successfully.";
        }
      }),
});
export const { resetState, resetStateisSuccess } = customersSlice.actions;
export const getCustomersState = (state: RootState) => state?.customers;
export const getCustomerDataById = (state: RootState, customerId: string) =>
  state.customers?.customersData?.find((f) => f?.id === customerId) || null;

export default customersSlice.reducer;
