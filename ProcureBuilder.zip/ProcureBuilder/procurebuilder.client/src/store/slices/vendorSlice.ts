import { createSlice } from "@reduxjs/toolkit";
import { RootState } from "@store/index";
import {
  Vendor,
  PaginationProperties,
  ReduxStateType,
  VendorsList,
} from "@utils/types";
import {
  createVendor,
  deleteVendorById,
  editVendorById,
  getAllVendors,
  getVendorById,
  getVendorslist,
} from "@/src/apis/vendorApis";

type VendorsState = {
  vendorsData: Vendor[] | null;
  vendorsList: VendorsList[] | null;
  vendor: Vendor | null;
};

const initialState: VendorsState & PaginationProperties & ReduxStateType = {
  vendorsData: null,
  vendorsList: null,
  vendor: null,
  isSuccess: false,
  isLoading: false,
  reqError: "",
  resError: "",
  currentPage: 1,
  hasNext: false,
  hasPrevious: false,
  pageSize: 10,
  totalCount: 10,
  totalPages: 1,
};

export const vendorsSlice = createSlice({
  name: "vendors",
  initialState,
  reducers: {
    resetState: (state) => {
      state.isSuccess = false;
      state.isLoading = false;
      state.successMessage = "";
      state.reqError = "";
      state.resError = "";
    },
    resetStateisSuccess: (state) => {
      state.isSuccess = false;
    },
  },
  extraReducers: (builder) =>
    builder
      .addCase(getAllVendors.pending, (state) => {
        state.isSuccess = false;
        state.isLoading = true;
      })
      .addCase(getAllVendors.rejected, (state) => {
        state.resError = "";
        state.isLoading = false;
      })
      .addCase(getAllVendors.fulfilled, (state, action) => {
        state.resError = "";
        state.isSuccess = false;
        state.successMessage = "";
        state.vendorsData = action.payload?.vendors;
        state.currentPage = action?.payload?.currentPage;
        state.pageSize = action?.payload?.pageSize;
        state.totalCount = action?.payload?.totalCount;
        state.totalPages = action?.payload?.totalPages;
        state.isLoading = false;
      })
      .addCase(getVendorById.pending, (state) => {
        state.isSuccess = false;
        state.isLoading = true;
      })
      .addCase(getVendorById.rejected, (state) => {
        state.isSuccess = false;
        state.isLoading = false;
      })
      .addCase(getVendorById.fulfilled, (state, action) => {
        state.vendor = action.payload?.vendor;
        state.isLoading = false;
        state.isSuccess = true;
      })

      // Ustad Inshal said iss pay pending ka case kisi kaam ka nahi hai, instead
      // maslay kar raha hai by resetting isSuccess, which leads to no success message shown on Create screen.
      // - Ustad Inshal on October 15th, 2024.

      // .addCase(getVendorslist.pending, (state) => {
      //   state.resError = "";
      //   state.isSuccess = false;
      //   state.successMessage = "";
      //   state.isLoading = true;
      // })
      .addCase(getVendorslist.rejected, (state) => {
        state.isSuccess = false;
        state.isLoading = false;
      })
      .addCase(getVendorslist.fulfilled, (state, action) => {
        // state.resError = "";
        // state.isLoading = false;
        // state.isSuccess = true;
        // state.successMessage = "";
        state.vendorsList = action.payload.vendors;
      })
      .addCase(createVendor.pending, (state) => {
        state.resError = "";
        state.reqError = "";
        state.isSuccess = false;
        state.successMessage = "";
        state.isLoading = true;
      })
      .addCase(createVendor.rejected, (state) => {
        state.resError = "";
        state.reqError = "Something went wrong!";
        state.successMessage = "";
        state.isSuccess = false;
        state.isLoading = false;
      })
      .addCase(createVendor.fulfilled, (state, action) => {
        console.log(action?.payload, "action payloadddd");
        console.log(state.vendorsData, "vendors dataaa");
        state.isLoading = false;
        state.isSuccess = action?.payload?.isSuccess;
        state.successMessage = "Vendor has been successfully created.";
        if (action?.payload?.errors?.length > 0) {
          state.resError = action?.payload?.errors[0] || "";
          return;
        }
        state.vendorsData?.push(action?.payload?.vendor);
        state.resError = "";
        state.reqError = "";
      })
      .addCase(editVendorById.pending, (state) => {
        state.resError = "";
        state.isSuccess = false;
        state.successMessage = "";
        state.isLoading = true;
      })
      .addCase(editVendorById.rejected, (state) => {
        state.resError = "";
        state.isSuccess = false;
        state.reqError = "Something went wrong!";
        state.successMessage = "";
        state.isLoading = false;
      })
      .addCase(editVendorById.fulfilled, (state, action) => {
        state.isLoading = false;
        state.isSuccess = action?.payload?.isSuccess;
        state.successMessage = "Vendor has been successfully updated.";

        if (action?.payload?.errors?.length > 0) {
          state.resError = action?.payload?.errors[0] || "";
          return;
        }
        console.log(state.vendorsData, "vendors dataaa");

        // const updatedVendor = action.payload.vendor;
        // state.vendorsData = (state.vendorsData || []).map((vendor) =>
        //   vendor.id === vendor.id ? updatedVendor : vendor
        // );
        state.reqError = "";
        state.resError = "";
      })
      .addCase(deleteVendorById.pending, (state) => {
        state.resError = "";

        state.isSuccess = false;
        state.successMessage = "";
        state.isLoading = true;
      })
      .addCase(deleteVendorById.rejected, (state) => {
        state.resError = "";
        state.reqError = "Something went wrong!";
        state.isSuccess = false;
        state.successMessage = "";
        state.isLoading = false;
      })
      .addCase(deleteVendorById.fulfilled, (state, action) => {
        state.isLoading = false;
        state.resError = "";
        state.reqError = "";
        state.isSuccess = action.payload?.isSuccess;
        if (action?.payload?.errors?.length > 0) {
          state.resError = action?.payload?.errors[0] || "";
          return;
        }
        state.successMessage = "Vendor Company has been deleted successfully";
        state.vendorsData =
          state.vendorsData?.filter(
            (vendor) => vendor?.id !== action.payload?.vendor?.id
          ) || [];
      }),
});

export const getVendorsState = (state: RootState) => state?.vendors;
export const { resetState, resetStateisSuccess } = vendorsSlice.actions;
export const getVendorDataById = (state: RootState, vendorId: string) =>
  state.vendors?.vendorsData?.find((f) => f.id === vendorId) || null;
export default vendorsSlice.reducer;
