import {
  createInvoice,
  deleteInvoiceById,
  getAllInvoices,
  updateInvoiceById,
} from "@/src/apis/invoicesApis";
import { createSlice } from "@reduxjs/toolkit";
import { RootState } from "@store/index";
import { Invoice, PaginationProperties, ReduxStateType } from "@utils/types";

type InvoicesState = {
  invoicesData: Invoice[] | null;
};

const initialState: InvoicesState & PaginationProperties & ReduxStateType = {
  invoicesData: null,
  isSuccess: false,
  isLoading: false,
  reqError: "",
  resError: "",
  successMessage: "",
  currentPage: 1,
  hasNext: false,
  hasPrevious: false,
  pageSize: 10,
  totalCount: 10,
  totalPages: 1,
};

export const invoicesSlice = createSlice({
  name: "invoices",
  initialState,
  reducers: {
    resetState: (state) => {
      state.isSuccess = false;
      state.isLoading = false;
      state.reqError = null;
      state.resError = null;
      state.successMessage = "";
      state.invoicesData = null;
    },
    resetStateisSuccess: (state) => {
      state.isSuccess = false;
    },
  },
  extraReducers: (builder) =>
    builder
      .addCase(getAllInvoices.pending, (state) => {
        state.isSuccess = false;
        state.isLoading = true;
      })
      .addCase(getAllInvoices.rejected, (state) => {
        state.resError = "";
        state.isSuccess = false;

        state.isLoading = false;
      })
      .addCase(getAllInvoices.fulfilled, (state, action) => {
        state.invoicesData = action.payload?.invoices?.sort(
          (a, b) =>
            //@ts-ignore
            new Date(b.modifiedDate).getTime() -
            //@ts-ignore
            new Date(a.modifiedDate).getTime()
        );
        state.invoicesData = action.payload?.invoices;
        state.currentPage = action?.payload?.currentPage;
        state.pageSize = action?.payload?.pageSize;
        state.totalCount = action?.payload?.totalCount;
        state.totalPages = action?.payload?.totalPages;
        state.isLoading = false;
      })
      .addCase(createInvoice.pending, (state) => {
        state.isLoading = true;
        state.isSuccess = false;
        state.successMessage = "";
        state.reqError = "";
        state.resError = "";
      })

      .addCase(createInvoice.rejected, (state) => {
        state.isLoading = false;
        state.isSuccess = false;
        state.reqError = "Something went wrong!";
      })
      .addCase(createInvoice.fulfilled, (state, action) => {
        state.isLoading = false;
        state.isSuccess = action?.payload?.isSuccess;
        if (action.payload.isSuccess) {
          state.successMessage = "Invoice created successfully.";
        }
        if (!action.payload.isSuccess) {
          state.resError = action?.payload?.errors?.[0];
        }
      })
      .addCase(updateInvoiceById.pending, (state) => {
        state.isLoading = true;
        state.isSuccess = false;
        state.successMessage = "";
        state.reqError = "";
        state.resError = "";
      })

      .addCase(updateInvoiceById.rejected, (state) => {
        state.isLoading = false;
        state.isSuccess = false;
        state.reqError = "Something went wrong!";
      })
      .addCase(updateInvoiceById.fulfilled, (state, action) => {
        state.isLoading = false;
        state.isSuccess = action?.payload?.isSuccess;
        if (action.payload.isSuccess) {
          state.successMessage = "Invoice updated successfully.";
        }
        if (!action.payload.isSuccess) {
          state.resError = action?.payload?.errors?.[0];
        }
      })
      .addCase(deleteInvoiceById.pending, (state) => {
        state.isLoading = true;
        state.isSuccess = false;
        state.successMessage = "";
        state.reqError = "";
        state.resError = "";
      })

      .addCase(deleteInvoiceById.rejected, (state) => {
        state.isLoading = false;
        state.isSuccess = false;
        state.reqError = "Something went wrong!";
      })
      .addCase(deleteInvoiceById.fulfilled, (state, action) => {
        state.isLoading = false;
        state.isSuccess = action?.payload?.isSuccess;
        if (action.payload.isSuccess) {
          state.successMessage = "Invoice deleted successfully.";
        }
        if (!action.payload.isSuccess) {
          state.resError = action?.payload?.errors?.[0];
        }
      }),
});

export const getInvoicesState = (state: RootState) => state?.invoices;
export const { resetState, resetStateisSuccess } = invoicesSlice.actions;
export const getInvoicesById = (state: RootState, invoiceId: string) =>
  state?.invoices?.invoicesData?.find((f) => f?.id === invoiceId);

export default invoicesSlice.reducer;
