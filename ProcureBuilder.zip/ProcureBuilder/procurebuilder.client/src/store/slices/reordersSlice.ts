import { createSlice } from "@reduxjs/toolkit";
import { RootState } from "@store/index";
import { Reorder, PaginationProperties, ReduxStateType } from "@utils/types";
import {
  createReorder,
  getAllReorders,
  getReorderById,
  editReorderById,
  editReorderRecipientById,
  deleteReorderById,
} from "@/src/apis/reorderApis";

type ReorderState = {
  reorderData: Reorder[] | null;
};

const initialState: ReorderState & PaginationProperties & ReduxStateType = {
  reorderData: null,
  isSuccess: false,
  isLoading: false,
  reqError: "",
  resError: "",
  currentPage: 1,
  hasNext: false,
  hasPrevious: false,
  pageSize: 10,
  totalCount: 10,
  totalPages: 1,
};

export const reorderSlice = createSlice({
  name: "reorders",
  initialState,
  reducers: {
    resetState: (state) => {
      state.isSuccess = false;
      state.isLoading = false;
      state.reqError = null;
      state.resError = null;
      state.successMessage = "";
    },
    resetStateisSuccess: (state) => {
      state.isSuccess = false;
    },
  },
  extraReducers: (builder) =>
    builder
      .addCase(getAllReorders.pending, (state) => {
        state.isSuccess = false;
        state.isLoading = true;
      })
      .addCase(getAllReorders.rejected, (state) => {
        state.isSuccess = false;
        state.isLoading = false;
      })
      .addCase(getAllReorders.fulfilled, (state, action) => {
        state.reorderData = action.payload?.reorders || [];
        state.currentPage = action?.payload?.currentPage;
        state.pageSize = action?.payload?.pageSize;
        state.totalCount = action?.payload?.totalCount;
        state.totalPages = action?.payload?.totalPages;
        state.isLoading = false;
        state.isSuccess = true;
      })

      .addCase(getReorderById.pending, (state) => {
        state.isSuccess = false;
        state.isLoading = true;
      })
      .addCase(getReorderById.rejected, (state) => {
        state.isSuccess = false;
        state.isLoading = false;
      })
      .addCase(getReorderById.fulfilled, (state, action) => {
        state.isLoading = false;
        state.isSuccess = true;

        if (action?.payload?.isSuccess) {
          state.reorderData = [action.payload?.reorder];
        }
      })

      .addCase(createReorder.pending, (state) => {
        state.resError = "";
        state.isSuccess = false;
        state.successMessage = "";
        state.isLoading = true;
      })
      .addCase(createReorder.rejected, (state) => {
        state.resError = "Something went wrong!";
        state.isSuccess = false;
        state.successMessage = "";
        state.isLoading = false;
      })
      .addCase(createReorder.fulfilled, (state, action) => {
        const { reorder } = action.payload;
        if (reorder && !(reorder instanceof FormData)) {
          state.reorderData?.push(reorder);
        }
        state.isLoading = false;
        state.isSuccess = true;
        if (!action.payload.isSuccess) {
          state.resError = action?.payload?.errors?.[0];
        } else {
          state.successMessage = "Reorder successfully created.";
        }
      })

      .addCase(editReorderById.pending, (state) => {
        state.resError = "";
        state.isSuccess = false;
        state.successMessage = "";
        state.isLoading = true;
      })
      .addCase(editReorderById.rejected, (state) => {
        state.resError = "Something went wrong!";
        state.isSuccess = false;
        state.successMessage = "";
        state.isLoading = false;
      })
      .addCase(editReorderById.fulfilled, (state, action) => {
        state.isLoading = false;
        state.isSuccess = true;
        if (!action.payload.isSuccess) {
          state.resError = action?.payload?.errors?.[0];
        } else {
          const updatedReorder = action.payload?.reorder;
          state.reorderData = (state.reorderData || []).map((co) => {
            return co?.id === updatedReorder?.id ? updatedReorder : co;
          });
          state.successMessage = "Reorder successfully updated.";
        }
      })

      .addCase(editReorderRecipientById.pending, (state) => {
        state.isSuccess = false;
        state.isLoading = true;
        state.reqError = null;
        state.resError = null;
        state.successMessage = "";
      })
      .addCase(editReorderRecipientById.rejected, (state) => {
        state.resError = "Something went wrong!";
        state.isSuccess = false;
        state.successMessage = "";
        state.isLoading = false;
      })
      .addCase(editReorderRecipientById.fulfilled, (state, action) => {
        state.isLoading = false;
        state.isSuccess = true;
        if (!action.payload.isSuccess) {
          state.resError = action.payload?.errors?.[0];
        } else {
          state.reorderData =
            (state.reorderData || [])?.map((m) =>
              m.id === action?.payload?.reorder?.id ? action.payload.reorder : m
            ) || [];
          state.successMessage = "Recipient successfully updated.";
        }
      })

      .addCase(deleteReorderById.pending, (state) => {
        state.resError = "";
        state.isSuccess = false;
        state.successMessage = "";
        state.isLoading = true;
      })
      .addCase(deleteReorderById.rejected, (state) => {
        state.resError = "Something went wrong!";
        state.isSuccess = false;
        state.successMessage = "";
        state.isLoading = false;
      })
      .addCase(deleteReorderById.fulfilled, (state, action) => {
        state.resError = "";
        state.isSuccess = true;
        if (!action.payload.isSuccess) {
          state.resError = action?.payload?.errors?.[0];
        } else {
          state.successMessage = "Reorder Deleted Successfully.";
        }
        state.isLoading = false;
      }),
});

export const { resetState, resetStateisSuccess } = reorderSlice.actions;
export const getReorderState = (state: RootState) => state.reorder;
export const getReorderDataById = (state: RootState, reorderId: string) =>
  state.reorder?.reorderData?.find((f) => f?.id === reorderId) || null;

export default reorderSlice.reducer;
