import {
  createQuestion,
  deleteQuestions,
  editQuestions,
  getAllQuestions,
} from "@/src/apis/questionApis";
import { createSlice } from "@reduxjs/toolkit";
import { RootState } from "@store/index";
import { OnlyQuestion, ReduxStateType } from "@utils/types";

type QuestionsState = {
  questionsData: OnlyQuestion | null;
};

const initialState: QuestionsState & ReduxStateType = {
  questionsData: null,
  isSuccess: false,
  isLoading: false,
  successMessage: "",
  reqError: "",
  resError: "",
};

export const questionsSlice = createSlice({
  name: "questions",
  initialState,
  reducers: {
    resetState: (state) => {
      state.isSuccess = false;
      state.isLoading = false;
      state.successMessage = "";
      state.reqError = "";
      state.resError = "";
    },
    resetStateisSuccess: (state) => {
      state.isSuccess = false;
    },
  },
  extraReducers: (builder) =>
    builder
      .addCase(getAllQuestions.pending, (state) => {
        state.isLoading = true;
      })
      .addCase(getAllQuestions.rejected, (state) => {
        state.isLoading = false;
        state.isSuccess = false;
      })
      .addCase(getAllQuestions.fulfilled, (state, action) => {
        state.isLoading = false;
        state.isSuccess = true;
        state.questionsData = action.payload;
      })
      .addCase(createQuestion.pending, (state) => {
        state.isLoading = true;
        state.isSuccess = false;
      })
      .addCase(createQuestion.rejected, (state) => {
        state.isLoading = false;
        state.isSuccess = false;
        state.reqError = "Something went wrong!";
      })
      .addCase(createQuestion.fulfilled, (state, action) => {
        state.isLoading = false;
        state.isSuccess = action.payload.isSuccess;
        if (action.payload.errors.length > 0) {
          state.resError = action?.payload?.errors[0];
          return;
        }
        state.successMessage = "Questions have been created successfully.";
        action.payload?.qualityQuestions?.map((question) => {
          state.questionsData?.qualityQuestions?.push(question);
        });
      })
      .addCase(editQuestions.pending, (state) => {
        state.isLoading = true;
      })
      .addCase(editQuestions.rejected, (state) => {
        state.isLoading = false;
        state.reqError = "Something went wrong!";
      })
      .addCase(editQuestions.fulfilled, (state, action) => {
        state.isLoading = false;
        state.isSuccess = true;
        state.successMessage = "Questions have been updated successfully.";
        if (action.payload.errors.length > 0) {
          state.resError = action?.payload?.errors[0];
        }
        if (state.questionsData) {
          state.questionsData.qualityQuestions =
            action.payload?.qualityQuestions;
        }
      })

      .addCase(deleteQuestions.pending, (state) => {
        state.isLoading = true;
      })
      .addCase(deleteQuestions.rejected, (state) => {
        state.isLoading = false;
        state.isSuccess = false;
        state.reqError = "Something went wrong!";
      })
      .addCase(deleteQuestions.fulfilled, (state) => {
        state.isLoading = false;
        state.isSuccess = true;
        state.successMessage = "Questions have been deleted successfully.";
        if (state.questionsData) {
          state.questionsData.qualityQuestions = null;
        }
      }),
});

export const getQuestionsState = (state: RootState) => state.questions;
export const { resetState, resetStateisSuccess } = questionsSlice.actions;

export default questionsSlice.reducer;
