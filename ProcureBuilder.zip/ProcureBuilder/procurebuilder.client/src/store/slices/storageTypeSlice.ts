import {
  createStorageType,
  getAllStorageTypes,
  updateStorageType,
} from "@/src/apis/storageTypeApis";
import { createSlice } from "@reduxjs/toolkit";
import { RootState } from "@store/index";
import { ReduxStateType, StorageType } from "@utils/types";

type TypesState = {
  storageTypesData: StorageType[] | null;
};

const initialState: TypesState & ReduxStateType = {
  storageTypesData: null,
  isSuccess: false,
  isLoading: false,
  reqError: null,
  resError: null,
};

const resetIntialValues = (state: any) => {
  state.isSuccess = false;
  state.isLoading = false;
  state.reqError = null;
  state.resError = null;
  state.successMessage = "";
};

export const storageTypesSlice = createSlice({
  name: "storageTypes",
  initialState,
  reducers: {
    resetState: (state) => {
      state.isSuccess = false;
      state.isLoading = false;
      state.reqError = null;
      state.resError = null;
      state.successMessage = "";
    },
  },
  extraReducers: (builder) =>
    builder
      .addCase(getAllStorageTypes.pending, (state) => {
        state.isLoading = true;
      })
      .addCase(getAllStorageTypes.rejected, (state) => {
        state.isLoading = false;
      })
      .addCase(getAllStorageTypes.fulfilled, (state, action) => {
        state.storageTypesData = action?.payload?.storageTypes || [];
        state.isLoading = false;
      })
      .addCase(createStorageType.pending, (state) => {
        resetIntialValues(state);
      })

      .addCase(createStorageType.rejected, (state) => {
        state.isLoading = false;
        state.isSuccess = false;
        state.reqError = "Something went wrong!";
      })
      .addCase(createStorageType.fulfilled, (state, action) => {
        state.isLoading = false;

        state.isSuccess = action?.payload?.isSuccess;

        if (!action?.payload?.isSuccess) {
          state.resError = action?.payload?.errors[0] || "";
        }

        if (action.payload.isSuccess) {
          state.storageTypesData?.unshift(action?.payload?.storageType);
          state.successMessage = "Storage type created successfully.";
        }
      })
      .addCase(updateStorageType.pending, (state) => {
        resetIntialValues(state);
      })

      .addCase(updateStorageType.rejected, (state) => {
        state.isLoading = false;
        state.isSuccess = false;
        state.reqError = "Something went wrong!";
      })
      .addCase(updateStorageType.fulfilled, (state, action) => {
        state.isLoading = false;

        state.isSuccess = action?.payload?.isSuccess;

        if (!action?.payload?.isSuccess) {
          state.resError = action?.payload?.errors[0] || "";
        }

        if (action.payload.isSuccess) {
          state.storageTypesData =
            state.storageTypesData?.map((f) =>
              f.id === action.payload.storageType.id
                ? action.payload.storageType
                : f
            ) || [];
          state.successMessage = "Storage type Updated successfully.";
        }
      }),
});
export const { resetState } = storageTypesSlice.actions;
export const getStorageTypesState = (state: RootState) => state.storageTypes;
export const getStorageTypeNameById = (state: RootState, typeId: string) =>
  state.storageTypes?.storageTypesData?.find((f) => f.id === typeId)?.name;

export default storageTypesSlice.reducer;
