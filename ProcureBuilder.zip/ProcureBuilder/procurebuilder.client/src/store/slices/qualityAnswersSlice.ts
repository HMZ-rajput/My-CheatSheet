import {
  createQualityAnswers,
  deleteQualityAnswers,
  getAllQualityAnswers,
  updateQualityAnswers,
} from "@/src/apis/qualityAnswers";
import { createSlice } from "@reduxjs/toolkit";
import { RootState } from "@store/index";
import { QualityQuestionAnswers, ReduxStateType } from "@utils/types";

type AnswersState = {
  qualityAnswers: QualityQuestionAnswers[] | null;
};

const initialState: AnswersState & ReduxStateType = {
  qualityAnswers: null,
  isSuccess: false,
  isLoading: false,
  successMessage: "",
  reqError: "",
  resError: "",
};

export const answersSlice = createSlice({
  name: "answers",
  initialState,
  reducers: {
    resetState: (state) => {
      state.isSuccess = false;
      state.isLoading = false;
      state.successMessage = "";
      state.reqError = "";
      state.resError = "";
    },
    resetStateisSuccess: (state) => {
      state.isSuccess = false;
    },
  },
  extraReducers: (builder) =>
    builder
      .addCase(getAllQualityAnswers.pending, (state) => {
        state.isLoading = true;
      })
      .addCase(getAllQualityAnswers.rejected, (state) => {
        state.isLoading = false;
        state.isSuccess = false;
      })
      .addCase(getAllQualityAnswers.fulfilled, (state, action) => {
        state.isLoading = false;
        state.isSuccess = true;
        if (action.payload.errors.length > 0) {
          state.resError = action?.payload?.errors[0];
          return;
        }
        state.qualityAnswers = action.payload.qualityAnswers;
      })

      .addCase(createQualityAnswers.pending, (state) => {
        state.isLoading = true;
        state.isSuccess = false;
      })
      .addCase(createQualityAnswers.rejected, (state) => {
        state.isLoading = false;
        state.isSuccess = false;
        state.reqError = "Something went wrong!";
      })
      .addCase(createQualityAnswers.fulfilled, (state, action) => {
        state.isLoading = false;
        state.isSuccess = action.payload.isSuccess;
        if (action.payload.errors.length > 0) {
          state.resError = action?.payload?.errors[0];
          return;
        }
        state.qualityAnswers = action.payload.qualityAnswers;
        state.successMessage = "Answers have been created successfully.";
      })

      .addCase(updateQualityAnswers.pending, (state) => {
        state.isLoading = true;
      })
      .addCase(updateQualityAnswers.rejected, (state) => {
        state.isLoading = false;
        state.reqError = "Something went wrong!";
      })
      .addCase(updateQualityAnswers.fulfilled, (state, action) => {
        state.isLoading = false;
        state.isSuccess = true;
        if (action.payload.errors.length > 0) {
          state.resError = action?.payload?.errors[0];
          return;
        }
        state.qualityAnswers = action.payload.qualityAnswers;
        state.successMessage = "Answers have been updated successfully.";
      })

      .addCase(deleteQualityAnswers.pending, (state) => {
        state.isLoading = true;
      })
      .addCase(deleteQualityAnswers.rejected, (state) => {
        state.isLoading = false;
        state.isSuccess = false;
        state.reqError = "Something went wrong!";
      })
      .addCase(deleteQualityAnswers.fulfilled, (state, action) => {
        state.isLoading = false;
        state.isSuccess = true;
        if (action.payload.errors.length > 0) {
          state.resError = action?.payload?.errors[0];
          return;
        }
        state.successMessage = "Answers have been deleted successfully.";
      }),
});

export const getAnswersState = (state: RootState) => state.answers;
export const { resetState, resetStateisSuccess } = answersSlice.actions;

export default answersSlice.reducer;
