import { createSlice } from "@reduxjs/toolkit";
import { RootState } from "@store/index";
import {
  ChangeOrder,
  PaginationProperties,
  ReduxStateType,
} from "@utils/types";
import {
  createChangeOrder,
  deleteChangeOrderById,
  editChangeOrderById,
  getAllChangeOrders,
  getApprovedChangeOrdersByProject,
  getChangeOrderById,
  getChangeOrdersByProject,
} from "@/src/apis/changeOrderApis";

type ChangeOrderState = {
  changeOrderData: ChangeOrder[] | null;
};

const initialState: ChangeOrderState & PaginationProperties & ReduxStateType = {
  changeOrderData: null,
  isSuccess: false,
  isLoading: false,
  reqError: "",
  resError: "",
  currentPage: 1,
  hasNext: false,
  hasPrevious: false,
  pageSize: 10,
  totalCount: 10,
  totalPages: 1,
};

export const changeOrderSlice = createSlice({
  name: "changeOrders",
  initialState,
  reducers: {
    resetState: (state) => {
      state.isSuccess = false;
      state.isLoading = false;
      state.reqError = null;
      state.resError = null;
      state.successMessage = "";
    },
    resetStateisSuccess: (state) => {
      state.isSuccess = false;
    },
  },
  extraReducers: (builder) =>
    builder
      .addCase(getAllChangeOrders.pending, (state) => {
        state.isSuccess = false;
        state.successMessage = "";
        state.reqError = "";
        state.resError = "";
        state.isLoading = true;
      })
      .addCase(getAllChangeOrders.rejected, (state) => {
        state.resError = "Something went wrong!";
        state.isSuccess = false;
        state.successMessage = "";
        state.isLoading = false;
      })
      .addCase(getAllChangeOrders.fulfilled, (state, action) => {
        state.changeOrderData = action.payload?.changeOrders || [];
        state.currentPage = action?.payload?.currentPage;
        state.pageSize = action?.payload?.pageSize;
        state.totalCount = action?.payload?.totalCount;
        state.totalPages = action?.payload?.totalPages;
        state.isLoading = false;
        state.isSuccess = true;
        state.successMessage = "";
      })

      .addCase(getChangeOrdersByProject.pending, (state) => {
        state.successMessage = "";
        state.reqError = "";
        state.resError = "";
        state.isSuccess = false;
        state.isLoading = true;
      })
      .addCase(getChangeOrdersByProject.rejected, (state) => {
        state.resError = "Something went wrong!";
        state.isSuccess = false;
        state.successMessage = "";
        state.isLoading = false;
      })
      .addCase(getChangeOrdersByProject.fulfilled, (state, action) => {
        state.changeOrderData = action.payload?.changeOrders || [];
        state.isLoading = false;
        state.isSuccess = true;
        state.successMessage = "";
      })

      .addCase(getApprovedChangeOrdersByProject.pending, (state) => {
        state.resError = "";
        state.isSuccess = false;
        state.successMessage = "";
        state.isLoading = true;
      })
      .addCase(getApprovedChangeOrdersByProject.rejected, (state) => {
        state.resError = "Something went wrong!";
        state.isSuccess = false;
        state.successMessage = "";
        state.isLoading = false;
      })
      .addCase(getApprovedChangeOrdersByProject.fulfilled, (state, action) => {
        state.changeOrderData = action.payload?.changeOrders || [];
        state.isLoading = false;
        state.isSuccess = true;
        state.successMessage = "";
      })

      .addCase(getChangeOrderById.pending, (state) => {
        state.resError = "";
        state.isSuccess = false;
        state.successMessage = "";
        state.isLoading = true;
      })
      .addCase(getChangeOrderById.rejected, (state) => {
        state.resError = "Something went wrong!";
        state.isSuccess = false;
        state.successMessage = "";
        state.isLoading = false;
      })
      .addCase(getChangeOrderById.fulfilled, (state, action) => {
        state.isLoading = false;
        state.isSuccess = action?.payload?.isSuccess;
        state.successMessage = "";

        if (action?.payload?.isSuccess) {
          if (Array.isArray(state.changeOrderData)) {
            state.changeOrderData = state.changeOrderData?.map((co) => {
              if (co?.id == action.payload?.changeOrder?.id) {
                return action.payload?.changeOrder;
              } else {
                return co;
              }
            });
          } else {
            state.changeOrderData = [action.payload?.changeOrder];
          }
        }
      })

      .addCase(createChangeOrder.pending, (state) => {
        state.isSuccess = false;
        state.successMessage = "";
        state.reqError = "";
        state.resError = "";
        state.isLoading = true;
      })
      .addCase(createChangeOrder.rejected, (state) => {
        state.resError = "Something went wrong!";
        state.isSuccess = false;
        state.successMessage = "";
        state.isLoading = false;
      })
      .addCase(createChangeOrder.fulfilled, (state, action) => {
        const { changeOrder } = action.payload;
        if (changeOrder && !(changeOrder instanceof FormData)) {
          state.changeOrderData?.push(changeOrder);
        }
        state.isLoading = false;
        state.isSuccess = true;
        if (!action.payload.isSuccess) {
          state.resError = action?.payload?.errors?.[0];
        } else {
          state.successMessage = "Change order successfully created.";
        }
      })

      .addCase(editChangeOrderById.pending, (state) => {
        state.isSuccess = false;
        state.successMessage = "";
        state.reqError = "";
        state.resError = "";
        state.isLoading = true;
      })
      .addCase(editChangeOrderById.rejected, (state) => {
        state.resError = "Something went wrong!";
        state.isSuccess = false;
        state.successMessage = "";
        state.isLoading = false;
      })
      .addCase(editChangeOrderById.fulfilled, (state, action) => {
        state.isLoading = false;
        state.isSuccess = true;
        if (!action.payload.isSuccess) {
          state.resError = action?.payload?.errors?.[0];
        } else {
          const updatedChangeOrder = action.payload?.changeOrder;
          state.changeOrderData = (state.changeOrderData || []).map((co) => {
            return co?.id === updatedChangeOrder?.id ? updatedChangeOrder : co;
          });
          state.successMessage = "Change order successfully updated.";
        }
      })

      .addCase(deleteChangeOrderById.pending, (state) => {
        state.isSuccess = false;
        state.successMessage = "";
        state.reqError = "";
        state.resError = "";
        state.isLoading = true;
      })
      .addCase(deleteChangeOrderById.rejected, (state) => {
        state.resError = "Something went wrong!";
        state.isSuccess = false;
        state.successMessage = "";
        state.isLoading = false;
      })
      .addCase(deleteChangeOrderById.fulfilled, (state, action) => {
        state.resError = "";
        state.isSuccess = true;
        state.successMessage = "";
        state.isLoading = false;
        if (!action.payload.isSuccess) {
          state.resError = action?.payload?.errors?.[0];
        } else {
          state.successMessage = "Change order successfully deleted.";
        }
      }),
});

export const { resetState, resetStateisSuccess } = changeOrderSlice.actions;
export const getChangeOrderState = (state: RootState) => state.changeOrders;
export const getChangeOrderByIdState = (
  state: RootState,
  changeOrderId: string
) =>
  state.changeOrders?.changeOrderData?.find((f) => f?.id === changeOrderId) ||
  null;

export default changeOrderSlice.reducer;
