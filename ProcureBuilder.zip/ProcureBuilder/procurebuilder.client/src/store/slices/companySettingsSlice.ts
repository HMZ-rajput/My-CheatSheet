import { createSlice } from "@reduxjs/toolkit";
import { RootState } from "@store/index";
import {
  CompanySettings,
  PurchaseOrderSettings,
  ReduxStateType,
  ReorderSettings,
} from "@utils/types";
import {
  editCompanyDetails,
  editPurchaseOrderDetails,
  editReorderDetails,
  getAllCompanyDetails,
  getAllPurchaseOrderDetails,
  getAllReorderDetails,
} from "@/src/apis/companySettingsApis";

type CompanyState = {
  companyData: CompanySettings | null;
  areCompanySettingsSuccessful: boolean;
  areCompanySettingsLoading: boolean;

  purchaseOrderData: PurchaseOrderSettings | null;
  arePurchaseOrderSettingsSuccessful: boolean;
  arePurchaseOrderSettingsLoading: boolean;

  reorderData: ReorderSettings | null;
  areReorderSettingsSuccessful: boolean;
  areReorderSettingsLoading: boolean;
};

const initialState: CompanyState & ReduxStateType = {
  companyData: null,
  areCompanySettingsSuccessful: false,
  areCompanySettingsLoading: false,

  purchaseOrderData: null,
  arePurchaseOrderSettingsSuccessful: false,
  arePurchaseOrderSettingsLoading: false,

  reorderData: null,
  areReorderSettingsSuccessful: false,
  areReorderSettingsLoading: false,

  reqError: "",
  resError: "",
  isSuccess: false,
  isLoading: false,
};

export const companySlice = createSlice({
  name: "companySettings",
  initialState,
  reducers: {
    resetState: (state) => {
      state.isSuccess = false;
      state.isLoading = false;
      state.reqError = null;
      state.resError = null;
      state.successMessage = "";
    },
    resetStateisSuccess: (state) => {
      state.isSuccess = false;
    },
  },
  extraReducers: (builder) =>
    builder
      // Company Settings
      .addCase(getAllCompanyDetails.pending, (state) => {
        state.areCompanySettingsSuccessful = false;
        state.isLoading = true;
      })
      .addCase(getAllCompanyDetails.rejected, (state) => {
        state.resError = "Something went wrong!";
        state.areCompanySettingsSuccessful = false;
        state.isLoading = false;
      })
      .addCase(getAllCompanyDetails.fulfilled, (state, action) => {
        state.companyData = action.payload?.companyInfo;
        state.isLoading = false;
      })

      .addCase(editCompanyDetails.pending, (state) => {
        state.resError = "";

        state.areCompanySettingsSuccessful = false;
        state.successMessage = "";
        state.isLoading = true;
      })
      .addCase(editCompanyDetails.rejected, (state) => {
        state.resError = "Something went wrong!";

        state.areCompanySettingsSuccessful = false;
        state.successMessage = "";
        state.isLoading = false;
      })
      .addCase(editCompanyDetails.fulfilled, (state, action) => {
        // state.areCompanySettingsSuccessful = true;
        state.isSuccess = action?.payload?.isSuccess;
        state.companyData = action?.payload?.companyInfo;
        if (!action?.payload?.isSuccess) {
          state.resError = action?.payload?.errors[0] || "";
          return;
        }
        if (action?.payload?.isSuccess) {
          state.successMessage =
            "Company settings have been updated successfully.";
          return;
        }
      })

      //Purchase Order Settings
      .addCase(getAllPurchaseOrderDetails.pending, (state) => {
        state.resError = "";
        state.arePurchaseOrderSettingsSuccessful = false;
        state.isLoading = true;
      })
      .addCase(getAllPurchaseOrderDetails.rejected, (state) => {
        state.resError = "Something went wrong!";
        state.arePurchaseOrderSettingsSuccessful = false;
        state.isLoading = false;
      })
      .addCase(getAllPurchaseOrderDetails.fulfilled, (state, action) => {
        // state.arePurchaseOrderSettingsSuccessful = true;
        state.purchaseOrderData = action.payload?.settings;
        state.isLoading = false;
      })

      .addCase(editPurchaseOrderDetails.pending, (state) => {
        state.resError = "";
        state.arePurchaseOrderSettingsSuccessful = false;
        state.successMessage = "";
        state.isLoading = true;
      })
      .addCase(editPurchaseOrderDetails.rejected, (state) => {
        state.resError = "Something went wrong!";

        state.arePurchaseOrderSettingsSuccessful = false;
        state.successMessage = "";
        state.isLoading = false;
      })
      .addCase(editPurchaseOrderDetails.fulfilled, (state, action) => {
        // state.arePurchaseOrderSettingsSuccessful = true;
        state.isSuccess = action?.payload?.isSuccess;
        state.purchaseOrderData = action?.payload?.settings;
        if (!action?.payload?.isSuccess) {
          state.resError = action?.payload?.errors[0] || "";
          return;
        }
        if (action?.payload?.isSuccess) {
          state.successMessage =
            "Purchase order settings have been updated successfully.";
          return;
        }
      })

      //Reorder Settings
      .addCase(getAllReorderDetails.pending, (state) => {
        state.resError = "";
        state.areReorderSettingsSuccessful = false;
        state.successMessage = "";
        state.isLoading = true;
      })
      .addCase(getAllReorderDetails.rejected, (state) => {
        state.resError = "Something went wrong!";
        state.areReorderSettingsSuccessful = false;
        state.successMessage = "";
        state.isLoading = false;
      })
      .addCase(getAllReorderDetails.fulfilled, (state, action) => {
        // state.areReorderSettingsSuccessful = true;
        state.successMessage = "";
        state.reorderData = action.payload;
        state.isLoading = false;
      })

      .addCase(editReorderDetails.pending, (state) => {
        state.resError = "";

        state.areReorderSettingsSuccessful = false;
        state.successMessage = "";
        state.isLoading = true;
      })
      .addCase(editReorderDetails.rejected, (state) => {
        state.resError = "Something went wrong!";

        state.areReorderSettingsSuccessful = false;
        state.successMessage = "";
        state.isLoading = false;
      })
      .addCase(editReorderDetails.fulfilled, (state, action) => {
        state.isSuccess = action?.payload?.isSuccess;
        // state.areReorderSettingsSuccessful = true;
        state.reorderData = action?.payload;
        if (!action?.payload?.isSuccess) {
          state.resError = action?.payload?.errors[0] || "";
          return;
        }
        if (action?.payload?.isSuccess) {
          state.successMessage =
            "Reorder settings have been updated successfully.";
          return;
        }
      }),
});

export const { resetState, resetStateisSuccess } = companySlice.actions;
export const getCompanyState = (state: RootState) => state.company;
export const getCompanyData = (state: RootState) => state.company?.companyData;

export const getPurchaseOrderData = (state: RootState) =>
  state.company?.purchaseOrderData;

export const getReOrderData = (state: RootState) => state.company?.reorderData;

export default companySlice.reducer;
