import { createProjectType, UpdateProjectType } from "@/src/apis/projectApis";
import { getAllProjectTypes } from "@/src/apis/projectTypeApis";
import { createSlice } from "@reduxjs/toolkit";
import { RootState } from "@store/index";
import { ProjectType, ReduxStateType } from "@utils/types";

type TypesState = {
  typesData: ProjectType[] | null;
};

const initialState: TypesState & ReduxStateType = {
  typesData: null,
  isSuccess: false,
  isLoading: false,
  reqError: null,
  resError: null,
};

export const typesSlice = createSlice({
  name: "types",
  initialState,
  reducers: {
    resetState: (state) => {
      state.isSuccess = false;
      state.isLoading = false;
      state.reqError = null;
      state.resError = null;
    },
  },
  extraReducers: (builder) =>
    builder
      .addCase(getAllProjectTypes.pending, (state) => {
        state.isLoading = true;
      })
      .addCase(getAllProjectTypes.rejected, (state) => {
        state.isLoading = false;
      })
      .addCase(getAllProjectTypes.fulfilled, (state, action) => {
        state.typesData = action?.payload?.projectTypes || [];
        state.isLoading = false;
      })
      .addCase(createProjectType.pending, (state) => {
        state.isLoading = true;
        state.isSuccess = false;
      })

      .addCase(createProjectType.rejected, (state) => {
        state.isLoading = false;
        state.isSuccess = true;
        state.isSuccess = false;
        state.reqError = "Something went wrong!";
        // state.resError = action?.payload;
      })
      .addCase(createProjectType.fulfilled, (state, action) => {
        state.isLoading = false;

        state.isSuccess = action?.payload?.isSuccess;

        if (!action.payload.isSuccess) {
          state.resError = action?.payload?.errors?.[0];
        }

        if (action.payload.isSuccess) {
          state.successMessage = "Project Type created successfully.";
          state.typesData?.unshift(action?.payload?.projectType);
        }
      })
      .addCase(UpdateProjectType.pending, (state) => {
        state.isLoading = true;
        state.isSuccess = false;
      })

      .addCase(UpdateProjectType.rejected, (state) => {
        state.isLoading = false;
        state.isSuccess = true;
        state.isSuccess = false;
        state.reqError = "Something went wrong!";
        // state.resError = action?.payload;
      })
      .addCase(UpdateProjectType.fulfilled, (state, action) => {
        state.isLoading = false;

        state.isSuccess = action?.payload?.isSuccess;

        if (!action.payload.isSuccess) {
          state.resError = action?.payload?.errors?.[0];
        }

        if (action.payload.isSuccess) {
          state.successMessage = "Project Type Update successfully.";
          state.typesData =
            state.typesData?.map((f) =>
              f.id === action.payload.projectType.id
                ? action.payload.projectType
                : f
            ) || [];
        }
      }),
});
export const { resetState } = typesSlice.actions;
export const getTypesState = (state: RootState) => state.types;
export const getTypeNameById = (state: RootState, typeId: string) =>
  state.types?.typesData?.find((f) => f.id === typeId)?.name;

export default typesSlice.reducer;
