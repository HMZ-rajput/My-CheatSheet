import {
  createMaterialGoingToSite,
  deleteMaterialGoingToSiteById,
  editMaterialGoingToSiteById,
  getAllMaterialGoingToSite,
} from "@/src/apis/materialGoingToSiteApis";
import { getAllMaterialTransferlist } from "@/src/apis/materialTransferApis";
import { createSlice } from "@reduxjs/toolkit";
import { RootState } from "@store/index";
import {
  MaterialTransfer,
  MaterialTransferAddMaterial,
  PaginationProperties,
  ReduxStateType,
} from "@utils/types";
import dayjs from "dayjs";

type MaterialTransferState = {
  materialGoingToSiteData: MaterialTransfer[] | null;
  materialTransferList: MaterialTransferAddMaterial[] | null;
};

const initialState: MaterialTransferState &
  PaginationProperties &
  ReduxStateType = {
  materialGoingToSiteData: null,
  materialTransferList: null,
  isSuccess: false,
  successMessage: "",
  isLoading: false,
  reqError: "",
  resError: "",
  currentPage: 1,
  hasNext: false,
  hasPrevious: false,
  pageSize: 10,
  totalCount: 10,
  totalPages: 1,
};

export const materialToSiteSlice = createSlice({
  name: "materialGoingToSite",
  initialState,
  reducers: {
    resetState: (state) => {
      state.isSuccess = false;
      state.isLoading = false;
      state.reqError = null;
      state.resError = null;
      state.successMessage = "";
    },
    resetStateisSuccess: (state) => {
      state.isSuccess = false;
    },
  },
  extraReducers: (builder) =>
    builder
      // .addCase(getAllMaterialTransferlist.pending, (state) => {
      //   // state.resError = "";
      //   // state.isSuccess = false;
      //   // state.successMessage = "";
      //   // state.isLoading = true;
      // })
      // .addCase(getAllMaterialTransferlist.rejected, (state) => {
      //   // state.resError = "";
      //   // state.isSuccess = false;
      //   // // state.successMessage = "";
      //   // state.isLoading = false;
      // })
      .addCase(getAllMaterialTransferlist.fulfilled, (state, action) => {
        // state.isSuccess = true;
        // state.successMessage = "";
        state.materialTransferList = action.payload?.materials;
        // state.isLoading = false;
      })
      .addCase(getAllMaterialGoingToSite.pending, (state) => {
        state.resError = "";

        state.isSuccess = false;
        state.successMessage = "";
        state.isLoading = true;
      })
      .addCase(getAllMaterialGoingToSite.rejected, (state) => {
        state.resError = "";

        state.isSuccess = false;
        state.successMessage = "";
        state.isLoading = false;
      })
      .addCase(getAllMaterialGoingToSite.fulfilled, (state, action) => {
        state.resError = "";

        state.isSuccess = false;
        state.successMessage = "";
        state.materialGoingToSiteData = action.payload?.materialToSites;
        state.currentPage = action?.payload?.currentPage;
        state.pageSize = action?.payload?.pageSize;
        state.totalCount = action?.payload?.totalCount;
        state.totalPages = action?.payload?.totalPages;
        state.isLoading = false;
      })
      .addCase(createMaterialGoingToSite.pending, (state) => {
        state.resError = "";
        state.reqError = "";
        state.isSuccess = false;
        state.successMessage = "";
        state.isLoading = true;
      })
      .addCase(createMaterialGoingToSite.rejected, (state) => {
        state.reqError = "Failed to create material going to site.";
        state.isSuccess = false;
        state.successMessage = "";
        state.isLoading = false;
      })
      .addCase(createMaterialGoingToSite.fulfilled, (state, action) => {
        state.isSuccess = action?.payload?.isSuccess;
        if (!action?.payload?.isSuccess) {
          state.resError = action?.payload?.errors[0] || "";
        }
        if (action?.payload?.isSuccess) {
          state.materialGoingToSiteData = [
            ...(state.materialGoingToSiteData || []),
            {
              ...action.payload.materialToSite,
              transferDate: dayjs(
                action.payload.materialToSite.transferDate
              ).toDate(),
            },
          ];
          state.successMessage =
            "Material Going To Site Form has been successfully created.";
        }

        state.reqError = "";
        state.isLoading = false;
      })
      .addCase(deleteMaterialGoingToSiteById.pending, (state) => {
        state.resError = "";
        state.reqError = "";
        state.isSuccess = false;
        state.successMessage = "";
        state.isLoading = true;
      })
      .addCase(deleteMaterialGoingToSiteById.rejected, (state) => {
        state.reqError = "Failed to delete Material going to site.";
        state.isSuccess = false;
        state.successMessage = "";
        state.isLoading = false;
      })
      .addCase(deleteMaterialGoingToSiteById.fulfilled, (state, action) => {
        state.isSuccess = action.payload.isSuccess;
        state.isLoading = false;
        state.materialGoingToSiteData =
          state.materialGoingToSiteData?.filter(
            (materialToSite) => materialToSite?.id !== action.payload?.id
          ) || [];
        if (!action?.payload?.isSuccess) {
          state.resError = action?.payload?.errors[0] || "";
        }
        if (action?.payload?.isSuccess) {
          state.successMessage =
            "Material Going to site has been deleted successfully.";
        }
        state.reqError = "";
      })
      .addCase(editMaterialGoingToSiteById.pending, (state) => {
        state.resError = "";
        state.reqError = "";
        state.isSuccess = false;
        state.successMessage = "";
        state.isLoading = true;
      })
      .addCase(editMaterialGoingToSiteById.rejected, (state) => {
        state.reqError = "Failed to update material going to site.";
        state.isSuccess = false;
        state.successMessage = "";
        state.isLoading = false;
      })
      .addCase(editMaterialGoingToSiteById.fulfilled, (state, action) => {
        if (!action?.payload?.isSuccess) {
          state.resError = action?.payload?.errors[0] || "";
        }

        if (action?.payload?.isSuccess) {
          state.isSuccess = action?.payload?.isSuccess;
          state.successMessage =
            "Material Going To Site has been updated successfully.";
          if (state.materialGoingToSiteData) {
            state.materialGoingToSiteData = [
              ...state.materialGoingToSiteData?.map((mts) => {
                if (mts.id === action.payload.materialToSite.id) {
                  return {
                    ...mts,
                    ...action.payload.materialToSite,
                    transferDate: dayjs(
                      action.payload.materialToSite.transferDate
                    ).toDate(),
                  };
                }
                return mts;
              }),
            ];
          } else {
            state.materialGoingToSiteData = [
              {
                ...action.payload.materialToSite,
                transferDate: dayjs(
                  action.payload.materialToSite.transferDate
                ).toDate(),
              },
            ];
          }
        }
        state.reqError = "";
      }),
});

export const { resetState, resetStateisSuccess } = materialToSiteSlice.actions;
export const getMaterialGoingToSiteState = (state: RootState) =>
  state.materialGoingToSite;

// export const getMaterialTransferData = (state: RootState) =>
//   state.materialTransfer?.materialTransferData;

export const getMaterialGoingToSiteById = (
  state: RootState,
  materialGoingToSiteId: string
) =>
  state.materialGoingToSite?.materialGoingToSiteData?.find(
    (f) => f.id === materialGoingToSiteId
  ) || null;

export default materialToSiteSlice.reducer;
