import {
  deleteNotificationById,
  getDashboard,
  getDashboardByProjectId,
  getDashboardSideNotification,
  updateDashboardNotificationByEntityId,
} from "@/src/apis/dashboardApis";
import { createSlice, PayloadAction } from "@reduxjs/toolkit";
import { RootState } from "@store/index";
import { DashboardType, Notifications, ReduxStateType } from "@utils/types";

type DashboardState = {
  dashboardData: DashboardType | null;
  dashboardDataByProjectId: DashboardType | null;
  dashBoardSideNotifyData: Notifications[] | null;
  text: string;
};

const initialState: DashboardState & ReduxStateType = {
  dashboardData: null,
  dashBoardSideNotifyData: null,
  dashboardDataByProjectId: null,
  text: "",
  // dashBoardSideNotifyData: null,
  isSuccess: false,
  isLoading: false,
  reqError: "",
  resError: "",
};

export const dashboardSlice = createSlice({
  name: "dashboard",
  initialState,
  reducers: {
    resetState: (state) => {
      state.isSuccess = false;
      state.reqError = null;
      state.resError = null;
      state.successMessage = "";
      state.text = "";
    },
    resetStateisSuccess: (state) => {
      state.isSuccess = false;
    },
    updateDashboardData: (
      state,
      action: PayloadAction<{
        dashboard: DashboardType;
        isProjectDashboard: boolean;
      }>
    ) => {
      if (action.payload.isProjectDashboard) {
        state.dashboardDataByProjectId = action.payload.dashboard;
      } else {
        state.dashboardData = action.payload.dashboard;
      }
    },
    updatedDashBoardSideNotifyData: (
      state,
      action: PayloadAction<{ dashBoardSideNotifyData: Notifications[] }>
    ) => {
      state.dashBoardSideNotifyData = action.payload.dashBoardSideNotifyData;
    },
  },
  extraReducers: (builder) =>
    builder
      .addCase(getDashboard.pending, (state) => {
        state.isSuccess = false;
        state.isLoading = true;
      })
      .addCase(getDashboard.rejected, (state) => {
        state.isSuccess = false;
        state.isLoading = false;
      })
      .addCase(getDashboard.fulfilled, (state, action) => {
        state.dashboardData = action.payload?.dashboard;
        state.isLoading = false;
      })
      .addCase(getDashboardSideNotification.pending, (state) => {
        state.isSuccess = false;
      })
      .addCase(getDashboardSideNotification.rejected, (state) => {
        state.isSuccess = false;
      })

      .addCase(getDashboardSideNotification.fulfilled, (state, action) => {
        state.dashBoardSideNotifyData = action.payload?.weeklySideNotifications;
        state.isSuccess = action.payload?.isSuccess;
      })

      .addCase(getDashboardByProjectId.pending, (state) => {
        state.isLoading = true;
      })
      .addCase(getDashboardByProjectId.rejected, (state) => {
        state.isLoading = false;
      })
      .addCase(getDashboardByProjectId.fulfilled, (state, action) => {
        state.dashboardDataByProjectId = action.payload.dashboard;
        state.isLoading = false;
      })
      .addCase(updateDashboardNotificationByEntityId.pending, (state) => {
        state.resError = null;
        state.reqError = null;
        state.text = "";
      })
      .addCase(updateDashboardNotificationByEntityId.rejected, (state) => {
        state.reqError = "Something went wrong!";
      })
      .addCase(
        updateDashboardNotificationByEntityId.fulfilled,
        (state, action) => {
          if (action.payload.isSuccess) {
            state.text = action.payload.text;
          } else {
            state.resError = action.payload.errors[0] || "";
          }
        }
      )
      .addCase(deleteNotificationById.pending, (state) => {
        state.resError = null;
        state.reqError = null;
        state.text = "";
      })
      .addCase(deleteNotificationById.rejected, (state) => {
        state.reqError = "Something went wrong!";
      })
      .addCase(deleteNotificationById.fulfilled, (state, action) => {
        if (action.payload.isSuccess) {
          state.text = "Notification cleared successfully";
        } else {
          state.resError = action.payload.errors[0] || "";
        }
      }),
});
export const {
  resetState,
  resetStateisSuccess,
  updateDashboardData,
  updatedDashBoardSideNotifyData,
} = dashboardSlice.actions;
export const getDashboardState = (state: RootState) => state?.dashboard;
export const getDashboardDataByProjectId = (
  state: RootState,
  projectId: string
) =>
  state.dashboard?.dashboardDataByProjectId?.projectDetails?.id === projectId
    ? state.dashboard.dashboardDataByProjectId
    : null;
export default dashboardSlice.reducer;
