import { createSlice, PayloadAction } from "@reduxjs/toolkit";
import { RootState } from "@store/index";
import {
  MaterialReceiptInspectionMaterial,
  MaterialReceiptInspection,
  PaginationProperties,
  QualityQuestionAnswers,
  ReduxStateType,
} from "@utils/types";
import {
  createMaterialReceiptInspection,
  getAllMaterialReceiptInspections,
  getMaterialReceiptInspectionById,
  getMaterialReceiptInspectionsMaterialList,
  editMaterialReceiptInspectionById,
  deleteMaterialReceiptInspectionById,
  editMaterialPhotoById,
  deleteMaterialImageById,
  downloadPdf,
} from "@/src/apis/materialReceiptInceptionApis";

type MaterialReceiptInspectionState = {
  MaterialReceiptInspectionData: MaterialReceiptInspection[] | null;
  MaterialReceiptInspectionMaterialList:
    | MaterialReceiptInspectionMaterial[]
    | null;
};

const initialState: MaterialReceiptInspectionState &
  PaginationProperties &
  ReduxStateType = {
  MaterialReceiptInspectionData: null,
  MaterialReceiptInspectionMaterialList: null,
  isSuccess: false,
  isLoading: false,
  reqError: "",
  resError: "",
  currentPage: 1,
  hasNext: false,
  hasPrevious: false,
  pageSize: 10,
  totalCount: 10,
  totalPages: 1,
};

export const materialReceiptInspectionSlice = createSlice({
  name: "materialReceiptInspections",
  initialState,
  reducers: {
    resetState: (state) => {
      state.isSuccess = false;
      state.isLoading = false;
      state.reqError = null;
      state.resError = null;
      state.successMessage = "";
    },
    resetStateisSuccess: (state) => {
      state.isSuccess = false;
    },
    updateMriAnswersByMriId: (
      state,
      action: PayloadAction<{
        mriId: string;
        answers: QualityQuestionAnswers[];
      }>
    ) => {
      state.MaterialReceiptInspectionData =
        state.MaterialReceiptInspectionData?.map((mri) => {
          if (mri?.id === action?.payload?.mriId) {
            return {
              ...mri,
              qualityQuestions: action?.payload?.answers || [],
            };
          } else {
            return mri;
          }
        }) || [];
    },
  },
  extraReducers: (builder) =>
    builder
      .addCase(getAllMaterialReceiptInspections.pending, (state) => {
        state.isSuccess = false;
        state.isLoading = true;
      })
      .addCase(getAllMaterialReceiptInspections.rejected, (state) => {
        state.isSuccess = false;
        state.isLoading = false;
      })
      .addCase(getAllMaterialReceiptInspections.fulfilled, (state, action) => {
        state.MaterialReceiptInspectionData =
          action.payload?.materialReceiptInspections || null;
        state.currentPage = action?.payload?.currentPage;
        state.pageSize = action?.payload?.pageSize;
        state.totalCount = action?.payload?.totalCount;
        state.totalPages = action?.payload?.totalPages;
        state.isLoading = false;
        state.isSuccess = true;
      })

      .addCase(getMaterialReceiptInspectionById.pending, (state) => {
        state.isSuccess = false;
        state.isLoading = true;
      })
      .addCase(getMaterialReceiptInspectionById.rejected, (state) => {
        state.isSuccess = false;
        state.isLoading = false;
      })
      .addCase(getMaterialReceiptInspectionById.fulfilled, (state, action) => {
        state.isLoading = false;
        state.isSuccess = true;
        state.successMessage = "";
        if (action?.payload?.isSuccess) {
          state.MaterialReceiptInspectionData = [
            // ...(state.MaterialReceiptInspectionData || [])?.filter(
            //   (mri) => mri?.id !== action.payload?.materialReceiptInspection?.id
            // ),
            action.payload?.materialReceiptInspection,
          ];
        }
      })

      .addCase(getMaterialReceiptInspectionsMaterialList.pending, (state) => {
        state.isSuccess = false;
        state.isLoading = true;
      })
      .addCase(getMaterialReceiptInspectionsMaterialList.rejected, (state) => {
        state.isSuccess = false;
        state.isLoading = false;
      })
      .addCase(
        getMaterialReceiptInspectionsMaterialList.fulfilled,
        (state, action) => {
          state.MaterialReceiptInspectionMaterialList =
            action.payload?.materials || null;
          state.isLoading = false;
          state.isSuccess = true;
          state.successMessage = "";
        }
      )

      .addCase(createMaterialReceiptInspection.pending, (state) => {
        state.resError = "";
        state.isSuccess = false;
        state.successMessage = "";
        state.isLoading = true;
      })
      .addCase(createMaterialReceiptInspection.rejected, (state) => {
        state.resError = "Something went wrong!";
        state.isSuccess = false;
        state.successMessage = "";
        state.isLoading = false;
      })
      .addCase(createMaterialReceiptInspection.fulfilled, (state, action) => {
        const { materialReceiptInspection } = action.payload;
        if (
          materialReceiptInspection &&
          !(materialReceiptInspection instanceof FormData)
        ) {
          state.MaterialReceiptInspectionData?.push(materialReceiptInspection);
        }
        state.isLoading = false;
        state.isSuccess = true;
        if (!action.payload.isSuccess) {
          state.resError = action?.payload?.errors?.[0];
        } else {
          state.successMessage =
            "Material Receipt Inspection successfully created.";
        }
      })

      .addCase(editMaterialReceiptInspectionById.pending, (state) => {
        state.resError = "";
        state.isSuccess = false;
        state.successMessage = "";
        state.isLoading = true;
      })
      .addCase(editMaterialReceiptInspectionById.rejected, (state) => {
        state.resError = "Something went wrong!";
        state.isSuccess = false;
        state.successMessage = "";
        state.isLoading = false;
      })
      .addCase(editMaterialReceiptInspectionById.fulfilled, (state, action) => {
        state.isLoading = false;
        state.isSuccess = true;
        if (!action.payload.isSuccess) {
          state.resError = action?.payload?.errors?.[0];
        } else {
          const updatedMaterialReceiptInspection =
            action.payload?.materialReceiptInspection;
          state.MaterialReceiptInspectionData = (
            state.MaterialReceiptInspectionData || []
          ).map((mri) => {
            return mri?.id === updatedMaterialReceiptInspection?.id
              ? updatedMaterialReceiptInspection
              : mri;
          });
          state.successMessage =
            "Material Receipt Inspection successfully updated.";
        }
      })

      .addCase(editMaterialPhotoById.pending, (state) => {
        state.resError = "";
        state.isSuccess = false;
        state.successMessage = "";
        state.isLoading = true;
      })
      .addCase(editMaterialPhotoById.rejected, (state) => {
        state.resError = "Something went wrong!";
        state.isSuccess = false;
        state.successMessage = "";
        state.isLoading = false;
      })
      .addCase(editMaterialPhotoById.fulfilled, (state, action) => {
        state.isLoading = false;
        state.isSuccess = true;
        if (!action.payload.isSuccess) {
          state.resError = action?.payload?.errors?.[0];
        } else {
          state.MaterialReceiptInspectionData =
            state.MaterialReceiptInspectionData?.map((mri) => {
              if (mri?.id === action?.payload?.materialReceiptInspectionId) {
                return {
                  ...mri,
                  documents: action?.payload?.materialImages || [],
                };
              } else {
                return mri;
              }
            }) || [];
          state.successMessage = "Material Photos successfully updated.";
        }
      })

      .addCase(deleteMaterialReceiptInspectionById.pending, (state) => {
        state.resError = "";
        state.isSuccess = false;
        state.successMessage = "";
        state.isLoading = true;
      })
      .addCase(deleteMaterialReceiptInspectionById.rejected, (state) => {
        state.resError = "Something went wrong!";
        state.isSuccess = false;
        state.successMessage = "";
        state.isLoading = false;
      })
      .addCase(
        deleteMaterialReceiptInspectionById.fulfilled,
        (state, action) => {
          state.resError = "";
          state.isSuccess = true;
          if (!action.payload.isSuccess) {
            state.resError = action?.payload?.errors?.[0];
          } else {
            state.successMessage =
              "Material Receipt Inspection Deleted Successfully.";
          }
          state.isLoading = false;
        }
      )

      .addCase(deleteMaterialImageById.pending, (state) => {
        state.resError = "";
        state.isSuccess = false;
        state.successMessage = "";
        state.isLoading = true;
      })
      .addCase(deleteMaterialImageById.rejected, (state) => {
        state.resError = "Something went wrong!";
        state.isSuccess = false;
        state.successMessage = "";
        state.isLoading = false;
      })
      .addCase(deleteMaterialImageById.fulfilled, (state, action) => {
        state.resError = "";
        state.isSuccess = true;
        if (!action.payload.isSuccess) {
          state.resError = action?.payload?.errors?.[0];
        } else {
          state.successMessage =
            "Material Receipt Inspection Deleted Successfully.";
        }
        state.isLoading = false;
      })

      .addCase(downloadPdf.pending, (state) => {
        state.resError = "";
        state.isSuccess = false;
        state.successMessage = "";
        state.isLoading = true;
      })
      .addCase(downloadPdf.rejected, (state) => {
        state.resError = "Something went wrong!";
        state.isSuccess = false;
        state.successMessage = "";
        state.isLoading = false;
      })
      .addCase(downloadPdf.fulfilled, (state) => {
        state.resError = "";
        state.isSuccess = true;
        state.isLoading = false;
      }),
});

export const { updateMriAnswersByMriId, resetState, resetStateisSuccess } =
  materialReceiptInspectionSlice.actions;
export const getMaterialReceiptInspectionState = (state: RootState) =>
  state.materialReceiptInspection;
export const getMaterialReceiptInspectionStateById = (
  state: RootState,
  MaterialReceiptInspectionId: string
) =>
  state.materialReceiptInspection?.MaterialReceiptInspectionData?.find(
    (f) => f?.id === MaterialReceiptInspectionId
  ) || null;

export default materialReceiptInspectionSlice.reducer;
