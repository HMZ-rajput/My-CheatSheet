import {
  addCustomerToProject,
  createProject,
  deleteProjectById,
  editProjectById,
  // editProjectById,
  getAllProjects,
  // getProjectById,
  getSummarizedProjectsList,
  updateUserAccessById,
} from "@/src/apis/projectApis";
import { createSlice, PayloadAction } from "@reduxjs/toolkit";
import { RootState } from "@store/index";
import {
  PaginationProperties,
  Project,
  ReduxStateType,
  SummarizedProject,
} from "@utils/types";

type ProjectsState = {
  projectsData: Project[] | null;
  projectsSummarizedData: SummarizedProject[] | null;

  isUserAccessSuccessful?: boolean;
  isUserAccessLoading?: boolean;
};

const initialState: ProjectsState & PaginationProperties & ReduxStateType = {
  projectsData: null,
  projectsSummarizedData: null,
  isSuccess: false,
  successMessage: "",
  isLoading: false,
  reqError: "",
  resError: "",
  currentPage: 1,
  hasNext: false,
  hasPrevious: false,
  pageSize: 10,
  totalCount: 10,
  totalPages: 1,

  isUserAccessSuccessful: false,
  isUserAccessLoading: false,
};

export const projectsSlice = createSlice({
  name: "projects",
  initialState,
  reducers: {
    createProjectDraft: (state, action: PayloadAction<SummarizedProject>) => {
      const draftProject = state.projectsSummarizedData?.find((p) => p.isDraft);

      if (!draftProject) {
        state.projectsSummarizedData?.push(action.payload);

        return;
      }
    },
    deleteDraftProject: (state) => {
      state.projectsSummarizedData =
        state.projectsSummarizedData?.filter((project) => !project.isDraft) ||
        null;
    },
    resetState: (state) => {
      state.isSuccess = false;
      state.isLoading = false;
      state.reqError = null;
      state.resError = null;
      state.successMessage = "";
    },
    resetStateisSuccess: (state) => {
      state.isSuccess = false;
    },
    updateProject(state, action) {
      state.projectsData =
        state.projectsData?.map((project) =>
          project.id === action.payload?.projectId
            ? { ...project, customer: undefined }
            : project
        ) || null;
    },
  },
  extraReducers: (builder) =>
    builder
      .addCase(getAllProjects.pending, (state) => {
        state.isSuccess = false;
        state.isLoading = true;
      })
      .addCase(getAllProjects.rejected, (state) => {
        state.isSuccess = false;
        state.isLoading = false;
      })
      .addCase(getAllProjects.fulfilled, (state, action) => {
        state.resError = "";

        state.isSuccess = false;
        state.successMessage = "";
        state.projectsData = action.payload?.projects;
        state.currentPage = action?.payload?.currentPage;
        state.pageSize = action?.payload?.pageSize;
        state.totalCount = action?.payload?.totalCount;
        state.totalPages = action?.payload?.totalPages;
        state.isLoading = false;
      })
      // Ustad Inshal said iss pay pending ka case kisi kaam ka nahi hai, instead
      // maslay kar raha hai by resetting isSuccess, which leads to no success message shown on Create Project screen.
      // - Ustad Inshal on October 15th, 2024.

      // .addCase(getSummarizedProjectsList.pending, (state) => {
      //   state.isSuccess = false;
      //   state.successMessage = "";
      //   state.isLoading = true;
      // })
      .addCase(getSummarizedProjectsList.rejected, (state) => {
        state.isSuccess = false;
        state.successMessage = "";
        state.isLoading = false;
      })
      .addCase(getSummarizedProjectsList.fulfilled, (state, action) => {
        state.isLoading = false;

        const draftProject = state.projectsSummarizedData?.find(
          (f) => f.isDraft
        );

        if (draftProject) {
          state.projectsSummarizedData = action.payload?.projects || null;

          if (Array.isArray(state.projectsSummarizedData)) {
            state.projectsSummarizedData.push(draftProject);
          }
        } else {
          state.projectsSummarizedData = action.payload?.projects || null;
        }
      })
      .addCase(createProject.pending, (state) => {
        state.resError = "";
        state.isSuccess = false;
        state.successMessage = "";
        state.isLoading = true;
      })
      .addCase(createProject.rejected, (state) => {
        state.reqError = "Something went wrong!";
        state.isSuccess = false;
        state.successMessage = "";
        state.isLoading = false;
      })
      .addCase(createProject.fulfilled, (state, action) => {
        state.isLoading = false;
        state.isSuccess = action?.payload?.isSuccess;
        if (action?.payload?.isSuccess) {
          state.successMessage = "Project has been created successfully.";
        }
        if (!action?.payload?.isSuccess) {
          state.resError = action?.payload?.errors[0];
        }
        state.projectsData?.push(action?.payload?.project);
      })
      .addCase(editProjectById.pending, (state) => {
        state.resError = "";
        state.isSuccess = false;
        state.successMessage = "";
        state.isLoading = true;
      })
      .addCase(editProjectById.rejected, (state) => {
        state.resError = "";
        state.isSuccess = false;
        state.successMessage = "";
        state.isLoading = false;
      })
      .addCase(editProjectById.fulfilled, (state, action) => {
        state.isLoading = false;
        state.isSuccess = action?.payload?.isSuccess;

        if (action?.payload?.isSuccess) {
          state.successMessage = "Project has been edited successfully.";
        }
        if (!action?.payload?.isSuccess) {
          state.resError = action?.payload?.errors[0];
        }

        const updatedProject = action.payload.project;
        state.projectsData = (state.projectsData || []).map((project) =>
          project?.id === updatedProject?.id ? updatedProject : project
        );
      })
      .addCase(deleteProjectById.pending, (state) => {
        state.resError = "";
        state.isSuccess = false;
        state.successMessage = "";
        state.isLoading = true;
      })
      .addCase(deleteProjectById.rejected, (state) => {
        state.reqError = "Something went wrong!";
        state.isSuccess = false;
        state.successMessage = "";
        state.isLoading = false;
      })
      .addCase(deleteProjectById.fulfilled, (state, action) => {
        state.isSuccess = false;
        state.successMessage = "";
        state.projectsData =
          state.projectsData?.filter(
            (project) => project?.id !== action.payload?.project?.id
          ) || [];
      })
      .addCase(addCustomerToProject.pending, (state) => {
        state.resError = "";

        state.isSuccess = false;
        state.successMessage = "";
        state.isLoading = true;
      })
      .addCase(addCustomerToProject.rejected, (state) => {
        state.isLoading = false;
        state.reqError = "Something went wrong!";
      })
      .addCase(addCustomerToProject.fulfilled, (state, action) => {
        state.resError = "";

        state.isSuccess = false;
        state.successMessage = "";
        state.isLoading = false;
        const updatedProject = action.payload.project;
        state.projectsData = (state.projectsData || []).map((project) =>
          project.id === updatedProject.id ? updatedProject : project
        );
      })
      .addCase(updateUserAccessById.pending, (state) => {
        state.isUserAccessLoading = true;
        state.isUserAccessSuccessful = false;
        state.isSuccess = false;
      })
      .addCase(updateUserAccessById.rejected, (state) => {
        state.isUserAccessLoading = false;
        state.isUserAccessSuccessful = false;
        state.isSuccess = false;
        state.reqError = "Something went wrong!";
      })
      .addCase(updateUserAccessById.fulfilled, (state, action) => {
        state.isUserAccessLoading = false;
        state.isUserAccessSuccessful = true;
        state.isSuccess = true;
        const { projectIds } = action.payload;
        state.projectsData = (state.projectsData || []).map((project) => {
          if (projectIds.includes(project.id)) {
            return {
              ...project,
              isAccessible: true,
            };
          }
          return project;
        });
        if (!action?.payload?.isSuccess) {
          state.resError = action?.payload?.errors[0];
        }
        if (action?.payload?.isSuccess) {
          state.successMessage =
            "Project access has been updated successfully.";
        }
      }),
});

export const { resetState, resetStateisSuccess, updateProject } =
  projectsSlice.actions;
export const getProjectsState = (state: RootState) => state?.projects;
export const getProjectDataById = (state: RootState, projectId: string) =>
  state.projects?.projectsData?.find((f) => f?.id === projectId) || null;

export const { createProjectDraft, deleteDraftProject } = projectsSlice.actions;
export default projectsSlice.reducer;
