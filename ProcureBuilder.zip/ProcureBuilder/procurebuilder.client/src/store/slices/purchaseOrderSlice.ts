import {
  createPurchaseOrder,
  createPurchaseOrderApprovals,
  deletePurchaseOrderById,
  getAllPurchaseOrders,
  getPurchaseOrdersById,
  getPurchaseOrdersList,
  getPurchaseOrderVendorById,
  updatePurchaseOrderById,
  updatePurchaseOrderProcurementDetails,
  updatePurchaseOrderVendor,
} from "@/src/apis/purchaseOrderApis";
import { createSlice } from "@reduxjs/toolkit";
import { RootState } from "@store/index";
import {
  PaginationProperties,
  PurchaseOrder,
  PurchaseOrderApprovalDetail,
  PurchaseOrderApprovalVendor,
  PurchaseOrderMaterials,
  PurchaseOrdersList,
  ReduxStateType,
} from "@utils/types";

type PurchaseOrdersState = {
  purchaseOrdersData: PurchaseOrder[] | null;
  purchaseOrdersList: PurchaseOrdersList[] | null;
  purchaseOrderApprovals: PurchaseOrderApprovalDetail | null;
  purchaseOrderMaterials: PurchaseOrderMaterials | null;
  purchaseOrderVendor: PurchaseOrderApprovalVendor | null;
};

const initialState: PurchaseOrdersState &
  PaginationProperties &
  ReduxStateType = {
  purchaseOrdersData: null,
  purchaseOrdersList: null,
  purchaseOrderMaterials: null,
  purchaseOrderApprovals: null,
  purchaseOrderVendor: null,
  isSuccess: false,
  successMessage: "",
  isLoading: false,
  reqError: "",
  resError: "",
  currentPage: 1,
  hasNext: false,
  hasPrevious: false,
  pageSize: 10,
  totalCount: 10,
  totalPages: 1,
};

export const purchaseOrdersSlice = createSlice({
  name: "purchaseOrders",
  initialState,
  reducers: {
    resetState: (state) => {
      state.isSuccess = false;
      state.isLoading = false;
      state.reqError = null;
      state.resError = null;
      state.successMessage = "";
    },
    resetStateisSuccess: (state) => {
      state.isSuccess = false;
    },
  },
  extraReducers: (builder) =>
    builder
      .addCase(getAllPurchaseOrders.pending, (state) => {
        state.isSuccess = false;
        state.isLoading = true;
      })
      .addCase(getAllPurchaseOrders.rejected, (state) => {
        state.isSuccess = false;
        state.isLoading = false;
      })
      .addCase(getAllPurchaseOrders.fulfilled, (state, action) => {
        state.isSuccess = false;
        state.purchaseOrdersData = action.payload?.purchaseOrders;
        state.currentPage = action?.payload?.currentPage;
        state.pageSize = action?.payload?.pageSize;
        state.totalCount = action?.payload?.totalCount;
        state.totalPages = action?.payload?.totalPages;
        state.isLoading = false;
      })

      .addCase(getPurchaseOrdersById.pending, (state) => {
        state.isSuccess = false;
        state.isLoading = true;
      })
      .addCase(getPurchaseOrdersById.rejected, (state) => {
        state.isSuccess = false;
        state.isLoading = false;
      })
      .addCase(getPurchaseOrdersById.fulfilled, (state, action) => {
        state.isLoading = false;
        state.isSuccess = true;
        if (action?.payload?.isSuccess) {
          state.purchaseOrdersData =
            state.purchaseOrdersData &&
            state.purchaseOrdersData?.map((po) => {
              if (po?.id == action.payload?.purchaseOrder?.id) {
                return action.payload?.purchaseOrder;
              } else {
                return po;
              }
            });
        }
      })

      .addCase(getPurchaseOrdersList.pending, (state) => {
        state.isSuccess = false;
        state.isLoading = true;
      })
      .addCase(getPurchaseOrdersList.rejected, (state) => {
        state.isSuccess = false;
        state.isLoading = false;
      })
      .addCase(getPurchaseOrdersList.fulfilled, (state, action) => {
        state.isSuccess = true;
        state.purchaseOrdersList = action?.payload?.purchaseOrders || [];
        state.isLoading = false;
      })
      .addCase(getPurchaseOrderVendorById.pending, (state) => {
        state.isSuccess = false;
        state.isLoading = true;
      })
      .addCase(getPurchaseOrderVendorById.rejected, (state) => {
        state.isSuccess = false;
        state.isLoading = false;
      })
      .addCase(getPurchaseOrderVendorById.fulfilled, (state, action) => {
        state.isSuccess = true;
        state.purchaseOrderVendor = action?.payload?.vendor;
        state.isLoading = false;
      })
      .addCase(createPurchaseOrder.pending, (state) => {
        state.resError = "";
        state.isSuccess = false;
        state.successMessage = "";
        state.reqError = "";
        state.isLoading = true;
      })
      .addCase(createPurchaseOrder.rejected, (state) => {
        state.resError = "";
        state.reqError = "Something went wrong!";
        state.isSuccess = false;
        state.successMessage = "";
        state.isLoading = false;
      })
      .addCase(createPurchaseOrder.fulfilled, (state, action) => {
        state.isLoading = false;
        if (!action?.payload?.isSuccess) {
          state.resError = action?.payload?.errors[0];
        } else if (action?.payload?.isSuccess) {
          state.isSuccess = action?.payload?.isSuccess;
          state.purchaseOrdersData?.push(action?.payload?.purchaseOrder);
          state.successMessage =
            "Purchase Order has been created successfully.";
        }
      })

      .addCase(createPurchaseOrderApprovals.pending, (state) => {
        state.resError = "";
        state.isSuccess = false;
        state.successMessage = "";
        state.isLoading = true;
      })
      .addCase(createPurchaseOrderApprovals.rejected, (state) => {
        state.resError = "";
        state.reqError = "Something went wrong!";
        state.isSuccess = false;
        state.successMessage = "";
        state.isLoading = false;
      })
      .addCase(createPurchaseOrderApprovals.fulfilled, (state, action) => {
        state.isLoading = false;
        if (!action?.payload?.isSuccess) {
          state.resError = action?.payload?.errors[0];
        } else if (action?.payload?.isSuccess) {
          state.isSuccess = action?.payload?.isSuccess;
          state.successMessage =
            "Purchase Order has been Approved successfully.";
        }
      })

      .addCase(updatePurchaseOrderVendor.pending, (state) => {
        state.resError = "";
        state.reqError = "";
        state.isSuccess = false;
        state.successMessage = "";
        state.isLoading = true;
      })
      .addCase(updatePurchaseOrderVendor.rejected, (state) => {
        state.resError = "";
        state.reqError = "Something went wrong!";
        state.isSuccess = false;
        state.successMessage = "";
        state.isLoading = false;
      })
      .addCase(updatePurchaseOrderVendor.fulfilled, (state, action) => {
        state.isLoading = false;
        console.log("state.purchaseOrdersData", state.purchaseOrdersData);

        if (!action?.payload?.isSuccess) {
          state.resError = action?.payload?.errors[0];
        } else if (action?.payload?.isSuccess) {
          state.isSuccess = action?.payload?.isSuccess;
          state.successMessage =
            "Purchase Order has been updated successfully.";

          const poId = action.payload?.purchaseOrderVendor?.id; // It's PurchaseOrder.Id not Vendor.Id.
          const vendor = action.payload?.purchaseOrderVendor.vendor;
          const vendorAddress =
            action.payload?.purchaseOrderVendor.vendorAddress;
          const hasPo = state.purchaseOrdersData?.some((s) => s.id === poId);

          if (hasPo) {
            state.purchaseOrdersData = (state.purchaseOrdersData || [])?.map(
              (purchaseOrder) =>
                purchaseOrder.id === poId
                  ? { ...purchaseOrder, vendor, vendorAddress }
                  : purchaseOrder
            );
          }
        }
      })
      .addCase(updatePurchaseOrderProcurementDetails.pending, (state) => {
        state.resError = "";
        state.isSuccess = false;
        state.successMessage = "";
        state.isLoading = true;
      })
      .addCase(updatePurchaseOrderProcurementDetails.rejected, (state) => {
        state.resError = "";
        state.reqError = "Something went wrong!";
        state.isSuccess = false;
        state.successMessage = "";
        state.isLoading = false;
      })
      .addCase(
        updatePurchaseOrderProcurementDetails.fulfilled,
        (state, action) => {
          state.isLoading = false;
          state.isSuccess = action?.payload?.isSuccess;

          if (action?.payload?.errors?.length > 0) {
            state.resError = action?.payload?.errors[0] || "";
            return;
          }
          state.successMessage =
            "Purchase Order Procurement Details has been updated successfully.";
          const purchaseOrder = state.purchaseOrdersData?.find(
            (purchaseOrder) => purchaseOrder.id === action.payload.id
          );
          if (!purchaseOrder || !action.payload.id) {
            // Handle the case where purchaseOrder or id is undefined
            return;
          }
          const updatePurchaseOrderProcurement = {
            ...purchaseOrder,
            id: purchaseOrder.id,
            ...action.payload.purchaseOrderProcurementUpdate,
          };

          state.purchaseOrdersData = (state.purchaseOrdersData || []).map(
            (purchaseOrder) =>
              purchaseOrder.id === updatePurchaseOrderProcurement.id
                ? updatePurchaseOrderProcurement
                : purchaseOrder
          );
        }
      )
      .addCase(updatePurchaseOrderById.pending, (state) => {
        state.resError = "";
        state.isSuccess = false;
        state.successMessage = "";
        state.isLoading = true;
      })
      .addCase(updatePurchaseOrderById.rejected, (state) => {
        state.isSuccess = false;
        state.successMessage = "";
        state.isLoading = false;
        state.reqError = "Something went wrong!";
      })
      .addCase(updatePurchaseOrderById.fulfilled, (state, action) => {
        state.isLoading = false;
        if (!action?.payload?.isSuccess) {
          state.resError = action?.payload?.errors[0];
        } else if (action?.payload?.isSuccess) {
          state.isSuccess = action?.payload?.isSuccess;
          state.successMessage =
            "Purchase Order  has been updated successfully.";
          if (!state.purchaseOrdersData) {
            return;
          }
          state.purchaseOrdersData = state?.purchaseOrdersData?.map((m) =>
            m.id === action.payload.purchaseOrder.id
              ? { ...m, ...action.payload.purchaseOrder }
              : m
          );
        }

        // const updatedPurchaseOrder = action.payload.purchaseOrder;
        // console.log("updatePurchaseOrderProcurement", updatedPurchaseOrder);
        // state.purchaseOrdersData = action.
      })
      .addCase(deletePurchaseOrderById.pending, (state) => {
        state.resError = "";
        state.isSuccess = false;
        state.successMessage = "";
        state.resError = "";
      })
      .addCase(deletePurchaseOrderById.rejected, (state) => {
        state.resError = "";
        state.reqError = "Something went wrong!";
        state.isSuccess = false;
        state.successMessage = "";
      })
      .addCase(deletePurchaseOrderById.fulfilled, (state, action) => {
        if (!action?.payload?.isSuccess) {
          state.resError = action?.payload?.errors[0];
        } else if (action?.payload?.isSuccess) {
          state.isSuccess = action?.payload?.isSuccess;
          state.successMessage =
            "Purchase Order has been deleted successfully.";
        }
      }),
});

export const getPurchaseOrdersState = (state: RootState) =>
  state?.purchaseOrders;
export const { resetState, resetStateisSuccess } = purchaseOrdersSlice.actions;
export const getPurchaseOrderDataById = (
  state: RootState,
  purchaseOrderId: string
) =>
  state.purchaseOrders.purchaseOrdersData?.find(
    (f) => f?.id === purchaseOrderId
  ) || null;
export default purchaseOrdersSlice.reducer;
