import { createSlice } from "@reduxjs/toolkit";
import { RootState } from "@store/index";
import { Inventory, PaginationProperties, ReduxStateType } from "@utils/types";
import {
  getInventoryListByProjectId,
  getAllInventoryListByProjectId,
  createInventory,
  editInventoryById,
  deleteInventoryById,
} from "@/src/apis/inventoryApis";
import { resetIntialValues } from "@/src/utils/sliceHelper";

type InventoriesState = {
  inventories: Inventory[] | null;
  createdBy?: string | null;
  createdDate?: Date | null;
  lastModifiedBy?: string | null;
  lastModifiedDate?: Date | null;
  modifiedBy?: string | null;
  modifiedDate?: Date | null;
};

const initialState: InventoriesState & ReduxStateType & PaginationProperties = {
  inventories: null,
  isSuccess: false,
  isLoading: false,
  reqError: "",
  resError: "",
  currentPage: 1,
  hasNext: false,
  hasPrevious: false,
  pageSize: 10,
  totalCount: 10,
  totalPages: 1,
};

export const inventoriesSlice = createSlice({
  name: "inventories",
  initialState,
  reducers: {
    resetState: (state) => {
      state.isSuccess = false;
      state.isLoading = false;
      state.reqError = null;
      state.resError = null;
      state.successMessage = "";
    },
  },
  extraReducers: (builder) =>
    builder
      .addCase(getAllInventoryListByProjectId.pending, (state) => {
        state.resError = "";
        state.isSuccess = false;
        // state.isLoading = true;
      })
      .addCase(getAllInventoryListByProjectId.rejected, (state) => {
        state.isSuccess = false;
        state.isLoading = false;
      })
      .addCase(getAllInventoryListByProjectId.fulfilled, (state, action) => {
        state.isSuccess = true;
        state.inventories = action.payload?.inventories;
        state.createdBy = action.payload?.createdBy;
        state.createdDate = action.payload?.createdDate;
        state.lastModifiedBy = action.payload?.lastModifiedBy;
        state.lastModifiedDate = action.payload?.lastModifiedDate;
        state.modifiedBy = action.payload?.modifiedBy;
        state.modifiedDate = action.payload?.modifiedDate;

        state.isLoading = false;
      })
      .addCase(getInventoryListByProjectId.pending, (state) => {
        state.isSuccess = false;
        state.isLoading = true;
      })
      .addCase(getInventoryListByProjectId.rejected, (state) => {
        state.resError = "";
        state.isSuccess = false;
        state.isLoading = false;
      })
      .addCase(getInventoryListByProjectId.fulfilled, (state, action) => {
        state.isSuccess = true;
        state.inventories = action.payload?.inventories;
        state.currentPage = action?.payload?.currentPage;
        state.pageSize = action?.payload?.pageSize;
        state.totalCount = action?.payload?.totalCount;
        state.totalPages = action?.payload?.totalPages;
        state.createdBy = action.payload?.createdBy;
        state.createdDate = action.payload?.createdDate;
        state.lastModifiedBy = action.payload?.lastModifiedBy;
        state.lastModifiedDate = action.payload?.lastModifiedDate;
        state.modifiedBy = action.payload?.modifiedBy;
        state.modifiedDate = action.payload?.modifiedDate;
        state.isLoading = false;
      })
      .addCase(createInventory.pending, (state) => {
        resetIntialValues(state);
      })
      .addCase(createInventory.rejected, (state) => {
        state.isLoading = false;
        state.reqError = "Something went wrong!";
        state.isSuccess = false;
      })
      .addCase(createInventory.fulfilled, (state, action) => {
        state.inventories = action?.payload?.inventories;
        state.createdBy = action.payload?.createdBy;
        state.createdDate = action.payload?.createdDate;
        state.isLoading = false;
        state.isSuccess = true;
        if (!action.payload.isSuccess) {
          state.resError = action.payload?.errors[0];
        }
        if (action.payload.isSuccess) {
          state.createdBy = action.payload.createdBy;
          state.createdDate = action.payload.createdDate;
          state.lastModifiedBy = action.payload?.lastModifiedBy;
          state.lastModifiedDate = action.payload?.lastModifiedDate;
          state.modifiedBy = action.payload?.modifiedBy;
          state.modifiedDate = action.payload?.modifiedDate;
          state.successMessage = "Inventory created successfully.";
        }
      })
      .addCase(editInventoryById.pending, (state) => {
        resetIntialValues(state);
      })
      .addCase(editInventoryById.rejected, (state) => {
        state.reqError = "Something went wrong!";
        state.isSuccess = false;
        state.isLoading = false;
      })
      .addCase(editInventoryById.fulfilled, (state, action) => {
        state.isSuccess = true;
        state.inventories = action.payload.inventories;
        if (!action.payload.isSuccess) {
          state.resError = action.payload.errors[0];
        } else if (action.payload.isSuccess) {
          state.createdBy = action.payload.createdBy;
          state.createdDate = action.payload.createdDate;
          state.lastModifiedBy = action.payload?.lastModifiedBy;
          state.lastModifiedDate = action.payload?.lastModifiedDate;
          state.modifiedBy = action.payload?.modifiedBy;
          state.modifiedDate = action.payload?.modifiedDate;
          state.successMessage = "Inventory updated successfully.";
        }
      })
      .addCase(deleteInventoryById.pending, (state) => {
        state.resError = "";
        state.isLoading = true;
        state.isSuccess = false;
      })
      .addCase(deleteInventoryById.rejected, (state) => {
        state.resError = "Something went wrong!";
        state.isLoading = false;
        state.isSuccess = false;
      })
      .addCase(deleteInventoryById.fulfilled, (state) => {
        state.isSuccess = true;
        state.successMessage = "Inventory deleted successfully.";
        state.isLoading = false;
      }),
});

export const getInventoriesState = (state: RootState) => state?.inventory;
export const { resetState } = inventoriesSlice.actions;

export default inventoriesSlice.reducer;
