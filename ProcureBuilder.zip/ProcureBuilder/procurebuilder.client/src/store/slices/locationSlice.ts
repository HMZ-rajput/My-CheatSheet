import { createSlice } from "@reduxjs/toolkit";
import { RootState } from "@store/index";
import {
  Location,
  LocationsList,
  PaginationProperties,
  ReduxStateType,
} from "@utils/types";
import {
  createLocation,
  createSingleLocation,
  deleteLocationById,
  editLocationById,
  getAllLocations,
  getLocationListForSideBar,
  getLocationslist,
} from "@/src/apis/locationApis";

type LocationsState = {
  locationsData: Location[] | null;
  locationsList: LocationsList[] | null;
  locationListForSideBar: LocationsList[] | null;
};

const initialState: LocationsState & PaginationProperties & ReduxStateType = {
  locationsData: null,
  locationsList: null,
  locationListForSideBar: null,

  isSuccess: false,
  isLoading: false,
  reqError: "",
  resError: "",
  currentPage: 1,
  hasNext: false,
  hasPrevious: false,
  pageSize: 10,
  totalCount: 10,
  totalPages: 1,
};

export const locationsSlice = createSlice({
  name: "locations",
  initialState,
  reducers: {
    resetState: (state) => {
      state.isSuccess = false;
      state.isLoading = false;
      state.reqError = null;
      state.resError = null;
      state.successMessage = "";
    },
    resetStateisSuccess: (state) => {
      state.isSuccess = false;
    },
  },
  extraReducers: (builder) =>
    builder
      .addCase(getAllLocations.pending, (state) => {
        state.isLoading = true;
      })
      .addCase(getAllLocations.rejected, (state) => {
        state.isLoading = false;
      })
      .addCase(getAllLocations.fulfilled, (state, action) => {
        state.isLoading = false;
        state.locationsData = action.payload?.locations;
        state.currentPage = action?.payload?.currentPage;
        state.pageSize = action?.payload?.pageSize;
        state.totalCount = action?.payload?.totalCount;
        state.totalPages = action?.payload?.totalPages;
        state.isLoading = false;
      })
      .addCase(getLocationslist.pending, (state) => {
        state.isLoading = true;
      })
      .addCase(getLocationslist.rejected, (state) => {
        state.isLoading = false;
      })
      .addCase(getLocationslist.fulfilled, (state, action) => {
        state.locationsList = action.payload.locations;
        state.isLoading = false;
      })
      .addCase(getLocationListForSideBar.pending, (state) => {
        state.isLoading = true;
      })
      .addCase(getLocationListForSideBar.rejected, (state) => {
        state.isLoading = false;
      })
      .addCase(getLocationListForSideBar.fulfilled, (state, action) => {
        state.locationListForSideBar = action.payload.locations;
        state.isLoading = false;
      })
      .addCase(createLocation.pending, (state) => {
        state.resError = "";
        state.isSuccess = false;
        state.successMessage = "";
        state.isLoading = true;
      })
      .addCase(createLocation.rejected, (state) => {
        state.reqError = "Something went wrong!";
        state.isSuccess = false;
        state.successMessage = "";
        state.isLoading = false;
      })
      .addCase(createLocation.fulfilled, (state, action) => {
        state.isSuccess = action.payload.isSuccess;
        state.isLoading = false;
        if (action.payload.isSuccess) {
          state.successMessage = "Location created successfully.";
          state.locationsData?.push(action?.payload?.locations as any);
        }
        if (!action.payload.isSuccess) {
          state.resError = action?.payload?.errors?.[0];
        }
      })
      .addCase(createSingleLocation.pending, (state) => {
        state.resError = "";
        state.isSuccess = false;
        state.successMessage = "";
        state.isLoading = true;
      })
      .addCase(createSingleLocation.rejected, (state) => {
        state.reqError = "Something went wrong!";
        state.isSuccess = false;
        state.successMessage = "";
        state.isLoading = false;
      })
      .addCase(createSingleLocation.fulfilled, (state, action) => {
        state.isSuccess = action.payload.isSuccess;
        state.isLoading = false;
        if (action.payload.isSuccess) {
          state.successMessage = "Location created successfully.";
          state.locationsData?.unshift(action?.payload.location as Location);
        }
        if (!action.payload.isSuccess) {
          state.resError = action?.payload?.errors?.[0];
        }
      })
      .addCase(editLocationById.pending, (state) => {
        state.resError = "";
        state.isSuccess = false;
        state.successMessage = "";
        state.isLoading = true;
      })
      .addCase(editLocationById.rejected, (state) => {
        state.reqError = "Something went wrong!";
        state.isSuccess = false;
        state.successMessage = "";
        state.isLoading = false;
      })
      .addCase(editLocationById.fulfilled, (state, action) => {
        state.isSuccess = action.payload.isSuccess;
        state.successMessage = "";
        state.isLoading = false;
        if (action.payload.isSuccess) {
          state.successMessage = "Location updated successfully.";
          // state.locationsData = (state.locationsData || []).map((location) =>
          //   location?.id === action?.payload?.locations?.id
          //     ? action?.payload?.locations
          //     : location
          // );
          state.locationsData = action?.payload?.locations;
        }
        if (!action.payload.isSuccess) {
          state.resError = action?.payload?.errors?.[0];
        }
      })
      .addCase(deleteLocationById.pending, (state) => {
        state.resError = "";
        state.isSuccess = false;
        state.successMessage = "";
        state.isLoading = true;
      })
      .addCase(deleteLocationById.rejected, (state) => {
        state.reqError = "Something went wrong!";
        state.isSuccess = false;
        state.successMessage = "";
        state.isLoading = false;
      })
      .addCase(deleteLocationById.fulfilled, (state, action) => {
        state.isSuccess = true;
        state.successMessage = "";
        state.isLoading = false;
        if (action.payload.isSuccess) {
          state.successMessage = "Location deleted successfully.";
        }
        if (!action.payload.isSuccess) {
          state.resError = action?.payload?.errors?.[0];
        }
      }),
});
export const { resetState, resetStateisSuccess } = locationsSlice.actions;
export const getLocationsState = (state: RootState) => state?.locations;
// export const getLocationDataById = (state: RootState, projectId: string) =>
//   state.locations?.locationsData?.filter((f) => f.project.id === projectId) ||
//   null;

export default locationsSlice.reducer;
