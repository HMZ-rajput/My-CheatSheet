import {
  changePassword,
  getAllUsersSummaryList,
  loginUserByEmail,
  updatePersonalInfo,
} from "@apis/userApis";
import { createSlice } from "@reduxjs/toolkit";
import { RootState } from "@store/index";
import { AccountSettings, Approver, ReduxStateType, User } from "@utils/types";

type UserState = {
  data: User | null;
  usersList: Approver[] | null;
  personalInfoData: AccountSettings | null;
  areUpdatePersonalInfoSuccessful: boolean;
  areUpdatePersonalInfoLoading: boolean;
};

const initialState: UserState & ReduxStateType = {
  data: null,
  personalInfoData: null,
  usersList: null,

  isSuccess: false,
  isLoading: false,

  areUpdatePersonalInfoSuccessful: false,
  areUpdatePersonalInfoLoading: false,

  reqError: "",
  resError: "",
  successMessage: "",
};

export const userSlice = createSlice({
  name: "user",
  initialState,
  reducers: {
    logOutUser: (state) => {
      state.data = null;
    },
    resetResponseError: (state) => {
      state.resError = "";
    },
    resetState: (state) => {
      state.isSuccess = false;
      state.isLoading = false;
      state.reqError = null;
      state.resError = null;
      state.successMessage = "";
    },
    resetStateisSuccess: (state) => {
      state.isSuccess = false;
    },
    resetUser: (state) => {
      state.data = null;
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(loginUserByEmail.pending, (state) => {
        state.isSuccess = false;
        state.isLoading = true;
        state.reqError = "";
        state.resError = "";
      })
      .addCase(loginUserByEmail.rejected, (state) => {
        state.data = null;
        state.isLoading = false;
        state.reqError = "Something went wrong!";
      })
      .addCase(loginUserByEmail.fulfilled, (state, action) => {
        state.isLoading = false;
        if (!action.payload.isSuccess) {
          state.resError = action.payload.errors[0] || "";
        } else if (action.payload.isSuccess) {
          state.data = action.payload;
        }
      })

      // Get userslist
      .addCase(getAllUsersSummaryList.pending, (state) => {
        state.isSuccess = false;
        state.isLoading = true;
      })
      .addCase(getAllUsersSummaryList.rejected, (state, action) => {
        state.usersList = null;
        state.isLoading = false;
        state.resError = action.error.message || "";
      })
      .addCase(getAllUsersSummaryList.fulfilled, (state, action) => {
        state.isLoading = false;
        if (action.payload.errors?.length > 0) {
          state.resError = action.payload.errors[0] || "";
          state.isSuccess = false;
          return;
        }
        state.usersList = action.payload.users;
        state.isSuccess = true;
      })

      //Update Personal Info
      .addCase(updatePersonalInfo.pending, (state) => {
        state.resError = "";
        state.successMessage = "";
        state.isLoading = true;
        state.areUpdatePersonalInfoLoading = true;
        state.isSuccess = false;
      })
      .addCase(updatePersonalInfo.rejected, (state) => {
        state.reqError = "Something went wrong!";
        state.successMessage = "";
        state.isLoading = false;
        state.areUpdatePersonalInfoLoading = false;
        state.isSuccess = false;
      })
      .addCase(updatePersonalInfo.fulfilled, (state, action) => {
        state.isLoading = false;
        state.reqError = "";
        state.isSuccess = action?.payload?.isSuccess;

        if (state.data) {
          state.data.firstName = action.payload.firstName;
          state.data.lastName = action.payload.lastName;
          state.data.phoneNumber = action.payload.phoneNumber;
          state.data.cellNumber = action.payload.cellNumber;
        }

        if (!action?.payload?.isSuccess) {
          state.resError = action?.payload?.errors[0] || "";
          return;
        }
        if (action?.payload?.isSuccess) {
          state.successMessage =
            "Account settings have been updated successfully.";
          return;
        }
      })

      .addCase(changePassword.pending, (state) => {
        (state.resError = ""), (state.successMessage = "");
        state.isLoading = true;
        state.areUpdatePersonalInfoLoading = true;
      })
      .addCase(changePassword.rejected, (state) => {
        state.resError = "Something went wrong!";
        state.successMessage = "";
        state.isLoading = false;
        state.areUpdatePersonalInfoLoading = false;
        state.isSuccess = false;
      })
      .addCase(changePassword.fulfilled, (state, action) => {
        state.isSuccess = action?.payload?.isSuccess;
        if (!action?.payload?.isSuccess) {
          state.resError = action?.payload?.errors[0] || "";
        }
        if (action?.payload?.isSuccess) {
          state.successMessage = "Password has been updated successfully.";
        }
      });
  },
});

export const {
  logOutUser,
  resetResponseError,
  resetState,
  resetStateisSuccess,
  resetUser,
} = userSlice.actions;
export const getUserState = (state: RootState) => state?.user;
export const getUserFullName = (state: RootState) =>
  `${state.user?.data?.firstName} ${state.user?.data?.lastName}`;

export const getUsersListState = (state: RootState) => state.user?.usersList;

export const getUpdatePersonalInfoData = (state: RootState) =>
  state?.user?.personalInfoData;
export const getUpdatePersonalInfoDataSuccess = (state: RootState) =>
  state?.user?.areUpdatePersonalInfoSuccessful;

export default userSlice.reducer;
