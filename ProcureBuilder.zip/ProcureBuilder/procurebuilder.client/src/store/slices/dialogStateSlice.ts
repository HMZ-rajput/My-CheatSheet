import { createSlice, PayloadAction } from "@reduxjs/toolkit";
import { RootState } from "@store/index";

type DialogStateType = {
  title: string;
  isDialogOpen: boolean;
  data: {
    message: string;
    lines: string[];
  };
};

const initialState: DialogStateType = {
  title: "",
  isDialogOpen: false,
  data: {
    message: "",
    lines: [],
  },
};

export const dialogStateSlice = createSlice({
  name: "dialogState",
  initialState,
  reducers: {
    updateDialogState: (_, action: PayloadAction<DialogStateType>) => {
      return action.payload;
    },
    resetDialogState: () => {
      return {
        title: "",
        isDialogOpen: false,
        data: {
          message: "",
          lines: [],
        },
      };
    },
  },
});

export const { updateDialogState, resetDialogState } = dialogStateSlice.actions;
export const getDialogState = (state: RootState) => state.dialogState;

export default dialogStateSlice.reducer;
