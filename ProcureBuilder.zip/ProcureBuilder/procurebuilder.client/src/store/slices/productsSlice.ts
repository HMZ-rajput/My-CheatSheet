import { getAllProducts, getAllProductByName } from "@/src/apis/productApis";
import { createSlice } from "@reduxjs/toolkit";
import { RootState } from "@store/index";
import {
  PaginationProperties,
  Product,
  ProductMaterial,
  ReduxStateType,
} from "@utils/types";

type ProductState = {
  productsData: Product[] | null;
  productsByName: ProductMaterial[] | null;
};

const initialState: ProductState & PaginationProperties & ReduxStateType = {
  productsData: null,
  productsByName: null,
  isSuccess: false,
  successMessage: "",
  isLoading: false,
  reqError: "",
  resError: "",
  currentPage: 1,
  hasNext: false,
  hasPrevious: false,
  pageSize: 10,
  totalCount: 10,
  totalPages: 1,
};

export const productsSlice = createSlice({
  name: "products",
  initialState,
  reducers: {},
  extraReducers: (builder) =>
    builder
      .addCase(getAllProducts.pending, (state) => {
        state.isSuccess = false;
        state.isLoading = true;
      })
      .addCase(getAllProducts.rejected, (state) => {
        state.isSuccess = false;
        state.isLoading = false;
      })
      .addCase(getAllProducts.fulfilled, (state, action) => {
        state.isSuccess = false;
        state.productsData = action.payload?.products;
        state.currentPage = action?.payload?.currentPage;
        state.pageSize = action?.payload?.pageSize;
        state.totalCount = action?.payload?.totalCount;
        state.totalPages = action?.payload?.totalPages;
        state.isLoading = false;
      })
      .addCase(getAllProductByName.pending, (state) => {
        state.isSuccess = false;
        state.isLoading = true;
      })
      .addCase(getAllProductByName.rejected, (state) => {
        state.isSuccess = false;
        state.isLoading = false;
      })
      .addCase(getAllProductByName.fulfilled, (state, action) => {
        state.isSuccess = false;
        state.productsByName = action.payload?.product;
        state.currentPage = action?.payload?.currentPage;
        state.pageSize = action?.payload?.pageSize;
        state.totalCount = action?.payload?.totalCount;
        state.totalPages = action?.payload?.totalPages;
        state.isLoading = false;
      }),
});

export const getProductState = (state: RootState) => state.products;

export default productsSlice.reducer;
