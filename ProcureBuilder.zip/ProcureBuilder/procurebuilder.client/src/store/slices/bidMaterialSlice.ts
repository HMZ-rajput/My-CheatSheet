import { createSlice } from "@reduxjs/toolkit";
import { RootState } from "@store/index";
import {
  BidMaterials,
  PaginationProperties,
  ReduxStateType,
} from "@utils/types";
import {
  getBidMaterialsById,
  createBidMaterials,
  editBidMaterials,
  deleteBidMaterialById,
  getBidMaterialsList,
} from "@/src/apis/bidMaterialApis";

type BidMaterialsListState = {
  name: string;
  costCode: string;
};

type BidMaterialState = {
  bidMaterialData: BidMaterials | null;
  bidMaterialsList: BidMaterialsListState[] | null;
  isSuccess: boolean;
  isLoading: boolean;
  resError: string | null;
};

const initialState: BidMaterialState & PaginationProperties & ReduxStateType = {
  bidMaterialData: null,
  bidMaterialsList: null,
  isSuccess: false,
  isLoading: false,
  reqError: "",
  resError: "",
  currentPage: 1,
  hasNext: false,
  hasPrevious: false,
  pageSize: 10,
  totalCount: 10,
  totalPages: 1,
};

export const bidMaterialSlice = createSlice({
  name: "bidMaterial",
  initialState,
  reducers: {
    resetState: (state) => {
      state.isSuccess = false;
      state.isLoading = false;
      state.reqError = null;
      state.resError = null;
      state.successMessage = "";
    },
    resetStateisSuccess: (state) => {
      state.isSuccess = false;
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(getBidMaterialsById.pending, (state) => {
        state.resError = "";
        state.isSuccess = false;
        state.isLoading = true;
        state.successMessage = "";
      })
      .addCase(getBidMaterialsById.rejected, (state) => {
        state.resError = "Something went wrong!";
        state.isSuccess = false;
        state.isLoading = false;
        state.successMessage = "";
      })
      .addCase(getBidMaterialsById.fulfilled, (state, action) => {
        state.bidMaterialData = action.payload;
        state.isSuccess = true;
        state.isLoading = false;
      })

      .addCase(getBidMaterialsList.pending, (state) => {
        state.resError = "";
        state.isSuccess = false;
        state.isLoading = true;
        state.successMessage = "";
      })
      .addCase(getBidMaterialsList.rejected, (state) => {
        state.resError = "Something went wrong!";
        state.isSuccess = false;
        state.isLoading = false;
        state.successMessage = "";
      })
      .addCase(getBidMaterialsList.fulfilled, (state, action) => {
        state.bidMaterialsList = action.payload;
        state.isSuccess = true;
        state.isLoading = false;
      })

      .addCase(createBidMaterials.pending, (state) => {
        state.resError = "";
        state.isSuccess = false;
        state.isLoading = true;
        state.successMessage = "";
      })
      .addCase(createBidMaterials.rejected, (state) => {
        state.resError = "Something went wrong!";
        state.isSuccess = false;
        state.isLoading = false;
        state.successMessage = "";
      })
      .addCase(createBidMaterials.fulfilled, (state, action) => {
        state.bidMaterialData = action?.payload;
        state.isSuccess = true;
        state.isLoading = false;
        if (!action.payload.isSuccess) {
          state.resError = action?.payload?.errors?.[0];
        } else {
          state.successMessage =
            "Bid materials have been updated successfully.";
        }
      })

      .addCase(editBidMaterials.pending, (state) => {
        state.resError = "";
        state.isSuccess = false;
        state.isLoading = true;
        state.successMessage = "";
      })
      .addCase(editBidMaterials.rejected, (state) => {
        state.resError = "Something went wrong!";
        state.isSuccess = false;
        state.isLoading = false;
        state.successMessage = "";
      })
      .addCase(editBidMaterials.fulfilled, (state, action) => {
        state.isLoading = false;
        state.isSuccess = true;
        if (!action.payload.isSuccess) {
          state.resError = action?.payload?.errors?.[0];
        } else {
          state.successMessage =
            "Bid materials have been updated successfully.";
        }
        if (
          state.bidMaterialData &&
          state.bidMaterialData.projectId === action.payload.projectId
        ) {
          state.bidMaterialData = action.payload;
        }
      })

      .addCase(deleteBidMaterialById.pending, (state) => {
        state.resError = "";
        state.isSuccess = false;
        state.successMessage = "";
        state.isLoading = true;
      })
      .addCase(deleteBidMaterialById.rejected, (state) => {
        state.resError = "Something went wrong!";
        state.isSuccess = false;
        state.successMessage = "";
        state.isLoading = false;
      })
      .addCase(deleteBidMaterialById.fulfilled, (state, action) => {
        state.isSuccess = true;
        if (!action.payload.isSuccess) {
          state.resError = action?.payload?.errors?.[0];
        } else {
          state.successMessage =
            "Bid materials have been deleted successfully.";
        }
        state.isLoading = false;
      });
  },
});

export const { resetState, resetStateisSuccess } = bidMaterialSlice.actions;
export const getBidMaterialState = (state: RootState) => state.bidMaterials;
export const getBidMaterialDetails = (state: RootState) =>
  state?.bidMaterials?.bidMaterialData;
export const getBidMaterialsListState = (state: RootState) =>
  state.bidMaterials.bidMaterialsList;

export default bidMaterialSlice.reducer;
