import { combineReducers, configureStore } from "@reduxjs/toolkit";
import { persistReducer, persistStore } from "redux-persist";
import storage from "redux-persist/lib/storage";

// Reducers
import userReducer from "@store/slices/userSlice";
import projectsReducer from "@store/slices/projectsSlice";
import typesReducer from "@store/slices/typesSlice";
import projectManagersReducer from "@store/slices/projectManagersSlice";
import customersReducer from "@store/slices/customersSlice";
import locationReducer from "@store/slices/locationSlice";
import questionsReducer from "@store/slices/questionsSlice";
import answersReducer from "@store/slices/qualityAnswersSlice";
import storageReducer from "@store/slices/storageTypeSlice";
import changeOrdersReducer from "@store/slices/changeOrderSlice";
import bidMaterialsReducer from "@store/slices/bidMaterialSlice";
import vendorReducer from "./slices/vendorSlice";
import companySettingsReducer from "@store/slices/companySettingsSlice";
import inventoryReducer from "@store/slices/inventorySlice";
import internalUsersReducer from "@store/slices/internalUsersSlice";
import invoicesReducer from "@store/slices/invoicesSlice";
import productsReducer from "@store/slices/productsSlice";
import purchaseOrdersReducer from "./slices/purchaseOrderSlice";
import reordersReducer from "./slices/reordersSlice";
import materialTransferReducer from "@store/slices/materialTransferSlice";
import materialReceiptInspectionsReducer from "@store/slices/materialReceiptInceptionSlice";
import materialGoingToSiteReducer from "./slices/materialGoingToSiteSlice";
import dialogStateReducer from "./slices/dialogStateSlice";
import dashboardReducer from "@store/slices/dashboardSlice";

const persistConfig = {
  key: "USER_DATA",
  storage,
  whitelist: ["user"],
};

const rootReducer = combineReducers({
  locations: locationReducer,
  user: userReducer,
  projects: projectsReducer,
  types: typesReducer,
  projectManagers: projectManagersReducer,
  questions: questionsReducer,
  answers: answersReducer,
  customers: customersReducer,
  bidMaterials: bidMaterialsReducer,
  storageTypes: storageReducer,
  changeOrders: changeOrdersReducer,
  company: companySettingsReducer,
  vendors: vendorReducer,
  inventory: inventoryReducer,
  reorder: reordersReducer,
  internalUsers: internalUsersReducer,
  invoices: invoicesReducer,
  products: productsReducer,
  purchaseOrders: purchaseOrdersReducer,
  materialTransfer: materialTransferReducer,
  materialReceiptInspection: materialReceiptInspectionsReducer,
  materialGoingToSite: materialGoingToSiteReducer,
  dialogState: dialogStateReducer,
  dashboard: dashboardReducer,
});

const persistedReducer = persistReducer(persistConfig, rootReducer);

const store = configureStore({
  reducer: persistedReducer,
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware({
      serializableCheck: false,
    }),
});

const persistor = persistStore(store);

export { store, persistor };
export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;
