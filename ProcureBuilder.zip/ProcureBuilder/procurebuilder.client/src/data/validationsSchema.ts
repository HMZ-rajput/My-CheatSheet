import * as Yup from "yup";

export const InventoryValidationSchema = Yup.object().shape({
  projectId: Yup.string().required("Project is required"),
  inventories: Yup.array().of(
    Yup.object().shape({
      locationId: Yup.string().required("Location is required"),
      materials: Yup.array().of(
        Yup.object().shape({
          name: Yup.string()
            .required("Material is required")
            .test(
              "test-duplicate-material-error",
              "Cannot add the same material under the same sublocation.",
              (_, ctx) => {
                const [{ value: material }, { value: inventory }] =
                  ctx.from as any;
                const seen = new Set();
                const duplicates = new Set();

                inventory.materials?.forEach((material: any) => {
                  const key = `${material?.name?.toLowerCase()?.trim()}-${
                    material.subLocationId
                  }`;
                  if (seen.has(key)) {
                    duplicates.add(key);
                  } else {
                    seen.add(key);
                  }
                });

                const key = `${material?.name?.toLowerCase()?.trim()}-${
                  material.subLocationId
                }`;

                if (!duplicates.has(key)) {
                  return true;
                } else {
                  return false;
                }
              }
            ),
          costCode: Yup.string().required("Cost Code is required"),
          unitOfMeasure: Yup.string().required(
            "Unit of Measurement is required"
          ),
        })
      ),
    })
  ),
});

export const PurchaseOrderValidationSchema = Yup.object().shape({
  purchaseOrderNumber: Yup.string().required(
    "Purchase Order number is required."
  ),
  title: Yup.string().required("Purchase Order title is required."),
  purchaseOrderProjectId: Yup.string().required("Project is required."),
  taxPercentage: Yup.string().required("Please add tax percentage here"),
  deliveryLocationId: Yup.string().required("Delivery Location is required."),
  vendorAddress: Yup.string().required("Vendor Address is required."),
  assignedUserId: Yup.string().required("Assigned User is required."),
  vendorId: Yup.string().required("Vendor is required."),
  purchaseOrderMaterials: Yup.array()
    .of(
      Yup.object({
        name: Yup.string()
          .required("Material name is a required field.")
          .test(
            "test-duplicate-material-name",
            "Cannot add materials with same name.",
            (_, ctx) => {
              const [{ value: material }, { value: purchaseOrder }] =
                ctx.from as any;
              const seen = new Set();
              const duplicates = new Set();

              purchaseOrder?.purchaseOrderMaterials?.forEach(
                (material: any) => {
                  const key = `${material?.name?.toLowerCase()?.trim()}`;
                  if (seen.has(key)) {
                    duplicates.add(key);
                  } else {
                    seen.add(key);
                  }
                }
              );

              const key = `${material?.name?.toLowerCase()?.trim()}`;

              if (!duplicates.has(key)) {
                return true;
              } else {
                return false;
              }
            }
          ),
        costCode: Yup.string().required("Cost Code is a required field."),
        unitRate: Yup.number().required("nitRate is a required field."),
        unitOfMeasure: Yup.string().required("Unit is a required field."),
      })
    )
    .min(1, "At least one material is required.")
    .required("At least one material is required."),
  deliveryContacts: Yup.array()
    .of(
      Yup.object({
        id: Yup.string().required(
          "At least one delivery contact must be selected."
        ),
      })
    )
    .min(1, "At least one delivery contact must be added")
    .required("At least one delivery contact must be added"),
  paymentTerm: Yup.string()
    .min(1, "At least one payment term must be selected.")
    .required("At least one payment term must be selected."),
});

export const BidMaterialValidationSchema = Yup.object().shape({
  isMaterialReceiptInspectionFormRequired: Yup.boolean().required("Required"),
  assumedSubmittalReview: Yup.number()
    .min(0, "Cannot be negative")
    .required("Assumed Submittal Review Period is Required"),
  assumedSubmittalReviewPeriod: Yup.number()
    .min(0, "Cannot be negative")
    .required("Assumed Submittal Review Period is Required"),

  materials: Yup.array().of(
    Yup.object().shape({
      name: Yup.string()
        .required("Material Name is required")
        .test(
          "test-duplicate-material-name",
          "Cannot add materials with same name.",
          (_, ctx) => {
            const [{ value: material }, { value: bidMaterial }] =
              ctx.from as any;
            const seen = new Set();
            const duplicates = new Set();

            bidMaterial.materials?.forEach((material: any) => {
              const key = `${material?.name?.toLowerCase()?.trim()}`;
              if (seen.has(key)) {
                duplicates.add(key);
              } else {
                seen.add(key);
              }
            });

            const key = `${material?.name?.toLowerCase()?.trim()}`;

            if (!duplicates.has(key)) {
              return true;
            } else {
              return false;
            }
          }
        ),
      costCode: Yup.string().required("Cost Code is required"),
      quantity: Yup.number()
        .required("Quantity is required")
        .moreThan(0, "Quantity cannot be 0"),
      unitOfMeasure: Yup.string().required("Unit of Measurement is required"),
      unitRate: Yup.number().required("Unit Rate is required"),
      totalBudget: Yup.number().required("Total Budget is required"),
    })
  ),
  subTotal: Yup.number().required("Required"),
});

export const ChangeOrderInfoValidationSchema = Yup.object().shape({
  title: Yup.string().required("Title is required."),
  changeOrderNumber: Yup.string().required("Change Order Number is required."),
  materials: Yup.array().of(
    Yup.object().shape({
      name: Yup.string()
        .required("Material Name is required")
        .test(
          "test-duplicate-material-name",
          "Cannot add materials with same name.",
          (_, ctx) => {
            const [{ value: material }, { value: changeOrder }] =
              ctx.from as any;
            const seen = new Set();
            const duplicates = new Set();

            changeOrder.materials?.forEach((material: any) => {
              const key = `${material?.name?.toLowerCase()?.trim()}`;
              if (seen.has(key)) {
                duplicates.add(key);
              } else {
                seen.add(key);
              }
            });

            const key = `${material?.name?.toLowerCase()?.trim()}`;

            if (!duplicates.has(key)) {
              return true;
            } else {
              return false;
            }
          }
        ),
      costCode: Yup.string().required("Cost Code is required"),
      quantity: Yup.number().required("Quantity is required"),
      unitOfMeasure: Yup.string().required("Unit of Measurement is required"),
      unitRate: Yup.number().required("Unit rate is required"),
      totalBudget: Yup.number().required("Total Budget is required"),
    })
  ),
  subTotal: Yup.number().required("Required"),
});

export const ChangeOrderDetailsValidationSchema = Yup.object().shape({
  title: Yup.string().required("Title is required."),
  changeOrderNumber: Yup.string().required("Change Order Number is required."),
  projectId: Yup.string().required("Project is required."),
  materials: Yup.array().of(
    Yup.object().shape({
      name: Yup.string()
        .required("Material Name is required")
        .test(
          "test-duplicate-material-name",
          "Cannot add materials with same name.",
          (_, ctx) => {
            const [{ value: material }, { value: changeOrder }] =
              ctx.from as any;
            const seen = new Set();
            const duplicates = new Set();

            changeOrder.materials?.forEach((material: any) => {
              const key = `${material?.name?.toLowerCase()?.trim()}`;
              if (seen.has(key)) {
                duplicates.add(key);
              } else {
                seen.add(key);
              }
            });

            const key = `${material?.name?.toLowerCase()?.trim()}`;

            if (!duplicates.has(key)) {
              return true;
            } else {
              return false;
            }
          }
        ),
      costCode: Yup.string().required("Cost Code is required"),
      quantity: Yup.number().required("Quantity is required"),
      unitOfMeasure: Yup.string().required("Unit of Measurement is required"),
      unitRate: Yup.number().required("Unit Rate is required"),
      totalBudget: Yup.number().required("Total Budget is required"),
    })
  ),
  subTotal: Yup.number().required("Required"),
});

export const ReorderGeneralValidationSchema = Yup.object().shape({
  title: Yup.string().required("Title is required."),
  reorderNumber: Yup.string().required("Reorder Number is required."),
  projectId: Yup.string().required("Project is required."),
  projectLocationId: Yup.string().required("Location is required."),
  status: Yup.number().required("Status is required."),
  materials: Yup.array().of(
    Yup.object().shape({
      name: Yup.string()
        .required("Material Name is required")
        .test(
          "test-duplicate-material-name",
          "Cannot add materials with same name.",
          (_, ctx) => {
            const [{ value: material }, { value: reOrder }] = ctx.from as any;
            const seen = new Set();
            const duplicates = new Set();

            reOrder.materials?.forEach((material: any) => {
              const key = `${material?.name?.toLowerCase()?.trim()}`;
              if (seen.has(key)) {
                duplicates.add(key);
              } else {
                seen.add(key);
              }
            });

            const key = `${material?.name?.toLowerCase()?.trim()}`;

            if (!duplicates.has(key)) {
              return true;
            } else {
              return false;
            }
          }
        ),
      costCode: Yup.string().required("Cost Code is required"),
      quantity: Yup.number().required("Quantity is required"),
      unitOfMeasure: Yup.string().required("Unit of Measurement is required"),
    })
  ),
});

export const ReorderRecipientValidationSchema = Yup.object().shape({
  vendorIds: Yup.array()
    .min(1, "At least 1 Vendor is required.")
    .of(Yup.string())
    .required("Vendor is required."),
});

export const MaterialReceiptInspectionValidationSchema = Yup.object().shape({
  title: Yup.string().required("Title is required."),
  purchaseOrderId: Yup.string().required("Purchase Order Number is required."),
  projectId: Yup.string().required("Project is required."),
  projectLocationId: Yup.string().required("Location is required."),
  status: Yup.number().required("Status is required."),
  materials: Yup.array().of(
    Yup.object().shape({
      name: Yup.string()
        .required("Material Name is required")
        .test(
          "test-duplicate-material-name",
          "Cannot add materials with same name.",
          (_, ctx) => {
            const [{ value: material }, { value: materialReceiptInspection }] =
              ctx.from as any;
            const seen = new Set();
            const duplicates = new Set();

            materialReceiptInspection?.materials?.forEach((material: any) => {
              const key = `${material?.name?.toLowerCase().trim() || ""}`;
              if (seen.has(key)) {
                duplicates.add(key);
              } else {
                seen.add(key);
              }
            });

            const key = `${material?.name?.toLowerCase()?.trim()}`;

            if (!duplicates.has(key)) {
              return true;
            } else {
              return false;
            }
          }
        ),
      quantity: Yup.number().required("Quantity is required"),
      unitOfMeasure: Yup.string().required("Unit of Measurement is required"),
    })
  ),
  // qualityQuestions: Yup.array().of(
  //   Yup.object().shape({
  //     id: Yup.string().required("Question is required"),
  //     answer: Yup.string().required("Answer is required"),
  //   })
  // ),
});

export const MaterialImagesValidationSchemna = Yup.object().shape({
  materialImages: Yup.array().required("Material Images are required"),
});

export const PO_APPROVAL_CREATE_VALIDATION_SCHEMA = Yup.object().shape({
  contractorApproval: Yup.object().shape({
    signature: Yup.string().required("Signature is required.") || "",
    company: Yup.string().required("Company is required."),
    title: Yup.string().required("Title is required."),
    dateSigned: Yup.date().nullable(),
  }),
});

export const LocationValidationsSchema = Yup.object().shape({
  projectId: Yup.string().required("Project is required"),
  // projectTypeId: Yup.string().required("Project Type is required"),
  locations: Yup.array().of(
    Yup.object().shape({
      name: Yup.string().required("Location name is required"),
      address: Yup.string().required("Address is required"),
      storageTypeId: Yup.string().required("Storage Type is required"),
      subLocations: Yup.array().of(
        Yup.object().shape({
          name: Yup.string()
            .required("Sublocation name is required")
            .test(
              "unique-sublocation-name",
              "Sublocation names must be unique within a location",
              (value, ctx) => {
                const [
                  { value: _ },
                  {
                    value: { subLocations },
                  },
                ] = ctx.from as any;

                if (!value) return false;

                // Count occurrences of this name
                const occurrences = (subLocations || [])?.filter(
                  (sl: { name: string | null }) => sl.name === value
                ).length;

                // It's valid if there's exactly one occurrence
                return occurrences === 1;
              }
            ),
        })
      ),
    })
  ),
});
export const SingleLocationValidationsSchema = Yup.object().shape({
  name: Yup.string().required("Location name is required"),
  address: Yup.string().required("Address is required"),
  storageTypeId: Yup.string().required("Storage Type is required"),
  subLocations: Yup.array().of(
    Yup.object().shape({
      name: Yup.string()
        .required("Sublocation name is required")
        .test(
          "unique-sublocation-name",
          "Sublocation names must be unique within a location",
          (value, ctx) => {
            const [
              { value: _ },
              {
                value: { subLocations },
              },
            ] = ctx.from as any;

            if (!value) return false;

            // Count occurrences of this name
            const occurrences = (subLocations || [])?.filter(
              (sl: { name: string | null }) => sl.name === value
            ).length;

            // It's valid if there's exactly one occurrence
            return occurrences === 1;
          }
        ),
    })
  ),
});
