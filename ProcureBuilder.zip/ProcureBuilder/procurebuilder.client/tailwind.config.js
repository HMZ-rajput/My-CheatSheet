/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,ts,jsx,tsx}"],
  theme: {
    screens: {
      lg: "1440px",
      xl: "1600px",
    },
    fontFamily: {
      sans: ["Inter", "sans-serif"],
    },
    colors: {
      // Danger
      danger: {
        5: "#DF1C41",
        "5-12": "#DF1C411F",
        "5-14": "#FFF2F5",
        510: "#DF1C411A",
        "5-18": "#DF1C4124",
        "5-02": "#FCE8EC",
      },

      // Primary colors
      primary: "#F44803",
      primaryHover: "#FF672B",
      primaryActive: "#FF672B",
      primary25: "#FEF3EB",
      error: "#ff4d4f",

      // Text and background colors
      textBase: "#000000E0",
      border: "#E2E4E9",
      bgBase: "#FFFFFF",
      white: "#FFFFFF",
      lightOrange: "#FFE6DF",

      // Neutral colors
      neutral: {
        0: "#f5f5f5",
        1: "#F6F8FA",
        5: "#E2E4E9",
        6: "#CDD0D5",
        7: "#868C98",
        75: "#BBBBBB",
        85: "#525866",
        8: "#313B4F",
        9: "#111827",
        10: "#F3F3F3",
      },

      // Green
      green: {
        1: "#E7F7EF",
        4: "#2E8B57",
        "4-12": "#E9FFF3",
        5: "#0CAF60",
        8: "#38C793",
        "8-12": "#38C7931F",
        primary: "#26A376",
        primaryHover: "#3AC392",
      },

      // Orange
      orange: {
        1: "#FEF3EB",
        "5-12": "#F17B2C1F",
        5: "#F17B2C",
      },

      // Blue
      blue: {
        1: "#1976D2",
        "1-12": "#F0F7FF",
      },

      // Purple
      purple: {
        5: "#5B4C9E",
        "5-12": "#EEEEFF",
      },

      // Gray
      gray: {
        1: "#53575A",
        "1-12": "#ECECEC",
        2: "#687588",
        3: "#F1F2F4",
        4: "#E4E4E4",
        5: "#666D80",
      },

      // Black
      black900: "#0A0D14",

      // Other colors
      pink3: "#F7C3FF",
      purple8: "#7851A9",
      yellow5: "#FFD700",
      cyan3: "#9CD8E5",
    },
  },
  plugins: [],
};
