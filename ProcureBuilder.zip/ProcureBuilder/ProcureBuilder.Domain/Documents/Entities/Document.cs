﻿using ProcureBuilder.ActivityLogs.Entities;
using ProcureBuilder.ChangeOrders.Entities;
using ProcureBuilder.Common.Entities;
using ProcureBuilder.CompanySettings.Entities;
using ProcureBuilder.Identity.Entities;
using ProcureBuilder.Invoices.Entities;
using ProcureBuilder.MaterialReceiptInspections.Entities;
using ProcureBuilder.PurchaseOrders.Entities;
using ProcureBuilder.Reorders.Entities;
using System.ComponentModel.DataAnnotations.Schema;

namespace ProcureBuilder.Documents.Entities;

public class Document : ModifiableDomainEntity
{
    public required string FileName { get; set; }
    public virtual ApplicationUser? User { get; set; }
    public DocumentType DocumentType { get; set; }

    [ForeignKey(nameof(Invoice))]
    public Guid? InvoiceId { get; set; }
    public Invoice? Invoice { get; set; }

    [ForeignKey(nameof(PurchaseOrder))]
    public Guid? PurchaseOrderId { get; set; }
    public virtual PurchaseOrder? PurchaseOrder { get; set; }

    [ForeignKey(nameof(ChangeOrder))]
    public Guid? ChangeOrderId { get; set; }
    public virtual ChangeOrder? ChangeOrder { get; set; }

    [ForeignKey(nameof(MaterialReceiptInspection))]
    public Guid? MaterialReceiptInspectionId { get; set; }
    public virtual MaterialReceiptInspection? MaterialReceiptInspection { get; set; }

    [ForeignKey(nameof(Reorder))]
    public Guid? ReorderId { get; set; }
    public Reorder? Reorder { get; set; }
    public virtual Company? Company { get; set; }
    public ICollection<ActivityLog> ActivityLogs { get; } = [];
}

public enum DocumentType
{
    Other = 0,
    PurchaseOrder = 1,
    VendorInvoice = 2,
    InvoiceAttachments = 3,
    PurchaseOrderAttachments = 4,
    RecentQuote = 5,
    ChangeOrderAttachments = 6,
    CompanyImage = 7,
    MaterialImage = 8,
    QuoteRequest = 9,
    ReorderAttachments = 10,
    RequestQuote = 11,
    BillOfLanding = 12,
    CompanyLogo = 13
}

public enum PDFType
{
    PurchaseOrder = 0,
    PurchaseOrderVendor = 1,
    PurchaseOrderApproval = 2
}
