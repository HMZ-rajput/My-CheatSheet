﻿using ProcureBuilder.Common.DTOs;

namespace ProcureBuilder.MaterialInventory.DTOs;

public class MaterialInventoryFilters : QueryStringParameters
{
    public Guid? LocationId { get; set; }
    public Guid? SubLocationId { get; set; }
    public string? Search { get; set; }
}

public class GetAllInventoryMaterialsFilter
{
    public Guid? LocationId { get; set; }
    public Guid? SubLocationId { get; set; }
    public string? Search { get; set; }
}

