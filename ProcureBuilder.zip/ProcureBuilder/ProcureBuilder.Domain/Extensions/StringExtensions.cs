﻿using ProcureBuilder.Invoices.Entities;
using ProcureBuilder.MaterialReceiptInspections.Entities;
using ProcureBuilder.PurchaseOrders.Entities;

namespace ProcureBuilder.Extensions;

public static class StringExtensions
{
    public static string PurchaseOrderStatusToString(PurchaseOrderStatus status) =>
        status switch
        {
            PurchaseOrderStatus.PendingAdminApproval => "Pending Admin Approval",
            PurchaseOrderStatus.AdminApprovedPartial => "Admin Approved Partial",
            PurchaseOrderStatus.AdminApprovedAll => "Admin Approved All",
            PurchaseOrderStatus.AdminRejectedAll => "Admin Rejected All",
            PurchaseOrderStatus.VendorApprovalPending => "Vendor Approval Pending",
            PurchaseOrderStatus.VendorApproved => "Vendor Approved",
            PurchaseOrderStatus.VendorRejected => "Vendor Rejected",
            PurchaseOrderStatus.PartiallyReceived => "Partially Received",
            PurchaseOrderStatus.FullyReceived => "Fully Received",
            PurchaseOrderStatus.AdminSigned => "Admin Signed",
            _ => ""
        };

    public static string PaymentTermStatusToString(PaymentTerm? status) =>
        status switch
        {
            PaymentTerm.Net30Days => "Net 30 Days",
            PaymentTerm.Net45Days => "Net 45 Days",
            PaymentTerm.Net60Days => "Net 60 Days",
            _ => ""
        };

    public static string SubmittalStatusToString(SubmittalStatus? status) =>
        status switch
        {
            SubmittalStatus.Pending => "Pending",
            SubmittalStatus.Recieved => "Received",
            SubmittalStatus.UnderReview => "Under Review",
            SubmittalStatus.NoExceptionsTaken => "No Exceptions Taken",
            SubmittalStatus.ApprovedAsNoted => "Approved As Noted",
            SubmittalStatus.ReviseAndResubmit => "Revise And Resubmit",
            SubmittalStatus.Rejected => "Rejected",
            _ => ""
        };

    public static string MRIStatusToString(MaterialReceiptInspectionStatus? status) =>
        status switch
        {
            MaterialReceiptInspectionStatus.Pending => "Pending",
            MaterialReceiptInspectionStatus.Approved => "Approved",
            MaterialReceiptInspectionStatus.ApprovedWithExceptions => "Approved With Exception",
            MaterialReceiptInspectionStatus.Rejected => "Rejected",
            _ => ""
        };
}
