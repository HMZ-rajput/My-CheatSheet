﻿using ProcureBuilder.ActivityLogs.Entities;
using ProcureBuilder.Common.Entities;
using ProcureBuilder.Invoices.Entities;
using ProcureBuilder.MaterialReceiptInspections.Entities;
using ProcureBuilder.Materials.Entities;
using ProcureBuilder.MaterialToSites.Entities;
using ProcureBuilder.MaterialTransfers.Entities;
using ProcureBuilder.Projects.Entities;
using ProcureBuilder.PurchaseOrders.Entities;
using ProcureBuilder.Reorders.Entities;
using ProcureBuilder.StorageTypes.Entities;
using System.ComponentModel.DataAnnotations.Schema;

namespace ProcureBuilder.Locations.Entities;

public class ProjectLocation : ModifiableDomainEntity
{
    public required string Name { get; set; }
    public required string Address { get; set; }
    public string? NearestCrossStreets { get; set; }

    [ForeignKey(nameof(StorageType))]
    public Guid? StorageTypeId { get; set; }
    public virtual StorageType? StorageType { get; set; }

    [ForeignKey(nameof(Project))]
    public Guid? ProjectId { get; set; }
    public virtual Project? Project { get; set; }
    public ICollection<SubLocation> SubLocations { get; } = [];
    public ICollection<ActivityLog> ActivityLogs { get; } = [];
    public ICollection<MaterialTransfer> OriginalMaterialTransfers { get; } = [];
    public ICollection<MaterialTransfer> DestinationMaterialTransfers { get; } = [];
    public ICollection<MaterialToSite> OriginalMaterialToSites { get; } = [];
    public ICollection<MaterialToSite> DestinationMaterialToSites { get; } = [];
    public ICollection<Invoice> Invoices { get; } = [];
    public ICollection<PurchaseOrder> DeliveryLocationPurchaseOrders { get; } = [];
    public ICollection<MaterialReceiptInspection> MaterialReceiptInspections { get; } = [];
    public ICollection<Material> Materials { get; } = [];
    public ICollection<Reorder> Reorders { get; } = [];
}
