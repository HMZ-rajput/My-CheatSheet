﻿using ProcureBuilder.Common.Entities;
using ProcureBuilder.MaterialReceiptInspections.Entities;
using ProcureBuilder.Materials.Entities;
using ProcureBuilder.MaterialTransfers.Entities;
using System.ComponentModel.DataAnnotations.Schema;

namespace ProcureBuilder.Locations.Entities;

public class SubLocation : ModifiableDomainEntity
{
    public string Name { get; set; } = string.Empty;

    [ForeignKey(nameof(ProjectLocation))]
    public Guid? ProjectLocationId { get; set; }
    public virtual ProjectLocation? ProjectLocation { get; set; }
    public ICollection<Material> Materials { get; } = [];
    public ICollection<MaterialTransfer> MaterialTransfers { get; } = [];
    public ICollection<MaterialReceiptInspection> MaterialReceiptInspections { get; } = [];
}