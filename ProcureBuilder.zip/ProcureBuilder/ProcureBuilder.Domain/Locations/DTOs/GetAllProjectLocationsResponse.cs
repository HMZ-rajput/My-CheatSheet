﻿using ProcureBuilder.Common.DTOs;

namespace ProcureBuilder.Locations.DTOs;

public class GetAllProjectLocationsResponse : GetAllBaseResponse
{
    public IList<GetProjectLocationProjectDTO> Locations { get; set; } = [];
}