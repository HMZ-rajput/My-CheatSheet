﻿using ProcureBuilder.Common.DTOs;
using ProcureBuilder.Projects.Entities;

namespace ProcureBuilder.Locations.DTOs;

public class GetLocationsListResponse : BaseResponse
{
    public List<GetLocationsListDTO> Locations { get; set; } = [];
    public int AssumedSubmittalReview { get; set; }
    public MaterialReviewPeriod AssumedSubmittalReviewPeriod { get; set; }
    public decimal TaxPercentage { get; set; }
}

public class GetLocationsListDTO
{
    public Guid? ProjectId { get; set; }
    public required Guid? Id { get; set; }
    public required string? Name { get; set; }
    public List<GetSubLocationsListDTO> SubLocations { get; set; } = [];
}

public class GetSubLocationsListDTO
{
    public required Guid Id { get; set; }
    public required string Name { get; set; }
}
