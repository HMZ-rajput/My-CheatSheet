﻿using ProcureBuilder.Common.DTOs;
using ProcureBuilder.StorageTypes.Entities;

namespace ProcureBuilder.Locations.DTOs;

public class ProjectLocationFilters : QueryStringParameters
{
    public Guid? StorageType { get; set; }
    public string? Search { get; set; }
}