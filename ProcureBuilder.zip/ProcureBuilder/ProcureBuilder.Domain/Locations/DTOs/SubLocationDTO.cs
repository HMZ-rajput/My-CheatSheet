﻿namespace ProcureBuilder.Locations.DTOs;

public class SubLocationDTO
{
    public Guid? Id { get; set; }
    public string? Name { get; set; }
    public Guid? ProjectLocationId { get; set; }
}