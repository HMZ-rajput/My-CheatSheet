﻿using ProcureBuilder.Common.DTOs;

namespace ProcureBuilder.Locations.DTOs;

public class ProjectLocationResponse : BaseResponse
{
    public Guid? ProjectId { get; set; }
    public IList<GetProjectLocationProjectDTO> Locations { get; set; } = [];
}