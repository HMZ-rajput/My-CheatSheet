﻿using ProcureBuilder.Common.DTOs;
using ProcureBuilder.Projects.DTOs;
using ProcureBuilder.StorageTypes.DTOs;
using System.ComponentModel.DataAnnotations;

namespace ProcureBuilder.Locations.DTOs;

public class ProjectLocationDTO
{
    [Required]
    [DataType(DataType.Text)]
    [StringLength(maximumLength: 200, MinimumLength = 1,
        ErrorMessage = $"{nameof(Name)} must be between 1 to 200 characters.")]
    public required string Name { get; set; }

    [Required]
    [DataType(DataType.Text)]
    [StringLength(maximumLength: 200, MinimumLength = 1,
        ErrorMessage = $"{nameof(Address)} must be between 1 to 200 characters.")]
    public required string Address { get; set; }

    public string? NearestCrossStreets { get; set; }
    public Guid? StorageTypeId { get; set; }
    public Guid? ProjectId { get; set; }
    public string? ModifiedBy { get; set; }
}

public class CreateProjectLocationDTO : ProjectLocationDTO
{
    public IList<string> SubLocations { get; set; } = [];
}

public class UpdateProjectLocationDTO : ProjectLocationDTO
{
    public Guid? Id { get; set; }
    public IList<SubLocationDTO> SubLocations { get; set; } = [];
}

public class GetProjectLocationDTO : UpdateProjectLocationDTO
{
    public GetStorageTypeDTO? StorageType { get; set; }
    public DateTimeOffset? ModifiedDate { get; set; }
    public string? CreatedBy { get; set; }
    public DateTimeOffset? CreatedDate { get; set; }
    public string? LastModifiedBy => ModifiedBy ?? CreatedBy;
    public DateTimeOffset? LastModifiedDate => ModifiedDate ?? CreatedDate;
}

public class GetProjectLocationProjectDTO : GetProjectLocationDTO
{
    public GetProjectDTO? Project { get; set; }
}

public class GetProjectLocationResponse : BaseResponse
{
    public GetProjectLocationDTO? Location { get; set; }
}