﻿namespace ProcureBuilder.Locations.DTOs;

public class UpdateProjectLocationRequest
{
    public IList<UpdateProjectLocationDTO> Locations { get; set; } = [];
    public string? ModifiedBy { get; set; }
}