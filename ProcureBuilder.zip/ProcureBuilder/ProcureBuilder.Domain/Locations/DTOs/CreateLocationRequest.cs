﻿namespace ProcureBuilder.Locations.DTOs;

public class CreateLocationRequest
{
    public IList<CreateProjectLocationDTO> Locations { get; set; } = [];
    public string? ModifiedBy { get; set; }
}