﻿using Microsoft.EntityFrameworkCore;
using ProcureBuilder.ActivityLogs.Entities;
using ProcureBuilder.Common.Entities;
using ProcureBuilder.Documents.Entities;
using ProcureBuilder.Identity.Entities;
using ProcureBuilder.Materials.Entities;
using ProcureBuilder.Projects.Entities;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ProcureBuilder.ChangeOrders.Entities;

public class ChangeOrder : ModifiableDomainEntity
{
    public required string Title { get; set; }
    public required string ChangeOrderNumber { get; set; }
    public DateTimeOffset? ApprovalDeadline { get; set; }
    public string? Notes { get; set; }

    [EnumDataType(typeof(ChangeOrderStatus))]
    public ChangeOrderStatus Status { get; set; }

    [Precision(18, 2)]
    public decimal SubTotal { get; set; }

    [Precision(18, 2)]
    public decimal OtherCosts { get; set; }

    [ForeignKey(nameof(User))]
    public string? UserId { get; set; }
    public virtual ApplicationUser? User { get; set; }

    [ForeignKey(nameof(Project))]
    public Guid? ProjectId { get; set; }
    public virtual Project? Project { get; set; }
    public ICollection<Material> Materials { get; } = [];
    public ICollection<ActivityLog> ActivityLogs { get; } = [];
    public ICollection<Document> Documents { get; } = [];
}

public enum ChangeOrderStatus
{
    Pending = 0,
    Approved = 1,
    Rejected = 2,
    AddedToBidMaterial = 3
}