﻿using ProcureBuilder.Common.DTOs;

namespace ProcureBuilder.ChangeOrders.DTOs;

public class GetNewChangeOrderNumberResponse : BaseResponse
{
    public string ChangeOrderNumber { get; set; } = string.Empty;
}