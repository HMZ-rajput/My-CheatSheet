﻿using ProcureBuilder.Common.DTOs;

namespace ProcureBuilder.ChangeOrders.DTOs;

public class GetAllChangeOrdersResponse : GetAllBaseResponse
{
    public IList<GetChangeOrderProjectDTO> ChangeOrders { get; set; } = [];
    public decimal? CombinedSubtotal { get; set; }
    public int? TotalPending { get; set; }
    public int? TotalApproved { get; set; }
    public int? TotalRejected { get; set; }
    public int? TotalAddedToBidMaterial { get; set; }
}