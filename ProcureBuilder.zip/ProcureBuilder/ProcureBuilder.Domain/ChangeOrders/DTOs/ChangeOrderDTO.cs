﻿using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using ProcureBuilder.ChangeOrders.Entities;
using ProcureBuilder.Documents.DTOs;
using ProcureBuilder.Materials.DTOs;
using ProcureBuilder.Projects.DTOs;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ProcureBuilder.ChangeOrders.DTOs;

public class ChangeOrderDTO
{
    [Required]
    public required string Title { get; set; }

    [Required]
    public string? ChangeOrderNumber { get; set; }

    public DateTimeOffset? ApprovalDeadline { get; set; }
    public string? UserId { get; set; }
    public string? Notes { get; set; }
    public ChangeOrderStatus Status { get; set; }

    [Precision(18, 2)]
    public decimal SubTotal { get; set; }

    [Precision(18, 2)]
    public decimal OtherCosts { get; set; }
    public Guid? ProjectId { get; set; }
    public string? ModifiedBy { get; set; }
    public IList<MaterialIdDTO> Materials { get; set; } = [];
}

public class CreateChangeOrderDTO : ChangeOrderDTO
{
    public IList<IFormFile> Attachments { get; set; } = [];
}

public class UpdateChangeOrderDTO : CreateChangeOrderDTO
{
    public Guid? Id { get; set; }
    public IList<Guid> DeleteAttachmentIds { get; set; } = [];
}

public class GetChangeOrderDTO : ChangeOrderDTO
{
    public Guid? Id { get; set; }
    public DateTimeOffset? ModifiedDate { get; set; }
    public string? CreatedBy { get; set; }
    public DateTimeOffset? CreatedDate { get; set; }
    public string? LastModifiedBy => ModifiedBy ?? CreatedBy;
    public DateTimeOffset? LastModifiedDate => ModifiedDate ?? CreatedDate;
}

public class GetChangeOrderProjectDTO : GetChangeOrderDTO
{
    public IList<DocumentDTO> Attachments { get; set; } = [];
    public GetProjectDTO? Project { get; set; }
}