﻿namespace ProcureBuilder.ChangeOrders.DTOs;

public class DeleteChangeOrderMaterialsRequest
{
    public IList<Guid> MaterialIds { get; set; } = [];
    public string? ModifiedBy { get; set; }
}