﻿using ProcureBuilder.Common.DTOs;

namespace ProcureBuilder.ChangeOrders.DTOs;

public class ChangeOrderResponse : BaseResponse
{
    public GetChangeOrderProjectDTO? ChangeOrder { get; set; }
}