﻿namespace ProcureBuilder.ChangeOrders.DTOs;

public class DeleteChangeOrderAttachmentsRequest
{
    public IList<Guid> AttachmentIds { get; set; } = [];
    public string? ModifiedBy { get; set; }
}