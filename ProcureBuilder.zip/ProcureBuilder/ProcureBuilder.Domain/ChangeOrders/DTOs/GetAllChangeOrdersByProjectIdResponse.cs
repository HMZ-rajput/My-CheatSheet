﻿using ProcureBuilder.Common.DTOs;

namespace ProcureBuilder.ChangeOrders.DTOs;

public class GetAllChangeOrdersByProjectIdResponse : BaseResponse
{
    public IList<GetChangeOrderProjectDTO> ChangeOrders { get; set; } = [];
}