﻿using ProcureBuilder.ChangeOrders.Entities;
using ProcureBuilder.Common.DTOs;
using System.ComponentModel.DataAnnotations;

namespace ProcureBuilder.ChangeOrders.DTOs;

public class ChangeOrderFilters : QueryStringParameters
{
    public string? Search { get; set; }
    public bool IsDueToday { get; set; }
    public bool IsOverDue { get; set; }
    public bool IsUpComing { get; set; }

    [EnumDataType(typeof(ChangeOrderStatus))]
    public ChangeOrderStatus? Status { get; set; }
    public Guid? ProjectId { get; set; }

    public bool IsForReport { get; set; }
    public DateTimeOffset? ApprovalDeadlineFrom { get; set; }
    public DateTimeOffset? ApprovalDeadlineTo { get; set; }
    public decimal? SubtotalFrom { get; set; }
    public decimal? SubtotalTo { get; set; }
}