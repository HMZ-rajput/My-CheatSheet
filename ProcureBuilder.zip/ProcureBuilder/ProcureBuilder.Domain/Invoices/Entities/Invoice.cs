﻿using ProcureBuilder.Common.Entities;
using ProcureBuilder.Projects.Entities;
using ProcureBuilder.Locations.Entities;
using ProcureBuilder.Vendors.Entities;
using ProcureBuilder.Documents.Entities;
using System.ComponentModel.DataAnnotations.Schema;
using ProcureBuilder.Materials.Entities;
using ProcureBuilder.PurchaseOrders.Entities;
using Microsoft.EntityFrameworkCore;


namespace ProcureBuilder.Invoices.Entities;

public class Invoice : ModifiableDomainEntity
{
    public string InvoiceNumber { get; set; } = string.Empty;
    public string Title { get; set; } = string.Empty;
    public DateTimeOffset InvoiceDate { get; set; } = DateTimeOffset.UtcNow;
    public DateTimeOffset DueDate { get; set; } = DateTimeOffset.UtcNow;
    public string PurchaseOrderNumber { get; set; } = string.Empty;
    //public string VendorInvoiceNumber { get; set; } = string.Empty;
    public PaymentTerm? PaymentTerm { get; set; }
    public InvoiceStatus Status { get; set; }
    public string? Notes { get; set; }

    [Precision(18, 2)]
    public decimal SubTotal { get; set; }

    [Precision(18, 2)]
    public decimal Tax { get; set; }

    [Precision(18, 3)]
    public decimal TaxPercentage { get; set; }

    [Precision(18, 2)]
    public decimal Freight { get; set; }

    [Precision(18, 2)]
    public decimal Total { get; set; }

    [ForeignKey(nameof(Project))]
    public Guid? ProjectId { get; set; }
    public virtual Project? Project { get; set; }

    [ForeignKey(nameof(ProjectLocation))]
    public Guid? ProjectLocationId { get; set; }
    public virtual ProjectLocation? ProjectLocation { get; set; }

    [ForeignKey(nameof(Vendor))]
    public Guid? VendorId { get; set; }
    public virtual Vendor? Vendor { get; set; }

    [ForeignKey(nameof(PurchaseOrder))]
    public Guid? PurchaseOrderId { get; set; }
    public virtual PurchaseOrder? PurchaseOrder { get; set; }
    public ICollection<Document> Documents { get; } = [];
    public ICollection<Material> Materials { get; } = [];
}

public enum InvoiceStatus
{
    Pending = 0,
    PartiallyPaid = 1,
    Paid = 2,
}

public enum PaymentTerm
{
    Net30Days = 0,
    Net45Days = 1,
    Net60Days = 2,
}
