﻿using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using ProcureBuilder.Documents.DTOs;
using ProcureBuilder.Invoices.Entities;
using ProcureBuilder.Locations.DTOs;
using ProcureBuilder.Projects.DTOs;
using ProcureBuilder.PurchaseOrders.DTOs;
using ProcureBuilder.Vendors.DTOs;
using System.ComponentModel.DataAnnotations;

namespace ProcureBuilder.Invoices.DTOs;

public class InvoiceDTO
{
    [Required]
    [DataType(DataType.Text)]
    [StringLength(maximumLength: 200, MinimumLength = 1,
     ErrorMessage = "Invoice Number must be between 1 to 200 characters in length.")]
    public string InvoiceNumber { get; set; } = string.Empty;

    [Required]
    [DataType(DataType.Text)]
    [StringLength(maximumLength: 200, MinimumLength = 1,
        ErrorMessage = "Title must be between 1 to 200 characters in length.")]
    public string Title { get; set; } = string.Empty;


    [Required]
    [DataType(DataType.DateTime)]
    public DateTimeOffset InvoiceDate { get; set; } = DateTimeOffset.UtcNow;


    [Required]
    [DataType(DataType.DateTime)]
    public DateTimeOffset DueDate { get; set; } = DateTimeOffset.UtcNow;

    public string? VendorInvoiceNumber { get; set; }
    public PaymentTerm? PaymentTerm { get; set; }
    public InvoiceStatus Status { get; set; }
    public string? Notes { get; set; }

    [Precision(18, 2)]
    public decimal SubTotal { get; set; }

    [Precision(18, 2)]
    public decimal Tax { get; set; }

    [Precision(18, 3)]
    public decimal TaxPercentage { get; set; }

    //[Precision(18, 2)]
    //public decimal Freight { get; set; }

    [Precision(18, 2)]
    public decimal Total { get; set; }
    public string? ModifiedBy { get; set; }
}

public class CreateInvoiceDTO : InvoiceDTO
{
    [Required]
    public required Guid ProjectId { get; set; }

    [Required]
    public Guid VendorId { get; set; }
    public Guid? ProjectLocationId { get; set; }

    [Required]
    public Guid PurchaseOrderId { get; set; }
    public IList<Guid> DeleteDocumentsId { get; set; } = [];
    public IFormFile? VendorInvoiceDocument { get; set; }
    public IFormFile? PurchaseOrderDocument { get; set; }
    public IList<IFormFile> Attachments { get; set; } = [];
    public IList<InvoiceMaterialDTO> Materials { get; set; } = [];
}

public class GetInvoiceDTO : InvoiceDTO
{
    public Guid? Id { get; set; }
    public required string PurchaseOrderNumber { get; set; }
    public GetProjectListDTO? Project {  get; set; }

    [Precision(18, 2)]
    public decimal PurchaseOrderCost { get; set; }

    [Precision(18, 2)]
    public decimal PurchaseOrderBilled { get; set; }

    [Precision(18, 2)]
    public decimal RemainingTotal => PurchaseOrderCost - PurchaseOrderBilled;
    public GetLocationsListDTO? Location { get; set; }
    public GetVendorList? Vendor { get; set; }
    public GetPurchaseOrderListDTO? PurchaseOrder { get; set; }
    public IList<InvoiceMaterialDTO> Materials { get; set; } = [];
    public IList<DocumentDTO> Documents { get; set; } = [];
    public DateTimeOffset? ModifiedDate { get; set; }
    public string? CreatedBy { get; set; }
    public DateTimeOffset? CreatedDate { get; set; }
    public string? LastModifiedBy => ModifiedBy ?? CreatedBy;
    public DateTimeOffset? LastModifiedDate => ModifiedDate ?? CreatedDate;
}

public class InvoiceMaterialDTO
{
    public Guid? Id { set; get; }
    public required string Name { get; set; }
    public required string CostCode { get; set; }
    public string? Description { get; set; }
    public double Quantity { get; set; }
    public required string UnitOfMeasure {  get; set; }

    [Precision(18, 2)]
    public decimal UnitRate { get; set; }

    [Precision(18, 2)]
    public decimal Cost { get; set; }
    public double? BalanceQuantity { get; set; }

    [Precision(18, 2)]
    public decimal? RemainingBudget { get; set; }

    [Precision(18, 2)]
    public decimal? PreviouslyBilled { get; set; }
    public double TotalQuantity { get; set; }
}

public class InvoiceNumberListDTO
{
    public Guid Id { set; get; }
    public string InvoiceNumber { get; set; } = string.Empty;
}
