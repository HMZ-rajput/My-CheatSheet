﻿using ProcureBuilder.Common.DTOs;
using ProcureBuilder.Invoices.Entities;

namespace ProcureBuilder.Invoices.DTOs;

public class InvoiceFilters : QueryStringParameters
{
    public Guid? ProjectId { get; set; }
    public string? Search { get; set; }
    public bool IsDueToday { get; set; }
    public bool IsOverDue { get; set; }
    public bool IsUpComing { get; set; }
    public InvoiceStatus? Status { get; set; }

    public bool IsForReport { get; set; }
    public Guid? VendorId { get; set; }
    public DateTimeOffset? DueDateFrom { get; set; }
    public DateTimeOffset? DueDateTo { get; set; }
    public DateTimeOffset? InvoiceDateFrom { get; set; }
    public DateTimeOffset? InvoiceDateTo { get; set; }
    public decimal? AmountFrom { get; set; }
    public decimal? AmountTo { get; set; }
    public PaymentTerm? PaymentTerm { get; set; }
}

public class InvoiceReportFilters : QueryStringParameters
{
    public Guid? ProjectId { get; set; }
    public Guid? PurchaseOrderId { get; set; }
    public Guid? VendorId { get; set; }
    public string? InvoiceNumber { get; set; }
    public string? CostCode { get; set; }
    public InvoiceStatus? InvoiceStatus { get; set; }
    public DateTimeOffset? InvoiceDateFrom { get; set; }
    public DateTimeOffset? InvoiceDateTo { get; set; }
    public DateTimeOffset? DueDateFrom { get; set; }
    public DateTimeOffset? DueDateTo { get; set; }
    public decimal? AmountFrom { get; set; }
    public decimal? AmountTo { get; set; }
}

public class PurchaseOrderInvoiceReportFilters
{
    public Guid? ProjectId { get; set; }
    public Guid? VendorId { get; set; }
    public string? InvoiceNumber { get; set; }
    public string? CostCode { get; set; }
    public InvoiceStatus? InvoiceStatus { get; set; }
    public DateTimeOffset? InvoiceDateFrom { get; set; }
    public DateTimeOffset? InvoiceDateTo { get; set; }
    public DateTimeOffset? DueDateFrom { get; set; }
    public DateTimeOffset? DueDateTo { get; set; }
    public decimal? AmountFrom { get; set; }
    public decimal? AmountTo { get; set; }
}