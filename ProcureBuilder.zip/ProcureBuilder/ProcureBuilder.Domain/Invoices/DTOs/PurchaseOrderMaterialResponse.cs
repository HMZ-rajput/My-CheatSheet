﻿using ProcureBuilder.Common.DTOs;

namespace ProcureBuilder.Invoices.DTOs;

public class PurchaseOrderMaterialResponse : BaseResponse
{
    public decimal? PurchaseOrderTaxPercentage { get; set; }
    public IList<InvoiceMaterialDTO> Materials { get; set; } = [];
}

