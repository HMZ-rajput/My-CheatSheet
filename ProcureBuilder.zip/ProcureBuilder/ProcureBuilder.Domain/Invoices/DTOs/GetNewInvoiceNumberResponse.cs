﻿using ProcureBuilder.Common.DTOs;

namespace ProcureBuilder.Invoices.DTOs;

public class GetNewInvoiceNumberResponse : BaseResponse
{
    public string InvoiceNumber { get; set; } = string.Empty;
}

