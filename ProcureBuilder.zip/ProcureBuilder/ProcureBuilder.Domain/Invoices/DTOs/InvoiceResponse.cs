﻿using Microsoft.EntityFrameworkCore;
using ProcureBuilder.Common.DTOs;

namespace ProcureBuilder.Invoices.DTOs;

public class InvoiceResponse : BaseResponse
{
    public GetInvoiceDTO? Invoice { get; set; }
}

public class GetAllInvoiceResponse : GetAllBaseResponse
{
    public IList<GetInvoiceDTO> Invoices { get; set; } = [];

    [Precision(18, 2)]
    public decimal? TotalAmount { get; set; }
    public int? TotalNet30 { get; set; }
    public int? TotalNet45 { get; set; }
    public int? TotalNet60 { get; set; }
    public int? TotalPending { get; set; }
    public int? TotalPartiallyPaid { get; set; }
    public int? TotalFullyPaid { get; set; }
}

public class GetAllInvoiceNumberListResponse : BaseResponse
{
    public IList<InvoiceNumberListDTO> Data { get; set; } = [];
}

public class  GetAllInvoiceProjectReportResponse : GetAllBaseResponse
{
    public IList<InvoiceProjectReportDTO> Data { get; set; } = [];
}

public class GetAllInvoiceProjectCostCodeReportResponse : GetAllBaseResponse
{
    public IList<InvoiceProjectCostCodeReportDTO> Data { get; set; } = [];
}

public class GetAllInvoicePurchaseOrderReportResponse : GetAllBaseResponse
{
    public IList<InvoicePurchaseOrderReportDTO> Data { get; set; } = [];
}

public class GetAllPurchaseOrderInvoicesResponse : BaseResponse
{
    public IList<PurchaseOrderInvoiceReportDTO> Data { get; set; } = [];
}
