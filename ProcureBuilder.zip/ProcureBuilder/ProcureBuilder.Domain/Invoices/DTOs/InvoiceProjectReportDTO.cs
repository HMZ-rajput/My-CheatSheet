﻿using Microsoft.EntityFrameworkCore;

namespace ProcureBuilder.Invoices.DTOs;

public class InvoiceReportDTO
{
    public string? ProjectName { get; set; }

    [Precision(18, 2)]
    public decimal SumOfPurchaseOrders { get; set; }

    [Precision(18, 2)]
    public decimal SumOfInvoicesReceived { get; set; }

    [Precision(18, 2)]
    public decimal RemainingToBePaid => SumOfPurchaseOrders - SumOfInvoicesReceived;

}

public class InvoiceProjectReportDTO : InvoiceReportDTO
{

    [Precision(18, 2)]
    public decimal InvoicedToDatePerc => SumOfPurchaseOrders == 0 ? 0 : SumOfInvoicesReceived / SumOfPurchaseOrders * 100;
}

public class InvoicePurchaseOrderReportDTO : InvoiceReportDTO
{
    public Guid PurchaseOrderId { get; set; }
    public string PurchaseOrderNumber { get; set; } = string.Empty;
    public string CostCodes { get; set; } = string.Empty;
    public string? Vendor { get; set; }
    public bool IsAboveBudget { get; set; }
}

public class InvoiceProjectCostCodeReportDTO
{
    public string? ProjectName { get; set; }
    public string? CostCode { get; set; } 

    [Precision(18, 2)]
    public decimal SumOfMoneyCommittedToCostCode { get; set; } //bit material ayenge ya PO ka sum?

    [Precision(18, 2)]
    public decimal SumOfInvoiceReceivedToCostCode { get; set; }

    [Precision(18, 2)]
    public decimal RemainingToBePaidToCostCode => SumOfMoneyCommittedToCostCode - SumOfInvoiceReceivedToCostCode;

    [Precision(18, 2)]
    public decimal InvoicedToDatePerc => SumOfMoneyCommittedToCostCode == 0 ? 0 : SumOfInvoiceReceivedToCostCode / SumOfMoneyCommittedToCostCode * 100;
}

public class PurchaseOrderInvoiceReportDTO
{
    public string? Material { get; set; }
    public string? CostCode { get; set; }
    public string? Description { get; set; }

    [Precision(18, 2)]
    public decimal PurchaseOrderQuantity { get; set; }

    [Precision(18, 2)]
    public decimal PurchaseOrderCostPerLineItem { get; set; }

    [Precision(18, 2)]
    public decimal QuantityBilledToDate { get; set; }

    [Precision(18, 2)]
    public decimal CostBilledToDate { get; set; }

    [Precision(18, 2)]
    public decimal RemainderQuantity => PurchaseOrderQuantity - QuantityBilledToDate;

    [Precision(18, 2)]
    public decimal RemainderOfCostToBeBilled => PurchaseOrderCostPerLineItem - CostBilledToDate;
    public string InvoiceNumbers { get; set; } = string.Empty;
}
