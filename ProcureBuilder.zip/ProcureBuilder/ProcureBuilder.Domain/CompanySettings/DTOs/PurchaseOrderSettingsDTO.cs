﻿using Microsoft.EntityFrameworkCore;
using ProcureBuilder.Common.DTOs;
using ProcureBuilder.Identity.DTOs;

namespace ProcureBuilder.CompanySettings.DTOs;

public class PurchaseOrderSettingsDTO
{
    [Precision(18, 2)]
    public decimal? LimitOne { get; set; }

    [Precision(18, 2)]
    public decimal? LimitTwoFrom { get; set; }

    [Precision(18, 2)]
    public decimal? LimitTwoTo { get; set; }

    public string? TermsAndConditions { get; set; }
}

public class UpdatePurchaseOrderSettingsDTO : PurchaseOrderSettingsDTO
{
    public IList<string> SuperApproverIds { get; set; } = [];
    public IList<string> LimitOneApproverIds { get; set; } = [];
    public IList<string> LimitTwoApproverIds { get; set; } = [];
    public string? ModifiedBy { get; set; }
}

public class GetPurchaseOrderSettingsResponse : BaseResponse
{
    public GetPurchaseOrderSettingsDTO? Settings { get; set; }
}

public class GetPurchaseOrderSettingsDTO : PurchaseOrderSettingsDTO
{
    public IList<GetUserListDTO> SuperApprovers { get; set; } = [];
    public IList<GetUserListDTO> LimitOneApprovers { get; set; } = [];
    public IList<GetUserListDTO> LimitTwoApprovers { get; set; } = [];
    public DateTimeOffset? ModifiedDate { get; set; }
    public string? CreatedBy { get; set; }
    public string? ModifiedBy { get; set; }
    public DateTimeOffset? CreatedDate { get; set; }
    public string? LastModifiedBy => ModifiedBy ?? CreatedBy;
    public DateTimeOffset? LastModifiedDate => ModifiedDate ?? CreatedDate;
}
