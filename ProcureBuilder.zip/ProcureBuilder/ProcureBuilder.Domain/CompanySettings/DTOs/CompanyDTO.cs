﻿using Microsoft.AspNetCore.Http;
using ProcureBuilder.Common.DTOs;
using ProcureBuilder.Documents.DTOs;
using System.ComponentModel.DataAnnotations;

namespace ProcureBuilder.CompanySettings.DTOs;

public class GetCompanyInfoResponse : BaseResponse
{
    public GetCompanyInfoDTO? CompanyInfo { get; set; }
}

public class GetCompanyInfoDTO : CompanyInfoDTO
{
    public DateTimeOffset? ModifiedDate { get; set; }
    public string? CreatedBy { get; set; }
    public DateTimeOffset? CreatedDate { get; set; }
    public string? LastModifiedBy => ModifiedBy ?? CreatedBy;
    public DateTimeOffset? LastModifiedDate => ModifiedDate ?? CreatedDate;
    public DocumentDTO? Logo { get; set; }
}

public class CompanyInfoDTO
{
    [Required]
    public string Name { get; set; } = string.Empty;
    public string? Address { get; set; }
    public string? City { get; set; }
    public string? State { get; set; }
    public string? Zip { get; set; }
    public string? Email { get; set; }
    public string? PhoneNumber { get; set; }
    public string? Fax { get; set; }
    public string? ModifiedBy { get; set; }
}

public class UpdateCompanyInfoRequest
{
    [Required]
    public string Name { get; set; } = string.Empty;
    public string? Address { get; set; }
    public string? City { get; set; }
    public string? State { get; set; }
    public string? Zip { get; set; }
    public string? Email { get; set; }
    public string? PhoneNumber { get; set; }
    public string? Fax { get; set; }
    public string? ModifiedBy { get; set; }
    public IFormFile? Logo { get; set; }
    public bool ShouldDeleteLogo { get; set; }
}
