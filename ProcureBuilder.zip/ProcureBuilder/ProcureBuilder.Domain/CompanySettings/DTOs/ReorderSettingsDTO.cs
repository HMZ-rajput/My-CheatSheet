﻿using ProcureBuilder.Common.DTOs;

namespace ProcureBuilder.CompanySettings.DTOs;

public class ReorderSettingsDTO
{
    public decimal? ReorderLimit { get; set; }
}

public class UpdateReorderSettings : ReorderSettingsDTO
{
    public string? ModifiedBy { get; set; }
}

public class GetReorderSettingsResponse : BaseResponse
{
    public decimal? ReorderLimit { get; set; }
    public DateTimeOffset? ModifiedDate { get; set; }
    public string? CreatedBy { get; set; }
    public string? ModifiedBy { get; set; }
    public DateTimeOffset? CreatedDate { get; set; }
    public string? LastModifiedBy => ModifiedBy ?? CreatedBy;
    public DateTimeOffset? LastModifiedDate => ModifiedDate ?? CreatedDate;
}
