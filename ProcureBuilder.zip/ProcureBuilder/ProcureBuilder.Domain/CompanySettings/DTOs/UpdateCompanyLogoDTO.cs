﻿using Microsoft.AspNetCore.Http;
using ProcureBuilder.Common.DTOs;
using ProcureBuilder.Documents.DTOs;

namespace ProcureBuilder.CompanySettings.DTOs;

public class UpdateCompanyLogoDTO
{
    public IFormFile? Logo { get; set; }
}

public class GetCompanyLogoResponse : BaseResponse
{
    public DocumentDTO? Data { get; set; }
}
