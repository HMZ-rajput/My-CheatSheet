﻿using Microsoft.EntityFrameworkCore;
using ProcureBuilder.ActivityLogs.Entities;
using ProcureBuilder.Common.Entities;
using ProcureBuilder.Documents.Entities;
using ProcureBuilder.Identity.Entities;
using System.ComponentModel.DataAnnotations.Schema;

namespace ProcureBuilder.CompanySettings.Entities;

public class Company : ModifiableDomainEntity
{
    public string Name { get; set; } = string.Empty;
    public string Address { get; set; } = string.Empty;
    public string City { get; set; } = string.Empty;
    public string State { get; set; } = string.Empty;
    public string Zip { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public string PhoneNumber { get; set; } = string.Empty;
    public string Fax { get; set; } = string.Empty;

    [Precision(18, 2)]
    public decimal? ReorderLimit { get; set; }

    [Precision(18, 2)]
    public decimal? LimitOne { get; set; }

    [Precision(18, 2)]
    public decimal? LimitTwoFrom { get; set; }

    [Precision(18, 2)]
    public decimal? LimitTwoTo { get; set; }

    public string? TermsAndConditions { get; set; }

    public ICollection<ApplicationUser> SuperApprovers { get; } = [];
    public ICollection<ApplicationUser> LimitOneApprovers { get; } = [];
    public ICollection<ApplicationUser> LimitTwoApprovers { get; } = [];

    [ForeignKey(nameof(Document))]
    public Guid? DocumentId { get; set; }
    public virtual Document? Document { get; set; }

    public ICollection<ActivityLog> ActivityLogs { get; } = [];
}
