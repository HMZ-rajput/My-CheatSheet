﻿using Microsoft.AspNetCore.Identity;
using ProcureBuilder.CompanySettings.Entities;
using ProcureBuilder.Projects.Entities;
using ProcureBuilder.PurchaseOrders.Entities;
using System.ComponentModel.DataAnnotations.Schema;

namespace ProcureBuilder.Identity.Entities;

public class ApplicationUser : IdentityUser
{
    public string FirstName { get; set; } = "FirstName";
    public string LastName { get; set; } = "LastName";
    public string? CellNumber { get; set; }
    //public bool IsActive { get; set; } = true;
    public UserStatus Status { get; set; }
    public int? PasswordOTP { get; set; }
    public DateTimeOffset OTPDate { get; set; }
    public DateTimeOffset? CreatedDate { get; set; }
    public string? CreatedBy { get; set; }
    public DateTimeOffset? ModifiedDate { get; set; }
    public string? ModifiedBy { get; set; }
    public bool EmailNotificationsEnabled { get; set; }
    public bool TextNotificationsEnabled { get; set; }
    public ICollection<Project> Projects { get; } = [];
    public ICollection<Project> ManagedProjects { get; } = [];
    public ICollection<PurchaseOrder> ContactPurchaseOrders { get; } = [];
    public ICollection<PurchaseOrder> AssignedPurchaseOrders { get; } = [];

    [ForeignKey(nameof(SuperApproverCompany))]
    public Guid? SuperApproverCompanyId { get; set; }
    public virtual Company? SuperApproverCompany { get; set; }

    [ForeignKey(nameof(LimitOneApproverCompany))]
    public Guid? LimitOneApproverCompanyId { get; set; }
    public virtual Company? LimitOneApproverCompany { get; set; }

    [ForeignKey(nameof(LimitTwoApproverCompany))]
    public Guid? LimitTwoApproverCompanyId { get; set; }
    public virtual Company? LimitTwoApproverCompany { get; set; }
    public ICollection<PurchaseOrderApproval> PurchaseOrderApprovals { get; } = [];
}

public enum UserRole
{
    FieldCraft = 0,
    Engineer = 1,
    Superintendent = 2,
    Admin = 3,
    SuperAdmin = 4
}

public enum UserStatus
{
    Active = 0,
    InvitePending = 1,
    InActive = 2,
}