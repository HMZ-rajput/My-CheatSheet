﻿using ProcureBuilder.Common.DTOs;

namespace ProcureBuilder.Identity.DTOs;

public class AuthResponse : BaseResponse
{
    public string UserId { get; set; } = string.Empty;
    public string FirstName { get; set; } = string.Empty;
    public string LastName { get; set; } = string.Empty;
    public string UserName { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public string UserRole { get; set; } = string.Empty;
    public string Role { get; set; } = string.Empty;
    public string BearerToken { get; set; } = string.Empty;
    public bool IsActive { get; set; } = true;
    public bool IsAuthenticated { get; set; }
    public string? PhoneNumber { get; set; }
    public string? CellNumber { get; set; }
    public bool? IsEmailNotificationsEnabled { get; set; }
    public bool? IsTextNotificationsEnabled { get; set; }
    public DateTimeOffset? CreatedDate { get; set; }
    public string? CreatedBy { get; set; }

}