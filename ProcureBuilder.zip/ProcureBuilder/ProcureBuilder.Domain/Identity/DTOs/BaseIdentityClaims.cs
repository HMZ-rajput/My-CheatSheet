﻿using System.Security.Claims;

public static class BaseIdentityClaims
{
    private static readonly AsyncLocal<string?> _userId = new();
    private static readonly AsyncLocal<string?> _userName = new();
    private static readonly AsyncLocal<string?> _userRole = new();

    public static string? UserId => _userId.Value;
    public static string? UserName => _userName.Value;
    public static string? UserRole => _userRole.Value;

    public static void SetUserCredentials(ClaimsPrincipal user)
    {
        var claimsIdentity = (ClaimsIdentity?)user.Identity;
        _userName.Value = claimsIdentity?.FindFirst(ClaimTypes.Name)?.Value;
        _userId.Value = claimsIdentity?.FindFirst(ClaimTypes.NameIdentifier)?.Value;
        _userRole.Value = claimsIdentity?.FindFirst(ClaimTypes.Role)?.Value;
    }

    public static string? GetUserIdFromClaims(ClaimsPrincipal user)
    {
        var claimsIdentity = (ClaimsIdentity)user.Identity!;
        return claimsIdentity.FindFirst(ClaimTypes.NameIdentifier)?.Value;
    }

    public static void ClearUserCredentials(ClaimsPrincipal user)
    {
        _userName.Value = null;
        _userId.Value = null;
        _userRole.Value = null;
    }

    public static string? GetUserNameFromClaims(ClaimsPrincipal user)
    {
        var claimsIdentity = (ClaimsIdentity)user.Identity!;
        return claimsIdentity.FindFirst(ClaimTypes.Name)?.Value;
    }
}
