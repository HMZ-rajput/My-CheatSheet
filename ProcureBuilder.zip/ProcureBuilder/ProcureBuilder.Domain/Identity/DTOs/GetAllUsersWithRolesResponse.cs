﻿using ProcureBuilder.Common.DTOs;

namespace ProcureBuilder.Identity.DTOs;

public class GetAllUsersWithRolesResponse : BaseResponse
{
    public List<GetUserWithRoleDTO> Users { get; set; } = [];
}

public class GetUserWithRoleDTO
{
    public string Id { get; set; } = Guid.NewGuid().ToString();
    public string? UserName { get; set; }
    public string? Role { get; set; }
    public string FirstName { get; set; } = string.Empty;
    public string LastName { get; set; } = string.Empty;
    public string FullName => FirstName + " " + LastName;
    public string? PhoneNumber {  get; set; }
}