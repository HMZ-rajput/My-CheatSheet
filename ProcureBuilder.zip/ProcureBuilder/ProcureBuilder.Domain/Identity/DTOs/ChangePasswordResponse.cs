﻿using ProcureBuilder.Common.DTOs;

namespace ProcureBuilder.Identity.DTOs;

public class ChangePasswordResponse : BaseResponse
{
}
