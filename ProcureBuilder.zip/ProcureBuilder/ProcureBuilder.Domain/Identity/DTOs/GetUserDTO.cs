﻿using ProcureBuilder.Identity.Entities;

namespace ProcureBuilder.Identity.DTOs;

public class UserDTO
{
    public string? Id { get; set; }
    public string FirstName { get; set; } = "FirstName";
    public string LastName { get; set; } = "LastName";
    public string? UserName { get; set; }
    public string? Email { get; set; } = string.Empty;
    public string? PhoneNumber { get; set; } = string.Empty;
    public UserStatus IsActive { get; set; }
}
