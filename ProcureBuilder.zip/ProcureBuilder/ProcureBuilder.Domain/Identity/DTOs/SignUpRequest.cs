﻿using ProcureBuilder.Identity.Entities;
using System.ComponentModel.DataAnnotations;

namespace ProcureBuilder.Identity.DTOs;

public class SignUpRequest
{
    [Required]
    public required string FirstName { get; set; }

    [Required]
    public required string LastName { get; set; }

    [Required]
    [RegularExpression("\\w+([-+.']\\w+)*@\\w+([-.]\\w+)*\\.\\w+([-.]\\w+)*",ErrorMessage = "Invalid Email Address")]
    public required string Email { get; set; }

    public string? PhoneNumber { get; set; }

    public string? CellNumber { get; set; }

    [Required]
    public bool EmailNotificationsEnabled { get; set; }

    [Required]
    public bool TextNotificationsEnabled { get; set; }

    [Required]
    [EnumDataType(typeof(UserRole), ErrorMessage = "Invalid value. Value must be between 0 - 3")]
    public required UserRole Role { get; set; }

    public string? ModifiedBy { get; set; }
}