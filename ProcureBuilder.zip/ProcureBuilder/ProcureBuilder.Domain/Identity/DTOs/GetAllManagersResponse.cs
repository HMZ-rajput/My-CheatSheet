﻿using ProcureBuilder.Common.DTOs;

namespace ProcureBuilder.Identity.DTOs;

public class GetAllManagersResponse : BaseResponse
{
    public List<GetUserWithRoleDTO> Managers { get; set; } = [];
}
