﻿using ProcureBuilder.Common.DTOs;
using ProcureBuilder.Identity.Entities;

namespace ProcureBuilder.Identity.DTOs;

public class GetAllUsersResponse : GetAllBaseResponse
{
    public List<GetUserDTO> Users { get; set; } = [];
}

public class GetUserDTO
{
    public string Id { get; set; } = Guid.NewGuid().ToString();
    public string? UserName { get; set; }
    public string FirstName { get; set; } = string.Empty;
    public string LastName { get; set; } = string.Empty;
    public string FullName => FirstName + " " + LastName;
    public string? Email { get; set; }
    public string Role { get; set; } = string.Empty;
    public string? PhoneNumber { get; set; }
    public UserStatus Status { get; set; }
    public string? CellNumber { get; set; }
    public bool? IsEmailNotificationsEnabled { get; set; }
    public bool? IsTextNotificationsEnabled { get; set; }
    public DateTimeOffset? CreatedDate { get; set; }
    public string? CreatedBy { get; set; }
    public DateTimeOffset? ModifiedDate { get; set; }
    public string? ModifiedBy { get; set; }
    public string? LastModifiedBy => ModifiedBy ?? CreatedBy;
    public DateTimeOffset? LastModifiedDate => ModifiedDate ?? CreatedDate;
}

public class GetUserByIdResponse : BaseResponse
{
    public GetUserDTO? User { get; set; }
}