﻿using ProcureBuilder.Common.DTOs;
using ProcureBuilder.Identity.Entities;

namespace ProcureBuilder.Identity.DTOs;

public class Userfilters : QueryStringParameters
{
    public string? Search { get; set; }
    public UserStatus? Status { get; set; }
    public UserRole? Role { get; set; }
}
