﻿using ProcureBuilder.Identity.Entities;
using System.ComponentModel.DataAnnotations;

namespace ProcureBuilder.Identity.DTOs;

public class UpdatePersonalInfoRequest
{
    [Required]
    public required string FirstName { get; set; }

    [Required]
    public required string LastName { get; set; }

    public string? PhoneNumber { get; set; }

    public string? CellNumber { get; set; }

    public string? ModifiedBy { get; set; }
    public bool? IsEmailNotificationsEnabled { get; set; }
    public bool? IsTextNotificationsEnabled { get; set; }
}

public class UpdateInternalUserRequest : UpdatePersonalInfoRequest
{
    public required string id { get; set; }

    [Required]
    [EnumDataType(typeof(UserRole), ErrorMessage = "Invalid value. Value must be between 0 - 3")]
    public required UserRole Role { get; set; }
}