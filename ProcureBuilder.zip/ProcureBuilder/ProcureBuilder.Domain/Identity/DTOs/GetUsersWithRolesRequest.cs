﻿using ProcureBuilder.Identity.Entities;

namespace ProcureBuilder.Identity.DTOs;

public class GetUsersWithRolesRequest
{
    public IList<UserRole> Roles { get; set; } = [];
}
