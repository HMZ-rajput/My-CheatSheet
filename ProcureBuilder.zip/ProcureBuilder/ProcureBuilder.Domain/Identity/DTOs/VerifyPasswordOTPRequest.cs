﻿using ProcureBuilder.Common.DTOs;

namespace ProcureBuilder.Identity.DTOs;

public class VerifyPasswordOTPRequest
{
    public required int OTP { get; set; }
    public required string Email { get; set; }
}

public class VerifyPasswordOTPResponse : BaseResponse
{
    public string ResetPasswordToken { get; set; } = string.Empty;
}
