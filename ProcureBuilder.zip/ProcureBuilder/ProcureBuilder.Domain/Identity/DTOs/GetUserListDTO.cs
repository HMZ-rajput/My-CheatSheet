﻿namespace ProcureBuilder.Identity.DTOs;

public class GetUserListDTO
{
    public required string Id { get; set; }
    public string FullName { get; set; } = string.Empty;
}
