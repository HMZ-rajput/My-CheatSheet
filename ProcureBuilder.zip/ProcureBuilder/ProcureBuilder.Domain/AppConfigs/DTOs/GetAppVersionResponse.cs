﻿using ProcureBuilder.Common.DTOs;

namespace ProcureBuilder.AppConfigs.DTOs;

public class GetAppVersionResponse : BaseResponse
{
    public string Version { get; set; } = "1.0.0";
}
