﻿using ProcureBuilder.Common.Entities;

namespace ProcureBuilder.AppConfigs.Entities;

public class AppConfig : DomainEntity
{
    public string SettingKey { get; set; } = string.Empty;
    public string SettingValue { get; set; } = string.Empty;
}
