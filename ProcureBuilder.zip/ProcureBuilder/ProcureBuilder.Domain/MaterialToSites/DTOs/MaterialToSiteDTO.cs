﻿using ProcureBuilder.Locations.DTOs;
using ProcureBuilder.MaterialTransfers.DTOs;
using ProcureBuilder.MaterialTransfers.Entities;
using ProcureBuilder.Projects.DTOs;

namespace ProcureBuilder.MaterialToSites.DTOs;

public class MaterialToSiteDTO
{
    public string Title { get; set; } = string.Empty;
    public DateTimeOffset TransferDate { get; set; } = DateTimeOffset.Now;
    public TransferStatus Status { get; set; }
    public string? ModifiedBy { get; set; }
}

public class CreateMaterialToSiteDTO : MaterialToSiteDTO
{
    public required Guid ProjectId { get; set; }
    public required Guid OriginalLocationId { get; set; }
    public required Guid DestinationLocationId { get; set; }
    public IList<TransferingMaterialDTO> Materials { get; set; } = [];
}

public class GetMaterialToSiteDTO : MaterialToSiteDTO
{
    public Guid Id { get; set; }
    public IList<GetTransferingMaterialDTO> Materials { get; set; } = [];
    public GetProjectListDTO? OriginalProject { get; set; }
    public GetLocationsListDTO? OriginalLocation { get; set; }
    public GetLocationsListDTO? DestinationLocation { get; set; }
    public DateTimeOffset? ModifiedDate { get; set; }
    public string? CreatedBy { get; set; }
    public DateTimeOffset? CreatedDate { get; set; }
    public string? LastModifiedBy => ModifiedBy ?? CreatedBy;
    public DateTimeOffset? LastModifiedDate => ModifiedDate ?? CreatedDate;
}

