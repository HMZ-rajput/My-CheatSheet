﻿using ProcureBuilder.Common.DTOs;
using ProcureBuilder.Documents.DTOs;

namespace ProcureBuilder.MaterialReceiptInspections.DTOs;

public class MaterialReceiptInspectionResponse : BaseResponse
{
    public GetMaterialReceiptInspectionDTO? MaterialReceiptInspection {  get; set; }
}

public class AllMaterialReceiptInspectionResponse : GetAllBaseResponse
{
    public IList<GetMaterialReceiptInspectionDTO> MaterialReceiptInspections { get; set; } = [];

    public int? TotalPending { get; set; }
    public int? TotalApproved { get; set; }
    public int? TotalApprovedWithExceptions { get; set; }
    public int? TotalRejected { get; set; }
    public double? TotalRegularMaterials { get; set; }
    public double? TotalSpareMaterials { get; set; }
    public double? TotalSampleMaterials { get; set; }
}

public class MaterialImagesResponse : BaseResponse
{
    public Guid MaterialReceiptInspectionId { get; set; }
    public ICollection<DocumentDTO> MaterialImages { get; set; } = [];
}

public class DeleteMaterialImageResponse : BaseResponse
{
    public Guid MaterialReceiptInspectionId { get; set; }
    public IList<Guid> imageIds { get; set; } = [];
}

