﻿using ProcureBuilder.Common.DTOs;

namespace ProcureBuilder.MaterialReceiptInspections.DTOs;

public class GetPurchaseOrderMaterialResponse : BaseResponse
{
    public IList<InspectionMaterials> Materials { get; set; } = [];
}

