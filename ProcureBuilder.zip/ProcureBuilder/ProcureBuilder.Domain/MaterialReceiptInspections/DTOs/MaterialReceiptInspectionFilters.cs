﻿using ProcureBuilder.Common.DTOs;
using ProcureBuilder.MaterialReceiptInspections.Entities;
using ProcureBuilder.Materials.Entities;

namespace ProcureBuilder.MaterialReceiptInspections.DTOs;

public class MaterialReceiptInspectionFilters : QueryStringParameters
{
    public Guid? ProjectId { get; set; }
    public string? Search { get; set; }
    public bool IsDueToday { get; set; }
    public bool IsOverDue { get; set; }
    public bool IsUpComing { get; set; }
    public MaterialReceiptInspectionStatus? Status { get; set; }
    public DateTimeOffset? RequestedDateFrom { get; set; }
    public DateTimeOffset? RequestedDateTo { get; set; }
    public bool IsForReport { get; set; }
    public Guid? LocationId { get; set; }
    public Guid? PurchaseOrderId { get; set; }
    public MaterialType? MaterialType { get; set; }
}

public class MaterialReceiptInspectionPDFFilters
{
    public IList<Guid> MaterialReceiptInspectionIds { get; set; } = [];
}