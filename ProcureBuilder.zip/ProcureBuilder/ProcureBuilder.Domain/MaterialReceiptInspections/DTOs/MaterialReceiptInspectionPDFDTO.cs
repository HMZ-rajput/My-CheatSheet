﻿using ProcureBuilder.MaterialReceiptInspections.Entities;

namespace ProcureBuilder.MaterialReceiptInspections.DTOs;

public class MaterialReceiptInspectionPDFDTO
{
    public string Title { get; set; } = string.Empty;
    public string? PurchaseOrderNumber { get; set; }
    public string? ProjectName { get; set; }
    public string? LocationName { get; set; }
    public string? SubLocationName { get; set; }
    public DateTimeOffset ExpectedDate { get; set; }
    public MaterialReceiptInspectionStatus Status { get; set; }
    public IList<MaterialReceiptInspectionMaterialDTO> Materials { get; set; } = [];
    public IList<MaterialReceiptInspectionQualityQuestionDTO> QualityQuestions { get; set; } = [];
}

public class MaterialReceiptInspectionMaterialDTO
{
    public string Name { get; set; } = string.Empty;
    public string UnitOfMeasure { get; set; } = string.Empty;
    public double Quantity { get; set; }
    public double TotalQuantity { get; set; }
}

public class MaterialReceiptInspectionQualityQuestionDTO
{
    public string Question { get; set; } = string.Empty;
    public string? Answer { get; set; }
}
