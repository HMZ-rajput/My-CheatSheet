﻿using Microsoft.AspNetCore.Http;
using ProcureBuilder.Documents.DTOs;
using ProcureBuilder.Locations.DTOs;
using ProcureBuilder.MaterialReceiptInspections.Entities;
using ProcureBuilder.Projects.DTOs;
using ProcureBuilder.PurchaseOrders.DTOs;
using ProcureBuilder.QualityQuestions.DTOs;

namespace ProcureBuilder.MaterialReceiptInspections.DTOs;

public class MaterialReceiptInspectionDTO
{
    public required string Title { get; set; }
    public required DateTimeOffset ExpectedDate { get; set; }
    public MaterialReceiptInspectionStatus? Status { get; set; }
    public DateTimeOffset? RequestedDate { get; set; }
    public string? ModifiedBy { get; set; }
}

public class CreateInspectionDTO : MaterialReceiptInspectionDTO
{
    public Guid ProjectId { get; set; }
    public Guid ProjectLocationId { get; set; }
    public Guid? SubLocationId { get; set; }
    public Guid PurchaseOrderId { get; set; }
    public IFormFile? BillOfLanding {  get; set; }
    public IList<UpdateQualityAnswerDTO> Answers { get; set; } = [];
    public IList<InspectionMaterials> Materials { get; set; } = [];
}

public class UpdateInspectionDTO : CreateInspectionDTO
{
    public Guid? DeleteBillOfLandingId { get; set; }
}

public class GetMaterialReceiptInspectionDTO : MaterialReceiptInspectionDTO
{
    public Guid Id {  get; set; }
    public GetProjectListDTO? Project { get; set; }
    public GetLocationsListDTO? Location { get; set; }
    public GetSubLocationsListDTO? SubLocation { get; set; }
    public GetPurchaseOrderListDTO? PurchaseOrder { get; set; }
    public IList<InspectionMaterials> Materials { get; set; } = [];
    public IList<DocumentDTO> Documents { get; set; } = [];
    public IList<GetQualityAnswerDTO> QualityQuestions { get; set; } = [];
    public DateTimeOffset? ModifiedDate { get; set; }
    public string? CreatedBy { get; set; }
    public DateTimeOffset? CreatedDate { get; set; }
    public string? LastModifiedBy => ModifiedBy ?? CreatedBy;
    public DateTimeOffset? LastModifiedDate => ModifiedDate ?? CreatedDate;
}


public class UpdateImagesDTO 
{
    public IList<Guid> DeleteDocumentIds { get; set; } = [];
    public IList<IFormFile> MaterialImages { get; set; } = [];
    public string? ModifiedBy { get; set; }
}

public class InspectionMaterials
{
    public Guid? Id { get; set; }
    public required string Name { get; set; }
    public double Quantity { get; set; }
    public double Samples { get; set; }
    public double Spares { get; set; }
    public double Regular { get; set; }
    public double TotalQuantity { get; set; }
    public double TotalSamples { get; set; }
    public double TotalSpares { get; set; }
    public double TotalRegular { get; set; }
    public required string UnitOfMeasure { get; set; }
    public string? CostCode { get; set; } = string.Empty;
}