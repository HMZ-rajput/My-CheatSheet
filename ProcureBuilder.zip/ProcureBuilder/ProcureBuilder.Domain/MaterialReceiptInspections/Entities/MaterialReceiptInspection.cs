﻿using ProcureBuilder.Common.Entities;
using ProcureBuilder.Documents.Entities;
using ProcureBuilder.Locations.Entities;
using ProcureBuilder.Materials.Entities;
using ProcureBuilder.Projects.Entities;
using ProcureBuilder.PurchaseOrders.Entities;
using ProcureBuilder.QualityQuestions.Entities;
using System.ComponentModel.DataAnnotations.Schema;

namespace ProcureBuilder.MaterialReceiptInspections.Entities;
public class MaterialReceiptInspection : ModifiableDomainEntity
{
    public string Title { get; set; } = string.Empty;
    public DateTimeOffset ExpectedDate { get; set; }
    public MaterialReceiptInspectionStatus Status { get; set; }
    public DateTimeOffset? RequestedDate { get; set; }

    [ForeignKey(nameof(PurchaseOrder))]
    public Guid? PurchaseOrderId { get; set; }
    public virtual PurchaseOrder? PurchaseOrder { get; set; }

    [ForeignKey(nameof(Project))]
    public Guid? ProjectId { get; set; }
    public virtual Project? Project { get; set; }

    [ForeignKey(nameof(ProjectLocation))]
    public Guid? ProjectLocationId { get; set; }
    public virtual ProjectLocation? ProjectLocation { get; set; }

    [ForeignKey(nameof(SubLocation))]
    public Guid? SubLocationId { get; set; }
    public virtual SubLocation? SubLocation { get; set; }

    public ICollection<Material> Materials { get; set; } = [];
    public ICollection<QualityAnswer> QualityAnswers { get; set; } = [];
    public ICollection<Document> Documents { get; set; } = [];
}

public enum MaterialReceiptInspectionStatus
{
    Pending = 0,
    ApprovedWithExceptions = 1,
    Approved = 2,
    Rejected = 3,
}