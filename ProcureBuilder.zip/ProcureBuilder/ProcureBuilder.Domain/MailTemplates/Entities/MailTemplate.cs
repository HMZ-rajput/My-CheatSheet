﻿using ProcureBuilder.Common.Entities;

namespace ProcureBuilder.MailTemplates.Entities;

public class MailTemplate : ModifiableDomainEntity
{
    public required string Subject { get; set; }
    public required string Template {  get; set; }
    public string? Row {  get; set; }
    public MailType Type { get; set; }
}

public enum MailType
{
    Signup = 0,
    PasswordOTP = 1,
    ReorderQuote = 2,
    ResendInvite = 3,
    VendorPurchaseOrder = 5
}

