﻿using ProcureBuilder.Common.Entities;
using System.ComponentModel.DataAnnotations.Schema;

namespace ProcureBuilder.DashBoards.Entities;

public class DeletedNotificationsByUser : DomainEntity
{
    public string? UserId { get; set; }

    [ForeignKey(nameof(Notification))]
    public Guid NotificationId { get; set; }
    public virtual Notification? Notification { get; set; }
}
