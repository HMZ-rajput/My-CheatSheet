﻿using Microsoft.EntityFrameworkCore.Metadata.Internal;
using ProcureBuilder.Common.Entities;
using ProcureBuilder.Materials.Entities;
using ProcureBuilder.Projects.Entities;
using System.ComponentModel.DataAnnotations.Schema;

namespace ProcureBuilder.DashBoards.Entities;

public class Notification : ModifiableDomainEntity
{
    public string Title { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
    public EntityType EntityType { get; set; }
    public NotificationCategory Category { get; set; }
    public Actions? Action { get; set; }

    [ForeignKey(nameof(Project))]
    public Guid ProjectId { get; set; }
    public Project? Project { get; set; }

    public Guid? EntityId { get; set; }
    public ICollection<Material> Materials { get; } = [];
    public ICollection<DeletedNotificationsByUser> DeletedNotificationsByUsers { get; } = [];
}

public enum EntityType
{
    PurchaseOrder = 1,
    Reorder = 2,
    MaterialTransfer = 3,
    MaterialToSite = 4,
    Invoice = 5,
    ChangeOrder = 6,
    MaterialReceiptInspection = 7,
    Project = 8,
}

public enum NotificationCategory
{
    ActionItems = 0,
    UpcomingDeliverables = 1,
    WaitingFor = 2,
}

public enum Actions
{
    PurchaseOrderApproval = 0,
    ChangeOrderApproval = 1,
    MaterialTransferApproval = 2,
    MaterialToSiteApproval = 3,
    CreateReorder = 4,
    ExpectingMaterials = 5,
    VendorApproval = 6
}

