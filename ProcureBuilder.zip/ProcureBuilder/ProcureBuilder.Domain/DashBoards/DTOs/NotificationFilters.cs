﻿namespace ProcureBuilder.DashBoards.DTOs;

public class NotificationFilters
{
    public DateTimeOffset Date { get; set; } = DateTimeOffset.Now;
    public ProjectComparisionType ProjectComparisonType { get; set; }
}

public enum ProjectComparisionType
{
    LastMonth = 0,
    Last6Month = 1,
    LastYear = 2,
    AllTime = 3,
}

