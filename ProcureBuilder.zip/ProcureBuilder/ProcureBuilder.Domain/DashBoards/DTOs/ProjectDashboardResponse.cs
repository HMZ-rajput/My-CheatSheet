﻿using ProcureBuilder.Common.DTOs;
using ProcureBuilder.Materials.DTOs;
using ProcureBuilder.Materials.Entities;

namespace ProcureBuilder.DashBoards.DTOs;

public class ProjectDashboardResponse : BaseResponse
{
    public ProjectDashboardDTO? Dashboard { get; set; }
}

public class AllProjectDashboardResponse : BaseResponse
{
    public AllProjectsDashboardDTO? Dashboard { get; set; }
}

public class SideNotificationResponse : BaseResponse
{
    public IList<WeeklySideNotification> WeeklySideNotifications { get; set; } = [];
}

public class StatusUpdateResponse : BaseResponse
{
    public string? Text { get; set; }
    public IList<MaterialDTO> Materials { get; set; } = [];
}

