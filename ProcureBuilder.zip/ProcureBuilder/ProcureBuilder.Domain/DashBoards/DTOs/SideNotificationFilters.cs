﻿namespace ProcureBuilder.DashBoards.DTOs;

public class SideNotificationFilters
{
    public DateTimeOffset Date { get; set; } = DateTimeOffset.Now;
    public Guid? ProjectId { get; set; }
    public string? UserId { get; set; }
}

