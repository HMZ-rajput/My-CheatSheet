﻿using ProcureBuilder.DashBoards.Entities;
using ProcureBuilder.Materials.DTOs;
using ProcureBuilder.Projects.Entities;

namespace ProcureBuilder.DashBoards.DTOs;

public class NotificationDTO
{
    public Guid Id { get; set; }
    public string Description { get; set; } = string.Empty;
    public Guid? EntityId { get; set; }
    public Guid? ProjectId { get; set; }
    public EntityType EntityType { get; set; }
    public Actions? Action { get; set; }
    public IList<MaterialDTO> Materials { get; set; } = [];
}

public class SideNotificationDTO
{
    public Guid Id { get; set; }
    public string Title { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
    public string? Date { get; set; }
    public EntityType EntityType { get; set; }
}

public class WeeklySideNotification
{
    public IList<SideNotificationDTO> notifications { get; set; } = [];
    public DateTimeOffset? Date { get; set; }
}

public class ProjectDashboardDTO
{
    public ProjectDetailsDTO? ProjectDetails { get; set; }
    public ProjectStackHolderDetailDTO? ProjectOwner { get; set; }
    public IList<ProjectStackHolderDetailDTO> ProjectManagers { get; set; } = [];
    public ProjectMaterialsDTO? Materials { get; set; }
    public IList<NotificationDTO> ActionItemNotifications { get; set; } = [];
    public IList<NotificationDTO> UpcomingDeliverableNotifications { get; set; } = [];
    public IList<NotificationDTO> WaitingForNotifications { get; set; } = [];
    public IList<SideNotificationDTO> SideNotifications { get; set; } = [];
}

public class AllProjectsDashboardDTO
{
    public ProjectComparisionDTO? ProjectComparision { get; set; }
    public IList<NotificationDTO> ActionItemNotifications { get; set; } = [];
    public IList<NotificationDTO> UpcomingDeliverableNotifications { get; set; } = [];
    public IList<NotificationDTO> WaitingForNotifications { get; set; } = [];
    public IList<SideNotificationDTO> SideNotifications { get; set; } = [];
}

public class ProjectDetailsDTO
{
    public Guid Id { get; set; }
    public string? Name { get; set; }
    public DateTimeOffset StartDate { get; set; }
    public DateTimeOffset CompletionDate { get; set; }
    public DateTimeOffset? ActualStartDate { get; set; }
    public DateTimeOffset? ActualCompletionDate { get; set; }
    public decimal? ContractPrice { get; set; }
    public ProjectStatus Status { get; set; }
}

public class ProjectStackHolderDetailDTO
{
    public string Id { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
}

public class ProjectComparisionDTO
{
    public double OpenProjectsPerc { get; set; }
    public double ClosedProjectsPerc { get; set; }
    public int OpenProjects { get; set; }
    public int ClosedProjects { get; set; }
}

public class ProjectMaterialsDTO
{
    public double MaterialsReceivedPerc { get; set; }
    public double MaterialsExpectedPerc { get; set; }
    public int MaterialsReceived {  get; set; }
    public int MaterialsExpected { get; set; }
}

public class UpdateStatusDTO
{
    public Guid NotificationId { get; set; }
    public bool IsApproved { get; set; }
    public string? ModifiedBy { get; set; }
}
