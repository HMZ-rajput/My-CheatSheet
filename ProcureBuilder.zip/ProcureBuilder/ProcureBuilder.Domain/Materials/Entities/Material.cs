﻿using Microsoft.EntityFrameworkCore;
using ProcureBuilder.ActivityLogs.Entities;
using ProcureBuilder.ChangeOrders.Entities;
using ProcureBuilder.Common.Entities;
using ProcureBuilder.Invoices.Entities;
using ProcureBuilder.Locations.Entities;
using ProcureBuilder.MaterialReceiptInspections.Entities;
using ProcureBuilder.MaterialToSites.Entities;
using ProcureBuilder.MaterialTransfers.Entities;
using ProcureBuilder.Projects.Entities;
using ProcureBuilder.PurchaseOrders.Entities;
using ProcureBuilder.Reorders.Entities;
using System.ComponentModel.DataAnnotations.Schema;

namespace ProcureBuilder.Materials.Entities;

public class Material : ModifiableDomainEntity
{
    public string Name { get; set; } = string.Empty;

    [Precision(18, 2)]
    public decimal Cost { get; set; }

    [Precision(18, 3)]
    public decimal TaxPercentage { get; set; }
    public string UnitOfMeasure { get; set; } = string.Empty;

    [Precision(18, 3)]
    public decimal UnitRate { get; set; }

    [Precision(18, 2)]
    public decimal TotalBudget { get; set; }
    public string? CostCode { get; set; }
    public double CurrentQuantity { get; set; }
    public double NewQuantity { get; set; }
    public double Quantity { get; set; }
    public double OriginalQuantity { get; set; }
    public double Spares { get; set; }
    public double Samples { get; set; }
    public double Regular { get; set; }
    public double TotalQuantity { get; set; }
    public double TotalSpares { get; set; }
    public double TotalSamples { get; set; }
    public double TotalRegular { get; set; }
    public bool IsRefillable { get; set; }
    public string? Description { get; set; }
    public double? BalanceQuantity { get; set; }

    [Precision(18, 2)]
    public decimal? RemainingBudget { get; set; }

    [Precision(18, 2)]
    public decimal? PreviouslyBilled { get; set; }

    [ForeignKey(nameof(Project))]
    public Guid? ProjectId { get; set; }
    public virtual Project? Project { get; set; }

    [ForeignKey(nameof(SubLocation))]
    public Guid? SubLocationId { get; set; }
    public virtual SubLocation? SubLocation { get; set; }

    [ForeignKey(nameof(ProjectLocation))]
    public Guid? ProjectLocationId { get; set; }
    public virtual ProjectLocation? ProjectLocation { get; set; }

    public ICollection<ActivityLog> ActivityLogs { get; } = [];

    [ForeignKey(nameof(PurchaseOrder))]
    public Guid? PurchaseOrderId { get; set; }
    public virtual PurchaseOrder? PurchaseOrder { get; set; }
    public MaterialType? Type { get; set; }
    public EntityType EntityType { get; set; }

    [ForeignKey(nameof(ChangeOrder))]
    public Guid? ChangeOrderId { get; set; }
    public virtual ChangeOrder? ChangeOrder { get; set; }

    [ForeignKey(nameof(Reorder))]
    public Guid? ReorderId { get; set; }
    public virtual Reorder? Reorder { get; set; }

    [ForeignKey(nameof(Invoice))]
    public Guid? InvoiceId { get; set; }
    public virtual Invoice? Invoice { get; set; }

    [ForeignKey(nameof(MaterialTransfer))]
    public Guid? MaterialTransferId { get; set; }
    public MaterialTransfer? MaterialTransfer { get; set; }

    [ForeignKey(nameof(MaterialToSite))]
    public Guid? MaterialToSiteId { get; set; }
    public MaterialToSite? MaterialToSite { get; set; }

    [ForeignKey(nameof(MaterialReceiptInspection))]
    public Guid? MaterialReceiptInspectionId { get; set; }
    public MaterialReceiptInspection? MaterialReceiptInspection { get; set; }

    public bool IsMaterialAlreadyApproved { get; set; }
    public bool IsMaterialRejected { get; set; }
    public double? MaxSubmittalLeadTime { get; set; }
    public DateTimeOffset? ExpectedSubmittalDate { get; set; }
    public double? MaxMaterialLeadTime { get; set; }
    public DateTimeOffset? ExpectedDeliveryDate { get; set; }
    public SubmittalStatus? SubmittalStatus { get; set; }
    public PurchaseOrderMaterialStatus? PurchaseOrderMaterialStatus { get; set; }
}

public enum MaterialType
{
    Regular = 0,
    Sample = 1,
    Spares = 2
}

public enum EntityType
{
    Project = 0,
    PurchaseOrder = 1,
    ChangeOrder = 2,
    Inventory = 3,
    Transfer = 4,
    Reorder = 5,
    Invoice = 6,
    MaterialReceiptInspection = 7,
}

public enum PurchaseOrderMaterialStatus
{
    Pending = 0,
    PartiallyReceived = 1,
    FullyReceived = 2,
}