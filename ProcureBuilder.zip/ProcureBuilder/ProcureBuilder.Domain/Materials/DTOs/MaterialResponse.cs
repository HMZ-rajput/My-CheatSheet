﻿using Microsoft.EntityFrameworkCore;
using ProcureBuilder.Common.DTOs;
using ProcureBuilder.Projects.DTOs;
using ProcureBuilder.Projects.Entities;

namespace ProcureBuilder.Materials.DTOs;

public class MaterialResponse : BaseResponse
{
    public GetProjectDTO? Project { get; set; }
    public IList<MaterialIdDTO> Materials { get; set; } = [];
    public bool IsMaterialReceiptInspectionFormRequired { get; set; } = true;
    public int AssumedSubmittalReview { get; set; }
    public MaterialReviewPeriod AssumedSubmittalReviewPeriod { get; set; }
    [Precision(18, 2)]
    public decimal SubTotal { get; set; }

    [Precision(18, 2)]
    public decimal OtherCosts { get; set; }

    [Precision(18, 2)]
    public decimal Tax { get; set; }

    [Precision(18, 3)]
    public decimal TaxPercentage { get; set; }
    
    [Precision(18, 2)]
    public decimal Total { get; set; }
    public string? ModifiedBy { get; set; }
    public DateTimeOffset? ModifiedDate { get; set; }
    public string? CreatedBy { get; set; }
    public DateTimeOffset? CreatedDate { get; set; }
    public string? LastModifiedBy => ModifiedBy ?? CreatedBy;
    public DateTimeOffset? LastModifiedDate => ModifiedDate ?? CreatedDate;
}