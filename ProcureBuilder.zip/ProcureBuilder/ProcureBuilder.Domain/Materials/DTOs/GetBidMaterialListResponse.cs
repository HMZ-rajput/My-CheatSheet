﻿using ProcureBuilder.Common.DTOs;

namespace ProcureBuilder.Materials.DTOs
{
    public class GetBidMaterialListResponse : BaseResponse
    {
        public IList<GetBidMaterialListDTO> BidMaterials { get; set; } = [];
    }

    public class GetBidMaterialListDTO
    {
        public string? Name { get; set; }
        public string? CostCode { get; set; }
    }
}

