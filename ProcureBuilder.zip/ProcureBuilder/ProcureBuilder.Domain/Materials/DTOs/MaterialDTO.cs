﻿using Microsoft.EntityFrameworkCore;
using ProcureBuilder.Projects.Entities;
using System.ComponentModel.DataAnnotations;

namespace ProcureBuilder.Materials.DTOs;

public class MaterialDTO
{
    [Required]
    public required string Name { get; set; }

    [Precision(18, 2)]
    public decimal Cost { get; set; }
    public double Quantity { get; set; }
    public string? UnitOfMeasure { get; set; }

    [Precision(18, 3)]
    public decimal UnitRate { get; set; }

    [Precision(18, 2)]
    public decimal TotalBudget { get; set; }
    public string? CostCode { get; set; }
    public double NewQuantity { get; set; }
    public double Spares { get; set; }
    public double Sample { get; set; }
    public double Regular { get; set; }
    public bool IsRefillable { get; set; }
    public Guid? ProjectId { get; set; }
    public Guid? SubLocationId { get; set; }
}

public class MaterialProjectDTO
{
    public Guid? ProjectId { get; set; }
    public bool IsMaterialReceiptInspectionFormRequired { get; set; }

    [EnumDataType(typeof(MaterialReviewPeriod))]
    public MaterialReviewPeriod AssumedSubmittalReviewPeriod { get; set; }
    public int AssumedSubmittalReview { get; set; }

    [Precision(18, 2)]
    public decimal SubTotal { get; set; }

    [Precision(18, 2)]
    public decimal OtherCosts { get; set; }

    [Precision(18, 3)]
    public decimal TaxPercentage { get; set; }

    public decimal Tax { get; set; }

    [Precision(18, 2)]
    public decimal Total { get; set; }

    public string? ModifiedBy { get; set; }
    public IList<Guid> ChangeOrderIds { get; set; } = [];
}

public class MaterialIdDTO : MaterialDTO 
{
    public Guid? Id { get; set; }
    public Guid? ProjectLocationId {  get; set; }
}

public class CreateMaterialDTO : MaterialProjectDTO
{
    public IList<MaterialDTO> Materials { get; set; } = [];
}

public class UpdateMaterialDTO : MaterialProjectDTO
{
    public IList<MaterialIdDTO> Materials { get; set; } = [];
}

public class DeleteMaterialDTO : MaterialProjectDTO
{
    public IList<Guid> Materials { get; set; } = [];
}

public class GetMaterialDTO : UpdateMaterialDTO
{
}

public class LocationInventoryDTO
{
    public Guid? LocationId { get; set; }
    public IList<MaterialInventoryDTO> Materials { get; set; } = [];
}

public class MaterialInventoryDTO
{
    public Guid? SubLocationId { get; set; }
    public string? SubLocationName { get; set; }
    public Guid? MaterialId { get; set; }

    [Required]
    public required string Name { get; set; }

    [Required]
    public required string CostCode { get; set; }
    public double Quantity { get; set; }
    public string UnitOfMeasure { get; set; } = string.Empty;
    public double Spares { get; set; }
    public double Sample { get; set; }
    public double Regular { get; set; }
    public bool IsRefillable { get; set; }
}

public class AddInventoryRequest
{
    public IList<LocationInventoryDTO> Inventories { get; set; } = [];
    public string? ModifiedBy { get; set; }
}

public class DeleteMaterialRequest
{
    public Guid ProjectId { get; set; }
    public string? ModifiedBy { get; set; }
}