﻿using System.ComponentModel.DataAnnotations;

namespace ProcureBuilder.Materials.DTOs;

public class PurchaseOrderMaterialItemDTO
{
    public Guid? SubLocationId { get; set; }
    public string? SubLocationName { get; set; }
    public Guid? MaterialId { get; set; }

    [Required]
    public required string Name { get; set; }

    [Required]
    public required string CostCode { get; set; }
    public double NewQuantity { get; set; }
    public double Quantity { get; set; }
    public string UnitOfMeasure { get; set; } = string.Empty;
    public double Spares { get; set; }
    public double Samples { get; set; }
    public double Regular { get; set; }
    public bool IsRefillable { get; set; }
}
