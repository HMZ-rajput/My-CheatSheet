﻿using ProcureBuilder.Common.DTOs;
using ProcureBuilder.Projects.Entities;

namespace ProcureBuilder.Materials.DTOs;

public class BidMaterialFilters : QueryStringParameters
{
    public Guid? ProjectId { get; set; }
    public Guid? ProjectTypeId { get; set; }
    public bool? IsMRIRequired { get; set; }
    public decimal? TotalPriceFrom { get; set; }
    public decimal? TotalPriceTo { get; set; }
    public int? AssumedSubmittalReview { get; set; }
    public MaterialReviewPeriod? AssumedSubmittalReviewPeriod { get; set; }
}
