﻿namespace ProcureBuilder.Materials.DTOs;

public class MaterialCostAnalysisFilters
{
    public bool IsForReport { get; set; }
}