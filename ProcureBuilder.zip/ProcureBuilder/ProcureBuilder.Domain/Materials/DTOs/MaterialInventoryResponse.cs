﻿using ProcureBuilder.Common.DTOs;
using ProcureBuilder.Projects.DTOs;

namespace ProcureBuilder.Materials.DTOs;

public class MaterialInventoryResponse : BaseResponseModified
{
    public GetProjectListDTO? Project {  get; set; }
    public IList<GetLocationInventoryDTO> Inventories { get; set; } = [];
}

public class GetMaterialInventoryResponse : GetAllBaseResponseModified
{
    public GetProjectListDTO? Project { get; set; }
    public IList<GetLocationInventoryDTO> Inventories { get; set; } = [];
}

public class GetLocationInventoryDTO : LocationInventoryDTO
{
    public string? LocationName { get; set; }
}

public class GetAllInventoryResponse : GetAllBaseResponse
{
    public IList<GetLocationInventoryDTO> Inventories { get; set; } = [];
}


