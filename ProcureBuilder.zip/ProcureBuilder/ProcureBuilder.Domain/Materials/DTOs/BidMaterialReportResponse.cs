﻿using Microsoft.EntityFrameworkCore;
using ProcureBuilder.Common.DTOs;

namespace ProcureBuilder.Materials.DTOs;

public class BidMaterialReportResponse : GetAllBaseResponse
{
    public List<BidMaterialReportDTO> BidMaterials { get; set; } = [];
    public int TotalMRIFRequired { get; set; }
    public int TotalMRIFNotRequired { get; set; }
    public int TotalMaterials { get; set; }

    [Precision(18, 2)]
    public decimal TotalBudget { get; set; }
}

public class BidMaterialReportDTO
{
    public string ProjectName { get; set; } = string.Empty;
    public Guid ProjectId { get; set; }
    public string SubmittalReviewPeriod { get; set; } = string.Empty;
    public bool IsMRIFRequired { get; set; }
    public int Materials { get; set; }
    
    [Precision(18, 2)]
    public decimal Total { get; set; }
}
