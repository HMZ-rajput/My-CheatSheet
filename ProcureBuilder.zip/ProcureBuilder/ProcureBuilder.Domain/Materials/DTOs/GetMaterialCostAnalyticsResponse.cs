﻿using Microsoft.EntityFrameworkCore;
using ProcureBuilder.Common.DTOs;

namespace ProcureBuilder.Materials.DTOs;

public class GetMaterialCostAnalyticsResponse : BaseResponse
{
    public List<MaterialCostAnalyticsDTO> Materials { get; set; } = [];

    [Precision(18, 2)]
    public decimal? TotalBudgetCost { get; set; }
    [Precision(18, 2)]
    public decimal? TotalCommittedCost { get; set; }
    [Precision(18, 2)]
    public decimal? TotalCostDifference => TotalBudgetCost - TotalCommittedCost;

    [Precision(18, 2)]
    public decimal? TotalBudgetUnitRate { get; set; }
    [Precision(18, 2)]
    public decimal? TotalCommittedUnitRate { get; set; }
    [Precision(18, 2)]
    public decimal? TotalUnitRateDifference => TotalBudgetUnitRate - TotalCommittedUnitRate;

    public double? TotalBudgetQuantity { get; set; }
    public double? TotalCommittedQuantity { get; set; }
    public double? TotalQuantityDifference => TotalBudgetQuantity - TotalCommittedQuantity;
}

public class MaterialCostAnalyticsDTO
{
    public string CostCode { get; set; } = string.Empty;
    public decimal BudgetUnitRate { get; set; }
    public decimal BudgetCost { get; set; }
    public double BudgetQuantity { get; set; }
    public decimal CommittedUnitRate { get; set; }
    public decimal CommittedCost { get; set; }
    public double CommittedQuantity { get; set; }
    public string UnitOfMeasure { get; set; } = string.Empty;
    public double QuantityDifference { get; set; }
    public decimal CostDifference { get; set; }
    public bool IsOverBudget => CostDifference < 0;
    [Precision(18, 2)]
    public decimal? UnitRateDifference => BudgetUnitRate - CommittedUnitRate;
}