﻿namespace ProcureBuilder.Common.DTOs;

public abstract class BaseResponse
{
    private readonly List<string> errors = [];

    public List<string> Errors
    {
        get { return errors; }
    }

    public bool IsSuccess => errors.Count == 0;

    public void AddError(string error)
    {
        errors.Add(error);
    }
}

public abstract class GetAllBaseResponse : BaseResponse
{
    public int CurrentPage { get; set; }
    public int TotalPages { get; set; }
    public int PageSize { get; set; }
    public int TotalCount { get; set; }
    public bool HasPrevious { get; set; }
    public bool HasNext { get; set; }
}

public class GetAllBaseResponseModified : BaseResponseModified
{
    public int CurrentPage { get; set; }
    public int TotalPages { get; set; }
    public int PageSize { get; set; }
    public int TotalCount { get; set; }
    public bool HasPrevious { get; set; }
    public bool HasNext { get; set; }
}

public class BaseResponseModified : BaseResponse
{
    public DateTimeOffset? ModifiedDate { get; set; }
    public string? CreatedBy { get; set; }
    public string? ModifiedBy { get; set; }
    public DateTimeOffset? CreatedDate { get; set; }
    public string? LastModifiedBy => ModifiedBy ?? CreatedBy;
    public DateTimeOffset? LastModifiedDate => ModifiedDate ?? CreatedDate;
}