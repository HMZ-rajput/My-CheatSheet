﻿namespace ProcureBuilder.Common.DTOs;

public class CommonResponse : BaseResponse
{
}
