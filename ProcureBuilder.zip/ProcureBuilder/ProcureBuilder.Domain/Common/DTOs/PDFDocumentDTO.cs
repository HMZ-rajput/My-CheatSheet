﻿namespace ProcureBuilder.Common.DTOs;

public class PDFDocumentDTO
{
    public string FileName { get; set; } = "Procure.pdf";
    public MemoryStream? FileData { get; set; }
}

public class GeneratePDFDocumentResponse : BaseResponse
{
    public PDFDocumentDTO? Data { get; set; }
}
