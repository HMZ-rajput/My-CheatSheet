﻿using System.ComponentModel.DataAnnotations;

namespace ProcureBuilder.Common.Entities;

public abstract class DomainEntity
{
    [Key]
    public Guid Id { get; set; } = Guid.NewGuid();
    public DateTimeOffset CreatedDate { get; set; } = DateTimeOffset.UtcNow;
    public string? CreatedBy { get; set; }
    public bool IsActive { get; set; } = true;
}

public abstract class ModifiableDomainEntity : DomainEntity
{
    public DateTimeOffset? ModifiedDate { get; set; }
    public string? ModifiedBy { get; set; }
}