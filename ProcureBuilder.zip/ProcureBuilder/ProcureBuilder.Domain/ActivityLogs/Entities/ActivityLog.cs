﻿using ProcureBuilder.ChangeOrders.Entities;
using ProcureBuilder.Common.Entities;
using ProcureBuilder.CompanySettings.Entities;
using ProcureBuilder.Customers.Entities;
using ProcureBuilder.Documents.Entities;
using ProcureBuilder.Locations.Entities;
using ProcureBuilder.Materials.Entities;
using ProcureBuilder.MaterialToSites.Entities;
using ProcureBuilder.MaterialTransfers.Entities;
using ProcureBuilder.Projects.Entities;
using ProcureBuilder.PurchaseOrders.Entities;
using ProcureBuilder.QualityQuestions.Entities;
using ProcureBuilder.Reorders.Entities;
using ProcureBuilder.StorageTypes.Entities;
using ProcureBuilder.Vendors.Entities;
using System.ComponentModel.DataAnnotations.Schema;

namespace ProcureBuilder.ActivityLogs.Entities;

public class ActivityLog : DomainEntity
{
    public required string Title { get; set; }
    public string? Description { get; set; }

    public virtual Project? Project { get; set; }
    [ForeignKey(nameof(Project))]
    public Guid? ProjectId { get; set; }

    public virtual ProjectType? ProjectType { get; set; }
    [ForeignKey(nameof(ProjectType))]
    public Guid? ProjectTypeId { get; set; }

    public virtual Customer? Customer { get; set; }
    [ForeignKey(nameof(Customer))]
    public Guid? CustomerId { get; set; }

    public virtual ProjectLocation? ProjectLocation { get; set; }
    [ForeignKey(nameof(ProjectLocation))]
    public Guid? ProjectLocationId { get; set; }

    public virtual StorageType? StorageType { get; set; }
    [ForeignKey(nameof(StorageType))]
    public Guid? StorageTypeId { get; set; }

    public virtual Material? Material { get; set; }
    [ForeignKey(nameof(Material))]
    public Guid? MaterialId { get; set; }

    public virtual ChangeOrder? ChangeOrder { get; set; }
    [ForeignKey(nameof(ChangeOrder))]
    public Guid? ChangeOrderId { get; set; }

    public virtual PurchaseOrder? PurchaseOrder{ get; set; }
    [ForeignKey(nameof(PurchaseOrder))]
    public Guid? PurchaseOrderId { get; set; }

    public virtual Vendor? Vendor{ get; set; }
    [ForeignKey(nameof(Vendor))]
    public Guid? VendorId { get; set; }

    public virtual Company? Company { get; set; }
    [ForeignKey(nameof(Company))]
    public Guid? CompanyId { get; set; }

    public virtual QualityQuestion? QualityQuestion { get; set; }
    [ForeignKey(nameof(QualityQuestion))]
    public Guid? QualityQuestionId { get; set; }

    public virtual QualityAnswer? QualityAnswer { get; set; }
    [ForeignKey(nameof(QualityAnswer))]
    public Guid? QualityAnswerId { get; set; }

    public virtual Document? Document { get; set; }

    [ForeignKey(nameof(Document))]
    public Guid? DocumentId { get; set; }

    public virtual MaterialTransfer? MaterialTransfer { get; set; }

    [ForeignKey(nameof(MaterialTransfer))]
    public Guid? MaterialTransferId { get; set; }

    public virtual MaterialToSite? MaterialToSite { get; set; }

    [ForeignKey(nameof(MaterialToSite))]
    public Guid? MaterialToSiteId { get; set; }

    public virtual Reorder? Reorder{ get; set; }

    [ForeignKey(nameof(Reorder))]
    public Guid? ReorderId { get; set; }
}
