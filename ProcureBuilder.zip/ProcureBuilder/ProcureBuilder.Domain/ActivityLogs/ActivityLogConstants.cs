﻿namespace ProcureBuilder.ActivityLogs;

public static class ActivityLogConstants
{
    public const string Created = "created";
    public const string Updated = "updated";
    public const string Deleted = "deleted";
}