﻿using ProcureBuilder.ActivityLogs.Entities;
using ProcureBuilder.Common.Entities;
using ProcureBuilder.Projects.Entities;

namespace ProcureBuilder.Customers.Entities;

public class Customer : ModifiableDomainEntity
{
    public required string FirstName { get; set; }
    public required string LastName { get; set; }
    public string? CompanyName { get; set; }
    public required string PhoneNumber { get; set; }
    public string? CellPhoneNumber { get; set; }
    public required string PrimaryEmail { get; set; }
    public string? StreetAddress { get; set; }
    public string? City { get; set; }
    public string? State { get; set; }
    public string? ZipCode { get; set; }
    public ICollection<Project> Projects { get; } = [];
    public ICollection<ActivityLog> ActivityLogs { get; } = [];
}