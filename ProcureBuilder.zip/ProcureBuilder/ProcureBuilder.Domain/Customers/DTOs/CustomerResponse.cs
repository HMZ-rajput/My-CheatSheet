﻿using ProcureBuilder.Common.DTOs;

namespace ProcureBuilder.Customers.DTOs;

public class CustomerResponse : BaseResponse
{
    public GetCustomerProjectDTO? Customer { get; set; }
}