﻿using ProcureBuilder.Common.DTOs;

namespace ProcureBuilder.Customers.DTOs;

public class CustomerFilters : QueryStringParameters
{
    public string? Search { get; set; }
}