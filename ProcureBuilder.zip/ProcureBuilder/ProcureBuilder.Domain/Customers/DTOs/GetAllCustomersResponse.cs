﻿using ProcureBuilder.Common.DTOs;

namespace ProcureBuilder.Customers.DTOs;

public class GetAllCustomersResponse : GetAllBaseResponse
{
    public IList<GetCustomerProjectDTO> Customers { get; set; } = [];
}