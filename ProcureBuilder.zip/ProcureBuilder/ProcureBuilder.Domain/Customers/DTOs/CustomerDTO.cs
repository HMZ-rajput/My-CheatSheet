﻿using ProcureBuilder.Projects.DTOs;
using System.ComponentModel.DataAnnotations;

namespace ProcureBuilder.Customers.DTOs;


public class CustomerDTO
{
    [Required]
    [DataType(DataType.Text)]
    [StringLength(200, MinimumLength = 1,
        ErrorMessage = "First Name must be between 1 to 200 characters in length.")]
    public required string FirstName { get; set; }
    [Required]
    [DataType(DataType.Text)]
    [StringLength(200, MinimumLength = 1,
        ErrorMessage = "Last Name must be between 1 to 200 characters in length.")]
    public required string LastName { get; set; }
    [Required]
    [DataType(DataType.Text)]
    [StringLength(200, MinimumLength = 1,
        ErrorMessage = "Company Name must be between 1 to 200 characters in length.")]
    public required string CompanyName { get; set; }
    [Required]
    public required string PhoneNumber { get; set; }
    public string? CellPhoneNumber { get; set; }
    [Required]
    [DataType(DataType.EmailAddress)]
    [EmailAddress]
    public required string PrimaryEmail { get; set; }
    public string? StreetAddress { get; set; }
    public string? City { get; set; }
    public string? State { get; set; }
    public string? ZipCode { get; set; }
    public string? ModifiedBy { get; set; }
}
public class CreateCustomerDTO : CustomerDTO
{
    public Guid? ProjectId { get; set; }
}

public class UpdateCustomerDTO : CustomerDTO
{
}

public class GetCustomerDTO : CustomerDTO
{
    public Guid? Id { get; set; }
    public DateTimeOffset? ModifiedDate { get; set; }
    public string? CreatedBy { get; set; }
    public DateTimeOffset? CreatedDate { get; set; }
    public string? LastModifiedBy => ModifiedBy ?? CreatedBy;
    public DateTimeOffset? LastModifiedDate => ModifiedDate ?? CreatedDate;
}

public class GetCustomerProjectDTO : GetCustomerDTO
{
    public IList<GetProjectDTO> Projects { get; set; } = [];
}