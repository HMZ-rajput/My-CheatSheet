﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using ProcureBuilder.IRepositories;
using ProcureBuilder.Projects.DTOs;
using ProcureBuilder.Projects.Entities;

namespace ProcureBuilder.Controllers;

[Authorize]
[Route("api/projects")]
[ApiController]
public class ProjectController : BaseController
{
    private readonly IProjectRepository<Project> _projectRepository;

    public ProjectController(IProjectRepository<Project> projectRepository)
    {
        _projectRepository = projectRepository ?? throw new ArgumentNullException(nameof(projectRepository));
    }

    [Route("newCode")]
    [HttpGet]
    public async ValueTask<IActionResult> GetNewProjectCodeAsync() =>
        await HandleRequestAsync(_projectRepository.GetNewCodeAsync)
        .ConfigureAwait(false);

    [Route("createType")]
    [HttpPost]
    public async ValueTask<IActionResult> CreateProjectTypeAsync([FromBody] CreateProjectTypeRequest request)
    {
        request.ModifiedBy = BaseIdentityClaims.GetUserNameFromClaims(User);
        return await HandleRequestAsync(() => _projectRepository.CreateProjectTypeAsync(request)).ConfigureAwait(false);
    }

    [Route("updateType")]
    [HttpPut]
    public async ValueTask<IActionResult> UpdateProjectTypeAsync([FromBody] UpdateProjectTypeRequest request)
    {
        request.ModifiedBy = BaseIdentityClaims.GetUserNameFromClaims(User);
        return await HandleRequestAsync(() => _projectRepository.UpdateProjectTypeAsync(request)).ConfigureAwait(false);
    }

    [Route("create")]
    [HttpPost]
    public async ValueTask<IActionResult> CreateProjectAsync([FromBody] CreateProjectDTO request)
    {
        request.ModifiedBy = BaseIdentityClaims.GetUserNameFromClaims(User);
        return await HandleRequestAsync(() => _projectRepository.CreateProjectAsync(request)).ConfigureAwait(false);
    }


    [Route("delete/{projectId}")]
    [HttpDelete]
    public async ValueTask<IActionResult> DeleteProjectAsync(Guid projectId)
    {
        var modifiedBy = BaseIdentityClaims.GetUserNameFromClaims(User);
        return await HandleRequestAsync(() => _projectRepository.DeleteProjectAsync(projectId, modifiedBy)).ConfigureAwait(false);
    }

    [HttpGet]
    public async ValueTask<IActionResult> GetAllProjects([FromQuery] ProjectFilters filters) =>
        await HandleRequestAsync(() => _projectRepository.GetAllProjectsAsync(filters));

    [HttpGet("{projectId}")]
    public async ValueTask<IActionResult> GetProjectByIdAsync(Guid projectId) =>
        await HandleRequestAsync(() => _projectRepository.GetProjectByIdAsync(projectId));

    [Route("update/{projectId}")]
    [HttpPut]
    public async ValueTask<IActionResult> UpdateProjectAsync(Guid projectId, [FromBody] UpdateProjectDTO request)
    {
        request.ModifiedBy = BaseIdentityClaims.GetUserNameFromClaims(User);
        return await HandleRequestAsync(() => _projectRepository.UpdateProjectAsync(projectId, request)).ConfigureAwait(false);
    }

    [Route("types")]
    [HttpGet]
    public async ValueTask<IActionResult> GetAllProjectTypesAsync() =>
        await HandleRequestAsync(_projectRepository.GetAllProjectTypesAsync)
        .ConfigureAwait(false);

    [Route("addCustomerToProject")]
    [HttpPost]
    public async ValueTask<IActionResult> AddCustomerToProjectAsync(Guid projectId, Guid customerId)
    {
        var modifiedBy = BaseIdentityClaims.GetUserNameFromClaims(User);
        return await HandleRequestAsync(() => _projectRepository.AddCustomerToProjectAsync(projectId, customerId, modifiedBy)).ConfigureAwait(false);
    }

    [Route("access/user/{userId}")]
    [HttpPut]
    public async ValueTask<IActionResult> AllowProjectAccessAsync(string userId, [FromBody] AssignProjectRequest request)
    {
        request.ModifiedBy = BaseIdentityClaims.GetUserNameFromClaims(User);
        return await HandleRequestAsync(() => _projectRepository.AssignProjectAsync(userId, request)).ConfigureAwait(false);
    }

    [Route("list")]
    [HttpGet]
    public async ValueTask<IActionResult> GetAllProjectsAsync([FromQuery] ProjectStatus? status) =>
        await HandleRequestAsync(() => _projectRepository.GetProjectsListResponseAsync(status));
}
