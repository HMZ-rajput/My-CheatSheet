﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using ProcureBuilder.IRepositories;
using ProcureBuilder.Reorders.DTOs;
using ProcureBuilder.Reorders.Entities;

namespace ProcureBuilder.Controllers;

[Authorize]
[Route("api/reorders")]
[ApiController]
public class ReorderController : BaseController
{
    private readonly IReorderRepository<Reorder> _reorderRepository;

    public ReorderController(IReorderRepository<Reorder> reorderRepository)
    {
        _reorderRepository = reorderRepository ?? throw new ArgumentNullException(nameof(reorderRepository));
    }

    [Route("create/project/{projectId}")]
    [HttpPost]
    public async ValueTask<IActionResult> CreateReorderAsync(Guid projectId, [FromForm] CreateReorderRequest request)
    {
        request.ModifiedBy = BaseIdentityClaims.GetUserNameFromClaims(User);
        return await HandleRequestAsync(() => _reorderRepository.CreateReorderAsync(projectId, request)).ConfigureAwait(false);
    }

    [HttpGet]
    public async ValueTask<IActionResult> GetReordersAsync([FromQuery] ReorderFilters filters) =>
        await HandleRequestAsync(() => _reorderRepository.GetAllReorderAsync(filters)).ConfigureAwait(false);

    [Route("{reorderId}")]
    [HttpGet]
    public async ValueTask<IActionResult> GetReorderByIdAsync(Guid reorderId) =>
    await HandleRequestAsync(() => _reorderRepository.GetReorderByIdAsync(reorderId)).ConfigureAwait(false);

    [Route("updateRecipient/{reorderId}")]
    [HttpPut]
    public async ValueTask<IActionResult> UpdateReorderRecipientAsync(Guid reorderId, [FromForm] UpdateReorderRecipientRequest request)
    {
        request.ModifiedBy = BaseIdentityClaims.GetUserNameFromClaims(User);
        return await HandleRequestAsync(() => _reorderRepository.UpdateReorderRecipentAsync(reorderId, request)).ConfigureAwait(false);
    }

    [Route("delete/{reorderId}")]
    [HttpDelete]
    public async ValueTask<IActionResult> DeleteReorderAsync(Guid reorderId)
    {
        string? ModifiedBy = BaseIdentityClaims.GetUserNameFromClaims(User);
        return await HandleRequestAsync(() => _reorderRepository.DeleteReorderAsync(reorderId, ModifiedBy)).ConfigureAwait(false);
    }

    [Route("update/project/{projectId}/reorder/{reorderId}")]
    [HttpPut]
    public async ValueTask<IActionResult> UpdateReorderAsync(Guid reorderId, Guid projectId, [FromForm] UpdateReorderRequest request)
    {
        string? ModifiedBy = BaseIdentityClaims.GetUserNameFromClaims(User);
        return await HandleRequestAsync(() => _reorderRepository.UpdateReorderAsync(reorderId, projectId, request)).ConfigureAwait(false);
    }

    [Route("newReorderNumber")]
    [HttpGet]
    public async ValueTask<IActionResult> GetNewReorderNumberAsync() =>
    await HandleRequestAsync(() => _reorderRepository.GetNewReorderNumberAsync()).ConfigureAwait(false);
}
