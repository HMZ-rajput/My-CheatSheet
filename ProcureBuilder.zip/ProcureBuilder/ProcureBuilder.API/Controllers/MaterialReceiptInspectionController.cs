﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using ProcureBuilder.Common.DTOs;
using ProcureBuilder.IRepositories;
using ProcureBuilder.MaterialReceiptInspections.DTOs;
using ProcureBuilder.MaterialReceiptInspections.Entities;

namespace ProcureBuilder.Controllers;

[Authorize]
[Route("api/materialReceiptInspection")]
[ApiController]
public class MaterialReceiptInspectionController : BaseController
{
    private readonly IMaterialReceiptInspectionRepository<MaterialReceiptInspection> _materialReceiptInspectionRepository;

    public MaterialReceiptInspectionController(IMaterialReceiptInspectionRepository<MaterialReceiptInspection> materialReceiptInspectionRepository)
    {
        _materialReceiptInspectionRepository = materialReceiptInspectionRepository ?? throw new ArgumentNullException(nameof(materialReceiptInspectionRepository));
    }

    [Route("create")]
    [HttpPost]
    public async ValueTask<IActionResult> CreateMaterialReceiptInspectionAsync([FromForm] CreateInspectionDTO request)
    {
        request.ModifiedBy = BaseIdentityClaims.GetUserNameFromClaims(User);
        return await HandleRequestAsync(() => _materialReceiptInspectionRepository.CreateMaterialReceiptInspectionAsync(request)).ConfigureAwait(false);
    }

    [Route("{materialReceiptInspectionId}")]
    [HttpGet]
    public async ValueTask<IActionResult> GetMaterialReceiptInspectionByIdAsync(Guid materialReceiptInspectionId) =>
        await HandleRequestAsync(() => _materialReceiptInspectionRepository.GetMaterialReceiptInspectionByIdAsync(materialReceiptInspectionId)).ConfigureAwait(false);

    [HttpGet]
    public async ValueTask<IActionResult> GetAllMaterialReceiptInspectionAsync([FromQuery] MaterialReceiptInspectionFilters request) =>
        await HandleRequestAsync(() => _materialReceiptInspectionRepository.GetAllMaterialReceiptInspectionAsync(request)).ConfigureAwait(false);

    [Route("update/{materialReceiptInspectionId}")]
    [HttpPut]
    public async ValueTask<IActionResult> UpdateMaterialReceiptInspectionAsync(Guid materialReceiptInspectionId, [FromForm] UpdateInspectionDTO request)
    {
        request.ModifiedBy = BaseIdentityClaims.GetUserNameFromClaims(User);
        return await HandleRequestAsync(() => _materialReceiptInspectionRepository.UpdateMaterialReceiptInspectionAsync(materialReceiptInspectionId, request)).ConfigureAwait(false);
    }

    [Route("updateMaterialImage/{materialReceiptInspectionId}")]
    [HttpPut]
    public async ValueTask<IActionResult> UpdateMaterialReceiptInspectionImagesAsync(Guid materialReceiptInspectionId, [FromForm] UpdateImagesDTO request)
    {
        request.ModifiedBy = BaseIdentityClaims.GetUserNameFromClaims(User);
        return await HandleRequestAsync(() => _materialReceiptInspectionRepository.UpdateMaterialReceiptInspectionMaterialImagesAsync(materialReceiptInspectionId, request)).ConfigureAwait(false);
    }

    [Route("delete/{materialReceiptInspectionId}")]
    [HttpDelete]
    public async ValueTask<IActionResult> DeleteMaterialReceiptInspectionByIdAsync(Guid materialReceiptInspectionId)
    {
        var modifiedBy = BaseIdentityClaims.GetUserNameFromClaims(User);
        return await HandleRequestAsync(() => _materialReceiptInspectionRepository.DeleteMaterialReceiptInspectionAsync(materialReceiptInspectionId, modifiedBy)).ConfigureAwait(false);
    }

    [Route("deleteMaterialImage/{materialReceiptInspectionId}")]
    [HttpDelete]
    public async ValueTask<IActionResult> DeleteMaterialReceiptInspectionImagesAsync(Guid materialReceiptInspectionId)
    {
        var ModifiedBy = BaseIdentityClaims.GetUserNameFromClaims(User);
        return await HandleRequestAsync(() => _materialReceiptInspectionRepository.DeleteMaterialReceiptInspectionMaterialImagesAsync(materialReceiptInspectionId, ModifiedBy)).ConfigureAwait(false);
    }

    [Route("materialList/{purchaseOrderId}")]
    [HttpGet]
    public async ValueTask<IActionResult> GetPurchaseOrderMaterialsAsync(Guid purchaseOrderId) =>
        await HandleRequestAsync(() => _materialReceiptInspectionRepository.GetPurchaseOrderMaterialsAsync(purchaseOrderId)).ConfigureAwait(false);

    [Route("pdf")]
    [HttpPost]
    public async ValueTask<IActionResult> GetMaterialReceiptInspectionsPDFAsync([FromBody] MaterialReceiptInspectionPDFFilters filters)
    {
        var response = new GeneratePDFDocumentResponse();
        try
        {
            response = await _materialReceiptInspectionRepository.GenerateMaterialReceiptInspectionAsync(filters).ConfigureAwait(false);

            if (response.Data is null || response.Data.FileData is null)
            {
                throw new Exception("An error occurred while trying to generate the document. Please try again.");
            }

            return File(response.Data.FileData, "application/pdf", response.Data.FileName);
        }
        catch (Exception ex)
        {
            response.AddError("An error occurred while trying to generate the document. Please try again.");
            response.AddError(ex.Message);
            return BadRequest(response);
        }
    }
}
