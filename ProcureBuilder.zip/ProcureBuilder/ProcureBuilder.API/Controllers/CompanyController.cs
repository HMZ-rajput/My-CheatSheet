﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using ProcureBuilder.CompanySettings.DTOs;
using ProcureBuilder.CompanySettings.Entities;
using ProcureBuilder.IRepositories;
 
namespace ProcureBuilder.Controllers;

[Route("api/company")]
[ApiController]
public class CompanyController : BaseController
{
    private readonly ICompanyRepository<Company> _companyRepository;

    public CompanyController(ICompanyRepository<Company> companyRepository)
    {
        _companyRepository = companyRepository ?? throw new ArgumentNullException(nameof(companyRepository));
    }

    [Authorize]
    [Route("updateInfo")]
    [HttpPost]
    public async ValueTask<IActionResult> UpdateCompanyInfoAsync([FromForm] UpdateCompanyInfoRequest request)
    {
        request.ModifiedBy = BaseIdentityClaims.GetUserNameFromClaims(User);
        return await HandleRequestAsync(() => _companyRepository.UpdateCompanyInfoAsync(request)).ConfigureAwait(false);
    }

    [Authorize]
    [Route("updateReorderSettings")]
    [HttpPost]
    public async ValueTask<IActionResult> UpdateReorderSettingsAsync([FromBody] UpdateReorderSettings request)
    {
        request.ModifiedBy = BaseIdentityClaims.GetUserNameFromClaims(User);
        return await HandleRequestAsync(() => _companyRepository.UpdateReorderSettingsAsync(request)).ConfigureAwait(false);
    }

    [Authorize]
    [Route("updatePurchaseOrderSettings")]
    [HttpPost]
    public async ValueTask<IActionResult> UpdatePurchaseOrderSettingsAsync([FromBody] UpdatePurchaseOrderSettingsDTO request)
    {
        request.ModifiedBy = BaseIdentityClaims.GetUserNameFromClaims(User);
        return await HandleRequestAsync(() => _companyRepository.UpdatePurchaseOrderSettingsAsync(request)).ConfigureAwait(false);
    }

    [Authorize]
    [Route("purchaseOrderSettings")]
    [HttpGet]
    public async ValueTask<IActionResult> GetPurchaseOrderSettingsAsync()
    {
        return await HandleRequestAsync(() => _companyRepository.GetPurchaseOrderSettingsAsync()).ConfigureAwait(false);
    }

    [Authorize]
    [Route("reorderSettings")]
    [HttpGet]
    public async ValueTask<IActionResult> GetReorderSettingsAsync()
    {
        return await HandleRequestAsync(() => _companyRepository.GetReorderSettingsAsync()).ConfigureAwait(false);
    }

    [Route("logo")]
    [HttpGet]
    public async ValueTask<IActionResult> GetCompanyLogoAsync()
    {
        return await HandleRequestAsync(() => _companyRepository.GetCompanyLogoAsync()).ConfigureAwait(false);
    }

    [Authorize]
    [Route("updateLogo")]
    [HttpPost]
    public async ValueTask<IActionResult> UpdateLogoAsync([FromForm] UpdateCompanyLogoDTO request)
    {
        return await HandleRequestAsync(() => _companyRepository.UpdateCompanyLogoAsync(request)).ConfigureAwait(false);
    }

    [Route("info")]
    [HttpGet]
    public async ValueTask<IActionResult> GetCompanyInfoAsync()
    {
        return await HandleRequestAsync(() => _companyRepository.GetCompanyInfoAsync()).ConfigureAwait(false);
    }
}
