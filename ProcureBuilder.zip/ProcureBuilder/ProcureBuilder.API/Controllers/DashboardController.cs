﻿using Microsoft.AspNetCore.Mvc;
using ProcureBuilder.DashBoards.DTOs;
using ProcureBuilder.Identity.DTOs;
using ProcureBuilder.IRepositories;
using ProcureBuilder.Materials.DTOs;
using ProcureBuilder.Projects.DTOs;
using ProcureBuilder.Projects.Entities;

namespace ProcureBuilder.Controllers;

[Route("api/dashboard")]
[ApiController]
public class DashboardController : BaseController
{
    private readonly IDashboardRepository<Project> _dashboardRepository;

    public DashboardController(IDashboardRepository<Project> dashboardRepository)
    {
        _dashboardRepository = dashboardRepository ?? throw new ArgumentNullException(nameof(dashboardRepository));
    }

    [Route("{projectId}")]
    [HttpGet]
    public async ValueTask<IActionResult> GetDashboardByProjectIdAsync(Guid projectId, [FromQuery] NotificationFilters filters)
    {
        var userId = BaseIdentityClaims.GetUserIdFromClaims(User);
        return await HandleRequestAsync(() => _dashboardRepository.GetDashboardByProjectIdAsync(projectId, userId, filters));
    }

    [Route("materialCostAnalysis/{projectId}")]
    [HttpGet]
    public IActionResult GetDashboardByProjectIdAsync(Guid projectId, [FromQuery] MaterialCostAnalysisFilters filters) =>
        HandleRequest(() => _dashboardRepository.GetMaterialCostAnalysis(projectId, filters));

    [HttpGet]
    public async ValueTask<IActionResult> GetDashboardAsync([FromQuery] NotificationFilters filters)
    {
        var userId = BaseIdentityClaims.GetUserIdFromClaims(User);
        return await HandleRequestAsync(() => _dashboardRepository.GetDashboardAsync(userId, filters));
    }

    [HttpGet("sideNotification")]
    public async ValueTask<IActionResult> GetSideNotificationsAsync([FromQuery] SideNotificationFilters filters)
    {
        var userId = BaseIdentityClaims.GetUserIdFromClaims(User);
        return await HandleRequestAsync(() => _dashboardRepository.GetSideNotification(userId, filters));
    }

    [Route("update/{entityId}")]
    [HttpPut]
    public async ValueTask<IActionResult> UpdateStatusAsync(Guid entityId, [FromBody] UpdateStatusDTO request)
    {
        request.ModifiedBy = BaseIdentityClaims.GetUserNameFromClaims(User);
        return await HandleRequestAsync(() => _dashboardRepository.UpdateStatus(entityId, request)).ConfigureAwait(false);
    }

    [Route("notification/delete/{id}")]
    [HttpPut]
    public async ValueTask<IActionResult> DeleteNotificationByIdAsync(Guid id)
    {
        var modifiedBy = BaseIdentityClaims.GetUserNameFromClaims(User);
        var userId = BaseIdentityClaims.GetUserIdFromClaims(User);
        return await HandleRequestAsync(() => _dashboardRepository.DeleteNotificationByIdAsync(userId, modifiedBy, id)).ConfigureAwait(false);
    }
}
