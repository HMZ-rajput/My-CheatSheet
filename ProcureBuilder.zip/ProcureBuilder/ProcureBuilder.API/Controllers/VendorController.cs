﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using ProcureBuilder.IRepositories;
using ProcureBuilder.Vendors.DTOs;
using ProcureBuilder.Vendors.Entities;

namespace ProcureBuilder.Controllers;

[Authorize]
[Route("api/vendors")]
[ApiController]
public class VendorController : BaseController
{
    private readonly IVendorRepository<Vendor> _vendorRepository;
    public VendorController(IVendorRepository<Vendor> vendorRepository)
    {
        _vendorRepository = vendorRepository ?? throw new ArgumentNullException(nameof(vendorRepository));
    }

    [Route("createDivision")]
    [HttpPost]
    public async ValueTask<IActionResult> CreateDivisionAsync([FromBody] CreateDivisionRequest request)
    {
        request.ModifiedBy = BaseIdentityClaims.GetUserNameFromClaims(User);
        return await HandleRequestAsync(() => _vendorRepository.CreateDivisionAsync(request)).ConfigureAwait(false);
    }

    [Route("updateDivision")]
    [HttpPut]
    public async ValueTask<IActionResult> UpdateDivisionAsync([FromBody] UpdateDivisionRequest request)
    {
        request.ModifiedBy = BaseIdentityClaims.GetUserNameFromClaims(User);
        return await HandleRequestAsync(() => _vendorRepository.UpdateDivisionAsync(request)).ConfigureAwait(false);
    }

    [Route("create")]
    [HttpPost]
    public async ValueTask<IActionResult> CreateVendorAsync([FromBody] CreateVendorDTO request)
    {
        request.ModifiedBy = BaseIdentityClaims.GetUserNameFromClaims(User);
        return await HandleRequestAsync(() => _vendorRepository.CreateVendorAsync(request)).ConfigureAwait(false);
    }

    [HttpGet]
    public async ValueTask<IActionResult> GetAllVendors([FromQuery] VendorFilters filters) =>
        await HandleRequestAsync(() => _vendorRepository.GetAllVendorsAsync(filters));

    [Route("divisions")]
    [HttpGet]
    public async ValueTask<IActionResult> GetAllDivisionAsync() =>
        await HandleRequestAsync(_vendorRepository.GetAllDivisionAsync).ConfigureAwait(false);

    [HttpGet("{vendorId}")]
    public async ValueTask<IActionResult> GetVendorByIdAsync(Guid vendorId) =>
        await HandleRequestAsync(() => _vendorRepository.GetVendorByIdAsync(vendorId));

    [Route("update/{vendorId}")]
    [HttpPut]
    public async ValueTask<IActionResult> UpdateVendorAsync(Guid vendorId, [FromBody] UpdateVendorDTO request)
    {
        request.ModifiedBy = BaseIdentityClaims.GetUserNameFromClaims(User);
        return await HandleRequestAsync(() => _vendorRepository.UpdateVendorAsync(vendorId, request)).ConfigureAwait(false);
    }

    [Route("list")]
    [HttpGet]
    public async ValueTask<IActionResult> GetVendorListAsync() =>
        await HandleRequestAsync(() => _vendorRepository.GetVendorListAsync()).ConfigureAwait(false);


    [Route("delete/{vendorId}")]
    [HttpDelete]
    public async ValueTask<IActionResult> DeleteVendorAsync(Guid vendorId)
    {
        var modifiedBy = BaseIdentityClaims.GetUserNameFromClaims(User);
        return await HandleRequestAsync(() => _vendorRepository.DeleteVendorAsync(vendorId, modifiedBy)).ConfigureAwait(false);
    }
}
