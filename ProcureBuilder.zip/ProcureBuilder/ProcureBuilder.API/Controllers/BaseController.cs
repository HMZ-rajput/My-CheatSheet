﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using ProcureBuilder.Application;
using ProcureBuilder.Common.DTOs;

namespace ProcureBuilder.Controllers;

public class BaseController : ControllerBase
{
    protected async ValueTask<IActionResult> HandleRequestAsync<T>(Func<ValueTask<T>> func) where T : BaseResponse, new()
    {
        BaseIdentityClaims.SetUserCredentials(User);

        var response = new T();
        try
        {
            response = await func().ConfigureAwait(false);
            return Ok(response);
        }
        catch (UnauthorizedAccessException ex)
        {
            response.Errors.Add(AppEnvironment.GenericSQLDatabaseError);
            response.Errors.Add(ex.Message);
            return Unauthorized(response);
        }
        catch (SqlException ex)
        {
            response.Errors.Add(AppEnvironment.GenericSQLDatabaseError);
            response.Errors.Add(ex.Message);
            return BadRequest(response);
        }
        catch (DbUpdateException ex)
        {
            response.Errors.Add(AppEnvironment.GenericSQLDatabaseError);
            response.Errors.Add(ex.Message);
            return BadRequest(response);
        }
        catch (Exception ex)
        {
            response.Errors.Add(AppEnvironment.GenericSQLDatabaseError);
            response.Errors.Add(ex.Message);
            return BadRequest(response);
        }
        finally
        {
            BaseIdentityClaims.ClearUserCredentials(User);
        }
    }

    protected IActionResult HandleRequest<T>(Func<T> func) where T : BaseResponse, new()
    {
        var response = new T();
        try
        {
            response = func();
            return Ok(response);
        }
        catch (SqlException)
        {
            response.Errors.Add(AppEnvironment.GenericSQLDatabaseError);
            return BadRequest(response);
        }
        catch (Exception ex)
        {
            response.Errors.Add(ex.Message);
            return BadRequest(response);
        }
    }
}