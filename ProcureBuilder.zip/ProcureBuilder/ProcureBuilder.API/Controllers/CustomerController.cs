﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using ProcureBuilder.Customers.DTOs;
using ProcureBuilder.Customers.Entities;
using ProcureBuilder.IRepositories;

namespace ProcureBuilder.Controllers;

[Authorize]
[Route("api/customers")]
[ApiController]
public class CustomerController : BaseController
{
    private readonly ICustomerRepository<Customer> _customerRepository;

    public CustomerController(ICustomerRepository<Customer> customerRepository)
    {
        _customerRepository = customerRepository ?? throw new ArgumentNullException(nameof(customerRepository));
    }

    [Route("create")]
    [HttpPost]
    public async ValueTask<IActionResult> CreateCustomerAsync([FromBody] CreateCustomerDTO request)
    {
        request.ModifiedBy = BaseIdentityClaims.GetUserNameFromClaims(User);
        return await HandleRequestAsync(() => _customerRepository.CreateCustomerAsync(request)).ConfigureAwait(false);
    }


    [Route("delete/{customerId}")]
    [HttpDelete]
    public async ValueTask<IActionResult> DeleteCustomerAsync(Guid customerId)
    {
        var modifiedBy = BaseIdentityClaims.GetUserNameFromClaims(User);
        return await HandleRequestAsync(() => _customerRepository.DeleteCustomerAsync(customerId, modifiedBy)).ConfigureAwait(false);
    }

    [HttpGet]
    public async ValueTask<IActionResult> GetAllCustomersAsync([FromQuery] CustomerFilters filters) =>
        await HandleRequestAsync(() => _customerRepository.GetAllCustomersAsync(filters));

    [HttpGet("{customerId}")]
    public async ValueTask<IActionResult> GetCustomerByIdAsync(Guid customerId) =>
        await HandleRequestAsync(() => _customerRepository.GetCustomerByIdAsync(customerId));

    [Route("update/{customerId}")]
    [HttpPut]
    public async ValueTask<IActionResult> UpdateCustomerAsync(Guid customerId, [FromBody] UpdateCustomerDTO request)
    {
        request.ModifiedBy = BaseIdentityClaims.GetUserNameFromClaims(User);
        return await HandleRequestAsync(() => _customerRepository.UpdateCustomerAsync(customerId, request)).ConfigureAwait(false);
    }

    [Route("remove/{customerId}/project/{projectId}")]
    [HttpPut]
    public async ValueTask<IActionResult> RemoveCustomerFromProjectAsync(Guid customerId, Guid projectId)
    {
        var modifiedBy = BaseIdentityClaims.GetUserNameFromClaims(User);
            return await HandleRequestAsync(() => _customerRepository.RemoveCustomerFromProjectAsync(projectId, customerId, modifiedBy)).ConfigureAwait(false);
    }
}