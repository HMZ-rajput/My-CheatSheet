﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using ProcureBuilder.IRepositories;
using ProcureBuilder.MaterialToSites.DTOs;
using ProcureBuilder.MaterialToSites.Entities;

namespace ProcureBuilder.Controllers;

[Authorize]
[Route("api/materialToSite")]
[ApiController]
public class MaterialToSiteController : BaseController
{
    private readonly IMaterialToSiteRepository<MaterialToSite> _materialToSiteRepository;

    public MaterialToSiteController(IMaterialToSiteRepository<MaterialToSite> materialToSiteRepository)
    {
        _materialToSiteRepository = materialToSiteRepository ?? throw new ArgumentNullException(nameof(_materialToSiteRepository));
    }

    [Route("create")]
    [HttpPost]
    public async ValueTask<IActionResult> CreateMaterialToSiteAsync([FromBody] CreateMaterialToSiteDTO request)
    {
        request.ModifiedBy = BaseIdentityClaims.GetUserNameFromClaims(User);
        return await HandleRequestAsync(() => _materialToSiteRepository.CreateMaterialToSiteAsync(request)).ConfigureAwait(false);
    }

    [HttpGet]
    public async ValueTask<IActionResult> GetAllMaterialToSiteAsync([FromQuery] MaterialToSiteFilters filters) =>
        await HandleRequestAsync(() => _materialToSiteRepository.GetAllMaterialToSiteAsync(filters)).ConfigureAwait(false);

    [Route("delete/{materialToSiteId}")]
    [HttpDelete]
    public async ValueTask<IActionResult> DeleteMaterialToSiteAsync(Guid materialToSiteId)
    {
        var modifiedBy = BaseIdentityClaims.GetUserNameFromClaims(User);
        return await HandleRequestAsync(() => _materialToSiteRepository.DeleteMaterialToSiteAsync(materialToSiteId, modifiedBy)).ConfigureAwait(false);
    }

    [Route("update/{materialToSiteId}")]
    [HttpPut]
    public async ValueTask<IActionResult> UpdateMaterialToSiteAsync(Guid materialToSiteId, [FromBody] CreateMaterialToSiteDTO request)
    {
        request.ModifiedBy = BaseIdentityClaims.GetUserNameFromClaims(User);
        return await HandleRequestAsync(() => _materialToSiteRepository.UpdateMaterialToSiteAsync(materialToSiteId, request)).ConfigureAwait(false);
    }

    [Route("{materialToSiteId}")]
    [HttpGet]
    public async ValueTask<IActionResult> GetAllMaterialToSiteAsync(Guid materialToSiteId) =>
    await HandleRequestAsync(() => _materialToSiteRepository.GetMaterialToSiteByIdAsync(materialToSiteId)).ConfigureAwait(false);
}
