﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using ProcureBuilder.IRepositories;
using ProcureBuilder.Locations.DTOs;
using ProcureBuilder.Locations.Entities;

namespace ProcureBuilder.Controllers;

[Authorize]
[Route("api/locations")]
[ApiController]
public class ProjectLocationController : BaseController
{

    private readonly IProjectLocationRepository<ProjectLocation> _locationRepository;

    public ProjectLocationController(IProjectLocationRepository<ProjectLocation> locationRepository)
    {
        _locationRepository = locationRepository ?? throw new ArgumentNullException(nameof(locationRepository));
    }

    [Route("create/project/{projectId}")]
    [HttpPost]
    public async ValueTask<IActionResult> CreateLocationAsync(Guid projectId, [FromBody] CreateLocationRequest request)
    {
        request.ModifiedBy = BaseIdentityClaims.GetUserNameFromClaims(User);
        return await HandleRequestAsync(() => _locationRepository.CreateLocationAsync(projectId, request)).ConfigureAwait(false);
    }

    [Route("createSingle/project/{projectId}")]
    [HttpPost]
    public async ValueTask<IActionResult> CreateSingleLocationAsync(Guid projectId, [FromBody] CreateProjectLocationDTO request)
    {
        request.ModifiedBy = BaseIdentityClaims.GetUserNameFromClaims(User);
        return await HandleRequestAsync(() => _locationRepository.CreateSingleLocationAsync(projectId, request)).ConfigureAwait(false);
    }

    [Route("delete/project/{projectId}")]
    [HttpDelete]
    public async ValueTask<IActionResult> DeleteLocationAsync(Guid projectId, IList<Guid> locationIds)
    {
        var modifiedBy = BaseIdentityClaims.GetUserNameFromClaims(User);
        return await HandleRequestAsync(() => _locationRepository.DeleteLocationAsync(projectId, locationIds, modifiedBy)).ConfigureAwait(false);
    }

    [HttpGet("list")]
    public async ValueTask<IActionResult> GetAllLocationsAsync(Guid? projectId) =>
        await HandleRequestAsync(() => _locationRepository.GetLocationsListResponseAsync(projectId));

    [HttpGet]
    public async ValueTask<IActionResult> GetAllLocationsAsync([FromQuery] ProjectLocationFilters filters) =>
        await HandleRequestAsync(() => _locationRepository.GetAllLocationsAsync(filters));

    [HttpGet("{projectId}")]
    public async ValueTask<IActionResult> GetLocationByIdAsync(Guid projectId) =>
        await HandleRequestAsync(() => _locationRepository.GetLocationByIdAsync(projectId));

    [Route("update/project/{projectId}")]
    [HttpPut]
    public async ValueTask<IActionResult> UpdateLocationAsync(Guid projectId, [FromBody] UpdateProjectLocationRequest request)
    {
        request.ModifiedBy = BaseIdentityClaims.GetUserNameFromClaims(User);
        return await HandleRequestAsync(() => _locationRepository.UpdateLocationAsync(projectId, request)).ConfigureAwait(false);
    }
}