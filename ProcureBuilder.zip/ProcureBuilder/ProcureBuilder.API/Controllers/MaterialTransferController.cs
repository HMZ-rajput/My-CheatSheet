﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using ProcureBuilder.IRepositories;
using ProcureBuilder.MaterialTransfers.DTOs;
using ProcureBuilder.MaterialTransfers.Entities;

namespace ProcureBuilder.Controllers;

[Authorize]
[Route("api/materialTransfer")]
[ApiController]
public class MaterialTransferController : BaseController
{
    private readonly IMaterialTransferRepository<MaterialTransfer> _materialTransferRepository;

    public MaterialTransferController(IMaterialTransferRepository<MaterialTransfer> materialTransferRepository)
    {
        _materialTransferRepository = materialTransferRepository ?? throw new ArgumentNullException(nameof(_materialTransferRepository));
    }

    [Route("create")]
    [HttpPost]
    public async ValueTask<IActionResult> CreateMaterialTransferAsync([FromBody] CreateMaterialTransferDTO request)
    {
        request.ModifiedBy = BaseIdentityClaims.GetUserNameFromClaims(User);
        return await HandleRequestAsync(() => _materialTransferRepository.CreateMaterialTransferAsync(request)).ConfigureAwait(false);
    }

    [Route("delete/{materialTransferId}")]
    [HttpDelete]
    public async ValueTask<IActionResult> DeleteMaterialTransferAsync(Guid materialTransferId)
    {
        var modifiedBy = BaseIdentityClaims.GetUserNameFromClaims(User);
        return await HandleRequestAsync(() => _materialTransferRepository.DeleteMaterialTransferAsync(materialTransferId, modifiedBy)).ConfigureAwait(false);
    }

    [Route("update/{materialTransferId}")]
    [HttpPut]
    public async ValueTask<IActionResult> UpdateMaterialTransferAsync(Guid materialTransferId, [FromBody] CreateMaterialTransferDTO request)
    {
        var modifiedBy = BaseIdentityClaims.GetUserNameFromClaims(User);
        return await HandleRequestAsync(() => _materialTransferRepository.UpdateMaterialTransferAsync(materialTransferId, request)).ConfigureAwait(false);
    }

    [HttpGet]
    public async ValueTask<IActionResult> GetAllMaterialTransfersAsync([FromQuery] MaterialTransferFilters filters) =>
        await HandleRequestAsync(() => _materialTransferRepository.GetAllMaterialTransferAsync(filters)).ConfigureAwait(false);

    [Route("list/{locationId}")]
    [HttpPost]
    public async ValueTask<IActionResult> GetMaterialInventoryListAsync(Guid locationId, [FromBody] GetMaterialInventoryListRequest request) =>
    await HandleRequestAsync(() => _materialTransferRepository.GetMaterialInventoryListAsync(locationId, request)).ConfigureAwait(false);

    [Route("{materialTransferId}")]
    [HttpGet]
    public async ValueTask<IActionResult> GetMaterialTransferByIdAsync(Guid materialTransferId) =>
        await HandleRequestAsync(() => _materialTransferRepository.GetMaterialTransferByIdAsync(materialTransferId)).ConfigureAwait(false);
}
