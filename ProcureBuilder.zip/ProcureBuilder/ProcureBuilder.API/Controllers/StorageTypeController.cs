﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using ProcureBuilder.IRepositories;
using ProcureBuilder.StorageTypes.DTOs;
using ProcureBuilder.StorageTypes.Entities;

namespace ProcureBuilder.Controllers;

[Authorize]
[Route("api/storageType")]
[ApiController]
public class StorageTypeController : BaseController
{
    private readonly IStorageTypeRepository<StorageType> _storageTypeRepository;

    public StorageTypeController(IStorageTypeRepository<StorageType> storageTypeRepository)
    {
        _storageTypeRepository = storageTypeRepository ?? throw new ArgumentNullException(nameof(storageTypeRepository));
    }

    [Route("create")]
    [HttpPost]
    public async ValueTask<IActionResult> CreateStorageTypeAsync([FromBody] CreateStorageTypeDTO request)
    {
        request.ModifiedBy = BaseIdentityClaims.GetUserNameFromClaims(User);
        return await HandleRequestAsync(() => _storageTypeRepository.CreateStorageTypeAsync(request)).ConfigureAwait(false);
    }


    [Route("delete/{storageTypeId}")]
    [HttpDelete]
    public async ValueTask<IActionResult> DeleteStorageTypeAsync(Guid storageTypeId)
    {
        var modifiedBy = BaseIdentityClaims.GetUserNameFromClaims(User);
        return await HandleRequestAsync(() => _storageTypeRepository.DeleteStorageTypeAsync(storageTypeId, modifiedBy)).ConfigureAwait(false);
    }

    [HttpGet]
    public async ValueTask<IActionResult> GetAllStorageTypesAsync() =>
        await HandleRequestAsync(() => _storageTypeRepository.GetAllStorageTypesAsync());

    [Route("update/{storageTypeId}")]
    [HttpPut]
    public async ValueTask<IActionResult> UpdateStorageTypeAsync(Guid storageTypeId, [FromBody] UpdateStorageTypeDTO request)
    {
        request.ModifiedBy = BaseIdentityClaims.GetUserNameFromClaims(User);
        return await HandleRequestAsync(() => _storageTypeRepository.UpdateStorageTypeAsync(storageTypeId, request)).ConfigureAwait(false);
    }
}