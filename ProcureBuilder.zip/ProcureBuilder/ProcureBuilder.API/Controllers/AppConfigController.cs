﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using ProcureBuilder.AppConfigs.Entities;
using ProcureBuilder.IRepositories;

namespace ProcureBuilder.Controllers;

[Route("api/config")]
[ApiController]
public class AppConfigController : BaseController
{
    private readonly IAppConfigRepository<AppConfig> _appConfigRepository;

    public AppConfigController(IAppConfigRepository<AppConfig> appConfigRepository)
    {
        _appConfigRepository = appConfigRepository ?? throw new ArgumentNullException(nameof(appConfigRepository));
    }

    [HttpGet("version")]
    public async ValueTask<IActionResult> GetAppVersionAsync() =>
        await HandleRequestAsync(_appConfigRepository.GetAppVersionAsync);
}