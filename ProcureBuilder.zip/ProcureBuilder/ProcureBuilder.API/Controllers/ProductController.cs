﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using ProcureBuilder.IRepositories;
using ProcureBuilder.Materials.Entities;
using ProcureBuilder.Products.DTOs;

namespace ProcureBuilder.Controllers;

[Authorize]
[Route("api/products")]
[ApiController]
public class ProductController : BaseController
{
    private readonly IProductRepository<Material> _productRepository;

    public ProductController(IProductRepository<Material> productRepository)
    {
        _productRepository = productRepository ?? throw new ArgumentNullException(nameof(productRepository));
    }

    [HttpGet]
    public async ValueTask<IActionResult> GetAllProductsAsync([FromQuery] ProductsFilter filters) =>
        await HandleRequestAsync(() => _productRepository.GetAllProductsAsync(filters));

    [Route("{productName}")]
    [HttpGet]
    public async ValueTask<IActionResult> GetProductByNameAsync(string productName, [FromQuery] GetProductFilter filters) =>
        await HandleRequestAsync(() => _productRepository.GetProductByNameAsync(productName, filters));
}
