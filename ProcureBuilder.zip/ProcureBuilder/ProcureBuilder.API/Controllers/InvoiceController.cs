﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using ProcureBuilder.Invoices.DTOs;
using ProcureBuilder.Invoices.Entities;
using ProcureBuilder.IRepositories;
using ProcureBuilder.PurchaseOrders.DTOs;

namespace ProcureBuilder.Controllers;

[Authorize]
[Route("api/invoice")]
[ApiController]
public class InvoiceController : BaseController
{
    private readonly IInvoiceRepository<Invoice> _invoiceRepository;
    public InvoiceController(IInvoiceRepository<Invoice> invoiceRepository)
    {
        _invoiceRepository = invoiceRepository ?? throw new ArgumentNullException(nameof(invoiceRepository));
    }

    [Route("create")]
    [HttpPost]
    public async ValueTask<IActionResult> CreateInvoiceAsync([FromForm] CreateInvoiceDTO request)
    {
        request.ModifiedBy = BaseIdentityClaims.GetUserNameFromClaims(User);
        return await HandleRequestAsync(() => _invoiceRepository.CreateInvoiceAsync(request)).ConfigureAwait(false);
    }

    [HttpGet]
    public async ValueTask<IActionResult> GetAllInvoicesAsync([FromQuery] InvoiceFilters filters) =>
        await HandleRequestAsync(() => _invoiceRepository.GetAllInvoiceAsync(filters)).ConfigureAwait(false);

    [Route("{invoiceId}")]
    [HttpGet]
    public async ValueTask<IActionResult> GetInvocieByIdAsync(Guid invoiceId) =>
        await HandleRequestAsync(() => _invoiceRepository.GetInvoiceByIdAsync(invoiceId)).ConfigureAwait(false);

    [Route("delete/{invoiceId}")]
    [HttpDelete]
    public async ValueTask<IActionResult> DeleteInvoiceAsync(Guid invoiceId)
    {
        var ModifiedBy = BaseIdentityClaims.GetUserNameFromClaims(User);
        return await HandleRequestAsync(() => _invoiceRepository.DeleteInvoiceAsync(invoiceId, ModifiedBy)).ConfigureAwait(false);
    }

    [Route("update/{invoiceId}")]
    [HttpPut]
    public async ValueTask<IActionResult> UpdateInvoiceAsync(Guid invoiceId, [FromForm] CreateInvoiceDTO request)
    {
        request.ModifiedBy = BaseIdentityClaims.GetUserNameFromClaims(User);
        return await HandleRequestAsync(() => _invoiceRepository.UpdateInvoiceAsync(invoiceId, request)).ConfigureAwait(false);
    }

    [Route("materialList")]
    [HttpGet]
    public async ValueTask<IActionResult> GetPurchaseOrderMaterials([FromQuery] Guid purchaseOrderId) =>
        await HandleRequestAsync(() => _invoiceRepository.GetMaterialsFromPurchaseOrder(purchaseOrderId)).ConfigureAwait(false);

    [Route("newInvoiceNumber")]
    [HttpGet]
    public async ValueTask<IActionResult> GetNewInvoiceNumberAsync() =>
        await HandleRequestAsync(() => _invoiceRepository.GetNewInvoiceNumberAsync()).ConfigureAwait(false);

    [Route("list")]
    [HttpGet]
    public async ValueTask<IActionResult> GetInvoiceNumberListAsync() =>
        await HandleRequestAsync(() => _invoiceRepository.GetInvoiceNumberListAsync()).ConfigureAwait(false);

    [Route("projectReport")]
    [HttpGet]
    public async ValueTask<IActionResult> GetInvoiceProjectReportAsync([FromQuery] InvoiceReportFilters filters) =>    
        await HandleRequestAsync(() => _invoiceRepository.GetAllInvoiceProjectReportAsync(filters)).ConfigureAwait(false);

    [Route("projectCostCodeReport")]
    [HttpGet]
    public async ValueTask<IActionResult> GetInvoiceProjectCostCodeReportAsync([FromQuery] InvoiceReportFilters filters) =>
        await HandleRequestAsync(() => _invoiceRepository.GetAllInvoiceProjectCostCodeReportAsync(filters)).ConfigureAwait(false);

    [Route("purchaseOrderReport")]
    [HttpGet]
    public async ValueTask<IActionResult> GetInvoicePurchaseOrderReportAsync([FromQuery] InvoiceReportFilters filters) =>
        await HandleRequestAsync(() => _invoiceRepository.GetAllInvoicePurchaseOrderReportAsync(filters)).ConfigureAwait(false);

    [Route("purchaseOrderInvoicesReport/{purchaseOrderId}")]
    [HttpGet]
    public async ValueTask<IActionResult> GetPurchaseOrderInvoicesReportAsync(Guid purchaseOrderId, [FromQuery] PurchaseOrderInvoiceReportFilters filters) =>
        await HandleRequestAsync(() => _invoiceRepository.GetAllPurchaseOrderInvoicesReportAsync(purchaseOrderId, filters)).ConfigureAwait(false);
}
