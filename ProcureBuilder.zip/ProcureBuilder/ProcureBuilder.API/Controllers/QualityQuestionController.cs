﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using ProcureBuilder.IRepositories;
using ProcureBuilder.QualityQuestions.DTOs;
using ProcureBuilder.QualityQuestions.Entities;

namespace ProcureBuilder.Controllers;

[Authorize]
[Route("api/qualityQuestion")]
[ApiController]
public class QualityQuestionController : BaseController
{
    private readonly IQualityQuestionRepository<QualityQuestion> _qualityQuestionRepository;

    public QualityQuestionController(IQualityQuestionRepository<QualityQuestion> qualityQuestionRepository)
    {
        _qualityQuestionRepository = qualityQuestionRepository ?? throw new ArgumentNullException(nameof(_qualityQuestionRepository));
    }

    [Route("create")]
    [HttpPost]
    public async ValueTask<IActionResult> CreateQualityQuestionAsync([FromBody] CreateQualityQuestion request)
    {
        request.ModifiedBy = BaseIdentityClaims.GetUserNameFromClaims(User);
        return await HandleRequestAsync(() => _qualityQuestionRepository.CreateQualityQuestionsAsync(request)).ConfigureAwait(false);
    }

    [Route("project/{projectId}")]
    [HttpGet]
    public async ValueTask<IActionResult> GetQualityQuestionsAsync(Guid projectId) =>
        await HandleRequestAsync(() => _qualityQuestionRepository.GetQualityQuestionsAsync(projectId)).ConfigureAwait(false);

    [Route("delete/project/{projectId}")]
    [HttpDelete]
    public async ValueTask<IActionResult> DeleteAllQualityQuestionsAsync(Guid projectId)
    {
        var ModifiedBy = BaseIdentityClaims.GetUserNameFromClaims(User);
        return await HandleRequestAsync(() => _qualityQuestionRepository.DeleteAllQualityQuestionsAsync(projectId, ModifiedBy)).ConfigureAwait(false);
    }

    [Route("update/project/{projectId}")]
    [HttpPut]
    public async ValueTask<IActionResult> UpdateQualityQuestionsAsync(Guid projectId, [FromBody] UpdateQualityQuestionRequestDTO request)
    {
        request.ModifiedBy = BaseIdentityClaims.GetUserNameFromClaims(User);
        return await HandleRequestAsync(() => _qualityQuestionRepository.UpdateQualityQuestionsAsync(projectId, request)).ConfigureAwait(false);
    }
}
