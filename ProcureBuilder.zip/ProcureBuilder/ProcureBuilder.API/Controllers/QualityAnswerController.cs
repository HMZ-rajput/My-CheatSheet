﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using ProcureBuilder.IRepositories;
using ProcureBuilder.QualityQuestions.DTOs;
using ProcureBuilder.QualityQuestions.Entities;

namespace ProcureBuilder.Controllers;

[Authorize]
[Route("api/qualityAnswer")]
[ApiController]
public class QualityAnswerController : BaseController
{
    private readonly IQualityAnswerRepository<QualityAnswer> _qualityAnswerRepository;

    public QualityAnswerController(IQualityAnswerRepository<QualityAnswer> qualityAnswerRepository)
    {
        _qualityAnswerRepository = qualityAnswerRepository ?? throw new ArgumentNullException(nameof(_qualityAnswerRepository));
    }

    [Route("create")]
    [HttpPost]
    public async ValueTask<IActionResult> CreateQualityAnswerAsync([FromBody] CreateQualityAnswersDTO request)
    {
        request.ModifiedBy = BaseIdentityClaims.GetUserNameFromClaims(User);
        return await HandleRequestAsync(() => _qualityAnswerRepository.CreateQualityAnswersAsync(request)).ConfigureAwait(false);
    }

    [Route("{materialReceiptInspectionId}")]
    [HttpGet]
    public async ValueTask<IActionResult> GetQualityAnswerAsync(Guid materialReceiptInspectionId) =>
        await HandleRequestAsync(() => _qualityAnswerRepository.GetQualityAnswersAsync(materialReceiptInspectionId)).ConfigureAwait(false);

    [Route("delete/materialReceiptInspection/{materialReceiptInspectionId}")]
    [HttpDelete]
    public async ValueTask<IActionResult> DeleteQualityAnswerAsync(Guid materialReceiptInspectionId)
    {
        var ModifiedBy = BaseIdentityClaims.GetUserNameFromClaims(User);
        return await HandleRequestAsync(() => _qualityAnswerRepository.DeleteQualityAnswersAsync(materialReceiptInspectionId, ModifiedBy)).ConfigureAwait(false);
    }

    [Route("update")]
    [HttpPut]
    public async ValueTask<IActionResult> UpdateQualityAnswerAsync([FromBody] UpdateQualityAnswerRequestDTO request)
    {
        var ModifiedBy = BaseIdentityClaims.GetUserNameFromClaims(User);
        return await HandleRequestAsync(() => _qualityAnswerRepository.UpdateQualityAnswersAsync(request)).ConfigureAwait(false);
    }
}
