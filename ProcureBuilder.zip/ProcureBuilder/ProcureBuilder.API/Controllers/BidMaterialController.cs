﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using ProcureBuilder.IRepositories;
using ProcureBuilder.Materials.DTOs;
using ProcureBuilder.Materials.Entities;

namespace ProcureBuilder.Controllers;

[Authorize]
[Route("api/bidMaterial")]
[ApiController]
public class BidMaterialController : BaseController
{
    private readonly IMaterialRepository<Material> _bidMaterialRepository;

    public BidMaterialController(IMaterialRepository<Material> bidMaterialRepository)
    {
        _bidMaterialRepository = bidMaterialRepository ?? throw new ArgumentNullException(nameof(bidMaterialRepository));
    }

    [Route("create")]
    [HttpPost]
    public async ValueTask<IActionResult> CreateBidMaterialAsync([FromBody] CreateMaterialDTO request)
    {
        request.ModifiedBy = BaseIdentityClaims.GetUserNameFromClaims(User);
        return await HandleRequestAsync(() => _bidMaterialRepository.CreateMaterialAsync(request)).ConfigureAwait(false);
    }


    [Route("delete")]
    [HttpDelete]
    public async ValueTask<IActionResult> DeleteMaterialAsync(DeleteMaterialDTO request)
    {
        request.ModifiedBy = BaseIdentityClaims.GetUserNameFromClaims(User);
        return await HandleRequestAsync(() => _bidMaterialRepository.DeleteMaterialAsync(request)).ConfigureAwait(false);
    }

    [HttpGet("{projectId}")]
    public async ValueTask<IActionResult> GetMaterialsByIdAsync(Guid projectId) =>
        await HandleRequestAsync(() => _bidMaterialRepository.GetMaterialsByIdAsync(projectId));

    [Route("update")]
    [HttpPut]
    public async ValueTask<IActionResult> UpdateMaterialsAsync([FromBody] UpdateMaterialDTO request)
    {
        request.ModifiedBy = BaseIdentityClaims.GetUserNameFromClaims(User);
        return await HandleRequestAsync(() => _bidMaterialRepository.UpdateMaterialAsync(request)).ConfigureAwait(false);
    }

    [Route("list")]
    [HttpGet]
    public async ValueTask<IActionResult> GetBidMaterialListAsync([FromQuery] Guid projectId) =>
        await HandleRequestAsync(() => _bidMaterialRepository.GetBidMaterialListAsync(projectId));

    [Route("report")]
    [HttpGet]
    public async ValueTask<IActionResult> GetBidMaterialReportAsync([FromQuery] BidMaterialFilters filters) =>
        await HandleRequestAsync(() => _bidMaterialRepository.GetBidMaterialReportAsync(filters));
}
