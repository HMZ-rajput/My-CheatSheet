﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using ProcureBuilder.IRepositories;
using ProcureBuilder.PurchaseOrders.DTOs;
using ProcureBuilder.PurchaseOrders.Entities;

namespace ProcureBuilder.Controllers;

[Route("api/purchaseOrderApprovals")]
[ApiController]
public class PurchaseOrderApprovalController : BaseController
{
    private readonly IPurchaseOrderApprovalRepository<PurchaseOrderApproval> _purchaseOrderApprovalRepository;

    public PurchaseOrderApprovalController(IPurchaseOrderApprovalRepository<PurchaseOrderApproval> purchaseOrderApprovalRepository)
    {
        _purchaseOrderApprovalRepository = purchaseOrderApprovalRepository ?? throw new ArgumentNullException(nameof(purchaseOrderApprovalRepository));
    }

    [Route("create")]
    [HttpPost]
    public async ValueTask<IActionResult> CreatePurchaseOrderApprovalAsync([FromBody] CreatePurchaseOrderApprovalDTO request)
    {
        request.ModifiedBy = BaseIdentityClaims.GetUserNameFromClaims(User);
        return await HandleRequestAsync(() => _purchaseOrderApprovalRepository.CreatePurchaseOrderApprovalAsync(request)).ConfigureAwait(false);
    }

    [Authorize]
    [Route("{purchaseOrderId}")]
    [HttpGet]
    public async ValueTask<IActionResult> GetPurchaseOrderApprovalAsync(Guid purchaseOrderId) =>
        await HandleRequestAsync(() => _purchaseOrderApprovalRepository.GetPurchaseOrderApprovalAsync(purchaseOrderId)).ConfigureAwait(false);
}
