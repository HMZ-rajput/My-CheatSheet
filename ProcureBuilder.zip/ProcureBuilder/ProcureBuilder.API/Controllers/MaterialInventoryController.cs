﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using ProcureBuilder.IRepositories;
using ProcureBuilder.MaterialInventory.DTOs;
using ProcureBuilder.Materials.DTOs;
using ProcureBuilder.Materials.Entities;

namespace ProcureBuilder.Controllers;

[Authorize]
[Route("api/inventory")]
[ApiController]
public class MaterialInventoryController : BaseController
{
    private readonly IMaterialInventoryRepository<Material> _materialInventoryRepository;

    public MaterialInventoryController(IMaterialInventoryRepository<Material> materialInventoryRepository)
    {
        _materialInventoryRepository = materialInventoryRepository ?? throw new ArgumentNullException(nameof(_materialInventoryRepository));
    }

    [Route("create/project/{projectId}")]
    [HttpPost]
    public async ValueTask<IActionResult> CreateMaterialInventory(Guid projectId, [FromBody] AddInventoryRequest request)
    {
        request.ModifiedBy = BaseIdentityClaims.GetUserNameFromClaims(User);
        return await HandleRequestAsync(() => _materialInventoryRepository.CreateMaterialInventoryAsync(projectId, request)).ConfigureAwait(false);
    }

    [Route("project/{projectId}")]
    [HttpGet]
    public async ValueTask<IActionResult> GetMaterialInventory(Guid projectId, [FromQuery] MaterialInventoryFilters filters) =>
        await HandleRequestAsync(() => _materialInventoryRepository.GetMaterialInventoryAsync(projectId, filters)).ConfigureAwait(false);

    [Route("allMaterials/project/{projectId}")]
    [HttpGet]
    public async ValueTask<IActionResult> GetAllInventoryMaterialsAsync(Guid projectId, [FromQuery] GetAllInventoryMaterialsFilter filters) =>
        await HandleRequestAsync(() => _materialInventoryRepository.GetAllInventoryMaterialsAsync(projectId, filters)).ConfigureAwait(false);

    [Route("update/project/{projectId}")]
    [HttpPut]
    public async ValueTask<IActionResult> UpdateMaterialInventory(Guid projectId, [FromBody] AddInventoryRequest request)
    {
        request.ModifiedBy = BaseIdentityClaims.GetUserNameFromClaims(User);
        return await HandleRequestAsync(() => _materialInventoryRepository.UpdateMaterialInventoryAsync(projectId, request)).ConfigureAwait(false);
    }

    [Route("delete/project/{projectId}")]
    [HttpDelete]
    public async ValueTask<IActionResult> DeleteMaterialInventory(Guid projectId)
    {
        var ModifiedBy = BaseIdentityClaims.GetUserNameFromClaims(User);
        return await HandleRequestAsync(() => _materialInventoryRepository.DeleteMaterialInventoryAsync(projectId, ModifiedBy)).ConfigureAwait(false);
    }
}
