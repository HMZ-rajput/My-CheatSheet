﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using ProcureBuilder.ChangeOrders.DTOs;
using ProcureBuilder.ChangeOrders.Entities;
using ProcureBuilder.IRepositories;

namespace ProcureBuilder.Controllers;

[Authorize]
[Route("api/changeOrders")]
[ApiController]
public class ChangeOrderController : BaseController
{
    private readonly IChangeOrderRepository<ChangeOrder> _changeOrderRepository;

    public ChangeOrderController(IChangeOrderRepository<ChangeOrder> changeOrderRepository)
    {
        _changeOrderRepository = changeOrderRepository ?? throw new ArgumentNullException(nameof(changeOrderRepository));
    }

    [Route("create/project/{projectId}")]
    [HttpPost]
    public async ValueTask<IActionResult> CreateChangeOrderAsync(Guid projectId, [FromForm] CreateChangeOrderDTO request)
    {
        request.ModifiedBy = BaseIdentityClaims.GetUserNameFromClaims(User);
        return await HandleRequestAsync(() => _changeOrderRepository.CreateChangeOrderAsync(projectId, request)).ConfigureAwait(false);
    }

    [Route("delete/project/{projectId}/changeOrder/{changeOrderId}")]
    [HttpDelete]
    public async ValueTask<IActionResult> DeleteChangeOrderAsync(Guid projectId, Guid changeOrderId)
    {
        var modifiedBy = BaseIdentityClaims.GetUserNameFromClaims(User);
        return await HandleRequestAsync(() => _changeOrderRepository.DeleteChangeOrderAsync(projectId, changeOrderId, modifiedBy)).ConfigureAwait(false);
    }

    [Route("deleteChangeOrderMaterials/project/{projectId}/changeOrder/{changeOrderId}")]
    [HttpDelete]
    public async ValueTask<IActionResult> DeleteChangeOrderMaterialsAsync(Guid projectId, Guid changeOrderId, DeleteChangeOrderMaterialsRequest request)
    {
        request.ModifiedBy = BaseIdentityClaims.GetUserNameFromClaims(User);
        return await HandleRequestAsync(() => _changeOrderRepository.DeleteChangeOrderMaterialsByIdAsync(projectId, changeOrderId, request)).ConfigureAwait(false);
    }

    [HttpGet("{changeOrderId}")]
    public async ValueTask<IActionResult> GetChangeOrderByIdAsync(Guid changeOrderId) =>
        await HandleRequestAsync(() => _changeOrderRepository.GetChangeOrderByIdAsync(changeOrderId));

    [HttpGet("project/{projectId}")]
    public async ValueTask<IActionResult> GetChangeOrdersByProjectIdAsync(Guid projectId) =>
        await HandleRequestAsync(() => _changeOrderRepository.GetChangeOrdersByProjectIdAsync(projectId, false));

    [HttpGet("project/{projectId}/approved")]
    public async ValueTask<IActionResult> GetApprovedChangeOrdersByProjectIdAsync(Guid projectId) =>
        await HandleRequestAsync(() => _changeOrderRepository.GetChangeOrdersByProjectIdAsync(projectId, true));

    [HttpGet]
    public async ValueTask<IActionResult> GetChangeOrdersAsync([FromQuery] ChangeOrderFilters filters) =>
        await HandleRequestAsync(() => _changeOrderRepository.GetAllChangeOrdersAsync(filters));

    [Route("update/project/{projectId}/changeOrder/{changeOrderId}")]
    [HttpPut]
    public async ValueTask<IActionResult> UpdateChangeOrderAsync(Guid projectId, Guid changeOrderId, [FromForm] UpdateChangeOrderDTO request)
    {
        request.ModifiedBy = BaseIdentityClaims.GetUserNameFromClaims(User);
        return await HandleRequestAsync(() => _changeOrderRepository.UpdateChangeOrderAsync(projectId, changeOrderId, request)).ConfigureAwait(false);
    }

    [Route("deleteAttachments/project/{projectId}/changeOrder/{changeOrderId}")]
    [HttpDelete]
    public async ValueTask<IActionResult> DeleteChangeOrderAttachmentsByIdAsync(Guid projectId, Guid changeOrderId, DeleteChangeOrderAttachmentsRequest request)
    {
        request.ModifiedBy = BaseIdentityClaims.GetUserNameFromClaims(User);
        return await HandleRequestAsync(() => _changeOrderRepository.DeleteChangeOrderAttachmentsByIdAsync(projectId, changeOrderId, request)).ConfigureAwait(false);
    }

    [HttpGet("newChangeOrderNumber")]
    public async ValueTask<IActionResult> GetChangeOrderNumberAsync() =>
        await HandleRequestAsync(() => _changeOrderRepository.GetNewChangeOrderNumberAsync());
}
