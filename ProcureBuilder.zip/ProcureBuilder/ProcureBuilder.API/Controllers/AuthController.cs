﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using ProcureBuilder.Identity.DTOs;
using ProcureBuilder.IRepositories;

namespace ProcureBuilder.Controllers;

[Route("api/auth")]
[ApiController]
public class AuthController : BaseController
{
    private readonly IAuthRepository _authRepository;

    public AuthController(IAuthRepository authRepository)
    {
        _authRepository = authRepository ?? throw new ArgumentNullException(nameof(authRepository));
    }

    [Route("login")]
    [HttpPost]
    public async ValueTask<IActionResult> LoginAsync([FromBody] LoginRequest request) =>
    await HandleRequestAsync(() => _authRepository.LoginAsync(request))
        .ConfigureAwait(false);

    [Authorize]
    [Route("signUp")]
    [HttpPost]
    public async ValueTask<IActionResult> SignUpAsync([FromBody] SignUpRequest request)
    {
        request.ModifiedBy = BaseIdentityClaims.GetUserNameFromClaims(User);
        return await HandleRequestAsync(() => _authRepository.SignUpAsync(request)).ConfigureAwait(false);
    }

    [Authorize]
    [Route("changePassword")]
    [HttpPost]
    public async ValueTask<IActionResult> ChangePasswordAsync(ChangePasswordRequest request)
    {
        request.ModifiedBy = BaseIdentityClaims.GetUserNameFromClaims(User);
        return await HandleRequestAsync(() => _authRepository.ChangePasswordAsync(request)).ConfigureAwait(false);
    }

    [Route("sendForgotPasswordEmail")]
    [HttpPost]
    public async ValueTask<IActionResult> SendForgotPasswordEmailAsync([FromBody] SendForgotPasswordEmailRequest request) =>
        await HandleRequestAsync(() => _authRepository.SendForgotPasswordEmailAsync(request))
        .ConfigureAwait(false);

    [Route("verifyOTP")]
    [HttpPost]
    public async ValueTask<IActionResult> VerifyPasswordOTPAsync([FromBody] VerifyPasswordOTPRequest request) =>
            await HandleRequestAsync(() => _authRepository.VerifyPasswordOTPAsync(request))
        .ConfigureAwait(false);

    [Route("resetPassword")]
    [HttpPost]
    public async ValueTask<IActionResult> ResetPasswordAsync([FromBody] ResetPasswordRequest request) =>
    await HandleRequestAsync(() => _authRepository.ResetPasswordAsync(request))
        .ConfigureAwait(false);

    [Authorize]
    [Route("updatePersonalInfo/{userId}")]
    [HttpPut]
    public async ValueTask<IActionResult> UpdatePersonalInfoAsync(string userId, [FromBody] UpdatePersonalInfoRequest request)
    {
        request.ModifiedBy = BaseIdentityClaims.GetUserNameFromClaims(User);
        return await HandleRequestAsync(() => _authRepository.UpdatePersonalInfoAsync(userId, request)).ConfigureAwait(false);
    }

    [Authorize]
    [Route("managers")]
    [HttpGet]
    public async ValueTask<IActionResult> GetAllManagerAsync() =>
            await HandleRequestAsync(() => _authRepository.GetAllManagersAsync())
        .ConfigureAwait(false);

    [Authorize]
    [Route("users")]
    [HttpGet]
    public async ValueTask<IActionResult> GetAllApplicationUserAsync([FromQuery] Userfilters filters) =>
        await HandleRequestAsync(() => _authRepository.GetAllUsersAsync(filters)).ConfigureAwait(false);

    [Authorize]
    [Route("users/{userId}")]
    [HttpGet]
    public async ValueTask<IActionResult> GetUserByIdAsync(Guid userId) =>
        await HandleRequestAsync(() => _authRepository.GetUserByIdAsync(userId)).ConfigureAwait(false);

    [Authorize]
    [Route("list")]
    [HttpPost]
    public async ValueTask<IActionResult> GetUsersWithRolesAsync([FromBody] GetUsersWithRolesRequest request) =>
        await HandleRequestAsync(() => _authRepository.GetUsersWithRolesAsync(request)).ConfigureAwait(false);

    [Authorize]
    [Route("updateInternalUser")]
    [HttpPut]
    public async ValueTask<IActionResult> UpdateInternalUser([FromBody] UpdateInternalUserRequest request)
    {
        request.ModifiedBy = BaseIdentityClaims.GetUserNameFromClaims(User);
        return await HandleRequestAsync(() => _authRepository.UpdateInternalUserAsync(request)).ConfigureAwait(false);
    }

    [Authorize(Roles = "SuperAdmin,Admin")]
    [Route("deleteInternalUser/{userId}")]
    [HttpDelete]
    public async ValueTask<IActionResult> DeleteInternalUser(string userId)
    {
        var modifiedBy = BaseIdentityClaims.GetUserNameFromClaims(User);
        return await HandleRequestAsync(() => _authRepository.DeleteInternalUserAsync(userId, modifiedBy)).ConfigureAwait(false);
    }

    [Authorize]
    [Route("resendInvite/{userId}")]
    [HttpPut]
    public async ValueTask<IActionResult> ResendInviteUserByIdAsync(string userId) =>
    await HandleRequestAsync(() => _authRepository.ResendInviteAsync(userId)).ConfigureAwait(false);
}
