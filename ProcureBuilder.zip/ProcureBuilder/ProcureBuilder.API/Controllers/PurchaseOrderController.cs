﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using ProcureBuilder.Common.DTOs;
using ProcureBuilder.Documents.Entities;
using ProcureBuilder.IRepositories;
using ProcureBuilder.MaterialReceiptInspections.Entities;
using ProcureBuilder.PurchaseOrders.DTOs;
using ProcureBuilder.PurchaseOrders.Entities;

namespace ProcureBuilder.Controllers;

[Route("api/purchaseOrders")]
[ApiController]
public class PurchaseOrderController : BaseController
{
    private readonly IPurchaseOrderRepository<PurchaseOrder> _purchaseOrderRepository;

    public PurchaseOrderController(IPurchaseOrderRepository<PurchaseOrder> purchaseOrderRepository)
    {
        _purchaseOrderRepository = purchaseOrderRepository ?? throw new ArgumentNullException(nameof(purchaseOrderRepository));
    }

    [Authorize]
    [Route("createPurchaseOrder")]
    [HttpPost]
    public async ValueTask<IActionResult> CreatePurchaseOrderAsync([FromForm] CreatePurchaseOrderDTO request)
    {
        request.ModifiedBy = BaseIdentityClaims.GetUserNameFromClaims(User);
        return await HandleRequestAsync(() => _purchaseOrderRepository.CreatePurchaseOrderAsync(request)).ConfigureAwait(false);
    }

    [Authorize]
    [HttpGet]
    public async ValueTask<IActionResult> GetAllPurchaseOrdersAsync([FromQuery] PurchaseOrderFilters filters) =>
        await HandleRequestAsync(() => _purchaseOrderRepository.GetAllPurchaseOrdersAsync(filters));

    [Authorize]
    [HttpGet("{purchaseOrderId}")]
    public async ValueTask<IActionResult> GetPurchaseOrderByIdAsync(Guid purchaseOrderId) =>
        await HandleRequestAsync(() => _purchaseOrderRepository.GetPurchaseOrderByIdAsync(purchaseOrderId));

    [Authorize]
    [HttpGet("vendorDetails/{purchaseOrderId}")]
    public async ValueTask<IActionResult> GetVendorDetailsAsync(Guid purchaseOrderId) =>
        await HandleRequestAsync(() => _purchaseOrderRepository.GetVendorDetailsAsync(purchaseOrderId));

    [Route("vendorApprove/{purchaseOrderId}")]
    [HttpGet]
    public async ValueTask<IActionResult> GetPurchaseOrderVendorByIdAsync(Guid purchaseOrderId) =>
        await HandleRequestAsync(() => _purchaseOrderRepository.GetPurchaseOrderVendorByIdAsync(purchaseOrderId));

    [Authorize]
    [Route("update/{purchaseOrderId}")]
    [HttpPut]
    public async ValueTask<IActionResult> UpdatePurchaseOrderAsync(Guid purchaseOrderId, [FromForm] UpdatePurchaseOrderDTO request)
    {
        request.ModifiedBy = BaseIdentityClaims.GetUserNameFromClaims(User);
        return await HandleRequestAsync(() => _purchaseOrderRepository.UpdatePurchaseOrderAsync(purchaseOrderId, request)).ConfigureAwait(false);
    }

    [Authorize]
    [Route("updateProcurement/{purchaseOrderId}")]
    [HttpPut]
    public async ValueTask<IActionResult> UpdatePurchaseOrderProcurmentAsync(Guid purchaseOrderId, [FromBody] PurchaseOrderProcurmentUpdateDTO request)
    {
        request.ModifiedBy = BaseIdentityClaims.GetUserNameFromClaims(User);
        return await HandleRequestAsync(() => _purchaseOrderRepository.UpdatePurchaseOrderProcurementAsync(purchaseOrderId, request)).ConfigureAwait(false);
    }

    [Authorize]
    [Route("delete/{purchaseOrderId}")]
    [HttpDelete]
    public async ValueTask<IActionResult> DeletePurchaseOrderByIdAsync(Guid purchaseOrderId)
    {
        var modifiedBy = BaseIdentityClaims.GetUserNameFromClaims(User);
        return await HandleRequestAsync(() => _purchaseOrderRepository.DeletePurchaseOrderByIdAsync(purchaseOrderId, modifiedBy)).ConfigureAwait(false);
    }

    [Authorize]
    [Route("updateVendor/{purchaseOrderId}")]
    [HttpPut]
    public async ValueTask<IActionResult> UpdatePurchaseOrderVendorAsync(Guid purchaseOrderId, [FromBody] PurchaseOrderVendorUpdateDTO request)
    {
        request.ModifiedBy = BaseIdentityClaims.GetUserNameFromClaims(User);
        return await HandleRequestAsync(() => _purchaseOrderRepository.UpdatePurchaseOrderVendorAsync(purchaseOrderId, request)).ConfigureAwait(false);
    }

    [Authorize]
    [Route("list")]
    [HttpGet]
    public async ValueTask<IActionResult> GetPurchaseOrderListAsync([FromQuery] Guid? projectId, bool isForMRI, MaterialReceiptInspectionStatus mRIStatus) =>
        await HandleRequestAsync(() => _purchaseOrderRepository.GetPurchaseOrderListAsync(projectId, isForMRI, mRIStatus)).ConfigureAwait(false);

    [Authorize]
    [Route("materialList")]
    [HttpGet]
    public async ValueTask<IActionResult> GetPurchaseOrderMaterialListAsync([FromQuery] Guid purchaseOrderId) =>
    await HandleRequestAsync(() => _purchaseOrderRepository.GetPurchaseOrderMaterialListAsync(purchaseOrderId)).ConfigureAwait(false);

    [Authorize]
    [Route("newPurchaseOrderNumber")]
    [HttpGet]
    public async ValueTask<IActionResult> GetNewPurchaseOrderNumberAsync() =>
        await HandleRequestAsync(() => _purchaseOrderRepository.GetNewPurchaseOrderNumberAsync()).ConfigureAwait(false);

    [Route("document/{purchaseOrderId}")]
    [HttpGet]
    public async ValueTask<IActionResult> GeneratePODocumentAsync(Guid purchaseOrderId)
    {
        var response = new GeneratePDFDocumentResponse();
        try
        {
            response = await _purchaseOrderRepository.GeneratePOScanDocumentAsync(purchaseOrderId).ConfigureAwait(false);

            if (response.Data is null || response.Data.FileData is null)
            {
                throw new Exception("An error occurred while trying to generate the document. Please try again.");
            }

            return File(response.Data.FileData, "application/pdf", response.Data.FileName);
        }
        catch (Exception ex)
        {
            response.AddError("An error occurred while trying to generate the document. Please try again.");
            response.AddError(ex.Message);
            return BadRequest(response);
        }
    }

    [Route("document/{purchaseOrderId}/material/{materialId}")]
    [HttpGet]
    public async ValueTask<IActionResult> GeneratePOMaterialDocumentAsync(Guid purchaseOrderId, Guid materialId)
    {
        var response = new GeneratePDFDocumentResponse();
        try
        {
            response = await _purchaseOrderRepository.GeneratePOMaterialScanDocumentAsync(purchaseOrderId, materialId).ConfigureAwait(false);

            if (response.Data is null || response.Data.FileData is null)
            {
                throw new Exception("An error occurred while trying to generate the document. Please try again.");
            }

            return File(response.Data.FileData, "application/pdf", response.Data.FileName);
        }
        catch (Exception ex)
        {
            response.AddError("An error occurred while trying to generate the document. Please try again.");
            response.AddError(ex.Message);
            return BadRequest(response);
        }
    }

    [Route("{purchaseOrderId}/PDF/{pdfType}")]
    [HttpGet]
    public async ValueTask<IActionResult> GenerateCompletePODocumentAsync(Guid purchaseOrderId, PDFType pdfType)
    {
        var response = new GeneratePDFDocumentResponse();
        try
        {
            response = await _purchaseOrderRepository.GeneratePODocumentAsync(purchaseOrderId, pdfType).ConfigureAwait(false);

            if (response.Data is null || response.Data.FileData is null)
            {
                throw new Exception("An error occurred while trying to generate the document. Please try again.");
            }

            return File(response.Data.FileData, "application/pdf", response.Data.FileName);
        }
        catch (Exception ex)
        {
            response.AddError("An error occurred while trying to generate the document. Please try again.");
            response.AddError(ex.Message);
            return BadRequest(response);
        }
    }
}
