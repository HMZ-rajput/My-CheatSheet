﻿using MarketPro.Application;
using MarketPro.Facebook.DTOs;
using MarketPro.LinkedIn.DTOs;
using MarketPro.SocialAccounts.DTOs;
using Microsoft.AspNetCore.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;
using NSJ = Newtonsoft.Json;

namespace MarketPro.Services;

public class FacebookService : IFacebookService
{
    private const string _apiVersion = "v20.0";
    private const string _graphApiBaseUrl = "https://graph.facebook.com";
    private const string _facebookError = "Facebook Error:";
    private const string _unableToConnectToFacebook = "Unable to connect to Facebook.";
    private const string _facebookAuthCodeExpired = "Facebook auth code expired.";
    private const string _facebookErrorUnauthorized = "Facebook Unauthorized access.";
    private const string _revokedAccessToken = "Facebook revoked access token.";
    private const string _facebookAccessDenied = "Facebook access denied.";
    private const string _facebookServiceError = "Facebook service error.";
    private const string _postSuccessfullyPublished = "Post successfully published!";
    private const string _id = "id";
    private const string _firstName = "first_name";
    private const string _lastName = "last_name";
    private const string _picture = "picture";
    private const string _profilePicture = "profilePicture";
    private const string _data = "data";
    private const string _url = "url";

    private readonly string _clientId;
    private readonly string _clientSecret;
    private readonly HttpClient _httpClient;

    public FacebookService(HttpClient httpClient)
    {
        _httpClient = httpClient ?? throw new ArgumentNullException(nameof(httpClient));
        _clientId = AppEnvironment.FacebookClientId ?? throw new ArgumentNullException(nameof(AppEnvironment.FacebookClientId));
        _clientSecret = AppEnvironment.FacebookClientSecret ?? throw new ArgumentNullException(nameof(AppEnvironment.FacebookClientSecret));
    }

    async ValueTask<FacebookAccessTokenResponse> IFacebookService.GetAccessTokenAsync(string authorizationCode, bool isConnect)
    {
        var response = new FacebookAccessTokenResponse();
        try
        {
            string redirectUri = isConnect ? AppEnvironment.FacebookRedirectUriConnect : AppEnvironment.FacebookRedirectUriSignup;
            var queryParams = new Dictionary<string, string>
        {
            { "code", authorizationCode},
            { "redirect_uri", redirectUri },
            { "client_id", _clientId },
            { "client_secret", _clientSecret }
        };

            var queryString = new FormUrlEncodedContent(queryParams).ReadAsStringAsync().Result;
            var httpClientResponse = await HTTPGetAsync($"{_graphApiBaseUrl}/{_apiVersion}/oauth/access_token?{queryString}").ConfigureAwait(false);

            if (httpClientResponse.IsSuccess && httpClientResponse.HttpResponseMessage is not null)
            {
                var jsonString = await httpClientResponse.HttpResponseMessage.Content.ReadAsStringAsync();
                var deserializeResponse = NSJ.JsonConvert.DeserializeObject<FacebookAccessTokenResponse>(jsonString);

                if (deserializeResponse is null)
                {
                    var error = NSJ.JsonConvert.DeserializeObject<MetaError>(jsonString);
                    response.AddError(error?.Error?.Message ?? _unableToConnectToFacebook);
                    return response;
                }

                return deserializeResponse;
            }
            httpClientResponse.Errors.ForEach(response.AddError);

            return response;
        }
        catch (Exception ex)
        {
            var serviceError = $"{_facebookError} {ex.Message}";
            var error = NSJ.JsonConvert.DeserializeObject<MetaError>(ex.Message);
            response.AddError(error?.Error?.Message ?? serviceError);
            return response;
        }
    }

    async ValueTask<IdResponse?> IFacebookService.PostToPageAsync(string pageAccessToken, IList<IFormFile> images, IList<string> imageUrls, string pageId, string postText)
    {
        var response = new IdResponse();
        try
        {
            IList<AttachedMedia> attachedMedia = [];
            IList<Task<string?>> uploadFbImagetasks = [];
            var url = $"{_graphApiBaseUrl}/{_apiVersion}/{pageId}/feed";

            //this one pending testing
            foreach (var image in images)
                uploadFbImagetasks.Add(UploadPhotosAsync(pageAccessToken, pageId, image, null).AsTask());

            if (uploadFbImagetasks.Any())
            {
                var uploadedImageIds = await Task.WhenAll(uploadFbImagetasks);

                foreach (var uploadedImageId in uploadedImageIds)
                {
                    if (uploadedImageId is not null)
                    {
                        var fbid = new AttachedMedia { media_fbid = uploadedImageId };
                        attachedMedia.Add(fbid);
                    }
                }
            }

            foreach (var image in imageUrls)
                uploadFbImagetasks.Add(UploadPhotosAsync(pageAccessToken, pageId, null, image).AsTask());

            if (uploadFbImagetasks.Any())
            {
                var uploadedImageIds = await Task.WhenAll(uploadFbImagetasks);

                foreach (var uploadedImageId in uploadedImageIds)
                {
                    if (uploadedImageId is not null)
                    {
                        var fbid = new AttachedMedia { media_fbid = uploadedImageId };
                        attachedMedia.Add(fbid);
                    }
                }
            }

            var content = new StringContent(JsonSerializer.Serialize(new
            {
                message = postText,
                access_token = pageAccessToken,
                attached_media = attachedMedia,
                published = true
            }), Encoding.UTF8, "application/json");

            var httpClientResponse = await _httpClient.PostAsync(url, content).ConfigureAwait(false);
            var jsonString = await httpClientResponse.Content.ReadAsStringAsync().ConfigureAwait(false);

            if (httpClientResponse.IsSuccessStatusCode && httpClientResponse.Content is not null)
            {
                var jsonSerializerOptions = new JsonSerializerOptions { PropertyNameCaseInsensitive = true };
                response = NSJ.JsonConvert.DeserializeObject<IdResponse>(jsonString);

                return response;
            }

            response.AddError($"{_facebookError} {jsonString}");
            return response;
        }
        catch (Exception ex)
        {
            var serviceError = $"{_facebookError} {ex.Message}";
            var error = NSJ.JsonConvert.DeserializeObject<MetaError>(ex.Message);
            response?.AddError(error?.Error?.Message ?? serviceError);
            return response;
        }
    }

    async ValueTask<GetUserProfileResponse> IFacebookService.GetUserProfileAsync(string? accessToken)
    {
        var response = new GetUserProfileResponse();
        try
        {
            var headers = new Dictionary<string, string>
        {
            { "Authorization", $"Bearer {accessToken}" }
        };
            var uri = $"{_graphApiBaseUrl}/{_apiVersion}/me/?fields=id,first_name,last_name,name,picture";
            var httpResponse = await HTTPGetAsync(uri, headers)
                .ConfigureAwait(false);

            if (httpResponse.IsSuccess && httpResponse.HttpResponseMessage is not null)
            {
                var jsonString = await httpResponse.HttpResponseMessage.Content.ReadAsStringAsync().ConfigureAwait(false);
                var extractedValues = ExtractUserProfileValues(jsonString);
                if (extractedValues is not null)
                {
                    response.UserProfile = new UserProfileResponse
                    {
                        SocialAccountId = extractedValues[_id].ToString(),
                        FirstName = extractedValues[_firstName].ToString(),
                        LastName = extractedValues[_lastName].ToString(),
                        ProfilePicture = extractedValues[_profilePicture].ToString()
                    };
                    return response;
                }
            }

            httpResponse.Errors.ForEach(e => response.AddError(e));

            return response;
        }
        catch (Exception ex)
        {
            var serviceError = $"{_facebookError} {ex.Message}";
            var error = NSJ.JsonConvert.DeserializeObject<MetaError>(ex.Message);
            response.AddError(error?.Error?.Message ?? serviceError);
            return response;
        }
    }

    async ValueTask<GetFacebookPageDetailsResponse> IFacebookService.GetPagesDetailsAsync(string? accessToken, string userId)
    {
        var response = new GetFacebookPageDetailsResponse();
        try
        {
            _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);
            var httpClientResponse = await HTTPGetAsync($"{_graphApiBaseUrl}/{_apiVersion}/{userId}/accounts?fields=name,id,access_token,instagram_business_account{{id,name,username,profile_picture_url}}").ConfigureAwait(false);
            if (httpClientResponse.IsSuccess && httpClientResponse.HttpResponseMessage is not null)
            {
                var jsonString = await httpClientResponse.HttpResponseMessage.Content.ReadAsStringAsync();
                var jsonSerializerOptions = new JsonSerializerOptions { PropertyNameCaseInsensitive = true };
                var deserializeResponse = NSJ.JsonConvert.DeserializeObject<FacebookPageDetailResponse>(jsonString);

                if (deserializeResponse is null || deserializeResponse.Pages.Count == 0)
                {
                    var error = NSJ.JsonConvert.DeserializeObject<MetaError>(jsonString);
                    response.AddError(error?.Error?.Message ?? _unableToConnectToFacebook);
                    return response;
                }

                foreach (var page in deserializeResponse.Pages)
                {
                    var pageItem = new PageDTO
                    {
                        Id = page.Id,
                        Name = page.Name,
                        Category = page.Category,
                        AccessToken = page.AccessToken,
                        InstagramBusinessAccount = page.InstagramBusinessAccount
                    };

                    foreach (var category in page.Categories)
                    {
                        var categoryList = new CategoryList
                        {
                            Id = category.Id,
                            Name = category.Name
                        };
                        pageItem.Categories.Add(categoryList);
                    }

                    response.Pages.Add(pageItem);
                }
            }
            return response;

        }
        catch (Exception ex)
        {
            var serviceError = $"{_facebookError} {ex.Message}";
            var error = NSJ.JsonConvert.DeserializeObject<MetaError>(ex.Message);
            response.AddError(error?.Error?.Message ?? serviceError);
            return response;
        }
    }

    async ValueTask<GetStatisticsResponse> IFacebookService.GetStatisticsAsync(string? pageAccessToken, string pageId)
    {
        var response = new GetStatisticsResponse();
        try
        {
            var insightsResponse = await GetPageInsightsAsync(pageAccessToken, pageId).ConfigureAwait(false);
            response.Statistic = CalculateStatistics(insightsResponse.Insights);
            return response;
        }
        catch (Exception ex)
        {
            var serviceError = $"{_facebookError} {ex.Message}";
            var error = NSJ.JsonConvert.DeserializeObject<MetaError>(ex.Message);
            response.AddError(error?.Error?.Message ?? serviceError);
            return response;
        }
    }

    private async ValueTask<PageInsightsResponse> GetPageInsightsAsync(string? pageAccessToken, string pageId)
    {
        var response = new PageInsightsResponse();
        try
        {
            var startDate = DateTimeOffset.UtcNow.AddDays(-9);
            var endDate = DateTimeOffset.UtcNow.AddDays(-2);
            var url = $"{_graphApiBaseUrl}/{_apiVersion}/{pageId}/insights?metric=page_impressions_unique,page_impressions,page_post_engagements&since={startDate.ToUnixTimeSeconds()}&until={endDate.ToUnixTimeSeconds()}&period={InsightsPeriod.day.ToString()}&access_token={pageAccessToken}";
            using var request = new HttpRequestMessage(HttpMethod.Get, url);
            var httpResponse = await _httpClient.SendAsync(request);
            var responseBody = await httpResponse.Content.ReadAsStringAsync().ConfigureAwait(false);

            if (!httpResponse.IsSuccessStatusCode)
            {
                var error = NSJ.JsonConvert.DeserializeObject<MetaError>(responseBody);
                response.AddError(error?.Error?.Message ?? _facebookServiceError);
                return response;
            }

            var deserializeResponse = NSJ.JsonConvert.DeserializeObject<PageInsights>(responseBody);

            if (deserializeResponse is null)
            {
                var error = NSJ.JsonConvert.DeserializeObject<MetaError>(responseBody);
                response.AddError(error?.Error?.Message ?? _facebookServiceError);
                return response;
            }

            response.Insights = deserializeResponse;
            return response;
        }
        catch (Exception ex)
        {
            var serviceError = $"{_facebookError} {ex.Message}";
            var error = NSJ.JsonConvert.DeserializeObject<MetaError>(ex.Message);
            response.AddError(error?.Error?.Message ?? serviceError);
            return response;
        }
    }

    private StatisticsResponse CalculateStatistics(PageInsights? pageInsights)
    {
        var response = new StatisticsResponse();

        if (pageInsights is not null)
        {
            foreach (var insightData in pageInsights.Data)
            {
                var (sum, xAxis, yAxis) = CalculateMetrics(insightData.Values);
                switch (insightData.Name)
                {
                    case "page_impressions_unique":
                        response.TotalAudience.Total += sum;
                        response.TotalAudience.YAxis.AddRange(yAxis);
                        response.TotalAudience.XAxis.AddRange(xAxis);
                        break;

                    case "page_impressions":
                        response.TotalImpression.Total += sum;
                        response.TotalImpression.YAxis.AddRange(yAxis);
                        response.TotalImpression.XAxis.AddRange(xAxis);
                        break;

                    case "page_post_engagements":
                        response.TotalEngagement.Total += sum;
                        response.TotalEngagement.YAxis.AddRange(yAxis);
                        response.TotalEngagement.XAxis.AddRange(xAxis);
                        break;

                    default:
                        break;
                }
            }
        }

        return response;
    }

    private (int sum, IList<int> xAxis, IList<DateTime> yAxis) CalculateMetrics(IList<InsightValue> values)
    {
        int sum = 0;
        IList<int> xAxis = [];
        IList<DateTime> yAxis = [];
        foreach (var value in values)
        {
            sum += value.Value;
            xAxis.Add(value.Value);
            yAxis.Add(value.EndTime);
        }
        return (sum, xAxis, yAxis);
    }

    private async ValueTask<string?> UploadPhotosAsync(string pageAccessToken, string pageId, IFormFile? image, string? imageUrl)
    {
        try
        {
            StringContent? content = null;
            var url = $"{_graphApiBaseUrl}/{_apiVersion}/{pageId}/photos";

            Dictionary<string, object> obj = new Dictionary<string, object>()
        {
            { "access_token", pageAccessToken },
            { "published", false }
        };

            if (image is not null)
            {
                obj.Add("source", image);
            }
            else if (imageUrl is not null)
            {
                obj.Add("url", imageUrl);
            }


            content = new StringContent(JsonSerializer.Serialize(obj), Encoding.UTF8, "application/json");

            var response = await _httpClient.PostAsync(url, content);

            if (response.IsSuccessStatusCode)
            {
                var jsonString = await response.Content.ReadAsStringAsync();
                var deserializeResponse = NSJ.JsonConvert.DeserializeObject<IdResponse>(jsonString);

                if (deserializeResponse is null || deserializeResponse.Id is null)
                {
                    var error = NSJ.JsonConvert.DeserializeObject<MetaError>(jsonString);
                    throw new Exception(error?.Error?.Message ?? _unableToConnectToFacebook);
                }

                return deserializeResponse.Id;
            }

            return null;
        }
        catch (Exception ex)
        {
            var serviceError = $"{_facebookError} {ex.Message}";
            var error = NSJ.JsonConvert.DeserializeObject<MetaError>(ex.Message);
            throw new Exception(error?.Error?.Message ?? serviceError);
        }
    }

    private async ValueTask<HttpResponse> HTTPGetAsync(string uri, Dictionary<string, string>? headers = null)
    {
        var response = new HttpResponse();
        try
        {
            using (var request = new HttpRequestMessage(HttpMethod.Get, uri))
            {
                if (headers is not null)
                {
                    foreach (var header in headers)
                    {
                        request.Headers.Add(header.Key, header.Value);
                    }
                }
                var httpClientResponse = await _httpClient.SendAsync(request);
                response.HttpResponseMessage = httpClientResponse;
                var jsonString = await httpClientResponse.Content.ReadAsStringAsync().ConfigureAwait(false);

                if (httpClientResponse is not null)
                {
                    var error = NSJ.JsonConvert.DeserializeObject<MetaError>(jsonString);

                    if (httpClientResponse.StatusCode == System.Net.HttpStatusCode.BadRequest)
                    {
                        response.AddError(error?.Error?.Message ?? _facebookAuthCodeExpired);
                        return response;
                    }
                    else if (httpClientResponse.StatusCode == System.Net.HttpStatusCode.Unauthorized)
                    {
                        response.AddError(error?.Error?.Message ?? _facebookErrorUnauthorized);
                        return response;
                    }
                    else if (httpClientResponse.StatusCode == System.Net.HttpStatusCode.Forbidden)
                    {
                        response.AddError(error?.Error?.Message ?? _facebookAccessDenied);
                        return response;
                    }
                    else if (httpClientResponse.StatusCode != System.Net.HttpStatusCode.OK)
                    {
                        response.AddError(error?.Error?.Message ?? _facebookAuthCodeExpired);
                        return response;
                    }
                }

                return response;
            }
        }
        catch (Exception ex)
        {
            var serviceError = $"{_facebookError} {ex.Message}";
            var error = NSJ.JsonConvert.DeserializeObject<MetaError>(ex.Message);
            response.AddError(error?.Error?.Message ?? serviceError);
            return response;
        }
    }

    private Dictionary<string, object>? ExtractUserProfileValues(string jsonString)
    {
        try
        {
            Dictionary<string, object> keyValuePairs = new Dictionary<string, object>();
            JsonNode? jsonNode = JsonNode.Parse(jsonString);

            if (jsonNode != null)
            {
                ExtractProperty(jsonNode, _id, keyValuePairs);
                ExtractProperty(jsonNode, _firstName, keyValuePairs);
                ExtractProperty(jsonNode, _lastName, keyValuePairs);

                var profilePictureNode = jsonNode[_picture]?[_data]?[_url];
                if (profilePictureNode != null)
                {
                    keyValuePairs[_profilePicture] = profilePictureNode.ToString();
                }
            }

            return keyValuePairs;
        }
        catch (Exception ex)
        {
            var error = NSJ.JsonConvert.DeserializeObject<MetaError>(ex.Message);
            throw new InvalidOperationException(error?.Error?.Message ?? _facebookServiceError);
        }
    }

    private void ExtractProperty(JsonNode node, string propertyKey, Dictionary<string, object> keyValuePairs)
    {
        var nodeProperty = node[propertyKey];
        if (nodeProperty != null)
        {
            keyValuePairs[propertyKey] = nodeProperty.ToString();
        }
    }

    public enum InsightsPeriod
    {
        day = 0,
        week = 1,
        days_28 = 2
    }

}