﻿using MailKit.Net.Smtp;
using MailKit.Security;
using MimeKit;
using MarketPro.Application;

namespace MarketPro.Services;

public class MailService : IMailService
{
    async ValueTask<bool> IMailService.SendEmailAsync(string toEmailAddress, string subject, string body)
    {
        int retryCount = 0;

        while (retryCount < 5)
        {
            retryCount++;

            try
            {
                var message = new MimeMessage();
                message.From.Add(new MailboxAddress(AppEnvironment.SenderEmailAddress, AppEnvironment.SenderEmailAddress));
                message.To.Add(new MailboxAddress(toEmailAddress, toEmailAddress));
                message.Subject = subject;

                var bodyBuilder = new BodyBuilder();
                bodyBuilder.HtmlBody = body;
                message.Body = bodyBuilder.ToMessageBody();

                using (var client = new SmtpClient())
                {
                    client.Connect(AppEnvironment.SMTPHost, AppEnvironment.SMTPPort, SecureSocketOptions.StartTls);
                    client.Authenticate(AppEnvironment.SenderEmailAddress, AppEnvironment.SenderEmailPassword);
                    await client.SendAsync(message).ConfigureAwait(false);
                    await client.DisconnectAsync(true).ConfigureAwait(false);
                }

                retryCount = 6;
            }
            catch (Exception)
            {
                if (retryCount == 4)
                {
                    return false;
                }
            }
        }

        return true;
    }
}