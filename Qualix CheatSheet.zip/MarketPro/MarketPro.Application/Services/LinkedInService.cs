﻿using MarketPro.Application;
using MarketPro.Facebook.DTOs;
using MarketPro.LinkedIn.DTOs;
using MarketPro.SocialAccounts.DTOs;
using Newtonsoft.Json;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json.Nodes;

namespace MarketPro.Services;

public class LinkedInService : ILinkedInService
{
    private const string _baseUrl = "https://api.linkedin.com";
    private const string _oauthBaseUrl = "https://www.linkedin.com/oauth";
    private const string _apiVersion = "v2";
    private const string _unableToConnectToLinkedIn = "Unable to connect to linkedIn.";
    private const string _linkedInAuthCodeExpired = "LinkedIn auth code expired.";
    private const string _revokedAccessToken = "LinkedIn revoked access token.";
    private const string _linkedInAccessDenied = "LinkedIn access denied.";
    private const string _linkedInErrorUnauthorized = "LinkedIn Unauthorized access.";
    private const string _linkedInServiceError = "LinkedIn service error.";
    private const string _linkedInFailedToUploadImage = "LinkedIn service failed to upload image.";
    private const string _id = "id";
    private const string _localizedFirstName = "localizedFirstName";
    private const string _localizedLastName = "localizedLastName";
    private const string _localizedHeadline = "localizedHeadline";
    private const string _vanityName = "vanityName";
    private const string _profilePicture = "profilePicture";
    private const string _displayImage = "displayImage~";
    private const string _elements = "elements";
    private const string _identifiers = "identifiers";
    private const string _identifier = "identifier";
    private const int _analyticsDaysToSubtract = -7;

    private readonly string _client_id;
    private readonly string _client_secret;
    private readonly IFileService _fileService;
    private readonly IHttpClientFactory _httpClientFactory;

    public LinkedInService(HttpClient httpClient, IFileService fileService, IHttpClientFactory httpClientFactory)
    {
        _client_id = AppEnvironment.LinkedInClientId ?? throw new ArgumentNullException(nameof(AppEnvironment.LinkedInClientId));
        _client_secret = AppEnvironment.LinkedInClientSecret ?? throw new ArgumentNullException(nameof(AppEnvironment.LinkedInClientSecret));
        _fileService = fileService ?? throw new ArgumentNullException(nameof(fileService));
        _httpClientFactory = httpClientFactory ?? throw new ArgumentNullException(nameof(httpClientFactory));
    }

    async ValueTask<GetAccessTokenResponse?> ILinkedInService.GetAccessTokenAsync(string authorizationCode, bool isConnect)
    {
        string redirectUri = isConnect ? AppEnvironment.LinkedInRedirectUriConnect : AppEnvironment.LinkedInRedirectUriSignup;
        GetAccessTokenResponse response = new GetAccessTokenResponse();
        var queryParams = new Dictionary<string, string>
    {
        { "grant_type", "authorization_code"},
        { "code", authorizationCode},
        { "redirect_uri", redirectUri },
        { "client_id", _client_id },
        { "client_secret", _client_secret }
    };

        var queryString = new FormUrlEncodedContent(queryParams).ReadAsStringAsync().Result;
        var httpClientResponse = await HTTPGetAsync($"{_oauthBaseUrl}/{_apiVersion}/accessToken?{queryString}").ConfigureAwait(false);

        if (httpClientResponse.IsSuccess && httpClientResponse.HttpResponseMessage is not null)
        {
            var jsonString = await httpClientResponse.HttpResponseMessage.Content.ReadAsStringAsync();
            var deserializeResponse = JsonConvert.DeserializeObject<AccessTokenResponse>(jsonString);

            if (deserializeResponse is null)
            {
                response.AddError(_unableToConnectToLinkedIn);
                return response;
            }

            response.AccessTokenResponse = deserializeResponse;
            return response;
        }
        httpClientResponse.Errors.ForEach(response.AddError);

        return response;
    }

    async ValueTask<string?> ILinkedInService.GetAccessTokenFromRefreshTokenAsync(string refreshToken, bool isConnect)
    {
        var client = _httpClientFactory.CreateClient();
        string redirectUri = isConnect ? AppEnvironment.LinkedInRedirectUriConnect : AppEnvironment.LinkedInRedirectUriSignup;
        var queryParams = new Dictionary<string, string>
        {
            { "grant_type", "refresh_token" },
            { "refresh_token", refreshToken },
            { "Content-Type", "application/x-www-form-urlencoded" },
            { "redirect_uri", redirectUri },
            { "client_id", _client_id },
            { "client_secret", _client_secret }
        };

        var queryString = new FormUrlEncodedContent(queryParams).ReadAsStringAsync().Result;
        var response = await client.GetAsync($"{_oauthBaseUrl}/{_apiVersion}/accessToken?{queryString}");

        return await response.Content.ReadAsStringAsync();
    }

    async ValueTask<GetUserProfileResponse> ILinkedInService.GetUserProfileAsync(string? accessToken)
    {
        GetUserProfileResponse response = new GetUserProfileResponse();
        var headers = new Dictionary<string, string>
        {
            { "Authorization", $"Bearer {accessToken}" }
        };
        var uri = $"{_baseUrl}/{_apiVersion}/me?projection=(id,firstName,localizedFirstName,lastName,localizedLastName,vanityName,headline,localizedHeadline,profilePicture(displayImage~:playableStreams))";
        var httpResponse = await HTTPGetAsync(uri, headers)
            .ConfigureAwait(false);

        if (httpResponse.IsSuccess && httpResponse.HttpResponseMessage is not null)
        {
            var jsonString = await httpResponse.HttpResponseMessage.Content.ReadAsStringAsync();
            var extractedValues = ExtractUserProfileValues(jsonString);
            if (extractedValues is not null)
            {
                response.UserProfile = new UserProfileResponse
                {
                    SocialAccountId = extractedValues[_id].ToString(),
                    FirstName = extractedValues[_localizedFirstName].ToString(),
                    LastName = extractedValues[_localizedLastName].ToString(),
                    VanityName = extractedValues[_vanityName].ToString(),
                    Headline = extractedValues[_localizedHeadline].ToString(),
                    ProfilePicture = extractedValues[_profilePicture].ToString()
                };
                return response;
            }
        }

        response.Errors.ForEach(e => response.AddError(e));

        return response;
    }

    async ValueTask<IdResponse?> ILinkedInService.PostContentAsync(string accessToken, string organizationId, IList<string> imageUrls, string postContent)
    {
        var response = new IdResponse();

        try
        {
            var client = _httpClientFactory.CreateClient();
            IList<object> imagesMedia = [];
            IList<Task<string?>> uploadLinkedInImagetasks = [];
            var url = $"{_baseUrl}/{_apiVersion}/ugcPosts";

            foreach (var imageUrl in imageUrls)
                uploadLinkedInImagetasks.Add(GetImageMedia(accessToken, organizationId, imageUrl).AsTask());

            if (uploadLinkedInImagetasks.Any())
            {
                var uploadedImageAssets = await Task.WhenAll(uploadLinkedInImagetasks);

                foreach (var asset in uploadedImageAssets)
                {
                    if (asset is not null)
                    {
                        var imageMedia = new
                        {
                            status = "READY",
                            media = asset
                        };
                        imagesMedia.Add(imageMedia);
                    }
                }
            }

            var postRequest = new Dictionary<string, object>
            {
                { "author", $"urn:li:organization:{organizationId}" },
                { "lifecycleState", "PUBLISHED" },
                {
                    "specificContent", new Dictionary<string, object>
                    {
                        {
                            "com.linkedin.ugc.ShareContent", new Dictionary<string, object>
                            {
                                { "shareCommentary", new { text = postContent } },
                                { "shareMediaCategory", imagesMedia.Count == 0 ? MediaType.NONE.ToString() : MediaType.IMAGE.ToString() },
                                { "media", imagesMedia }
                            }
                        }
                    }
                },
                { "visibility", new Dictionary<string, object> { { "com.linkedin.ugc.MemberNetworkVisibility", "PUBLIC" } } }
            };

            var content = new StringContent(JsonConvert.SerializeObject(postRequest), Encoding.UTF8, "application/json");
            using var request = new HttpRequestMessage(HttpMethod.Post, url)
            {
                Content = content
            };
            request.Headers.Add("Authorization", $"Bearer {accessToken}");
            request.Headers.Add("X-Restli-Protocol-Version", "2.0.0");
            var httpClientResponse = await client.SendAsync(request);
            var jsonString = await httpClientResponse.Content.ReadAsStringAsync().ConfigureAwait(false);

            if (httpClientResponse.IsSuccessStatusCode)
            {
                var deserializeResponse = JsonConvert.DeserializeObject<IdResponse>(jsonString);

                return deserializeResponse;
            }

            response.AddError(jsonString);
            return response;
        }
        catch (Exception ex)
        {
            response.AddError(ex.Message);
            return response;
        }

    }

    async ValueTask<PageDetailsResponse?> ILinkedInService.GetOrganizationsAsync(string accessToken)
    {
        var response = new PageDetailsResponse();
        var headers = new Dictionary<string, string>
        {
            { "Authorization", $"Bearer {accessToken}" },
            { "X-Restli-Protocol-Version", "2.0.0" }
        };
        var uri = $"{_baseUrl}/{_apiVersion}/organizationAcls?q=roleAssignee&role=ADMINISTRATOR&projection=(elements*(*,organization~(id,localizedName)))";
        var httpResponse = await HTTPGetAsync(uri, headers)
            .ConfigureAwait(false);

        if (httpResponse.IsSuccess && httpResponse.HttpResponseMessage is not null)
        {
            var responseBody = await httpResponse.HttpResponseMessage.Content.ReadAsStringAsync().ConfigureAwait(false);
            var deserializeResponse = JsonConvert.DeserializeObject<PageDetailsResponse>(responseBody);

            if (deserializeResponse is null)
            {
                response.AddError(_linkedInServiceError);
                return response;
            }

            return deserializeResponse;
        }

        httpResponse.Errors.ForEach(e => response.AddError(e));

        return response;
    }

    async ValueTask<GetStatisticsResponse> ILinkedInService.GetStatisticsAsync(string accessToken, string organizationId)
    {
        var response = new GetStatisticsResponse();
        var pageStatistics = await GetOrganizationPageStatisticsAsync(accessToken, organizationId).ConfigureAwait(false);
        var entityFollowerStatistics = await GetOrganizationalEntityFollowerStatisticsAsync(accessToken, organizationId).ConfigureAwait(false);

        response.Statistic = CalculateStatistics(entityFollowerStatistics.OrganizationalEntityFollowerStatistics, pageStatistics.OrganizationPageStatistics);
        return response;
    }

    private async ValueTask<RegisterUploadResponse?> RegisterUploadAsync(string accessToken, string organizationId)
    {
        var client = _httpClientFactory.CreateClient();
        var response = new RegisterUploadResponse();
        var url = $"{_baseUrl}/{_apiVersion}/assets?action=registerUpload";

        var requestBody = new
        {
            registerUploadRequest = new
            {
                owner = $"urn:li:organization:{organizationId}",
                recipes = new[] { "urn:li:digitalmediaRecipe:feedshare-image" },
                serviceRelationships = new[]
                        {
                            new
                            {
                                identifier = "urn:li:userGeneratedContent",
                                relationshipType = "OWNER"
                            }
                        },
                supportedUploadMechanism = new[] { "SYNCHRONOUS_UPLOAD" }
            }
        };

        var json = JsonConvert.SerializeObject(requestBody);
        var content = new StringContent(json, Encoding.UTF8, "application/json");
        using var request = new HttpRequestMessage(HttpMethod.Post, url)
        {
            Content = content
        };
        request.Headers.Add("Authorization", $"Bearer {accessToken}");
        request.Headers.Add("X-Restli-Protocol-Version", "2.0.0");
        var httpResponse = await client.SendAsync(request);

        if (!httpResponse.IsSuccessStatusCode)
        {
            response.AddError(_linkedInServiceError);
            return response;
        }

        var responseBody = await httpResponse.Content.ReadAsStringAsync().ConfigureAwait(false);
        var deserializeResponse = JsonConvert.DeserializeObject<RegisterUploadResponse>(responseBody);

        if (deserializeResponse is null)
        {
            response.AddError(_linkedInServiceError);
            return response;
        }

        return deserializeResponse;
    }

    private async ValueTask<bool> UploadMediaAsync(string accessToken, string? registeredUploadUrl, string imageUrl)
    {
        var client = _httpClientFactory.CreateClient();
        byte[] imageData = await _fileService.DownloadImageAsByteArrayAsync(imageUrl);

        if (imageData == null || imageData.Length == 0)
        {
            throw new InvalidOperationException("Failed to download or convert image to byte array.");
        }

        using (var request = new HttpRequestMessage(HttpMethod.Put, registeredUploadUrl))
        {
            request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);
            request.Headers.Add("X-Restli-Protocol-Version", "2.0.0");
            var content = new ByteArrayContent(imageData);
            content.Headers.ContentType = new MediaTypeHeaderValue("image/jpeg");
            request.Content = content;

            HttpResponseMessage response = await client.SendAsync(request);

            return true;
        }
    }

    private async ValueTask<OrganizationPageStatisticsResponse> GetOrganizationPageStatisticsAsync(string accessToken, string organizationId)
    {
        var response = new OrganizationPageStatisticsResponse();
        try
        {
            using var http = new HttpClient();
            var currentTime = DateTimeOffset.UtcNow.AddDays(-1);
            var end = currentTime.ToUnixTimeMilliseconds();
            var start = currentTime.AddDays(_analyticsDaysToSubtract).ToUnixTimeMilliseconds();
            var url = $"{_baseUrl}/{_apiVersion}/organizationPageStatistics?q=organization&organization=urn%3Ali%3Aorganization%3A{organizationId}&timeIntervals=(timeGranularityType:{TimeGranularityType.DAY.ToString()},timeRange:(start:{start},end:{end}))";
            using var request = new HttpRequestMessage(HttpMethod.Get, url);
            request.Headers.Add("Authorization", $"Bearer {accessToken}");
            request.Headers.Add("X-Restli-Protocol-Version", "2.0.0");
            var httpResponse = await http.SendAsync(request);


            if (!httpResponse.IsSuccessStatusCode)
            {
                response.AddError(_linkedInServiceError);
                return response;
            }

            var responseBody = await httpResponse.Content.ReadAsStringAsync().ConfigureAwait(false);
            var deserializeResponse = JsonConvert.DeserializeObject<OrganizationPageStatistics>(responseBody);

            if (deserializeResponse is null)
            {
                response.AddError(_linkedInServiceError);
                return response;
            }

            response.OrganizationPageStatistics = deserializeResponse;
            return response;
        }
        catch (Exception ex)
        {
            response.AddError($"{_linkedInServiceError}  {ex.Message}");
            return response;
        }
    }

    private async ValueTask<OrganizationalEntityFollowerStatisticsResponse> GetOrganizationalEntityFollowerStatisticsAsync(string accessToken, string organizationId)
    {
        var client = _httpClientFactory.CreateClient();
        var response = new OrganizationalEntityFollowerStatisticsResponse();
        var currentTime = DateTimeOffset.UtcNow.AddDays(-1);
        var end = currentTime.ToUnixTimeMilliseconds();
        var start = currentTime.AddDays(_analyticsDaysToSubtract).ToUnixTimeMilliseconds();
        var url = $"{_baseUrl}/{_apiVersion}/organizationalEntityFollowerStatistics?q=organizationalEntity&organizationalEntity=urn%3Ali%3Aorganization%3A{organizationId}&timeIntervals=(timeGranularityType:{TimeGranularityType.DAY.ToString()},timeRange:(start:{start},end:{end}))";
        using var request = new HttpRequestMessage(HttpMethod.Get, url);
        request.Headers.Add("Authorization", $"Bearer {accessToken}");
        request.Headers.Add("X-Restli-Protocol-Version", "2.0.0");
        var httpResponse = await client.SendAsync(request);
        var responseBody = await httpResponse.Content.ReadAsStringAsync().ConfigureAwait(false);

        if (!httpResponse.IsSuccessStatusCode)
        {
            response.AddError(_linkedInServiceError);
            return response;
        }

        var deserializeResponse = JsonConvert.DeserializeObject<OrganizationalEntityFollowerStatistics>(responseBody);

        if (deserializeResponse is null)
        {
            response.AddError(_linkedInServiceError);
            return response;
        }

        response.OrganizationalEntityFollowerStatistics = deserializeResponse;
        return response;
    }

    private StatisticsResponse CalculateStatistics(OrganizationalEntityFollowerStatistics? entityFollowerStatistics, OrganizationPageStatistics? pageStatistics)
    {
        var response = new StatisticsResponse();

        if (entityFollowerStatistics is not null)
        {
            foreach (var element in entityFollowerStatistics.Elements)
            {
                var audience = element?.FollowerGains?.OrganicFollowerGain ?? 0 + element?.FollowerGains?.PaidFollowerGain ?? 0;
                response.TotalAudience.Total += audience;
                response.TotalAudience.XAxis.Add(audience);
                DateTime date = DateTimeOffset.FromUnixTimeMilliseconds(element?.TimeRange?.End ?? 0).DateTime;
                response.TotalAudience.YAxis.Add(date);
            }
        }

        if (pageStatistics is not null)
        {
            foreach (var element in pageStatistics.Elements)
            {
                var impression = element?.TotalPageStatistics?.Views?.AllPageViews?.PageViews ?? 0 +
                                    element?.TotalPageStatistics?.Views?.AllDesktopPageViews?.PageViews ?? 0 +
                                    element?.TotalPageStatistics?.Views?.AllMobilePageViews?.PageViews ?? 0;
                var engagement = element?.TotalPageStatistics?.Clicks?.MobileCustomButtonClickCounts?.Sum(x => x.Clicks) ?? 0 +
                                   element?.TotalPageStatistics?.Clicks?.CareersPageClicks?.CareersPageJobsClicks ?? 0 +
                                   element?.TotalPageStatistics?.Clicks?.CareersPageClicks?.CareersPagePromoLinksClicks ?? 0 +
                                   element?.TotalPageStatistics?.Clicks?.CareersPageClicks?.CareersPageBannerPromoClicks ?? 0 +
                                   element?.TotalPageStatistics?.Clicks?.CareersPageClicks?.CareersPageEmployeesClicks ?? 0;
                DateTime date = DateTimeOffset.FromUnixTimeMilliseconds(element?.TimeRange?.End ?? 0).DateTime;
                response.TotalImpression.Total += impression;
                response.TotalEngagement.Total += engagement;

                response.TotalImpression.XAxis.Add(impression);
                response.TotalEngagement.XAxis.Add(engagement);
                response.TotalImpression.YAxis.Add(date);
                response.TotalEngagement.YAxis.Add(date);
            }
        }

        return response;
    }

    private async ValueTask<HttpResponse> HTTPGetAsync(string uri, Dictionary<string, string>? headers = null)
    {
        var client = _httpClientFactory.CreateClient();
        using (var request = new HttpRequestMessage(HttpMethod.Get, uri))
        {
            if (headers is not null)
            {
                foreach (var header in headers)
                {
                    request.Headers.Add(header.Key, header.Value);
                }
            }
            var httpClientResponse = await client.SendAsync(request);
            var response = new HttpResponse
            {
                HttpResponseMessage = httpClientResponse
            };

            if (httpClientResponse is not null)
            {
                switch (httpClientResponse.StatusCode)
                {
                    case System.Net.HttpStatusCode.BadRequest:
                        response.AddError(_linkedInAuthCodeExpired);
                        break;
                    case System.Net.HttpStatusCode.Unauthorized:
                        response.AddError(_linkedInErrorUnauthorized);
                        break;
                    case System.Net.HttpStatusCode.Forbidden:
                        response.AddError(_linkedInAccessDenied);
                        break;
                    default:
                        if (httpClientResponse.StatusCode != System.Net.HttpStatusCode.OK)
                        {
                            response.AddError(_linkedInAuthCodeExpired);
                        }
                        break;
                }
            }
            return response;
        }
    }

    private Dictionary<string, object>? ExtractUserProfileValues(string jsonString)
    {
        try
        {
            Dictionary<string, object> keyValuePairs = new Dictionary<string, object>();
            JsonNode? jsonNode = JsonNode.Parse(jsonString);

            if (jsonNode != null)
            {
                ExtractProperty(jsonNode, _id, keyValuePairs);
                ExtractProperty(jsonNode, _localizedFirstName, keyValuePairs);
                ExtractProperty(jsonNode, _localizedLastName, keyValuePairs);
                ExtractProperty(jsonNode, _localizedHeadline, keyValuePairs);
                ExtractProperty(jsonNode, _vanityName, keyValuePairs);

                var profilePictureNode = jsonNode[_profilePicture]?[_displayImage]?[_elements]?[0]?[_identifiers]?[0]?[_identifier];
                if (profilePictureNode != null)
                {
                    keyValuePairs[_profilePicture] = profilePictureNode.ToString();
                }
            }

            return keyValuePairs;
        }
        catch (Exception)
        {
            throw new Exception(_linkedInServiceError);
        }
    }

    private void ExtractProperty(JsonNode node, string propertyKey, Dictionary<string, object> keyValuePairs)
    {
        var nodeProperty = node[propertyKey];
        if (nodeProperty != null)
        {
            keyValuePairs[propertyKey] = nodeProperty.ToString();
        }
    }

    private async ValueTask<string?> GetImageMedia(string accessToken, string organizationId, string imageUrl)
    {
        var uploadRegistered = await RegisterUploadAsync(accessToken, organizationId).ConfigureAwait(false);
        if (uploadRegistered is not null && uploadRegistered.IsSuccess)
        {
            var uploadUrl = uploadRegistered?.Value?.UploadMechanism?.MediaUploadHttpRequest?.UploadUrl;
            var uploadMediaResponse = await UploadMediaAsync(accessToken, uploadUrl, imageUrl).ConfigureAwait(false);
            if (uploadMediaResponse)
            {
                var asset = uploadRegistered?.Value?.Asset;

                if (asset is not null)
                    return asset;
            }
        }
        return null;
    }

    public enum MediaType
    {
        NONE = 0,
        IMAGE = 1,
        VIDEO = 2
    }


    public enum TimeGranularityType
    {
        DAY = 0,
        WEEK = 1,
        MONTH = 2
    }

}