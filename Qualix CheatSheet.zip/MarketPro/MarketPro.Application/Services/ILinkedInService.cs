﻿using MarketPro.Facebook.DTOs;
using MarketPro.LinkedIn.DTOs;

namespace MarketPro.Services;

public interface ILinkedInService
{
    public ValueTask<GetAccessTokenResponse?> GetAccessTokenAsync(string authorizationCode, bool isConnect);
    public ValueTask<string?> GetAccessTokenFromRefreshTokenAsync(string refreshToken, bool isConnect);
    public ValueTask<GetUserProfileResponse> GetUserProfileAsync(string? accessToken);
    public ValueTask<IdResponse?> PostContentAsync(string accessToken, string organizationId, IList<string> imageUrls, string postContent);
    public ValueTask<PageDetailsResponse?> GetOrganizationsAsync(string accessToken);
    public ValueTask<GetStatisticsResponse> GetStatisticsAsync(string accessToken, string organizationId);

}