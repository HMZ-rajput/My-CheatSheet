﻿using MarketPro.PlanRules.DTOs;
using MarketPro.UserAccounts.Entities;

namespace MarketPro.Services;

public class PlanRuleValidator : IPlanRuleValidator
{
    private const string _socialAccountLimitError = "Social account limit reached. Can not add more social accounts.";
    private const string _managerLimitError = "Manager limit reached. Can not add more Managers.";
    private const string _unrecognizedPlan = "Unrecognized plan type:";
    private const string _subscriptionStatusError = "Subscription: ";
    private const string _userNotFoundError = "User does not exist.";
    private const string _aiNotAllowedError = "User does not have right to generate Ai Content.";
    private const string _queueNotAllowedError = "User does not have right to schedule post.";
    private const string _managerNotAllowedError = "Managers are not allowed in";

    private readonly Dictionary<Plan, PlanRule> packageRules = new Dictionary<Plan, PlanRule>
    {
        { Plan.Basic, new PlanRule { MaxSocialAccounts = 3, MaxManagers = 0, IsAiAllowed = false, IsQueueAllowed = false } },
        { Plan.Pro, new PlanRule { MaxSocialAccounts = 10 , MaxManagers = 0, IsAiAllowed = false, IsQueueAllowed = false } },
        { Plan.Enterprise, new PlanRule { MaxSocialAccounts = 100 , MaxManagers = 10, IsAiAllowed = true, IsQueueAllowed = true } }
    };

    bool IPlanRuleValidator.CanConnectSocialAccount(UserAccount? user)
    {
        if (user is null)
            throw new ArgumentException(_userNotFoundError);

        var plan = user.Plan;
        var status = user.SubscriptionStatus;
        var socialAccountsCount = user.ApplicationUser!.SocialAccounts.Where(s => s.IsActive).Count();

        if (!packageRules.TryGetValue(plan, out var planRule))
            throw new ArgumentException($"{_unrecognizedPlan} {plan.ToString()}");

        if (status != SubscriptionStatus.active && status != SubscriptionStatus.trialing)
            throw new ArgumentException($"{_subscriptionStatusError} {status.ToString()}");

        if (socialAccountsCount < packageRules[plan].MaxSocialAccounts)
            return true;

        throw new ArgumentException(_socialAccountLimitError);
    }

    bool IPlanRuleValidator.CanAddManager(UserAccount? user)
    {
        if (user is null)
            throw new ArgumentException(_userNotFoundError);

        var plan = user.Plan;
        var status = user.SubscriptionStatus;
        var managerCount = user.Managers.Where(m => m.IsActive).Count();

        if (!packageRules.TryGetValue(plan, out var planRule))
            throw new ArgumentException($"{_unrecognizedPlan} {plan.ToString()}");

        if (status != SubscriptionStatus.active && status != SubscriptionStatus.trialing)
            throw new ArgumentException($"{_subscriptionStatusError} {status.ToString()}");

        if(managerCount < packageRules[plan].MaxManagers)
            return true;

        throw new ArgumentException(_managerLimitError);
    }

    bool IPlanRuleValidator.CanGenerateAiContent(UserAccount? user)
    {
        if (user is null)
            throw new ArgumentException(_userNotFoundError);

        var plan = user.Plan;
        var status = user.SubscriptionStatus;

        if (!packageRules.TryGetValue(plan, out var planRule))
            throw new ArgumentException($"{_unrecognizedPlan} {plan.ToString()}");

        if (status != SubscriptionStatus.active && status != SubscriptionStatus.trialing)
            throw new ArgumentException($"{_subscriptionStatusError} {status.ToString()}");

        if (packageRules[plan].IsAiAllowed)
            return true;

        throw new ArgumentException(_aiNotAllowedError);
    }

    bool IPlanRuleValidator.CanQueuePost(UserAccount? user)
    {
        if (user is null)
            throw new ArgumentException(_userNotFoundError);

        var plan = user.Plan;
        var status = user.SubscriptionStatus;

        if (!packageRules.TryGetValue(plan, out var planRule))
            throw new ArgumentException($"{_unrecognizedPlan} {plan.ToString()}");

        if (status != SubscriptionStatus.active && status != SubscriptionStatus.trialing)
            throw new ArgumentException($"{_subscriptionStatusError} {status.ToString()}");

        if (packageRules[plan].IsQueueAllowed)
            return true;

        throw new ArgumentException(_queueNotAllowedError);
    }

    bool IPlanRuleValidator.IsSubscriptionValid(UserAccount? user, bool isManager)
    {
        if(user is null)
            throw new ArgumentException(_userNotFoundError);

        var status = user.SubscriptionStatus;

        if (isManager && user.Plan != Plan.Enterprise)
            throw new ArgumentException($"{_managerNotAllowedError} {user.Plan.ToString()} Plan");

        if(status == SubscriptionStatus.active || status == SubscriptionStatus.trialing)
            return true;

        throw new ArgumentException($"{_subscriptionStatusError} {status.ToString()}");
    }
}

