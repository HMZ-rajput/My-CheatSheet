﻿using MarketPro.Application;
using MarketPro.Identity.Entities;
using MarketPro.Payments.DTOs;
using MarketPro.UserAccounts.Entities;
using Microsoft.AspNetCore.Identity;
using Stripe;

namespace MarketPro.Services;

public class PaymentService : IPaymentService
{
    private const int _trialPeriodDays = 7; // Number of trial days.
    private const string _trialing = "trialing";
    private const string _active = "active";
    private const string _latestInvoice = "latest_invoice";
    private const string _paymentIntent = "payment_intent";
    private const string _couldNotRetreiveAnyProductsError = "Couldn't retreive any products.";
    private const string _userAlreadyExistsError = "User already exists!.";

    private readonly UserManager<ApplicationUser> _userManager;

    public PaymentService(UserManager<ApplicationUser> userManager)
    {
        StripeConfiguration.ApiKey = AppEnvironment.StripeTestKey;
        _userManager = userManager ?? throw new ArgumentNullException(nameof(userManager));
    }

    async ValueTask<GetClientKeyResponse> IPaymentService.CreateIntentAndGetKeyAsync(CreateIntentAndGetKeyRequest request)
    {
        string? customerId = null;
        var response = new GetClientKeyResponse();

        if (!request.IsUpdate)
        {
            var user = await _userManager.FindByEmailAsync(request.Email).ConfigureAwait(false);

            if (user is not null)
            {
                response.AddError(_userAlreadyExistsError);
                return response;
            }
        }

        var customerService = new CustomerService();

        var stripeExsitingCustomers = await customerService.ListAsync(new CustomerListOptions()
        {
            Email = request.Email,
        });

        if (stripeExsitingCustomers.Data.Count > 0)
        {
            customerId = stripeExsitingCustomers.Data[0].Id;
        }
        else if (!request.IsUpdate)
        {
            var options = new CustomerCreateOptions
            {
                Name = request.FullName,
                Email = request.Email
            };

            var customer = customerService.Create(options);
            customerId = customer.Id;
        }

        var setupIntentOptions = new SetupIntentCreateOptions
        {
            Customer = customerId,
            PaymentMethodTypes = ["card"]
        };

        var setupIntentService = new SetupIntentService();
        var setupIntent = setupIntentService.Create(setupIntentOptions);

        response.Key = setupIntent.ClientSecret;
        response.CustomerId = customerId ?? string.Empty;
        return response;
    }

    async ValueTask<GetRegisteredUserResponse> IPaymentService.RegisterSubscriptionAsync(UserRegistrationRequest request)
    {
        var response = new GetRegisteredUserResponse();
        ProductService productService = new();
        StripeList<Product> products = productService.List();
        var product = products.FirstOrDefault(x => x.Name == request.Plan.ToString()) ?? throw new Exception(_couldNotRetreiveAnyProductsError);
        var subscriptionOptions = new SubscriptionCreateOptions
        {
            Customer = request.CustomerId,
            Items = new List<SubscriptionItemOptions>
            {
                new SubscriptionItemOptions
                {
                    Plan = product.DefaultPriceId,
                },
            },
            TrialPeriodDays = _trialPeriodDays,
            Expand = new List<string> { $"{_latestInvoice}.{_paymentIntent}" },
            DefaultPaymentMethod = request.PaymentMethod,
        };
        var subscriptionService = new SubscriptionService();

        CustomerService customerService = new CustomerService();
        var test = customerService.Get(request.CustomerId);

        var subscription = await subscriptionService.CreateAsync(subscriptionOptions);

        if (subscription.Status == _active || subscription.Status == _trialing)
        {
            response.Stripe = new StripeDetails
            {
                StripeCustomerId = request.CustomerId,
                SubscriptionId = subscription.Id,
                SubscriptionStatus = subscription.Status
            };
        }

        return response;
    }

    async ValueTask<GetRegisteredUserResponse> IPaymentService.UpdateSubscriptionAsync(string subscriptionId, UserAccounts.Entities.Plan plan)
    {
        var response = new GetRegisteredUserResponse();

        ProductService productService = new();
        StripeList<Product> products = productService.List();
        var product = products.FirstOrDefault(x => x.Name == plan.ToString()) ?? throw new Exception(_couldNotRetreiveAnyProductsError);

        var service = new SubscriptionService();

        var subscription = service.Get(subscriptionId);

        if (subscription.Status == SubscriptionStatus.canceled.ToString())
        {
            var subscriptionOptions = new SubscriptionCreateOptions
            {
                Customer = subscription.CustomerId,
                Items = new List<SubscriptionItemOptions>
                {
                    new SubscriptionItemOptions
                    {
                        Plan = product.DefaultPriceId,
                    },
                },
                DefaultPaymentMethod = subscription.DefaultPaymentMethodId,//
            };

            subscription = await service.CreateAsync(subscriptionOptions);
        }
        else
        {
            var subscriptionUpdateOptions = new SubscriptionUpdateOptions
            {
                Items = new List<SubscriptionItemOptions>
                {
                    new SubscriptionItemOptions { Id = subscription.Items.Data[0].Id, Deleted = true },
                    new SubscriptionItemOptions { Plan = product.DefaultPriceId },
                },
                CancelAtPeriodEnd = true,
            };

            subscription = await service.UpdateAsync(subscriptionId, subscriptionUpdateOptions).ConfigureAwait(false);
        }

        response.Stripe = new StripeDetails
        {
            StripeCustomerId = subscription.CustomerId,
            SubscriptionId = subscription.Id,
            SubscriptionStatus = subscription.Status
        };

        return response;
    }

    async ValueTask<GetRegisteredUserResponse> IPaymentService.UpdatePaymentMethodAsync(string subscriptionId, string paymentId)
    {
        var response = new GetRegisteredUserResponse();

        var service = new SubscriptionService();
        var paymentService = new PaymentMethodService();

        var subscription = service.Get(subscriptionId);

        if (subscription.Status == SubscriptionStatus.canceled.ToString())
            return response;

        var customerPaymentMethod = paymentService.Get(paymentId);

        if (customerPaymentMethod.CustomerId != subscription.CustomerId)
            return response;

        if (subscription.DefaultPaymentMethodId != paymentId && subscription.DefaultPaymentMethodId != null)
        {
            paymentService.Detach(subscription.DefaultPaymentMethodId);
        }

        var paymentOptions = new PaymentMethodAttachOptions { Customer = subscription.CustomerId };
        paymentService.Attach(paymentId, paymentOptions);


        var subscriptionUpdateOptions = new SubscriptionUpdateOptions { DefaultPaymentMethod = paymentId };

        subscription = await service.UpdateAsync(subscriptionId, subscriptionUpdateOptions).ConfigureAwait(false);

        response.Stripe = new StripeDetails
        {
            StripeCustomerId = subscription.CustomerId,
            SubscriptionId = subscription.Id,
            SubscriptionStatus = subscription.Status
        };

        return response;
    }

    async ValueTask<GetRegisteredUserResponse> IPaymentService.CancelSubscriptionAsync(string subscriptionId)
    {
        var response = new GetRegisteredUserResponse();

        var service = new SubscriptionService();

        var subscription = service.Get(subscriptionId);//

        var subscriptionUpdateOptions = new SubscriptionUpdateOptions { DefaultPaymentMethod = subscription.DefaultPaymentMethodId };//

        subscription = await service.UpdateAsync(subscriptionId, subscriptionUpdateOptions).ConfigureAwait(false);//

        var subsrciption = await service.CancelAsync(subscriptionId).ConfigureAwait(false);

        response.Stripe = new StripeDetails
        {
            StripeCustomerId = subsrciption.CustomerId,
            SubscriptionId = subsrciption.Id,
            SubscriptionStatus = subsrciption.Status
        };

        return response;
    }

    async ValueTask<IList<InvoiceDTO>> IPaymentService.GetAllInvoiceAsync(string customerId, StripePaginationDTO pagination)
    {
        IList<InvoiceDTO> invoices = [];

        var invoiceOptions = new InvoiceListOptions
        {
            Limit = pagination.PageSize,
            StartingAfter = pagination.StartingAfter,
            EndingBefore = pagination.StartingBefore,
            Customer = customerId,
        };
        var invoiceService = new InvoiceService();

        StripeList<Invoice> stripeInvoices = await invoiceService.ListAsync(invoiceOptions).ConfigureAwait(false);

        if (pagination.StartingAfter is not null)
        {
            pagination.HasPrevious = true;
            pagination.HasNext = stripeInvoices.HasMore;
        }
        else if (pagination.StartingBefore is not null)
        {
            pagination.HasNext = true;
            pagination.HasPrevious = stripeInvoices.HasMore;
        }
        else
            pagination.HasNext = stripeInvoices.HasMore;


        if (stripeInvoices.Count() == 0)
            return invoices;

        invoices = stripeInvoices.Select(x => MapInvoice(x)).ToList();

        return invoices;
    }

    async ValueTask<IList<PlanDTO>> IPaymentService.GetAllPlansAsync()
    {
        var response = new List<PlanDTO>();

        var productOptions = new ProductListOptions
        {
            Active = true,
            Expand = new List<string> { "data.default_price" },
        };
        var productService = new ProductService();
        StripeList<Product> products = await productService.ListAsync(productOptions).ConfigureAwait(false);

        foreach (var product in products)
        {
            var subscription = new PlanDTO
            {
                ProductId = product.Id,
                PlanId = product.DefaultPriceId,
                Price = product.DefaultPrice is not null && product.DefaultPrice.UnitAmountDecimal is not null ? (decimal)product.DefaultPrice.UnitAmountDecimal / 100 : 0,
                Duration = product.DefaultPrice is not null ? product.DefaultPrice.Recurring.Interval : "",
                Name = product.Name,
                Plan = MapNameToPlan(product.Name),
                Features = product.MarketingFeatures.Select(x => x.Name).ToList(),
            };

            response.Add(subscription);
        }

        return response;
    }

    async ValueTask<PlanDTO?> IPaymentService.GetPlanAsync(UserAccounts.Entities.Plan plan)
    {
        var productOptions = new ProductListOptions
        {
            Active = true,
            Expand = new List<string> { "data.default_price" },
        };
        var productService = new ProductService();
        StripeList<Product> products = await productService.ListAsync(productOptions).ConfigureAwait(false);

        var product = products.FirstOrDefault(x => MapNameToPlan(x.Name) == plan);

        if (product is null || product.DefaultPrice == null)
            return null;

        var response = new PlanDTO
        {
            ProductId = product.Id,
            PlanId = product.DefaultPrice.Id,
            Price = product.DefaultPrice is not null && product.DefaultPrice.UnitAmountDecimal is not null ? (decimal)product.DefaultPrice.UnitAmountDecimal / 100 : 0,
            Duration = product.DefaultPrice!.Recurring?.Interval ?? "",
            Name = product.Name,
            Plan = MapNameToPlan(product.Name),
            Features = product.MarketingFeatures.Select(x => x.Name).ToList(),
        };

        return response;
    }

    SubscriptionStatus IPaymentService.MapSubscriptionStatusToEnum(string subscriptionStatus)
    {
        switch (subscriptionStatus)
        {
            case "trialing":
                return SubscriptionStatus.trialing;
            case "active":
                return SubscriptionStatus.active;
            case "past_due":
                return SubscriptionStatus.past_due;
            case "canceled":
                return SubscriptionStatus.canceled;
            case "unpaid":
                return SubscriptionStatus.unpaid;
            case "incomplete":
                return SubscriptionStatus.incomplete;
            case "incomplete_expired":
                return SubscriptionStatus.incomplete_expired;
            default:
                return SubscriptionStatus.paused;
        }
    }

    private static InvoiceDTO MapInvoice(Invoice invoice)
    {
        return new InvoiceDTO
        {
            Id = invoice.Id,
            Description = invoice.Lines.Select(i => i.Description).ToList(),
            Date = invoice.Created,
            Amount = (decimal)invoice.Total / 100,
            Status = MapInvoiceStatus(invoice.Status),
            ViewURL = invoice.HostedInvoiceUrl,
            DownloadURL = invoice.InvoicePdf,
        };
    }

    private static InvoiceStatus MapInvoiceStatus(string invoiceStatus)
    {
        switch (invoiceStatus)
        {
            case "draft":
                return InvoiceStatus.draft;
            case "open":
                return InvoiceStatus.open;
            case "paid":
                return InvoiceStatus.paid;
            case "uncollectible":
                return InvoiceStatus.uncollectible;
            default:
                return InvoiceStatus.empty;
        }
    }

    private UserAccounts.Entities.Plan MapNameToPlan(string name)
    {
        switch (name)
        {
            case "Enterprise":
                return UserAccounts.Entities.Plan.Enterprise;
            case "Pro":
                return UserAccounts.Entities.Plan.Pro;
            default:
                return UserAccounts.Entities.Plan.Basic;
        }
    }

}