﻿using MarketPro.UserAccounts.Entities;

namespace MarketPro.Services;

public interface IPlanRuleValidator
{
    bool CanConnectSocialAccount(UserAccount user);
    bool CanAddManager(UserAccount user);
    bool IsSubscriptionValid(UserAccount? user, bool isManager);
    bool CanGenerateAiContent(UserAccount? user);
    bool CanQueuePost(UserAccount? user);
}
