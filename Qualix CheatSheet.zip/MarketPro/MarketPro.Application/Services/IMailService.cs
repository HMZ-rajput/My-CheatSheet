﻿
namespace MarketPro.Services;
public interface IMailService
{
    ValueTask<bool> SendEmailAsync(string toEmailAddress, string subject, string body);
}
