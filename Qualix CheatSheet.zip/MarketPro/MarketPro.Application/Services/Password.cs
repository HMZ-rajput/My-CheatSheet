﻿using System.Security.Cryptography;

namespace MarketPro.Services;

public static class Password
{
    private static readonly char[] _punctuations = "!@#$%^&*()_-+=[{]};:>|./?".ToCharArray();

    public static string Generate(int length, int numberOfNonAlphanumericCharacters)
    {
        if (length < 1 || length > 128)
        {
            throw new ArgumentException("Invalid Password Length");
        }

        if (numberOfNonAlphanumericCharacters > length || numberOfNonAlphanumericCharacters < 0)
        {
            throw new ArgumentException("Invalid Non-AlphaNumeric Character Length");
        }

        using (var rng = RandomNumberGenerator.Create())
        {
            var byteBuffer = new byte[length];

            rng.GetBytes(byteBuffer);

            var count = 0;
            var characterBuffer = new char[length];

            for (var iter = 0; iter < length; iter++)
            {
                var i = byteBuffer[iter] % 87;

                if (i < 10)
                {
                    characterBuffer[iter] = (char)('0' + i);
                }
                else if (i < 36)
                {
                    characterBuffer[iter] = (char)('A' + i - 10);
                }
                else if (i < 62)
                {
                    characterBuffer[iter] = (char)('a' + i - 36);
                }
                else
                {
                    characterBuffer[iter] = _punctuations[i - 62];
                    count++;
                }
            }

            var rand = new Random();
            var randomDigit = rand.Next(0,9);

            if (count >= numberOfNonAlphanumericCharacters)
            {
                return new string(characterBuffer) + randomDigit;
            }

            int j;

            for (j = 0; j < numberOfNonAlphanumericCharacters - count; j++)
            {
                int k;
                do
                {
                    k = rand.Next(0, length);
                }
                while (!char.IsLetterOrDigit(characterBuffer[k]));

                characterBuffer[k] = _punctuations[rand.Next(0, _punctuations.Length)];
            }

            var newPassword = new string(characterBuffer) + randomDigit;

            return newPassword;
        }
    }
}