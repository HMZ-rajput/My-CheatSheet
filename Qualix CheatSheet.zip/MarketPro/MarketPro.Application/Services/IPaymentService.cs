﻿using MarketPro.Payments.DTOs;
using MarketPro.UserAccounts.Entities;

namespace MarketPro.Services;

public interface IPaymentService
{
    ValueTask<GetClientKeyResponse> CreateIntentAndGetKeyAsync(CreateIntentAndGetKeyRequest request);
    ValueTask<GetRegisteredUserResponse> RegisterSubscriptionAsync(UserRegistrationRequest request);
    ValueTask<GetRegisteredUserResponse> UpdateSubscriptionAsync(string subscriptionId, Plan plan);
    ValueTask<GetRegisteredUserResponse> UpdatePaymentMethodAsync(string subscriptionId, string paymentId);
    ValueTask<GetRegisteredUserResponse> CancelSubscriptionAsync(string subscriptionId);
    ValueTask<IList<InvoiceDTO>> GetAllInvoiceAsync(string customerId, StripePaginationDTO pagination);
    ValueTask<IList<PlanDTO>> GetAllPlansAsync();
    ValueTask<PlanDTO?> GetPlanAsync(Plan plan);
    SubscriptionStatus MapSubscriptionStatusToEnum(string subscriptionStatus);
}
