﻿using MarketPro.Facebook.DTOs;
using MarketPro.Instagram.DTOs;
using MarketPro.LinkedIn.DTOs;

namespace MarketPro.Services;

public interface IInstagramService
{
    public ValueTask<InstagramAccessTokenResponse?> GetAccessTokenAsync(string authorizationCode, bool isConnect);
    public ValueTask<IdResponse?> PostContantAsync(string accessToken, string userId, IList<string> imageUrls, string caption);
    public ValueTask<GetUserProfileResponse> GetUserProfileAsync(string? accessToken);
    public ValueTask<GetStatisticsResponse> GetStatisticsAsync(string? userAccessToken, string userId);
}