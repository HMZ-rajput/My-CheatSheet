﻿using MarketPro.OpenAi.DTOs;

namespace MarketPro.Services;

public interface IOpenAiService
{
    public ValueTask<GenerateContentResponse> GenerateContentAsync(string prompt, List<string>? userTones = null, List<string>? keywords = null, string? businessDescription = null, string targetAudience = null);
    public ValueTask<GenerateImageResponse> GenerateImageAsync(string prompt);
}