﻿using MarketPro.Facebook.DTOs;
using MarketPro.LinkedIn.DTOs;
using Microsoft.AspNetCore.Http;

namespace MarketPro.Services;

public interface IFacebookService
{
    public ValueTask<FacebookAccessTokenResponse> GetAccessTokenAsync(string authorizationCode, bool isConnect);
    public ValueTask<IdResponse?> PostToPageAsync(string accessToken, IList<IFormFile> images, IList<string> imagesUrl, string pageId, string postText);
    public ValueTask<GetUserProfileResponse> GetUserProfileAsync(string? accessToken);
    public ValueTask<GetFacebookPageDetailsResponse> GetPagesDetailsAsync(string? accessToken, string userId);
    public ValueTask<GetStatisticsResponse> GetStatisticsAsync(string? pageAccessToken, string pageId);
}