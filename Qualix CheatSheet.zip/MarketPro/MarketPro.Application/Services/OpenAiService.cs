﻿using MarketPro.OpenAi.DTOs;
using Rystem.OpenAi;
using Rystem.OpenAi.Image;
using System.Text.Json.Serialization;

namespace MarketPro.Services;

public class OpenAiService : IOpenAiService
{
    private const string _openAiError = "OpenAi Error:";
    private const string _contentModel = "gpt-4o";
    private const string _imageModel = "dall-e-3";
    private const int _maxTokens = 250;
    private const float _temperature = 0.7f;
    private const int _maxImages = 1;

    private readonly IOpenAiFactory _openAiFactory;

    public OpenAiService(IOpenAiFactory openAiFactory)
    {
        _openAiFactory = openAiFactory ?? throw new ArgumentNullException(nameof(openAiFactory));
    }

    async ValueTask<GenerateContentResponse> IOpenAiService.GenerateContentAsync(string prompt, List<string>? userTones, List<string>? keywords, string? businessDescription, string? targetAudience)
    {
        var response = new GenerateContentResponse();
        var toneList = new List<string> { "professional", "friendly", "enthusiastic" }
            .Concat(userTones ?? new List<string>())
            .Distinct()
            .ToList();
        var keywordList = keywords ?? new List<string>();

        try
        {
            var chatResponse = await _openAiFactory.CreateChat()
                .RequestWithUserMessage(prompt)
                .WithModel(_contentModel)
                .WithTemperature(_temperature)
                .SetMaxTokens(_maxTokens)
                .WithFunction(new JsonFunction
                {
                    Name = "get_current_time",
                    Description = "Get the current weather in a given location",
                    Parameters = new JsonFunctionNonPrimitiveProperty()
                    .AddPrimitive("location", new JsonFunctionProperty
                    {
                        Type = "string",
                        Description = "The city and state, e.g. San Francisco, CA"
                    })
                    .AddEnum("unit", new JsonFunctionEnumProperty
                    {
                        Type = "string",
                        Enums = new List<string> { "celsius", "fahrenheit" }
                    })
                    .AddRequired("location")
                })
                .ExecuteAsync();
            var result = chatResponse?
                .Choices?
                .FirstOrDefault()?
                .Message?
                .Content?
                .ToString();

            response.Content = result;
            return response;
        }
        catch (Exception ex)
        {
            var error = $"{_openAiError} {ex.Message}";
            response.AddError(error);
            return response;
        }
    }

    async ValueTask<GenerateImageResponse> IOpenAiService.GenerateImageAsync(string prompt)
    {
        var response = new GenerateImageResponse();
        try
        {
            var promptInSpecificLanguage = prompt;
            var imageResponse = await _openAiFactory.Create()
                .Image
                .Generate(promptInSpecificLanguage)
                .WithSize(ImageSize.Large)
                .WithNumberOfResults(_maxImages)
                .ExecuteAsync();
            var result = imageResponse?
                .Data?
                .Select(data => data.Url)
                .ToList();

            response.Urls = result;
            return response;
        }
        catch (Exception ex)
        {
            var error = $"{_openAiError} {ex.Message}";
            response.AddError(error);
            return response;
        }
    }

}