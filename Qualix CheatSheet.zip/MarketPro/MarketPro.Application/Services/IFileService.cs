﻿using Microsoft.AspNetCore.Http;

namespace MarketPro.Services;

public interface IFileService
{
    ValueTask<(string fileName, string filePath)> UploadFileAndGetNewFileNameAndPath(IFormFile file, string fileName, IList<string>? fileNames);
    bool DeleteUploadedFile(string filePath);
    string GetFileURL(string fileName);
    string GetUploadDirectoryPath();
    ValueTask<byte[]> DownloadImageAsByteArrayAsync(string imageUrl);
    (string? newFileName, string? destinationFilePath) DuplicateFileAndGetNewFileNameAndPath(string fileName, IList<string>? fileNames);

    ValueTask<(string fileName, string filePath)> UploadFileFromUrlAndGetNewFileNameAndPath(string imageUrl, IList<string>? fileNames);

}
