﻿using MarketPro.Application;
using MarketPro.Facebook.DTOs;
using MarketPro.Instagram.DTOs;
using MarketPro.LinkedIn.DTOs;
using MarketPro.SocialAccounts.DTOs;
using System.Net.Mime;
using System.Text;
using System.Text.Json.Nodes;
using NSJ = Newtonsoft.Json;

namespace MarketPro.Services;

public class InstagramService : IInstagramService
{
    private const string _baseUrl = "https://api.facebook.com";
    private const string _graphBaseUrl = "https://graph.facebook.com";
    private const string _apiVersion = "v20.0";
    private const string _grantTypeAuthorizationCode = "authorization_code";
    private const string _grantTypeIgExchangeToken = "ig_exchange_token";
    private const string _unableToConnectInstagram = "Unable to connect to Instagram.";
    private const string _instagramAuthCodeExpired = "Instagram auth code expired.";
    private const string _instagramErrorUnauthorized = "Instagram Unauthorized access.";
    private const string _instagramAccessToken = "Instagram revoked access token.";
    private const string _instagramAccessDenied = "Instagram access denied.";
    private const string _instagramServiceError = "Instagram service error.";
    private const string _postSuccessfullyPublished = "Post successfully published!";
    private const string _id = "id";
    private const string _userId = "user_id";
    private const string _username = "username";
    private const string _name = "name";
    private const string _profilePictureUrl = "profile_picture_url";

    private readonly string _clientId;
    private readonly string _clientSecret;
    private readonly HttpClient _httpClient;

    public InstagramService(HttpClient httpClient)
    {
        _httpClient = httpClient ?? throw new ArgumentNullException(nameof(httpClient));
        _clientId = AppEnvironment.InstagramClientId;
        _clientSecret = AppEnvironment.InstagramClientSecret;
    }

    async ValueTask<InstagramAccessTokenResponse?> IInstagramService.GetAccessTokenAsync(string authorizationCode, bool isConnect)
    {
        var response = new InstagramAccessTokenResponse();
        try
        {
            string redirectUri = isConnect ? AppEnvironment.InstagramRedirectUriConnect : AppEnvironment.InstagramRedirectUriSignup;
            string uri = $"{_baseUrl}/oauth/access_token";
            using var multipartFormData = new MultipartFormDataContent();
            multipartFormData.Add(new StringContent(_clientId, Encoding.UTF8, MediaTypeNames.Text.Plain), "client_id");
            multipartFormData.Add(new StringContent(_clientSecret, Encoding.UTF8, MediaTypeNames.Text.Plain), "client_secret");
            multipartFormData.Add(new StringContent(_grantTypeAuthorizationCode, Encoding.UTF8, MediaTypeNames.Text.Plain), "grant_type");
            multipartFormData.Add(new StringContent(redirectUri, Encoding.UTF8, MediaTypeNames.Text.Plain), "redirect_uri");
            multipartFormData.Add(new StringContent(authorizationCode, Encoding.UTF8, MediaTypeNames.Text.Plain), "code");

            using var httpClientResponse = await _httpClient.PostAsync(uri, multipartFormData);
            var jsonString = await httpClientResponse.Content.ReadAsStringAsync();
            var deserializeResponse = NSJ.JsonConvert.DeserializeObject<InstagramShortLivedAccessTokenResponse>(jsonString);

            if (deserializeResponse is null)
            {
                var error = NSJ.JsonConvert.DeserializeObject<MetaError>(jsonString);
                response.AddError(error?.Error?.Message ?? _unableToConnectInstagram);
                return response;
            }

            return await GetLongLivedAccessTokenAsync(deserializeResponse).ConfigureAwait(false);
        }
        catch (Exception ex)
        {
            {
                var error = NSJ.JsonConvert.DeserializeObject<MetaError>(ex.Message);
                response.AddError(error?.Error?.Message ?? ex.Message);
                return response;
            }
        }
    }

    async ValueTask<IdResponse?> IInstagramService.PostContantAsync(string accessToken, string userId, IList<string> imageUrls, string caption)
    {
        var response = new IdResponse();
        try
        {
            string carouselMediaContainerIds = string.Empty;

            if (imageUrls.Count == 0)
                return null;

            if (imageUrls.Count > 1)
            {
                foreach (var imageUrl in imageUrls)
                {
                    var carouselMediaContainerId = await CreateCarouselMediaContainerAsync(accessToken, userId, imageUrl).ConfigureAwait(false);

                    if (carouselMediaContainerId is not null && carouselMediaContainerId.Id is not null)
                    {
                        carouselMediaContainerIds += string.IsNullOrEmpty(carouselMediaContainerIds) ? carouselMediaContainerId.Id : "," + carouselMediaContainerId.Id;
                    }
                }
            }

            var creationId = await CreateCarouselContainerAsync(accessToken, userId, caption, carouselMediaContainerIds, imageUrls[0], imageUrls.Count == 1).ConfigureAwait(false);

            if (creationId is null || creationId.Id is null)
                return null;

            response = await PublishCarouselContainerAsync(accessToken, userId, creationId.Id).ConfigureAwait(false);

            return response;

        }
        catch (Exception ex)
        {
            var error = NSJ.JsonConvert.DeserializeObject<MetaError>(ex.Message);
            response?.AddError(error?.Error?.Message ?? ex.Message);
            return response;
        }

    }

    async ValueTask<GetUserProfileResponse> IInstagramService.GetUserProfileAsync(string? accessToken)
    {
        var response = new GetUserProfileResponse();
        try
        {
            var headers = new Dictionary<string, string>
        {
            { "Authorization", $"Bearer {accessToken}" }
        };
            var uri = $"{_graphBaseUrl}/{_apiVersion}/me?fields=id,user_id,username,name,profile_picture_url";
            var httpResponse = await HTTPGetAsync(uri, headers)
                .ConfigureAwait(false);

            if (httpResponse.IsSuccess && httpResponse.HttpResponseMessage is not null)
            {
                var jsonString = await httpResponse.HttpResponseMessage.Content.ReadAsStringAsync().ConfigureAwait(false);
                var extractedValues = ExtractUserProfileValues(jsonString);
                if (extractedValues is not null)
                {
                    response.UserProfile = new UserProfileResponse
                    {
                        SocialAccountId = extractedValues[_id].ToString(),
                        VanityName = extractedValues[_username].ToString(),
                        FirstName = extractedValues[_name].ToString(),
                        ProfilePicture = extractedValues[_profilePictureUrl].ToString()
                    };
                    return response;
                }
            }

            httpResponse.Errors.ForEach(response.AddError);
            return response;
        }
        catch (Exception ex)
        {
            var error = NSJ.JsonConvert.DeserializeObject<MetaError>(ex.Message);
            response.AddError(error?.Error?.Message ?? ex.Message);
            return response;
        }
    }

    async ValueTask<GetStatisticsResponse> IInstagramService.GetStatisticsAsync(string? userAccessToken, string userId)
    {
        var response = new GetStatisticsResponse();
        var insightsResponse = await GetPageInsightsAsync(userAccessToken, userId).ConfigureAwait(false);
        response.Statistic = CalculateStatistics(insightsResponse.Insights);
        return response;
    }

    private async ValueTask<PageInsightsResponse> GetPageInsightsAsync(string? userAccessToken, string userId)
    {
        var response = new PageInsightsResponse();
        try
        {
            var endDate = DateTimeOffset.UtcNow.AddDays(-1);
            var startDate = endDate.AddDays(-7);
            var url = $"{_graphBaseUrl}/{_apiVersion}/{userId}/insights?metric=impressions,reach&since={startDate.ToUnixTimeSeconds()}&until={endDate.ToUnixTimeSeconds()}&period={InsightsPeriod.week.ToString()}&access_token={userAccessToken}";
            using var request = new HttpRequestMessage(HttpMethod.Get, url);
            var httpResponse = await _httpClient.SendAsync(request);

            if (!httpResponse.IsSuccessStatusCode)
            {
                response.AddError(_instagramServiceError);
                return response;
            }

            var responseBody = await httpResponse.Content.ReadAsStringAsync().ConfigureAwait(false);
            var deserializeResponse = NSJ.JsonConvert.DeserializeObject<PageInsights>(responseBody);

            if (deserializeResponse is null)
            {
                var error = NSJ.JsonConvert.DeserializeObject<MetaError>(responseBody);
                response.AddError(error?.Error?.Message ?? _instagramServiceError);
                return response;
            }

            response.Insights = deserializeResponse;
            return response;
        }
        catch (Exception ex)
        {
            var error = NSJ.JsonConvert.DeserializeObject<MetaError>(ex.Message);
            response.AddError(error?.Error?.Message ?? ex.Message);
            return response;
        }
    }

    private StatisticsResponse CalculateStatistics(PageInsights? pageInsights)
    {
        var response = new StatisticsResponse();

        if (pageInsights is not null)
        {
            foreach (var insightData in pageInsights.Data)
            {
                var (sum, xAxis, yAxis) = CalculateMetrics(insightData.Values);
                switch (insightData.Name)
                {
                    case "impressions":
                        response.TotalAudience.Total += sum;
                        response.TotalAudience.YAxis.AddRange(yAxis);
                        response.TotalAudience.XAxis.AddRange(xAxis);
                        break;

                    case "reach":
                        response.TotalImpression.Total += sum;
                        response.TotalImpression.YAxis.AddRange(yAxis);
                        response.TotalImpression.XAxis.AddRange(xAxis);
                        break;

                    default:
                        break;
                }
            }
        }

        return response;
    }

    private (int sum, IList<int> xAxis, IList<DateTime> yAxis) CalculateMetrics(IList<InsightValue> values)
    {
        int sum = 0;
        IList<int> xAxis = [];
        IList<DateTime> yAxis = [];
        foreach (var value in values)
        {
            sum += value.Value;
            xAxis.Add(value.Value);
            yAxis.Add(value.EndTime);
        }
        return (sum, xAxis, yAxis);
    }

    private async ValueTask<InstagramAccessTokenResponse> GetLongLivedAccessTokenAsync(InstagramShortLivedAccessTokenResponse shortLivedToken)
    {
        InstagramAccessTokenResponse response = new InstagramAccessTokenResponse();
        try
        {
            var queryParams = new Dictionary<string, string>
        {
            { "grant_type", _grantTypeIgExchangeToken},
            { "client_secret", _clientSecret },
            { "access_token", $"{shortLivedToken.Accesstoken}"}
        };
            var queryString = new FormUrlEncodedContent(queryParams).ReadAsStringAsync().Result;
            var uri = $"{_graphBaseUrl}/{_apiVersion}/access_token?{queryString}";
            var httpClientResponse = await HTTPGetAsync(uri).ConfigureAwait(false);

            if (httpClientResponse.IsSuccess && httpClientResponse.HttpResponseMessage is not null)
            {
                var jsonString = await httpClientResponse.HttpResponseMessage.Content.ReadAsStringAsync();
                var deserializeResponse = Newtonsoft.Json.JsonConvert.DeserializeObject<InstagramAccessToken>(jsonString);

                if (deserializeResponse is null)
                {
                    var error = NSJ.JsonConvert.DeserializeObject<MetaError>(jsonString);
                    response.AddError(error?.Error?.Message ?? _unableToConnectInstagram);
                    return response;
                }

                deserializeResponse.Permissions = shortLivedToken.Permissions;
                deserializeResponse.UserId = shortLivedToken.UserId;

                response.InstagramAccessToken = deserializeResponse;
                return response;
            }

            httpClientResponse.Errors.ForEach(response.AddError);
            return response;
        }
        catch (Exception ex)
        {
            var serviceError = $"{_instagramServiceError} {ex.Message}";
            var error = NSJ.JsonConvert.DeserializeObject<MetaError>(ex.Message);
            response.AddError(error?.Error?.Message ?? serviceError);
            return response;
        }
    }

    private async ValueTask<IdResponse?> CreateCarouselMediaContainerAsync(string accessToken, string userId, string imageUrl)
    {
        try
        {
            var url = $"{_graphBaseUrl}/{_apiVersion}/{userId}/media";

            var content = new StringContent(System.Text.Json.JsonSerializer.Serialize(new
            {
                image_url = imageUrl,
                is_carousel_item = true
            }), Encoding.UTF8, "application/json");

            using var request = new HttpRequestMessage(HttpMethod.Post, url)
            {
                Content = content
            };

            request.Headers.Add("Authorization", $"Bearer {accessToken}");
            var httpClientResponse = await _httpClient.SendAsync(request);
            var jsonString = await httpClientResponse.Content.ReadAsStringAsync().ConfigureAwait(false);

            if (httpClientResponse.IsSuccessStatusCode)
            {
                var deserializeResponse = NSJ.JsonConvert.DeserializeObject<IdResponse>(jsonString);

                return deserializeResponse;
            }

            return null;
        }
        catch (Exception)
        {
            return null;
        }
    }

    private async ValueTask<IdResponse?> CreateCarouselContainerAsync(string accessToken, string userId, string? caption, string? carouselMediaContainerIds, string? imageUrl, bool isImage)
    {
        try
        {
            var url = $"{_graphBaseUrl}/{_apiVersion}/{userId}/media";

            var content = new StringContent(System.Text.Json.JsonSerializer.Serialize(new
            {
                caption = $"{caption}",
                media_type = isImage ? MediaType.IMAGE.ToString() : MediaType.CAROUSEL.ToString(),
                image_url = imageUrl,
                children = carouselMediaContainerIds
            }), Encoding.UTF8, "application/json");

            using var request = new HttpRequestMessage(HttpMethod.Post, url)
            {
                Content = content
            };

            request.Headers.Add("Authorization", $"Bearer {accessToken}");
            var httpClientResponse = await _httpClient.SendAsync(request);
            var jsonString = await httpClientResponse.Content.ReadAsStringAsync().ConfigureAwait(false);

            if (httpClientResponse.IsSuccessStatusCode)
            {
                var deserializeResponse = NSJ.JsonConvert.DeserializeObject<IdResponse>(jsonString);

                return deserializeResponse;
            }

            return null;
        }
        catch (Exception)
        {
            return null;
        }
    }

    private async ValueTask<IdResponse?> PublishCarouselContainerAsync(string accessToken, string userId, string creationId)
    {
        var response = new IdResponse();
        try
        {
            var url = $"{_graphBaseUrl}/{_apiVersion}/{userId}/media_publish";

            var content = new StringContent(System.Text.Json.JsonSerializer.Serialize(new
            {
                creation_id = creationId,
            }), Encoding.UTF8, "application/json");

            using var request = new HttpRequestMessage(HttpMethod.Post, url)
            {
                Content = content
            };

            request.Headers.Add("Authorization", $"Bearer {accessToken}");
            var httpClientResponse = await _httpClient.SendAsync(request);
            var jsonString = await httpClientResponse.Content.ReadAsStringAsync().ConfigureAwait(false);

            if (httpClientResponse.IsSuccessStatusCode)
            {
                var deserializeResponse = NSJ.JsonConvert.DeserializeObject<IdResponse>(jsonString);

                return deserializeResponse;
            }
            var error = NSJ.JsonConvert.DeserializeObject<MetaError>(jsonString);
            response.AddError(error?.Error?.Message ?? jsonString);
            return response;
        }
        catch (Exception ex)
        {
            var error = NSJ.JsonConvert.DeserializeObject<MetaError>(ex.Message);
            response.AddError(error?.Error?.Message ?? ex.Message);
            return response;
        }
    }

    private async ValueTask<HttpResponse> HTTPGetAsync(string uri, Dictionary<string, string>? headers = null)
    {
        var response = new HttpResponse();
        try
        {
            using (var request = new HttpRequestMessage(HttpMethod.Get, uri))
            {
                if (headers is not null)
                {
                    foreach (var header in headers)
                    {
                        request.Headers.Add(header.Key, header.Value);
                    }
                }
                var httpClientResponse = await _httpClient.SendAsync(request);

                if (httpClientResponse is not null)
                {
                    var errorString = await httpClientResponse.Content.ReadAsStringAsync();
                    var error = NSJ.JsonConvert.DeserializeObject<MetaError>(errorString);

                    if (httpClientResponse.StatusCode == System.Net.HttpStatusCode.BadRequest)
                    {
                        response.AddError(error?.Error?.Message ?? _instagramAuthCodeExpired);
                        return response;
                    }
                    else if (httpClientResponse.StatusCode == System.Net.HttpStatusCode.Unauthorized)
                    {
                        response.AddError(error?.Error?.Message ?? _instagramAuthCodeExpired);
                        return response;
                    }
                    else if (httpClientResponse.StatusCode == System.Net.HttpStatusCode.Forbidden)
                    {
                        response.AddError(error?.Error?.Message ?? _instagramAuthCodeExpired);
                        return response;
                    }
                    else if (httpClientResponse.StatusCode != System.Net.HttpStatusCode.OK)
                    {
                        response.AddError(error?.Error?.Message ?? _instagramAuthCodeExpired);
                        return response;
                    }
                }

                response.HttpResponseMessage = httpClientResponse;
                return response;
            }
        }
        catch (Exception ex)
        {
            var error = NSJ.JsonConvert.DeserializeObject<MetaError>(ex.Message);
            response.AddError(error?.Error?.Message ?? ex.Message);
            return response;
        }
    }

    private string? ExtractContainerId(string containerResponse)
    {
        return NSJ.JsonConvert.DeserializeObject<dynamic>(containerResponse)?.id;
    }

    private Dictionary<string, object>? ExtractUserProfileValues(string jsonString)
    {
        try
        {
            Dictionary<string, object> keyValuePairs = new Dictionary<string, object>();
            JsonNode? jsonNode = JsonNode.Parse(jsonString);

            if (jsonNode != null)
            {
                ExtractProperty(jsonNode, _id, keyValuePairs);
                ExtractProperty(jsonNode, _userId, keyValuePairs);
                ExtractProperty(jsonNode, _username, keyValuePairs);
                ExtractProperty(jsonNode, _name, keyValuePairs);
                ExtractProperty(jsonNode, _profilePictureUrl, keyValuePairs);
            }

            return keyValuePairs;
        }
        catch (Exception)
        {
            throw new Exception(_instagramServiceError);
        }
    }

    private void ExtractProperty(JsonNode node, string propertyKey, Dictionary<string, object> keyValuePairs)
    {
        var nodeProperty = node[propertyKey];
        if (nodeProperty != null)
        {
            keyValuePairs[propertyKey] = nodeProperty.ToString();
        }
    }

    public enum MediaType
    {
        IMAGE = 0,
        CAROUSEL = 1
    }

    public enum InsightsPeriod
    {
        day = 0,
        week = 1,
        days_28 = 2
    }

}