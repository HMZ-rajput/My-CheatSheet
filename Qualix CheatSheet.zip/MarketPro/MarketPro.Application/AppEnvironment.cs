﻿using MailKit.Security;

namespace MarketPro.Application;

public static class AppEnvironment
{
    public static EnvironmentType Type { get; private set; }

    public const string DefaultConnectionString = "Server=(local)\\SQLEXPRESS;Database=MarketPro;TrustServerCertificate=True;Trusted_Connection=True;MultipleActiveResultSets=true";
    public static string ConnectionString { get; private set; } = DefaultConnectionString;
    public static string AuthSecretKey { get; private set; } = "marketprotmm79!#!@#$*()&*($#Q#@$%@@$%&^!$@%#^@$^*&@%^%$@^$$@#%)@#$%@!!@#@$$$mmww@blvopgBN";
    public static string SenderEmailAddress { get; set; } = "qualixdev1@gmail.com";
    public static string SenderEmailPassword { get; set; } = "gpnb cswv icct dvac";
    public static string SMTPHost { get; private set; } = "smtp.gmail.com";
    public static string EmailClientId { get; private set; } = "693008661286-mlrr9qduq9mmvh6v3608qrtvtnljne20.apps.googleusercontent.com";
    public static string EmailClientSecret { get; private set; } = "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";
    public static string EmailRefreshToken { get; private set; } = "1//04eXFwVxwwDhlCgYIARAAGAQSNwF-L9IreEDeHgadO52Hb_S4UMSoxX9qU3twT_0cvgGWbEQem73rATbwBsXiWYoNtpfM493tdBU";
    public static int SMTPPort { get; private set; } = 587;
    public static string BaseURL { get; private set; } = "https://marketpro.naveedportfolio.com";
    public static string FrontendBaseURL { get; private set; } = "https://localhost:5173";
    public static bool EnableMailSSL { get; private set; } = true;
    public static SecureSocketOptions EmailSocketOption { get; private set; } = SecureSocketOptions.StartTls;
    public static string CreateUserEmailSubject { get; private set; } = "Your MarketPro App account password";
    public static string CreateUserEmailBody { get; private set; } = "Your MarketPro App account has been successfully created. Please use this username: <b>{EMAIL}</b> and password: <b>{PASSWORD}</b> to login";
    public static string CreateInvitationEmailSubject { get; private set; } = "MarketPro Invitation";
    public static string SuccessfulPaymentEmailSubject { get; private set; } = "MarketPro Subscription Payment Success";
    public static string PasswordOTPEmailSubject { get; private set; } = "OTP For Resetting Your MarketPro App Password";
    public static string PasswordOTPEmailBody { get; private set; } = "Dear MarketPro User, Please use this OTP <b>{OTP}</b> to reset your password. Please ignore this email if you did not request a password reset and contact support@marketpro.org";
    public static int OTPExpiry { get; private set; } = 10; // In minutes
    public static string GenericSQLDatabaseError { get; private set; } = "An error occurred while processing the data.";
    public static string SuperAdminEmail { get; private set; } = "superadmin@marketpro.com";
    public static string StripeTestKey { get; private set; } = "sk_test_51PkSNoIQlsOLmSXVmGnTIg6st54VbNq0SnPatlbkXPNwi2muMqJKsUhdCmsxSvvd9O225j6J7KBaw1ieDQ7uPKoU00AltOmXGZ";
    public static string LinkedInClientId { get; private set; } = "86crx838tfzi73";
    public static string LinkedInClientSecret { get; private set; } = "WPL_AP1.3CMMpe9FQ0rG3FkS.NPRhWA==";
    public static string LinkedInRedirectUriSignup { get; private set; } = "https://localhost:5173/signup?type=0";
    public static string LinkedInRedirectUriConnect { get; private set; } = "https://localhost:5173/connect?type=0";
    public static string FacebookClientId { get; private set; } = "1457356144972777";
    public static string FacebookClientSecret { get; private set; } = "636119027046faf47e324dc73a5acac2";
    public static string FacebookRedirectUriSignup { get; private set; } = "https://localhost:5173/signup?type=2";
    public static string FacebookRedirectUriConnect { get; private set; } = "https://localhost:5173/connect?type=2";
    public static string InstagramClientId { get; private set; } = "1264723644702333";
    public static string InstagramClientSecret { get; private set; } = "2f851bbfbe6cf07b1d2f9750b0eeb717";
    public static string InstagramRedirectUriSignup { get; private set; } = "https://localhost:5173/signup";
    public static string InstagramRedirectUriConnect { get; private set; } = "https://localhost:5173/connect";
    public static string OpenApiKey { get; private set; } = "sk-svcacct-Lps-3UMnzeujca9Ki4s8ZDnuoiYhUiDdEyV-GY8xcXbRQyT0i8SayLzUGP6OHvWgVT3BlbkFJQsM0vlo42dhZrxi0zlR21lAHJcgsLHkZv6p4JdPBPlu9rYvESTji_RWGE83mjHOAA";

    static AppEnvironment()
    {
        Type = EnvironmentType.QA;
        switch (Type)
        {
            case EnvironmentType.PROD:
                SetUpProd();
                break;
            case EnvironmentType.QA:
                SetUpQA();
                break;
            case EnvironmentType.LOCAL:
                SetUpLocal();
                break;
            case EnvironmentType.DEV:
                SetUpDev();
                break;
            default:
                break;
        }
    }

    public static void SetUpLocal()
    {
        ConnectionString = DefaultConnectionString;
        BaseURL = "http://localhost:3000";
        FrontendBaseURL = "https://localhost:5173";
    }

    public static void SetUpQA()
    {
        ConnectionString = "Server=154.12.241.246;Database=QA_MarketPro;User ID=qualixadmin;Password=Qualix_Admin@156;MultipleActiveResultSets=true;TrustServerCertificate=True";
        BaseURL = "https://localhost:5173";
        FrontendBaseURL = "https://localhost:5173";
        LinkedInRedirectUriSignup = $"{BaseURL}/signup?type=0";
        LinkedInRedirectUriConnect = $"{BaseURL}/connect?type=0";
        FacebookRedirectUriSignup = $"{BaseURL}/signup?type=2";
        FacebookRedirectUriConnect = $"{BaseURL}/connect?type=2";
        InstagramRedirectUriSignup = $"{BaseURL}/signup";
        InstagramRedirectUriConnect = $"{BaseURL}/connect";
    }

    public static void SetUpDev()
    {
        ConnectionString = "Server=154.12.241.246;Database=QA_MarketPro;User ID=qualixadmin;Password=Qualix_Admin@156;MultipleActiveResultSets=true;TrustServerCertificate=True";
        BaseURL = "https://qa-marketpro.naveedportfolio.com";
        FrontendBaseURL = "https://qa-marketpro.naveedportfolio.com";
        LinkedInRedirectUriSignup = $"{BaseURL}/signup?type=0";
        LinkedInRedirectUriConnect = $"{BaseURL}/connect?type=0";
        FacebookRedirectUriSignup = $"{BaseURL}/signup?type=2";
        FacebookRedirectUriConnect = $"{BaseURL}/connect?type=2";
        InstagramRedirectUriSignup = $"{BaseURL}/signup";
        InstagramRedirectUriConnect = $"{BaseURL}/connect";
    }

    public static void SetUpProd()
    {
    }
}

public enum EnvironmentType
{
    LOCAL = 0,
    QA = 1,
    PROD = 2,
    DEV = 3
}
