﻿namespace MarketPro.Repositories;

public interface IBaseRepository<TEntity> : IDisposable where TEntity : class
{
    void Add(TEntity entity);
    void Update(TEntity entity);
    void UpdateRange(IEnumerable<TEntity> entities);
    void Delete(TEntity entity);
    void DeleteRange(IEnumerable<TEntity> entities);
    TEntity? GetById(Guid id);
    IEnumerable<TEntity> GetAll();
    ValueTask AddAsync(TEntity entity);
    ValueTask UpdateAsync(TEntity entity);
    ValueTask DeleteAsync(TEntity entity);
    ValueTask<TEntity?> GetByIdAsync(Guid id);
    ValueTask<IEnumerable<TEntity>> GetAllAsync();
    ValueTask SaveChangesAsync();
}