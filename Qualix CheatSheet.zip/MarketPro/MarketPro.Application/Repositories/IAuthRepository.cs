﻿using MarketPro.Identity.DTOs;
using MarketPro.Identity.Entities;
using MarketPro.UserAccounts.Entities;

namespace MarketPro.IRepositories;

public interface IAuthRepository
{
    ValueTask<AuthResponse> LoginAsync(LoginRequest request);

    ValueTask<AuthResponse> SignUpAsync(SignUpRequest request, string? modifiedBy);

    ValueTask ConfirmEmailAsync(string userId);

    ValueTask<ChangePasswordResponse> ChangePasswordAsync(ChangePasswordRequest request, string? modifiedBy);

    ValueTask<SendForgotPasswordEmailResponse> SendForgotPasswordEmailAsync(SendForgotPasswordEmailRequest request);

    ValueTask<ResetPasswordResponse> ResetPasswordAsync(ResetPasswordRequest request);

    ValueTask<VerifyPasswordOTPResponse> VerifyPasswordOTPAsync(VerifyPasswordOTPRequest request);

    ValueTask<AuthDTO> MapAuthResponseAsync(ApplicationUser user, UserAccount? userDetails);

    ValueTask<AuthResponse> UpdatePersonalInfoAsync(string userId, UpdatePersonalInfoRequest request);

    ValueTask<AuthResponse> DeleteAccountAsync(string userId, string? modifiedBy);
}