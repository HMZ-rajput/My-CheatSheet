﻿using MarketPro.Posts.DTOs;
using MarketPro.Posts.Entities;
using MarketPro.SocialAccounts.DTOs;

namespace MarketPro.Repositories;

public interface IPostRepository<TEntity> :
    IBaseRepository<Post>,
    IDisposable where TEntity : class
{
    ValueTask<PostsResponse> CreatePostsAsync(string applicationUserId, CreatePostDTO request);
    ValueTask<GetAllPostResponse> GetAllPostsByUserIdAsync(string userId, PostFilters filters);
    ValueTask<GetPostResponse> GetPostByIdAsync(Guid postId, string userId);
    ValueTask<GetPostResponse> DeletePostByIdAsync(Guid postId, string userId, string? modifiedBy);
    ValueTask<GetPostResponse> UpdatePostAsync(Guid postId, string userId, UpdatePostDTO request);
    ValueTask<GetPostResponse> PostActionAsync(Guid postId, string userId, PostActionDTO request);
}