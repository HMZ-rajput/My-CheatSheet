﻿using MarketPro.Identity.DTOs;
using MarketPro.UserAccounts.DTOs;

namespace MarketPro.Repositories;

public interface IUserAccountRepository
{
    ValueTask<AuthResponse> UpdateUserAsync(string id, UpdateUserRequest request, string? modifiedBy);
    ValueTask<AuthResponse> GetUserPlanAsync();
}