﻿using MarketPro.Analytics.DTOs;
using MarketPro.Analytics.Entities;

namespace MarketPro.Repositories;

public interface IAnalyticsRepository<TEntity> :
    IBaseRepository<Report>,
    IDisposable where TEntity : class
{
    ValueTask<GetAnalyticsResponse> GetAnalyticsAsync(string userId, AnalyticsFilters filters);
    ValueTask<GetReportResponse> CreateReportAsync(string userId, CreateReportDTO request);
    ValueTask<GetReportResponse> UpdateReportByIdAsync(string userId, Guid reportId, UpdateReportDTO request);
    ValueTask<GetReportResponse> GetReportByIdAsync(string userId, Guid reportId);
    ValueTask<GetAllReportResponse> GetAllReportsByIdAsync(string userId);
    ValueTask<GetReportResponse> DeleteReportByIdAsync(string userId, Guid reportId, string? modifiedBy);
}
