﻿using MarketPro.Analytics.DTOs;
using MarketPro.Common.DTOs;
using MarketPro.Posts.Entities;
using MarketPro.Services;
using MarketPro.SocialAccounts.DTOs;
using MarketPro.SocialAccounts.Entities;

namespace MarketPro.Repositories;

public interface ISocialAccountRepository<TEntity> :
    IBaseRepository<SocialAccount>,
    IDisposable where TEntity : class
{
    ValueTask<ConnectSocialAccountResponse> ConnectSocialAccountAsync(string userAccountId, ConnectSocialAccountDTO request, string? modifiedBy);
    ValueTask<GetSocialAccountResponse> GetConnectedSocialAccountsByUserIdAsync(string userAccountId);
    ValueTask<GetSocialAccountResponse> GetSocialAccountsListByUserIdAsync(string userAccountId);
    ValueTask<DisconnectSocialAccountResponse> DisconnectSocialAccountAsync(string userAccountId, DisconnectSocialAccountDTO request, string? modifiedBy);
    ValueTask<AllAnalyticsDTO> GetSocialAccountAnalytics(IList<SocialAccount> socialAccounts);
    ValueTask<PublishResponse> HandlePostPublishAsync(Post post);
}