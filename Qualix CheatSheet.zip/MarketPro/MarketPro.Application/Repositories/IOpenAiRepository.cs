﻿using MarketPro.OpenAi.DTOs;

namespace MarketPro.Repositories;

public interface IOpenAiRepository
{
    ValueTask<GenerateIdeaResponse> GenerateIdeaAsync(GenerateIdeaDTO request);
}
