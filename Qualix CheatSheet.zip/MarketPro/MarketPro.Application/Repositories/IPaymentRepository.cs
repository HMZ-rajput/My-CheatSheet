﻿using MarketPro.Identity.DTOs;
using MarketPro.Payments.DTOs;
using Stripe;

namespace MarketPro.Repositories;

public interface IPaymentRepository
{
    ValueTask<bool> UpdateUserSubscriptionStatusAsync(Subscription? subscription);

    ValueTask<bool> SendPaymentEmailAsync(Invoice? invoice);

    ValueTask<AuthResponse> CancelSubscriptionAsync(string userId, string? modifiedBy);

    ValueTask<AuthResponse> UpdateSubscriptionAsync(string userId, UpdateSubscriptionRequest request);

    ValueTask<AuthResponse> UpdatePaymentMethodAsync(string userId, UpdatePaymentMethodRequest request);

    ValueTask<InvoiceRespose> GetAllInvoicesAsync(string userId, StripePagination pagination);

    ValueTask<PlansResponse> GetAllPlansAsync();

    ValueTask<PlanResponse> GetUserPlanByIdAsync(string userId);
}