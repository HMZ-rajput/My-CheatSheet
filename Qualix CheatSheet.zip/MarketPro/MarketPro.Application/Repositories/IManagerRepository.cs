﻿using MarketPro.Managers.DTOs;
using MarketPro.Managers.Entities;

namespace MarketPro.Repositories;

public interface IManagerRepository<TEntity> :
    IBaseRepository<Invitation>,
    IDisposable where TEntity : class
{
    ValueTask<GetManagerResponse> CreateInvitationAsync(string userId, CreateInvitationDTO request);
    ValueTask<GetManagerResponse> AcceptOrDenyInvitationAsync(Guid invitationId, bool isAccept);
    ValueTask<GetAllManagersResponse> GetAllManagersByUserIdAsync(string userId);
    ValueTask<GetManagerResponse> DeleteManagerByIdAsync(string userId, string entityId, DeleteManagerDTO request);
    ValueTask<GetManagerResponse> UpdateManagerSocialAccountAsync(string userId, string managerId, UpdateManagerRequest request);

}
