﻿using MarketPro.Application;
using MarketPro.Services;
using Microsoft.Extensions.DependencyInjection;

namespace MarketPro;

public static class DependencyInjection
{
    public static IServiceCollection AddApplication(this IServiceCollection services)
    {
        services.AddHttpClient();
        services.AddScoped<IMailService, MailService>();
        services.AddScoped<IPlanRuleValidator, PlanRuleValidator>();
        services.AddScoped<IPaymentService, PaymentService>();
        services.AddScoped<IFacebookService, FacebookService>();
        services.AddScoped<IInstagramService, InstagramService>();
        services.AddScoped<ILinkedInService, LinkedInService>();
        services
            .AddOpenAi(settings =>
            {
                settings.ApiKey = AppEnvironment.OpenApiKey;
                settings.UseVersionForChat("v1");
                settings.UseVersionForImage("v1");
            });
        services.AddTransient<IOpenAiService, OpenAiService>();

        return services;
    }
}
