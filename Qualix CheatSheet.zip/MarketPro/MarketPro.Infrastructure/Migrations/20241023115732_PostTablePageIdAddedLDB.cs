﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace MarketPro.Migrations
{
    /// <inheritdoc />
    public partial class PostTablePageIdAddedLDB : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "PageId",
                table: "Post",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "PageName",
                table: "Post",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "PublishedBy",
                table: "Post",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "PublishedPostId",
                table: "Post",
                type: "nvarchar(max)",
                nullable: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "PageId",
                table: "Post");

            migrationBuilder.DropColumn(
                name: "PageName",
                table: "Post");

            migrationBuilder.DropColumn(
                name: "PublishedBy",
                table: "Post");

            migrationBuilder.DropColumn(
                name: "PublishedPostId",
                table: "Post");
        }
    }
}
