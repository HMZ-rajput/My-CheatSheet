﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace MarketPro.Migrations
{
    /// <inheritdoc />
    public partial class ApplicationUserProfilePicAdded : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_AspNetUsers_UserAccount_ManagerId",
                table: "AspNetUsers");

            migrationBuilder.DropForeignKey(
                name: "FK_Document_AspNetUsers_UserId",
                table: "Document");

            migrationBuilder.DropIndex(
                name: "IX_Document_UserId",
                table: "Document");

            migrationBuilder.RenameColumn(
                name: "UserId",
                table: "Document",
                newName: "ApplicationUserId");

            migrationBuilder.RenameColumn(
                name: "ManagerId",
                table: "AspNetUsers",
                newName: "AdminAccountId");

            migrationBuilder.RenameIndex(
                name: "IX_AspNetUsers_ManagerId",
                table: "AspNetUsers",
                newName: "IX_AspNetUsers_AdminAccountId");

            migrationBuilder.CreateIndex(
                name: "IX_Document_ApplicationUserId",
                table: "Document",
                column: "ApplicationUserId",
                unique: true,
                filter: "[ApplicationUserId] IS NOT NULL");

            migrationBuilder.AddForeignKey(
                name: "FK_AspNetUsers_UserAccount_AdminAccountId",
                table: "AspNetUsers",
                column: "AdminAccountId",
                principalTable: "UserAccount",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Document_AspNetUsers_ApplicationUserId",
                table: "Document",
                column: "ApplicationUserId",
                principalTable: "AspNetUsers",
                principalColumn: "Id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_AspNetUsers_UserAccount_AdminAccountId",
                table: "AspNetUsers");

            migrationBuilder.DropForeignKey(
                name: "FK_Document_AspNetUsers_ApplicationUserId",
                table: "Document");

            migrationBuilder.DropIndex(
                name: "IX_Document_ApplicationUserId",
                table: "Document");

            migrationBuilder.RenameColumn(
                name: "ApplicationUserId",
                table: "Document",
                newName: "UserId");

            migrationBuilder.RenameColumn(
                name: "AdminAccountId",
                table: "AspNetUsers",
                newName: "ManagerId");

            migrationBuilder.RenameIndex(
                name: "IX_AspNetUsers_AdminAccountId",
                table: "AspNetUsers",
                newName: "IX_AspNetUsers_ManagerId");

            migrationBuilder.CreateIndex(
                name: "IX_Document_UserId",
                table: "Document",
                column: "UserId");

            migrationBuilder.AddForeignKey(
                name: "FK_AspNetUsers_UserAccount_ManagerId",
                table: "AspNetUsers",
                column: "ManagerId",
                principalTable: "UserAccount",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Document_AspNetUsers_UserId",
                table: "Document",
                column: "UserId",
                principalTable: "AspNetUsers",
                principalColumn: "Id");
        }
    }
}
