﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace MarketPro.Migrations
{
    /// <inheritdoc />
    public partial class PostTableUpdatedLCDB : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<Guid>(
                name: "SocialAccountId",
                table: "Post",
                type: "uniqueidentifier",
                nullable: true);

            migrationBuilder.CreateTable(
                name: "DocumentPost",
                columns: table => new
                {
                    ImagesId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    PostsId = table.Column<Guid>(type: "uniqueidentifier", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_DocumentPost", x => new { x.ImagesId, x.PostsId });
                    table.ForeignKey(
                        name: "FK_DocumentPost_Document_ImagesId",
                        column: x => x.ImagesId,
                        principalTable: "Document",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_DocumentPost_Post_PostsId",
                        column: x => x.PostsId,
                        principalTable: "Post",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Post_SocialAccountId",
                table: "Post",
                column: "SocialAccountId");

            migrationBuilder.CreateIndex(
                name: "IX_DocumentPost_PostsId",
                table: "DocumentPost",
                column: "PostsId");

            migrationBuilder.AddForeignKey(
                name: "FK_Post_SocialAccount_SocialAccountId",
                table: "Post",
                column: "SocialAccountId",
                principalTable: "SocialAccount",
                principalColumn: "Id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Post_SocialAccount_SocialAccountId",
                table: "Post");

            migrationBuilder.DropTable(
                name: "DocumentPost");

            migrationBuilder.DropIndex(
                name: "IX_Post_SocialAccountId",
                table: "Post");

            migrationBuilder.DropColumn(
                name: "SocialAccountId",
                table: "Post");
        }
    }
}
