﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace MarketPro.Migrations
{
    /// <inheritdoc />
    public partial class InvitationTableUpdatedAdded : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Invitation_AspNetUsers_UserAccountId",
                table: "Invitation");

            migrationBuilder.DropForeignKey(
                name: "FK_Post_AspNetUsers_UserAccountId",
                table: "Post");

            migrationBuilder.DropForeignKey(
                name: "FK_SocialAccount_AspNetUsers_UserAccountId",
                table: "SocialAccount");

            migrationBuilder.DropForeignKey(
                name: "FK_UserAccount_AspNetUsers_AdminUserId",
                table: "UserAccount");

            migrationBuilder.DropIndex(
                name: "IX_UserAccount_AdminUserId",
                table: "UserAccount");

            migrationBuilder.RenameColumn(
                name: "AdminUserId",
                table: "UserAccount",
                newName: "ApplicationUserId");

            migrationBuilder.RenameColumn(
                name: "UserAccountId",
                table: "SocialAccount",
                newName: "ApplicationUserId");

            migrationBuilder.RenameIndex(
                name: "IX_SocialAccount_UserAccountId",
                table: "SocialAccount",
                newName: "IX_SocialAccount_ApplicationUserId");

            migrationBuilder.RenameColumn(
                name: "UserAccountId",
                table: "Post",
                newName: "ApplicationUserId");

            migrationBuilder.RenameIndex(
                name: "IX_Post_UserAccountId",
                table: "Post",
                newName: "IX_Post_ApplicationUserId");

            migrationBuilder.RenameColumn(
                name: "UserAccountId",
                table: "Invitation",
                newName: "ApplicationUserId");

            migrationBuilder.RenameIndex(
                name: "IX_Invitation_UserAccountId",
                table: "Invitation",
                newName: "IX_Invitation_ApplicationUserId");

            migrationBuilder.AddColumn<Guid>(
                name: "InvitationId",
                table: "Invitation",
                type: "uniqueidentifier",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_UserAccount_ApplicationUserId",
                table: "UserAccount",
                column: "ApplicationUserId",
                unique: true,
                filter: "[ApplicationUserId] IS NOT NULL");

            migrationBuilder.CreateIndex(
                name: "IX_Invitation_InvitationId",
                table: "Invitation",
                column: "InvitationId");

            migrationBuilder.AddForeignKey(
                name: "FK_Invitation_AspNetUsers_ApplicationUserId",
                table: "Invitation",
                column: "ApplicationUserId",
                principalTable: "AspNetUsers",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Invitation_Invitation_InvitationId",
                table: "Invitation",
                column: "InvitationId",
                principalTable: "Invitation",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Post_AspNetUsers_ApplicationUserId",
                table: "Post",
                column: "ApplicationUserId",
                principalTable: "AspNetUsers",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_SocialAccount_AspNetUsers_ApplicationUserId",
                table: "SocialAccount",
                column: "ApplicationUserId",
                principalTable: "AspNetUsers",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_UserAccount_AspNetUsers_ApplicationUserId",
                table: "UserAccount",
                column: "ApplicationUserId",
                principalTable: "AspNetUsers",
                principalColumn: "Id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Invitation_AspNetUsers_ApplicationUserId",
                table: "Invitation");

            migrationBuilder.DropForeignKey(
                name: "FK_Invitation_Invitation_InvitationId",
                table: "Invitation");

            migrationBuilder.DropForeignKey(
                name: "FK_Post_AspNetUsers_ApplicationUserId",
                table: "Post");

            migrationBuilder.DropForeignKey(
                name: "FK_SocialAccount_AspNetUsers_ApplicationUserId",
                table: "SocialAccount");

            migrationBuilder.DropForeignKey(
                name: "FK_UserAccount_AspNetUsers_ApplicationUserId",
                table: "UserAccount");

            migrationBuilder.DropIndex(
                name: "IX_UserAccount_ApplicationUserId",
                table: "UserAccount");

            migrationBuilder.DropIndex(
                name: "IX_Invitation_InvitationId",
                table: "Invitation");

            migrationBuilder.DropColumn(
                name: "InvitationId",
                table: "Invitation");

            migrationBuilder.RenameColumn(
                name: "ApplicationUserId",
                table: "UserAccount",
                newName: "AdminUserId");

            migrationBuilder.RenameColumn(
                name: "ApplicationUserId",
                table: "SocialAccount",
                newName: "UserAccountId");

            migrationBuilder.RenameIndex(
                name: "IX_SocialAccount_ApplicationUserId",
                table: "SocialAccount",
                newName: "IX_SocialAccount_UserAccountId");

            migrationBuilder.RenameColumn(
                name: "ApplicationUserId",
                table: "Post",
                newName: "UserAccountId");

            migrationBuilder.RenameIndex(
                name: "IX_Post_ApplicationUserId",
                table: "Post",
                newName: "IX_Post_UserAccountId");

            migrationBuilder.RenameColumn(
                name: "ApplicationUserId",
                table: "Invitation",
                newName: "UserAccountId");

            migrationBuilder.RenameIndex(
                name: "IX_Invitation_ApplicationUserId",
                table: "Invitation",
                newName: "IX_Invitation_UserAccountId");

            migrationBuilder.CreateIndex(
                name: "IX_UserAccount_AdminUserId",
                table: "UserAccount",
                column: "AdminUserId",
                unique: true,
                filter: "[AdminUserId] IS NOT NULL");

            migrationBuilder.AddForeignKey(
                name: "FK_Invitation_AspNetUsers_UserAccountId",
                table: "Invitation",
                column: "UserAccountId",
                principalTable: "AspNetUsers",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Post_AspNetUsers_UserAccountId",
                table: "Post",
                column: "UserAccountId",
                principalTable: "AspNetUsers",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_SocialAccount_AspNetUsers_UserAccountId",
                table: "SocialAccount",
                column: "UserAccountId",
                principalTable: "AspNetUsers",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_UserAccount_AspNetUsers_AdminUserId",
                table: "UserAccount",
                column: "AdminUserId",
                principalTable: "AspNetUsers",
                principalColumn: "Id");
        }
    }
}
