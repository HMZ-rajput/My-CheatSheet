﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace MarketPro.Migrations
{
    /// <inheritdoc />
    public partial class UserRoleAddedQADB : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.InsertData(
                table: "AspNetRoles",
                columns: new[] { "Id", "ConcurrencyStamp", "Name", "NormalizedName" },
                values: new object[,]
                {
                    { "15ed2398-0e42-4d5b-9f83-d1727f0bd5e9", null, "Manager", "MANAGER" },
                    { "833b7264-9e3f-4e2e-a752-628690acb053", null, "Admin", "ADMIN" }
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "15ed2398-0e42-4d5b-9f83-d1727f0bd5e9");

            migrationBuilder.DeleteData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "833b7264-9e3f-4e2e-a752-628690acb053");
        }
    }
}
