﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace MarketPro.Migrations
{
    /// <inheritdoc />
    public partial class UserAccountTableManagersAdded : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<Guid>(
                name: "ManagerId",
                table: "AspNetUsers",
                type: "uniqueidentifier",
                nullable: true);

            migrationBuilder.CreateTable(
                name: "ApplicationUserSocialAccount",
                columns: table => new
                {
                    ManagerSocialAccountsId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    ManagersId = table.Column<string>(type: "nvarchar(450)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ApplicationUserSocialAccount", x => new { x.ManagerSocialAccountsId, x.ManagersId });
                    table.ForeignKey(
                        name: "FK_ApplicationUserSocialAccount_AspNetUsers_ManagersId",
                        column: x => x.ManagersId,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_ApplicationUserSocialAccount_SocialAccount_ManagerSocialAccountsId",
                        column: x => x.ManagerSocialAccountsId,
                        principalTable: "SocialAccount",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_AspNetUsers_ManagerId",
                table: "AspNetUsers",
                column: "ManagerId");

            migrationBuilder.CreateIndex(
                name: "IX_ApplicationUserSocialAccount_ManagersId",
                table: "ApplicationUserSocialAccount",
                column: "ManagersId");

            migrationBuilder.AddForeignKey(
                name: "FK_AspNetUsers_UserAccount_ManagerId",
                table: "AspNetUsers",
                column: "ManagerId",
                principalTable: "UserAccount",
                principalColumn: "Id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_AspNetUsers_UserAccount_ManagerId",
                table: "AspNetUsers");

            migrationBuilder.DropTable(
                name: "ApplicationUserSocialAccount");

            migrationBuilder.DropIndex(
                name: "IX_AspNetUsers_ManagerId",
                table: "AspNetUsers");

            migrationBuilder.DropColumn(
                name: "ManagerId",
                table: "AspNetUsers");
        }
    }
}
