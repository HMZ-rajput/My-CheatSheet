﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace MarketPro.Migrations
{
    /// <inheritdoc />
    public partial class SocialAccountLinkedToApplicationUserQADB : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_SocialAccount_UserAccount_UserAccountId",
                table: "SocialAccount");

            migrationBuilder.AlterColumn<string>(
                name: "UserAccountId",
                table: "SocialAccount",
                type: "nvarchar(450)",
                nullable: true,
                oldClrType: typeof(Guid),
                oldType: "uniqueidentifier",
                oldNullable: true);

            migrationBuilder.AddForeignKey(
                name: "FK_SocialAccount_AspNetUsers_UserAccountId",
                table: "SocialAccount",
                column: "UserAccountId",
                principalTable: "AspNetUsers",
                principalColumn: "Id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_SocialAccount_AspNetUsers_UserAccountId",
                table: "SocialAccount");

            migrationBuilder.AlterColumn<Guid>(
                name: "UserAccountId",
                table: "SocialAccount",
                type: "uniqueidentifier",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(450)",
                oldNullable: true);

            migrationBuilder.AddForeignKey(
                name: "FK_SocialAccount_UserAccount_UserAccountId",
                table: "SocialAccount",
                column: "UserAccountId",
                principalTable: "UserAccount",
                principalColumn: "Id");
        }
    }
}
