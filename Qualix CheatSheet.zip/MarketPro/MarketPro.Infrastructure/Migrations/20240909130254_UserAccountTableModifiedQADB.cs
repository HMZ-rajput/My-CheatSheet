﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace MarketPro.Migrations
{
    /// <inheritdoc />
    public partial class UserAccountTableModifiedQADB : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_AspNetUsers_UserAccount_AccountId",
                table: "AspNetUsers");

            migrationBuilder.DropIndex(
                name: "IX_AspNetUsers_AccountId",
                table: "AspNetUsers");

            migrationBuilder.DropColumn(
                name: "AccountId",
                table: "AspNetUsers");

            migrationBuilder.AddColumn<string>(
                name: "AccountUserId",
                table: "UserAccount",
                type: "nvarchar(450)",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_UserAccount_AccountUserId",
                table: "UserAccount",
                column: "AccountUserId",
                unique: true,
                filter: "[AccountUserId] IS NOT NULL");

            migrationBuilder.AddForeignKey(
                name: "FK_UserAccount_AspNetUsers_AccountUserId",
                table: "UserAccount",
                column: "AccountUserId",
                principalTable: "AspNetUsers",
                principalColumn: "Id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_UserAccount_AspNetUsers_AccountUserId",
                table: "UserAccount");

            migrationBuilder.DropIndex(
                name: "IX_UserAccount_AccountUserId",
                table: "UserAccount");

            migrationBuilder.DropColumn(
                name: "AccountUserId",
                table: "UserAccount");

            migrationBuilder.AddColumn<Guid>(
                name: "AccountId",
                table: "AspNetUsers",
                type: "uniqueidentifier",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_AspNetUsers_AccountId",
                table: "AspNetUsers",
                column: "AccountId");

            migrationBuilder.AddForeignKey(
                name: "FK_AspNetUsers_UserAccount_AccountId",
                table: "AspNetUsers",
                column: "AccountId",
                principalTable: "UserAccount",
                principalColumn: "Id");
        }
    }
}
