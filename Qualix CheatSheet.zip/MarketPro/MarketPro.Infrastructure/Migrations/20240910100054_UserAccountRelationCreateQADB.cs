﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace MarketPro.Migrations
{
    /// <inheritdoc />
    public partial class UserAccountRelationCreateQADB : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_UserAccount_AspNetUsers_AccountUserId",
                table: "UserAccount");

            migrationBuilder.DropIndex(
                name: "IX_UserAccount_AccountUserId",
                table: "UserAccount");

            migrationBuilder.RenameColumn(
                name: "AccountUserId",
                table: "UserAccount",
                newName: "AdminUserId");

            migrationBuilder.CreateIndex(
                name: "IX_UserAccount_AdminUserId",
                table: "UserAccount",
                column: "AdminUserId",
                unique: true,
                filter: "[AdminUserId] IS NOT NULL");

            migrationBuilder.AddForeignKey(
                name: "FK_UserAccount_AspNetUsers_AdminUserId",
                table: "UserAccount",
                column: "AdminUserId",
                principalTable: "AspNetUsers",
                principalColumn: "Id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_UserAccount_AspNetUsers_AdminUserId",
                table: "UserAccount");

            migrationBuilder.DropIndex(
                name: "IX_UserAccount_AdminUserId",
                table: "UserAccount");

            migrationBuilder.RenameColumn(
                name: "AdminUserId",
                table: "UserAccount",
                newName: "AccountUserId");

            migrationBuilder.CreateIndex(
                name: "IX_UserAccount_AccountUserId",
                table: "UserAccount",
                column: "AccountUserId",
                unique: true,
                filter: "[AccountUserId] IS NOT NULL");

            migrationBuilder.AddForeignKey(
                name: "FK_UserAccount_AspNetUsers_AccountUserId",
                table: "UserAccount",
                column: "AccountUserId",
                principalTable: "AspNetUsers",
                principalColumn: "Id");
        }
    }
}
