﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace MarketPro.Migrations
{
    /// <inheritdoc />
    public partial class OneToManyUserAccountsQA : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_UserAccount_AspNetUsers_AdminId",
                table: "UserAccount");

            migrationBuilder.DropForeignKey(
                name: "FK_UserAccount_AspNetUsers_ManagerId",
                table: "UserAccount");

            migrationBuilder.DropIndex(
                name: "IX_UserAccount_AdminId",
                table: "UserAccount");

            migrationBuilder.DropIndex(
                name: "IX_UserAccount_ManagerId",
                table: "UserAccount");

            migrationBuilder.DropColumn(
                name: "AdminId",
                table: "UserAccount");

            migrationBuilder.DropColumn(
                name: "ManagerId",
                table: "UserAccount");

            migrationBuilder.AddColumn<Guid>(
                name: "AccountId",
                table: "AspNetUsers",
                type: "uniqueidentifier",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "Role",
                table: "AspNetUsers",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateIndex(
                name: "IX_AspNetUsers_AccountId",
                table: "AspNetUsers",
                column: "AccountId");

            migrationBuilder.AddForeignKey(
                name: "FK_AspNetUsers_UserAccount_AccountId",
                table: "AspNetUsers",
                column: "AccountId",
                principalTable: "UserAccount",
                principalColumn: "Id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_AspNetUsers_UserAccount_AccountId",
                table: "AspNetUsers");

            migrationBuilder.DropIndex(
                name: "IX_AspNetUsers_AccountId",
                table: "AspNetUsers");

            migrationBuilder.DropColumn(
                name: "AccountId",
                table: "AspNetUsers");

            migrationBuilder.DropColumn(
                name: "Role",
                table: "AspNetUsers");

            migrationBuilder.AddColumn<string>(
                name: "AdminId",
                table: "UserAccount",
                type: "nvarchar(450)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "ManagerId",
                table: "UserAccount",
                type: "nvarchar(450)",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_UserAccount_AdminId",
                table: "UserAccount",
                column: "AdminId");

            migrationBuilder.CreateIndex(
                name: "IX_UserAccount_ManagerId",
                table: "UserAccount",
                column: "ManagerId");

            migrationBuilder.AddForeignKey(
                name: "FK_UserAccount_AspNetUsers_AdminId",
                table: "UserAccount",
                column: "AdminId",
                principalTable: "AspNetUsers",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_UserAccount_AspNetUsers_ManagerId",
                table: "UserAccount",
                column: "ManagerId",
                principalTable: "AspNetUsers",
                principalColumn: "Id");
        }
    }
}
