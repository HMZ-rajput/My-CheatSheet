﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace MarketPro.Migrations
{
    /// <inheritdoc />
    public partial class TableSocialAccountUpdateQADB : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "FirstName",
                table: "SocialAccount",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Headline",
                table: "SocialAccount",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "LastName",
                table: "SocialAccount",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "ProfilePicture",
                table: "SocialAccount",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "SocialAccountId",
                table: "SocialAccount",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "VanityName",
                table: "SocialAccount",
                type: "nvarchar(max)",
                nullable: true);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "FirstName",
                table: "SocialAccount");

            migrationBuilder.DropColumn(
                name: "Headline",
                table: "SocialAccount");

            migrationBuilder.DropColumn(
                name: "LastName",
                table: "SocialAccount");

            migrationBuilder.DropColumn(
                name: "ProfilePicture",
                table: "SocialAccount");

            migrationBuilder.DropColumn(
                name: "SocialAccountId",
                table: "SocialAccount");

            migrationBuilder.DropColumn(
                name: "VanityName",
                table: "SocialAccount");
        }
    }
}
