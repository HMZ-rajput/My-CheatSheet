﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace MarketPro.Migrations
{
    /// <inheritdoc />
    public partial class PostDocumentTableUpdatedLCDB : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "DocumentPost");

            migrationBuilder.AddColumn<Guid>(
                name: "PostId",
                table: "Document",
                type: "uniqueidentifier",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Document_PostId",
                table: "Document",
                column: "PostId");

            migrationBuilder.AddForeignKey(
                name: "FK_Document_Post_PostId",
                table: "Document",
                column: "PostId",
                principalTable: "Post",
                principalColumn: "Id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Document_Post_PostId",
                table: "Document");

            migrationBuilder.DropIndex(
                name: "IX_Document_PostId",
                table: "Document");

            migrationBuilder.DropColumn(
                name: "PostId",
                table: "Document");

            migrationBuilder.CreateTable(
                name: "DocumentPost",
                columns: table => new
                {
                    ImagesId = table.Column<Guid>(type: "uniqueidentifier", nullable: false),
                    PostsId = table.Column<Guid>(type: "uniqueidentifier", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_DocumentPost", x => new { x.ImagesId, x.PostsId });
                    table.ForeignKey(
                        name: "FK_DocumentPost_Document_ImagesId",
                        column: x => x.ImagesId,
                        principalTable: "Document",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_DocumentPost_Post_PostsId",
                        column: x => x.PostsId,
                        principalTable: "Post",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_DocumentPost_PostsId",
                table: "DocumentPost",
                column: "PostsId");
        }
    }
}
