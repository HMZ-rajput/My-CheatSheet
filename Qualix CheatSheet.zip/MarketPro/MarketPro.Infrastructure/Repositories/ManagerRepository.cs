﻿using AutoMapper;
using MarketPro.Application;
using MarketPro.Data;
using MarketPro.Identity.DTOs;
using MarketPro.Identity.Entities;
using MarketPro.Managers.DTOs;
using MarketPro.Managers.Entities;
using MarketPro.Services;
using MarketPro.SocialAccounts.DTOs;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;

namespace MarketPro.Repositories;

public class ManagerRepository :
    BaseRepository<Invitation>,
    IManagerRepository<Invitation>
{
    private const string _inviteNotFoundError = "Invitation does not exsist.";
    private const string _socialAccountRequiredError = "Atleast one social account is required";
    private const string _userNotFoundError = "User does not exist.";
    private const string _managerNotFoundError = "Manager does not exist.";
    private const string _userAlreadyExist = "User already exsist.";
    private const string _invitationAlreadyExist = "Invitation is already pending or accepted by user.";
    private const string _emailError = "User was created but a problem occurred while sending the email";

    private readonly ApplicationDbContext _context;
    private readonly UserManager<ApplicationUser> _userManager;
    private readonly IMapper _mapper;
    private readonly IFileService _fileService;
    private readonly IMailService _mailService;
    private readonly IPlanRuleValidator _planValidator;

    public ManagerRepository(ApplicationDbContext context, UserManager<ApplicationUser> userManager, IMapper mapper, IFileService fileService, IMailService mailService, IPlanRuleValidator planValidator) : base(context)
    {
        _context = context ?? throw new ArgumentNullException(nameof(context));
        _userManager = userManager ?? throw new ArgumentNullException(nameof(userManager));
        _mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));
        _fileService = fileService ?? throw new ArgumentNullException(nameof(fileService));
        _mailService = mailService ?? throw new ArgumentNullException(nameof(mailService));
        _planValidator = planValidator ?? throw new ArgumentNullException(nameof(planValidator));
    }


    async ValueTask<GetManagerResponse> IManagerRepository<Invitation>.CreateInvitationAsync(string userId, CreateInvitationDTO request)
    {
        var response = new GetManagerResponse();
        bool invitationExist = false;

        var socialAccounts = await _context.SocialAccount
            .Include(x => x.ApplicationUser)
            .ThenInclude(au => au!.UserAccount)
            .Where(x => x.IsActive && x.ApplicationUserId == userId && request.SocialAccountIds.Contains(x.Id))
            .ToListAsync()
            .ConfigureAwait(false);

        var invitation = await _context.Invitation
            .Include(x => x.SocialAccounts)
            .FirstOrDefaultAsync(x => x.ApplicationUserId == userId && x.Email == request.Email.ToLower().Trim())
            .ConfigureAwait(false);

        if (socialAccounts.Count == 0)
        {
            response.AddError(_socialAccountRequiredError);
            return response;
        }

        _planValidator.CanAddManager(socialAccounts.First().ApplicationUser!.UserAccount!);

        if (invitation is not null && invitation.IsActive is true)
        {
            response.AddError(_invitationAlreadyExist);
            return response;
        }

        var manager = await _userManager.FindByEmailAsync(request.Email).ConfigureAwait(false);

        if (manager is not null && (manager.IsActive is true || manager.Role == UserRole.Admin))
        {
            response.AddError(_userAlreadyExist);
            return response;
        }

        var user = socialAccounts.First().ApplicationUser;

        if (user is null)
        {
            response.AddError(_userNotFoundError);
            return response;
        }

        if (invitation is not null)
        {
            invitationExist = true;
            invitation.Status = InviteStatus.Pending;
            invitation.ModifiedBy = request.ModifiedBy;
            invitation.IsActive = true;
            invitation.SocialAccounts.Clear();
        }

        invitation = invitation is not null ? invitation : new Invitation
        {
            Name = request.Name,
            Email = request.Email,
            Status = InviteStatus.Pending,
            ApplicationUserId = userId,
            ApplicationUser = user,
            CreatedBy = request.ModifiedBy,
            ModifiedDate = DateTimeOffset.UtcNow,
        };

        foreach (var socialAccount in socialAccounts)
            invitation.SocialAccounts.Add(socialAccount);

        var bodyText = @"<html lang=""en"">
  <body>
    <div
      style=""
        font-family: 'Inter', sans-serif;
        max-width: 600px;
        padding: 20px;
        color: #0a0d14;
      ""
    >
      <div style=""margin-bottom: 40px"">
        <img
          src=""https://raw.githubusercontent.com/FarazQx/RawAssets/refs/heads/main/marketprologo.png""
          alt=""MarketPro Logo""
          style=""width: auto; height: auto""
        />
      </div>

      <h2 style=""font-size: 24px; color: #0a0d14; font-weight: 500; margin: 0"">
        Join marketPro Team
      </h2>

      <div style=""margin-bottom: 40px"">
        <p
          style=""
            font-size: 16px;
            color: #475467;
            font-weight: 400;
            margin-bottom: 20px;
          ""
        >
          Hello [Username],
        </p>
        <p
          style=""
            font-size: 16px;
            color: #475467;
            font-weight: 400;
            margin-bottom: 16px;
          ""
        >
          You&apos;ve been invited by <strong>[AdminName]</strong> to
          join the MarketPro team. Once you accept, you&apos;ll be able to
          collaborate and manage social content efficiently.
        </p>
        <p
          style=""
            font-size: 16px;
            color: #475467;
            font-weight: 400;
            margin-bottom: 16px;
          ""
        >
          [AdminEmail]
        </p>
      </div>

      <div
        style=""
          display: flex;
          gap: 16px;
          justify-content: flex-start;
          margin-bottom: 40px;
        ""
      >
        <a
          href=""[AcceptInvitation]""
          style=""
            min-width: 140px;
            padding: 10px;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 600;
            background-color: #6e51e0;
            color: white;
            text-decoration: none;
            text-align: center;
            display: inline-block;
          ""
        >
          Accept
        </a>
        <a
          href=""[RejectInvitation]""
          style=""
            min-width: 140px;
            padding: 10px;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 600;
            color: #b00020;
            border: 1px solid #b8c9e2;
            background-color: transparent;
            text-decoration: none;
            text-align: center;
            display: inline-block;
          ""
        >
          Decline
        </a>
      </div>

      <div
        style=""
          font-size: 14px;
          color: #9ca3af;
          line-height: 1.5;
          border-top: 1px solid #e5e7eb;
          padding-top: 20px;
          margin-top: 40px;
        ""
      >
        <p>
          This email was sent to [UserEmail]. If you&apos;d rather not
          receive this kind of email, you can
          <a href=""#"" style=""color: #6e51e0; text-decoration: none""
            >unsubscribe</a
          >
          or manage your email preferences.
        </p>
        <p style=""margin-top: 10px"">&copy; [CurrentYear] MarketPro</p>
      </div>

      <div style=""margin-top: 24px"">
        <img
          src=""https://raw.githubusercontent.com/FarazQx/RawAssets/refs/heads/main/marketprologo.png""
          alt=""MarketPro Logo""
          style=""width: auto; height: auto""
        />
      </div>
    </div>
  </body>
</html>
";
        var subject = AppEnvironment.CreateInvitationEmailSubject;
        var acceptInvitationLink = AppEnvironment.Type != EnvironmentType.PROD ? $"{AppEnvironment.FrontendBaseURL}/invitation-accepted?invitationId={invitation.Id}" : $"https://marketpro.naveedportfolio.com/invitation-accepted?invitationId={invitation.Id}";
        var rejectInvitationLink = AppEnvironment.Type != EnvironmentType.PROD ? $"{AppEnvironment.FrontendBaseURL}/invitation-rejected?invitationId={invitation.Id}" : $"https://marketpro.naveedportfolio.com/invitation-rejected?invitationId={invitation.Id}";
        bodyText = bodyText.Replace("[InvitationId]", invitation.Id.ToString());
        bodyText = bodyText.Replace("[Username]", request.Name);
        bodyText = bodyText.Replace("[UserEmail]", request.Email);
        bodyText = bodyText.Replace("[AdminName]", user.FirstName + " " + user.LastName);
        bodyText = bodyText.Replace("[AdminEmail]", user.Email);
        bodyText = bodyText.Replace("[CurrentYear]", DateTime.Now.Year.ToString());
        bodyText = bodyText.Replace("[AcceptInvitation]", acceptInvitationLink);
        bodyText = bodyText.Replace("[RejectInvitation]", rejectInvitationLink);


        var isEmailSent = await _mailService.SendEmailAsync(request.Email, subject, bodyText).ConfigureAwait(false);

        if (!isEmailSent)
        {
            response.AddError("Invitation was created but a problem occurred while sending the email");
        }

        if (!invitationExist)
            await AddAsync(invitation).ConfigureAwait(false);
        await SaveChangesAsync().ConfigureAwait(false);

        response.Manager = MapInvitationToManager(invitation);
        return response;
    }

    async ValueTask<GetManagerResponse> IManagerRepository<Invitation>.AcceptOrDenyInvitationAsync(Guid invitationId, bool isAccept)
    {
        var response = new GetManagerResponse();

        var invitation = await _context.Invitation
            .Include(x => x.ApplicationUser)
            .ThenInclude(x => x!.UserAccount)
            .Include(x => x.SocialAccounts)
            .FirstOrDefaultAsync(x => x.IsActive && x.Status == InviteStatus.Pending && x.Id == invitationId)
            .ConfigureAwait(false);

        if (invitation is null || invitation.ApplicationUser is null || invitation.ApplicationUser.UserAccount is null)
        {
            response.AddError(_inviteNotFoundError);
            return response;
        }

        if (!isAccept)
        {
            invitation.Status = InviteStatus.Rejected;
            invitation.ModifiedDate = DateTime.UtcNow;
            invitation.ModifiedBy = invitation.Name;

            response.Manager = MapInvitationToManager(invitation);

            await SaveChangesAsync().ConfigureAwait(false);

            return response;
        }

        _planValidator.CanAddManager(invitation.ApplicationUser.UserAccount);

        var user = await _userManager.FindByEmailAsync(invitation.Email).ConfigureAwait(false);

        if (user is not null && (user.IsActive is true || user.Role == UserRole.Admin))
        {
            response.AddError(_userAlreadyExist);
            return response;
        }

        var password = Password.Generate(12, 3);
        var adminUser = await _userManager.FindByIdAsync(invitation.ApplicationUser.UserAccount.ApplicationUserId ?? string.Empty).ConfigureAwait(false);

        if (user is not null)
        {
            user.FirstName = invitation.Name;
            user.LastName = string.Empty;
            user.Role = UserRole.Manager;
            user.AdminAccount = invitation.ApplicationUser!.UserAccount;
            user.IsActive = true;
            user.ModifiedBy = invitation.Name;
            user.ModifiedDate = DateTimeOffset.UtcNow;

            await _userManager.RemovePasswordAsync(user).ConfigureAwait(false);
            var identityResponse = await _userManager.AddPasswordAsync(user, password).ConfigureAwait(false);

            if (!identityResponse.Succeeded)
            {
                response.Errors.AddRange(identityResponse.Errors.Select(x => x.Description).ToList());
                return response;
            }
        }
        else
        {
            user = new ApplicationUser
            {
                FirstName = invitation.Name,
                LastName = string.Empty,
                Email = invitation.Email,
                UserName = invitation.Email,
                Role = UserRole.Manager,
                AdminAccount = invitation.ApplicationUser.UserAccount,
                CreatedBy = invitation.Name,
                CreatedDate = DateTimeOffset.UtcNow,

            };
            var identityResponse = await _userManager.CreateAsync(user, password).ConfigureAwait(false);

            if (!identityResponse.Succeeded)
            {
                response.Errors.AddRange(identityResponse.Errors.Select(x => x.Description).ToList());
                return response;
            }
        }

        await _userManager.AddToRoleAsync(user, UserRole.Manager.ToString());

        foreach (var socialAccount in invitation.SocialAccounts)
            user.ManagerSocialAccounts.Add(socialAccount);

        invitation.ApplicationUser.UserAccount.Managers.Add(user);

        var subject = AppEnvironment.CreateUserEmailSubject;
        var bodyText = @"<html lang=""en"">
  <body>
    <div
      style=""
        font-family: 'Inter', sans-serif;
        max-width: 600px;
        padding: 20px;
        color: #0a0d14;
      ""
    >
      <div style=""margin-bottom: 40px"">
        <img
          src=""https://raw.githubusercontent.com/FarazQx/RawAssets/refs/heads/main/marketprologo.png""
          alt=""MarketPro Logo""
          style=""width: auto; height: auto""
        />
      </div>

      <h2
        style=""
          font-size: 24px;
          color: #0a0d14;
          font-weight: 500;
          margin-bottom: 20px;
        ""
      >
        Welcome to MarketPro! Your Account Details
      </h2>

      <p style=""font-size: 16px; color: #475467; margin-bottom: 20px"">
        Hi [AccountManagerName],
      </p>
      <p style=""font-size: 16px; color: #475467; margin-bottom: 20px"">
        Congratulations on accepting your invitation to join MarketPro!
        You&apos;re now part of our team, and we&apos;re excited to have you on
        board.
      </p>
      <p style=""font-size: 16px; color: #475467; margin-bottom: 20px"">
        Here are your login credentials:
      </p>

      <p style=""font-size: 16px; color: #475467; margin: 5px 0"">
        <strong>Email:</strong> [Email]
      </p>
      <p style=""font-size: 16px; color: #475467; margin: 5px 0"">
        <strong>Password:</strong> [Password] (Please change this after your
        first login)
      </p>
      <p style=""font-size: 16px; color: #475467; margin: 5px 0"">
        <strong>Login Link:</strong>
        <a
          href=""https://marketpro.naveedportfolio.com/login""
          style=""color: #6e51e0; text-decoration: none""
          >MarketPro Login</a
        >
      </p>

      <p style=""font-size: 16px; color: #475467; margin-top: 20px"">
        To get started, click the link above and enter your credentials. If you
        have any questions or need assistance, feel free to reach out.
      </p>
      <p style=""font-size: 16px; color: #475467; margin-top: 20px"">
        Welcome aboard!
      </p>

      <p style=""font-size: 16px; color: #475467; margin-top: 20px"">
        Best regards,<br />
        [AdminName]<br />
        [AdminEmail]<br />
        MarketPro Team
      </p>

      <div
        style=""
          font-size: 14px;
          color: #9ca3af;
          line-height: 1.5;
          border-top: 1px solid #e5e7eb;
          padding-top: 20px;
          margin-top: 40px;
        ""
      >
        <p>
          This email was sent to [Email]. If you&apos;d rather not
          receive this kind of email, you can
          <a href=""#"" style=""color: #6e51e0; text-decoration: none""
            >unsubscribe</a
          >
          or manage your email preferences.
        </p>
        <p style=""margin-top: 10px"">&copy; [CurrentYear] MarketPro</p>
      </div>

      <div style=""margin-top: 24px"">
        <img
          src=""https://raw.githubusercontent.com/FarazQx/RawAssets/refs/heads/main/marketprologo.png""
          alt=""MarketPro Logo""
          style=""width: auto; height: auto""
        />
      </div>
    </div>
  </body>
</html>
";

        bodyText = bodyText.Replace("[Email]", invitation.Email);
        bodyText = bodyText.Replace("[Password]", password);
        bodyText = bodyText.Replace("[AccountManagerName]", invitation.Name);
        bodyText = bodyText.Replace("[AdminName]", adminUser?.FirstName + " " + adminUser?.LastName);
        bodyText = bodyText.Replace("[AdminEmail]", adminUser?.Email);
        bodyText = bodyText.Replace("[CurrentYear]", DateTime.Now.Year.ToString());

        var isEmailSent = await _mailService.SendEmailAsync(invitation.Email, subject, bodyText).ConfigureAwait(false);

        if (!isEmailSent)
        {
            response.AddError(_emailError);
        }

        invitation.Status = InviteStatus.Accepted;
        invitation.ModifiedBy = invitation.Name;
        invitation.ModifiedDate = DateTimeOffset.UtcNow;

        await SaveChangesAsync().ConfigureAwait(false);

        response.Manager = MapInvitationToManager(invitation);

        return response;
    }

    async ValueTask<GetAllManagersResponse> IManagerRepository<Invitation>.GetAllManagersByUserIdAsync(string userId)
    {
        var response = new GetAllManagersResponse();

        var admin = await _context.UserAccount
            .Include(x => x.Managers.Where(m => m.IsActive))
            .ThenInclude(m => m.ManagerSocialAccounts)
            .FirstOrDefaultAsync(x => x.ApplicationUserId == userId)
            .ConfigureAwait(false);

        var invitations = await _context.Invitation
            .Where(x => x.IsActive && x.ApplicationUserId == userId)
            .Include(x => x.SocialAccounts)
            .ToListAsync()
            .ConfigureAwait(false);


        if (admin is null)
        {
            //response.AddError(_userNotFoundError);
            return response;
        }

        if (invitations.Count == 0)
        {
            //response.AddError($"{_inviteNotFoundError}");
            return response;
        }

        response.Managers = MapAllManagers(admin.Managers.ToList(), invitations).ToList();

        //response.Managers = admin.Managers.Select(m => MapManager(m)).ToList();

        return response;
    }

    async ValueTask<GetManagerResponse> IManagerRepository<Invitation>.DeleteManagerByIdAsync(string userId, string entityId, DeleteManagerDTO request)
    {
        var response = new GetManagerResponse();

        if (request.Status == InviteStatus.Accepted)
        {
            var admin = await _context.UserAccount
            .Include(x => x.Managers.Where(m => m.IsActive && m.Id == entityId))
            .ThenInclude(m => m.ManagerSocialAccounts)
            .FirstOrDefaultAsync(x => x.IsActive && x.ApplicationUserId == userId)
            .ConfigureAwait(false);

            if (admin is null || admin.Managers.Count == 0)
            {
                response.AddError(_userNotFoundError);
                return response;
            }

            _planValidator.IsSubscriptionValid(admin, false);

            var manager = admin.Managers.First();

            var invitation = await _context.Invitation
                .FirstOrDefaultAsync(x => x.IsActive && x.ApplicationUserId == userId && x.Email.ToLower().Trim() == (manager.Email != null ? manager.Email.ToLower().Trim() : ""))
                .ConfigureAwait(false);

            if (invitation is not null)
            {
                invitation.IsActive = false;
                invitation.ModifiedBy = request.ModifiedBy;
                invitation.ModifiedDate = DateTimeOffset.UtcNow;
            }

            manager.IsActive = false;
            manager.ModifiedBy = request.ModifiedBy;
            manager.ModifiedDate = DateTimeOffset.UtcNow;

            response.Manager = MapManager(manager);

            manager.ManagerSocialAccounts.Clear();
            //admin.Managers.Remove(manager);

            await SaveChangesAsync().ConfigureAwait(false);

            return response;
        }
        else
        {
            var invitation = await _context.Invitation
                .Include(x => x.SocialAccounts)
                .FirstOrDefaultAsync(x => x.IsActive && x.Id.ToString() == entityId)
                .ConfigureAwait(false);

            if (invitation is null || invitation.Status == InviteStatus.Accepted)
            {
                response.AddError(_inviteNotFoundError);
                return response;
            }

            invitation.IsActive = false;
            invitation.ModifiedBy = request.ModifiedBy;
            invitation.ModifiedDate = DateTimeOffset.UtcNow;

            await SaveChangesAsync().ConfigureAwait(false);

            response.Manager = MapInvitationToManager(invitation);

            return response;
        }


    }

    async ValueTask<GetManagerResponse> IManagerRepository<Invitation>.UpdateManagerSocialAccountAsync(string userId, string managerId, UpdateManagerRequest request)
    {
        var response = new GetManagerResponse();

        var admin = await _context.UserAccount
            .Include(x => x.Managers.Where(m => m.IsActive && m.Id == managerId))
            .ThenInclude(m => m.ManagerSocialAccounts)
            .Include(x => x.ApplicationUser)
            .ThenInclude(ap => ap!.SocialAccounts.Where(sa => sa.IsActive))
            .FirstOrDefaultAsync(x => x.IsActive && x.ApplicationUserId == userId)
            .ConfigureAwait(false);

        if (admin is null || admin.Managers.Count == 0 || admin.ApplicationUser is null || admin.ApplicationUser.SocialAccounts.Count == 0)
        {
            response.AddError(_userNotFoundError);
            return response;
        }

        _planValidator.IsSubscriptionValid(admin, false);

        var socialAccounts = admin.ApplicationUser.SocialAccounts.Where(sa => request.SocialAccountIds.Contains(sa.Id)).ToList();

        var manager = admin.Managers.First();

        manager.ManagerSocialAccounts.Clear();

        foreach (var socialAccount in socialAccounts)
        {
            manager.ManagerSocialAccounts.Add(socialAccount);
        }

        manager.ModifiedBy = request.ModifiedBy;
        manager.ModifiedDate = DateTimeOffset.UtcNow;

        await SaveChangesAsync().ConfigureAwait(false);

        response.Manager = MapManager(manager);

        return response;
    }

    private static GetInvitationDTO MapInvitation(Invitation invitation)
    {
        return new GetInvitationDTO
        {
            id = invitation.Id,
            Name = invitation.Name,
            Email = invitation.Email,
            Status = invitation.Status,
            ApplicationUser = invitation.ApplicationUser is null ? null : new GetAuthDTO
            {
                UserId = invitation.ApplicationUser.Id,
                FirstName = invitation.ApplicationUser.FirstName,
                LastName = invitation.ApplicationUser.LastName,
            },
            SocialAccounts = invitation.SocialAccounts.Select(x => new SocialAccountInfoDTO
            {
                Id = x.Id,
                Type = x.Type,
                FirstName = x.FirstName,
                LastName = x.LastName,
                ProfilePicture = x.ProfilePicture,
            }).ToList(),
            CreatedBy = invitation.CreatedBy,
            CreatedDate = invitation.CreatedDate,
            ModifiedBy = invitation.ModifiedBy,
            ModifiedDate = invitation.ModifiedDate,
        };
    }

    private static GetManagerDTO MapManager(ApplicationUser manager)
    {
        return new GetManagerDTO
        {
            Id = manager.Id,
            Name = manager.FirstName,
            Email = manager.Email,
            SocialAccounts = manager.ManagerSocialAccounts.Select(s => new SocialAccountInfoDTO
            {
                Id = s.Id,
                Type = s.Type,
                FirstName = s.FirstName,
                LastName = s.LastName,
                ProfilePicture = s.ProfilePicture,
            }).ToList(),
        };
    }

    private GetManagerDTO MapInvitationToManager(Invitation invitation)
    {
        return new GetManagerDTO
        {
            Id = "",
            Name = invitation.Name,
            Email = invitation.Email,
            Status = invitation.Status,
            InvitationId = invitation.Id,
            SocialAccounts = invitation.SocialAccounts.Select(s => new SocialAccountInfoDTO
            {
                Id = s.Id,
                Type = s.Type,
                FirstName = s.FirstName,
                LastName = s.LastName,
                ProfilePicture = s.ProfilePicture,
            }).ToList(),
        };
    }

    private static IList<GetManagerDTO> MapAllManagers(IList<ApplicationUser> managers, IList<Invitation> invitations)
    {
        IList<GetManagerDTO> managersResponse = [];

        foreach (var invitation in invitations)
        {
            var manager = managers.FirstOrDefault(x => x.Email == invitation.Email);

            var managerItem = new GetManagerDTO
            {
                Id = manager is not null ? manager.Id : "",
                Name = manager is not null ? $"{manager.FirstName} {manager.LastName}" : invitation.Name,
                Email = manager is not null ? manager.Email : invitation.Email,
                Status = invitation.Status,
                InvitationId = manager is null ? invitation.Id : null,
                SocialAccounts = manager is not null ? manager.ManagerSocialAccounts.Select(s => new SocialAccountInfoDTO
                {
                    Id = s.Id,
                    Type = s.Type,
                    FirstName = s.FirstName,
                    LastName = s.LastName,
                    ProfilePicture = s.ProfilePicture,
                }).ToList() :
                    invitation.SocialAccounts.Select(s => new SocialAccountInfoDTO
                    {
                        Id = s.Id,
                        Type = s.Type,
                        FirstName = s.FirstName,
                        LastName = s.LastName,
                        ProfilePicture = s.ProfilePicture,
                    }).ToList(),
            };

            managersResponse.Add(managerItem);
        }

        return managersResponse;
    }

}


