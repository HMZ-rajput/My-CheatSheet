﻿using AutoMapper;
using Coravel.Invocable;
using MarketPro.Analytics.DTOs;
using MarketPro.Application;
using MarketPro.Data;
using MarketPro.Identity.Entities;
using MarketPro.LinkedIn.DTOs;
using MarketPro.Posts.Entities;
using MarketPro.Services;
using MarketPro.SocialAccounts.DTOs;
using MarketPro.SocialAccounts.Entities;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using System.Text.RegularExpressions;

namespace MarketPro.Repositories;


public class SocialAccountRepository :
    BaseRepository<SocialAccount>,
    ISocialAccountRepository<SocialAccount>,
    IInvocable
{
    private const string _socialAccountNotFoundError = "Social account does not exist.";
    private const string _userNotFoundError = "User does not exist.";
    private const string _postNotFoundError = "Post does not exist.";
    private const string _invalidSocialAccountTypeError = "Invalid social account type.";
    private const string _facebookpageDetailsNotFoundError = "Something went wrong when getting Facebook page details.";
    private const string _LinkedInpageDetailsNotFoundError = "Something went wrong when getting LinkedIn page details.";
    private const string _instagrampageDetailsNotFoundError = "Something went wrong when getting Instagram page details.";
    private const string _facebookPublisError = "Something went wrong when publishing to facebook.";
    private const string _linkedInPublisError = "Something went wrong when publishing to linkedIn.";
    private const string _instagramPublisError = "Something went wrong when publishing to instagram.";

    private readonly ApplicationDbContext _context;
    private readonly IFacebookService _facebookService;
    private readonly IInstagramService _instagramService;
    private readonly ILinkedInService _linkedInService;
    private readonly IMapper _mapper;
    private readonly IFileService _fileService;
    private readonly IPlanRuleValidator _planValidator;
    private readonly UserManager<ApplicationUser> _userManager;

    public SocialAccountRepository(ApplicationDbContext context, IFacebookService facebookService, IInstagramService instagramService, ILinkedInService linkedInService, IMapper mapper, IFileService fileService, IPlanRuleValidator planValidator, UserManager<ApplicationUser> userManager) : base(context)
    {
        if (userManager is null)
        {
            throw new ArgumentNullException(nameof(userManager));
        }

        _context = context ?? throw new ArgumentNullException(nameof(context));
        _linkedInService = linkedInService ?? throw new ArgumentNullException(nameof(linkedInService));
        _instagramService = instagramService ?? throw new ArgumentNullException(nameof(instagramService));
        _facebookService = facebookService ?? throw new ArgumentNullException(nameof(facebookService));
        _mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));
        _fileService = fileService ?? throw new ArgumentNullException(nameof(fileService));
        _planValidator = planValidator ?? throw new ArgumentNullException(nameof(planValidator));
        _userManager = userManager ?? throw new ArgumentNullException(nameof(userManager));
    }

    async ValueTask<ConnectSocialAccountResponse> ISocialAccountRepository<SocialAccount>.ConnectSocialAccountAsync(string userAccountId, ConnectSocialAccountDTO request, string? modifiedBy)
    {
        var response = new ConnectSocialAccountResponse { SocialAccounts = [] };
        SocialAccount? socialAccount = null;
        GetUserProfileResponse? profileDetails = null;
        IList<SocialAccount> socialAccounts = [];

        if (request.Type == SocialAccountType.LinkedIn)
        {
            var linkedInResponse = await _linkedInService.GetAccessTokenAsync(request.AuthorizationCode, request.IsConnect)
                .ConfigureAwait(false);

            if (linkedInResponse is not null && linkedInResponse.IsSuccess)
            {
                profileDetails = await _linkedInService.GetUserProfileAsync(linkedInResponse?.AccessTokenResponse?.AccessToken)
                    .ConfigureAwait(false);

                if (!profileDetails.IsSuccess)
                {
                    profileDetails.Errors.ForEach(response.AddError);
                    return response;
                }

                var socialAccountId = profileDetails?.UserProfile?.SocialAccountId ?? string.Empty;

                socialAccount = await _context.SocialAccount
                    .Include(x => x.ApplicationUser)
                    .ThenInclude(au => au!.UserAccount)
                    .FirstOrDefaultAsync(sa => sa.ApplicationUserId == userAccountId && sa.SocialAccountId == socialAccountId)
                    .ConfigureAwait(false);

                if (socialAccount is not null)
                {
                    _planValidator.CanConnectSocialAccount(socialAccount.ApplicationUser!.UserAccount!);

                    socialAccount.AuthToken = linkedInResponse?.AccessTokenResponse?.AccessToken;
                    socialAccount.SocialAccountId = profileDetails?.UserProfile?.SocialAccountId;
                    socialAccount.FirstName = profileDetails?.UserProfile?.FirstName;
                    socialAccount.LastName = profileDetails?.UserProfile?.LastName;
                    socialAccount.VanityName = profileDetails?.UserProfile?.VanityName;
                    socialAccount.Headline = profileDetails?.UserProfile?.Headline;
                    socialAccount.ProfilePicture = profileDetails?.UserProfile?.ProfilePicture;
                    socialAccount.Type = request.Type;
                    socialAccount.ApplicationUserId = userAccountId;
                    socialAccount.IsActive = true;//
                    socialAccount.ModifiedBy = modifiedBy;
                    socialAccount.ModifiedDate = DateTimeOffset.UtcNow;

                    socialAccounts.Add(socialAccount);
                }
                else
                {
                    socialAccount = new SocialAccount
                    {
                        AuthToken = linkedInResponse?.AccessTokenResponse?.AccessToken,
                        SocialAccountId = profileDetails?.UserProfile?.SocialAccountId,
                        FirstName = profileDetails?.UserProfile?.FirstName,
                        LastName = profileDetails?.UserProfile?.LastName,
                        VanityName = profileDetails?.UserProfile?.VanityName,
                        Headline = profileDetails?.UserProfile?.Headline,
                        ProfilePicture = profileDetails?.UserProfile?.ProfilePicture,
                        Type = request.Type,
                        ApplicationUserId = userAccountId,
                        CreatedBy = modifiedBy
                    };

                    socialAccounts.Add(socialAccount);

                    await _context.SocialAccount.AddAsync(socialAccount)
                        .ConfigureAwait(false);
                }
            }
            else
            {
                if (linkedInResponse is not null && !linkedInResponse.IsSuccess)
                {
                    linkedInResponse.Errors.ForEach(response.AddError);
                    return response;
                }
            }
        }
        else if (request.Type == SocialAccountType.Facebook)
        {
            var facebookResponse = await _facebookService.GetAccessTokenAsync(request.AuthorizationCode, request.IsConnect)
                .ConfigureAwait(false);

            if (facebookResponse is not null)
            {
                profileDetails = await _facebookService.GetUserProfileAsync(facebookResponse.AccessToken)
                    .ConfigureAwait(false);

                if (!profileDetails.IsSuccess)
                {
                    profileDetails.Errors.ForEach(response.AddError);
                    return response;
                }

                var socialAccountId = profileDetails?.UserProfile?.SocialAccountId ?? string.Empty;

                socialAccount = await _context.SocialAccount
                    .Include(x => x.ApplicationUser)
                    .ThenInclude(au => au!.UserAccount)
                    .FirstOrDefaultAsync(sa => sa.ApplicationUserId == userAccountId && sa.SocialAccountId == socialAccountId)
                    .ConfigureAwait(false);

                if (socialAccount is not null)
                {
                    _planValidator.CanConnectSocialAccount(socialAccount.ApplicationUser!.UserAccount!);

                    socialAccount.AuthToken = facebookResponse.AccessToken;
                    socialAccount.SocialAccountId = profileDetails?.UserProfile?.SocialAccountId;
                    socialAccount.FirstName = profileDetails?.UserProfile?.FirstName;
                    socialAccount.LastName = profileDetails?.UserProfile?.LastName;
                    socialAccount.ProfilePicture = profileDetails?.UserProfile?.ProfilePicture;
                    socialAccount.Type = request.Type;
                    socialAccount.ApplicationUserId = userAccountId;
                    socialAccount.IsActive = true;//
                    socialAccount.ModifiedBy = modifiedBy;
                    socialAccount.ModifiedDate = DateTimeOffset.UtcNow;

                    socialAccounts.Add(socialAccount);
                }
                else
                {
                    socialAccount = new SocialAccount
                    {
                        AuthToken = facebookResponse.AccessToken,
                        SocialAccountId = profileDetails?.UserProfile?.SocialAccountId,
                        FirstName = profileDetails?.UserProfile?.FirstName,
                        LastName = profileDetails?.UserProfile?.LastName,
                        ProfilePicture = profileDetails?.UserProfile?.ProfilePicture,
                        Type = request.Type,
                        ApplicationUserId = userAccountId,
                        CreatedBy = modifiedBy
                    };

                    socialAccounts.Add(socialAccount);

                    await _context.SocialAccount.AddAsync(socialAccount)
                        .ConfigureAwait(false);
                }

                var facebookPageDetails = await _facebookService.GetPagesDetailsAsync(facebookResponse.AccessToken, socialAccountId).ConfigureAwait(false);

                if (facebookPageDetails is not null && facebookPageDetails.IsSuccess)
                {
                    foreach (var item in facebookPageDetails.Pages)
                    {
                        if (item.InstagramBusinessAccount is not null)
                        {
                            var instagramId = item.InstagramBusinessAccount?.Id ?? string.Empty;
                            var pageId = profileDetails?.UserProfile?.SocialAccountId ?? string.Empty;
                            var instagramAccount = await _context.SocialAccount
                            .FirstOrDefaultAsync(sa => sa.ApplicationUserId == userAccountId && sa.SocialAccountId == instagramId && sa.Headline == pageId)
                            .ConfigureAwait(false);

                            //insta headline is facebook id
                            //insta vanityName is facebook access token
                            if (instagramAccount is not null)
                            {
                                instagramAccount.AuthToken = item.AccessToken;
                                instagramAccount.SocialAccountId = item.InstagramBusinessAccount?.Id;
                                instagramAccount.FirstName = item.InstagramBusinessAccount?.Name;
                                instagramAccount.ProfilePicture = item.InstagramBusinessAccount?.ProfilePicture;
                                instagramAccount.Headline = pageId;
                                instagramAccount.VanityName = facebookResponse.AccessToken;
                                instagramAccount.Type = SocialAccountType.Instagram;
                                instagramAccount.ApplicationUserId = userAccountId;
                                instagramAccount.IsActive = true;
                                instagramAccount.ModifiedBy = modifiedBy;
                                instagramAccount.ModifiedDate = DateTimeOffset.UtcNow;

                                socialAccounts.Add(instagramAccount);
                            }
                            else
                            {
                                instagramAccount = new SocialAccount
                                {
                                    AuthToken = item.AccessToken,
                                    SocialAccountId = item.InstagramBusinessAccount?.Id,
                                    FirstName = item.InstagramBusinessAccount?.Name,
                                    ProfilePicture = item.InstagramBusinessAccount?.ProfilePicture,
                                    Headline = profileDetails?.UserProfile?.SocialAccountId,
                                    VanityName = facebookResponse.AccessToken,
                                    Type = SocialAccountType.Instagram,
                                    ApplicationUserId = userAccountId,
                                    CreatedBy = modifiedBy
                                };

                                socialAccounts.Add(instagramAccount);

                                await _context.SocialAccount.AddAsync(instagramAccount)
                                .ConfigureAwait(false);
                            }
                        }
                    }
                }

            }
            else
            {
                if (facebookResponse is not null && !facebookResponse.IsSuccess)
                {
                    facebookResponse.Errors.ForEach(response.AddError);
                    return response;
                }
            }
        }

        await _context.SaveChangesAsync().ConfigureAwait(false);

        foreach (var socialAccountItem in socialAccounts)
        {
            GetSocialAccount? socialAccountDTO = null;

            if (socialAccountItem.Type == SocialAccountType.LinkedIn)
                socialAccountDTO = MapSocialAccount(socialAccountItem, profileDetails, null);
            socialAccountDTO = MapSocialAccount(socialAccountItem, null, null, false);

            response.SocialAccounts.Add(socialAccountDTO);
        }
        //response.SocialAccounts = socialAccount is not null ? MapSocialAccount(socialAccount, profileDetails, null) : null;
        return response;
    }

    async ValueTask<DisconnectSocialAccountResponse> ISocialAccountRepository<SocialAccount>.DisconnectSocialAccountAsync(string userAccountId, DisconnectSocialAccountDTO request, string? modifiedBy)
    {
        var response = new DisconnectSocialAccountResponse();
        var userAccount = await _userManager.FindByIdAsync(userAccountId).ConfigureAwait(false);

        if (userAccount is null)
        {
            response.AddError(_userNotFoundError);
            return response;
        }

        var socialAccount = await _context.SocialAccount
            .Include(x => x.ApplicationUser)
            .ThenInclude(au => au!.UserAccount)
            .FirstOrDefaultAsync(sa => sa.ApplicationUserId == userAccountId && sa.Id == request.SocialAccountId && sa.IsActive);

        if (socialAccount is null)
        {
            response.AddError(_socialAccountNotFoundError);
            return response;
        }

        //if useraccount is null it means that socialaccount or applicationuser have not been created properly. what should we do in this case?
        //_planValidator.IsSubscriptionValid(socialAccount.ApplicationUser!.UserAccount);

        socialAccount.IsActive = false;
        socialAccount.ModifiedBy = modifiedBy;
        socialAccount.ModifiedDate = DateTimeOffset.UtcNow;

        await _context.SaveChangesAsync().ConfigureAwait(false);

        response.SocialAccount = MapSocialAccount(socialAccount, null, null, false);
        return response;
    }

    async ValueTask<GetSocialAccountResponse> ISocialAccountRepository<SocialAccount>.GetConnectedSocialAccountsByUserIdAsync(string userAccountId)
    {
        var response = new GetSocialAccountResponse();
        IList<GetSocialAccount> socialProfiles = [];

        var socialAccounts = await _context.SocialAccount
           .Where(sa => sa.IsActive && sa.ApplicationUserId == userAccountId || sa.Managers.Select(m => m.Id).Contains(userAccountId))
           .OrderByDescending(sa => sa.Type)
           .GroupBy(s => s.SocialAccountId)
           .Select(g => g.FirstOrDefault())
           .ToListAsync();

        foreach (var socialAccount in socialAccounts)
        {
            if (socialAccount is null)
                continue;

            if (socialAccount.Type == SocialAccountType.LinkedIn)
            {
                var profileDetails = await _linkedInService.GetUserProfileAsync(socialAccount.AuthToken).ConfigureAwait(false);
                if (profileDetails is not null && profileDetails.IsSuccess)
                {
                    socialAccount.SocialAccountId = profileDetails?.UserProfile?.SocialAccountId;
                    socialAccount.FirstName = profileDetails?.UserProfile?.FirstName;
                    socialAccount.LastName = profileDetails?.UserProfile?.LastName;
                    socialAccount.VanityName = profileDetails?.UserProfile?.VanityName;
                    socialAccount.Headline = profileDetails?.UserProfile?.Headline;
                    socialAccount.ProfilePicture = profileDetails?.UserProfile?.ProfilePicture;
                }

                var profile = MapSocialAccount(socialAccount, profileDetails, null);
                socialProfiles.Add(profile);
            }
            else if (socialAccount.Type == SocialAccountType.Facebook)
            {
                var profileDetails = await _facebookService.GetUserProfileAsync(socialAccount.AuthToken)
                    .ConfigureAwait(false);

                if (profileDetails is null)
                    continue;

                if (!profileDetails.IsSuccess)
                {
                    var oldFacebookProfile = MapSocialAccount(socialAccount, profileDetails, null);
                    socialProfiles.Add(oldFacebookProfile);
                    continue;
                }

                socialAccount.AuthToken = socialAccount.AuthToken;
                socialAccount.SocialAccountId = profileDetails?.UserProfile?.SocialAccountId;
                socialAccount.FirstName = profileDetails?.UserProfile?.FirstName;
                socialAccount.LastName = profileDetails?.UserProfile?.LastName;
                socialAccount.ProfilePicture = profileDetails?.UserProfile?.ProfilePicture;
                socialAccount.Type = SocialAccountType.Facebook;
                //socialAccount.ApplicationUserId = userAccountId;

                var facebookProfile = MapSocialAccount(socialAccount, profileDetails, null);
                socialProfiles.Add(facebookProfile);
            }
            else if (socialAccount.Type == SocialAccountType.Instagram)
            {
                //insta headline is facebook id
                //insta vanityName is facebook access token
                var facebookPageDetails = await _facebookService.GetPagesDetailsAsync(socialAccount.VanityName, socialAccount.Headline ?? "").ConfigureAwait(false);

                if (facebookPageDetails is null)
                    continue;

                if (!facebookPageDetails.IsSuccess)
                {
                    var oldInstagramAccount = MapSocialAccount(socialAccount, null, null, false);
                    facebookPageDetails.Errors.ForEach(oldInstagramAccount.AddError);
                    continue;//
                }

                foreach (var item in facebookPageDetails.Pages)
                {
                    if (item.InstagramBusinessAccount is null)
                        continue;

                    var instagramId = item.InstagramBusinessAccount?.Id ?? string.Empty;
                    var instagramAccount = socialAccounts.FirstOrDefault(x => x.SocialAccountId == instagramId);

                    if (instagramAccount is null)
                        continue;

                    instagramAccount.AuthToken = item.AccessToken;
                    instagramAccount.SocialAccountId = item.InstagramBusinessAccount?.Id;
                    instagramAccount.FirstName = item.InstagramBusinessAccount?.Name;
                    instagramAccount.ProfilePicture = item.InstagramBusinessAccount?.ProfilePicture;
                    instagramAccount.Type = SocialAccountType.Instagram;
                    //instagramAccount.ApplicationUserId = userAccountId;

                    var profile = MapSocialAccount(instagramAccount, null, null, false);
                    socialProfiles.Add(profile);

                    //socialAccounts.Remove(instagramAccount);
                }
            }
        }

        await SaveChangesAsync().ConfigureAwait(false);

        response.SocialAccounts = socialProfiles;
        return response;
    }

    async ValueTask<GetSocialAccountResponse> ISocialAccountRepository<SocialAccount>.GetSocialAccountsListByUserIdAsync(string userAccountId)
    {
        var response = new GetSocialAccountResponse();
        IList<GetSocialAccount> socialProfiles = [];
        IList<Task> tasks = [];

        var socialAccounts = await _context.SocialAccount
           .Where(sa => sa.IsActive && sa.ApplicationUserId == userAccountId || sa.Managers.Select(m => m.Id).Contains(userAccountId))
           .OrderByDescending(sa => sa.Type)
           .GroupBy(g => g.SocialAccountId)
           .Select(g => g.FirstOrDefault())
           .ToListAsync();

        if (socialAccounts is null || socialAccounts.Count == 0)
            return response;

        foreach (var socialAccount in socialAccounts)
        {
            tasks.Add(Task.Run(() => GetSocialAccountListAsync(userAccountId, response, socialProfiles, socialAccounts, socialAccount)));
        }

        if (tasks.Any())
            await Task.WhenAll(tasks);

        await SaveChangesAsync().ConfigureAwait(false);

        response.SocialAccounts = socialProfiles;
        return response;
    }

    private async Task GetSocialAccountListAsync(string userAccountId, GetSocialAccountResponse response, IList<GetSocialAccount> socialProfiles, List<SocialAccount?>? socialAccounts, SocialAccount? socialAccount)
    {
        if (socialAccounts is null || socialAccount is null)
            return;
        if (socialAccount.Type == SocialAccountType.LinkedIn)
        {
            var profileDetails = await _linkedInService.GetUserProfileAsync(socialAccount.AuthToken).ConfigureAwait(false);
            if (profileDetails is not null && profileDetails.IsSuccess)
            {
                socialAccount.SocialAccountId = profileDetails?.UserProfile?.SocialAccountId;
                socialAccount.FirstName = profileDetails?.UserProfile?.FirstName;
                socialAccount.LastName = profileDetails?.UserProfile?.LastName;
                socialAccount.VanityName = profileDetails?.UserProfile?.VanityName;
                socialAccount.Headline = profileDetails?.UserProfile?.Headline;
                socialAccount.ProfilePicture = profileDetails?.UserProfile?.ProfilePicture;
            }

            var profilePages = await _linkedInService.GetOrganizationsAsync(socialAccount.AuthToken ?? "").ConfigureAwait(false);

            if (profilePages is not null && profilePages.IsSuccess && profilePages.OrganizationDetails.Count() > 0)
            {
                foreach (var page in profilePages.OrganizationDetails)
                {
                    var pageItem = page.Organization is null ? null : new GetPageDTO
                    {
                        Id = page.Organization.Id,
                        Name = page.Organization.LocalizedName,
                    };

                    var profile = MapSocialAccount(socialAccount, profileDetails, pageItem);
                    socialProfiles.Add(profile);
                }
            }
            else
            {
                var profile = MapSocialAccount(socialAccount, profileDetails, null);
                profile.AddError("No pages in linkedin account");
                socialProfiles.Add(profile);
            }
        }
        else if (socialAccount.Type == SocialAccountType.Facebook)
        {
            var profileDetails = await _facebookService.GetUserProfileAsync(socialAccount.AuthToken)
                .ConfigureAwait(false);

            if (profileDetails is null)
                return;

            if (!profileDetails.IsSuccess)
            {
                var profile = MapSocialAccount(socialAccount, profileDetails, null);
                return;
            }

            socialAccount.AuthToken = socialAccount.AuthToken;
            socialAccount.SocialAccountId = profileDetails?.UserProfile?.SocialAccountId;
            socialAccount.FirstName = profileDetails?.UserProfile?.FirstName;
            socialAccount.LastName = profileDetails?.UserProfile?.LastName;
            socialAccount.ProfilePicture = profileDetails?.UserProfile?.ProfilePicture;
            socialAccount.Type = SocialAccountType.Facebook;
            //socialAccount.ApplicationUserId = userAccountId;

            var facebookPageDetails = await _facebookService.GetPagesDetailsAsync(socialAccount.AuthToken, socialAccount.SocialAccountId ?? "").ConfigureAwait(false);

            if (facebookPageDetails is null)
                return;

            if (!facebookPageDetails.IsSuccess)
            {
                var profile = MapSocialAccount(socialAccount, profileDetails, null);
                facebookPageDetails.Errors.ForEach(profile.Errors.Add);
                return;
            }

            if (facebookPageDetails.Pages.Count == 0)
            {
                var profile = MapSocialAccount(socialAccount, profileDetails, null);
                profile.AddError("No pages in facebook account");
                socialProfiles.Add(profile);
            }

            foreach (var item in facebookPageDetails.Pages)
            {
                var pageItem = new GetPageDTO
                {
                    Id = item.Id,
                    Name = item.Name,
                };

                var facebookProfile = MapSocialAccount(socialAccount, profileDetails, pageItem);
                socialProfiles.Add(facebookProfile);
            }
        }
        else if (socialAccount.Type == SocialAccountType.Instagram)
        {
            var facebookPageDetails = await _facebookService.GetPagesDetailsAsync(socialAccount.VanityName, socialAccount.Headline ?? "").ConfigureAwait(false);

            if (facebookPageDetails is null)
                return;

            if (!facebookPageDetails.IsSuccess)
            {
                var profile = MapSocialAccount(socialAccount, null, null, false);
                facebookPageDetails.Errors.ForEach(profile.Errors.Add);
                return;
            }

            if (facebookPageDetails.Pages.Count == 0)
            {
                var profile = MapSocialAccount(socialAccount, null, null, false);
                profile.AddError("No pages in instagram account");
                socialProfiles.Add(profile);
            }

            foreach (var item in facebookPageDetails.Pages)
            {
                var instagramId = item.InstagramBusinessAccount?.Id ?? string.Empty;
                var instagramAccount = socialAccounts.FirstOrDefault(x => x.SocialAccountId == instagramId);

                if (instagramAccount is null)
                    continue;

                instagramAccount.AuthToken = item.AccessToken;
                instagramAccount.SocialAccountId = item.InstagramBusinessAccount?.Id;
                instagramAccount.FirstName = item.InstagramBusinessAccount?.Name;
                instagramAccount.ProfilePicture = item.InstagramBusinessAccount?.ProfilePicture;
                instagramAccount.Type = SocialAccountType.Instagram;
                //instagramAccount.ApplicationUserId = userAccountId;

                var pageItem = new GetPageDTO
                {
                    Id = item.InstagramBusinessAccount?.Id,
                    Name = item.InstagramBusinessAccount?.Name
                };

                var profile = MapSocialAccount(instagramAccount, null, pageItem, false);
                socialProfiles.Add(profile);

                socialAccounts.Remove(instagramAccount);
            }
        }
    }

    async ValueTask<AllAnalyticsDTO> ISocialAccountRepository<SocialAccount>.GetSocialAccountAnalytics(IList<SocialAccount> socialAccounts)
    {
        var analytics = new AllAnalyticsDTO();
        IList<GetPageDTO> pages = [];
        GetStatisticsResponse? socialAccountStats = null;
        IList<AnalyticsGraph> impressions = [];
        IList<AnalyticsGraph> engagment = [];
        IList<AnalyticsGraph> audience = [];
        IList<Task> tasks = [];

        foreach (var socialAccount in socialAccounts)
        {
            tasks.Add(GetSocialAccountAnalyticsAsync(analytics, pages, socialAccountStats, impressions, engagment, audience, socialAccount));
        }

        if (tasks.Any())
            await Task.WhenAll(tasks);

        analytics.TotalImpressionsGraph = MergeGraph(impressions);
        analytics.TotalEngagmentGraph = MergeGraph(engagment);
        analytics.TotalAudianceGraph = MergeGraph(audience);

        return analytics;
    }

    private async Task GetSocialAccountAnalyticsAsync(AllAnalyticsDTO analytics, IList<GetPageDTO> pages, GetStatisticsResponse? socialAccountStats, IList<AnalyticsGraph> impressions, IList<AnalyticsGraph> engagment, IList<AnalyticsGraph> audience, SocialAccount socialAccount)
    {
        if (socialAccount.Type == SocialAccountType.LinkedIn)
        {
            var profilePages = await _linkedInService.GetOrganizationsAsync(socialAccount.AuthToken ?? "").ConfigureAwait(false);
            pages.Clear();

            if (profilePages is null || !profilePages.IsSuccess)
                return;

            foreach (var page in profilePages.OrganizationDetails)
            {
                if (page.Organization is null || page.Organization.Id is null || page.Organization.LocalizedName is null)
                    continue;

                socialAccountStats = await _linkedInService.GetStatisticsAsync(socialAccount.AuthToken ?? "", page.Organization.Id).ConfigureAwait(false);

                if (socialAccountStats is null || socialAccountStats.Statistic is null)
                    continue;

                var socialAccountAnalytic = MapSocialAccountAnalytics(socialAccount, page.Organization.Id, page.Organization.LocalizedName, impressions, engagment, audience, socialAccountStats.Statistic);
                analytics.SocialAccountAnalytics.Add(socialAccountAnalytic);
            }
        }
        else if (socialAccount.Type == SocialAccountType.Instagram)
        {
            socialAccountStats = await _instagramService.GetStatisticsAsync(socialAccount.AuthToken, socialAccount.SocialAccountId ?? "").ConfigureAwait(false);

            if (socialAccountStats is null || socialAccountStats.Statistic is null)
                return;

            var socialAccountAnalytics = MapSocialAccountAnalytics(socialAccount, socialAccount.SocialAccountId, socialAccount.FirstName, impressions, engagment, audience, socialAccountStats.Statistic);
            analytics.SocialAccountAnalytics.Add(socialAccountAnalytics);
        }
        else if (socialAccount.Type == SocialAccountType.Facebook)
        {
            var profilePages = await _facebookService.GetPagesDetailsAsync(socialAccount.AuthToken, socialAccount.SocialAccountId ?? "").ConfigureAwait(false);
            pages.Clear();

            if (profilePages is null || !profilePages.IsSuccess)
                return;

            foreach (var page in profilePages.Pages)
            {
                if (page.Id is null || page.Name is null)
                    continue;

                socialAccountStats = await _facebookService.GetStatisticsAsync(page.AccessToken, page.Id).ConfigureAwait(false);

                if (socialAccountStats is null || socialAccountStats.Statistic is null)
                    continue;

                var socialAccountAnalytic = MapSocialAccountAnalytics(socialAccount, page.Id, page.Name, impressions, engagment, audience, socialAccountStats.Statistic);
                analytics.SocialAccountAnalytics.Add(socialAccountAnalytic);
            }
        }

        return;
    }

    async ValueTask<PublishResponse> ISocialAccountRepository<SocialAccount>.HandlePostPublishAsync(Post post)
    {
        var response = new PublishResponse();
        return await HandlePostPublishAsync(post).ConfigureAwait(false);
    }

    private async ValueTask<PublishResponse> HandlePostPublishAsync(Post post)
    {
        var response = new PublishResponse();

        if (post is null || post.SocialAccount is null)
        {
            response.AddError(_postNotFoundError);
            return response;
        }

        string content = Regex.Replace(post.Content, "<.*?>", string.Empty);

        if (post.SocialAccount.Type == SocialAccountType.Facebook)
        {
            IList<string> imageUrls = [];

            foreach (var image in post.Images)
            {
                var url = _fileService.GetFileURL(image.FileName);
                imageUrls.Add(url);
            }

            var profileDetails = await _facebookService.GetPagesDetailsAsync(post.SocialAccount.AuthToken, post.SocialAccount.SocialAccountId ?? "").ConfigureAwait(false);

            if (profileDetails is null)
            {
                response.AddError(_facebookpageDetailsNotFoundError);
                return response;
            }

            if (!profileDetails.IsSuccess)
            {
                profileDetails.Errors.ForEach(response.AddError);
                return response;
            }

            var profilePage = profileDetails.Pages.FirstOrDefault(p => p.Id == post.PageId);

            if (profilePage is null || profilePage.AccessToken is null)
            {
                response.AddError(_facebookpageDetailsNotFoundError);
                return response;
            }

            var facebookResponse = await _facebookService.PostToPageAsync(
                profilePage.AccessToken,
                [],
                AppEnvironment.Type == EnvironmentType.PROD ? imageUrls : ["https://plus.unsplash.com/premium_photo-1683727986626-355d473cb936?q=80&w=2000&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D", "https://images.unsplash.com/photo-1549813069-f95e44d7f498?q=80&w=1956&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"],
                post.PageId,
                content)
                .ConfigureAwait(false);

            if (facebookResponse is null)
            {
                response.AddError(_facebookPublisError);
                return response;
            }

            if (facebookResponse.Id is null)
            {
                facebookResponse.Errors.ForEach(response.AddError);
                return response;
            }

            post.PublishedPostId = facebookResponse.Id;
            post.PublishedBy = post.ModifiedBy ?? post.CreatedBy;
            post.PublishDate = DateTimeOffset.UtcNow;
            return response;
        }
        else if (post.SocialAccount.Type == SocialAccountType.LinkedIn)
        {
            IList<string> imageUrls = [];

            foreach (var image in post.Images)
            {
                var url = _fileService.GetFileURL(image.FileName);
                imageUrls.Add(url);
            }

            //get new access token?
            var linkedinResponse = await _linkedInService.PostContentAsync(
                post.SocialAccount.AuthToken ?? "",
                post.PageId,
                AppEnvironment.Type == EnvironmentType.PROD ? imageUrls : ["https://images.unsplash.com/photo-1592093506632-92ef342e2591?q=80&w=1976&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D", "https://images.unsplash.com/photo-1592093947163-51f1d258d110?q=80&w=2025&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"],
                content)
                .ConfigureAwait(false);

            if (linkedinResponse is null)
            {
                response.AddError(_linkedInPublisError);
                return response;
            }

            if (linkedinResponse.Id is null)
            {
                linkedinResponse.Errors.ForEach(response.AddError);
                return response;
            }

            post.PublishedPostId = linkedinResponse.Id;
            post.PublishedBy = post.ModifiedBy ?? post.CreatedBy;
            post.PublishDate = DateTimeOffset.UtcNow;
            return response;
        }
        else if (post.SocialAccount.Type == SocialAccountType.Instagram)
        {
            IList<string> imageUrls = [];

            foreach (var image in post.Images)
            {
                var url = _fileService.GetFileURL(image.FileName);
                imageUrls.Add(url);
            }

            //get new access token?
            var instagramResponse = await _instagramService.PostContantAsync(
                post.SocialAccount.AuthToken ?? "",
                post.SocialAccount.SocialAccountId ?? "",
                AppEnvironment.Type == EnvironmentType.PROD ? imageUrls : ["https://images.unsplash.com/photo-1572573309811-48474d1891b7?q=80&w=1964&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D", "https://images.unsplash.com/photo-1611162618758-2a29a995354b?q=80&w=2127&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"],
                content)
                .ConfigureAwait(false);

            if (instagramResponse is null)
            {
                response.AddError(_instagramPublisError);
                return response;
            }

            if (instagramResponse.Id is null)
            {
                instagramResponse.Errors.ForEach(response.AddError);
                return response;
            }

            post.PublishedPostId = instagramResponse.Id;
            post.PublishedBy = post.ModifiedBy ?? post.CreatedBy;
            post.PublishDate = DateTimeOffset.UtcNow;
            return response;
        }
        response.AddError(_invalidSocialAccountTypeError);
        return response;
    }

    private GetSocialAccount MapSocialAccount(SocialAccount socialAccount, GetUserProfileResponse? linkedInGetUserProfileResponse, GetPageDTO? page, bool checkCondition = true)
    {
        var response = new GetSocialAccount
        {
            Id = socialAccount.Id,
            AuthToken = socialAccount.AuthToken,
            SocialAccountId = socialAccount.SocialAccountId,
            FirstName = socialAccount.FirstName,
            LastName = socialAccount.LastName,
            VanityName = socialAccount.VanityName,
            Headline = socialAccount.Headline,
            ProfilePicture = socialAccount.ProfilePicture,
            Type = socialAccount.Type,
            PageId = page?.Id ?? string.Empty,
            PageName = page?.Name ?? string.Empty,
            ModifiedBy = socialAccount.ModifiedBy,
            ModifiedDate = socialAccount.ModifiedDate,
            CreatedBy = socialAccount.CreatedBy,
            CreatedDate = socialAccount.CreatedDate
        };

        if (checkCondition)
        {
            if (linkedInGetUserProfileResponse is not null)
            {
                linkedInGetUserProfileResponse.Errors.ForEach(response.AddError);
            }
            else
            {
                response.AddError(AppEnvironment.GenericSQLDatabaseError);
            }
        }


        return response;
    }

    private SocialAccountAnalyticsDTO MapSocialAccountAnalytics(SocialAccount socialAccount, string? pageId, string? pageName, IList<AnalyticsGraph> impressions, IList<AnalyticsGraph> engagment, IList<AnalyticsGraph> audience, StatisticsResponse statistics)
    {
        if (statistics.TotalImpression.XAxis.Count > 0)//is this necessary?
        {
            var impressionGraph = new AnalyticsGraph
            {
                YAxis = statistics.TotalImpression.XAxis,
                XAxis = statistics.TotalImpression.YAxis.Select(x => x.ToString("dd-MMM").Replace("-", " ")).ToList(),
            };

            impressions.Add(impressionGraph);
        }

        if (statistics.TotalEngagement.XAxis.Count > 0)
        {
            var engagmentGraph = new AnalyticsGraph
            {
                YAxis = statistics.TotalEngagement.XAxis,
                XAxis = statistics.TotalEngagement.YAxis.Select(x => x.ToString("dd-MMM").Replace("-", " ")).ToList(),
            };

            engagment.Add(engagmentGraph);
        }

        if (statistics.TotalAudience.XAxis.Count > 0)
        {
            var audienceGraph = new AnalyticsGraph
            {
                YAxis = statistics.TotalAudience.XAxis,
                XAxis = statistics.TotalAudience.YAxis.Select(x => x.ToString("dd-MMM").Replace("-", " ")).ToList(),
            };

            audience.Add(audienceGraph);
        }

        return new SocialAccountAnalyticsDTO
        {
            Id = socialAccount.Id,
            FirstName = socialAccount.FirstName,
            LastName = socialAccount.LastName,
            ProfilePicture = socialAccount.ProfilePicture,
            Type = socialAccount.Type,
            PageId = pageId,
            PageName = pageName,
            //PageId = socialAccount.Type != SocialAccountType.Instagram ?
            //            pageId :
            //        socialAccount.SocialAccountId,
            //PageName = socialAccount.Type != SocialAccountType.Instagram ?
            //            pageName :
            //        socialAccount.FirstName,
            Impressions = statistics.TotalImpression.Total,
            EngagmentRate = statistics.TotalEngagement.Total,
            Followers = statistics.TotalAudience.Total,
        };
    }

    private AnalyticsGraph MergeGraph(IList<AnalyticsGraph> graphs)
    {
        var combinedGraph = new AnalyticsGraph();
        IList<int> yAxis = [];
        IList<string> xAxis = [];

        for (var i = 0; i < 7; i++)
        {
            var total = 0;
            var date = "";

            foreach (var graph in graphs)
            {
                total += graph.YAxis[i];
                date = graph.XAxis[i];
            }

            yAxis.Add(total);
            xAxis.Add(date);
        }

        combinedGraph.YAxis = yAxis;
        combinedGraph.XAxis = xAxis;

        if (combinedGraph.YAxis[6] < 1000)
            combinedGraph.Total = yAxis[6].ToString();
        else if (combinedGraph.YAxis[6] < 1000000)
            combinedGraph.Total = $"{yAxis[6] / 1000} K";
        else if (combinedGraph.YAxis[6] >= 1000000)
            combinedGraph.Total = combinedGraph.Total = $"{yAxis[6] / 1000000} M";

        var insightsGain = combinedGraph.YAxis[0] - combinedGraph.YAxis[6];

        if (insightsGain < 0)
        {
            combinedGraph.Percentage = (combinedGraph.YAxis[6] / (combinedGraph.YAxis[0] == 0 ? 1 : combinedGraph.YAxis[0]) * 100).ToString();
        }
        else
        {
            combinedGraph.Percentage = (combinedGraph.YAxis[0] / (combinedGraph.YAxis[6] == 0 ? 1 : combinedGraph.YAxis[6]) * 100).ToString();
            combinedGraph.IsNegative = true;
        }

        int start = combinedGraph.YAxis[0];
        int end = combinedGraph.YAxis[6];

        if (end < 1000)
            combinedGraph.Total = end.ToString();
        else if (end < 1000000)
            combinedGraph.Total = $"{end / 1000} K";
        else if (end >= 1000000)
            combinedGraph.Total = $"{end / 1000000} M";

        double denominator = start == 0 ? 1 : (double)start;
        double numerator = Math.Abs(start - end);
        combinedGraph.Percentage = $"{(numerator / denominator) * 100:F2}%";
        combinedGraph.IsNegative = start > end;

        return combinedGraph;
    }

    private async Task PublishPost(Post post)
    {
        bool isManager = post!.SocialAccount!.ApplicationUserId != post.ApplicationUserId ? true : false;
        _planValidator.IsSubscriptionValid(post!.SocialAccount!.ApplicationUser!.UserAccount, isManager);

        post.PublishedBy = post.CreatedBy;

        var response = await HandlePostPublishAsync(post).ConfigureAwait(false);

        if (response.IsSuccess)
        {
            post.Status = PostStatus.Published;
            post.PublishedBy = post.ModifiedBy ?? post.CreatedBy;
        }
        else
            post.Status = PostStatus.Failed;

        post.ModifiedDate = DateTimeOffset.UtcNow;

        await _context.SaveChangesAsync().ConfigureAwait(false);
    }

    public async Task Invoke()
    {
        var posts = await _context.Post
            .Where(x => x.IsActive &&
                        x.Status == PostStatus.Queue &&
                        (x.ScheduledDate.HasValue ?
                            x.ScheduledDate.Value.Date < DateTimeOffset.UtcNow.Date ||
                            (x.ScheduledDate.Value.Date == DateTimeOffset.UtcNow.Date && x.ScheduledDate.Value.TimeOfDay <= DateTimeOffset.UtcNow.TimeOfDay) :
                        false))
            .Include(x => x.SocialAccount)
                .ThenInclude(sa => sa!.ApplicationUser)
                    .ThenInclude(au => au!.UserAccount)
            .ToListAsync()
            .ConfigureAwait(false);

        foreach (var post in posts.ToList())
        {
            //if (post.SocialAccount is null || post.SocialAccount.ApplicationUser is null || post.SocialAccount.ApplicationUser.UserAccount is null)
            //{
            //    posts.Remove(post);
            //    continue;
            //}

            //var status = post.SocialAccount.ApplicationUser.UserAccount.SubscriptionStatus;

            //if (status == UserAccounts.Entities.SubscriptionStatus.active || status == UserAccounts.Entities.SubscriptionStatus.trialing)
            //    continue;

            posts.Remove(post);
        }

        if (posts.Count == 0)
            return;

        IList<Task> tasks = [];

        foreach (var post in posts)
            tasks.Add(Task.Run(() => PublishPost(post)));

        if (tasks.Any())
            await Task.WhenAll(tasks);
    }

}