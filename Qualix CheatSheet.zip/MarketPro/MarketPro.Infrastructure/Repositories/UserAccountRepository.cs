﻿using AutoMapper;
using MarketPro.Data;
using MarketPro.Identity.DTOs;
using MarketPro.Identity.Entities;
using MarketPro.IRepositories;
using MarketPro.UserAccounts.DTOs;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;

namespace MarketPro.Repositories;

public class UserAccountRepository : IUserAccountRepository
{
    private const string _theUserDoesNotExistError = "The user does not exist.";

    private readonly IAuthRepository _authRepository;
    private readonly ApplicationDbContext _context;
    private readonly IMapper _mapper;
    private readonly UserManager<ApplicationUser> _userManager;
    private readonly CurrentUser _currentUser;

    public UserAccountRepository(IAuthRepository authRepository, ApplicationDbContext context, IMapper mapper, UserManager<ApplicationUser> userManager, IHttpContextAccessor httpContextAccessor)
    {
        _authRepository = authRepository ?? throw new ArgumentNullException(nameof(authRepository));
        _context = context ?? throw new ArgumentNullException(nameof(context));
        _mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));
        _userManager = userManager ?? throw new ArgumentNullException(nameof(userManager));
        _currentUser = new CurrentUser(httpContextAccessor);
    }
    async ValueTask<AuthResponse> IUserAccountRepository.UpdateUserAsync(string id, UpdateUserRequest request, string? modifiedBy)
    {
        var response = new AuthResponse();

        var user = await _context.Users
            .Include(x => x.ProfileImage)
            .Include(x => x.UserAccount)
            .Include(x => x.AdminAccount)
            .FirstOrDefaultAsync(x => x.IsActive && x.Id == _currentUser.Id)
            .ConfigureAwait(false);

        if (user is null)
        {
            response.AddError(_theUserDoesNotExistError);
            return response;
        }

        var userAccount = user.UserAccount ?? user.AdminAccount;

        if (request.FirstName is not null)
        {
            user.FirstName = request.FirstName ?? "First Name";
            user.LastName = request.LastName ?? "";
            user.ModifiedBy = modifiedBy;
            user.ModifiedDate = DateTimeOffset.Now;

            await _userManager.UpdateAsync(user).ConfigureAwait(false);
        }

        if (userAccount is not null)
        {
            userAccount.TargetAudienceDescription = request.TargetAudienceDescription ?? userAccount.TargetAudienceDescription;
            userAccount.BusinessDescription = request.BusinessDescription ?? userAccount.BusinessDescription;
            userAccount.Plan = request.Plan ?? userAccount.Plan;
            userAccount.ModifiedBy = modifiedBy;
            userAccount.ModifiedDate = DateTimeOffset.Now;
        }

        await _context.SaveChangesAsync().ConfigureAwait(false);

        response.User = await _authRepository.MapAuthResponseAsync(user, userAccount);

        return response;
    }

    async ValueTask<AuthResponse> IUserAccountRepository.GetUserPlanAsync()
    {
        var response = new AuthResponse();

        var user = await _context.Users
            .Include(x => x.ProfileImage)
            .Include(x => x.UserAccount)
            .Include(x => x.AdminAccount)
            .FirstOrDefaultAsync(x => x.IsActive && x.Id == _currentUser.Id)
            .ConfigureAwait(false);

        if (user is null)
        {
            response.AddError(_theUserDoesNotExistError);
            return response;
        }

        response.User = await _authRepository.MapAuthResponseAsync(user, user.UserAccount ?? user.AdminAccount);

        return response;
    }

}