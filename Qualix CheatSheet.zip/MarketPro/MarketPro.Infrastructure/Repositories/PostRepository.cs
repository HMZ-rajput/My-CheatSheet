﻿using AutoMapper;
using MarketPro.Common.DTOs;
using MarketPro.Data;
using MarketPro.Documents.DTOs;
using MarketPro.Documents.Entities;
using MarketPro.Posts.DTOs;
using MarketPro.Posts.Entities;
using MarketPro.Services;
using MarketPro.SocialAccounts.DTOs;
using MarketPro.SocialAccounts.Entities;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;

namespace MarketPro.Repositories;

public class PostRepository :
    BaseRepository<Post>,
    IPostRepository<Post>
{
    private const string _postNotFoundError = "Post does not exsist.";
    private const string _socialAccountNotFoundError = "Social Account does not exist";
    private const string _socialAccountRequiredError = "Atleast one social account is required";
    private const string _postCreateError = "Something went wrong when creating post.";
    private const string _postContentError = "Content or Image is required to schedule or publish a post.";
    private const string _instagramPostCreateError = "Can not create or schedule instagram post without an image.";
    private const string _publishPostError = "Post is already published.";

    private readonly ApplicationDbContext _context;
    private readonly IMapper _mapper;
    private readonly IFileService _fileService;
    private readonly ISocialAccountRepository<SocialAccount> _socialAccountRepository;
    private readonly IPlanRuleValidator _planRuleValidator;

    public PostRepository(ApplicationDbContext context, IMapper mapper, IFileService fileService, ISocialAccountRepository<SocialAccount> socialAccountRepository, IPlanRuleValidator planRuleValidator) : base(context)
    {
        _context = context ?? throw new ArgumentNullException(nameof(context));
        _mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));
        _fileService = fileService ?? throw new ArgumentNullException(nameof(fileService));
        _socialAccountRepository = socialAccountRepository ?? throw new ArgumentNullException(nameof(socialAccountRepository));
        _planRuleValidator = planRuleValidator ?? throw new ArgumentNullException(nameof(planRuleValidator));
    }

    async ValueTask<PostsResponse> IPostRepository<Post>.CreatePostsAsync(string userId, CreatePostDTO request)
    {
        var response = new PostsResponse();
        IList<Document> images = [];
        IList<Post> posts = [];
        IList<GetPostDTO> postsResponse = [];

        var socialAccountIds = request.SocialAccounts.Select(x => x.Id).Distinct().ToList();

        var socialAccounts = await _context.SocialAccount
            .Where(x => x.IsActive &&
                        (x.ApplicationUserId == userId || x.Managers.Select(m => m.Id).Contains(userId)) &&
                        socialAccountIds.Contains(x.Id))
            .Include(x => x.ApplicationUser)
            .ThenInclude(au => au!.UserAccount)
            .ToListAsync()
            .ConfigureAwait(false);

        if (socialAccounts.Count == 0)
        {
            response.AddError(_socialAccountRequiredError);
            return response;
        }

        bool isManager = socialAccounts.First()?.ApplicationUserId != userId ? true : false;
        _planRuleValidator.IsSubscriptionValid(socialAccounts.First()!.ApplicationUser!.UserAccount, isManager);

        if(request.Status == PostStatus.Queue)
            _planRuleValidator.CanQueuePost(socialAccounts.First()!.ApplicationUser!.UserAccount);

        foreach (var socialAccount in socialAccounts)
        {
            var pages = request.SocialAccounts.Where(x => x.Id == socialAccount.Id).Select(x => new { x.PageId, x.PageName }).ToList();

            if (socialAccount.Type == SocialAccountType.Instagram && request.Status != PostStatus.Draft && request.InstagramImages.Count == 0 && request.InstagramImagesUrl.Count == 0)
            {
                response.AddError(_instagramPostCreateError);
                return response;
            }

            if (socialAccount.Type == SocialAccountType.Instagram)
            {
                var pageId = request.SocialAccounts.FirstOrDefault(i => i.Id == socialAccount.Id)?.PageId;
                var pageName = request.SocialAccounts.FirstOrDefault(i => i.Id == socialAccount.Id)?.PageName;
                var post = await CreatePost(request, socialAccount, pageId, pageName, images, userId, _fileService).ConfigureAwait(false);

                if (post is null)
                {
                    response.AddError(_postCreateError);
                    return response;
                }

                post.SocialAccount = socialAccount;
                posts.Add(post);
                socialAccount.Posts.Add(post);

                continue;
            }

            foreach (var page in pages)
            {
                var post = await CreatePost(request, socialAccount, page.PageId, page.PageName, images, userId, _fileService).ConfigureAwait(false);

                if (post is null)
                {
                    response.AddError(_postCreateError);
                    return response;
                }

                if (post.Status != PostStatus.Draft && string.IsNullOrEmpty(post.Content) && post.Images.Count == 0)
                {
                    response.AddError(_postContentError);
                    return response;
                }

                post.SocialAccount = socialAccount;
                posts.Add(post);
                socialAccount.Posts.Add(post);
            }

        }

        if (request.Status == PostStatus.Published)
        {
            IList<Task<GetPostDTO>> tasks = [];

            foreach (var post in posts)
                tasks.Add(Task.Run(() => PublishPost(post).AsTask()));

            if (tasks.Any())
            {
                var publishedPosts = await Task.WhenAll(tasks);

                foreach (var publishedPost in publishedPosts)
                    response.Posts.Add(publishedPost);
            }
        }
        else
            response.Posts = posts.Select(p => MapPost(p, _fileService)).ToList();

        await _context.AddRangeAsync(posts).ConfigureAwait(false);
        await _context.AddRangeAsync(images).ConfigureAwait(false);
        await _context.SaveChangesAsync().ConfigureAwait(false);

        return response;
    }

    async ValueTask<GetAllPostResponse> IPostRepository<Post>.GetAllPostsByUserIdAsync(string userId, PostFilters filters)
    {
        var response = new GetAllPostResponse();

        var userAccount = _context.UserAccount
            //.Include(x => x.Managers.Where(m => m.IsActive))
            .Include(x => x.Managers)
            .FirstOrDefault(x => x.IsActive && x.ApplicationUserId == userId);

        IList<string> managerIds = [];

        if (userAccount is not null)
        {
            managerIds = userAccount.Managers.Select(x => x.Id).ToList();
        }

        IQueryable<Post> query = _context.Post
            .Where(p => p.IsActive && (p.ApplicationUserId == userId || managerIds.Contains(p.ApplicationUserId ?? "")))
            .Include(p => p.SocialAccount)
            .Include(p => p.Images.Where(x => x.IsActive))
            .OrderByDescending(on => on.ModifiedDate)
            .AsQueryable();

        if (filters.StartDate is not null && filters.EndDate is not null)
        {
            query = query.Where(x =>
                (x.ScheduledDate!.Value.Date >= filters.StartDate.Value.Date && x.ScheduledDate!.Value.Date <= filters.EndDate.Value.Date)
                || (x.PublishDate!.Value.Date >= filters.StartDate.Value.Date && x.PublishDate!.Value.Date <= filters.EndDate.Value.Date)
                || (x.ModifiedDate!.Value.Date >= filters.StartDate.Value.Date && x.ModifiedDate.Value.Date <= filters.EndDate.Value.Date)
                            || (x.CreatedDate.Date >= filters.StartDate.Value.Date && x.CreatedDate.Date <= filters.EndDate.Value.Date));
            if (filters.Status is not null)
            {
                IList<PostStatus> status = [];
                filters.Status.Split(',').ToList().ForEach(x =>
                {
                    if (Enum.TryParse(x, true, out PostStatus y) && y != PostStatus.Draft)
                        status.Add(y);
                });
                query = query.Where(x => status.Contains(x.Status));
            }
            else
            {
                query = query.Where(x => x.Status != PostStatus.Draft);
            }

        }

        if (!filters.IsCalanderView && filters.Status is not null)
        {
            var status = filters.Status.Split(',').ToList();
            query = query.Where(x => status.Contains(((int)x.Status).ToString()));
        }

        if (filters.IsCalanderView)
            query = query.Where(x => x.Status != PostStatus.Draft);

        if (filters.SocialsAccountIds is not null)
        {
            var socialAccountIds = filters.SocialsAccountIds.Split(',').ToList();

            query = query.Where(x => socialAccountIds.Contains(x.SocialAccountId.ToString() ?? ""));
        }

        var formattedQuery = query.Select(z => MapPost(z, _fileService));

        var paginatedData = await PagedList<GetPostDTO>
            .ToPagedListAsync(
                formattedQuery,
                filters.PageNumber,
                filters.IsCalanderView ? int.MaxValue : filters.PageSize);

        response.Posts = paginatedData;
        response.CurrentPage = paginatedData.CurrentPage;
        response.TotalPages = paginatedData.TotalPages;
        response.PageSize = paginatedData.PageSize;
        response.TotalCount = paginatedData.TotalCount;
        response.HasPrevious = paginatedData.HasPrevious;
        response.HasNext = paginatedData.HasNext;

        return response;
    }

    async ValueTask<GetPostResponse> IPostRepository<Post>.GetPostByIdAsync(Guid postId, string userId)
    {
        var response = new GetPostResponse();

        var userAccount = _context.UserAccount
            //.Include(x => x.Managers.Where(m => m.IsActive))
            .Include(x => x.Managers)
            .FirstOrDefault(x => x.IsActive && x.ApplicationUserId == userId);

        IList<string> managerIds = [];

        if (userAccount is not null)
        {
            managerIds = userAccount.Managers.Select(x => x.Id).ToList();
        }

        var post = await _context.Post
            .Include(p => p.SocialAccount)
            .Include(p => p.Images.Where(x => x.IsActive))
            .FirstOrDefaultAsync(p => p.IsActive && (p.ApplicationUserId == userId || managerIds.Contains(p.ApplicationUserId ?? "")) && p.Id == postId)
            .ConfigureAwait(false);

        if (post is null)
        {
            response.AddError(_postNotFoundError);
            return response;
        }

        response.Post = MapPost(post, _fileService);

        return response;
    }

    async ValueTask<GetPostResponse> IPostRepository<Post>.DeletePostByIdAsync(Guid postId, string userId, string? modifiedBy)
    {
        var response = new GetPostResponse();

        var userAccount = _context.UserAccount
            //.Include(x => x.Managers.Where(m => m.IsActive))
            .Include(x => x.Managers)
            .FirstOrDefault(x => x.IsActive && x.ApplicationUserId == userId);

        IList<string> managerIds = [];

        if (userAccount is not null)
        {
            managerIds = userAccount.Managers.Select(x => x.Id).ToList();
        }

        var post = await _context.Post
            .Include(p => p.SocialAccount)
            .Include(p => p.Images.Where(x => x.IsActive))
            .Include(p => p.ApplicationUser)
                .ThenInclude(au => au!.AdminAccount)
            .FirstOrDefaultAsync(p => p.IsActive && (p.ApplicationUserId == userId || managerIds.Contains(p.ApplicationUserId ?? "")) && p.Id == postId)
            .ConfigureAwait(false);

        if (post is null)
        {
            response.AddError(_postNotFoundError);
            return response;
        }

        _planRuleValidator.IsSubscriptionValid(userAccount ?? post.ApplicationUser!.AdminAccount, userAccount is not null ? false : true);

        post.IsActive = false;
        post.ModifiedBy = modifiedBy;
        post.ModifiedDate = DateTimeOffset.UtcNow;

        await HandleImages(post, [], [], post.Images.Select(x => x.Id).ToList(), [], modifiedBy, _fileService).ConfigureAwait(false);

        await _context.SaveChangesAsync().ConfigureAwait(false);

        response.Post = MapPost(post, _fileService);

        return response;
    }

    async ValueTask<GetPostResponse> IPostRepository<Post>.UpdatePostAsync(Guid postId, string userId, UpdatePostDTO request)
    {
        var response = new GetPostResponse();
        IList<Document> images = [];

        var userAccount = _context.UserAccount
            //.Include(x => x.Managers.Where(m => m.IsActive))
            .Include(x => x.Managers)
            .FirstOrDefault(x => x.IsActive && x.ApplicationUserId == userId);

        IList<string> managerIds = [];

        if (userAccount is not null)
        {
            managerIds = userAccount.Managers.Select(x => x.Id).ToList();
        }

        var post = await _context.Post
            .Include(p => p.SocialAccount)
            .Include(p => p.Images.Where(x => x.IsActive))
            .Include(p => p.ApplicationUser)
                .ThenInclude(au => au!.AdminAccount)
            .FirstOrDefaultAsync(x => x.IsActive && (x.ApplicationUserId == userId || managerIds.Contains(x.ApplicationUserId ?? "")) && x.Id == postId)
            .ConfigureAwait(false);

        if (post is null)
        {
            response.AddError(_postNotFoundError);
            return response;
        }

        _planRuleValidator.IsSubscriptionValid(userAccount ?? post.ApplicationUser!.AdminAccount, userAccount is not null ? false : true);
        if (request.Status == PostStatus.Queue)
            _planRuleValidator.CanQueuePost(userAccount ?? post.ApplicationUser!.AdminAccount);

        var oldImageIds = post.Images.Select(x => x.Id).ToList();

        SocialAccount? socialAccount = post.SocialAccount;

        if (post.SocialAccountId != request.SocialAccountId && request.SocialAccountId is not null)
        {
            socialAccount = await _context.SocialAccount
                .FirstOrDefaultAsync(x => x.IsActive && x.ApplicationUserId == userId && x.Id == request.SocialAccountId)
                .ConfigureAwait(false);
        }

        if (socialAccount is null)
        {
            response.AddError(_socialAccountNotFoundError);
            return response;
        }

        post.Content = request.Content;
        post.Status = request.Status;
        post.PageId = post.IsPublished && request.PageId is not null ? request.PageId : post.PageId;
        post.PageName = post.IsPublished && request.PageName is not null ? request.PageName : post.PageName;
        post.ScheduledDate = request.ScheduledDate;
        post.SocialAccount = socialAccount;
        post.SocialAccountId = socialAccount.Id;
        post.ModifiedBy = request.ModifiedBy;
        post.ModifiedDate = DateTimeOffset.UtcNow;

        if (request.Status != PostStatus.Draft && string.IsNullOrEmpty(post.Content))
        {
            response.AddError(_postContentError);
            return response;
        }

        if (socialAccount.Type == SocialAccountType.Instagram && request.Status != PostStatus.Draft && request.Images.Count == 0 && request.ImagesUrl.Count == 0)
        {
            response.AddError(_instagramPostCreateError);
            return response;
        }

        images = await HandleImages(post, request.Images, request.ImagesUrl, oldImageIds, images, request.ModifiedBy, _fileService).ConfigureAwait(false);

        response.Post = MapPost(post, _fileService);

        if (request.Status == PostStatus.Published)
        {
            post.ModifiedBy = request.ModifiedBy;

            response.Post = await PublishPost(post).ConfigureAwait(false);

            response.Post.Errors.ForEach(response.Errors.Add);
        }

        if (images.Count > 0)
            await _context.AddRangeAsync(images).ConfigureAwait(false);
        await SaveChangesAsync().ConfigureAwait(false);

        return response;
    }

    async ValueTask<GetPostResponse> IPostRepository<Post>.PostActionAsync(Guid postId, string userId, PostActionDTO request)
    {
        var response = new GetPostResponse();
        var newPost = new Post();
        IList<Document> newImages = [];

        var userAccount = _context.UserAccount
                //.Include(x => x.Managers.Where(m => m.IsActive))
                .Include(x => x.Managers)
                .FirstOrDefault(x => x.IsActive && x.ApplicationUserId == userId);

        IList<string> managerIds = [];

        if (userAccount is not null)
        {
            managerIds = userAccount.Managers.Select(x => x.Id).ToList();
        }

        var post = await _context.Post
            .Include(p => p.SocialAccount)
            .Include(p => p.Images.Where(x => x.IsActive))
            .Include(p => p.ApplicationUser)
                .ThenInclude(au => au!.AdminAccount)
            .FirstOrDefaultAsync(p => p.IsActive && (p.ApplicationUserId == userId || managerIds.Contains(p.ApplicationUserId ?? "")) && p.Id == postId)
            .ConfigureAwait(false);

        if (post is null)
        {
            response.AddError(_postNotFoundError);
            return response;
        }

        _planRuleValidator.IsSubscriptionValid(userAccount ?? post.ApplicationUser!.AdminAccount, userAccount is not null ? false : true);

        foreach (var image in post.Images)
        {
            (string? fileName, string? filePath) = _fileService.DuplicateFileAndGetNewFileNameAndPath(image.FileName, newImages.Select(x => x.FileName).ToList());

            if (fileName is not null && filePath is not null)
            {
                var imageItem = new Document
                {
                    FileName = fileName,
                    DocumentType = DocumentType.PostImage,
                    PostId = newPost.Id,
                    CreatedBy = request.ModifiedBy,
                    ModifiedDate = DateTimeOffset.UtcNow,
                };

                newPost.Images.Add(imageItem);
                newImages.Add(imageItem);
            }
        }

        newPost.Content = post.Content;
        //newPost.Status = (post.Status is PostStatus.Published || post.Status is PostStatus.Failed) ? PostStatus.Draft : post.Status;
        newPost.Status = PostStatus.Draft;
        newPost.ApplicationUserId = userId;
        newPost.SocialAccountId = post.SocialAccountId;
        newPost.SocialAccount = post.SocialAccount;
        newPost.ScheduledDate = post.ScheduledDate;
        newPost.PageId = post.PageId;
        newPost.PageName = post.PageName;
        newPost.CreatedBy = request.ModifiedBy;
        newPost.ModifiedDate = DateTimeOffset.UtcNow;

        if (request.Action == PostAction.Duplicate)
        {
            //do nothing
        }
        else if (request.Action == PostAction.PublishNow)
        {
            newPost.Status = post.Status;

            if (post.SocialAccount is null)
            {
                response.AddError(_postNotFoundError);
                return response;
            }

            if (string.IsNullOrEmpty(post.Content) && post.Images.Count == 0)
            {
                response.AddError(_postContentError);
                return response;
            }

            if (post.SocialAccount.Type == SocialAccountType.Instagram && post.Images.Count == 0)
            {
                response.AddError(_instagramPostCreateError);
                return response;
            }

            response.Post = await PublishPost(newPost).ConfigureAwait(false);

            if (!response.Post.IsSuccess)
            {
                post.ModifiedBy = request.ModifiedBy;
                post.ModifiedDate = DateTimeOffset.UtcNow;

                await SaveChangesAsync().ConfigureAwait(false);

                response.Post.Errors.ForEach(response.Errors.Add);

                return response;
            }

            if (newPost.Status == PostStatus.Failed)
            {
                await SaveChangesAsync().ConfigureAwait(false);
                return response;
            }
        }

        if (newImages.Count > 0)
            await _context.AddRangeAsync(newImages).ConfigureAwait(false);
        await AddAsync(newPost).ConfigureAwait(false);
        await SaveChangesAsync().ConfigureAwait(false);

        response.Post = MapPost(newPost, _fileService);

        return response;
    }

    private static GetPostDTO MapPost(Post post, IFileService fileService)
    {
        return new GetPostDTO
        {
            Id = post.Id,
            Content = post.Content,
            IsPublished = post.IsPublished,
            Status = post.Status,
            ScheduledDate = post.ScheduledDate,
            PublishedDate = post.PublishDate,
            PublishedBy = post.PublishedBy,
            PublisedPostId = post.PublishedPostId,
            PageId = post.SocialAccount is not null ?
                    post.SocialAccount.Type != SocialAccountType.Instagram ?
                        post.PageId :
                    post.SocialAccount.SocialAccountId :
                null,
            PageName = post.SocialAccount is not null ?
                    post.SocialAccount.Type != SocialAccountType.Instagram ?
                        post.PageName :
                    post.SocialAccount.FirstName :
                null,
            Images = post.Images.Select(x => new DocumentDTO
            {
                Id = x.Id,
                FileName = x.FileName,
                URL = fileService.GetFileURL(x.FileName),
                DocumentType = x.DocumentType,
            }).ToList(),
            SocialAccount = post.SocialAccount is null ? null : new SocialAccountInfoDTO
            {
                Id = post.SocialAccount.Id,
                Type = post.SocialAccount.Type,
                FirstName = post.SocialAccount.FirstName,
                LastName = post.SocialAccount.LastName,
                ProfilePicture = post.SocialAccount.ProfilePicture,
                PageId = post.SocialAccount.Type != SocialAccountType.Instagram ?
                        post.PageId :
                    post.SocialAccount.SocialAccountId,
                PageName = post.SocialAccount.Type != SocialAccountType.Instagram ?
                        post.PageName :
                    post.SocialAccount.FirstName
            },
            CreatedBy = post.CreatedBy,
            CreatedDate = post.CreatedDate,
            ModifiedBy = post.ModifiedBy,
            ModifiedDate = post.ModifiedDate,
            DisplayDate = post.Status == PostStatus.Queue ?
                            post.ScheduledDate :
                            post.Status == PostStatus.Published ?
                                post.PublishDate :
                                post.ModifiedDate ?? post.CreatedDate,
        };
    }

    async private ValueTask<Post?> CreatePost(CreatePostDTO request, SocialAccount socialAccount, string? pageId, string? pageName, IList<Document> newImages, string userId, IFileService fileService)
    {
        Post? post = null;
        var content = "";

        if (socialAccount.Type == SocialAccountType.Facebook)
        {
            content = request.FaceBookContent ?? string.Empty;

            post = new Post
            {
                Content = content,
                Status = request.Status,
                ApplicationUserId = userId,
                SocialAccountId = socialAccount.Id,
                PageId = pageId ?? string.Empty,
                PageName = pageName ?? string.Empty,
                ScheduledDate = request.Status != PostStatus.Published ? request.ScheduledDate ?? DateTimeOffset.UtcNow.AddDays(1) : null,
                PublishedBy = request.ModifiedBy,
                CreatedBy = request.ModifiedBy,
                ModifiedDate = DateTimeOffset.UtcNow,
            };

            await HandleImages(post, request.FaceBookImages, request.FaceBookImagesUrl, [], newImages, request.ModifiedBy, fileService).ConfigureAwait(false);
        }
        else if (socialAccount.Type == SocialAccountType.Instagram)
        {
            content = request.InstagramContent ?? string.Empty;

            post = new Post
            {
                Content = content,
                Status = request.Status,
                ApplicationUserId = userId,
                SocialAccountId = socialAccount.Id,
                PageId = pageId ?? string.Empty,
                PageName = pageName ?? string.Empty,
                ScheduledDate = request.Status != PostStatus.Published ? request.ScheduledDate ?? DateTimeOffset.UtcNow.AddDays(1) : null,
                PublishedBy = request.ModifiedBy,
                CreatedBy = request.ModifiedBy,
                ModifiedDate = DateTimeOffset.UtcNow,
            };

            await HandleImages(post, request.InstagramImages, request.InstagramImagesUrl, [], newImages, request.ModifiedBy, fileService).ConfigureAwait(false);
        }
        else if (socialAccount.Type == SocialAccountType.LinkedIn)
        {
            content = request.LinkedInContent ?? string.Empty;

            post = new Post
            {
                Content = content,
                Status = request.Status,
                ApplicationUserId = userId,
                SocialAccountId = socialAccount.Id,
                PageId = pageId ?? string.Empty,
                PageName = pageName ?? string.Empty,
                ScheduledDate = request.Status != PostStatus.Published ? request.ScheduledDate ?? DateTimeOffset.UtcNow.AddDays(1) : null,
                PublishedBy = request.ModifiedBy,
                CreatedBy = request.ModifiedBy,
                ModifiedDate = DateTimeOffset.UtcNow,
            };

            await HandleImages(post, request.LinkedInImages, request.LinkedInImagesUrl, [], newImages, request.ModifiedBy, fileService).ConfigureAwait(false);
        }

        return post;
    }

    async private ValueTask<IList<Document>> HandleImages(Post post, IList<IFormFile> images, IList<string> imageUrls, IList<Guid> deleteImageIds, IList<Document> newImages, string? modifiedBy, IFileService fileService)
    {
        foreach (var image in images)
        {
            (var fileName, var filePath) = await fileService.UploadFileAndGetNewFileNameAndPath(image, image.FileName, newImages.Select(x => x.FileName).ToList()).ConfigureAwait(false);
            var imageItem = new Document()
            {
                FileName = fileName,
                DocumentType = DocumentType.PostImage,
                PostId = post.Id,
                CreatedBy = modifiedBy,
                ModifiedDate = DateTimeOffset.UtcNow,
            };

            post.Images.Add(imageItem);
            newImages.Add(imageItem);
        }

        foreach (var imageUrl in imageUrls)
        {
            (var fileName, var filePath) = await fileService.UploadFileFromUrlAndGetNewFileNameAndPath(imageUrl, newImages.Select(x => x.FileName).ToList()).ConfigureAwait(false);

            var imageItem = new Document()
            {
                FileName = fileName,
                DocumentType = DocumentType.PostImage,
                PostId = post.Id,
                CreatedBy = modifiedBy,
                ModifiedDate = DateTimeOffset.UtcNow,
            };

            post.Images.Add(imageItem);
            newImages.Add(imageItem);
        }

        foreach (var image in post.Images.ToList())
        {
            if (deleteImageIds.Contains(image.Id))
            {
                image.IsActive = false;
                image.ModifiedBy = modifiedBy;
                image.ModifiedDate = DateTimeOffset.UtcNow;

                fileService.DeleteUploadedFile(image.FileName);

                post.Images.Remove(image);
            }
        }

        return newImages;
    }

    private async ValueTask<GetPostDTO> PublishPost(Post post)
    {
        GetPostDTO? response = null;

        var publishResponse = await _socialAccountRepository.HandlePostPublishAsync(post).ConfigureAwait(false);

        post.Status = publishResponse.IsSuccess ? PostStatus.Published : PostStatus.Failed;
        post.ModifiedDate = DateTimeOffset.UtcNow;
        post.PublishedBy = post.ModifiedBy ?? post.CreatedBy;

        response = MapPost(post, _fileService);
        publishResponse.Errors.ForEach(response.AddError);

        return response;
    }

}