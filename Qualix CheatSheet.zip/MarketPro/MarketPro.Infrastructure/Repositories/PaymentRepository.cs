﻿using AutoMapper;
using MarketPro.Application;
using MarketPro.Data;
using MarketPro.Documents.DTOs;
using MarketPro.Identity.DTOs;
using MarketPro.Identity.Entities;
using MarketPro.IRepositories;
using MarketPro.Payments.DTOs;
using MarketPro.Services;
using MarketPro.UserAccounts.DTOs;
using MarketPro.UserAccounts.Entities;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using Stripe;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace MarketPro.Repositories;

public class PaymentRepository : IPaymentRepository
{
    private const string _userNotFoundError = "User does not exist.";
    private const string _planNotFoundError = "User does not exist.";
    private const string _cancelSubscriptionError = "Subscription cancellation falied.";
    private const string _updateSubscriptionError = "Subscription updation falied.";
    private const string _updatePaymentMethodError = "Payment method updation falied.";
    private const string _invalidRequestError = "Invalid request. only one paramter required either StartingAfter or StartingBefore.";
    private readonly IAuthRepository _authRepository;
    private readonly IPaymentService _paymentService;
    private readonly IFileService _fileService;
    private readonly ApplicationDbContext _context;
    private readonly UserManager<ApplicationUser> _userManager;
    private readonly IMapper _mapper;
    private readonly IMailService _mailService;

    public PaymentRepository(ApplicationDbContext context, IAuthRepository authRepository, IPaymentService paymentService, IFileService fileService, UserManager<ApplicationUser> userManager, IMapper mapper, IMailService mailService)
    {
        _context = context ?? throw new ArgumentNullException(nameof(context));
        _authRepository = authRepository ?? throw new ArgumentNullException(nameof(authRepository));
        _paymentService = paymentService ?? throw new ArgumentNullException(nameof(paymentService));
        _fileService = fileService ?? throw new ArgumentNullException(nameof(fileService));
        _userManager = userManager ?? throw new ArgumentNullException(nameof(userManager));
        _mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));
        _mailService = mailService ?? throw new ArgumentNullException(nameof(mailService));
    }

    async ValueTask<bool> IPaymentRepository.UpdateUserSubscriptionStatusAsync(Subscription? subscription)
    {
        if (subscription is not null)
        {
            var userAccount = await _context.UserAccount
                .Include(x => x.ApplicationUser)
                .FirstOrDefaultAsync(ua => ua.SubscriptionId == subscription.Id).ConfigureAwait(false);
            if (userAccount is not null)
            {
                userAccount.SubscriptionStatus = _paymentService.MapSubscriptionStatusToEnum(subscription.Status);
                userAccount.SubscriptionDate = DateTimeOffset.UtcNow;
                userAccount.ModifiedDate = DateTimeOffset.UtcNow;

                await _context.SaveChangesAsync().ConfigureAwait(false);

                if (subscription.Status == SubscriptionStatus.canceled.ToString() && userAccount.ApplicationUser is not null && userAccount.ApplicationUser.Email is not null)
                {
                    var subject = "MarketPro Subscription Cancelled";
                    var bodyText = @"<!DOCTYPE html>
<html lang=""en"">
  <head>
    <meta charset=""UTF-8"" />
    <meta name=""viewport"" content=""width=device-width, initial-scale=1.0"" />
    <title>Payment Cancel</title>
  </head>
  <body>
    <div
      style=""
        font-family: 'Inter', sans-serif;
        max-width: 600px;
        padding: 20px;
        color: #0a0d14;
      ""
    >
      <div style=""margin-bottom: 40px"">
        <img
          src=""https://raw.githubusercontent.com/FarazQx/RawAssets/refs/heads/main/marketprologo.png""
          alt=""MarketPro Logo""
          style=""width: auto; height: auto""
        />
      </div>

      <h2
        style=""
          font-size: 24px;
          color: #0a0d14;
          font-weight: 500;
          margin-bottom: 20px;
        ""
      >
        Your MarketPro Subscription Has Been Canceled
      </h2>

      <p style=""font-size: 16px; color: #475467; margin-bottom: 20px"">
        Hi [Username],
      </p>

      <p style=""font-size: 16px; color: #475467; margin-bottom: 20px"">
        We&apos;re sorry to see you go. Your subscription with MarketPro has
        been successfully canceled. Here&apos;s a quick summary:
      </p>

      <p style=""font-size: 16px; color: #475467; margin: 5px 0"">
        <strong>Subscription Plan:</strong> [PlanName]
      </p>

      <p style=""font-size: 16px; color: #475467; margin: 5px 0"">
        <strong>Cancellation Date:</strong> [Date]
      </p>

      <p style=""font-size: 16px; color: #475467; margin-top: 20px"">
        If you change your mind, you&apos;re always welcome back. Please feel
        free to reach out if you have any questions or if there's anything we
        can help you with.
      </p>

      <p style=""font-size: 16px; color: #475467; margin-top: 20px"">
        Thank you for being with us.
      </p>

      <p style=""font-size: 16px; color: #475467; margin-top: 20px"">
        MarketPro Team
      </p>

      <div
        style=""
          font-size: 16px;
          color: #475467;
          line-height: 1.5;
          padding-top: 20px;
          margin-top: 40px;
        ""
      >
        <p style=""margin-top: 10px"">&copy; [CurrentYear] MarketPro</p>
      </div>

      <div style=""margin-top: 24px"">
        <img
          src=""https://raw.githubusercontent.com/FarazQx/RawAssets/refs/heads/main/marketprologo.png""
          alt=""MarketPro Logo""
          style=""width: auto; height: auto""
        />
      </div>
    </div>
  </body>
</html>";
                    bodyText = bodyText.Replace("[Username]", $"{userAccount.ApplicationUser.FirstName} {userAccount.ApplicationUser.LastName}");
                    bodyText = bodyText.Replace("[PlanName]", userAccount.Plan.ToString());
                    bodyText = bodyText.Replace("[Date]", DateTimeOffset.UtcNow.ToString(("yyyyMMddHHmmss")));
                    bodyText = bodyText.Replace("[CurrentYear]", DateTimeOffset.UtcNow.Year.ToString());

                    await _mailService.SendEmailAsync(userAccount.ApplicationUser.Email, subject, bodyText).ConfigureAwait(false);
                }

                if (subscription.Status == SubscriptionStatus.failed.ToString() && userAccount.ApplicationUser is not null && userAccount.ApplicationUser.Email is not null)
                {
                    var subject = "MarketPro Subscription Cancelled";
                    var bodyText = @"<!DOCTYPE html>
<html lang=""en"">
  <head>
    <meta charset=""UTF-8"" />
    <meta name=""viewport"" content=""width=device-width, initial-scale=1.0"" />
    <title>Payment Failed</title>
  </head>
  <body>
    <div
      style=""
        font-family: 'Inter', sans-serif;
        max-width: 600px;
        padding: 20px;
        color: #0a0d14;
      ""
    >
      <div style=""margin-bottom: 40px"">
        <img
          src=""https://raw.githubusercontent.com/FarazQx/RawAssets/refs/heads/main/marketprologo.png""
          alt=""MarketPro Logo""
          style=""width: auto; height: auto""
        />
      </div>

      <h2
        style=""
          font-size: 24px;
          color: #0a0d14;
          font-weight: 500;
          margin-bottom: 20px;
        ""
      >
        Payment Failed – Action Required
      </h2>

      <p style=""font-size: 16px; color: #475467; margin-bottom: 20px"">
        Hi [Username],
      </p>

      <p style=""font-size: 16px; color: #475467; margin-bottom: 20px"">
        Unfortunately, we encountered an issue processing your payment. Please
        review the details below:
      </p>

      <p style=""font-size: 16px; color: #475467; margin: 5px 0"">
        <strong>Subscription Plan:</strong> [PlanName]
      </p>

      <p style=""font-size: 16px; color: #475467; margin: 5px 0"">
        <strong>Date:</strong> [Date]
      </p>

      <p style=""font-size: 16px; color: #475467; margin-top: 20px"">
        Please double-check your payment information or use a different payment
        method. You can update your details by logging into your account at [<a
          href=""#""
          style=""color: #6e51e0; text-decoration: none""
          >Account Link</a
        >]. If you have any questions or need further assistance, don&apos;t
        hesitate to reach out to us.
      </p>

      <p style=""font-size: 16px; color: #475467; margin-top: 20px"">
        If you have any questions or need further assistance, don&apos;t
        hesitate to reach out to us.
      </p>

      <p style=""font-size: 16px; color: #475467; margin-top: 20px"">
        Thank you for your attention to this matter.
      </p>

      <p style=""font-size: 16px; color: #475467; margin-top: 20px"">
        MarketPro Team
      </p>

      <div
        style=""
          font-size: 16px;
          color: #475467;
          line-height: 1.5;
          padding-top: 20px;
          margin-top: 40px;
        ""
      >
        <p style=""margin-top: 10px"">&copy; [CurrentYear] MarketPro</p>
      </div>

      <div style=""margin-top: 24px"">
        <img
          src=""https://raw.githubusercontent.com/FarazQx/RawAssets/refs/heads/main/marketprologo.png""
          alt=""MarketPro Logo""
          style=""width: auto; height: auto""
        />
      </div>
    </div>
  </body>
</html>";
                    bodyText = bodyText.Replace("[Username]", $"{userAccount.ApplicationUser.FirstName} {userAccount.ApplicationUser.LastName}");
                    bodyText = bodyText.Replace("[PlanName]", userAccount.Plan.ToString());
                    bodyText = bodyText.Replace("[Date]", DateTimeOffset.UtcNow.ToString(("yyyyMMddHHmmss")));
                    bodyText = bodyText.Replace("[CurrentYear]", DateTimeOffset.UtcNow.Year.ToString());

                    await _mailService.SendEmailAsync(userAccount.ApplicationUser.Email, subject, bodyText).ConfigureAwait(false);
                }

                return true;
            }
        }
        return false;
    }

    async ValueTask<bool> IPaymentRepository.SendPaymentEmailAsync(Invoice? invoice)
    {
        if (invoice is null)
            return false;

        var user = await _context.UserAccount
            .Include(x => x.ApplicationUser)
            .FirstOrDefaultAsync(x => x.StripeCustomerId == invoice.CustomerId).ConfigureAwait(false);

        if (user is null || user.ApplicationUser is null || user.ApplicationUser.Email is null)
            return false;

        var subject = AppEnvironment.SuccessfulPaymentEmailSubject;
        var bodyText = @"<!DOCTYPE html>
<html lang=""en"">
  <head>
    <meta charset=""UTF-8"" />
    <meta name=""viewport"" content=""width=device-width, initial-scale=1.0"" />
    <title>Payment Sucess</title>
  </head>
  <body>
    <div
      style=""
        font-family: 'Inter', sans-serif;
        max-width: 600px;
        padding: 20px;
        color: #0a0d14;
      ""
    >
      <div style=""margin-bottom: 40px"">
        <img
          src=""https://raw.githubusercontent.com/FarazQx/RawAssets/refs/heads/main/marketprologo.png""
          alt=""MarketPro Logo""
          style=""width: auto; height: auto""
        />
      </div>

      <h2
        style=""
          font-size: 24px;
          color: #0a0d14;
          font-weight: 500;
          margin-bottom: 20px;
        ""
      >
        Payment Successful! Welcome to MarketPro
      </h2>

      <p style=""font-size: 16px; color: #475467; margin-bottom: 20px"">
        Hi [Username],
      </p>

      <p style=""font-size: 16px; color: #475467; margin-bottom: 20px"">
        Thank you for your payment! Your MarketPro subscription is now active.
        Here&apos;s a summary of your purchase:
      </p>

      <p style=""font-size: 16px; color: #475467; margin: 5px 0"">
        <strong>Receipt Number:</strong> [ReceiptNumber]
      </p>

      <p style=""font-size: 16px; color: #475467; margin: 5px 0"">
        <strong>Invoice Url:</strong> [InvoiceUrl]
      </p>

      <p style=""font-size: 16px; color: #475467; margin: 5px 0"">
        <strong>Subscription Plan:</strong> [PlanName]
      </p>

      <p style=""font-size: 16px; color: #475467; margin: 5px 0"">
        <strong>Amount:</strong> $[Amount]
      </p>

      <p style=""font-size: 16px; color: #475467; margin: 5px 0"">
        <strong>Date:</strong> [Date]
      </p>

      <p style=""font-size: 16px; color: #475467; margin-top: 20px"">
        We&apos;re thrilled to have you with us. If you have any questions about
        your subscription, feel free to get in touch.
      </p>

      <p style=""font-size: 16px; color: #475467; margin-top: 20px"">
        Thank you for being a valued member of MarketPro!
      </p>

      <p style=""font-size: 16px; color: #475467; margin-top: 20px"">
        MarketPro Team
      </p>

      <div
        style=""
          font-size: 16px;
          color: #475467;
          line-height: 1.5;
          padding-top: 20px;
          margin-top: 40px;
        ""
      >
        <p style=""margin-top: 10px"">&copy; [CurrentYear] MarketPro</p>
      </div>

      <div style=""margin-top: 24px"">
        <img
          src=""https://raw.githubusercontent.com/FarazQx/RawAssets/refs/heads/main/marketprologo.png""
          alt=""MarketPro Logo""
          style=""width: auto; height: auto""
        />
      </div>
    </div>
  </body>
</html>";
        bodyText = bodyText.Replace("[Username]", $"{user.ApplicationUser.FirstName} {user.ApplicationUser.LastName}");
        bodyText = bodyText.Replace("[ReceiptNumber]", invoice.ReceiptNumber);
        bodyText = bodyText.Replace("[InvoiceUrl]", invoice.HostedInvoiceUrl);
        bodyText = bodyText.Replace("[PlanName]", user.Plan.ToString());
        bodyText = bodyText.Replace("[Amount]", $"{(decimal)invoice.Total / 100}");
        bodyText = bodyText.Replace("[Date]", DateTimeOffset.UtcNow.ToString(("yyyyMMddHHmmss")));
        bodyText = bodyText.Replace("[CurrentYear]", DateTimeOffset.UtcNow.Year.ToString());

        user.SubscriptionStatus = SubscriptionStatus.active;
        user.ModifiedDate = DateTimeOffset.UtcNow;

        var isEmailSent = await _mailService.SendEmailAsync(user.ApplicationUser.Email, subject, bodyText).ConfigureAwait(false);

        await _context.SaveChangesAsync().ConfigureAwait(false);
        return true;
    }

    async ValueTask<AuthResponse> IPaymentRepository.CancelSubscriptionAsync(string userId, string? modifiedBy)
    {
        var response = new AuthResponse();

        var user = await _context.Users
            .Include(x => x.ProfileImage)
            .Include(x => x.UserAccount)
            .FirstOrDefaultAsync(x => x.IsActive && x.Id == userId)
            .ConfigureAwait(false);

        if (user is null || user.UserAccount is null)
        {
            response.AddError(_userNotFoundError);
            return response;
        }

        if (user.UserAccount.SubscriptionStatus == SubscriptionStatus.canceled)
        {
            response.AddError(_cancelSubscriptionError);
            return response;
        }

        var stripeDetails = await _paymentService
            .CancelSubscriptionAsync(user.UserAccount.SubscriptionId);

        if (stripeDetails is null || stripeDetails.Stripe is null || stripeDetails.Stripe.SubscriptionStatus != "canceled")
        {
            response.AddError(_cancelSubscriptionError);
            return response;
        }

        user.UserAccount.StripeCustomerId = stripeDetails.Stripe.StripeCustomerId;
        user.UserAccount.SubscriptionId = stripeDetails.Stripe.SubscriptionId;
        user.UserAccount.SubscriptionStatus = _paymentService.MapSubscriptionStatusToEnum(stripeDetails.Stripe.SubscriptionStatus);
        user.UserAccount.ApplicationUserId = user.Id;
        user.UserAccount.ModifiedBy = modifiedBy;
        user.UserAccount.ModifiedDate = DateTimeOffset.UtcNow;

        var roles = await _userManager.GetRolesAsync(user).ConfigureAwait(false);

        var authDTO = new AuthDTO
        {
            UserId = user.Id,
            FirstName = user.FirstName,
            LastName = user.LastName,
            UserName = user.UserName!,
            UserRole = roles.Count > 0 ? roles[0] : "",
            BearerToken = GenerateToken(user, roles),
            ProfileImage = user.ProfileImage is null ? null : new DocumentDTO
            {
                Id = user.ProfileImage.Id,
                FileName = user.ProfileImage.FileName,
                URL = _fileService.GetFileURL(user.ProfileImage.FileName),
                DocumentType = user.ProfileImage.DocumentType,
            },
            UserDetials = _mapper.Map<UserAccountDTO>(user.UserAccount),
            CreatedBy = user.CreatedBy,
            CreatedDate = user.CreatedDate,
            ModifiedBy = user.ModifiedBy,
            ModifiedDate = user.ModifiedDate
        };

        await _context.SaveChangesAsync().ConfigureAwait(false);

        response.User = authDTO;

        return response;
    }

    async ValueTask<AuthResponse> IPaymentRepository.UpdateSubscriptionAsync(string userId, UpdateSubscriptionRequest request)
    {
        var response = new AuthResponse();

        var user = await _context.Users
            .Include(x => x.ProfileImage)
            .Include(x => x.UserAccount)
            .FirstOrDefaultAsync(x => x.IsActive && x.Id == userId)
            .ConfigureAwait(false);

        if (user is null || user.UserAccount is null)
        {
            response.AddError(_userNotFoundError);
            return response;
        }

        var stripeDetails = await _paymentService
            .UpdateSubscriptionAsync(user.UserAccount.SubscriptionId, request.Plan);

        if (stripeDetails is null || stripeDetails.Stripe is null)
        {
            response.AddError(_updateSubscriptionError);
            return response;
        }

        user.UserAccount.StripeCustomerId = stripeDetails.Stripe.StripeCustomerId;
        user.UserAccount.SubscriptionId = stripeDetails.Stripe.SubscriptionId;
        user.UserAccount.SubscriptionStatus = _paymentService.MapSubscriptionStatusToEnum(stripeDetails.Stripe.SubscriptionStatus);
        user.UserAccount.Plan = request.Plan;
        user.UserAccount.ModifiedBy = request.ModifiedBy;
        user.UserAccount.ModifiedDate = DateTimeOffset.UtcNow;

        var roles = await _userManager.GetRolesAsync(user).ConfigureAwait(false);

        await _context.SaveChangesAsync().ConfigureAwait(false);

        response.User = await _authRepository.MapAuthResponseAsync(user, user.UserAccount).ConfigureAwait(false);

        return response;
    }

    async ValueTask<AuthResponse> IPaymentRepository.UpdatePaymentMethodAsync(string userId, UpdatePaymentMethodRequest request)
    {
        var response = new AuthResponse();

        var user = await _context.Users
            .Include(x => x.ProfileImage)
            .Include(x => x.UserAccount)
            .FirstOrDefaultAsync(x => x.IsActive && x.Id == userId)
            .ConfigureAwait(false);

        if (user is null || user.UserAccount is null)
        {
            response.AddError(_userNotFoundError);
            return response;
        }

        if (user.UserAccount.SubscriptionStatus == SubscriptionStatus.canceled)
        {
            response.AddError(_updatePaymentMethodError);
            return response;
        }

        var stripeDetails = await _paymentService
            .UpdatePaymentMethodAsync(user.UserAccount.SubscriptionId, request.PaymentId);

        if (stripeDetails is null || stripeDetails.Stripe is null)
        {
            response.AddError(_updatePaymentMethodError);
            return response;
        }

        user.UserAccount.SubscriptionStatus = _paymentService.MapSubscriptionStatusToEnum(stripeDetails.Stripe.SubscriptionStatus);
        user.UserAccount.ModifiedBy = request.ModifiedBy;
        user.UserAccount.ModifiedDate = DateTimeOffset.UtcNow;

        var roles = await _userManager.GetRolesAsync(user).ConfigureAwait(false);

        var authDTO = new AuthDTO
        {
            UserId = user.Id,
            FirstName = user.FirstName,
            LastName = user.LastName,
            UserName = user.UserName!,
            UserRole = roles.Count > 0 ? roles[0] : "",
            BearerToken = GenerateToken(user, roles),
            ProfileImage = user.ProfileImage is null ? null : new DocumentDTO
            {
                Id = user.ProfileImage.Id,
                FileName = user.ProfileImage.FileName,
                URL = _fileService.GetFileURL(user.ProfileImage.FileName),
                DocumentType = user.ProfileImage.DocumentType,
            },
            UserDetials = _mapper.Map<UserAccountDTO>(user.UserAccount),
            CreatedBy = user.CreatedBy,
            CreatedDate = user.CreatedDate,
            ModifiedBy = user.ModifiedBy,
            ModifiedDate = user.ModifiedDate
        };

        await _context.SaveChangesAsync().ConfigureAwait(false);

        response.User = authDTO;

        return response;
    }

    async ValueTask<InvoiceRespose> IPaymentRepository.GetAllInvoicesAsync(string userId, StripePagination pagination)
    {
        var response = new InvoiceRespose();

        var user = await _context.Users
            .Include(x => x.ProfileImage)
            .Include(x => x.UserAccount)
            .FirstOrDefaultAsync(x => x.IsActive && x.Id == userId)
            .ConfigureAwait(false);

        if (user is null || user.UserAccount is null)
        {
            response.AddError(_userNotFoundError);
            return response;
        }

        if (pagination.StartingAfter is not null && pagination.StartingBefore is not null)
        {
            response.AddError(_invalidRequestError);
            return response;
        }

        var paginatedData = new StripePaginationDTO
        {
            PageSize = pagination.PageSize,
            StartingAfter = pagination.StartingAfter,
            StartingBefore = pagination.StartingBefore,
        };

        var invoices = await _paymentService
            .GetAllInvoiceAsync(user.UserAccount.StripeCustomerId, paginatedData);

        response.Invoices = invoices;
        response.TotalCount = invoices.Count();
        response.PageSize = paginatedData.PageSize;
        response.HasNext = paginatedData.HasNext;
        response.HasPrevious = paginatedData.HasPrevious;

        return response;
    }

    async ValueTask<PlansResponse> IPaymentRepository.GetAllPlansAsync()
    {
        var response = new PlansResponse();

        response.Plans = await _paymentService.GetAllPlansAsync().ConfigureAwait(false);

        response.Plans = response.Plans.OrderBy(x => x.Plan).ToList();

        return response;
    }

    async ValueTask<PlanResponse> IPaymentRepository.GetUserPlanByIdAsync(string userId)
    {
        var response = new PlanResponse();

        var user = await _context.Users
            .Include(x => x.ProfileImage)
            .Include(x => x.UserAccount)
            .FirstOrDefaultAsync(x => x.IsActive && x.Id == userId)
            .ConfigureAwait(false);

        //what to do if user has not subcscribed or has canceled the plan?
        //should we manage everything by plan or planId?

        if (user is null || user.UserAccount is null)
        {
            response.AddError(_userNotFoundError);
            return response;
        }

        var plan = await _paymentService
            .GetPlanAsync(user.UserAccount.Plan);

        if (plan is null)
        {
            response.AddError(_userNotFoundError);
        }

        response.Plan = plan;

        return response;
    }

    private string GenerateToken(ApplicationUser user, IList<string> roles)
    {
        List<Claim> claims = [
                new (ClaimTypes.NameIdentifier, user.Id),
                new (ClaimTypes.Name, $"{user.FirstName} {user.LastName}"),
            ];

        foreach (var role in roles)
        {
            claims.Add(new(ClaimTypes.Role, role));
        }

        var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(AppEnvironment.AuthSecretKey));

        var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha512Signature);

        var token = new JwtSecurityToken(
                claims: claims,
                expires: DateTime.Now.AddDays(355),
                signingCredentials: creds
            );

        var jwt = new JwtSecurityTokenHandler().WriteToken(token);

        return jwt;
    }

}