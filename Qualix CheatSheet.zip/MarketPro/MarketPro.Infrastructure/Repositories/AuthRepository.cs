﻿using AutoMapper;
using MarketPro.Application;
using MarketPro.Data;
using MarketPro.Documents.DTOs;
using MarketPro.Documents.Entities;
using MarketPro.Identity.DTOs;
using MarketPro.Identity.Entities;
using MarketPro.IRepositories;
using MarketPro.Payments.DTOs;
using MarketPro.Services;
using MarketPro.UserAccounts.DTOs;
using MarketPro.UserAccounts.Entities;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using System.Data;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace MarketPro.Repositories;

public class AuthRepository : IAuthRepository
{
    private const int _otpMinValue = 100000;
    private const int _otpMaxValue = 999999;
    private const string _userNotFoundError = "User does not exist.";
    private const string _userNameOrPasswordIncorrectError = "UserName or Password Incorrect.";
    private const string _userAlreadyExistsError = "User already exists!.";
    private const string _theUserDoesNotExistError = "The user does not exist.";
    private const string _oldPasswordIsIncorrectError = "Old Password is incorrect.";
    private const string _anErrorOccurredWhileUpdatingThePasswordError = "An error occurred while updating the password.";
    private const string _theOTPIsEitherInvalidOrExpiredError = "The OTP is either invalid or expired.";
    private const string _theOTPIsInvalidError = "The OTP is invalid.";
    private const string _anErrorOccured = "An error occured.";
    private const string _replaceOTP = "{OTP}";


    private readonly ApplicationDbContext _context;
    private readonly IMailService _mailService;
    private readonly IPaymentService _paymentService;
    private readonly IMapper _mapper;
    private readonly UserManager<ApplicationUser> _userManager;
    private readonly IFileService _fileService;

    public AuthRepository(ApplicationDbContext context, IMapper mapper, IMailService mailService, IPaymentService paymentService, UserManager<ApplicationUser> userManager, IFileService fileService)
    {
        _context = context ?? throw new ArgumentNullException(nameof(context));
        _paymentService = paymentService ?? throw new ArgumentNullException(nameof(paymentService));
        _mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));
        _userManager = userManager ?? throw new ArgumentNullException(nameof(userManager));
        _mailService = mailService ?? throw new ArgumentNullException(nameof(mailService));
        _fileService = fileService ?? throw new ArgumentNullException(nameof(fileService));
    }

    async ValueTask<AuthResponse> IAuthRepository.LoginAsync(LoginRequest request)
    {
        var response = new AuthResponse();

        var user = await _context.Users
            .Include(x => x.UserAccount)
            .Include(x => x.AdminAccount)
            .Include(x => x.ProfileImage)
            .FirstOrDefaultAsync(x => x.IsActive && x.NormalizedUserName != null ? x.NormalizedUserName.ToLower() == request.UserName.ToLower() : false)
            .ConfigureAwait(false);

        //var testuser = await _userManager.FindByNameAsync(request.UserName).ConfigureAwait(false);

        if (user is null)
        {
            response.AddError(_userNotFoundError);
            return response;
        }

        var isAuthenticated = await _userManager.CheckPasswordAsync(user, request.Password).ConfigureAwait(false);

        if (!isAuthenticated)
        {
            response.AddError(_userNameOrPasswordIncorrectError);
            return response;
        }

        var userDetails = user.UserAccount ?? user.AdminAccount;

        response.User = await MapAuthAsync(user, userDetails);
        return response;
    }

    async ValueTask<AuthResponse> IAuthRepository.SignUpAsync(SignUpRequest request, string? modifiedBy)
    {
        var response = new AuthResponse();
        var user = await _userManager.FindByEmailAsync(request.Email).ConfigureAwait(false);
        UserAccount? userDetails = null;

        if (user is not null)
        {
            response.AddError(_userAlreadyExistsError);
            return response;
        }

        var stripeDetails = await _paymentService
            .RegisterSubscriptionAsync(new UserRegistrationRequest
            {
                Name = $"{request.FirstName} {request.LastName}",
                Email = request.Email,
                PaymentMethod = request.UserDetails.PaymentId,
                CustomerId = request.UserDetails.CustomerId,
                Plan = request.UserDetails.Plan
            });

        if (stripeDetails is not null && stripeDetails.Stripe is not null)
        {
            user = new ApplicationUser
            {
                FirstName = request.FirstName,
                LastName = request.LastName,
                Email = request.Email,
                UserName = request.Email,
                Role = UserRole.Admin,
                CreatedBy = modifiedBy,
                CreatedDate = DateTimeOffset.Now,
            };

            var identityResponse = await _userManager.CreateAsync(user, request.Password).ConfigureAwait(false);

            userDetails = new UserAccount
            {
                Plan = request.UserDetails.Plan,
                PaymentId = request.UserDetails.PaymentId,
                BusinessDescription = request.UserDetails.BusinessDescription,
                TargetAudienceDescription = request.UserDetails.TargetAudienceDescription,
                StripeCustomerId = stripeDetails.Stripe.StripeCustomerId,
                SubscriptionId = stripeDetails.Stripe.SubscriptionId,
                SubscriptionStatus = _paymentService.MapSubscriptionStatusToEnum(stripeDetails.Stripe.SubscriptionStatus),
                SubscriptionDate = DateTimeOffset.UtcNow,
                ApplicationUserId = user.Id,
                CreatedBy = modifiedBy
            };
            await _context.UserAccount.AddAsync(userDetails).ConfigureAwait(false);

            if (identityResponse.Succeeded)
            {
                await _userManager.AddToRoleAsync(user, UserRole.Admin.ToString());
                await _context.SaveChangesAsync().ConfigureAwait(false);

                response.User = await MapAuthAsync(user, userDetails);
                return response;
            }
            else
            {
                identityResponse.Errors.Select(e => e.Description).ToList().ForEach(response.AddError);
            }
        }

        response.AddError(_anErrorOccured);
        return response;
    }

    async ValueTask IAuthRepository.ConfirmEmailAsync(string userId)
    {
        var user = await _userManager.FindByIdAsync(userId) ?? throw new ArgumentException(_userNotFoundError);
        var token = await _userManager.GenerateEmailConfirmationTokenAsync(user).ConfigureAwait(false);
        await _userManager.ConfirmEmailAsync(user, token).ConfigureAwait(false);
    }

    async ValueTask<ChangePasswordResponse> IAuthRepository.ChangePasswordAsync(ChangePasswordRequest request, string? modifiedBy)
    {
        var response = new ChangePasswordResponse();
        var user = await _userManager.FindByNameAsync(request.Email).ConfigureAwait(false);
        if (user is null)
        {
            response.AddError(_theUserDoesNotExistError);
            return response;
        }
        var result = await _userManager.ChangePasswordAsync(user, request.OldPassword, request.NewPassword).ConfigureAwait(false);

        if (!result.Succeeded)
        {
            response.AddError(_oldPasswordIsIncorrectError);
            return response;
        }

        user.ModifiedBy = modifiedBy;
        user.ModifiedDate = DateTimeOffset.Now;
        await _userManager.UpdateAsync(user).ConfigureAwait(false);

        return response;
    }

    async ValueTask<SendForgotPasswordEmailResponse> IAuthRepository.SendForgotPasswordEmailAsync(SendForgotPasswordEmailRequest request)
    {
        var response = new SendForgotPasswordEmailResponse();

        var user = await _userManager.FindByNameAsync(request.Email);
        if (user is null)
        {
            response.AddError(_theUserDoesNotExistError);
            return response;
        }

        var otp = GenerateRandomNumber();
        var subject = AppEnvironment.PasswordOTPEmailSubject;
        var bodyText = AppEnvironment.PasswordOTPEmailBody;
        var body = bodyText.Replace(_replaceOTP, otp.ToString());
        await _mailService.SendEmailAsync(request.Email, subject, body).ConfigureAwait(false);

        user.PasswordOTP = otp;
        user.OTPDate = DateTimeOffset.Now;
        user.ModifiedDate = DateTimeOffset.Now;
        await _userManager.UpdateAsync(user).ConfigureAwait(false);

        response.Email = request.Email;
        return response;
    }

    async ValueTask<ResetPasswordResponse> IAuthRepository.ResetPasswordAsync(ResetPasswordRequest request)
    {
        var response = new ResetPasswordResponse();

        var user = await _userManager.FindByNameAsync(request.Email);
        if (user is null)
        {
            response.AddError(_theUserDoesNotExistError);
            return response;
        }

        var passwordChangeResult = await _userManager.ResetPasswordAsync(user, request.ResetPasswordToken, request.Password);

        if (passwordChangeResult.Succeeded)
        {
            user.ModifiedDate = DateTimeOffset.Now;
            await _userManager.UpdateAsync(user).ConfigureAwait(false);

            return response;
        }
        else
        {
            response.AddError(_anErrorOccurredWhileUpdatingThePasswordError);
            return response;
        }
    }

    async ValueTask<VerifyPasswordOTPResponse> IAuthRepository.VerifyPasswordOTPAsync(VerifyPasswordOTPRequest request)
    {
        var response = new VerifyPasswordOTPResponse();

        var user = await _userManager.FindByNameAsync(request.Email);
        if (user is null)
        {
            response.AddError(_theUserDoesNotExistError);
            return response;
        }

        if (user.PasswordOTP is null || IsOTPExpired(user.OTPDate, DateTimeOffset.Now))
        {
            response.AddError(_theOTPIsEitherInvalidOrExpiredError);
            return response;
        }

        if (user.PasswordOTP is not null && user.PasswordOTP == request.OTP)
        {
            response.ResetPasswordToken = await _userManager.GeneratePasswordResetTokenAsync(user).ConfigureAwait(false);
            return response;
        }
        else
        {
            response.AddError(_theOTPIsInvalidError);
            return response;
        }
    }

    async ValueTask<AuthDTO> IAuthRepository.MapAuthResponseAsync(ApplicationUser user, UserAccount? userDetails) => await MapAuthAsync(user, userDetails);

    async ValueTask<AuthResponse> IAuthRepository.UpdatePersonalInfoAsync(string userId, UpdatePersonalInfoRequest request)
    {
        var response = new AuthResponse();
        Document? imageItem = null;
        //var user = await _userManager.FindByIdAsync(applicationId).ConfigureAwait(false);

        var user = await _context.Users
            .Include(x => x.ProfileImage)
            .Include(x => x.UserAccount)
            .FirstOrDefaultAsync(x => x.IsActive && x.Id == userId)
            .ConfigureAwait(false);

        if (user is null)
        {
            response.AddError(_userNotFoundError);
            return response;
        }

        imageItem = await UpdateProfileImage(request, imageItem, user).ConfigureAwait(false);

        user.FirstName = request.FirstName;
        user.LastName = request.LastName;
        user.ModifiedBy = request.ModifiedBy;
        user.ModifiedDate = DateTimeOffset.Now;

        if (imageItem is not null)
            await _context.AddRangeAsync(imageItem).ConfigureAwait(false);
        await _context.SaveChangesAsync().ConfigureAwait(false);

        response.User = await MapAuthAsync(user, user.UserAccount);

        return response;
    }

    async ValueTask<AuthResponse> IAuthRepository.DeleteAccountAsync(string userId, string? modifiedBy)
    {
        var response = new AuthResponse();
        //string? subscriptionStatus = null;

        var user = await _context.Users
            .Include(x => x.ProfileImage)
            .Include(x => x.UserAccount)
            .ThenInclude(ua => ua!.Managers.Where(m => m.IsActive))
            .FirstOrDefaultAsync(x => x.IsActive && x.Id == userId)
            .ConfigureAwait(false);

        if (user is null || user.UserAccount is null)
        {
            response.AddError(_userNotFoundError);
            return response;
        }

        //if (user.UserAccount.SubscriptionStatus != SubscriptionStatus.canceled) //incomple condition required?
        //{
        //    var stripeDetails = await _paymentService
        //    .CancelSubscriptionAsync(user.UserAccount.SubscriptionId);

        //    if(stripeDetails is null || stripeDetails.Stripe is null)
        //    {
        //        response.AddError(_cancelSubscriptionError);
        //        return response;
        //    }

        //    subscriptionStatus = stripeDetails.Stripe.SubscriptionStatus;
        //}

        //foreach(var manager in user.UserAccount.Managers)
        //{
        //    manager.IsActive = false;// how do we handle this

        //    manager.ModifiedBy = modifiedBy;
        //    manager.ModifiedDate = DateTimeOffset.UtcNow;
        //}

        ////delete posts and all the images?

        //user.UserAccount.SubscriptionStatus = subscriptionStatus is not null ? _paymentService.MapSubscriptionStatusToEnum(subscriptionStatus) : user.UserAccount.SubscriptionStatus;
        //user.UserAccount.ApplicationUserId = user.Id;
        //user.UserAccount.IsActive = false;
        //user.UserAccount.ModifiedBy = modifiedBy;
        //user.UserAccount.ModifiedDate = DateTimeOffset.UtcNow;

        //user.IsActive = false;// how do we handle this
        //user.ModifiedBy = modifiedBy;
        //user.ModifiedDate = DateTimeOffset.UtcNow;

        //var roles = await _userManager.GetRolesAsync(user).ConfigureAwait(false);

        //var authDTO = new AuthDTO
        //{
        //    UserId = user.Id,
        //    FirstName = user.FirstName,
        //    LastName = user.LastName,
        //    UserName = user.UserName!,
        //    UserRole = roles.Count > 0 ? roles[0] : "",
        //    BearerToken = GenerateToken(user, roles),
        //    ProfileImage = user.ProfileImage is null ? null : new DocumentDTO
        //    {
        //        Id = user.ProfileImage.Id,
        //        FileName = user.ProfileImage.FileName,
        //        URL = _fileService.GetFileURL(user.ProfileImage.FileName),
        //        DocumentType = user.ProfileImage.DocumentType,
        //    },
        //    UserDetials = _mapper.Map<UserAccountDTO>(user.UserAccount),
        //    CreatedBy = user.CreatedBy,
        //    CreatedDate = user.CreatedDate,
        //    ModifiedBy = user.ModifiedBy,
        //    ModifiedDate = user.ModifiedDate
        //};

        ////await _context.SaveChangesAsync().ConfigureAwait(false);

        //response.User = authDTO;

        return response;
    }

    private string GenerateToken(ApplicationUser user, IList<string> roles)
    {
        List<Claim> claims = [
                new (ClaimTypes.NameIdentifier, user.Id),
                new (ClaimTypes.Name, $"{user.FirstName} {user.LastName}"),
            ];

        foreach (var role in roles)
        {
            claims.Add(new(ClaimTypes.Role, role));
        }

        var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(AppEnvironment.AuthSecretKey));

        var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha512Signature);

        var token = new JwtSecurityToken(
                claims: claims,
                expires: DateTime.Now.AddDays(355),
                signingCredentials: creds
            );

        var jwt = new JwtSecurityTokenHandler().WriteToken(token);

        return jwt;
    }

    private int GenerateRandomNumber()
    {
        int _min = _otpMinValue;
        int _max = _otpMaxValue;
        Random _rdm = new();
        return _rdm.Next(_min, _max);
    }

    private bool IsOTPExpired(DateTimeOffset date1, DateTimeOffset date2)
    {
        TimeSpan difference = date2 - date1;

        return Math.Abs(difference.TotalMinutes) >= AppEnvironment.OTPExpiry;
    }

    private async Task<Document?> UpdateProfileImage(UpdatePersonalInfoRequest request, Document? imageItem, ApplicationUser user)
    {
        if (user.ProfileImage is not null && (request.DeleteProfileImage || request.ProfileImage is not null))
        {
            user.ProfileImage.IsActive = false;
            user.ProfileImage.ModifiedBy = request.ModifiedBy;
            user.ProfileImage.ModifiedDate = DateTimeOffset.UtcNow;

            _fileService.DeleteUploadedFile(user.ProfileImage.FileName);

            user.ProfileImage = null;
        }

        if (request.ProfileImage is not null)
        {
            (var fileName, var filePath) = await _fileService.UploadFileAndGetNewFileNameAndPath(request.ProfileImage, request.ProfileImage.FileName, null).ConfigureAwait(false);

            imageItem = new Document
            {
                FileName = fileName,
                DocumentType = DocumentType.ProfileImage,
                ApplicationUserId = user.Id,
                ModifiedBy = request.ModifiedBy,
                ModifiedDate = DateTimeOffset.UtcNow,
            };

            user.ProfileImage = imageItem;
        }

        return imageItem;
    }

    private (string? message, bool isSubscriptionExpired) GetSubscriptionMessage(UserAccount? userDetails, bool isAdmin)
    {
        int trialDays;
        string? message = null;
        bool isSubscriptionExpired = false;
        if (userDetails is not null)
        {
            if (userDetails.SubscriptionStatus == SubscriptionStatus.trialing)
            {
                if (userDetails.SubscriptionDate.HasValue)
                {
                    trialDays = userDetails.SubscriptionDate.Value.AddDays(7).Date.Subtract(DateTimeOffset.UtcNow.Date).Days;

                    if (trialDays >= 0)
                        message = $"Your {userDetails.Plan.ToString()} Plan trial ends in {trialDays} days. Subscribe now to continue enjoying all the features without interruption.";
                    else
                    {
                        message = $"Your trial has ended. Subscribe now to continue enjoying all the features without interruption.";
                        isSubscriptionExpired = true;
                    }
                }
                else
                {
                    message = $"Subscribe now to continue enjoying all the features without interruption.";
                    isSubscriptionExpired = true;
                }
            }
            else if (userDetails.SubscriptionStatus == SubscriptionStatus.active)
                message = $"Your {userDetails.Plan.ToString()} plan is active. Now you can enjoy all the features without interruption.";
            else
            {
                message = $"Subscribe now to continue enjoying all the features without interruption.";
                isSubscriptionExpired = true;
            }
        }
        return (message, isSubscriptionExpired);

    }

    private async ValueTask<AuthDTO> MapAuthAsync(ApplicationUser user, UserAccount? userDetails)
    {
        var roles = await _userManager.GetRolesAsync(user).ConfigureAwait(false);
        var authDTO = new AuthDTO
        {
            UserId = user.Id,
            FirstName = user.FirstName,
            LastName = user.LastName,
            UserName = user.Email ?? string.Empty,
            UserRole = user.Role.ToString(),
            BearerToken = GenerateToken(user, roles),
            IsAuthenticated = true,
            UserDetials = _mapper.Map<UserAccountDTO>(userDetails),
            ProfileImage = user.ProfileImage is null ? null : new DocumentDTO
            {
                Id = user.ProfileImage.Id,
                FileName = user.ProfileImage.FileName,
                URL = _fileService.GetFileURL(user.ProfileImage.FileName),
                DocumentType = user.ProfileImage.DocumentType,
            },
            CreatedBy = user.CreatedBy,
            CreatedDate = user.CreatedDate,
            ModifiedBy = user.ModifiedBy,
            ModifiedDate = user.ModifiedDate
        };
        var subscriptionDetail = GetSubscriptionMessage(userDetails, authDTO.IsAdmin);
        authDTO.Message = subscriptionDetail.message;
        authDTO.IsSubscriptionExpired = subscriptionDetail.isSubscriptionExpired;
        return authDTO;
    }

}