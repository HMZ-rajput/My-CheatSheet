﻿using MarketPro.Data;
using MarketPro.OpenAi.DTOs;
using MarketPro.Services;
using Microsoft.AspNetCore.Http;

namespace MarketPro.Repositories;

public class OpenAiRepository : IOpenAiRepository
{
    private readonly IOpenAiService _openAiService;
    private readonly IPlanRuleValidator  _planRuleValidator;
    private readonly ApplicationDbContext _context;
    private readonly CurrentUser _currentUser;
    private readonly string _openAiError = "Something went wrong when generating Ai Content.";
    private readonly string _openAiPromptError = "Prompt is required.";
    public OpenAiRepository(IOpenAiService openAiService, IPlanRuleValidator planRuleValidator, ApplicationDbContext context ,IHttpContextAccessor httpContextAccessor)
    {
        _openAiService = openAiService ?? throw new ArgumentNullException(nameof(openAiService));
        _planRuleValidator = planRuleValidator ?? throw new ArgumentNullException(nameof(planRuleValidator));
        _context = context ?? throw new ArgumentNullException(nameof(context));
        _currentUser = new CurrentUser(httpContextAccessor);
    }

    async ValueTask<GenerateIdeaResponse> IOpenAiRepository.GenerateIdeaAsync(GenerateIdeaDTO request)
    {
        var response = new GenerateIdeaResponse();

        var adminUser = _context.UserAccount.FirstOrDefault(x => x.IsActive && (x.ApplicationUserId == _currentUser.Id || x.Managers.Select(m => m.Id).Contains(_currentUser.Id)));

        _planRuleValidator.CanGenerateAiContent(adminUser);

        if (request.BusinessDescription is null && request.Prompt is null)
        {
            response.AddError("Prompt is required.");
            return response;
        }

        var contentPrompt = "I have a custom social media management web app that allows users to generate content using AI. Generate a single social media post. The post should start directly with engaging content and avoid any introductions or explanations about the post itself.";
        //pending testing
        contentPrompt += " Make sure that content does not violate any content_policy_violation.";

        if (request.Prompt is not null)
            contentPrompt += $" - {request.Prompt} -.";

        if (request.BusinessDescription is not null)
            contentPrompt += $"This user has described his business as following - {request.BusinessDescription} -.";

        if (request.TargetAudience is not null)
            contentPrompt += $"This user has described his target audience as following - {request.TargetAudience} -.";

        var imagePrompt = $"Create a visually appealing and professional image for my business: {request.BusinessDescription}. Audience: {request.TargetAudience}.";

        if (request.Purpose is not null)
        {
            contentPrompt += $"This user has described his purpose as following - {request.Purpose} -.";
            imagePrompt += $" Purpose: {request.Purpose}.";
        }

        if (request.Tone is not null)
        {
            contentPrompt += $"Tone of conversion should be - {request.Tone} -.";
            imagePrompt += $" Tone: {request.Tone}.";
        }

        if (request.Keywords is not null)
            contentPrompt += $"Content should be around these keywords - {request.Keywords} -.";


        if (request.IsIdea)
            contentPrompt += "Generate summurized content under 1000 characters -.";

        contentPrompt += $"Generate some content for this.";

        imagePrompt += "Avoid including any text in the image.";

        if (imagePrompt.Length > 250)
            imagePrompt = imagePrompt.Substring(0, 247) + "...";


        for (var i = 0; i < 2; i++)
        {
            var postIdea = await GeneratePost(contentPrompt, imagePrompt, request.IsIdea, request.IsImageRequired).ConfigureAwait(false);

            if (postIdea is null)
            {
                response.AddError(_openAiError);
                return response;
            }

            response.Ideas.Add(postIdea);
        }

        return response;
    }

    private async ValueTask<GetGeneratedIdeaDTO?> GeneratePost(string contentPrompt, string imagePrompt, bool isIdea, bool isImageRequired)
    {
        GenerateImageResponse? imageUrl = new();
        var content = await _openAiService.GenerateContentAsync(contentPrompt).ConfigureAwait(false);

        if (content is null || content.Content is null || content.Errors.Any())
            return null;

        if (!isIdea && isImageRequired)
        {
            var aiPrompt =
            "Analyze the following content and craft a concise prompt, under 1000 characters, for generating an image." +
            //pending testing
            " Make sure that prompt does not violate any content_policy_violation. " +
            "The prompt should vividly describe the scene, include specific details, and reflect the mood and essence of the content. " +
            "Content: " + content.Content;

            var imageAiPrompt = await _openAiService.GenerateContentAsync(aiPrompt).ConfigureAwait(false);
            if (imageAiPrompt is null || imageAiPrompt.Content is null || imageAiPrompt.Errors.Any())
                return null;

            imageUrl = await _openAiService.GenerateImageAsync(imageAiPrompt.Content).ConfigureAwait(false);

            if (imageUrl is null || imageUrl.Urls is null || imageUrl.Urls.Count == 0 || imageUrl.Errors.Any())
                return null;

        }

        return new GetGeneratedIdeaDTO
        {
            Content = content.Content,
            Urls = imageUrl.Urls ?? null,
        };
    }

}

