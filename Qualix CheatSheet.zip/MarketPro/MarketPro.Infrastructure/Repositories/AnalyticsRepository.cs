﻿using MarketPro.Analytics.DTOs;
using MarketPro.Analytics.Entities;
using MarketPro.Data;
using MarketPro.Documents.DTOs;
using MarketPro.Documents.Entities;
using MarketPro.Posts.DTOs;
using MarketPro.Posts.Entities;
using MarketPro.Services;
using MarketPro.SocialAccounts.DTOs;
using MarketPro.SocialAccounts.Entities;
using Microsoft.EntityFrameworkCore;

namespace MarketPro.Repositories;

public class AnalyticsRepository :
    BaseRepository<Report>,
    IAnalyticsRepository<Report>
{
    private const string _postNotFoundError = "Post does not exist.";
    private const string _userNotFoundError = "User does not exist.";
    private const string _reportNotFoundError = "Report does not exist.";
    private const string _imageCountError = "Atleast one image is required to create report.";
    private const string _reportAlreadyExistError = "Report name must be unique.";

    private readonly ApplicationDbContext _context;
    private readonly IFileService _fileService;
    private readonly ISocialAccountRepository<SocialAccount> _socialAccountRepository;
    private readonly IPlanRuleValidator _planValidator;

    public AnalyticsRepository(ApplicationDbContext context, IFileService fileService, ISocialAccountRepository<SocialAccount> socialAccountRepository, IPlanRuleValidator planValidator) : base(context)
    {
        _context = context ?? throw new ArgumentNullException(nameof(context));
        _fileService = fileService ?? throw new ArgumentNullException(nameof(fileService));
        _socialAccountRepository = socialAccountRepository ?? throw new ArgumentNullException(nameof(socialAccountRepository));
        _planValidator = planValidator ?? throw new ArgumentNullException(nameof(planValidator));
    }

    async ValueTask<GetAnalyticsResponse> IAnalyticsRepository<Report>.GetAnalyticsAsync(string userId, AnalyticsFilters filters)
    {
        var response = new GetAnalyticsResponse();
        var analytics = new AnalyticsDTO();
        IList<string> socialAccountType = [];
        IList<string> socialAccountIds = [];

        var userAccount = _context.UserAccount
            .Include(x => x.Managers.Where(m => m.IsActive))
            .FirstOrDefault(x => x.IsActive && x.ApplicationUserId == userId);

        IList<string> managerIds = [];

        if (userAccount is not null)
        {
            managerIds = userAccount.Managers.Select(x => x.Id).ToList();
        }

        IQueryable<SocialAccount> socialAccountQuery = _context.SocialAccount
            .Include(x => x.ApplicationUser)
            .ThenInclude(au => au!.UserAccount)
            .Where(x => x.IsActive && (x.ApplicationUserId == userId || x.Managers.Select(m => m.Id).Contains(userId)));

        if (filters.socialAccountTypes is not null)
            socialAccountType = filters.socialAccountTypes.Split(',').ToList();

        if (filters.socialAccountIds is not null)
            socialAccountIds = filters.socialAccountIds.Split(',').ToList();

        socialAccountQuery = socialAccountQuery.Where(x =>
                (socialAccountIds.Count == 0 || socialAccountIds.Contains(x.Id.ToString())) &&
                (socialAccountType.Count == 0 || socialAccountType.Contains(((int)x.Type).ToString()))
            );

        var socialAccounts = await socialAccountQuery.GroupBy(m => m.SocialAccountId).Select(g => g.FirstOrDefault()).ToListAsync().ConfigureAwait(false);

        if (socialAccounts is null || socialAccounts.Count == 0)
            return response;

        bool isManager = socialAccounts.First()?.ApplicationUserId != userId ? true : false;
        _planValidator.IsSubscriptionValid(socialAccounts.First()?.ApplicationUser?.UserAccount, isManager);

        var newSocialAccountIds = socialAccounts.Select(x => x?.Id).ToList();

        var posts = await _context.Post
            .Where(x => x.IsActive &&
                       (x.ApplicationUserId == userId || managerIds.Contains(x.ApplicationUserId ?? "")) &&
                       newSocialAccountIds.Contains(x.SocialAccountId ?? Guid.Empty) &&
                       (x.Status == PostStatus.Queue ||
                        x.Status == PostStatus.Published ||
                        x.Status == PostStatus.Draft))
            .Include(x => x.SocialAccount)
            .Include(x => x.Images.Where(i => i.IsActive))
            .ToListAsync()
            .ConfigureAwait(false);

        var result = posts
            .GroupBy(x => x.Status)
            .SelectMany(g =>
            g.Key == PostStatus.Queue
                ? g.OrderByDescending(p => p.ScheduledDate).Take(3)
                : g.OrderByDescending(p => p.ModifiedDate ?? p.CreatedDate).Take(3))
            .ToList();


        var draftPosts = result.Where(x => x.Status == PostStatus.Draft).ToList();
        var publishedPosts = result.Where(x => x.Status == PostStatus.Published).ToList();
        var upcommingPosts = result.Where(x => x.Status == PostStatus.Queue).OrderByDescending(x => x.ScheduledDate).ToList();

        if (draftPosts.Count > 0)
            analytics.RecentDrafts = draftPosts.Select(p => MapPost(p, _fileService)).ToList();
        if (publishedPosts.Count > 0)
            analytics.RecentlyPublished = publishedPosts.Select(p => MapPost(p, _fileService)).ToList();
        if (upcommingPosts.Count > 0)
            analytics.UpcomingPosts = upcommingPosts.Select(p => MapPost(p, _fileService)).ToList();

        var socialAccountAnalytics = await _socialAccountRepository.GetSocialAccountAnalytics(socialAccounts).ConfigureAwait(false);

        if (socialAccounts.Count > 0)
            analytics.SocialAccountAnalytics = socialAccountAnalytics.SocialAccountAnalytics;

        analytics.TotalAudianceGraph = socialAccountAnalytics.TotalAudianceGraph;
        analytics.TotalImpressionsGraph = socialAccountAnalytics.TotalImpressionsGraph;
        analytics.TotalEngagmentGraph = socialAccountAnalytics.TotalEngagmentGraph;

        response.Analytics = analytics;

        return response;
    }

    async ValueTask<GetReportResponse> IAnalyticsRepository<Report>.CreateReportAsync(string userId, CreateReportDTO request)
    {
        var response = new GetReportResponse();
        Document? image = null;

        var user = await _context.Users
            .Include(x => x.UserAccount)
            .Include(x => x.AdminAccount)
            .FirstOrDefaultAsync(x => x.IsActive && x.Id == userId)
            .ConfigureAwait(false);

        if (user is null)
        {
            response.AddError(_userNotFoundError);
            return response;
        }

        _planValidator.IsSubscriptionValid(user.UserAccount ?? user.AdminAccount, user.UserAccount is not null ? false : true);

        var existingName = await _context.Report
            .FirstOrDefaultAsync(x => x.IsActive && x.ApplicationUserId == userId && x.Name.ToLower().Trim() == request.Name.ToLower().Trim())
            .ConfigureAwait(false);

        if (existingName is not null)
        {
            response.AddError(_reportAlreadyExistError);
            return response;
        }

        //do we need validation for userId?

        var report = new Report
        {
            Name = request.Name,
            ApplicationUserId = userId,
            CreatedBy = request.ModifiedBy,
            ModifiedDate = DateTimeOffset.UtcNow,
        };

        if (request.Image is not null)
        {
            (var fileName, var filePath) = await _fileService.UploadFileAndGetNewFileNameAndPath(request.Image, request.Image.FileName, null).ConfigureAwait(false);
            var imageItem = new Document()
            {
                FileName = fileName,
                ReportId = report.Id,
                DocumentType = DocumentType.Report,

                ModifiedBy = request.ModifiedBy,
                ModifiedDate = DateTimeOffset.UtcNow,
            };

            report.Images.Add(imageItem);
            image = imageItem;
        }

        if (image is not null)
            await _context.AddAsync(image).ConfigureAwait(false);
        await _context.AddAsync(report).ConfigureAwait(false);
        await SaveChangesAsync().ConfigureAwait(false);

        response.Report = MapReport(report, _fileService);

        return response;
    }

    async ValueTask<GetReportResponse> IAnalyticsRepository<Report>.UpdateReportByIdAsync(string userId, Guid reportId, UpdateReportDTO request)
    {
        var response = new GetReportResponse();
        Document? image = null;

        var userAccount = _context.UserAccount
            .Include(x => x.Managers)
            .FirstOrDefault(x => x.IsActive && x.ApplicationUserId == userId);

        IList<string> managerIds = [];

        if (userAccount is not null)
        {
            managerIds = userAccount.Managers.Select(x => x.Id).ToList();
        }

        if (request.Image is null)
        {
            response.AddError(_imageCountError);
            return response;
        }

        var report = await _context.Report
            .Include(x => x.ApplicationUser)
                .ThenInclude(au => au!.AdminAccount)
            .Include(x => x.Images.Where(i => i.IsActive))
            .FirstOrDefaultAsync(x => x.IsActive && x.Id == reportId && (x.ApplicationUserId == userId || managerIds.Contains(x.ApplicationUserId ?? "")))
            .ConfigureAwait(false);

        if (report is null)
        {
            response.AddError(_reportNotFoundError);
            return response;
        }

        _planValidator.IsSubscriptionValid(userAccount ?? report.ApplicationUser!.AdminAccount, userAccount is not null ? false : true);

        (var fileName, var filePath) = await _fileService.UploadFileAndGetNewFileNameAndPath(request.Image, request.Image.FileName, null).ConfigureAwait(false);
        var imageItem = new Document()
        {
            FileName = fileName,
            ReportId = report.Id,
            DocumentType = DocumentType.Report,
            CreatedBy = request.ModifiedBy,
            ModifiedDate = DateTimeOffset.UtcNow,
        };

        report.Images.Add(imageItem);
        image = imageItem;

        report.ModifiedBy = request.ModifiedBy;
        report.ModifiedDate = DateTimeOffset.UtcNow;

        if (image is not null)
            await _context.AddAsync(image).ConfigureAwait(false);
        await SaveChangesAsync().ConfigureAwait(false);

        response.Report = MapReport(report, _fileService);

        return response;
    }

    async ValueTask<GetReportResponse> IAnalyticsRepository<Report>.GetReportByIdAsync(string userId, Guid reportId)
    {
        var response = new GetReportResponse();

        var userAccount = _context.UserAccount
            .Include(x => x.Managers)
            .FirstOrDefault(x => x.IsActive && x.ApplicationUserId == userId);

        IList<string> managerIds = [];

        if (userAccount is not null)
        {
            managerIds = userAccount.Managers.Select(x => x.Id).ToList();
        }

        var report = await _context.Report
            .Include(x => x.Images.Where(i => i.IsActive))
            .FirstOrDefaultAsync(x => x.IsActive && x.Id == reportId && (x.ApplicationUserId == userId || managerIds.Contains(x.ApplicationUserId ?? "")))
            .ConfigureAwait(false);

        if (report is null)
        {
            response.AddError(_reportNotFoundError);
            return response;
        }

        response.Report = MapReport(report, _fileService);

        return response;
    }

    async ValueTask<GetAllReportResponse> IAnalyticsRepository<Report>.GetAllReportsByIdAsync(string userId)
    {
        var response = new GetAllReportResponse();

        var userAccount = _context.UserAccount
            .Include(x => x.Managers)
            .FirstOrDefault(x => x.IsActive && x.ApplicationUserId == userId);

        IList<string> managerIds = [];

        if (userAccount is not null)
        {
            managerIds = userAccount.Managers.Select(x => x.Id).ToList();
        }

        var reports = await _context.Report
            .Include(x => x.Images.Where(i => i.IsActive))
            .Where(x => x.IsActive && (x.ApplicationUserId == userId || managerIds.Contains(x.ApplicationUserId ?? "")))
            .ToListAsync()
            .ConfigureAwait(false);

        response.Reports = reports.Select(r => MapReport(r, _fileService)).ToList();

        return response;
    }

    async ValueTask<GetReportResponse> IAnalyticsRepository<Report>.DeleteReportByIdAsync(string userId, Guid reportId, string? modifiedBy)
    {
        var response = new GetReportResponse();

        var userAccount = _context.UserAccount
            .Include(x => x.Managers)
            .FirstOrDefault(x => x.IsActive && x.ApplicationUserId == userId);

        IList<string> managerIds = [];

        if (userAccount is not null)
        {
            managerIds = userAccount.Managers.Select(x => x.Id).ToList();
        }

        var report = await _context.Report
            .Include(x => x.Images.Where(i => i.IsActive))
            .Include(x => x.ApplicationUser)
                .ThenInclude(au => au!.AdminAccount)
            .FirstOrDefaultAsync(x => x.IsActive && x.Id == reportId && (x.ApplicationUserId == userId || managerIds.Contains(x.ApplicationUserId ?? "")))
            .ConfigureAwait(false);

        if (report is null)
        {
            response.AddError(_reportNotFoundError);
            return response;
        }

        _planValidator.IsSubscriptionValid(userAccount ?? report.ApplicationUser!.AdminAccount, userAccount is not null ? false : true);

        foreach (var image in report.Images.ToList())
        {
            image.IsActive = false;
            image.ModifiedBy = modifiedBy;
            image.ModifiedDate = DateTimeOffset.UtcNow;

            _fileService.DeleteUploadedFile(image.FileName);

            report.Images.Remove(image);
        }

        report.IsActive = false;
        report.ModifiedBy = modifiedBy;
        report.ModifiedDate = DateTimeOffset.UtcNow;

        await SaveChangesAsync().ConfigureAwait(false);

        response.Report = MapReport(report, _fileService);

        return response;
    }

    private GetPostDTO MapPost(Post post, IFileService _fileService)
    {
        return new GetPostDTO
        {
            Id = post.Id,
            Content = post.Content,
            IsPublished = post.IsPublished,
            Status = post.Status,
            ScheduledDate = post.ScheduledDate,
            PublishedDate = post.PublishDate,
            PublishedBy = post.PublishedBy,
            PublisedPostId = post.PublishedPostId,
            PageId = post.SocialAccount is not null ?
                    post.SocialAccount.Type != SocialAccountType.Instagram ?
                        post.PageId :
                    post.SocialAccount.SocialAccountId :
                null,
            PageName = post.SocialAccount is not null ?
                    post.SocialAccount.Type != SocialAccountType.Instagram ?
                        post.PageName :
                    post.SocialAccount.FirstName :
                null,
            Images = post.Images.Select(x => new DocumentDTO
            {
                Id = x.Id,
                FileName = x.FileName,
                URL = _fileService.GetFileURL(x.FileName),
                DocumentType = x.DocumentType,
            }).ToList(),
            SocialAccount = post.SocialAccount is null ? null : new SocialAccountInfoDTO
            {
                Id = post.SocialAccount.Id,
                Type = post.SocialAccount.Type,
                FirstName = post.SocialAccount.FirstName,
                LastName = post.SocialAccount.LastName,
                ProfilePicture = post.SocialAccount.ProfilePicture,
                PageId = post.SocialAccount.Type != SocialAccountType.Instagram ?
                        post.PageId :
                    post.SocialAccount.SocialAccountId,
                PageName = post.SocialAccount.Type != SocialAccountType.Instagram ?
                        post.PageName :
                    post.SocialAccount.FirstName
            },
            CreatedBy = post.CreatedBy,
            CreatedDate = post.CreatedDate,
            ModifiedBy = post.ModifiedBy,
            ModifiedDate = post.ModifiedDate,
            DisplayDate = post.Status == PostStatus.Queue ?
                            post.ScheduledDate :
                            post.Status == PostStatus.Published ?
                                post.PublishDate :
                                post.ModifiedDate ?? post.CreatedDate
        };
    }

    private GetReportDTO MapReport(Report report, IFileService fileService)
    {
        return new GetReportDTO
        {
            Id = report.Id,
            Name = report.Name,
            Images = report.Images.Select(x => new DocumentDTO
            {
                Id = x.Id,
                FileName = x.FileName,
                URL = fileService.GetFileURL(x.FileName),
                DocumentType = x.DocumentType,
            }).ToList(),
            CreatedBy = report.CreatedBy,
            CreatedDate = report.CreatedDate,
            ModifiedBy = report.ModifiedBy,
            ModifiedDate = report.ModifiedDate,
        };
    }

    private AnalyticsGraph MapGraph()
    {
        var graph = new AnalyticsGraph();
        Random random = new Random();

        IList<int> yAxis = [];
        IList<string> xAxis = [];

        for (int i = 0; i < 7; i++)
        {
            yAxis.Add(i * random.Next(100, 200));
            xAxis.Add(DateTimeOffset.UtcNow.Date.AddDays(i).ToString("dd-MMM").Replace("-", " "));
        }

        graph.XAxis = xAxis;
        graph.YAxis = yAxis;

        return graph;
    }

}

