﻿using Microsoft.AspNetCore.Http;
using System.Security.Claims;

namespace MarketPro;

public class CurrentUser(IHttpContextAccessor httpContextAccessor)
{
    public string? Id => httpContextAccessor.HttpContext?.User.FindFirstValue(ClaimTypes.NameIdentifier);
    public string? Name => httpContextAccessor.HttpContext?.User.FindFirstValue(ClaimTypes.Name);
    public string? Role => httpContextAccessor.HttpContext?.User.FindFirstValue(ClaimTypes.Role);
}