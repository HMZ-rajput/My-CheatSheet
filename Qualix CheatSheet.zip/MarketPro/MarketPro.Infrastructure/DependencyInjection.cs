﻿using MarketPro.Analytics.Entities;
using MarketPro.Application;
using MarketPro.Data;
using MarketPro.IRepositories;
using MarketPro.Managers.Entities;
using MarketPro.Posts.Entities;
using MarketPro.Repositories;
using MarketPro.Services;
using MarketPro.SocialAccounts.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using Microsoft.Extensions.DependencyInjection;

namespace MarketPro;

public static class DependencyInjection
{
    public static IServiceCollection AddInfrastructure(this IServiceCollection services, string? connectionString)
    {
        services.AddDbContext<ApplicationDbContext>(options => options.UseSqlServer(connectionString));
        services.AddScoped<IAuthRepository, AuthRepository>();
        services.AddScoped<IFileService, FileService>();
        services.AddScoped<IPostRepository<Post>, PostRepository>();
        services.AddScoped<ISocialAccountRepository<SocialAccount>, SocialAccountRepository>();
        services.AddScoped<IPaymentRepository, PaymentRepository>();
        services.AddScoped<IUserAccountRepository, UserAccountRepository>();
        services.AddScoped<IManagerRepository<Invitation>, ManagerRepository>();
        services.AddSingleton(MappingConfiguration.ConfigureAndCreateMapper());
        services.AddScoped(typeof(CurrentUser));
        services.AddTransient<SocialAccountRepository>(); // For cron
        services.AddScoped<IAnalyticsRepository<Report>, AnalyticsRepository>();
        services.AddScoped<IOpenAiRepository, OpenAiRepository>();

        return services;
    }
}

public class DesignTimeApplicationDbContext : IDesignTimeDbContextFactory<ApplicationDbContext>
{
    public ApplicationDbContext CreateDbContext(string[] args)
    {
        var optionsBuilder = new DbContextOptionsBuilder<ApplicationDbContext>();
        optionsBuilder.UseSqlServer(AppEnvironment.ConnectionString);
        return new ApplicationDbContext(optionsBuilder.Options);
    }
}
