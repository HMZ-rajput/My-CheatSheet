﻿using Azure;
using MarketPro.Application;
using MarketPro.Data;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Hosting;

namespace MarketPro.Services;

public class FileService : IFileService
{
    private const string _rootFolderName = "wwwroot";
    private const string _uploadsFolderName = "uploads";
    private const string _invalidExtension = "The file must have a valid extension. The provided extension is not allowed.";
    private const string _underscore = "_";
    private const string _unableToDownloadImage = "Unable to download image.";
    private const int _startingFolderVersionNumber = 1;

    private readonly ApplicationDbContext _context;
    private readonly HttpClient _httpClient;
    private readonly IHostEnvironment _hostEnvironment;

    public FileService(IHostEnvironment hostEnvironment, ApplicationDbContext context, HttpClient httpClient)
    {
        _context = context ?? throw new ArgumentNullException(nameof(context));
        _httpClient = httpClient ?? throw new ArgumentNullException(nameof(httpClient));
        _hostEnvironment = hostEnvironment ?? throw new ArgumentNullException(nameof(hostEnvironment));
    }

    bool IFileService.DeleteUploadedFile(string fileName)
    {
        var filePath = Path.Combine(UploadDirectoryPath(), fileName);

        if (!File.Exists(filePath)) return false;

        File.Delete(filePath);
        return true;
    }

    string IFileService.GetUploadDirectoryPath() => UploadDirectoryPath();

    string IFileService.GetFileURL(string fileName)
    {
        return $"{AppEnvironment.BaseURL}/{_uploadsFolderName}/{fileName}";
    }

    async ValueTask<byte[]> IFileService.DownloadImageAsByteArrayAsync(string imageUrl)
    {
        HttpResponseMessage response = await _httpClient.GetAsync(imageUrl);

        if (response.IsSuccessStatusCode)
        {
            return await response.Content.ReadAsByteArrayAsync();
        }

        throw new InvalidOperationException(_unableToDownloadImage);
    }

    async ValueTask<(string fileName, string filePath)> IFileService.UploadFileAndGetNewFileNameAndPath(IFormFile file, string fileName, IList<string>? fileNames)
    {
        var extension = Path.GetExtension(fileName)?.ToLower();

        if (string.IsNullOrEmpty(extension))
        {
            throw new InvalidOperationException(_invalidExtension);
        }

        (var newFileName, var filePath) = GetUniqueFileNameAndPath(fileName, fileNames);
        using var stream = new FileStream(filePath, FileMode.Create);
        await file.CopyToAsync(stream).ConfigureAwait(false);
        return (newFileName, filePath);
    }

    (string? newFileName, string? destinationFilePath) IFileService.DuplicateFileAndGetNewFileNameAndPath(string fileName, IList<string>? fileNames)
    {
        var sourceFilePath = Path.Combine(UploadDirectoryPath(), fileName);
        var extension = Path.GetExtension(fileName)?.ToLower();

        if (string.IsNullOrEmpty(extension))
        {
            throw new InvalidOperationException(_invalidExtension);
        }

        (var newFileName, var destinationFilePath) = GetUniqueFileNameAndPath(fileName, fileNames);

        if (File.Exists(sourceFilePath))
        {
            File.Copy(sourceFilePath, destinationFilePath);
            return (newFileName, destinationFilePath);
        }

        return (null, null);
    }

    async ValueTask<(string fileName, string filePath)> IFileService.UploadFileFromUrlAndGetNewFileNameAndPath(string imageUrl, IList<string>? fileNames)
    {

        using var httpResponse = await _httpClient.GetAsync(imageUrl, HttpCompletionOption.ResponseHeadersRead);

        if (!httpResponse.IsSuccessStatusCode)
            throw new InvalidOperationException(_unableToDownloadImage);

        var contentType = httpResponse.Content.Headers.ContentType?.MediaType;
        var fileExtension = GetFileExtensionFromContentType(contentType);

        if(fileExtension is null)
            throw new InvalidOperationException(_invalidExtension);

        (var newFileName, var filePath) = GetUniqueFileNameAndPath($"Ai_Generated_Image{fileExtension}", fileNames);

        using var stream = await httpResponse.Content.ReadAsStreamAsync();
        using var fileStream = new FileStream(filePath, FileMode.Create, FileAccess.Write, FileShare.None, 8192, true);
        await stream.CopyToAsync(fileStream);
        return (newFileName, filePath);
    }

    private (string uniqueFileName, string filePath) GetUniqueFileNameAndPath(string fileName, IList<string>? fileNames)
    {
        fileName = Path.GetFileName(fileName);
        var uniqueFileName = fileName;

        bool isUniqueName = false;
        int i = _startingFolderVersionNumber;

        var documentNames = _context.Document.Select(x => x.FileName).ToList();

        if (fileNames is not null)
            documentNames = [..documentNames, ..fileNames];

        while (!isUniqueName)
        {
            var doesNameExist = documentNames.Any(x => x.ToLower().Trim() == uniqueFileName.ToLower().Trim());

            if (doesNameExist)
            {
                uniqueFileName = Path.GetFileNameWithoutExtension(fileName) + "_" + i + Path.GetExtension(fileName);
                i++;
            }
            else
            {
                isUniqueName = true;
            }
        }

        var uploadsFolderPath = UploadDirectoryPath();
        var filePath = Path.Combine(uploadsFolderPath, uniqueFileName);
        return (uniqueFileName, filePath);
    }

    private string UploadDirectoryPath()
    {
        var contentRootPath = Path.Combine(Directory.GetCurrentDirectory(), _rootFolderName);
        var uploadsFolderPath = Path.Combine(contentRootPath, _uploadsFolderName);

        if (!Directory.Exists(uploadsFolderPath))
        {
            Directory.CreateDirectory(uploadsFolderPath);
        }

        return uploadsFolderPath;
    }

    private string? GetFileExtensionFromContentType(string? contentType)
    {
        return contentType?.ToLower() switch
        {
            "image/jpeg" => ".jpg",
            "image/png" => ".png",
            _ => null
        };
    }
}
