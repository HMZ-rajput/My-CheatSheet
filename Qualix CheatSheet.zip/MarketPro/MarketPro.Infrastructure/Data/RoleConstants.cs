﻿using Microsoft.AspNetCore.Identity;

namespace MarketPro.Data;

public static class RoleConstants
{
    public static readonly IdentityRole AdminRole = new()
    {
        Id = "833b7264-9e3f-4e2e-a752-628690acb053",
        Name = "Admin",
        NormalizedName = "ADMIN"
    };

    public static readonly IdentityRole ManagerRole = new()
    {
        Id = "15ed2398-0e42-4d5b-9f83-d1727f0bd5e9",
        Name = "Manager",
        NormalizedName = "MANAGER"
    };
}
