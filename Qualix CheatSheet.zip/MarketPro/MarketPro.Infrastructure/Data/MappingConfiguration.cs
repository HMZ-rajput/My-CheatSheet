﻿using AutoMapper;
using MarketPro.Posts.DTOs;
using MarketPro.Posts.Entities;
using MarketPro.SocialAccounts.DTOs;
using MarketPro.SocialAccounts.Entities;
using MarketPro.UserAccounts.DTOs;
using MarketPro.UserAccounts.Entities;

namespace MarketPro.Data;

public static class MappingConfiguration
{
    public static IMapper ConfigureAndCreateMapper() =>
        new MapperConfiguration(cfg =>
        {
            cfg.CreateMap<GetPostResponseDTO, Post>().ReverseMap();
            cfg.CreateMap<GetSocialAccountDTO, SocialAccount>().ReverseMap();
            cfg.CreateMap<UserAccountDTO, UserAccount>().ReverseMap();
        }).CreateMapper();
}
