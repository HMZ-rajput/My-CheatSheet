﻿using MarketPro.Analytics.Entities;
using MarketPro.Documents.Entities;
using MarketPro.Identity.Entities;
using MarketPro.Managers.Entities;
using MarketPro.Posts.Entities;
using MarketPro.SocialAccounts.Entities;
using MarketPro.UserAccounts.Entities;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace MarketPro.Data;

public class ApplicationDbContext : IdentityDbContext<ApplicationUser>
{
    public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
    {
    }

    public DbSet<Document> Document { get; set; }
    public DbSet<Post> Post { get; set; }
    public DbSet<SocialAccount> SocialAccount { get; set; }
    public DbSet<UserAccount> UserAccount { get; set; }
    public DbSet<Invitation> Invitation { get; set; }
    public DbSet<Report> Report { get; set; }

    protected override void OnModelCreating(ModelBuilder builder)
    {
        base.OnModelCreating(builder);

        builder.Entity<ApplicationUser>()
            .HasOne(x => x.UserAccount)
            .WithOne(x => x.ApplicationUser);

        builder.Entity<ApplicationUser>()
            .HasMany(x => x.SocialAccounts)
            .WithOne(x => x.ApplicationUser);

        builder.Entity<UserAccount>()
            .HasMany(x => x.Managers)
            .WithOne(x => x.AdminAccount);

        builder.Entity<SocialAccount>()
            .HasOne(x => x.ApplicationUser)
            .WithMany(x => x.SocialAccounts);

        builder.Entity<SocialAccount>()
            .HasMany(x => x.Managers)
            .WithMany(x => x.ManagerSocialAccounts);



        builder.ApplyConfiguration(new RoleConfiguration());
    }
}
