﻿using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace MarketPro.Data;

public class RoleConfiguration : IEntityTypeConfiguration<IdentityRole>
{
    public void Configure(EntityTypeBuilder<IdentityRole> builder)
    {
        builder.HasData(
            new IdentityRole
            {
                Id = RoleConstants.AdminRole.Id,
                Name = RoleConstants.AdminRole.Name,
                NormalizedName = RoleConstants.AdminRole.NormalizedName
            },
            new IdentityRole
            {
                Id = RoleConstants.ManagerRole.Id,
                Name = RoleConstants.ManagerRole.Name,
                NormalizedName = RoleConstants.ManagerRole.NormalizedName
            }
        );
    }
}