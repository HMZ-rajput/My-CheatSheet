﻿using MarketPro.Managers.DTOs;
using MarketPro.Managers.Entities;
using MarketPro.Repositories;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace MarketPro.Controllers;

[Route("api/manager")]
[ApiController]
public class ManagerController : BaseController
{
    private readonly IManagerRepository<Invitation> _managerRepository;

    public ManagerController(IManagerRepository<Invitation> managerRepository)
    {
        _managerRepository = managerRepository ?? throw new ArgumentNullException(nameof(managerRepository));
    }

    [Authorize(Roles = "Admin")]
    [Route("invite/UserAccount/{userAccountId}")]
    [HttpPost]
    public async ValueTask<IActionResult> CreateInvitationAsync(string userAccountId, [FromBody] CreateInvitationDTO request)
    {
        request.ModifiedBy = BaseIdentityClaims.GetUserNameFromClaims(User);
        return await HandleRequestAsync(() => _managerRepository.CreateInvitationAsync(userAccountId, request));
    }

    [Route("invitationAction/{invitationId}")]
    [HttpPost]
    public async ValueTask<IActionResult> AcceptOrDenyInvitationAsync(Guid invitationId, [FromQuery] bool isAccept) =>
        await HandleRequestAsync(() => _managerRepository.AcceptOrDenyInvitationAsync(invitationId, isAccept));

    [Authorize(Roles = "Admin")]
    [HttpGet("{userId}")]
    public async ValueTask<IActionResult> GetAllManagersByUserIdAsync(string userId) =>
        await HandleRequestAsync(() => _managerRepository.GetAllManagersByUserIdAsync(userId));

    [Authorize(Roles = "Admin")]
    [Route("delete/{entityId}/{userAccountId}")]
    [HttpDelete]
    public async ValueTask<IActionResult> DeleteManagerByIdAsync(string userAccountId, string entityId, [FromBody] DeleteManagerDTO request)
    {
        request.ModifiedBy = BaseIdentityClaims.GetUserNameFromClaims(User);
        return await HandleRequestAsync(() => _managerRepository.DeleteManagerByIdAsync(userAccountId, entityId, request));
    }

    [Authorize(Roles = "Admin")]
    [Route("update/manager/{managerId}/{userAccountId}")]
    [HttpPut]
    public async ValueTask<IActionResult> UpdateManagerSocialAccountAsync(string userAccountId, string managerId, [FromBody] UpdateManagerRequest request)
    {
        request.ModifiedBy = BaseIdentityClaims.GetUserNameFromClaims(User);
        return await HandleRequestAsync(() => _managerRepository.UpdateManagerSocialAccountAsync(userAccountId, managerId, request));
    }
}
