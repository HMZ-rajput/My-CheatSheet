﻿using MarketPro.Repositories;
using MarketPro.UserAccounts.DTOs;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace MarketPro.Controllers;

[Authorize]
[Route("api/userAccount")]
[ApiController]
public class UserAccountController : BaseController
{
    private readonly IUserAccountRepository _userAccountRepository;

    public UserAccountController(IUserAccountRepository userAccountRepository)
    {
        _userAccountRepository = userAccountRepository ?? throw new ArgumentNullException(nameof(userAccountRepository));
    }

    [Route("update/{id:required}")]
    [HttpPut]
    public async ValueTask<IActionResult> UpdateUserAccountAsync(string id, [FromBody] UpdateUserRequest request)
    {
        var modifiedBy = BaseIdentityClaims.GetUserNameFromClaims(User);
        return await HandleRequestAsync(() => _userAccountRepository.UpdateUserAsync(id, request, modifiedBy)).ConfigureAwait(false);
    }

    [Route("checkSubscription")]
    [HttpGet]
    public async ValueTask<IActionResult> GetUserAccountAsync() =>
        await HandleRequestAsync(() => _userAccountRepository.GetUserPlanAsync()).ConfigureAwait(false);
}
