﻿using MarketPro.IRepositories;
using MarketPro.Payments.DTOs;
using MarketPro.Repositories;
using MarketPro.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Stripe;

namespace MarketPro.Controllers;

[Route("api/payment")]
[ApiController]
public class PaymentController : BaseController
{
    private readonly IPaymentService _paymentService;
    private readonly IPaymentRepository _paymentRepository;

    public PaymentController(IPaymentRepository paymentRepository, IPaymentService paymentService)
    {
        _paymentService = paymentService ?? throw new ArgumentNullException(nameof(paymentService));
        _paymentRepository = paymentRepository ?? throw new ArgumentNullException(nameof(paymentRepository));
    }

    [Route("getClientKey")]
    [HttpPost]
    public async ValueTask<IActionResult> GetClientKeyAsync(CreateIntentAndGetKeyRequest request) =>
        await HandleRequestAsync(() => _paymentService.CreateIntentAndGetKeyAsync(request))
        .ConfigureAwait(false);

    [HttpPost("/api/webhook")]
    public async ValueTask<IActionResult> StripeWebhook()
    {
        try
        {
            var json = await new StreamReader(HttpContext.Request.Body).ReadToEndAsync();
            var stripeEvent = EventUtility.ParseEvent(json, throwOnApiVersionMismatch: false);

            if (stripeEvent.Type == Events.CustomerSubscriptionUpdated ||
                stripeEvent.Type == Events.CustomerSubscriptionDeleted ||
                stripeEvent.Type == Events.CustomerSubscriptionPaused ||
                stripeEvent.Type == Events.InvoicePaymentFailed || 
                stripeEvent.Type == Events.ChargeFailed)
            {
                var subscription = stripeEvent.Data.Object as Subscription;
                await _paymentRepository.UpdateUserSubscriptionStatusAsync(subscription);
            }

            if (stripeEvent.Type == Events.InvoicePaymentSucceeded || stripeEvent.Type == Events.ChargeSucceeded)
            {
                var invoice = stripeEvent.Data.Object as Invoice;
                await _paymentRepository.SendPaymentEmailAsync(invoice);
            }

            return Ok();
        }
        catch (Exception ex)
        {
            return BadRequest(ex.Message);
        }
    }

    [Authorize(Roles = "Admin")]
    [Route("plan/cancel/{applicationUserId}")]
    [HttpPut]
    public async ValueTask<IActionResult> CancelSubscriptionAsync(string applicationUserId)
    {
        var modifiedBy = BaseIdentityClaims.GetUserNameFromClaims(User);
        return await HandleRequestAsync(() => _paymentRepository.CancelSubscriptionAsync(applicationUserId, modifiedBy)).ConfigureAwait(false);
    }

    [Authorize(Roles = "Admin")]
    [Route("plan/update/{applicationUserId}")]
    [HttpPut]
    public async ValueTask<IActionResult> UpdateSubscriptionAsync(string applicationUserId, [FromBody] UpdateSubscriptionRequest request)
    {
        request.ModifiedBy = BaseIdentityClaims.GetUserNameFromClaims(User);
        return await HandleRequestAsync(() => _paymentRepository.UpdateSubscriptionAsync(applicationUserId, request)).ConfigureAwait(false);
    }

    [Authorize(Roles = "Admin")]
    [Route("method/update/{applicationUserId}")]
    [HttpPut]
    public async ValueTask<IActionResult> UpdatePaymentMethodnAsync(string applicationUserId, [FromBody] UpdatePaymentMethodRequest request)
    {
        request.ModifiedBy = BaseIdentityClaims.GetUserNameFromClaims(User);
        return await HandleRequestAsync(() => _paymentRepository.UpdatePaymentMethodAsync(applicationUserId, request)).ConfigureAwait(false);
    }

    [Authorize(Roles = "Admin")]
    [HttpGet("invoice/{applicationUserId}")]
    public async ValueTask<IActionResult> GetAllInvoicesAsync(string applicationUserId, [FromQuery] StripePagination pagination ) =>
        await HandleRequestAsync(() => _paymentRepository.GetAllInvoicesAsync(applicationUserId, pagination)).ConfigureAwait(false);

    [HttpGet("plan")]
    public async ValueTask<IActionResult> GetAllPlansAsync() =>
        await HandleRequestAsync(() => _paymentRepository.GetAllPlansAsync()).ConfigureAwait(false);

    [Authorize(Roles = "Admin")]
    [HttpGet("plan/{applicationUserId}")]
    public async ValueTask<IActionResult> GetPlanAsync(string applicationUserId) =>
        await HandleRequestAsync(() => _paymentRepository.GetUserPlanByIdAsync(applicationUserId)).ConfigureAwait(false);

}
