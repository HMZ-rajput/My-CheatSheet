﻿using MarketPro.Analytics.DTOs;
using MarketPro.Analytics.Entities;
using MarketPro.Repositories;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace MarketPro.Controllers;

[Authorize]
[Route("api/analytics")]
[ApiController]
public class AnalyticsController : BaseController
{
    private readonly IAnalyticsRepository<Report> _analyticsRepository;

    public AnalyticsController(IAnalyticsRepository<Report> analyticsRepository)
    {
        _analyticsRepository = analyticsRepository ?? throw new ArgumentNullException(nameof(analyticsRepository));
    }

    [HttpGet("UserAccount/{userAccountId}")]
    public async ValueTask<IActionResult> GetAnalyticsAsync(string userAccountId, [FromQuery] AnalyticsFilters filters) =>
        await HandleRequestAsync(() => _analyticsRepository.GetAnalyticsAsync(userAccountId, filters));

    [Route("report/create/UserAccount/{userAccountId}")]
    [HttpPost]
    public async ValueTask<IActionResult> CreateReportAsync(string userAccountId, [FromForm] CreateReportDTO request)
    {
        request.ModifiedBy = BaseIdentityClaims.GetUserNameFromClaims(User);
        return await HandleRequestAsync(() => _analyticsRepository.CreateReportAsync(userAccountId, request));
    }

    [Route("report/update/UserAccount/{userAccountId}/{reportId}")]
    [HttpPut]
    public async ValueTask<IActionResult> UpdateReportByIdAsync(string userAccountId, Guid reportId, [FromForm] UpdateReportDTO request)
    {
        request.ModifiedBy = BaseIdentityClaims.GetUserNameFromClaims(User);
        return await HandleRequestAsync(() => _analyticsRepository.UpdateReportByIdAsync(userAccountId, reportId, request));
    }

    [HttpGet("report/UserAccount/{userAccountId}/{reportId}")]
    public async ValueTask<IActionResult> GetReportByIdAsync(string userAccountId, Guid reportId) =>
        await HandleRequestAsync(() => _analyticsRepository.GetReportByIdAsync(userAccountId, reportId));

    [HttpGet("report/UserAccount/{userAccountId}")]
    public async ValueTask<IActionResult> GetAllReportsByIdAsync(string userAccountId) =>
        await HandleRequestAsync(() => _analyticsRepository.GetAllReportsByIdAsync(userAccountId));

    [Route("report/delete/UserAccount/{userAccountId}/{reportId}")]
    [HttpDelete]
    public async ValueTask<IActionResult> DeleteReportByIdAsync(string userAccountId, Guid reportId)
    {
        var modifiedBy = BaseIdentityClaims.GetUserNameFromClaims(User);
        return await HandleRequestAsync(() => _analyticsRepository.DeleteReportByIdAsync(userAccountId, reportId, modifiedBy));
    }
}
