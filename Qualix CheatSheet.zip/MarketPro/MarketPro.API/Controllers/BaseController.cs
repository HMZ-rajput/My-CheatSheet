﻿using MarketPro.Application;
using MarketPro.Common.DTOs;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;

namespace MarketPro.Controllers;

public class BaseController : ControllerBase
{
    protected async ValueTask<IActionResult> HandleRequestAsync<T>(Func<ValueTask<T>> func) where T : BaseResponse, new()
    {
        var response = new T();
        try
        {
            response = await func().ConfigureAwait(false);
            return Ok(response);
        }
        catch (SqlException)
        {
            response.Errors.Add(AppEnvironment.GenericSQLDatabaseError);
            return BadRequest(response);
        }
        catch (DbUpdateException)
        {
            response.Errors.Add(AppEnvironment.GenericSQLDatabaseError);
            return BadRequest(response);
        }
        catch (InvalidOperationException)
        {
            response.Errors.Add(AppEnvironment.GenericSQLDatabaseError);
            return BadRequest(response);
        }
        catch (Exception ex)
        {
            response.Errors.Add(ex.Message);
            return BadRequest(response);
        }
    }

    protected IActionResult HandleRequest<T>(Func<T> func) where T : BaseResponse, new()
    {
        var response = new T();
        try
        {
            response = func();
            return Ok(response);
        }
        catch (SqlException)
        {
            response.Errors.Add(AppEnvironment.GenericSQLDatabaseError);
            return BadRequest(response);
        }
        catch (Exception ex)
        {
            response.Errors.Add(ex.Message);
            return BadRequest(response);
        }
    }
}