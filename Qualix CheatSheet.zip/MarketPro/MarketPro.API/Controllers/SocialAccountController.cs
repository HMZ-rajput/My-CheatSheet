﻿using MarketPro.Repositories;
using MarketPro.SocialAccounts.DTOs;
using MarketPro.SocialAccounts.Entities;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace MarketPro.Controllers;
[Route("api/socialAccount")]
[ApiController]
public class SocialAccountController : BaseController
{
    private readonly ISocialAccountRepository<SocialAccount> _socialAccountRepository;

    public SocialAccountController(ISocialAccountRepository<SocialAccount> socialAccountRepository)
    {
        _socialAccountRepository = socialAccountRepository ?? throw new ArgumentNullException(nameof(socialAccountRepository));
    }

    [Authorize(Roles = "Admin")]
    [Route("connect/userAccount/{userAccountId}")]
    [HttpPost]
    public async ValueTask<IActionResult> ConnectSocialAccountsAsync(string userAccountId, ConnectSocialAccountDTO request)
    {
        var modifiedBy = BaseIdentityClaims.GetUserNameFromClaims(User);
        return await HandleRequestAsync(() => _socialAccountRepository.ConnectSocialAccountAsync(userAccountId, request, modifiedBy));
    }

    [Authorize(Roles = "Admin")]
    [Route("disconnect/userAccount/{userAccountId}")]
    [HttpPost]
    public async ValueTask<IActionResult> DisconnectSocialAccountsAsync(string userAccountId, DisconnectSocialAccountDTO request)
    {
        var modifiedBy = BaseIdentityClaims.GetUserNameFromClaims(User);
        return await HandleRequestAsync(() => _socialAccountRepository.DisconnectSocialAccountAsync(userAccountId, request, modifiedBy));
    }

    [Authorize]
    [HttpGet("userAccount/{userAccountId}")]
    public async ValueTask<IActionResult> GetAllConnectedSocialAccounts(string userAccountId) =>
        await HandleRequestAsync(() => _socialAccountRepository.GetConnectedSocialAccountsByUserIdAsync(userAccountId));

    [Authorize]
    [HttpGet("list/userAccount/{userAccountId}")]
    public async ValueTask<IActionResult> GetSocialAccountsListAsync(string userAccountId) =>
    await HandleRequestAsync(() => _socialAccountRepository.GetSocialAccountsListByUserIdAsync(userAccountId));
}