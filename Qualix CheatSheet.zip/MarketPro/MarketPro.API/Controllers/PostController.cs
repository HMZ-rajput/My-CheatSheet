﻿using MarketPro.Posts.DTOs;
using MarketPro.Posts.Entities;
using MarketPro.Repositories;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace MarketPro.Controllers;

[Authorize]
[Route("api/post")]
[ApiController]
public class PostController : BaseController
{
    private readonly IPostRepository<Post> _postRepository;

    public PostController(IPostRepository<Post> postRepository)
    {
        _postRepository = postRepository ?? throw new ArgumentNullException(nameof(postRepository));
    }

    [Route("create/UserAccount/{userAccountId}")]
    [HttpPost]
    public async ValueTask<IActionResult> CreatePostAsync(string userAccountId, [FromForm] CreatePostDTO request)
    {
        request.ModifiedBy = BaseIdentityClaims.GetUserNameFromClaims(User);
        return await HandleRequestAsync(() => _postRepository.CreatePostsAsync(userAccountId, request));
    }

    [Route("delete/{postId}/UserAccount/{userAccountId}")]
    [HttpDelete]
    public async ValueTask<IActionResult> DeletePostAsync(Guid postId, string userAccountId)
    {
        var modifiedBy = BaseIdentityClaims.GetUserNameFromClaims(User);
        return await HandleRequestAsync(() => _postRepository.DeletePostByIdAsync(postId, userAccountId, modifiedBy));
    }

    [HttpGet("UserAccount/{userAccountId}")]
    public async ValueTask<IActionResult> GetPostsByUserIdAsync(string userAccountId, [FromQuery] PostFilters filters) =>
        await HandleRequestAsync(() => _postRepository.GetAllPostsByUserIdAsync(userAccountId, filters));

    [HttpGet("{postId}/UserAccount/{userAccountId}")]
    public async ValueTask<IActionResult> GetPostByIdAsync(Guid postId, string userAccountId) =>
        await HandleRequestAsync(() => _postRepository.GetPostByIdAsync(postId, userAccountId));

    [Route("update/{postId}/UserAccount/{userAccountId}")]
    [HttpPut]
    public async ValueTask<IActionResult> UpdatePostAsync(Guid postId, string userAccountId, [FromForm] UpdatePostDTO request)
    {
        request.ModifiedBy = BaseIdentityClaims.GetUserNameFromClaims(User);
        return await HandleRequestAsync(() => _postRepository.UpdatePostAsync(postId, userAccountId, request));
    }

    [Route("action/{postId}/UserAccount/{userAccountId}")]
    [HttpPost]
    public async ValueTask<IActionResult> PostActionAsync(string userAccountId, Guid postId, [FromBody] PostActionDTO request)
    {
        request.ModifiedBy = BaseIdentityClaims.GetUserNameFromClaims(User);
        return await HandleRequestAsync(() => _postRepository.PostActionAsync(postId, userAccountId, request));
    }
}
