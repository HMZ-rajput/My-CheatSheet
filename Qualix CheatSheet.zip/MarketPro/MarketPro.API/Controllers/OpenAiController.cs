﻿using MarketPro.OpenAi.DTOs;
using MarketPro.Payments.DTOs;
using MarketPro.Repositories;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace MarketPro.Controllers;

[Authorize]
[Route("api/openAi")]
[ApiController]
public class OpenAiController : BaseController
{
    private readonly IOpenAiRepository _openAiRepository;

    public OpenAiController(IOpenAiRepository openAiRepository)
    {
        _openAiRepository = openAiRepository ?? throw new ArgumentNullException(nameof(openAiRepository));
    }

    [HttpPost("idea")]
    public async ValueTask<IActionResult> GenerateIdeaAsync([FromBody] GenerateIdeaDTO request) =>
        await HandleRequestAsync(() => _openAiRepository.GenerateIdeaAsync(request)).ConfigureAwait(false);
}
