﻿using MarketPro.Identity.DTOs;
using MarketPro.IRepositories;
using MarketPro.UserAccounts.Entities;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace MarketPro.Controllers;

[Route("api/auth")]
[ApiController]
public class AuthController : BaseController
{
    private readonly IAuthRepository _authRepository;

    public AuthController(IAuthRepository authRepository)
    {
        _authRepository = authRepository ?? throw new ArgumentNullException(nameof(authRepository));
    }

    [Route("login")]
    [HttpPost]
    public async ValueTask<IActionResult> LoginAsync([FromBody] LoginRequest request) =>
    await HandleRequestAsync(() => _authRepository.LoginAsync(request))
        .ConfigureAwait(false);

    [Route("signUp")]
    [HttpPost]
    public async ValueTask<IActionResult> SignUpAsync([FromBody] SignUpRequest request)
    {
        var modifiedBy = BaseIdentityClaims.GetUserNameFromClaims(User);
        return await HandleRequestAsync(() => _authRepository.SignUpAsync(request, modifiedBy)).ConfigureAwait(false);
    }

    [Authorize]
    [Route("changePassword")]
    [HttpPost]
    public async ValueTask<IActionResult> ChangePasswordAsync(ChangePasswordRequest request)
    {
        var modifiedBy = BaseIdentityClaims.GetUserNameFromClaims(User);
        return await HandleRequestAsync(() => _authRepository.ChangePasswordAsync(request, modifiedBy)).ConfigureAwait(false);
    }

    [Route("sendForgotPasswordEmail")]
    [HttpPost]
    public async ValueTask<IActionResult> SendForgotPasswordEmailAsync([FromBody] SendForgotPasswordEmailRequest request) =>
        await HandleRequestAsync(() => _authRepository.SendForgotPasswordEmailAsync(request))
        .ConfigureAwait(false);

    [Route("verifyOTP")]
    [HttpPost]
    public async ValueTask<IActionResult> VerifyPasswordOTPAsync([FromBody] VerifyPasswordOTPRequest request) =>
            await HandleRequestAsync(() => _authRepository.VerifyPasswordOTPAsync(request))
        .ConfigureAwait(false);

    [Route("resetPassword")]
    [HttpPost]
    public async ValueTask<IActionResult> ResetPasswordAsync([FromBody] ResetPasswordRequest request) =>
    await HandleRequestAsync(() => _authRepository.ResetPasswordAsync(request))
        .ConfigureAwait(false);

    [Authorize]
    [Route("update/accountSetting/{applicationUserId}")]
    [HttpPut]
    public async ValueTask<IActionResult> UpdatePersonalInfoAsync(string applicationUserId, [FromForm] UpdatePersonalInfoRequest request)
    {
        request.ModifiedBy = BaseIdentityClaims.GetUserNameFromClaims(User);
        return await HandleRequestAsync(() => _authRepository.UpdatePersonalInfoAsync(applicationUserId, request)).ConfigureAwait(false);
    }

}
