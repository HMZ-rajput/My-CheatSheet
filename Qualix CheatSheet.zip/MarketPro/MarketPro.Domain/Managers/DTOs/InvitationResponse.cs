﻿using MarketPro.Common.DTOs;

namespace MarketPro.Managers.DTOs;

public class InvitationResponse : BaseResponse
{
    public GetManagerDTO? Manager { get; set; }
}

