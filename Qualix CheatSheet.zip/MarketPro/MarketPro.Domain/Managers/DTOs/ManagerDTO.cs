﻿using MarketPro.Identity.DTOs;
using MarketPro.Managers.Entities;
using MarketPro.SocialAccounts.DTOs;

namespace MarketPro.Managers.DTOs;

public class ManagerDTO
{
    public string Id { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string? Email { get; set; }
    public AuthDTO? Admin { get; set; }
    public IList<SocialAccountInfoDTO> SocialAccounts { get; set; } = [];
}

public class GetManagerDTO : ManagerDTO
{
    public Guid? InvitationId { get; set; }
    public InviteStatus? Status { get; set; }
}

public class DeleteManagerDTO
{
    public InviteStatus Status { get; set; }
    public string? ModifiedBy { get; set; }
}

public class UpdateManagerRequest
{
    public IList<Guid> SocialAccountIds { get; set; } = [];
    public string? ModifiedBy { get; set; }
}

