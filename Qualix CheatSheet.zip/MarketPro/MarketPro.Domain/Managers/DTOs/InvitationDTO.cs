﻿using MarketPro.Identity.DTOs;
using MarketPro.Managers.Entities;
using MarketPro.SocialAccounts.DTOs;
using System.ComponentModel.DataAnnotations;

namespace MarketPro.Managers.DTOs;

public class InvitationDTO
{
    [Required]
    public required string Name { get; set; }

    [Required]
    [RegularExpression("\\w+([-+.']\\w+)*@\\w+([-.]\\w+)*\\.\\w+([-.]\\w+)*", ErrorMessage = "Invalid Email Address")]
    [EmailAddress]
    public required string Email { get; set; }
    public string? ModifiedBy { get; set; }
}

public class CreateInvitationDTO : InvitationDTO
{
    public IList<Guid> SocialAccountIds { get; set; } = [];
}

public class GetInvitationDTO : InvitationDTO
{
    public Guid id { get; set; }
    public InviteStatus Status { get; set; }
    public GetAuthDTO? ApplicationUser { get; set; }
    public IList<SocialAccountInfoDTO> SocialAccounts { get; set; } = [];
    public DateTimeOffset? ModifiedDate { get; set; }
    public string? CreatedBy { get; set; }
    public DateTimeOffset? CreatedDate { get; set; }
    public string? LastModifiedBy => ModifiedBy ?? CreatedBy;
    public DateTimeOffset? LastModifiedDate => ModifiedDate ?? CreatedDate;
}

public class UpdateInvitationDTO
{
    public bool IsAccept { get; set; }
}

