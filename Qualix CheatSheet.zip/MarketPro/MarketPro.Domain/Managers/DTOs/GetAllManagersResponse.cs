﻿using MarketPro.Common.DTOs;

namespace MarketPro.Managers.DTOs;

public class GetAllManagersResponse : BaseResponse
{
    public IList<GetManagerDTO> Managers { get; set; } = [];
}

public class GetManagerResponse : BaseResponse
{
    public GetManagerDTO? Manager { get; set; }
}

