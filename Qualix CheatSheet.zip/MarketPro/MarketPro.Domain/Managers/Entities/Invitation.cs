﻿using MarketPro.Common.Entities;
using MarketPro.Identity.Entities;
using MarketPro.SocialAccounts.Entities;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MarketPro.Managers.Entities;

public class Invitation : ModifiableDomainEntity
{
    [Required]
    public required string Name { get; set; }

    [Required]
    [RegularExpression("\\w+([-+.']\\w+)*@\\w+([-.]\\w+)*\\.\\w+([-.]\\w+)*", ErrorMessage = "Invalid Email Address")]
    public required string Email { get; set; }

    public InviteStatus Status { get; set; }

    [ForeignKey(nameof(ApplicationUser))]
    public string? ApplicationUserId { get; set; }
    public virtual ApplicationUser? ApplicationUser { get; set; }

    public ICollection<SocialAccount> SocialAccounts { get; } = [];
    public ICollection<Invitation> Invitations { get; } = [];
}

public enum InviteStatus
{
    Pending = 0,
    Accepted = 1,
    Rejected = 2,
}

