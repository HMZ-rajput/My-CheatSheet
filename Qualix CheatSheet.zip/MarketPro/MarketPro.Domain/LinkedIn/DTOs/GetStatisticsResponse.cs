﻿using MarketPro.Common.DTOs;

namespace MarketPro.LinkedIn.DTOs;

public class GetStatisticsResponse : BaseResponse
{
    public StatisticsResponse? Statistic { get; set; }
}


public class StatisticsResponse
{
    public TotalStatisticsResponse TotalImpression { get; set; } = new();
    public TotalStatisticsResponse TotalEngagement { get; set; } = new();
    public TotalStatisticsResponse TotalAudience { get; set; } = new();
}

public class TotalStatisticsResponse
{
    public int Total { get; set; }
    public List<int> XAxis { get; set; } = [];
    public List<DateTime> YAxis { get; set; } = [];
}

