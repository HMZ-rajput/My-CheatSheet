﻿using MarketPro.Common.DTOs;
using Newtonsoft.Json;

namespace MarketPro.LinkedIn.DTOs;

public class RegisterUploadResponse : BaseResponse
{
    [JsonProperty("value")]
    public MediaValue? Value { get; set; }
}

public class MediaValue
{
    [JsonProperty("mediaArtifact")]
    public string? MediaArtifact { get; set; }

    [JsonProperty("uploadMechanism")]
    public UploadMechanism? UploadMechanism { get; set; }

    [JsonProperty("asset")]
    public string? Asset { get; set; }

    [JsonProperty("assetRealTimeTopic")]
    public string? AssetRealTimeTopic { get; set; }
}

public class UploadMechanism
{
    [JsonProperty("com.linkedin.digitalmedia.uploading.MediaUploadHttpRequest")]
    public MediaUploadHttpRequest? MediaUploadHttpRequest { get; set; }
}

public class MediaUploadHttpRequest
{
    [JsonProperty("uploadUrl")]
    public string? UploadUrl { get; set; }

    [JsonProperty("headers")]
    public MediaHeaders? Headers { get; set; }
}

public class MediaHeaders
{
    [JsonProperty("media-type-family")]
    public string? MediaTypeFamily { get; set; }
}