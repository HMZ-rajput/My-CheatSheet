﻿using MarketPro.Common.DTOs;
using Newtonsoft.Json;

namespace MarketPro.LinkedIn.DTOs;

public class OrganizationPageStatisticsResponse : BaseResponse
{
    public OrganizationPageStatistics? OrganizationPageStatistics { get; set; }
}

public class OrganizationPageStatistics
{
    [JsonProperty("paging")]
    public OrganizationPageStatisticsPaging? Paging { get; set; }

    [JsonProperty("elements")]
    public IList<OrganizationPageStatisticsElement> Elements { get; set; } = [];
}

public class OrganizationPageStatisticsPaging
{
    [JsonProperty("start")]
    public int Start { get; set; }

    [JsonProperty("count")]
    public int Count { get; set; }

    [JsonProperty("links")]
    public IList<object> Links { get; set; } = [];
}

public class OrganizationPageStatisticsElement
{
    [JsonProperty("totalPageStatistics")]
    public OrganizationPageStatisticsTotalPageStatistics? TotalPageStatistics { get; set; }

    [JsonProperty("timeRange")]
    public OrganizationPageStatisticsTimeRange? TimeRange { get; set; }

    [JsonProperty("organization")]
    public string? Organization { get; set; }
}

public class OrganizationPageStatisticsTotalPageStatistics
{
    [JsonProperty("clicks")]
    public OrganizationPageStatisticsClicks? Clicks { get; set; }

    [JsonProperty("views")]
    public OrganizationPageStatisticsViews? Views { get; set; }
}

public class OrganizationPageStatisticsClicks
{
    [JsonProperty("mobileCustomButtonClickCounts")]
    public IList<OrganizationPageStatisticsCustomButtonClickCount> MobileCustomButtonClickCounts { get; set; } = [];

    [JsonProperty("careersPageClicks")]
    public OrganizationPageStatisticsCareersPageClicks? CareersPageClicks { get; set; }

    [JsonProperty("mobileCareersPageClicks")]
    public OrganizationPageStatisticsMobileCareersPageClicks? MobileCareersPageClicks { get; set; }

    [JsonProperty("desktopCustomButtonClickCounts")]
    public IList<OrganizationPageStatisticsCustomButtonClickCount> DesktopCustomButtonClickCounts { get; set; } = [];
}

public class OrganizationPageStatisticsCustomButtonClickCount
{
    [JsonProperty("customButtonType")]
    public string? CustomButtonType { get; set; }

    [JsonProperty("clicks")]
    public int Clicks { get; set; }
}

public class OrganizationPageStatisticsCareersPageClicks
{
    [JsonProperty("careersPagePromoLinksClicks")]
    public int CareersPagePromoLinksClicks { get; set; }

    [JsonProperty("careersPageBannerPromoClicks")]
    public int CareersPageBannerPromoClicks { get; set; }

    [JsonProperty("careersPageJobsClicks")]
    public int CareersPageJobsClicks { get; set; }

    [JsonProperty("careersPageEmployeesClicks")]
    public int CareersPageEmployeesClicks { get; set; }
}

public class OrganizationPageStatisticsMobileCareersPageClicks
{
    [JsonProperty("careersPageJobsClicks")]
    public int CareersPageJobsClicks { get; set; }

    [JsonProperty("careersPagePromoLinksClicks")]
    public int CareersPagePromoLinksClicks { get; set; }

    [JsonProperty("careersPageEmployeesClicks")]
    public int CareersPageEmployeesClicks { get; set; }
}

public class OrganizationPageStatisticsViews
{
    [JsonProperty("mobileProductsPageViews")]
    public OrganizationPageStatisticsPageViews? MobileProductsPageViews { get; set; }

    [JsonProperty("allDesktopPageViews")]
    public OrganizationPageStatisticsUniquePageViews? AllDesktopPageViews { get; set; }

    [JsonProperty("insightsPageViews")]
    public OrganizationPageStatisticsPageViews? InsightsPageViews { get; set; }

    [JsonProperty("mobileAboutPageViews")]
    public OrganizationPageStatisticsPageViews? MobileAboutPageViews { get; set; }

    [JsonProperty("allMobilePageViews")]
    public OrganizationPageStatisticsUniquePageViews? AllMobilePageViews { get; set; }

    [JsonProperty("jobsPageViews")]
    public OrganizationPageStatisticsPageViews? JobsPageViews { get; set; }

    [JsonProperty("productsPageViews")]
    public OrganizationPageStatisticsPageViews? ProductsPageViews { get; set; }

    [JsonProperty("desktopProductsPageViews")]
    public OrganizationPageStatisticsPageViews? DesktopProductsPageViews { get; set; }

    [JsonProperty("peoplePageViews")]
    public OrganizationPageStatisticsPageViews? PeoplePageViews { get; set; }

    [JsonProperty("overviewPageViews")]
    public OrganizationPageStatisticsPageViews? OverviewPageViews { get; set; }

    [JsonProperty("mobileOverviewPageViews")]
    public OrganizationPageStatisticsPageViews? MobileOverviewPageViews { get; set; }

    [JsonProperty("lifeAtPageViews")]
    public OrganizationPageStatisticsPageViews? LifeAtPageViews { get; set; }

    [JsonProperty("desktopOverviewPageViews")]
    public OrganizationPageStatisticsPageViews? DesktopOverviewPageViews { get; set; }

    [JsonProperty("mobileCareersPageViews")]
    public OrganizationPageStatisticsPageViews? MobileCareersPageViews { get; set; }

    [JsonProperty("allPageViews")]
    public OrganizationPageStatisticsUniquePageViews? AllPageViews { get; set; }

    [JsonProperty("mobileJobsPageViews")]
    public OrganizationPageStatisticsPageViews? MobileJobsPageViews { get; set; }

    [JsonProperty("careersPageViews")]
    public OrganizationPageStatisticsPageViews? CareersPageViews { get; set; }

    [JsonProperty("mobileLifeAtPageViews")]
    public OrganizationPageStatisticsPageViews? MobileLifeAtPageViews { get; set; }

    [JsonProperty("desktopJobsPageViews")]
    public OrganizationPageStatisticsPageViews? DesktopJobsPageViews { get; set; }

    [JsonProperty("desktopPeoplePageViews")]
    public OrganizationPageStatisticsPageViews? DesktopPeoplePageViews { get; set; }

    [JsonProperty("aboutPageViews")]
    public OrganizationPageStatisticsPageViews? AboutPageViews { get; set; }

    [JsonProperty("desktopAboutPageViews")]
    public OrganizationPageStatisticsPageViews? DesktopAboutPageViews { get; set; }

    [JsonProperty("mobilePeoplePageViews")]
    public OrganizationPageStatisticsPageViews? MobilePeoplePageViews { get; set; }

    [JsonProperty("desktopInsightsPageViews")]
    public OrganizationPageStatisticsPageViews? DesktopInsightsPageViews { get; set; }

    [JsonProperty("desktopCareersPageViews")]
    public OrganizationPageStatisticsPageViews? DesktopCareersPageViews { get; set; }

    [JsonProperty("desktopLifeAtPageViews")]
    public OrganizationPageStatisticsPageViews? DesktopLifeAtPageViews { get; set; }

    [JsonProperty("mobileInsightsPageViews")]
    public OrganizationPageStatisticsPageViews? MobileInsightsPageViews { get; set; }
}

public class OrganizationPageStatisticsPageViews
{
    [JsonProperty("pageViews")]
    public int PageViews { get; set; }
}

public class OrganizationPageStatisticsUniquePageViews : OrganizationPageStatisticsPageViews
{
    [JsonProperty("uniquePageViews")]
    public int UniquePageViews { get; set; }
}

public class OrganizationPageStatisticsTimeRange
{
    [JsonProperty("start")]
    public long Start { get; set; }

    [JsonProperty("end")]
    public long End { get; set; }
}