﻿using MarketPro.Common.DTOs;
using Newtonsoft.Json;

namespace MarketPro.LinkedIn.DTOs;

public class PageDetailsResponse : BaseResponse
{
    [JsonProperty("elements")]
    public IList<OrganizationDetail> OrganizationDetails { get; set; } = [];
}

public class OrganizationDetail
{
    [JsonProperty("organization~")]
    public Organization? Organization { get; set; }

    [JsonProperty("role")]
    public string? Role { get; set; }

    [JsonProperty("organization")]
    public string? OrganizationUrn { get; set; }

    [JsonProperty("roleAssignee")]
    public string? RoleAssignee { get; set; }

    [JsonProperty("state")]
    public string? State { get; set; }
}

public class Organization
{
    [JsonProperty("localizedName")]
    public string? LocalizedName { get; set; }

    [JsonProperty("id")]
    public string? Id { get; set; }
}
