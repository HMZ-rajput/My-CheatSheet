﻿using MarketPro.Common.DTOs;
using Newtonsoft.Json;

namespace MarketPro.LinkedIn.DTOs;

public class OrganizationalEntityFollowerStatisticsResponse : BaseResponse
{
    public OrganizationalEntityFollowerStatistics? OrganizationalEntityFollowerStatistics { get; set; }
}

public class OrganizationalEntityFollowerStatistics
{
    [JsonProperty("paging")]
    public OrganizationalEntityFollowerStatisticsPaging? Paging { get; set; }

    [JsonProperty("elements")]
    public IList<OrganizationalEntityFollowerStatisticsElement> Elements { get; set; } = [];
}

public class OrganizationalEntityFollowerStatisticsPaging
{
    [JsonProperty("start")]
    public int Start { get; set; }

    [JsonProperty("count")]
    public int Count { get; set; }

    [JsonProperty("links")]
    public IList<object> Links { get; set; } = [];
}

public class OrganizationalEntityFollowerStatisticsElement
{
    [JsonProperty("followerGains")]
    public OrganizationalEntityFollowerStatisticsFollowerGains? FollowerGains { get; set; }

    [JsonProperty("organizationalEntity")]
    public string? OrganizationalEntity { get; set; }

    [JsonProperty("timeRange")]
    public OrganizationalEntityFollowerStatisticsTimeRange? TimeRange { get; set; }
}

public class OrganizationalEntityFollowerStatisticsFollowerGains
{
    [JsonProperty("organicFollowerGain")]
    public int OrganicFollowerGain { get; set; }

    [JsonProperty("paidFollowerGain")]
    public int PaidFollowerGain { get; set; }
}

public class OrganizationalEntityFollowerStatisticsTimeRange
{
    [JsonProperty("start")]
    public long Start { get; set; }

    [JsonProperty("end")]
    public long End { get; set; }
}