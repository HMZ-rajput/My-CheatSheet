﻿using MarketPro.Common.DTOs;

namespace MarketPro.LinkedIn.DTOs;

public class GetUserProfileResponse : BaseResponse
{
    public UserProfileResponse? UserProfile { get; set; }
}

public class UserProfileResponse
{
    public string? SocialAccountId { get; set; }
    public string? FirstName { get; set; }
    public string? LastName { get; set; }
    public string? VanityName { get; set; }
    public string? Headline { get; set; }
    public string? ProfilePicture { get; set; }
}