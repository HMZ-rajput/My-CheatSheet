﻿using System.ComponentModel.DataAnnotations;

namespace MarketPro.OpenAi.DTOs;

public class GenerativeContentDTO
{
    [Required]
    public required string Prompt { get; set; }
}

public class GenerateIdeaDTO
{
    public string? Prompt { get; set; }
    public string? BusinessDescription { get; set; }
    public string? TargetAudience { get; set; }
    public string? Keywords { get; set; }
    public string? Tone { get; set; }
    public string? Purpose { get; set; }
    public bool IsIdea { get; set; }
    public bool IsImageRequired { get; set; } = true;
}

public class GetGeneratedIdeaDTO
{
    public string? Content { get; set; }
    public IList<string?>? Urls { get; set; } = [];
}

