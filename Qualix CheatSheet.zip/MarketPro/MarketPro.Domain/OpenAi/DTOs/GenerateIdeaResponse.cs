﻿using MarketPro.Common.DTOs;

namespace MarketPro.OpenAi.DTOs;

public class GenerateIdeaResponse : BaseResponse
{
    public IList<GetGeneratedIdeaDTO> Ideas { get; set; } = [];
}

