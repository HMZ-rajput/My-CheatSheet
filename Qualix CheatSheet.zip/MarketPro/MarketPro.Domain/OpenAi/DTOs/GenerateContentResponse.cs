﻿using MarketPro.Common.DTOs;

namespace MarketPro.OpenAi.DTOs;

public class GenerateContentResponse : BaseResponse
{
    public string? Content { get; set; }
}