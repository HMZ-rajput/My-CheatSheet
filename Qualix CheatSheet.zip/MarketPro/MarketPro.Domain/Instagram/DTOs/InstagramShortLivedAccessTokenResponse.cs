﻿using MarketPro.Common.DTOs;
using Newtonsoft.Json;

namespace MarketPro.Instagram.DTOs;

public class InstagramShortLivedAccessTokenResponse : BaseResponse
{
    [JsonProperty("access_token")]
    public string? Accesstoken { get; set; }

    [JsonProperty("user_id")]
    public string? UserId { get; set; }

    [JsonProperty("permissions")]
    public IList<string> Permissions { get; set; } = [];
}