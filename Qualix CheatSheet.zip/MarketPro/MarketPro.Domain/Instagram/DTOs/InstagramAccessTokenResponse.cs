﻿using MarketPro.Common.DTOs;
using Newtonsoft.Json;

namespace MarketPro.Instagram.DTOs;

public class InstagramAccessTokenResponse : BaseResponse
{
    public InstagramAccessToken? InstagramAccessToken { get; set; }
}

public class InstagramAccessToken
{
    [JsonProperty("access_token")]
    public string? AccessToken { get; set; }

    [JsonProperty("token_type")]
    public string? TokenType { get; set; }

    [JsonProperty("expires_in")]
    public int ExpiresIn { get; set; }

    [JsonProperty("user_id")]
    public string? UserId { get; set; }

    [JsonProperty("permissions")]
    public IList<string> Permissions { get; set; } = [];
}