﻿using MarketPro.Common.DTOs;
using Newtonsoft.Json;

namespace MarketPro.Instagram.DTOs;

public class InstagramLongLivedAccessTokenResponse : BaseResponse
{
    [JsonProperty("access_token")]
    public string? Accesstoken { get; set; }

    [JsonProperty("token_type")]
    public string? TokenType { get; set; }

    [JsonProperty("expires_in")]
    public int ExpiresIn { get; set; }
}