﻿using MarketPro.Common.DTOs;

namespace MarketPro.SocialAccounts.DTOs;

public class DisconnectSocialAccountResponse : BaseResponse
{
    public GetSocialAccount? SocialAccount { get; set; }
}