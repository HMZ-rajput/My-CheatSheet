﻿using MarketPro.SocialAccounts.Entities;
using System.ComponentModel.DataAnnotations;

namespace MarketPro.SocialAccounts.DTOs;

public class SocialAccountDTO
{
    public string? AuthToken { get; set; }
    public SocialAccountType Type { get; set; }
}

public class SocialAccountWithIdDTO : SocialAccountDTO
{
    public Guid? Id { get; set; }
}

public class ConnectSocialAccountDTO
{
    [Required]
    public required string AuthorizationCode { get; set; }

    [Required]
    public required SocialAccountType Type { get; set; }
    public bool IsConnect { get; set; }
}

public class DisconnectSocialAccountDTO
{
    public required Guid SocialAccountId { get; set; }
}

public class GetSocialAccountDTO : SocialAccountWithIdDTO
{
    public string? SocialAccountId { get; set; }
    public string? FirstName { get; set; }
    public string? LastName { get; set; }
    public string? FullName => (FirstName is not null || LastName is not null) ? $"{FirstName} {LastName}" : null;
    public string? VanityName { get; set; }
    public string? Headline { get; set; }
    public string? ProfilePicture { get; set; }
    public string? PageId { get; set; }
    public string? PageName { get; set; }
    public string? ModifiedBy { get; set; }
    public DateTimeOffset? ModifiedDate { get; set; }
    public string? CreatedBy { get; set; }
    public DateTimeOffset? CreatedDate { get; set; }
    public string? LastModifiedBy => ModifiedBy ?? CreatedBy;
    public DateTimeOffset? LastModifiedDate => ModifiedDate ?? CreatedDate;
}

public class SocialAccountInfoDTO
{
    public Guid? Id { get; set; }
    public SocialAccountType Type { get; set; }
    public string? FirstName { get; set; }
    public string? LastName { get; set; }
    public string? FullName => (FirstName is not null || LastName is not null) ? $"{FirstName} {LastName}" : null;
    public string? ProfilePicture { get; set; }
    public string? PageId { get; set; }
    public string? PageName { get; set; }
}

public class GetPageDTO
{
    public string? Id { get; set; }
    public string? Name { get; set; }
}