﻿using MarketPro.Common.DTOs;

namespace MarketPro.SocialAccounts.DTOs;

public class GetSocialAccountResponse : BaseResponse
{
    public IList<GetSocialAccount> SocialAccounts { get; set; } = [];
}

public class GetSocialAccount : GetSocialAccountDTO
{
    private readonly List<string> errors = [];

    public List<string> Errors
    {
        get { return errors; }
    }

    public bool IsSuccess => errors.Count == 0;

    public void AddError(string error)
    {
        errors.Add(error);
    }
}