﻿using MarketPro.Common.DTOs;

namespace MarketPro.SocialAccounts.DTOs;

public class HttpResponse : BaseResponse
{
    public HttpResponseMessage? HttpResponseMessage { get; set; }

}