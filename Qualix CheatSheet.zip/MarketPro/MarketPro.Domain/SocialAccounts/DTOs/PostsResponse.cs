﻿using MarketPro.Common.DTOs;
using MarketPro.Posts.DTOs;

namespace MarketPro.SocialAccounts.DTOs;

public class PostsResponse : BaseResponse
{
    public IList<GetPostDTO> Posts { get; set; } = [];
}