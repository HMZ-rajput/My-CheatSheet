﻿using MarketPro.Common.DTOs;

namespace MarketPro.SocialAccounts.DTOs;

public class ConnectSocialAccountResponse : BaseResponse
{
    public IList<GetSocialAccount>? SocialAccounts { get; set; }
}