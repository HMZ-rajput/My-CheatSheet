﻿using MarketPro.Common.DTOs;

namespace MarketPro.SocialAccounts.DTOs;

public class PublishResponse : BaseResponse
{
}

