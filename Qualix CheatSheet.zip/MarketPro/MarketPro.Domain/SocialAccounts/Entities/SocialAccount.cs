﻿using MarketPro.Common.Entities;
using MarketPro.Identity.Entities;
using MarketPro.Managers.Entities;
using MarketPro.Posts.Entities;
using System.ComponentModel.DataAnnotations.Schema;

namespace MarketPro.SocialAccounts.Entities;

public class SocialAccount : ModifiableDomainEntity
{
    public string? AuthToken { get; set; }
    public string? SocialAccountId { get; set; }
    public string? FirstName { get; set; }
    public string? LastName { get; set; }
    public string? VanityName { get; set; }
    public string? Headline { get; set; }
    public string? ProfilePicture { get; set; }
    public SocialAccountType Type { get; set; }

    [ForeignKey(nameof(ApplicationUser))]
    public string? ApplicationUserId { get; set; }
    public ApplicationUser? ApplicationUser { get; set; }

    public ICollection<ApplicationUser> Managers { get; } = [];
    public ICollection<Post> Posts { get; set; } = [];
    public ICollection<Invitation> Invitations { get; set; } = [];
}

public enum SocialAccountType
{
    LinkedIn = 0,
    Instagram = 1,
    Facebook = 2
}