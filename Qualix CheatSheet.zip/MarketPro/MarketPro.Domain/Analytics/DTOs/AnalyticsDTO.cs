﻿using MarketPro.Posts.DTOs;
using MarketPro.SocialAccounts.DTOs;

namespace MarketPro.Analytics.DTOs;

public class AnalyticsDTO : AllAnalyticsDTO
{
    //public AnalyticsGraph? TotalAudiance {  get; set; }
    //public AnalyticsGraph? TotalImpressions { get; set; }
    //public AnalyticsGraph? TotalEngagment { get; set; }
    public IList<GetPostDTO> RecentlyPublished { get; set; } = [];
    public IList<GetPostDTO> RecentDrafts { get; set; } = [];
    public IList<GetPostDTO> UpcomingPosts { get; set; } = [];
    //public IList<SocialAccountAnalyticsDTO> SocialAccountAnalytics { get; set; } = [];
}

public class AnalyticsGraph
{
    public IList<string> XAxis { get; set; } = [];
    public IList<int> YAxis { get; set; } = [];
    public string Total { get; set; } = string.Empty;
    public string Percentage {  get; set; } = string.Empty;
    public bool IsNegative { get; set; } = false;
}

//public class GraphNode
//{
//    public int YAxis { get; set; }
//    public DateTimeOffset XAxis { get; set; }
//}

public class SocialAccountAnalyticsDTO : SocialAccountInfoDTO
{
    public int Followers { get; set; }
    public int Impressions { get; set; }
    public int EngagmentRate { get; set; }
}

public class AllAnalyticsDTO
{
    public IList<SocialAccountAnalyticsDTO> SocialAccountAnalytics { get; set; } = [];
    public AnalyticsGraph? TotalAudianceGraph { get; set; }
    public AnalyticsGraph? TotalImpressionsGraph { get; set; }
    public AnalyticsGraph? TotalEngagmentGraph { get; set; }
}

