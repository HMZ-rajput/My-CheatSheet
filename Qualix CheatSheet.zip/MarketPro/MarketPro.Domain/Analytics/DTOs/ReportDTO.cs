﻿using MarketPro.Documents.DTOs;
using Microsoft.AspNetCore.Http;
using System.ComponentModel.DataAnnotations;

namespace MarketPro.Analytics.DTOs;

public class ReportDTO
{
    [Required]
    public required string Name { get; set; }
    public string? ModifiedBy { get; set; }
}

public class CreateReportDTO : ReportDTO
{
    public IFormFile? Image { get; set; }
}

public class UpdateReportDTO
{
    public required IFormFile Image { get; set; }
    public string? ModifiedBy { get; set; }
}

public class GetReportDTO : ReportDTO
{
    public Guid Id { get; set; }
    public IList<DocumentDTO> Images { get; set; } = [];
    public DateTimeOffset? ModifiedDate { get; set; }
    public string? CreatedBy { get; set; }
    public DateTimeOffset? CreatedDate { get; set; }
    public string? LastModifiedBy => ModifiedBy ?? CreatedBy;
    public DateTimeOffset? LastModifiedDate => ModifiedDate ?? CreatedDate;
}

