﻿using MarketPro.Common.DTOs;

namespace MarketPro.Analytics.DTOs;

public class GetReportResponse : BaseResponse
{
    public GetReportDTO? Report {  get; set; }
}

public class GetAllReportResponse : BaseResponse
{
    public IList<GetReportDTO> Reports { get; set; } = [];
}

