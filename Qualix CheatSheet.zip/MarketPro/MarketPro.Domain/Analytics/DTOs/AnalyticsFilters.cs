﻿using MarketPro.Common.DTOs;

namespace MarketPro.Analytics.DTOs;

public class AnalyticsFilters
{
    public string? socialAccountTypes {  get; set; }
    public string? socialAccountIds { get; set; }
}

