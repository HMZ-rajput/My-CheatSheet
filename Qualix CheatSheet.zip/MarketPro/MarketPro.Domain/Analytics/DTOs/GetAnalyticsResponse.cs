﻿using MarketPro.Common.DTOs;

namespace MarketPro.Analytics.DTOs;

public class GetAnalyticsResponse : BaseResponse
{
    public AnalyticsDTO? Analytics {  get; set; }
}

