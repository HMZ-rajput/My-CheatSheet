﻿using MarketPro.Common.Entities;
using MarketPro.Documents.Entities;
using MarketPro.Identity.Entities;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MarketPro.Analytics.Entities;

public class Report : ModifiableDomainEntity
{
    [Required]
    public required string Name { get; set; }

    [ForeignKey(nameof(ApplicationUser))]
    public required string ApplicationUserId { get; set; }
    public virtual ApplicationUser? ApplicationUser { get; set; }

    public ICollection<Document> Images { get; } = [];
}

