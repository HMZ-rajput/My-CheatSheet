﻿using MarketPro.Common.DTOs;
using MarketPro.Documents.DTOs;
using MarketPro.UserAccounts.DTOs;

namespace MarketPro.Identity.DTOs;

public class AuthDTO : BaseResponseModificationInfo
{
    public string UserId { get; set; } = string.Empty;
    public string FirstName { get; set; } = string.Empty;
    public string LastName { get; set; } = string.Empty;
    public string UserName { get; set; } = string.Empty;
    public string UserRole { get; set; } = string.Empty;
    public string BearerToken { get; set; } = string.Empty;
    public bool IsActive { get; set; } = true;
    public bool IsAdmin => UserRole == "Admin" ? true : false;
    public bool IsAuthenticated { get; set; }
    public string? Message { get; set; }
    public bool IsSubscriptionExpired { get; set; }
    public UserAccountDTO? UserDetials { get; set; }
    public DocumentDTO? ProfileImage { get; set; }
}

public class GetAuthDTO
{
    public string UserId { get; set; } = string.Empty;
    public string FirstName { get; set; } = string.Empty;
    public string LastName { get; set; } = string.Empty;
}