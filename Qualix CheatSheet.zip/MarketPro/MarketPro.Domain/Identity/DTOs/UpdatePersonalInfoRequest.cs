﻿using Microsoft.AspNetCore.Http;

namespace MarketPro.Identity.DTOs;

public class UpdatePersonalInfoRequest
{
    public required string FirstName { get; set; }
    public required string LastName { get; set; }

    public IFormFile? ProfileImage { get; set; }
    public bool DeleteProfileImage { get; set; }
    public string? ModifiedBy { get; set; }
}

