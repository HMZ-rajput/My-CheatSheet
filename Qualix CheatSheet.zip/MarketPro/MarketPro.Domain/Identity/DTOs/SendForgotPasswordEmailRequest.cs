﻿
using MarketPro.Common.DTOs;

namespace MarketPro.Identity.DTOs;

public class SendForgotPasswordEmailRequest
{
    public required string Email { get; set; }
}

public class SendForgotPasswordEmailResponse : BaseResponse
{
    public string Email { get; set; } = string.Empty;
}
