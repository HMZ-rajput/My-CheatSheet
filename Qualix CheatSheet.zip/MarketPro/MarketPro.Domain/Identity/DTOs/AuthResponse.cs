﻿using MarketPro.Common.DTOs;

namespace MarketPro.Identity.DTOs;

public class AuthResponse : BaseResponse
{
    public AuthDTO? User { get; set; }
}