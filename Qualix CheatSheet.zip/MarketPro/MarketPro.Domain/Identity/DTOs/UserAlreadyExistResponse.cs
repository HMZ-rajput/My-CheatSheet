﻿using MarketPro.Common.DTOs;

namespace MarketPro.Identity.DTOs;

public class UserAlreadyExistResponse : BaseResponse
{
    public bool IsAlreadyExist { get; set; }
}