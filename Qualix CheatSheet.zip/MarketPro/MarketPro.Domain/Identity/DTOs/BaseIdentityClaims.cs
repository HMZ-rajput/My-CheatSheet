﻿using System.Security.Claims;

namespace MarketPro.Controllers;

public static class BaseIdentityClaims
{
    public static string? GetUserNameFromClaims(ClaimsPrincipal user)
    {
        var claimsIdentity = (ClaimsIdentity)user.Identity!;
        return claimsIdentity.FindFirst(ClaimTypes.Name)?.Value;
    }
}