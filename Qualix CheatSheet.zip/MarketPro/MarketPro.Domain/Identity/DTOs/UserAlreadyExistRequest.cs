﻿using System.ComponentModel.DataAnnotations;

namespace MarketPro.Identity.DTOs;

public class UserAlreadyExistRequest
{
    [Required]
    [EmailAddress]
    public required string Email { get; set; }
}