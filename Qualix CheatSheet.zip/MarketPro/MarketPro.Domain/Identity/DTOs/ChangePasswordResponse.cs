﻿using MarketPro.Common.DTOs;

namespace MarketPro.Identity.DTOs;

public class ChangePasswordResponse : BaseResponse
{
}
