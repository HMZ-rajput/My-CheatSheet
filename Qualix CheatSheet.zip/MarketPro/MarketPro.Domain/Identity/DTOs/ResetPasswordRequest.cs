﻿using MarketPro.Common.DTOs;

namespace MarketPro.Identity.DTOs;

public class ResetPasswordRequest
{
    public required string Email { get; set; }
    public required string Password { get; set; }
    public required string ResetPasswordToken { get; set; }
}

public class ResetPasswordResponse : BaseResponse
{
}

