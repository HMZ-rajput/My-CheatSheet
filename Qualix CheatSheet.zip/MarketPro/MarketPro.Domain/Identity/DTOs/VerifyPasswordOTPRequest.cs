﻿using MarketPro.Common.DTOs;

namespace MarketPro.Identity.DTOs;

public class VerifyPasswordOTPRequest
{
    public required int OTP { get; set; }
    public required string Email { get; set; }
}

public class VerifyPasswordOTPResponse : BaseResponse
{
    public string ResetPasswordToken { get; set; } = string.Empty;
}
