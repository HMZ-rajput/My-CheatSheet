﻿using MarketPro.Analytics.Entities;
using MarketPro.Documents.Entities;
using MarketPro.Posts.Entities;
using MarketPro.SocialAccounts.Entities;
using MarketPro.UserAccounts.Entities;
using Microsoft.AspNetCore.Identity;

namespace MarketPro.Identity.Entities;

public class ApplicationUser : IdentityUser
{
    public string FirstName { get; set; } = "FirstName";
    public string LastName { get; set; } = "LastName";
    public bool IsActive { get; set; } = true;
    public int? PasswordOTP { get; set; }
    public DateTimeOffset OTPDate { get; set; }
    public DateTimeOffset? CreatedDate { get; set; }
    public string? CreatedBy { get; set; }
    public DateTimeOffset? ModifiedDate { get; set; }
    public string? ModifiedBy { get; set; }
    public UserRole Role { get; set; }
    public virtual UserAccount? UserAccount { get; set; }
    public virtual UserAccount? AdminAccount { get; set; }
    public ICollection<SocialAccount> SocialAccounts { get; } = [];
    public ICollection<SocialAccount> ManagerSocialAccounts { get; } = [];
    public ICollection<Post> Posts { get; } = [];
    public ICollection<Report> Reports { get; } = [];
    public virtual Document? ProfileImage {  get; set; }
}

public enum UserRole
{
    Admin = 0,
    Manager = 1
}