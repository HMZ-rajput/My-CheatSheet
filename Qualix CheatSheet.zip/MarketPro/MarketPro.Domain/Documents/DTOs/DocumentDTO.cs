﻿using MarketPro.Documents.Entities;

namespace MarketPro.Documents.DTOs;

public class DocumentDTO
{
    public Guid? Id { get; set; }
    public string? FileName { get; set; }
    public DocumentType DocumentType { get; set; }
    public string? URL { get; set; }
}