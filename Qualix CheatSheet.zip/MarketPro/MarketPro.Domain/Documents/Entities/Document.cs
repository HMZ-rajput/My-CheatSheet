﻿using MarketPro.Analytics.Entities;
using MarketPro.Common.Entities;
using MarketPro.Identity.Entities;
using MarketPro.Posts.Entities;
using System.ComponentModel.DataAnnotations.Schema;

namespace MarketPro.Documents.Entities;

public class Document : ModifiableDomainEntity
{
    public required string FileName { get; set; }
    //public virtual ApplicationUser? User { get; set; }
    public DocumentType DocumentType { get; set; }

    [ForeignKey(nameof(Post))]
    public Guid? PostId { get; set; }
    public virtual Post? Post { get; set; }

    [ForeignKey(nameof(ApplicationUser))]
    public string? ApplicationUserId { get; set; }
    public virtual ApplicationUser? ApplicationUser { get; set; }

    [ForeignKey(nameof(Report))]
    public Guid? ReportId { get; set; }
    public virtual Report? Report { get; set; }
}

public enum DocumentType
{
    Other = 0,
    PostImage = 1,
    ProfileImage = 2,
    Report = 3,
}
