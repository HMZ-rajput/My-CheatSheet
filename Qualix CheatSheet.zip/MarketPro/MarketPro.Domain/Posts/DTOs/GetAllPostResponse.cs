﻿using MarketPro.Common.DTOs;

namespace MarketPro.Posts.DTOs;

public class GetAllPostResponse : GetAllBaseResponse
{
    public IList<GetPostDTO> Posts { get; set; } = [];
}

public class GetPostResponse : BaseResponse
{
    public GetPostDTO? Post { get; set; }
}