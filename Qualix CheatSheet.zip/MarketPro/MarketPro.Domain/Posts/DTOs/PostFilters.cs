﻿using MarketPro.Common.DTOs;
using MarketPro.Posts.Entities;

namespace MarketPro.Posts.DTOs;

public class PostFilters : QueryStringParameters
{
    public string? Status { get; set; }
    public string? SocialsAccountIds { get; set; }
    public DateTimeOffset? StartDate {  get; set; }
    public DateTimeOffset? EndDate { get; set;}
    public bool IsCalanderView { get; set; }
}

