﻿using MarketPro.Documents.DTOs;
using MarketPro.Posts.Entities;
using MarketPro.SocialAccounts.DTOs;
using Microsoft.AspNetCore.Http;

namespace MarketPro.Posts.DTOs;

public class PostDTO
{
    public DateTimeOffset? ScheduledDate { get; set; }
    public required PostStatus Status { get; set; }
    public string? ModifiedBy { get; set; }
}

public class CreatePostDTO : PostDTO
{
    public IList<SocialAccountIdDTO> SocialAccounts { get; set; } = [];
    public string? FaceBookContent { get; set; }
    public string? InstagramContent { get; set; }
    public string? LinkedInContent { get; set; }
    public IList<IFormFile> FaceBookImages { get; set; } = [];
    public IList<IFormFile> InstagramImages { get; set; } = [];
    public IList<IFormFile> LinkedInImages { get; set; } = [];
    public IList<string> FaceBookImagesUrl { get; set; } = [];
    public IList<string> InstagramImagesUrl { get; set; } = [];
    public IList<string> LinkedInImagesUrl { get; set; } = [];
}

public class SocialAccountIdDTO
{
    public Guid Id { get; set; }
    public string? PageId { get; set; }
    public string? PageName { get; set; }
}

public class UpdatePostDTO : PostDTO
{
    public Guid? SocialAccountId { get; set; }
    public string? PageId { get; set; }
    public string? PageName { get; set; }
    public string Content { get; set; } = string.Empty;
    public IList<IFormFile> Images { get; set; } = [];
    public IList<string> ImagesUrl { get; set; } = [];
}

public class DeletePostDTO
{
    public IList<Guid> Ids { get; set; } = [];
    public string? ModifiedBy { get; set; }
}

public class PostActionDTO
{
    public PostAction Action { get; set; }
    public string? ModifiedBy { get; set; }
}

public class GetPostResponseDTO : PostDTO
{
    public IList<Guid> Ids { get; set; } = [];
    public IList<Guid> IsSuccessIds { get; set; } = [];
    public IList<SocialAccountInfoDTO> SocialAccounts { get; set; } = [];
    public DateTimeOffset? ModifiedDate { get; set; }
    public string? CreatedBy { get; set; }
    public DateTimeOffset? CreatedDate { get; set; }
    public string? LastModifiedBy => ModifiedBy ?? CreatedBy;
    public DateTimeOffset? LastModifiedDate => ModifiedDate ?? CreatedDate;
}

public class GetPostDTO : PostDTO
{
    public Guid? Id { get; set; }
    public string? Content { get; set; }
    public bool IsPublished { get; set; }
    public DateTimeOffset? PublishedDate { get; set; }
    public IList<DocumentDTO> Images { get; set; } = [];
    public SocialAccountInfoDTO? SocialAccount { get; set; }
    public string? PublishedBy {  get; set; }
    public string? PublisedPostId { get; set; }
    public string? PageId { get; set; }
    public string? PageName { get; set; }
    public DateTimeOffset? ModifiedDate { get; set; }
    public string? CreatedBy { get; set; }
    public DateTimeOffset? CreatedDate { get; set; }
    public string? LastModifiedBy => ModifiedBy ?? CreatedBy;
    public DateTimeOffset? LastModifiedDate => ModifiedDate ?? CreatedDate;
    public DateTimeOffset? DisplayDate {  get; set; }

    private readonly List<string> errors = [];

    public List<string> Errors
    {
        get { return errors; }
    }

    public bool IsSuccess => errors.Count == 0;

    public void AddError(string error)
    {
        errors.Add(error);
    }
}

public enum PostAction
{
    Duplicate = 0,
    PublishNow = 1,
}