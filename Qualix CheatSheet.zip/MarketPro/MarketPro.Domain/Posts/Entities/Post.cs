﻿using MarketPro.Common.Entities;
using MarketPro.Documents.Entities;
using MarketPro.Identity.Entities;
using MarketPro.SocialAccounts.Entities;
using System.ComponentModel.DataAnnotations.Schema;

namespace MarketPro.Posts.Entities;

public class Post : ModifiableDomainEntity
{
    public string Content { get; set; } = string.Empty;
    public DateTimeOffset? ScheduledDate { get; set; }
    public PostStatus Status { get; set; }
    public string PageId { get; set; } = string.Empty;
    public string PageName { get; set; } = string.Empty;
    public string? PublishedPostId { get; set; }
    public bool IsPublished => Status == PostStatus.Published;
    public DateTimeOffset? PublishDate { get; set; }
    public string? PublishedBy { get; set; }

    [ForeignKey(nameof(ApplicationUser))]
    public string? ApplicationUserId { get; set; }
    public virtual ApplicationUser? ApplicationUser { get; set; }

    [ForeignKey(nameof(SocialAccount))]
    public Guid? SocialAccountId { get; set; }
    public virtual SocialAccount? SocialAccount { get; set; }

    public ICollection<Document> Images { get; } = [];
}

public enum PostStatus
{
    Draft = 0,
    Published = 1,
    Failed = 2,
    Queue = 3
}