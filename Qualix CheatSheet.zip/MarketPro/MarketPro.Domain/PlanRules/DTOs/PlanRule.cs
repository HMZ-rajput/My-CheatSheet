﻿namespace MarketPro.PlanRules.DTOs;

public class PlanRule
{
    public int MaxSocialAccounts { get; set; }
    public int MaxManagers { get; set; }
    public bool IsAiAllowed { get; set; }
    public bool IsQueueAllowed { get; set; }
}

