﻿using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.Options;
using MarketPro.Identity.Entities;
using System.Security.Claims;

namespace MarketPro.Common;

public class ClaimsPrincipalFactory : UserClaimsPrincipalFactory<ApplicationUser>
{
    public ClaimsPrincipalFactory(
        UserManager<ApplicationUser> userManager,
        IOptions<IdentityOptions> optionsAccessor)
            : base(userManager, optionsAccessor)
    {
    }

    protected override async Task<ClaimsIdentity> GenerateClaimsAsync(ApplicationUser user)
    {
        var identity = await base.GenerateClaimsAsync(user);
        identity.AddClaim(new Claim(ClaimTypes.Email, user.Email ?? ""));
        identity.AddClaim(new Claim(ClaimTypes.GivenName, user.NormalizedUserName ?? string.Format("{0} {1}", user.FirstName, user.LastName)));
        var badData = identity.Claims.Where(c => c.Type == ClaimTypes.Name).Skip(1).ToArray();
        for (int i = 0; i < badData.Length; i++)
        {
            identity.RemoveClaim(badData[i]);
        }
        return identity;
    }
}
