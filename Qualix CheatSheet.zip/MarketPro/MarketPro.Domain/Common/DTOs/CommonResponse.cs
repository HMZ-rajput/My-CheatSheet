﻿namespace MarketPro.Common.DTOs;

public class CommonResponse : BaseResponse
{
}
