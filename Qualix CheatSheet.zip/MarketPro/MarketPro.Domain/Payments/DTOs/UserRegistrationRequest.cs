﻿using MarketPro.UserAccounts.Entities;
using System.ComponentModel.DataAnnotations;

namespace MarketPro.Payments.DTOs;

public class UserRegistrationRequest
{
    public required string Email { get; set; }
    public required string Name { get; set; }
    public required string PaymentMethod { get; set; }
    public required string CustomerId { get; set; }

    [Required]
    public required Plan Plan { get; set; }
}