﻿namespace MarketPro.Payments.DTOs;

public class StripePagination
{
    private const int _maxPageSize = 50;
    private int _pageSize = 10;
    public string? StartingAfter {  get; set; }
    public string? StartingBefore { get; set; }

    public int PageSize
    {
        get
        {
            return _pageSize;
        }
        set
        {
            _pageSize = (value > _maxPageSize) ? _maxPageSize : value;
        }
    }
}

public class StripePaginationDTO : StripePagination
{
    public bool HasNext { get; set; } = false;

    public bool HasPrevious { get; set; } = false;
}


