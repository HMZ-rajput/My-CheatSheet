﻿using MarketPro.Common.DTOs;

namespace MarketPro.Payments.DTOs;

public class InvoiceRespose : BaseResponse
{
    public IList<InvoiceDTO> Invoices { get; set; } = [];
    public int PageSize { get; set; }
    public int TotalCount { get; set; }
    public bool HasNext { get; set; }
    public bool HasPrevious { get; set; }
}

public class InvoiceDTO
{
    public string Id { get; set; } = string.Empty;
    public IList<string> Description { get; set; } = [];
    public DateTimeOffset Date { get; set; }
    public decimal Amount { get; set; }
    public InvoiceStatus Status { get; set; }
    public string BillingPeriod { get; set; } = "Monthly";
    public string? ViewURL { get; set; }
    public string? DownloadURL { get; set; }
}

public enum InvoiceStatus
{
    draft = 0,
    open = 1,
    paid = 2,
    uncollectible = 3,
    empty = 4,
}

