﻿using MarketPro.Common.DTOs;
using MarketPro.UserAccounts.Entities;

namespace MarketPro.Payments.DTOs;

public class PlansResponse : BaseResponse
{
    public IList<PlanDTO> Plans { get; set; } = [];
}

public class PlanResponse : BaseResponse
{
    public PlanDTO? Plan { get; set; }
}

public class PlanDTO
{
    public string ProductId { get; set; } = string.Empty;
    public string PlanId {  get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public Plan Plan { get; set; }
    public decimal Price { get; set; }
    public string Duration { get; set; } = string.Empty ;
    public IList<string> Features { get; set; } = [];

}

