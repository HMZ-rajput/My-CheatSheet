﻿using MarketPro.Common.DTOs;
using System.ComponentModel.DataAnnotations;

namespace MarketPro.Payments.DTOs;

public class GetClientKeyResponse : BaseResponse
{
    public string Key { get; set; } = string.Empty;
    public string CustomerId { get; set; } = string.Empty;
}

public class CreateIntentAndGetKeyRequest
{
    [Required]
    public string FullName { get; set; } = string.Empty;

    [Required]
    public string Email { get; set; } = string.Empty;
    public bool IsUpdate { get; set; }
}