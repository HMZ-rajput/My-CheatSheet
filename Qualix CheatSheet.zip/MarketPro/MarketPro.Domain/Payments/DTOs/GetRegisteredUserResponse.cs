﻿using MarketPro.Common.DTOs;

namespace MarketPro.Payments.DTOs;

public class GetRegisteredUserResponse : BaseResponse
{
    public StripeDetails? Stripe { get; set; }
}

public class StripeDetails
{
    public required string StripeCustomerId { get; set; }
    public required string SubscriptionId { get; set; }
    public required string SubscriptionStatus { get; set; }
}