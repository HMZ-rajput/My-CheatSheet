﻿using MarketPro.UserAccounts.Entities;
using System.ComponentModel.DataAnnotations;

namespace MarketPro.Payments.DTOs;

public class UpdateSubscriptionRequest
{
    public Plan Plan { get; set; }
    public string? ModifiedBy { get; set; }
}

public class UpdatePaymentMethodRequest
{
    [Required]
    public required string PaymentId { get; set; }

    public string? ModifiedBy { get; set; }
}