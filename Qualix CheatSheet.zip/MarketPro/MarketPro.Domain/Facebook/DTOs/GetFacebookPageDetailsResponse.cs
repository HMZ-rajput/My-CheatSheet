﻿using MarketPro.Common.DTOs;

namespace MarketPro.Facebook.DTOs;

public class GetFacebookPageDetailsResponse : BaseResponse
{
    public IList<PageDTO> Pages { get; set; } = [];
}

public class CategoryList
{
    public string? Id { get; set; }
    public string? Name { get; set; }
}

public class PageDTO
{
    public string? Id { get; set; }
    public string? Name { get; set; }
    public string? AccessToken { get; set; }
    public string? Category { get; set; }
    public IList<CategoryList> Categories { get; set; } = [];
    public InstagramBusinessAccount? InstagramBusinessAccount { get; set; }
}