﻿using MarketPro.Common.DTOs;
using Newtonsoft.Json;

namespace MarketPro.Facebook.DTOs;

public class FacebookPageDetailResponse : BaseResponse
{
    [JsonProperty("data")]
    public ICollection<PageDataDTO> Pages { get; set; } = [];
}

public class PageDataDTO
{
    [JsonProperty("id")]
    public string? Id { get; set; }

    [JsonProperty("name")]
    public string? Name { get; set; }

    [JsonProperty("category")]
    public string? Category { get; set; }

    [JsonProperty("category_list")]
    public ICollection<CategoryDataDTO> Categories { get; set; } = [];

    [JsonProperty("access_token")]
    public string? AccessToken { get; set; }

    [JsonProperty("instagram_business_account")]
    public InstagramBusinessAccount? InstagramBusinessAccount { get; set; }

}

public class CategoryDataDTO
{
    [JsonProperty("id")]
    public string? Id { get; set; }

    [JsonProperty("name")]
    public string? Name { get; set; }
}

public class InstagramBusinessAccount
{
    [JsonProperty("id")]
    public string? Id { get; set; }

    [JsonProperty("name")]
    public string? Name { get; set; }

    [JsonProperty("username")]
    public string? Username { get; set; }

    [JsonProperty("profile_picture_url")]
    public string? ProfilePicture { get; set; }
}