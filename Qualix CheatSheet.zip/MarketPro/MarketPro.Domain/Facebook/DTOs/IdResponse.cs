﻿using MarketPro.Common.DTOs;
using Newtonsoft.Json;

namespace MarketPro.Facebook.DTOs;

public class IdResponse : BaseResponse
{
    [JsonProperty("id")]
    public string? Id { get; set; }
}

