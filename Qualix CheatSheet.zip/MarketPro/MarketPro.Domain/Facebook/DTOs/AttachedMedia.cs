﻿namespace MarketPro.Facebook.DTOs;

public class AttachedMedia
{
    public required string media_fbid { get; set; }
}