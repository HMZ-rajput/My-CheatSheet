﻿using MarketPro.Common.DTOs;
using Newtonsoft.Json;

namespace MarketPro.Facebook.DTOs;

public class PageInsightsResponse : BaseResponse
{
    public PageInsights? Insights { get; set; }
}

public class PageInsights
{
    [JsonProperty("data")]
    public IList<InsightData> Data { get; set; } = [];

    [JsonProperty("paging")]
    public PagingInfo? Paging { get; set; }
}

public class InsightData
{
    [JsonProperty("name")]
    public string? Name { get; set; }

    [JsonProperty("period")]
    public string? Period { get; set; }

    [JsonProperty("values")]
    public IList<InsightValue> Values { get; set; } = [];

    [JsonProperty("title")]
    public string? Title { get; set; }

    [JsonProperty("description")]
    public string? Description { get; set; }

    [JsonProperty("id")]
    public string? Id { get; set; }
}

public class InsightValue
{
    [JsonProperty("value")]
    public int Value { get; set; }

    [JsonProperty("end_time")]
    public DateTime EndTime { get; set; }
}

public class PagingInfo
{
    [JsonProperty("previous")]
    public string? Previous { get; set; }

    [JsonProperty("next")]
    public string? Next { get; set; }
}