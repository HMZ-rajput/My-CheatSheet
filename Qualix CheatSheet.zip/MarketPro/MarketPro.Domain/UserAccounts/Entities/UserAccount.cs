﻿using MarketPro.Common.Entities;
using MarketPro.Identity.Entities;
using MarketPro.Managers.Entities;
using System.ComponentModel.DataAnnotations.Schema;

namespace MarketPro.UserAccounts.Entities;

public class UserAccount : ModifiableDomainEntity
{
    public required Plan Plan { get; set; }
    public required string PaymentId { get; set; }
    public string? BusinessDescription { get; set; }
    public required string StripeCustomerId { get; set; }
    public required string SubscriptionId { get; set; }
    public required SubscriptionStatus SubscriptionStatus { get; set; }
    public string? TargetAudienceDescription { get; set; }
    public DateTimeOffset? SubscriptionDate { get; set; }

    [ForeignKey(nameof(ApplicationUser))]
    public string? ApplicationUserId { get; set; }
    public virtual ApplicationUser? ApplicationUser { get; set; }
    public ICollection<ApplicationUser> Managers { get; } = [];
}

public enum Plan
{
    Basic = 0,
    Pro = 1,
    Enterprise = 2
}

public enum SubscriptionStatus
{
    paused = 0,
    incomplete_expired = 1,
    trialing = 2,
    active = 3,
    past_due = 4,
    canceled = 5,
    unpaid = 6,
    incomplete = 7,
    failed = 8
}