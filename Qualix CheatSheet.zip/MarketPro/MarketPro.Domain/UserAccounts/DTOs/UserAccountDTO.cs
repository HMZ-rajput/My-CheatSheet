﻿using MarketPro.UserAccounts.Entities;
using System.ComponentModel.DataAnnotations;

namespace MarketPro.UserAccounts.DTOs;

public class UserAccountDTO
{
    [Required]
    public required Plan Plan { get; set; }

    [Required]
    public required string PaymentId { get; set; }

    [Required]
    public required string CustomerId { get; set; }
    public string? BusinessDescription { get; set; }
    public string? TargetAudienceDescription { get; set; }
}