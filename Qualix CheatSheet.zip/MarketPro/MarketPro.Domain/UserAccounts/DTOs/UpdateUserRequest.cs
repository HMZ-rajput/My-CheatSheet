﻿using MarketPro.UserAccounts.Entities;
using System.ComponentModel.DataAnnotations;

namespace MarketPro.UserAccounts.DTOs;

public class UpdateUserRequest
{
    public string? FirstName { get; set; }
    public string? LastName { get; set; }
    public string? BusinessDescription { get; set; }
    public string? TargetAudienceDescription { get; set; }
    public Plan? Plan { get; set; }
}