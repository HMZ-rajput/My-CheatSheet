﻿using System.ComponentModel.DataAnnotations;

namespace ProjectName.Mails.DTOs;

public record SendEmailRequest
{
    [Required]
    public IList<string> ToAddress { get; set; } = [];

    [Required]
    public string Subject { get; set; } = string.Empty;

    [Required]
    public string Body { get; set; } = string.Empty;
    public IList<string> Attachments { get; set; } = [];
    public IList<string> Cc { get; set; } = [];
    public IList<string> Bcc { get; set; } = [];
    public bool IsReminder { get; set; }
    public int ReminderDays { get; set; }
}

public record EmailResponse
{
    public string Email { get; set; } = string.Empty;
    public bool IsSent { get; set; }
}