﻿using ProjectName.Common.Entities;

namespace ProjectName.MailTemplates.Entities;

public record MailTemplate : ModifiableDomainEntity
{
    public required string Subject { get; set; }
    public required string Template { get; set; }
    public string? Row { get; set; }
    public MailType Type { get; set; }
}

public enum MailType
{
    UserWelcome = 0,
    ForgetPassword = 1,
    UserCreated = 2,
}

