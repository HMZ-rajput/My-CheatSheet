﻿using System.ComponentModel.DataAnnotations;
using ProjectName.Common.DTOs;

namespace ProjectName.ReferenceData.DTOs
{
    public record ReferenceDataDTO
    {
        [Required(ErrorMessage = "Name is required.")]
        public string Name { get; set; } = string.Empty;
    }

    public record GetReferenceDataDTO : ReferenceDataDTO
    {
        public Guid Id { get; set; }
    }

    public record GetReferenceEntityResponse : BaseResponse
    {
        public GetReferenceDataDTO? Data { get; set; }
    }

    public record GetReferenceDataListResponse : BaseResponse
    {
        public List<GetReferenceDataDTO> Data { get; set; } = [];
    }
}
