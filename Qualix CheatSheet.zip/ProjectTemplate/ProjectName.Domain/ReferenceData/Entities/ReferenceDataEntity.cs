﻿using ProjectName.Common.Entities;

namespace ProjectName.ReferenceData.Entities;

public record ReferenceDataEntity : ModifiableDomainEntity
{
    public string Name { get; set; } = string.Empty;
}
