﻿namespace ProjectName.Common.Extensions;

public static class DateTimeExtensions
{
	public static DateTime StartOfWeek(this DateTime dt, DayOfWeek startOfWeek)
	{
		int diff = (7 + (dt.DayOfWeek - startOfWeek)) % 7;
		return dt.AddDays(-diff).Date;
	}

	public static DateTimeOffset StartOfDayUtc(this DateTimeOffset dateTimeOffset)
	{
		var utcDateTime = dateTimeOffset.ToUniversalTime();
		return utcDateTime;
	}

	public static DateTimeOffset EndOfDayUtc(this DateTimeOffset dateTimeOffset)
	{
		var utcDateTime = dateTimeOffset.AddDays(1).AddTicks(-1).ToUniversalTime();
		return utcDateTime;
	}

	public static DateTimeOffset? StartOfDayUtc(this DateTimeOffset? dateTimeOffset)
	{
		return dateTimeOffset?.StartOfDayUtc();
	}

	public static DateTimeOffset? EndOfDayUtc(this DateTimeOffset? dateTimeOffset)
	{
		return dateTimeOffset?.EndOfDayUtc();
	}

	public static string? FormatDate(this DateTimeOffset? date)
	{
		if (!date.HasValue)
			return null;

		return date.Value.ToString("MM/dd/yyyy");
	}

	public static string? FormatDate(this DateTimeOffset date)
	{
		return date.ToString("MM/dd/yyyy");
	}

	public static string? FormatDateWithTime(this DateTimeOffset? date)
	{
		if (!date.HasValue)
			return null;

		return date.Value.ToString("MM/dd/yyyy hh:mm tt");
	}

	public static string? FormatDateWithTime(this DateTimeOffset date)
	{
		return date.ToString("MM/dd/yyyy hh:mm tt");
	}

	public static string? FormatTime(this TimeSpan? time)
	{
		if (!time.HasValue)
			return null;

		DateTime Datetime = DateTime.Today.Add(time.Value);
		return Datetime.ToString("hh:mm tt");
	}

	public static string? FormatTime(this TimeSpan time)
	{
		DateTime Datetime = DateTime.Today.Add(time);
		return Datetime.ToString("hh:mm tt");
	}

}
