﻿namespace ProjectName.Common.Extensions;
public static class DecimalExtension
{
	public static string DecimalToFormattedString(this decimal value)
	{
		return value.ToString("#,0.##");
	}

	public static string DecimalToFormattedString(this decimal? value)
	{
		return value.HasValue ? value.Value.ToString("#,0.##") : string.Empty;
	}
}
