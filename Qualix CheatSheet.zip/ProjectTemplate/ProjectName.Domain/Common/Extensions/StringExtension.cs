﻿using System.Text.RegularExpressions;

namespace ProjectName.Common.Extensions;
public static class StringExtension
{
    public static string ToReadableLabel(this string? propertyName)
    {
        if (string.IsNullOrWhiteSpace(propertyName))
            return string.Empty;

        string formatted = Regex.Replace(
            propertyName,
            "(?<=[A-Z])(?=[A-Z][a-z])|(?<=[^A-Z])(?=[A-Z])|(?<=[A-Za-z])(?=[^A-Za-z])",
            " "
        );

        return formatted;
    }

    public static string ConvertToE164(this string? rawNumber)
    {
        if (string.IsNullOrWhiteSpace(rawNumber))
            return string.Empty;

        var digits = new string(rawNumber.Where(char.IsDigit).ToArray());

        return "+" + digits;
    }

    public static string NormalizePhoneNumber(this string? input)
    {
        if (string.IsNullOrWhiteSpace(input))
            return string.Empty;

        string cleaned = Regex.Replace(input, @"[^\d+]", "");

        if (cleaned.StartsWith("+"))
        {
            cleaned = cleaned.Substring(1);
        }

        return cleaned;
    }

}
