﻿using ProjectName.Common.DTOs;

namespace ProjectName.Common.Extensions;
public static class PaginationExtension
{
    public static TResponse MapPaginationToResponse<TResponse, TItem>(
        this TResponse response,
        PagedList<TItem> source) where TResponse : GetAllBaseResponse, new()
    {
        {
            response.CurrentPage = source.CurrentPage;
            response.TotalPages = source.TotalPages;
            response.PageSize = source.PageSize;
            response.TotalCount = source.TotalCount;
            response.HasPrevious = source.HasPrevious;
            response.HasNext = source.HasNext;

            return response;
        }
    }
}
