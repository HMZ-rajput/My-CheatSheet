﻿namespace ProjectName.Common.DTOs
{
    public record ErrorResponse : BaseResponse
    {

    }
}
