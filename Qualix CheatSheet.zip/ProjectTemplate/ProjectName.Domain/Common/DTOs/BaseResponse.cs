﻿using ProjectName.Common.Enums;

namespace ProjectName.Common.DTOs
{
    public abstract record BaseResponse
    {
        private readonly List<string> errors = [];

        public List<string> Errors
        {
            get { return errors; }
        }

        public string? WarningMessage { get; set; }
        public string? WarningHeading { get; set; }
        public WarningType? WarningType { get; set; }
        public bool IsSuccess => string.IsNullOrEmpty(WarningMessage) && errors.Count == 0;
        public string? Message => Errors.FirstOrDefault() ?? (string.IsNullOrEmpty(WarningMessage) && !IsSuccess ? "An error occurred while processing data." : null);

        public void AddError(string error)
        {
            errors.Add(error);
        }
    }

    public abstract record GetAllBaseResponse : BaseResponse
    {
        public int CurrentPage { get; set; }
        public int TotalPages { get; set; }
        public int PageSize { get; set; }
        public int TotalCount { get; set; }
        public bool HasPrevious { get; set; }
        public bool HasNext { get; set; }
    }

    public record GetAllBaseResponseModified : BaseResponseModified
    {
        public int CurrentPage { get; set; }
        public int TotalPages { get; set; }
        public int PageSize { get; set; }
        public int TotalCount { get; set; }
        public bool HasPrevious { get; set; }
        public bool HasNext { get; set; }
    }

    public record BaseResponseModified : BaseResponse
    {
        public DateTimeOffset? ModifiedDate { get; set; }
        public string? CreatedBy { get; set; }
        public string? ModifiedBy { get; set; }
        public DateTimeOffset? CreatedDate { get; set; }
        public string? LastModifiedBy => ModifiedBy ?? CreatedBy;
        public DateTimeOffset? LastModifiedDate => ModifiedDate ?? CreatedDate;
    }
    public record BaseResponseModificationInfo
    {
        public DateTimeOffset? ModifiedDate { get; set; }
        public string? CreatedBy { get; set; }
        public string? ModifiedBy { get; set; }
        public DateTimeOffset? CreatedDate { get; set; }
        public string? LastModifiedBy => ModifiedBy ?? CreatedBy;
        public DateTimeOffset? LastModifiedDate => ModifiedDate ?? CreatedDate;
    }
}
