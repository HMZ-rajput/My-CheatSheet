﻿namespace ProjectName.Common.Enums;

public enum EntityType
{
}

public enum WarningType
{
    Other = 0,
}
