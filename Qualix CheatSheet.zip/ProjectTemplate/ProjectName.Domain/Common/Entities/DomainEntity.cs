﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ProjectName.Common.Entities;

public abstract record DomainEntity
{
    [Key]
    public Guid Id { get; set; } = Guid.NewGuid();
    public DateTimeOffset CreatedDate { get; set; } = DateTimeOffset.UtcNow;
    public string? CreatedBy { get; set; }
    public bool IsActive { get; set; } = true;

    [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
    public int ShortId { get; set; }
}

public abstract record ModifiableDomainEntity : DomainEntity
{
    public DateTimeOffset? ModifiedDate { get; set; }
    public string? ModifiedBy { get; set; }
}
