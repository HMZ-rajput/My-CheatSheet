﻿namespace ProjectName.Common.Constants;

public static class MailConstants
{
    public static string CreateUserEmailSubject { get; private set; } = $"Your {Placeholders.AppName} account password";
    public static string CreateUserEmailBody { get; private set; } = $"Your {Placeholders.AppName} account has been successfully created. Please use this username: <b>{Placeholders.Email}</b> and password: <b>{Placeholders.Password}</b> to login";
    public static string PasswordOTPEmailSubject { get; private set; } = $"OTP For Resetting Your {Placeholders.AppName} Password";
    public static string PasswordOTPEmailBody { get; private set; } = $"Dear {Placeholders.AppName} User, Please use this OTP <b>{Placeholders.OTP}</b> to reset your password. Please ignore this email if you did not request a password reset and contact {Placeholders.SupportEmail}.";
    public static string LoginOTPEmailSubject { get; private set; } = $"OTP for login to {Placeholders.AppName}";
    public static string LoginOTPEmailBody { get; private set; } = $"Dear {Placeholders.AppName} User, Please use this OTP <b>{Placeholders.OTP}</b> to login yout account. Please change your password if it was not you and contact {Placeholders.OTP}.";
}
