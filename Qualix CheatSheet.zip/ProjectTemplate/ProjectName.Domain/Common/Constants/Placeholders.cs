﻿namespace ProjectName.Common.Constants;

public static class Placeholders
{
    public const string OTP = "{OTP}";
    public const string AppName = "{APP NAME}";
    public const string Email = "{EMAIL}";
    public const string Password = "{PASSWORD}";
    public const string SupportEmail = "{SUPPORT EMAIL}";
    public const string BaseUrl = "{BASE URL}";
}
