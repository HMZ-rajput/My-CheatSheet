﻿namespace ProjectName.Common.Constants;

public static class ErrorMessages
{
    public const string UserNotExistsError = "User does not exist.";
    public const string UserAlreadyExistsError = "A user already exists with this email. Please use a different email.";
    public const string InvalidUserCredentialsError = "Invalid username or password. Please verify your credentials and try again.";
    public const string PasswordUpdateError = "Something went wrong while updating your password. Please try again later.";
    public const string InvalidOTPError = "The OTP is either invalid or expired.";
    public const string OTPNotSendError = "We are unable to send you the OTP at the moment. Please try again later.";
}
