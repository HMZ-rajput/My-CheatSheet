﻿namespace ProjectName.Common.CustomAttributes;

[AttributeUsage(AttributeTargets.Interface | AttributeTargets.Class | AttributeTargets.Method, Inherited = false, AllowMultiple = false)]
public sealed class CustomDisplayNameAttribute : Attribute
{
    public string Name { get; }
    public CustomDisplayNameAttribute(string name) => Name = name;
}

