﻿using ProjectName.Common.Entities;
using ProjectName.Identity.Entities;

namespace ProjectName.Documents.Entities;

public record Document : ModifiableDomainEntity
{
    public int Index { get; set; }
    public string? FileName { get; set; }
    public DocumentType DocumentType { get; set; }
    public FileType FileType { get; set; }
    public string? Size { get; set; }
    public string? ApplicationUserId { get; set; }
    public virtual ApplicationUser? ApplicationUser { get; set; }
}

public enum DocumentType
{
    User = 0
}

public enum FileType
{
    Image = 0,
    Document = 1,
    Other = 2
}
