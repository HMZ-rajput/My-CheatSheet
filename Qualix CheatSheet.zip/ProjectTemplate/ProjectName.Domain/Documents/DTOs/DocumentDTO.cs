﻿using ProjectName.Documents.Entities;

namespace ProjectName.Documents.DTOs;

public class DocumentDTO
{
    public Guid? Id { get; set; }
    public Guid? Uid => Id;
    public int Index { get; set; }
    public string? Name { get; set; }
    public string? Size { get; set; }
    public DocumentType DocumentType { get; set; }
    public FileType FileType { get; set; }
    public string? URL { get; set; }
}
