﻿using ProjectName.Common.DTOs;
using System.ComponentModel.DataAnnotations;

namespace ProjectName.Identity.DTOs
{
    public record ResetPasswordRequest
    {
        [Required(ErrorMessage = "Email is required.")]
        [DataType(DataType.EmailAddress)]
        [RegularExpression("\\w+([-+.']\\w+)*@\\w+([-.]\\w+)*\\.\\w+([-.]\\w+)*", ErrorMessage = "Invalid Email Address")]
        public string Email { get; set; } = string.Empty;

        [Required(ErrorMessage = "Password is required.")]
        [DataType(DataType.Password)]
        [RegularExpression("^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[#$^+=!*()@%&]).{8,}$", ErrorMessage = "Password must be at least 8 characters long and include at least one uppercase letter, one lowercase letter, one number, and one special character.")]
        public string Password { get; set; } = string.Empty;

        [Required(ErrorMessage = "Reset password token is required.")]
        [DataType(DataType.Text)]
        public string ResetPasswordToken { get; set; } = string.Empty;
    }
    public record ResetPasswordResponse : BaseResponse
    {
    }
}
