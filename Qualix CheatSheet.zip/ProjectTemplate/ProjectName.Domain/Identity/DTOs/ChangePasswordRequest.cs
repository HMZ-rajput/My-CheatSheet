﻿using ProjectName.Common.DTOs;
using System.ComponentModel.DataAnnotations;

namespace ProjectName.Identity.DTOs;

public record ChangePasswordRequest
{
    [Required]
    [DataType(DataType.EmailAddress)]
    [RegularExpression("\\w+([-+.']\\w+)*@\\w+([-.]\\w+)*\\.\\w+([-.]\\w+)*", ErrorMessage = "Invalid Email Address")]
    public string Email { get; set; } = string.Empty;

    public string OldPassword { get; set; } = string.Empty;

    [Required]
    [DataType(DataType.Password)]
    [RegularExpression("^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[#$^+=!*()@%&]).{8,}$", ErrorMessage = "Password must be at least 8 characters long and include at least one uppercase letter, one lowercase letter, one number, and one special character.")]
    public string NewPassword { get; set; } = string.Empty;
}

public record ChangePasswordResponse : BaseResponse
{
}
