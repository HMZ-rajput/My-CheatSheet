﻿using ProjectName.Documents.DTOs;
using ProjectName.Common.DTOs;
using ProjectName.Identity.Entities;

namespace ProjectName.Identity.DTOs;

public record AuthDTO : BaseResponseModificationInfo
{
    public string Id { get; set; } = string.Empty;
    public string FirstName { get; set; } = string.Empty;
    public string LastName { get; set; } = string.Empty;
    public string FullName => $"{FirstName} {LastName}".Trim();
    public string Email { get; set; } = string.Empty;
    public string? PhoneNumber { get; set; }
    public UserRole Role { get; set; }
    public string? Address1 { get; set; }
    public string? Address2 { get; set; }
    public string? State { get; set; }
    public string? City { get; set; }
    public string? ZipCode { get; set; }
    public string BearerToken { get; set; } = string.Empty;
    public bool IsActive { get; set; } = true;
    public bool IsAuthenticated { get; set; }
    public DocumentDTO? ProfilePicture { get; set; }
}

public class GetAuthDTO
{
    public string Id { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public string FirstName { get; set; } = string.Empty;
    public string LastName { get; set; } = string.Empty;
    public string FullName => $"{FirstName} {LastName}".Trim();
}