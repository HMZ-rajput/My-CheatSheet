﻿using ProjectName.Common.DTOs;
using System.ComponentModel.DataAnnotations;

namespace ProjectName.Identity.DTOs
{
    public class VerifyPasswordOTPRequest
    {
        [Required(ErrorMessage = "Email is required.")]
        [DataType(DataType.EmailAddress)]
        [RegularExpression("\\w+([-+.']\\w+)*@\\w+([-.]\\w+)*\\.\\w+([-.]\\w+)*", ErrorMessage = "Invalid Email Address")]
        public string Email { get; set; } = string.Empty;

        [Required(ErrorMessage = "OTP is required.")]
        public int OTP { get; set; }
    }
    public record VerifyPasswordOTPResponse : BaseResponse
    {
        public VerifyPasswordOTPToken? Data { get; set; }
    }

    public record VerifyPasswordOTPToken
    {
        public string ResetPasswordToken { get; set; } = string.Empty;
    }

}


