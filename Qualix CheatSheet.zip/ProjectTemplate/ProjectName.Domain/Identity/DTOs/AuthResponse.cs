﻿using ProjectName.Common.DTOs;

namespace ProjectName.Identity.DTOs;

public record AuthResponse : BaseResponse
{
    public AuthDTO? Data { get; set; }
}