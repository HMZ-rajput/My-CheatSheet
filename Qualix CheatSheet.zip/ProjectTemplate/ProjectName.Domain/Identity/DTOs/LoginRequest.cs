﻿using Microsoft.AspNetCore.Http;
using System.ComponentModel.DataAnnotations;

namespace ProjectName.Identity.DTOs;

public record LoginRequest
{
    [Required(ErrorMessage = "Email is required.")]
    [DataType(DataType.EmailAddress)]
    public string Email { get; set; } = string.Empty;

    [Required(ErrorMessage = "Password is required.")]
    [DataType(DataType.Password)]
    public string Password { get; set; } = string.Empty;
}

public record UpdatePersonalInfoRequest
{
    [Required(ErrorMessage = "First name is required.")]
    [DataType(DataType.Text)]
    public string FirstName { get; set; } = string.Empty;

    [Required(ErrorMessage = "Last name is required.")]
    [DataType(DataType.Text)]
    public string LastName { get; set; } = string.Empty;
    public string? PhoneNumber { get; set; }
    public string? Address1 { get; set; } = string.Empty;
    public string? Address2 { get; set; } = string.Empty;
    public string? State { get; set; }
    public string? City { get; set; }
    public string? ZipCode { get; set; }
    public bool RemoveProfilePicture { get; set; }
    public IFormFile? ProfilePicture { get; set; }
}
