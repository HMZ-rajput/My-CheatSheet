﻿using ProjectName.Common.DTOs;
using System.ComponentModel.DataAnnotations;

namespace ProjectName.Identity.DTOs
{
    public class SendForgotPasswordEmailRequest
    {
        [Required(ErrorMessage = "Email is required.")]
        [DataType(DataType.EmailAddress)]
        [RegularExpression("\\w+([-+.']\\w+)*@\\w+([-.]\\w+)*\\.\\w+([-.]\\w+)*", ErrorMessage = "Invalid Email Address")]
        public string Email { get; set; } = string.Empty;
    }
    public record SendForgotPasswordEmailResponse : BaseResponse
    {
        public ForgotPasswordEmailResponse? Data { get; set; }
    }
    public record ForgotPasswordEmailResponse
    {
        public string? Email { get; set; }
    }
    public record SendConfirmPhoneRequest
    {
        [Required(ErrorMessage = "Email is required.")]
        [DataType(DataType.EmailAddress)]
        [RegularExpression("\\w+([-+.']\\w+)*@\\w+([-.]\\w+)*\\.\\w+([-.]\\w+)*", ErrorMessage = "Invalid Email Address")]
        public string Email { get; set; } = string.Empty;

        [Required(ErrorMessage = "Phone number is required.")]
        public string PhoneNumber { get; set; } = string.Empty;
    }
    public class SendConfirmEmailRequest
    {
        [Required(ErrorMessage = "Email is required.")]
        [DataType(DataType.EmailAddress)]
        [RegularExpression("\\w+([-+.']\\w+)*@\\w+([-.]\\w+)*\\.\\w+([-.]\\w+)*", ErrorMessage = "Invalid Email Address")]
        public string Email { get; set; } = string.Empty;
    }
}
