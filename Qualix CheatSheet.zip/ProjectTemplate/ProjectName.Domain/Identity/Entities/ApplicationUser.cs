﻿using ProjectName.Documents.Entities;
using Microsoft.AspNetCore.Identity;

namespace ProjectName.Identity.Entities;

public class ApplicationUser : IdentityUser
{
    public string FirstName { get; set; } = "FirstName";
    public string LastName { get; set; } = "LastName";
    public int TokenVersion { get; set; }
    public string? Address1 { get; set; }
    public string? Address2 { get; set; }
    public string? State { get; set; }
    public string? City { get; set; }
    public string? ZipCode { get; set; }
    public UserRole Role { get; set; }
    public UserStatus Status { get; set; }
    public bool IsActive { get; set; } = true;
    public int? PasswordOTP { get; set; }
    public DateTimeOffset PasswordOTPDate { get; set; }
    public int? EmailOTP { get; set; }
    public DateTimeOffset EmailOTPDate { get; set; }
    public int? PhoneOTP { get; set; }
    public DateTimeOffset PhoneOTPDate { get; set; }
    public DateTimeOffset CreatedDate { get; set; } = DateTimeOffset.Now;
    public string? CreatedBy { get; set; }
    public DateTimeOffset? ModifiedDate { get; set; }
    public string? ModifiedBy { get; set; }
    public virtual ICollection<Document> Documents { get; } = [];

    public ApplicationUser ShallowCopy()
    {
        return (ApplicationUser)MemberwiseClone();
    }
}
public enum UserRole
{
    SuperAdmin = 0,
    Admin = 1,
}
public enum UserStatus
{
    Active = 0,
    InActive = 1,
    InvitationSent = 2,
}

