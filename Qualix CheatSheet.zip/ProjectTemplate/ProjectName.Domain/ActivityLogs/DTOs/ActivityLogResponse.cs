﻿using ProjectName.Common.DTOs;

namespace ProjectName.ActivityLogs.DTOs;

public record ActivityLogResponse : GetAllBaseResponse
{
    public IList<ActivityLogDTO> Data { get; set; } = [];
}
