﻿using System.Text.Json.Serialization;

namespace ProjectName.ActivityLogs.DTOs;

public class ActivityLogDTO
{
    public Guid? Id { get; set; }
    public DateTimeOffset? Date { get; set; }
    public string? Name { get; set; } = string.Empty;
    public string? Description { get; set; } = string.Empty;
    public string? DisplayName { get; set; } = string.Empty;

    [JsonIgnore]
    public string? EntityType { get; set; } = string.Empty;

    [JsonIgnore]
    public string? EntityId { get; set; } = string.Empty;
}

