﻿using ProjectName.Common.DTOs;

namespace ProjectName.ActivityLogs.DTOs;

public record ActivityLogFilters : QueryStringParameters
{
    public string? Search { get; set; }
    public string? EntityType { get; set; }
    public string? EntityId { get; set; }
    public DateTimeOffset? StartDate { get; set; }
    public DateTimeOffset? EndDate { get; set; }
}
