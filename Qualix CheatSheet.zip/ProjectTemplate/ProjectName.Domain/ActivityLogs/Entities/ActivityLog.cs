﻿using ProjectName.Common.Entities;

namespace ProjectName.ActivityLogs.Entities;

public record ActivityLog : DomainEntity
{
    public string? Description { get; set; }
    public string? EntityType { get; set; }
    public string? EntityId { get; set; }
    public ActionType? ActionType { get; set; }
    public string? UserId { get; set; }
    public string? Username { get; set; }
}

public enum ActionType
{
    Created = 0,
    Modified = 1,
    Deleted = 2
}