﻿using Microsoft.AspNetCore.Authorization;

namespace ProjectName.AppConfigs.DTOs;

public class TokenVersionRequirement : IAuthorizationRequirement
{
}
