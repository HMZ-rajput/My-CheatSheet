﻿using ProjectName.Common.DTOs;

namespace ProjectName.AppConfigs.DTOs;

public record GetAppVersionResponse : BaseResponse
{
	public string Version { get; set; } = "1.0.0";
}

public record GetAppConfigResponse : BaseResponse
{
	public string Data { get; set; } = "";
}
