﻿using ProjectName.Common.Entities;

namespace ProjectName.AppConfigs.Entities;

public record AppConfig : ModifiableDomainEntity
{
    public string SettingKey { get; set; } = string.Empty;
    public string SettingValue { get; set; } = string.Empty;
}

