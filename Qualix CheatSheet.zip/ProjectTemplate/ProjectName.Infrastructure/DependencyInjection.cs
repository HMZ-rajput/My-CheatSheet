﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using Microsoft.Extensions.DependencyInjection;
using ProjectName.ActivityLogs.Entities;
using ProjectName.AppConfigs.Entities;
using ProjectName.Data;
using ProjectName.Identity.Entities;
using ProjectName.Repositories;
using ProjectName.Services;

namespace ProjectName
{
    public static class DependencyInjection
    {
        public static IServiceCollection AddInfrastructure(this IServiceCollection services, string? connectionString)
        {
            services.AddDbContext<ApplicationDbContext>(options => options.UseSqlServer(connectionString));
            services.AddScoped<CurrentUser>();
            services.AddScoped<IAuthRepository<ApplicationUser>, AuthRepository>();
            services.AddScoped<IAppConfigRepository<AppConfig>, AppConfigRepository>();
            services.AddScoped<IActivityLogRepository<ActivityLog>, ActivityLogRepository>();
            services.AddScoped(typeof(IReferenceDataRepository<>), typeof(ReferenceDataRepository<>));

            return services;
        }
    }
    public class DesignTimeApplicationDbContext : IDesignTimeDbContextFactory<ApplicationDbContext>
    {
        public ApplicationDbContext CreateDbContext(string[] args)
        {
            var optionsBuilder = new DbContextOptionsBuilder<ApplicationDbContext>();
            optionsBuilder.UseSqlServer(AppEnvironment.ConnectionString);
            return new ApplicationDbContext(optionsBuilder.Options);
        }
    }
}
