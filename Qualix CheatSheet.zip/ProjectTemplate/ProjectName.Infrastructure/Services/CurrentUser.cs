﻿using ProjectName.Identity.Entities;
using Microsoft.AspNetCore.Http;
using System.Security.Claims;

namespace ProjectName.Services;

public class CurrentUser(IHttpContextAccessor httpContextAccessor)
{
    public string? Id => httpContextAccessor.HttpContext?.User.FindFirstValue(ClaimTypes.NameIdentifier);
    public string? Name => httpContextAccessor.HttpContext?.User.FindFirstValue(ClaimTypes.Name);
    public string? Role => httpContextAccessor.HttpContext?.User.FindFirstValue(ClaimTypes.Role);

    public UserRole? GetRole() =>
        Role switch
        {
            "Superadmin" => UserRole.SuperAdmin,
            "Admin" => UserRole.Admin,
            _ => null,
        };
}
