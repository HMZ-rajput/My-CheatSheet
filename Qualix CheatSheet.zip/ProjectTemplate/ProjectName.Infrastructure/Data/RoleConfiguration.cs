﻿using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace ProjectName.Data
{
    public record RoleConfiguration : IEntityTypeConfiguration<IdentityRole>
    {
        public void Configure(EntityTypeBuilder<IdentityRole> builder)
        {
            builder.HasData(
                new IdentityRole
                {
                    Id = RoleConstants.AdminRole.Id,
                    Name = RoleConstants.AdminRole.Name,
                    NormalizedName = RoleConstants.AdminRole.NormalizedName,
                },
                new IdentityRole
                {
                    Id = RoleConstants.SuperAdminRole.Id,
                    Name = RoleConstants.SuperAdminRole.Name,
                    NormalizedName = RoleConstants.SuperAdminRole.NormalizedName,
                }
            );
        }
    }
}
