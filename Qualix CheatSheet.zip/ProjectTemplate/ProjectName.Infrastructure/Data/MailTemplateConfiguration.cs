﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using ProjectName.Common.Constants;
using ProjectName.MailTemplates.Entities;

namespace ProjectName.Data;
public record MailTemplateConfiguration : IEntityTypeConfiguration<MailTemplate>
{
    public void Configure(EntityTypeBuilder<MailTemplate> builder)
    {
        builder.HasData(
            new MailTemplate
            {
                Id = Guid.Parse("EDD9784F-F8BE-448E-8616-0E5D0B984AA7"),
                Type = MailType.UserCreated,
                Subject = $"{Placeholders.AppName} account has been created.",
                Template = $@"<!DOCTYPE html>
          <html>
          <head>
          <meta charset=""UTF-8"" />
          </head>
          <body style=""font-family: Arial, sans-serif; background-color: #f4f4f4; padding: 20px; margin: 0;"">
          <table width=""100%"" cellpadding=""0"" cellspacing=""0"" style=""max-width: 600px; margin: auto; background-color: #ffffff; border-radius: 6px; box-shadow: 0 0 10px rgba(0,0,0,0.1);"">
          <tr>
          <td style=""padding: 20px 30px; text-align: center; background-color: #4CAF50; color: #ffffff; border-top-left-radius: 6px; border-top-right-radius: 6px;"">
          <h2 style=""margin: 0;"">Welcome to {Placeholders.AppName}!</h2>
          </td>
          </tr>
          <tr>
          <td style=""padding: 30px; color: #333333;"">
          <p style=""font-size: 16px; margin-bottom: 20px;"">Your account has been successfully created.</p>
          <p style=""font-size: 16px;"">Here are your login details:</p>
          <p style=""font-size: 16px;""><strong>Email:</strong> {Placeholders.Email}</p>
          <p style=""font-size: 16px;""><strong>Password:</strong> {Placeholders.Password}</p>
          <p style=""font-size: 16px; margin-top: 30px;"">You can now log in and start using your account.</p>
          <p style=""font-size: 16px; margin-top: 30px;"">
          <a href=""{Placeholders.BaseUrl}"" style=""display: inline-block; background-color: #4CAF50; color: white; padding: 12px 20px; text-decoration: none; border-radius: 4px;"">Login</a>
          </p>
          </td>
          </tr>
          </table>
          </body>
          </html>",
                CreatedDate = DateTimeOffset.Parse("2025-04-22 10:43:39.3147303 +00:00"),
                CreatedBy = "System"
            },
            new MailTemplate
            {
                Id = Guid.Parse("04BFB758-24EE-4A81-A697-23284F0A8578"),
                Type = MailType.ForgetPassword,
                Subject = $"OTP for resetting your {Placeholders.AppName} password.",
                Template = $@"<!DOCTYPE html>
          <html>
          <head>
          <meta charset=""UTF-8"" />
          </head>
          <body style=""font-family: Arial, sans-serif; background-color: #f4f4f4; padding: 20px; margin: 0;"">
          <table width=""100%"" cellpadding=""0"" cellspacing=""0"" style=""max-width: 600px; margin: auto; background-color: #ffffff; border-radius: 6px; box-shadow: 0 0 10px rgba(0,0,0,0.1);"">
          <tr>
          <td style=""padding: 20px 30px; text-align: center; background-color: #2196F3; color: #ffffff; border-top-left-radius: 6px; border-top-right-radius: 6px;"">
          <h2 style=""margin: 0;"">Password Reset Request</h2>
          </td>
          </tr>
          <tr>
          <td style=""padding: 30px; color: #333333;"">
          <p style=""font-size: 16px; margin-bottom: 20px;"">Dear {Placeholders.AppName} User,</p>
          <p style=""font-size: 16px; margin-bottom: 20px;"">We received a request to reset your password. Please use the OTP below to proceed:</p>
          <p style=""font-size: 24px; font-weight: bold; color: #2196F3; text-align: center; margin: 30px 0;"">{Placeholders.OTP}</p>
          <p style=""font-size: 16px; margin-top: 30px;"">If you did not request a password reset, please ignore this email. No further action is required.</p>
          </td>
          </tr>
          </table>
          </body>
          </html>",
                CreatedDate = DateTimeOffset.Parse("2025-04-22 10:43:39.3147303 +00:00"),
                CreatedBy = "System"
            },
            new MailTemplate
            {
                Id = Guid.Parse("5B4173F2-100D-4D93-BC6E-140DC4B8E4BC"),
                Type = MailType.UserWelcome,
                Subject = $"{Placeholders.AppName} account has been created.",
                Template = $@"<!DOCTYPE html>
          <html>
          <head>
          <meta charset=""UTF-8"" />
          </head>
          <body style=""font-family: Arial, sans-serif; background-color: #f4f4f4; padding: 20px; margin: 0;"">
          <table width=""100%"" cellpadding=""0"" cellspacing=""0"" style=""max-width: 600px; margin: auto; background-color: #ffffff; border-radius: 6px; box-shadow: 0 0 10px rgba(0,0,0,0.1);"">
          <tr>
          <td style=""padding: 20px 30px; text-align: center; background-color: #4CAF50; color: #ffffff; border-top-left-radius: 6px; border-top-right-radius: 6px;"">
          <h2 style=""margin: 0;"">Welcome to {Placeholders.AppName}!</h2>
          </td>
          </tr>
          <tr>
          <td style=""padding: 30px; color: #333333;"">
          <p style=""font-size: 16px; margin-bottom: 20px;"">Hi there,</p>
          <p style=""font-size: 16px;"">We're thrilled to have you on board! Your account has been successfully created, and you're all set to explore.</p>
          <p style=""font-size: 16px;""><strong>Registered Email:</strong> {Placeholders.Email}</p>
          <p style=""font-size: 16px; margin-top: 30px;"">Here’s how you can get started:</p>
          <ul style=""font-size: 16px; padding-left: 20px;"">
          <li>Log in to your account using your email.</li>
          <li>Complete your profile setup.</li>
          <li>Discover all the amazing features!</li>
          </ul>
          <p style=""font-size: 16px; margin-top: 30px;"">
          <a href=""{Placeholders.BaseUrl}"" style=""display: inline-block; background-color: #4CAF50; color: white; padding: 12px 20px; text-decoration: none; border-radius: 4px;"">Login</a>
          </p>
          <p style=""font-size: 16px; margin-top: 30px;"">Need help? Reply to this email.</p>
          <p style=""font-size: 16px; margin-top: 30px;"">Happy exploring!<br>The {Placeholders.AppName} Team</p>
          </td>
          </tr>
          </table>
          </body>
          </html>",
                CreatedDate = DateTimeOffset.Parse("2025-04-22 10:43:39.3147303 +00:00"),
                CreatedBy = "System"
            }
            );
    }
}