﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using ProjectName.ActivityLogs.Entities;
using ProjectName.AppConfigs.Entities;
using ProjectName.Identity.Entities;
using ProjectName.MailTemplates.Entities;

namespace ProjectName.Data;

public class ApplicationDbContext : IdentityDbContext<ApplicationUser>
{
    public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
    {
    }

    public DbSet<AppConfig> AppConfig { get; set; }
    public DbSet<ActivityLog> ActivityLog { get; set; }
    public DbSet<MailTemplate> MailTemplate { get; set; }

    protected override void OnModelCreating(ModelBuilder builder)
    {
        base.OnModelCreating(builder);

        builder.ApplyConfiguration(new RoleConfiguration());
        builder.ApplyConfiguration(new MailTemplateConfiguration());

        // Add Fluent API configurations here



    }
}
