﻿using Microsoft.AspNetCore.Identity;

namespace ProjectName.Data
{
    public static class RoleConstants
    {
        public static readonly IdentityRole SuperAdminRole = new()
        {
            Id = "15ed2398-0e42-4d5b-9f83-d1727f0bd5e9",
            Name = "Superadmin",
            NormalizedName = "SUPERADMIN",
        };
        public static readonly IdentityRole AdminRole = new()
        {
            Id = "833b7264-9e3f-4e2e-a752-628690acb053",
            Name = "Admin",
            NormalizedName = "ADMIN",
        };
    }
}
