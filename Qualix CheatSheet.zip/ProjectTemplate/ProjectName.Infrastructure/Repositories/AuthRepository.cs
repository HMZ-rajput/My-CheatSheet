﻿using ProjectName.Documents.DTOs;
using ProjectName.Documents.Entities;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using ProjectName.ActivityLogs.Entities;
using ProjectName.Common.DTOs;
using ProjectName.Common.Enums;
using ProjectName.Data;
using ProjectName.Identity.DTOs;
using ProjectName.Identity.Entities;
using ProjectName.Mails.DTOs;
using ProjectName.MailTemplates.Entities;
using ProjectName.Services;
using System.Data;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using ProjectName.Common.Constants;

namespace ProjectName.Repositories;

public class AuthRepository : BaseRepository<ApplicationUser>, IAuthRepository<ApplicationUser>
{
    private const int _otpMinValue = 100000;
    private const int _otpMaxValue = 999999;

    private readonly ApplicationDbContext _context;
    private readonly CurrentUser _currentUser;
    private readonly IFileService _fileService;
    private readonly UserManager<ApplicationUser> _userManager;
    private readonly IMailService _mailService;
    private readonly IActivityLogRepository<ActivityLog> _activityLogRepository;

    public AuthRepository(ApplicationDbContext context, IMailService mailService, UserManager<ApplicationUser> userManager, IHttpContextAccessor httpContextAccessor, IFileService fileService, IActivityLogRepository<ActivityLog> activityLogRepository) : base(context)
    {
        _context = context ?? throw new ArgumentNullException(nameof(context));
        _currentUser = new CurrentUser(httpContextAccessor ?? throw new ArgumentNullException(nameof(httpContextAccessor)));
        _userManager = userManager ?? throw new ArgumentNullException(nameof(userManager));
        _mailService = mailService ?? throw new ArgumentNullException(nameof(mailService));
        _fileService = fileService ?? throw new ArgumentNullException(nameof(fileService));
        _activityLogRepository = activityLogRepository ?? throw new ArgumentNullException(nameof(activityLogRepository));
    }

    async ValueTask<AuthResponse> IAuthRepository<ApplicationUser>.SignUpAsync(SignUpRequest request)
    {
        var response = new AuthResponse();

        var user = await _userManager.FindByNameAsync(request.Email.ToLower().Trim()).ConfigureAwait(false);

        if (user is not null)
        {
            response.AddError(ErrorMessages.UserAlreadyExistsError);
            return response;
        }

        user = new ApplicationUser
        {
            FirstName = request.FirstName,
            LastName = request.LastName,
            Email = request.Email.ToLower().Trim(),
            UserName = request.Email.ToLower().Trim(),
            Status = UserStatus.Active,
            PhoneNumber = request.PhoneNumber,
            Address1 = request.Address1,
            Address2 = request.Address2,
            State = request.State,
            City = request.City,
            ZipCode = request.ZipCode,
            Role = request.Role,
        };

        var identityResponse = await _userManager.CreateAsync(user, request.Password).ConfigureAwait(false);

        if (!identityResponse.Succeeded)
        {
            response.Errors.AddRange(identityResponse.Errors.Select(x => x.Description).ToList());
            return response;
        }

        await _userManager.AddToRoleAsync(user, user.Role.ToString());

        response.Data = await MapAuthAsync(user, _fileService).ConfigureAwait(false);
        await _activityLogRepository.LogEntityChangesAsync(null, user, ActionType.Created).ConfigureAwait(false);
        return response;
    }

    async ValueTask<AuthResponse> IAuthRepository<ApplicationUser>.LoginAsync(LoginRequest request)
    {
        var response = new AuthResponse();

        var user = await _context.Users
            .Include(x => x.Documents.Where(y => y.IsActive && y.DocumentType == DocumentType.User && y.FileType == FileType.Image))
            .FirstOrDefaultAsync(x => x.IsActive && x.Email != null ? x.Email.ToLower().Trim() == request.Email.ToLower().Trim() : false)
            .ConfigureAwait(false);

        if (user is null)
        {
            response.AddError(ErrorMessages.UserNotExistsError);
            return response;
        }

        var isAuthenticated = await _userManager.CheckPasswordAsync(user, request.Password).ConfigureAwait(false);

        if (!isAuthenticated)
        {
            response.AddError(ErrorMessages.InvalidUserCredentialsError);
            return response;
        }

        response.Data = await MapAuthAsync(user, _fileService);
        return response;
    }

    async ValueTask<AuthResponse> IAuthRepository<ApplicationUser>.GetUserInfoAsync()
    {
        var response = new AuthResponse();

        var user = await _context.Users
            .AsNoTracking()
            .Include(x => x.Documents.Where(y => y.IsActive && y.DocumentType == DocumentType.User && y.FileType == FileType.Image))
            .FirstOrDefaultAsync(x => x.IsActive && x.Id == _currentUser.Id)
            .ConfigureAwait(false);

        if (user is null)
            return response;

        response.Data = await MapAuthAsync(user, _fileService);
        return response;
    }

    async ValueTask<ChangePasswordResponse> IAuthRepository<ApplicationUser>.ChangePasswordAsync(ChangePasswordRequest request)
    {
        var response = new ChangePasswordResponse();
        var user = await _userManager.FindByNameAsync(request.Email.ToLower().Trim()).ConfigureAwait(false);
        if (user is null)
        {
            response.AddError(ErrorMessages.UserNotExistsError);
            return response;
        }

        var isValid = await _userManager.CheckPasswordAsync(user, request.OldPassword).ConfigureAwait(false);

        if (!isValid)
        {
            response.AddError("Your old password is incorrect.");
            return response;
        }

        var result = await _userManager.ChangePasswordAsync(user, request.OldPassword, request.NewPassword).ConfigureAwait(false);

        if (!result.Succeeded)
        {
            response.AddError(ErrorMessages.PasswordUpdateError);
            return response;
        }

        user.ModifiedBy = _currentUser.Name;
        user.ModifiedDate = DateTimeOffset.Now;
        await _userManager.UpdateAsync(user).ConfigureAwait(false);

        return response;
    }

    async ValueTask<SendForgotPasswordEmailResponse> IAuthRepository<ApplicationUser>.SendForgotPasswordEmailAsync(SendForgotPasswordEmailRequest request)
    {
        var response = new SendForgotPasswordEmailResponse();

        var user = await _userManager.FindByNameAsync(request.Email.ToLower().Trim());
        if (user is null)
        {
            response.AddError(ErrorMessages.UserNotExistsError);
            return response;
        }

        var otp = GenerateRandomNumber();
        var mailTemplate = await _context.MailTemplate
            .AsNoTracking()
            .FirstOrDefaultAsync(x => x.IsActive && x.Type == MailType.ForgetPassword)
            .ConfigureAwait(false);

        var emailSubject = string.Empty;
        var emailBody = string.Empty;
        if (mailTemplate is not null)
        {
            emailSubject = mailTemplate.Subject;
            emailSubject = emailSubject.Replace(Placeholders.AppName, AppEnvironment.AppName);

            emailBody = mailTemplate.Template;
            emailBody = emailBody.Replace(Placeholders.AppName, AppEnvironment.AppName);
            emailBody = emailBody.Replace(Placeholders.OTP, otp.ToString());
        }

        user.PasswordOTP = otp;
        user.PasswordOTPDate = DateTimeOffset.Now;
        user.ModifiedDate = DateTimeOffset.Now;
        await _userManager.UpdateAsync(user).ConfigureAwait(false);

        if (!string.IsNullOrEmpty(emailBody))
        {
            var emailRequest = new SendEmailRequest
            {
                ToAddress = [request.Email.ToLower().Trim()],
                Subject = emailSubject,
                Body = emailBody
            };
            await _mailService.SendEmailAsync(emailRequest).ConfigureAwait(false);
        }

        response.Data = new ForgotPasswordEmailResponse { Email = request.Email };
        return response;
    }

    async ValueTask<ResetPasswordResponse> IAuthRepository<ApplicationUser>.ResetPasswordAsync(ResetPasswordRequest request)
    {
        var response = new ResetPasswordResponse();

        var user = await _userManager.FindByNameAsync(request.Email.ToLower().Trim());
        if (user is null)
        {
            response.AddError(ErrorMessages.UserNotExistsError);
            return response;
        }

        var isValidToken = await _userManager.VerifyUserTokenAsync(user, _userManager.Options.Tokens.PasswordResetTokenProvider, "ResetPassword", request.ResetPasswordToken);

        if (!isValidToken)
        {
            response.AddError(ErrorMessages.PasswordUpdateError);
            return response;
        }

        var passwordChangeResult = await _userManager.ResetPasswordAsync(user, request.ResetPasswordToken, request.Password);

        if (!passwordChangeResult.Succeeded)
        {
            response.AddError(ErrorMessages.PasswordUpdateError);
            return response;
        }

        user.ModifiedDate = DateTimeOffset.Now;
        await _userManager.UpdateAsync(user).ConfigureAwait(false);

        return response;
    }

    async ValueTask<VerifyPasswordOTPResponse> IAuthRepository<ApplicationUser>.VerifyPasswordOTPAsync(VerifyPasswordOTPRequest request)
    {
        var response = new VerifyPasswordOTPResponse();

        var user = await _userManager.FindByNameAsync(request.Email.ToLower().Trim());
        if (user is null)
        {
            response.AddError(ErrorMessages.UserNotExistsError);
            return response;
        }

        if (user.PasswordOTP is null || IsOTPExpired(user.PasswordOTPDate, DateTimeOffset.Now))
        {
            response.AddError(ErrorMessages.InvalidOTPError);
            return response;
        }

        if (user.PasswordOTP is null || user.PasswordOTP != request.OTP)
        {
            response.AddError(ErrorMessages.InvalidOTPError);
            return response;
        }

        response.Data = new VerifyPasswordOTPToken()
        {
            ResetPasswordToken = await _userManager.GeneratePasswordResetTokenAsync(user).ConfigureAwait(false)
        };
        return response;
    }

    async ValueTask<AuthDTO> IAuthRepository<ApplicationUser>.MapAuthResponseAsync(ApplicationUser user) => await MapAuthAsync(user, _fileService);

    async ValueTask<AuthResponse> IAuthRepository<ApplicationUser>.UpdatePersonalInfoAsync(string userId, UpdatePersonalInfoRequest request)
    {
        var response = new AuthResponse();
        var user = await _context.Users
            .Include(x => x.Documents.Where(y => y.IsActive && y.DocumentType == DocumentType.User && y.FileType == FileType.Image))
            .FirstOrDefaultAsync(x => x.IsActive && x.Id == userId)
            .ConfigureAwait(false);

        if (user is null)
        {
            response.AddError(ErrorMessages.UserNotExistsError);
            return response;
        }

        Document? imageItem = user.Documents.FirstOrDefault(x => x.DocumentType == DocumentType.User && x.FileType == FileType.Image);

        if (request.RemoveProfilePicture)
            DeleteDocument(user, imageItem);

        if (request.ProfilePicture is not null)
        {
            DeleteDocument(user, imageItem);

            (var fileName, var filePath) = await _fileService.UploadFileAndGetNewFileNameAndPath(request.ProfilePicture, request.ProfilePicture.FileName).ConfigureAwait(false);

            imageItem = new Document
            {
                FileName = fileName,
                DocumentType = DocumentType.User,
                FileType = FileType.Image,
                Size = _fileService.GetFileSize(request.ProfilePicture),
                ApplicationUserId = user.Id,
                CreatedBy = _currentUser.Name,
                CreatedDate = DateTimeOffset.UtcNow,
            };

            user.Documents.Add(imageItem);
        }

        var oldUser = user.ShallowCopy();

        user.FirstName = request.FirstName.Trim();
        user.LastName = request.LastName?.Trim() ?? string.Empty;
        user.PhoneNumber = request.PhoneNumber;
        user.PhoneNumberConfirmed = request.PhoneNumber is null || user.PhoneNumber != request.PhoneNumber ? false : user.PhoneNumberConfirmed;
        user.Address1 = request.Address1;
        user.Address2 = request.Address2;
        user.State = request.State;
        user.City = request.City;
        user.ZipCode = request.ZipCode;
        user.ModifiedBy = _currentUser.Name;
        user.ModifiedDate = DateTimeOffset.Now;

        if (imageItem is not null && request.ProfilePicture is not null)
            await _context.AddAsync(imageItem).ConfigureAwait(false);

        await _context.SaveChangesAsync().ConfigureAwait(false);

        await _activityLogRepository.LogEntityChangesAsync(oldUser, user, ActionType.Modified).ConfigureAwait(false);

        response.Data = await MapAuthAsync(user, _fileService);
        return response;
    }

    async ValueTask<bool> IAuthRepository<ApplicationUser>.IsTokenVersionValidAsync(string userId, int tokenVersion) =>
        await _context.Users.AsNoTracking().AnyAsync(x => x.Id == userId && x.TokenVersion == tokenVersion && x.IsActive).ConfigureAwait(false);

    async ValueTask<AuthResponse> IAuthRepository<ApplicationUser>.DeleteUserByIdAsync(string userId)
    {
        var response = new AuthResponse();

        var user = await _context.Users
            .Include(x => x.Documents.Where(y => y.IsActive && y.DocumentType == DocumentType.User && y.FileType == FileType.Image))
            .FirstOrDefaultAsync(x => x.IsActive && x.Id == userId)
            .ConfigureAwait(false);

        if (user is null || !user.IsActive || user.Status == UserStatus.InActive)
        {
            response.AddError(ErrorMessages.UserNotExistsError);
            return response;
        }

        DeleteUserAsync(user);
        await _context.SaveChangesAsync().ConfigureAwait(false);

        response.Data = await MapAuthAsync(user, _fileService);

        return response;
    }

    private async ValueTask<AuthDTO> MapAuthAsync(ApplicationUser user, IFileService fileService)
    {
        var roles = await _userManager.GetRolesAsync(user).ConfigureAwait(false);

        var authDTO = new AuthDTO
        {
            Id = user.Id,
            FirstName = user.FirstName,
            LastName = user.LastName,
            Email = user.Email ?? string.Empty,
            BearerToken = GenerateToken(user, roles),
            PhoneNumber = user.PhoneNumber,
            Role = user.Role,
            Address1 = user.Address1,
            Address2 = user.Address2,
            State = user.State,
            City = user.City,
            ZipCode = user.ZipCode,
            ProfilePicture = user.Documents.Count == 0 ? null : user.Documents.Where(x => x.DocumentType == DocumentType.User && x.FileType == FileType.Image).Select(x => new DocumentDTO
            {
                Id = x.Id,
                Name = x.FileName,
                Size = x.Size,
                URL = fileService.GetFileURL(x.FileName),
                DocumentType = x.DocumentType,
            }).FirstOrDefault(),
            CreatedBy = user.CreatedBy,
            CreatedDate = user.CreatedDate,
            ModifiedBy = user.ModifiedBy,
            ModifiedDate = user.ModifiedDate,
        };
        return authDTO;
    }

    private string GenerateToken(ApplicationUser user, IList<string> roles)
    {
        List<Claim> claims = [
                new (ClaimTypes.NameIdentifier, user.Id),
                new (ClaimTypes.Name, $"{user.FirstName} {user.LastName}"),
                new ("tokenVersion", user.TokenVersion.ToString())
        ];

        foreach (var role in roles)
        {
            claims.Add(new(ClaimTypes.Role, role));
        }

        var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(AppEnvironment.AuthSecretKey));

        var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha512Signature);

        var token = new JwtSecurityToken(
                claims: claims,
                expires: DateTime.Now.AddDays(355),
                signingCredentials: creds
            );

        var jwt = new JwtSecurityTokenHandler().WriteToken(token);

        return jwt;
    }

    private int GenerateRandomNumber()
    {
        int _min = _otpMinValue;
        int _max = _otpMaxValue;
        Random _rdm = new();
        return _rdm.Next(_min, _max);
    }

    private bool IsOTPExpired(DateTimeOffset OTPDate, DateTimeOffset currentDate)
    {
        TimeSpan difference = currentDate - OTPDate;

        return Math.Abs(difference.TotalMinutes) >= AppEnvironment.OTPExpiry;
    }

    private void DeleteUserAsync(ApplicationUser user)
    {
        //user.Email = $"{user.Email} - (InActive)";
        user.Email = $"{user.Email} - {user.Id}";
        user.NormalizedEmail = user.Email.ToUpper();
        user.UserName = $"{user.UserName} - {user.Id}";
        user.NormalizedUserName = user.UserName.ToUpper();
        user.IsActive = false;
        user.Status = UserStatus.InActive;
        user.TokenVersion++;
        user.ModifiedBy = _currentUser.Name;
        user.ModifiedDate = DateTimeOffset.Now;

    }

    private void DeleteDocument(ApplicationUser user, Document? document)
    {
        if (document is null || string.IsNullOrEmpty(document.FileName))
            return;

        document.IsActive = false;
        document.ModifiedBy = _currentUser.Name;
        document.ModifiedDate = DateTimeOffset.Now;

        _fileService.DeleteUploadedFile(document.FileName);

        user.Documents.Remove(document);
    }

}
