﻿using ProjectName.AppConfigs.DTOs;
using ProjectName.AppConfigs.Entities;
using ProjectName.Data;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;

namespace ProjectName.Repositories;
public class AppConfigRepository :
	BaseRepository<AppConfig>,
	IAppConfigRepository<AppConfig>
{
	private readonly ApplicationDbContext _context;

	public AppConfigRepository(ApplicationDbContext context, IHttpContextAccessor httpContextAccessor) : base(context)
	{
		_context = context ?? throw new ArgumentNullException(nameof(context));
	}

	async ValueTask<GetAppVersionResponse> IAppConfigRepository<AppConfig>.GetAppVersionAsync()
	{
		var response = new GetAppVersionResponse();

		var versionSetting = await _context.AppConfig
			.AsNoTracking()
			.FirstOrDefaultAsync(x => x.SettingKey.ToLower().Trim() == "version")
			.ConfigureAwait(false);

		if (versionSetting is not null)
		{
			response.Version = versionSetting.SettingValue;
		}

		return response;
	}

	async ValueTask<GetAppConfigResponse> IAppConfigRepository<AppConfig>.GetAppConfigAsync(string name)
	{
		var response = new GetAppConfigResponse();

		var versionSetting = await _context.AppConfig
			.AsNoTracking()
			.FirstOrDefaultAsync(x => x.SettingKey.ToLower().Trim() == name.ToLower().Trim())
			.ConfigureAwait(false);

		if (versionSetting is not null)
		{
			response.Data = versionSetting.SettingValue;
		}

		return response;
	}

	async ValueTask<GetAppVersionResponse> IAppConfigRepository<AppConfig>.UpdateAppVersionAsync()
	{
		var response = new GetAppVersionResponse();

		var versionSetting = await _context.AppConfig
			.FirstOrDefaultAsync(x => x.SettingKey.ToLower().Trim() == "version")
			.ConfigureAwait(false);

		if (versionSetting is null)
		{
			response.AddError("Failed to update the build version.");
			return response;
		}

		versionSetting.SettingValue = IncrementVersion(versionSetting.SettingValue);

		await _context.SaveChangesAsync().ConfigureAwait(false);

		response.Version = versionSetting.SettingValue;
		return response;
	}

	private string IncrementVersion(string version)
	{
		var parts = version.Split('.');
		if (parts.Length != 3 ||
			!int.TryParse(parts[0], out int major) ||
			!int.TryParse(parts[1], out int minor) ||
			!int.TryParse(parts[2], out int patch))
		{
			throw new ArgumentException("Invalid version format. Expected format: X.Y.Z");
		}
		if (patch < 9)
		{
			patch++;
		}
		else
		{
			patch = 0;
			if (minor < 9)
			{
				minor++;
			}
			else
			{
				minor = 0;
				major++;
			}
		}
		return $"{major}.{minor}.{patch}";
	}

}