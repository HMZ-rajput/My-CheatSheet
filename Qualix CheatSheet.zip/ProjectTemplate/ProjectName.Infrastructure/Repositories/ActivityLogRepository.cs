﻿using ProjectName.Common.Extensions;
using Microsoft.EntityFrameworkCore;
using ProjectName.ActivityLogs.DTOs;
using ProjectName.ActivityLogs.Entities;
using ProjectName.Common.DTOs;
using ProjectName.Data;
using ProjectName.Identity.Entities;
using ProjectName.Services;
using System.Collections;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;

namespace ProjectName.Repositories;

public class ActivityLogRepository : BaseRepository<ActivityLog>, IActivityLogRepository<ActivityLog>
{
    private readonly IList<string> _excludedColumns = [
        "ModifiedBy", "ModifiedDate",
        "CreatedBy", "CreatedDate",
        "ShortId", "EstimateTime"
        ];

    private readonly ApplicationDbContext _context;
    private readonly CurrentUser _currentUser;
    public ActivityLogRepository(ApplicationDbContext context, CurrentUser currentUser) : base(context)
    {
        _context = context ?? throw new ArgumentNullException(nameof(context));
        _currentUser = currentUser ?? throw new ArgumentNullException(nameof(currentUser));
    }

    async Task IActivityLogRepository<ActivityLog>.LogEntityChangesAsync<T>([AllowNull] T oldEntity, T newEntity, ActionType actionType)
    {
        var log = CreateActivityLog(oldEntity, newEntity, actionType);

        if (log is null)
            return;

        await AddAsync(log).ConfigureAwait(false);
        await SaveChangesAsync().ConfigureAwait(false);
    }

    ActivityLog? IActivityLogRepository<ActivityLog>.LogEntityChanges<T>([AllowNull] T oldEntity, T newEntity, ActionType actionType)
        => CreateActivityLog(oldEntity, newEntity, actionType);

    async ValueTask<ActivityLogResponse> IActivityLogRepository<ActivityLog>.GetAllActivityLogsAsync(ActivityLogFilters filters)
    {
        var response = new ActivityLogResponse();

        IQueryable<ActivityLog> query = _context.ActivityLog
            .Where(x => x.IsActive)
            .OrderByDescending(x => x.CreatedDate);

        if (!string.IsNullOrEmpty(filters.EntityType))
            query = query.Where(x => x.EntityType!.ToLower() == filters.EntityType.ToLower());

        if (!string.IsNullOrEmpty(filters.EntityId))
            query = query.Where(x => x.EntityId!.ToLower() == filters.EntityId.ToLower());

        if (filters.StartDate is not null && filters.EndDate is not null)
            query = query.Where(x => x.CreatedDate >= filters.StartDate && x.CreatedDate <= filters.EndDate);

        if (!string.IsNullOrEmpty(filters.Search))
        {
            var search = $"%{filters.Search.Trim()}%";
            query = query.Where(x => EF.Functions.Like(x.Username, search)
            || EF.Functions.Like(x.Description, search)
            );
        }

        var formattedQuery = query.Select(x => new ActivityLogDTO
        {
            Id = x.Id,
            Name = x.Username,
            Description = x.Description,
            Date = x.CreatedDate,
            EntityType = x.EntityType,
            EntityId = x.EntityId,
        });

        var paginatedData = await PagedList<ActivityLogDTO>
        .ToPagedListAsync(
            formattedQuery,
            filters.PageNumber,
            filters.PageSize
        );

        response.Data = paginatedData;
        response = response.MapPaginationToResponse(paginatedData);
        return response;
    }

    private ActivityLog? CreateActivityLog<T>([AllowNull] T oldEntity, T newEntity, ActionType actionType)
    {
        if (actionType == ActionType.Created && newEntity == null)
            throw new Exception("For Create, newEntity should not be null.");
        if (actionType == ActionType.Deleted && newEntity == null)
            throw new Exception("For Delete, newEntity should not be null.");
        if (actionType == ActionType.Modified && (oldEntity == null || newEntity == null))
            throw new Exception("For Update, both oldEntity and newEntity must be provided.");

        var entityType = EntityTypeName(typeof(T).Name.ToReadableLabel());
        var entityKey = GetEntityKey(oldEntity ?? newEntity);
        if (entityKey.StartsWith("Id="))
            entityKey = entityKey.Substring(3);

        var descriptionLines = new List<string>();

        if (actionType == ActionType.Created)
        {
            descriptionLines.Add($"{entityType} has been created.");
        }
        else if (actionType == ActionType.Deleted)
        {
            descriptionLines.Add($"{entityType} has been deleted.");
        }
        else
        {
            IList<string> updatedValues = [];

            var properties = typeof(T).GetProperties();
            foreach (var property in properties)
            {
                var type = property.PropertyType;
                var oldValue = oldEntity != null ? property.GetValue(oldEntity)?.ToString() : null;
                var newValue = newEntity != null ? property.GetValue(newEntity)?.ToString() : null;

                if (type is null)
                    continue;

                if (IsGuidType(type) || IsGuidStringType(property.Name))
                    continue;

                if (IsDecimalType(type))
                {
                    oldValue = oldValue != null ? decimal.Parse(oldValue).DecimalToFormattedString() : null;
                    newValue = newValue != null ? decimal.Parse(newValue).DecimalToFormattedString() : null;
                }

                if (IsDateType(type))
                {
                    oldValue = oldValue != null ? DateTimeOffset.Parse(oldValue).ToString("MMMM dd yyyy") : null;
                    newValue = newValue != null ? DateTimeOffset.Parse(newValue).ToString("MMMM dd yyyy") : null;
                }

                if (IsTimeType(type))
                {
                    oldValue = oldValue != null ? DateTime.Today.Add(TimeSpan.Parse(oldValue)).ToString("hh:mm tt") : null;
                    newValue = newValue != null ? DateTime.Today.Add(TimeSpan.Parse(newValue)).ToString("hh:mm tt") : null;
                }

                if (IsBoolType(type))
                {
                    oldValue = oldValue == "True" ? "Yes" : "No";
                    newValue = newValue == "True" ? "Yes" : "No";
                }

                if (IsEnumType(type))
                {
                    oldValue = oldEntity != null ? GetEnumDisplayName(property.GetValue(oldEntity)) : null;
                    newValue = newEntity != null ? GetEnumDisplayName(property.GetValue(newEntity)) : null;
                }

                if (type == typeof(ApplicationUser))
                {
                    var oldUser = oldEntity != null ? property.GetValue(oldEntity) : null;
                    var newUser = newEntity != null ? property.GetValue(newEntity) : null;

                    oldValue = oldUser != null ? type.GetProperty("FirstName")?.GetValue(oldUser)?.ToString() + " " + type.GetProperty("LastName")?.GetValue(oldUser)?.ToString() : null;
                    newValue = newUser != null ? type.GetProperty("FirstName")?.GetValue(newUser)?.ToString() + " " + type.GetProperty("LastName")?.GetValue(newUser)?.ToString() : null;
                }

                bool isObject = !type.IsValueType && !(type == typeof(string) || type == typeof(ApplicationUser));

                if (isObject)
                {
                    oldValue = ExtractNameFromRawString(oldValue);
                    newValue = ExtractNameFromRawString(newValue);
                }

                if (newValue != oldValue && !_excludedColumns.Contains(property.Name) && !(oldValue ?? string.Empty).Equals(newValue ?? string.Empty))
                    updatedValues.Add($"{property.Name.ToReadableLabel()} from '{oldValue ?? string.Empty}' to '{newValue ?? string.Empty}'");
            }
            if (updatedValues.Any())
                descriptionLines.Add($"Updated {string.Join(", ", updatedValues)}");
        }

        if (descriptionLines.Any())
        {
            var log = new ActivityLog
            {
                EntityType = entityType,
                EntityId = entityKey,
                ActionType = actionType,
                Description = string.Join(Environment.NewLine, descriptionLines),
                UserId = _currentUser.Id,
                Username = _currentUser.Name ?? AppEnvironment.CreatedBySystem,
                CreatedBy = _currentUser.Name ?? AppEnvironment.CreatedBySystem
            };

            return log;
        }

        return null;
    }

    private string GetEntityKey<T>(T entity)
    {
        var keyProps = typeof(T).GetProperties()
            .Where(p => p.GetCustomAttributes(typeof(KeyAttribute), false).Any())
            .ToList();

        if (keyProps.Any())
        {
            return string.Join(",", keyProps.Select(p => $"{p.Name}={p.GetValue(entity)}"));
        }
        else
        {
            var idProp = typeof(T).GetProperties()
                .FirstOrDefault(p => string.Equals(p.Name, "Id", StringComparison.OrdinalIgnoreCase));

            if (idProp != null)
            {
                return $"{idProp.Name}={idProp.GetValue(entity)}";
            }
        }

        return string.Empty;
    }

    bool IsGuidType(Type type)
    {
        return type == typeof(Guid)
            || type == typeof(Guid?);
    }

    bool IsGuidStringType(string propertyName)
    {
        return propertyName.EndsWith("Id");
    }

    bool IsDecimalType(Type type)
    {
        return type == typeof(decimal)
            || type == typeof(decimal?);
    }

    bool IsBoolType(Type type)
    {
        return type == typeof(bool)
            || type == typeof(bool?);
    }

    bool IsEnumType(Type type)
    {
        if (type.IsEnum)
            return true;

        var underlyingType = Nullable.GetUnderlyingType(type);
        return underlyingType?.IsEnum == true;
    }

    bool IsEnumerableType(Type type)
    {
        return (type.Name != nameof(String)
            && type.GetInterface(nameof(IEnumerable)) != null);
    }

    bool IsDateType(Type type)
    {
        return type == typeof(DateTimeOffset)
            || type == typeof(DateTimeOffset?);
    }

    bool IsTimeType(Type type)
    {
        return type == typeof(TimeSpan)
            || type == typeof(TimeSpan?);
    }

    private static string ExtractNameFromRawString(string? raw)
    {
        var name = string.Empty;

        if (string.IsNullOrWhiteSpace(raw))
            return name;

        int start = raw.IndexOf('{');
        int end = raw.LastIndexOf('}');

        if (start == -1 || end == -1 || end <= start)
            return name;

        string inner = raw.Substring(start + 1, end - start - 1);

        var parts = inner.Split(',');

        foreach (var part in parts)
        {
            var kv = part.Split('=');
            if (kv.Length == 2 && kv[0].Trim() == "Name")
            {
                return kv[1].Trim();
            }
        }

        return name;
    }

    private static string? EntityTypeName(string? entityType)
    {
        return entityType switch
        {
            "Application User" => "User",
            _ => entityType
        };
    }

    private static string? GetEnumDisplayName(object? property)
    {
        if (property == null)
            return null;

        var type = property.GetType();

        if (type.IsGenericType && type.GetGenericTypeDefinition() == typeof(Nullable<>))
            type = Nullable.GetUnderlyingType(type)!;

        var enumName = Enum.GetName(type, property).ToReadableLabel();
        if (enumName == null)
            return enumName;

        var member = type.GetMember(Enum.GetName(type, property) ?? string.Empty).FirstOrDefault();
        if (member == null)
            return enumName;

        var displayAttr = member.GetCustomAttributes(typeof(DisplayAttribute), false)
                                .Cast<DisplayAttribute>()
                                .FirstOrDefault();
        return displayAttr?.Name ?? enumName;
    }

}