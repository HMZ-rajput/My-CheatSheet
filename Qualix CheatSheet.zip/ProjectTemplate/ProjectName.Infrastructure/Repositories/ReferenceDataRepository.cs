﻿using System.Reflection;
using ProjectName.Data;
using ProjectName.ReferenceData.DTOs;
using ProjectName.ReferenceData.Entities;
using ProjectName.Services;
using Microsoft.EntityFrameworkCore;

namespace ProjectName.Repositories
{
    public class ReferenceDataRepository<TEntity> :
      BaseRepository<TEntity>,
      IReferenceDataRepository<TEntity> where TEntity : ReferenceDataEntity
    {
        private readonly ApplicationDbContext _context;
        private readonly CurrentUser _currentUser;

        public ReferenceDataRepository(ApplicationDbContext context, CurrentUser currentUser) : base(context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));
            _currentUser = currentUser ?? throw new ArgumentNullException(nameof(currentUser));
        }

        async ValueTask<GetReferenceEntityResponse> IReferenceDataRepository<TEntity>.CreateAsync(string entityName, ReferenceDataDTO request)
        {
            var response = new GetReferenceEntityResponse();

            var dbSet = GetReferenceDataDBSet(entityName);

            var newEntity = Activator.CreateInstance<TEntity>();

            var existingItem = await RestoreSoftDeltedItemAsync(dbSet, request.Name, newEntity.Id, null);

            if (existingItem is not null)
            {
                response.Data = existingItem;
                return response;
            }

            var entity = MapReferenceDataDTOToEntity(newEntity, request, false);

            dbSet.Add(entity);
            await _context.SaveChangesAsync().ConfigureAwait(false);

            response.Data = MapReferenceDataEntityToDTO(entity);

            return response;
        }

        async ValueTask<GetReferenceDataListResponse> IReferenceDataRepository<TEntity>.GetAllAsync(string entityName)
        {
            var response = new GetReferenceDataListResponse();

            var dbSet = GetReferenceDataDBSet(entityName);

            response.Data = await dbSet
                .AsNoTracking()
                .Where(x => x.IsActive)
                .OrderBy(x => x.Name)
                .Select(x => MapReferenceDataEntityToDTO(x))
                .ToListAsync()
                .ConfigureAwait(false);

            return response;
        }

        async ValueTask<GetReferenceEntityResponse> IReferenceDataRepository<TEntity>.UpdateAsync(string entityName, GetReferenceDataDTO request)
        {
            var response = new GetReferenceEntityResponse();

            var dbSet = GetReferenceDataDBSet(entityName);

            var item = await GetItemByIdAsync(dbSet, request.Id, entityName).ConfigureAwait(false);

            var existingItem = await RestoreSoftDeltedItemAsync(dbSet, request.Name, item.Id, item);
            if (existingItem is not null)
            {
                response.Data = existingItem;
                return response;
            }

            item = MapReferenceDataDTOToEntity(item, request, true);
            await _context.SaveChangesAsync().ConfigureAwait(false);

            response.Data = MapReferenceDataEntityToDTO(item);
            return response;
        }

        async ValueTask<GetReferenceEntityResponse> IReferenceDataRepository<TEntity>.DeleteAsync(string entityName, Guid id)
        {
            var response = new GetReferenceEntityResponse();

            var dbSet = GetReferenceDataDBSet(entityName);

            var item = await GetItemByIdAsync(dbSet, id, entityName).ConfigureAwait(false);

            item.IsActive = false;
            await _context.SaveChangesAsync().ConfigureAwait(false);

            response.Data = MapReferenceDataEntityToDTO(item);
            return response;
        }

        async ValueTask<GetReferenceEntityResponse> IReferenceDataRepository<TEntity>.GetItemByIdAsync(string entityName, Guid id)
        {
            var response = new GetReferenceEntityResponse();

            var dbSet = GetReferenceDataDBSet(entityName);

            var item = await GetItemByIdAsync(dbSet, id, entityName).ConfigureAwait(false);

            response.Data = MapReferenceDataEntityToDTO(item);
            return response;
        }

        private async ValueTask<GetReferenceDataDTO?> RestoreSoftDeltedItemAsync(DbSet<TEntity> dbSet, string newItemName, Guid itemId, TEntity? item)
        {
            var deletedItem = await dbSet
                .FirstOrDefaultAsync(x => x.Id != itemId
                    && x.Name.ToLower().Trim() == newItemName.ToLower().Trim())
                .ConfigureAwait(false);

            if (deletedItem is null)
            {
                return null;
            }

            if (deletedItem.IsActive)
            {
                throw new ArgumentException($"{newItemName} already exists.");
            }

            if (item is not null)
            {
                item.IsActive = true;
                item.ModifiedBy = _currentUser.Name;
                item.ModifiedDate = DateTimeOffset.UtcNow;
            }

            deletedItem.IsActive = true;
            deletedItem.ModifiedBy = _currentUser.Name;
            deletedItem.ModifiedDate = DateTimeOffset.UtcNow;

            await _context.SaveChangesAsync().ConfigureAwait(false);
            return MapReferenceDataEntityToDTO(deletedItem);
        }

        private DbSet<TEntity> GetReferenceDataDBSet(string entityName)
        {
            var property = _context.GetType().GetProperty(entityName, BindingFlags.IgnoreCase | BindingFlags.Public | BindingFlags.Instance);
            if (property == null)
            {
                throw new ArgumentException($"DbSet for entity '{entityName}' not found in the context.", nameof(entityName));
            }

            var dbSet = property.GetValue(_context) as DbSet<TEntity>;
            if (dbSet == null)
            {
                throw new InvalidOperationException($"DbSet for entity '{entityName}' is not of type DbSet<{typeof(TEntity).Name}>.");
            }

            return dbSet;
        }

        private TEntity MapReferenceDataDTOToEntity(TEntity entity, ReferenceDataDTO dto, bool isUpdateRequest)
        {
            entity.Name = dto.Name;
            entity.CreatedBy = isUpdateRequest ? entity.CreatedBy : _currentUser.Name;
            entity.ModifiedBy = isUpdateRequest ? _currentUser.Name : null;
            entity.ModifiedDate = isUpdateRequest ? DateTimeOffset.UtcNow : null;

            return entity;
        }

        private static GetReferenceDataDTO MapReferenceDataEntityToDTO(TEntity entity)
            => new()
            {
                Id = entity.Id,
                Name = entity.Name
            };

        private static async ValueTask<TEntity> GetItemByIdAsync(DbSet<TEntity> dbSet, Guid id, string entityName)
        {
            var item = await dbSet
                .FirstOrDefaultAsync(x => x.Id == id && x.IsActive)
                .ConfigureAwait(false);

            if (item is null)
            {
                throw new ArgumentException($"{entityName} not found.");
            }

            return item;
        }

        async ValueTask<TEntity> IReferenceDataRepository<TEntity>.GetEntityByIdAsync(string entityName, Guid id)
        {
            var dbSet = GetReferenceDataDBSet(entityName);
            return await GetItemByIdAsync(dbSet, id, entityName).ConfigureAwait(false);
        }
    }
}
