﻿using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc.Filters;

namespace ProjectName.Middlewares
{
    public class CaptureModelStateFilter : IActionFilter
    {
        public void OnActionExecuting(ActionExecutingContext context)
        {
            if (!context.ModelState.IsValid)
            {
                string error = string.Empty;

                var errorList = context.ModelState
                    .Where(m => m.Value!.Errors.Any())
                    .SelectMany(m => m.Value!.Errors)
                    .Select(e => e.ErrorMessage)
                    .Order()
                    .ToList();

                error = string.Join("[[]]", errorList ?? [AppEnvironment.InvalidModelStateError]);

                throw new ValidationException(error);
            }
        }

        public void OnActionExecuted(ActionExecutedContext context)
        {
        }
    }
}
