﻿using System.ComponentModel.DataAnnotations;
using ProjectName.Common.DTOs;
using System.Net;

namespace ProjectName.Middlewares
{
    public class ExceptionHandlingMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly ILogger<ExceptionHandlingMiddleware> _logger;
        public ExceptionHandlingMiddleware(RequestDelegate next, ILogger<ExceptionHandlingMiddleware> logger)
        {
            _next = next;
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        public async Task InvokeAsync(HttpContext context)
        {
            try
            {
                await _next(context);
            }
            catch (ValidationException ex)
            {
                _logger.LogInformation($"Validation Error: {ex.Message} - {ex.InnerException}");
                await HandleValidationExceptionAsync(context, ex);
            }
            catch (Exception ex)
            {
                _logger.LogInformation($"Validation Error: {ex.Message} - {ex.InnerException}");
                await HandleExceptionAsync(context, ex);
            }
        }
        private static Task HandleValidationExceptionAsync(HttpContext context, ValidationException exception)
        {
            var response = new ErrorResponse();
            response.AddError(AppEnvironment.GenericSQLDatabaseError);
            exception.Message.Split("[[]]").ToList().ForEach(response.AddError);
            context.Response.ContentType = "application/json";
            context.Response.StatusCode = (int)HttpStatusCode.OK;

            return context.Response.WriteAsJsonAsync(response);
        }
        private static Task HandleExceptionAsync(HttpContext context, Exception exception)
        {
            var response = new ErrorResponse();
            response.AddError(AppEnvironment.GenericSQLDatabaseError);
            response.AddError(exception.Message);
            context.Response.ContentType = "application/json";
            context.Response.StatusCode = (int)HttpStatusCode.OK;

            return context.Response.WriteAsJsonAsync(response);
        }
    }
}
