﻿using ProjectName.AppConfigs.DTOs;
using ProjectName.Identity.Entities;
using ProjectName.Repositories;
using Microsoft.AspNetCore.Authorization;
using System.Security.Claims;

namespace ProjectName.Middlewares;

public class TokenVersionHandler : AuthorizationHandler<TokenVersionRequirement>
{
    private readonly IAuthRepository<ApplicationUser> _authRepository;

    public TokenVersionHandler(IAuthRepository<ApplicationUser> authRepository)
    {
        _authRepository = authRepository ?? throw new ArgumentNullException(nameof(authRepository));
    }

    protected override async Task HandleRequirementAsync(AuthorizationHandlerContext context, TokenVersionRequirement requirement)
    {
        var userId = context.User.FindFirst(ClaimTypes.NameIdentifier)?.Value;

        var tokenVersionClaim = context.User.FindFirst("tokenVersion")?.Value;

        if (string.IsNullOrEmpty(userId) || string.IsNullOrEmpty(tokenVersionClaim) || !int.TryParse(tokenVersionClaim, out var tokenVersionFromToken))
            return;

        var isValid = await _authRepository.IsTokenVersionValidAsync(userId, tokenVersionFromToken);

        if (isValid)
            context.Succeed(requirement);
    }
}