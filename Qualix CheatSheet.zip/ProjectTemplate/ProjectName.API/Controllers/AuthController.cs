﻿using Microsoft.AspNetCore.Mvc;
using ProjectName.Identity.DTOs;
using ProjectName.Identity.Entities;
using ProjectName.Repositories;

namespace ProjectName.Controllers
{
    [Route("api/auth")]
    [ApiController]
    public class AuthController : BaseController<AuthController>
    {
        private readonly IAuthRepository<ApplicationUser> _authRepository;
        private readonly ILogger<AuthController> _logger;
        public AuthController(IAuthRepository<ApplicationUser> authRepository, ILogger<AuthController> logger) : base(logger)
        {
            _authRepository = authRepository ?? throw new ArgumentNullException(nameof(authRepository));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        [Route("signUp")]
        [HttpPost]
        public async ValueTask<IActionResult> SignUpAsync(SignUpRequest request)
        {
            return await HandleRequestAsync(() => _authRepository.SignUpAsync(request)).ConfigureAwait(false);
        }
        [Route("login")]
        [HttpPost]
        public async ValueTask<IActionResult> LoginAsync([FromBody] LoginRequest request) => await HandleRequestAsync(() => _authRepository.LoginAsync(request)).ConfigureAwait(false);

        [Route("changePassword")]
        [HttpPost]
        public async ValueTask<IActionResult> ChangePasswordAsync(ChangePasswordRequest request)
        {
            return await HandleRequestAsync(() => _authRepository.ChangePasswordAsync(request)).ConfigureAwait(false);
        }

        [Route("getUserInfo")]
        [HttpGet]
        public async ValueTask<IActionResult> GetUserInfoAsync()
        {
            return await HandleRequestAsync(_authRepository.GetUserInfoAsync).ConfigureAwait(false);
        }

        [Route("sendForgotPasswordEmail")]
        [HttpPost]
        public async ValueTask<IActionResult> SendForgotPasswordEmailAsync([FromBody] SendForgotPasswordEmailRequest request) =>
        await HandleRequestAsync(() => _authRepository.SendForgotPasswordEmailAsync(request))
       .ConfigureAwait(false);

        [Route("verifyPasswordOTP")]
        [HttpPost]
        public async ValueTask<IActionResult> VerifyPasswordOTPAsync([FromBody] VerifyPasswordOTPRequest request) =>
        await HandleRequestAsync(() => _authRepository.VerifyPasswordOTPAsync(request))
       .ConfigureAwait(false);

        [Route("resetPassword")]
        [HttpPost]
        public async ValueTask<IActionResult> ResetPasswordAsync([FromBody] ResetPasswordRequest request) =>
        await HandleRequestAsync(() => _authRepository.ResetPasswordAsync(request))
       .ConfigureAwait(false);

        [Route("update/accountSetting/{id}")]
        [HttpPut]
        public async ValueTask<IActionResult> UpdatePersonalInfoAsync(string id, [FromForm] UpdatePersonalInfoRequest request)
        {
            return await HandleRequestAsync(() => _authRepository.UpdatePersonalInfoAsync(id, request)).ConfigureAwait(false);
        }

        [HttpDelete("{id}")]
        public async ValueTask<IActionResult> DeleteUserByIdAsync(string id)
        {
            return await HandleRequestAsync(() => _authRepository.DeleteUserByIdAsync(id)).ConfigureAwait(false);
        }

    }
}
