﻿using ProjectName.ReferenceData.DTOs;
using ProjectName.ReferenceData.Entities;
using ProjectName.Repositories;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace ProjectName.Controllers
{
    [Route("api/referenceData/[controller]")]
    [ApiController]
    public class ReferenceDataController<TEntity> : BaseController<ReferenceDataEntity> where TEntity : ReferenceDataEntity
    {
        private readonly IReferenceDataRepository<TEntity> _referenceDataRepository;
        private readonly string _entityName;

        public ReferenceDataController(ILogger<ReferenceDataEntity> logger, IReferenceDataRepository<TEntity> referenceDataRepository, string entityName) : base(logger)
        {
            _referenceDataRepository = referenceDataRepository ?? throw new ArgumentNullException(nameof(referenceDataRepository));
            _entityName = entityName ?? throw new ArgumentNullException(nameof(entityName));
        }

        [Authorize]
        [HttpPost("create")]
        public async ValueTask<IActionResult> CreateAsync([FromBody] ReferenceDataDTO request) =>
            await HandleRequestAsync(() => _referenceDataRepository.CreateAsync(_entityName, request)).ConfigureAwait(false);

        [HttpGet]
        public async ValueTask<IActionResult> GetAllAsync() =>
            await HandleRequestAsync(() => _referenceDataRepository.GetAllAsync(_entityName)).ConfigureAwait(false);

        [HttpGet("{id}")]
        public async ValueTask<IActionResult> GetByIdAsync(Guid id) =>
            await HandleRequestAsync(() => _referenceDataRepository.GetItemByIdAsync(_entityName, id)).ConfigureAwait(false);

        [Authorize]
        [HttpPut("update")]
        public async ValueTask<IActionResult> UpdateAsync([FromBody] GetReferenceDataDTO request) =>
            await HandleRequestAsync(() => _referenceDataRepository.UpdateAsync(_entityName, request)).ConfigureAwait(false);

        [Authorize]
        [HttpDelete("{id}")]
        public async ValueTask<IActionResult> DeleteAsync(Guid id) =>
            await HandleRequestAsync(() => _referenceDataRepository.DeleteAsync(_entityName, id)).ConfigureAwait(false);
    }
}
