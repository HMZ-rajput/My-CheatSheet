﻿using Microsoft.AspNetCore.Mvc;
using ProjectName.Common.CustomAttributes;
using ProjectName.Common.DTOs;

namespace ProjectName.Controllers
{
    public class BaseController<EntityC> : ControllerBase
    {
        private readonly ILogger<EntityC> _logger;
        public BaseController(ILogger<EntityC> logger)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        protected async ValueTask<IActionResult> HandleRequestAsync<T>(Func<ValueTask<T>> func) where T : BaseResponse, new()
        {
            var response = new T();
            try
            {
                response = await func().ConfigureAwait(false);
                if (!response.IsSuccess)
                {
                    return BadRequest(response);
                }
                return Ok(response);
            }
            catch (CustomException ex)
            {
                _logger.LogInformation($"Custom Error: {ex.Message}{(ex.InnerException is not null ? $" - {ex.InnerException}" : string.Empty)}");
                response.Errors.Add(ex.Message);
                return BadRequest(response);
            }
            catch (Exception ex)
            {
                _logger.LogInformation($"{ex.GetType().Name} Error: {ex.Message}{(ex.InnerException != null ? $" - {ex.InnerException}" : string.Empty)}");
                response.Errors.Add(AppEnvironment.GenericSQLDatabaseError);
                return BadRequest(response);
            }
        }

        protected IActionResult HandleRequest<T>(Func<T> func) where T : BaseResponse, new()
        {
            var response = new T();
            try
            {
                response = func();
                return Ok(response);
            }
            catch (CustomException ex)
            {
                _logger.LogInformation($"Custom Error: {ex.Message}{(ex.InnerException is not null ? $" - {ex.InnerException}" : string.Empty)}");
                response.Errors.Add(ex.Message);
                return BadRequest(response);
            }
            catch (Exception ex)
            {
                _logger.LogInformation($"{ex.GetType().Name} Error: {ex.Message}{(ex.InnerException != null ? $" - {ex.InnerException}" : string.Empty)}");
                response.Errors.Add(AppEnvironment.GenericSQLDatabaseError);
                return BadRequest(response);
            }
        }
    }
}
