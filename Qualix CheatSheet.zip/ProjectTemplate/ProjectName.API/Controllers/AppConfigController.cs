﻿using ProjectName.AppConfigs.Entities;
using ProjectName.Repositories;
using Microsoft.AspNetCore.Mvc;

namespace ProjectName.Controllers;

[Route("api/config")]
[ApiController]
public class AppConfigController : BaseController<AppConfigController>
{
	private readonly IAppConfigRepository<AppConfig> _appConfigRepository;
	private readonly ILogger<AppConfigController> _logger;

	public AppConfigController(IAppConfigRepository<AppConfig> appConfigRepository, ILogger<AppConfigController> logger) : base(logger)
	{
		_appConfigRepository = appConfigRepository ?? throw new ArgumentNullException(nameof(appConfigRepository));
		_logger = logger ?? throw new ArgumentNullException(nameof(logger));
	}

	[HttpGet("version")]
	public async ValueTask<IActionResult> GetAppVersionAsync() =>
		await HandleRequestAsync(_appConfigRepository.GetAppVersionAsync);

	[HttpGet("{name}")]
	public async ValueTask<IActionResult> GetAppVersionAsync(string name) =>
		await HandleRequestAsync(() => _appConfigRepository.GetAppConfigAsync(name));

	[HttpPost("version")]
	public async ValueTask<IActionResult> UpdateAppVersionAsync() =>
		await HandleRequestAsync(_appConfigRepository.UpdateAppVersionAsync);

}