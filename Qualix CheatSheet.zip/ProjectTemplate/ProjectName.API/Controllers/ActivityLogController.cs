﻿using ProjectName.ActivityLogs.DTOs;
using ProjectName.ActivityLogs.Entities;
using ProjectName.Repositories;
using Microsoft.AspNetCore.Mvc;

namespace ProjectName.Controllers;

[ApiController]
[Route("api/activityLog")]
public class ActivityLogController : BaseController<ActivityLogController>
{
    private readonly IActivityLogRepository<ActivityLog> _activityLogRepository;
    private readonly ILogger<ActivityLogController> _logger;

    public ActivityLogController(IActivityLogRepository<ActivityLog> activityLogRepository, ILogger<ActivityLogController> logger) : base(logger)
    {
        _activityLogRepository = activityLogRepository ?? throw new ArgumentNullException(nameof(activityLogRepository));
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    [HttpGet]
    public async ValueTask<IActionResult> GetActivityLogsAsync([FromQuery] ActivityLogFilters filters) =>
        await HandleRequestAsync(() => _activityLogRepository.GetAllActivityLogsAsync(filters)).ConfigureAwait(false);
}
