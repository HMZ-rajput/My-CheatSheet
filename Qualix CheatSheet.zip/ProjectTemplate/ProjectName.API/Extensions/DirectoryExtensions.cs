﻿namespace ProjectName.Extensions
{
    public static class DirectoryExtensions
    {
        public static void EnsureDirectoryExists(this string directoryPath)
        {
            if (!Directory.Exists(directoryPath))
            {
                Directory.CreateDirectory(directoryPath);
            }
        }
    }
}
