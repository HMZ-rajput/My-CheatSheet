﻿using ProjectName.Middlewares;
using Microsoft.AspNetCore.Authorization;

namespace ProjectName;

public static class DependencyInjection
{
    public static IServiceCollection AddAPI(this IServiceCollection services)
    {
        services.AddApplication();
        services.AddInfrastructure(AppEnvironment.ConnectionString);
        services.AddScoped<IAuthorizationHandler, TokenVersionHandler>();
        services.AddSingleton<IAuthorizationMiddlewareResultHandler, CustomAuthorizationMiddlewareResultHandler>();

        return services;
    }
}
