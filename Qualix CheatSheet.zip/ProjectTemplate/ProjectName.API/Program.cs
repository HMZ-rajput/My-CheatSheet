using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using ProjectName;
using ProjectName.AppConfigs.DTOs;
using ProjectName.Common;
using ProjectName.Data;
using ProjectName.Extensions;
using ProjectName.Identity.Entities;
using ProjectName.Middlewares;
using Quartz;
using Serilog;
using System.Text;

var builder = WebApplication.CreateBuilder(args);

Path.Combine(Directory.GetCurrentDirectory(), "wwwroot").EnsureDirectoryExists();
builder.Services.AddControllers();

builder.Services.AddAuthentication().AddJwtBearer(options =>
{
    options.TokenValidationParameters = new TokenValidationParameters
    {
        ValidateIssuerSigningKey = true,
        ValidateAudience = false,
        ValidateIssuer = false,
        IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(AppEnvironment.AuthSecretKey))
    };
});

builder.Services.AddQuartz(q =>
{
    // Register a job
    //    var jobKey = new JobKey("MyJob");
    //    q.AddJob<RecurringAppointmentService>(opts => opts.WithIdentity(jobKey));

    //    // Define a trigger
    //    q.AddTrigger(opts => opts
    //        .ForJob(jobKey)
    //        .WithIdentity("MyJob-trigger")
    //        .WithSimpleSchedule(x => x.WithIntervalInSeconds(10).RepeatForever()));
});

builder.Services.AddQuartzHostedService(q => q.WaitForJobsToComplete = true);

builder.Services
    .AddControllers()
    .AddJsonOptions(options =>
    {
        options.JsonSerializerOptions.PropertyNameCaseInsensitive = true;
        options.JsonSerializerOptions.PropertyNamingPolicy = System.Text.Json.JsonNamingPolicy.CamelCase;
        options.JsonSerializerOptions.Converters.Add(new NullToEmptyStringConverter());
    });


builder.Services.AddEndpointsApiExplorer();

builder.Services.AddSwaggerGen(options =>
{
    options.CustomSchemaIds(type => type.ToString());

    options.SwaggerDoc("v1", new OpenApiInfo { Title = "ProjectName.Api", Version = "v1" });

    options.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
    {
        In = ParameterLocation.Header,
        Description = "Please enter a valid token",
        Name = "Authorization",
        Type = SecuritySchemeType.Http,
        BearerFormat = "JWT",
        Scheme = "Bearer"
    });

    options.AddSecurityRequirement(new OpenApiSecurityRequirement
                {
                    {
                        new OpenApiSecurityScheme
                        {
                            Reference = new OpenApiReference
                            {
                                Type=ReferenceType.SecurityScheme,
                                Id="Bearer"
                            }
                        },
                        new string[] { }
                    }
                });
});

builder.Services.AddAPI();

builder.Services.AddIdentityCore<ApplicationUser>(options => options.SignIn.RequireConfirmedAccount = false)
                .AddClaimsPrincipalFactory<ClaimsPrincipalFactory>()
                .AddTokenProvider<DataProtectorTokenProvider<ApplicationUser>>(TokenOptions.DefaultProvider)
                .AddRoles<IdentityRole>()
                .AddEntityFrameworkStores<ApplicationDbContext>();

//builder.Services.AddAuthorization();
builder.Services.AddAuthorization(options =>
{
    options.DefaultPolicy = new AuthorizationPolicyBuilder()
    .RequireAuthenticatedUser()
    .AddRequirements(new TokenVersionRequirement())
    .Build();
});

builder.Services.AddCors(p => p.AddPolicy("corsapp", builder =>
{
    builder.WithOrigins("*").AllowAnyMethod().AllowAnyHeader();
}));

builder.Services.AddHttpContextAccessor();

builder.Services.AddHttpClient();

builder.Host.UseSerilog((context, configuration) =>
    configuration
    .WriteTo.Console()
    .ReadFrom.Configuration(context.Configuration)
    );

builder.Services.AddControllers(options => options.Filters.Add<CaptureModelStateFilter>());

builder.Services.Configure<ApiBehaviorOptions>(options =>
{
    options.SuppressModelStateInvalidFilter = true;
});

var app = builder.Build();

app.UseSerilogRequestLogging(options =>
{
    options.EnrichDiagnosticContext = (diagnosticContext, httpContext) =>
    {
        diagnosticContext.Set("RequestHost", httpContext.Request.Host.Value);
        diagnosticContext.Set("RequestScheme", httpContext.Request.Scheme);
        diagnosticContext.Set("RemoteIpAddress", httpContext.Connection.RemoteIpAddress);
    };
});

app.UseMiddleware<ExceptionHandlingMiddleware>();
app.UseAuthentication();

if (AppEnvironment.Type != EnvironmentType.PROD)
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseCors(x => x
    .AllowAnyMethod()
    .AllowAnyHeader()
    .SetIsOriginAllowed(origin => true)
    .AllowCredentials());


app.MapFallbackToFile("index.html");

if (!app.Environment.IsDevelopment())
{
    app.UseHsts();
}

app.UseStaticFiles();

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();