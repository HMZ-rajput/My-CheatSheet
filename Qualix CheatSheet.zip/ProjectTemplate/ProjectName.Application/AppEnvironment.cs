﻿using MailKit.Security;

namespace ProjectName;

public static class AppEnvironment
{
	public static EnvironmentType Type { get; private set; }
	public const string DefaultConnectionString = "Server=(local)\\SQLEXPRESS;Database=ProjectName;TrustServerCertificate=True;Trusted_Connection=True;MultipleActiveResultSets=true";
	public static string ConnectionString { get; private set; } = DefaultConnectionString;
	public static string AuthSecretKey { get; private set; } = "ProjectNamealromaufmwitaltmm79!#!@#$*()&*($#Q#@$%@@$%&^!$@%#^@$^*&@%^%$@^$$@#%)@#$%@!!@#@$$$mmww@blvopgBN";
	public static string SenderEmailAddress { get; set; } = "qualixdev1@gmail.com";
	public static string SenderEmailPassword { get; set; } = "gpnb cswv icct dvac";
	public static string SMTPHost { get; private set; } = "smtp.gmail.com";
	public static int SMTPPort { get; private set; } = 587;
	public static string BaseURL { get; private set; } = "https://qa-ProjectName.naveedportfolio.com";
	public static bool EnableMailSSL { get; private set; } = true;
	public static SecureSocketOptions EmailSocketOption { get; private set; } = SecureSocketOptions.StartTls;
	public static int OTPExpiry { get; private set; } = 10;
	public static string GenericSQLDatabaseError { get; private set; } = "An error occurred while processing the data.";
	public static string InvalidModelStateError { get; private set; } = "One or more inputs are invalid. Please review the provided data and try again.";
	public static string CreatedBySystem { get; private set; } = "System";
	public static string AppName { get; set; } = "ProjectName";

	static AppEnvironment()
	{
		Type = EnvironmentType.LOCAL;
		switch (Type)
		{
			case EnvironmentType.PROD:
				SetUpProd();
				break;
			case EnvironmentType.QA:
				SetUpQA();
				break;
			case EnvironmentType.LOCAL:
				SetUpLocal();
				break;
			case EnvironmentType.DEV:
				SetUpDev();
				break;
			default:
				break;
		}
	}

	public static void SetUpLocal()
	{
		ConnectionString = DefaultConnectionString;
		BaseURL = "http://localhost:3000";
	}

	public static void SetUpQA()
	{
		ConnectionString = "Server=154.12.241.246;Database=qa-ProjectName;User ID=qualixadmin;Password=Qualix_Admin@156;MultipleActiveResultSets=true;TrustServerCertificate=True";
	}

	public static void SetUpDev()
	{
		ConnectionString = "Server=154.12.241.246;Database=qa-ProjectName;User ID=qualixadmin;Password=Qualix_Admin@156;MultipleActiveResultSets=true;TrustServerCertificate=True";
	}

	public static void SetUpProd()
	{
		ConnectionString = "Server=154.12.241.246;Database=ProjectName;User ID=qualixadmin;Password=Qualix_Admin@156;MultipleActiveResultSets=true;TrustServerCertificate=True";
		BaseURL = "https://ProjectName.naveedportfolio.com";
	}

}

public enum EnvironmentType
{
	LOCAL = 0,
	QA = 1,
	PROD = 2,
	DEV = 3
}
