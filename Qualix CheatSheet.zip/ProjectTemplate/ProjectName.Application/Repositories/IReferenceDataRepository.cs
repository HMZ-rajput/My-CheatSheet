﻿using ProjectName.ReferenceData.DTOs;
using ProjectName.ReferenceData.Entities;

namespace ProjectName.Repositories
{
    public interface IReferenceDataRepository<TEntity> :
    IBaseRepository<TEntity>,
    IDisposable where TEntity : ReferenceDataEntity
    {
        ValueTask<GetReferenceEntityResponse> CreateAsync(string entityName, ReferenceDataDTO request);
        ValueTask<GetReferenceDataListResponse> GetAllAsync(string entityName);
        ValueTask<GetReferenceEntityResponse> UpdateAsync(string entityName, GetReferenceDataDTO request);
        ValueTask<GetReferenceEntityResponse> DeleteAsync(string entityName, Guid id);
        ValueTask<GetReferenceEntityResponse> GetItemByIdAsync(string entityName, Guid id);
        ValueTask<TEntity> GetEntityByIdAsync(string entityName, Guid id);
    }
}
