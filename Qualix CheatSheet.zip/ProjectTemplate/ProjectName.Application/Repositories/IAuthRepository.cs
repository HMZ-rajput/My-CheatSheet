﻿using ProjectName.Identity.DTOs;
using ProjectName.Identity.Entities;

namespace ProjectName.Repositories
{
    public interface IAuthRepository<TEntity> : IBaseRepository<TEntity>, IDisposable where TEntity : class
    {
        ValueTask<AuthResponse> SignUpAsync(SignUpRequest request);
        ValueTask<AuthResponse> LoginAsync(LoginRequest request);
        ValueTask<AuthResponse> GetUserInfoAsync();
        ValueTask<ChangePasswordResponse> ChangePasswordAsync(ChangePasswordRequest request);
        ValueTask<SendForgotPasswordEmailResponse> SendForgotPasswordEmailAsync(SendForgotPasswordEmailRequest request);
        ValueTask<ResetPasswordResponse> ResetPasswordAsync(ResetPasswordRequest request);
        ValueTask<VerifyPasswordOTPResponse> VerifyPasswordOTPAsync(VerifyPasswordOTPRequest request);
        ValueTask<AuthDTO> MapAuthResponseAsync(ApplicationUser user);
        ValueTask<AuthResponse> UpdatePersonalInfoAsync(string userId, UpdatePersonalInfoRequest request);
        ValueTask<bool> IsTokenVersionValidAsync(string userId, int tokenVersion);
        ValueTask<AuthResponse> DeleteUserByIdAsync(string userId);
    }
}
