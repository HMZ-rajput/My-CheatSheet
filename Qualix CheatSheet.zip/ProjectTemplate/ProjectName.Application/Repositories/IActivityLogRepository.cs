﻿using ProjectName.ActivityLogs.DTOs;
using ProjectName.ActivityLogs.Entities;
using System.Diagnostics.CodeAnalysis;

namespace ProjectName.Repositories
{
    public interface IActivityLogRepository<TEntity> : IBaseRepository<ActivityLog>, IDisposable where TEntity : class
    {
        Task LogEntityChangesAsync<T>([AllowNull] T oldEntity, T newEntity, ActionType actionType);
        ActivityLog? LogEntityChanges<T>([AllowNull] T oldEntity, T newEntity, ActionType actionType);
        ValueTask<ActivityLogResponse> GetAllActivityLogsAsync(ActivityLogFilters filters);
    }
}
