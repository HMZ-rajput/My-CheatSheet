﻿using ProjectName.AppConfigs.DTOs;
using ProjectName.AppConfigs.Entities;

namespace ProjectName.Repositories;
public interface IAppConfigRepository<TEntity> :
	IBaseRepository<AppConfig>,
	IDisposable where TEntity : class
{
	ValueTask<GetAppVersionResponse> GetAppVersionAsync();
	ValueTask<GetAppConfigResponse> GetAppConfigAsync(string name);
	ValueTask<GetAppVersionResponse> UpdateAppVersionAsync();
}
