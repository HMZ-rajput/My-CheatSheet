﻿using ProjectName.Services;
using Microsoft.Extensions.DependencyInjection;

namespace ProjectName
{
	public static class DependencyInjection
	{
		public static IServiceCollection AddApplication(this IServiceCollection services)
		{
			services.AddHttpClient();
			services.AddScoped<IMailService, MailService>();
			services.AddScoped<IFileService, FileService>();

			return services;
		}
	}
}
