﻿using Microsoft.AspNetCore.Http;

namespace ProjectName.Services
{
    public interface IFileService
    {
        ValueTask<(string fileName, string filePath)> UploadFileAndGetNewFileNameAndPath(IFormFile file, string fileName);
        bool DeleteUploadedFile(string filePath);
        string GetFileURL(string? fileName);
        string GetFileSize(IFormFile file);
        string GetUploadDirectoryPath();
        ValueTask<byte[]> DownloadImageAsByteArrayAsync(string imageUrl);
        (string? newFileName, string? destinationFilePath) DuplicateFileAndGetNewFileNameAndPath(string fileName);

        ValueTask<(string fileName, string filePath)> UploadFileFromUrlAndGetNewFileNameAndPath(string imageUrl);
    }
}
