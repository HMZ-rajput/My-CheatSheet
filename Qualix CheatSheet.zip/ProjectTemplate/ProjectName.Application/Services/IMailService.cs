﻿using ProjectName.Mails.DTOs;

namespace ProjectName.Services;

public interface IMailService
{
    ValueTask<bool> SendEmailAsync(SendEmailRequest request);
}
