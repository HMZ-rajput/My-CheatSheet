﻿using System.Security.Cryptography;
using System.Text.RegularExpressions;

namespace ProjectName.Services;
public static class Password
{
    private static readonly char[] _punctuations = "!@#$%^&*()_-+=[{]};:>|./?".ToCharArray();
    private const int _length = 12;
    private const int _numberOfNonAlphanumericCharacters = 4;

    public static string Generate()
    {
        string password = GeneratePassword();
        bool isPasswordValid = IsValidPassword(password);

        while (!isPasswordValid)
        {
            password = GeneratePassword();
            isPasswordValid = IsValidPassword(password);
        }

        return password;
    }

    private static string GeneratePassword()
    {
        if (_length < 1 || _length > 128)
        {
            throw new ArgumentException("Invalid Password Length");
        }

        if (_numberOfNonAlphanumericCharacters > _length || _numberOfNonAlphanumericCharacters < 0)
        {
            throw new ArgumentException("Invalid Non-AlphaNumeric Character Length");
        }

        using (var rng = RandomNumberGenerator.Create())
        {
            var byteBuffer = new byte[_length];

            rng.GetBytes(byteBuffer);

            var count = 0;
            var characterBuffer = new char[_length];

            for (var iter = 0; iter < _length; iter++)
            {
                var i = byteBuffer[iter] % 87;

                if (i < 10)
                {
                    characterBuffer[iter] = (char)('0' + i);
                }
                else if (i < 36)
                {
                    characterBuffer[iter] = (char)('A' + i - 10);
                }
                else if (i < 62)
                {
                    characterBuffer[iter] = (char)('a' + i - 36);
                }
                else
                {
                    characterBuffer[iter] = _punctuations[i - 62];
                    count++;
                }
            }

            var rand = new Random();
            var randomDigit = rand.Next(0, 9);

            if (count >= _numberOfNonAlphanumericCharacters)
            {
                return new string(characterBuffer) + randomDigit;
            }

            int j;

            for (j = 0; j < _numberOfNonAlphanumericCharacters - count; j++)
            {
                int k;
                do
                {
                    k = rand.Next(0, _length);
                }
                while (!char.IsLetterOrDigit(characterBuffer[k]));

                characterBuffer[k] = _punctuations[rand.Next(0, _punctuations.Length)];
            }

            var newPassword = new string(characterBuffer) + randomDigit;

            return newPassword;
        }
    }

    public static bool IsValidPassword(string? password)
    {
        if (string.IsNullOrEmpty(password))
            return false;

        string pattern = @"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$";
        Regex regex = new Regex(pattern);

        return regex.IsMatch(password);
    }

}
