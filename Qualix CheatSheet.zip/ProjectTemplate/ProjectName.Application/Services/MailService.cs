﻿using ProjectName.Mails.DTOs;
using MailKit.Net.Smtp;
using MailKit.Security;
using Microsoft.Extensions.Logging;
using MimeKit;

namespace ProjectName.Services;

public class MailService : IMailService
{
    private readonly ILogger<MailService> _logger;
    public MailService(ILogger<MailService> logger)
    {
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    async ValueTask<bool> IMailService.SendEmailAsync(SendEmailRequest request)
    {
        int retryCount = 0;

        while (retryCount < 5)
        {
            retryCount++;

            try
            {
                var message = new MimeMessage();
                message.From.Add(new MailboxAddress(AppEnvironment.AppName, AppEnvironment.SenderEmailAddress));
                message.Subject = request.Subject;

                var bodyBuilder = new BodyBuilder();
                bodyBuilder.HtmlBody = request.Body;

                foreach (var toAddress in request.ToAddress)
                {
                    message.To.Add(new MailboxAddress(string.Empty, toAddress));
                }

                foreach (var ccAddress in request.Cc)
                {
                    message.Cc.Add(new MailboxAddress(string.Empty, ccAddress));
                }

                foreach (var bccAddress in request.Bcc)
                {
                    message.Bcc.Add(new MailboxAddress(string.Empty, bccAddress));
                }

                foreach (var attachment in request.Attachments)
                {
                    if (!File.Exists(attachment))
                        continue;

                    bodyBuilder.Attachments.Add(attachment);
                }

                message.Body = bodyBuilder.ToMessageBody();

                using (var client = new SmtpClient())
                {
                    client.Connect(AppEnvironment.SMTPHost, AppEnvironment.SMTPPort, SecureSocketOptions.StartTls);
                    client.Authenticate(AppEnvironment.SenderEmailAddress, AppEnvironment.SenderEmailPassword);
                    await client.SendAsync(message).ConfigureAwait(false);
                    await client.DisconnectAsync(true).ConfigureAwait(false);
                }

                retryCount = 6;
            }
            catch (Exception ex)
            {
                _logger.LogInformation($"Email Error: {ex.Message}{(ex.InnerException is not null ? $" - {ex.InnerException}" : string.Empty)}");

                if (retryCount == 4)
                {
                    return false;
                }
            }
        }

        return true;
    }

}
